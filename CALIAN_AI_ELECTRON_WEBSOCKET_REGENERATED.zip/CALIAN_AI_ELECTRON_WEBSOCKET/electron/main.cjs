const {app,BrowserWindow,dialog}=require('electron');
const {spawn}=require('node:child_process');
const path=require('node:path');
const fs=require('node:fs');
let backend;
const dev=!app.isPackaged;
function startBackend(){if(dev)return;
 const executable=process.execPath;
 const script=path.join(app.getAppPath(),'dist','backend.cjs');
 const staticDir=path.join(app.getAppPath(),'dist','calian','browser');
 backend=spawn(executable,[script],{env:{...process.env,ELECTRON_RUN_AS_NODE:'1',CALIAN_STATIC_DIR:staticDir,PORT:'8787'},stdio:'ignore',windowsHide:true});
 backend.on('error',e=>dialog.showErrorBox('Backend startup failed',e.message));
}
async function waitBackend(){for(let i=0;i<80;i++){try{const r=await fetch('http://127.0.0.1:8787/api/health');if(r.ok)return;}catch{}await new Promise(r=>setTimeout(r,250));}throw new Error('Backend did not start on port 8787');}
app.whenReady().then(async()=>{try{startBackend();await waitBackend();const win=new BrowserWindow({width:1440,height:920,minWidth:950,minHeight:650,backgroundColor:'#111827',webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}});await win.loadURL(dev?'http://127.0.0.1:4200':'http://127.0.0.1:8787');}catch(e){dialog.showErrorBox('CALIAN AI startup',String(e));app.quit();}});
app.on('window-all-closed',()=>app.quit());
app.on('before-quit',()=>{if(backend)backend.kill();});
