import { Injectable, NgZone } from '@angular/core';
import { consumeA2AEvent } from './protocol';
@Injectable({providedIn:'root'})
export class SocketService {
 private socket?:WebSocket;
 private opening?:Promise<WebSocket>;
 private pending=new Map<string,{resolve:(v:any)=>void;reject:(e:Error)=>void;chunks:string[];onChunk?:(v:string)=>void}>();
 constructor(private zone:NgZone){}
 private connect():Promise<WebSocket>{
  if(this.socket?.readyState===WebSocket.OPEN)return Promise.resolve(this.socket);
  if(this.opening)return this.opening;
  this.opening=new Promise((resolve,reject)=>{
   const ws=new WebSocket(`ws://${location.hostname||'127.0.0.1'}:8787/ws`);
   const timeout=setTimeout(()=>{ws.close();reject(new Error('Backend WebSocket connection timed out'));},10000);
   ws.onopen=()=>{clearTimeout(timeout);this.socket=ws;resolve(ws);};
   ws.onerror=()=>{clearTimeout(timeout);reject(new Error('Backend WebSocket unavailable on port 8787'));};
   ws.onclose=()=>{this.socket=undefined;this.opening=undefined;for(const p of this.pending.values())p.reject(new Error('Backend socket disconnected'));this.pending.clear();};
   ws.onmessage=(event)=>this.zone.run(()=>this.handle(JSON.parse(event.data)));
  }).finally(()=>{this.opening=undefined;});return this.opening;
 }
 private handle(msg:any){const p=this.pending.get(msg.id);if(!p)return;
  if(msg.type==='chunk'){p.chunks.push(msg.data);p.onChunk?.(p.chunks.join(''));return;}
  this.pending.delete(msg.id);
  if(msg.type==='error')p.reject(new Error(msg.error));
  else if(msg.type==='result')p.resolve(msg.data);
  else if(msg.type==='done')p.resolve(p.chunks.join(''));
 }
 async request(path:string,method:'GET'|'POST'='GET',body?:unknown,onChunk?:(v:string)=>void):Promise<any>{
  const ws=await this.connect();const id=crypto.randomUUID();return new Promise((resolve,reject)=>{
   const timeout=setTimeout(()=>{this.pending.delete(id);reject(new Error('Socket request timed out'));},190000);
   this.pending.set(id,{resolve:v=>{clearTimeout(timeout);resolve(v);},reject:e=>{clearTimeout(timeout);reject(e);},chunks:[],onChunk});
   ws.send(JSON.stringify({id,path,method,body}));
  });
 }
 async a2a(body:unknown,onChunk:(text:string)=>void):Promise<string>{
  let buffer='';let answer='';
  const process=(raw:string)=>{buffer+=raw;let match;while((match=buffer.match(/\r?\n\r?\n/))){const block=buffer.slice(0,match.index);buffer=buffer.slice((match.index||0)+match[0].length);const data=block.split(/\r?\n/).filter(x=>x.startsWith('data:')).map(x=>x.slice(5).trimStart()).join('\n');if(data){answer=consumeA2AEvent(data,answer);onChunk(answer);}}};
  await this.request('/api/a2a','POST',body,process);
  if(buffer.trim()){const data=buffer.split(/\r?\n/).filter(x=>x.startsWith('data:')).map(x=>x.slice(5).trimStart()).join('\n');if(data){answer=consumeA2AEvent(data,answer);onChunk(answer);}}
  return answer.trim();
 }
}
