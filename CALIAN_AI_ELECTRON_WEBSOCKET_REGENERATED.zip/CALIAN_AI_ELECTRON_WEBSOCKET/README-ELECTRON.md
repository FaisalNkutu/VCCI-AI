# CALIAN AI — Electron + Angular Material + WebSocket

## Windows quick start
1. Install Node.js 22 LTS.
2. Extract this ZIP to a **new** folder. Your existing working backups are not changed.
3. Open a terminal in the extracted folder and run `npm install`.
4. Copy `.env.example` to `.env`; set Python A2A and AI Core URLs if needed.
5. Start the existing Python A2A service (default port 9999) and optional AI Core registry.
6. Run `npm run dev` to start Angular, the WebSocket backend and the Electron desktop window.

## Build a standalone Windows executable
Run `npm run dist:win`. The portable EXE appears in `release/`. To create an installer instead run `npm run dist:win-installer`.

## Architecture
Angular Material in Electron -> WebSocket ws://127.0.0.1:8787/ws -> Express bridge -> Python A2A (SSE), trusted AI Core registry/agents.
The WebSocket bridge carries discovery, auto-selection, execution, and streaming data. Existing Express routes remain as internal backend adapters and for Paradigm callback support. Do not expose port 8787 beyond localhost.

## Notes
- The desktop application includes the Node bridge, **not** the external Python service or AI Core. Start those services separately.
- Auto-selection-only is enabled by default as in the original; uncheck it to execute the selected agent.
- The Java Paradigm callback is still supported through the existing HTTP endpoint `/api/paradigm/discovery`.
- This source conversion has not been end-to-end tested with your live services. Electron build requires downloading npm packages.
