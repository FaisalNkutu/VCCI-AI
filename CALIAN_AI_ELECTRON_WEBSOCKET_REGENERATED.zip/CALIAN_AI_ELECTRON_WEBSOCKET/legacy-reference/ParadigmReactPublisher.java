package com.calian.chat;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.Map;

/** Publishes the existing Paradigm AIService.LIST callback to the local React proxy. */
public final class ParadigmReactPublisher {
 private static final ObjectMapper JSON = new ObjectMapper();
 private static final HttpClient HTTP = HttpClient.newHttpClient();
 private ParadigmReactPublisher() {}

 public static void publish(Map<String, ? extends List<String>> commands, Map<String, String> urls) {
 String token = System.getenv("PARADIGM_BRIDGE_TOKEN");
 if (token == null || token.isBlank()) {
 System.err.println("Paradigm React bridge disabled: PARADIGM_BRIDGE_TOKEN is missing");
 return;
 }
 // Do not block the Swing event-dispatch thread or Paradigm callback.
 Thread worker = new Thread(() -> {
 try {
 var payload = JSON.writeValueAsString(Map.of(
 "commandList", commands == null ? Map.of() : commands,
 "agentURLs", urls == null ? Map.of() : urls));
 var request = HttpRequest.newBuilder(URI.create("http://127.0.0.1:8787/api/paradigm/discovery"))
 .timeout(Duration.ofSeconds(10))
 .header("Content-Type", "application/json")
 .header("X-Paradigm-Bridge-Token", token)
 .POST(HttpRequest.BodyPublishers.ofString(payload)).build();
 var response = HTTP.send(request, HttpResponse.BodyHandlers.ofString());
 if (response.statusCode() / 100 != 2)
 System.err.println("Paradigm React discovery publish failed: HTTP " + response.statusCode());
 else System.out.println("Paradigm agents published to React: " + response.body());
 } catch (Exception ex) {
 System.err.println("Paradigm React bridge: " + ex.getMessage());
 }
 }, "paradigm-react-discovery");
 worker.setDaemon(true);
 worker.start();
 }
}
