/**
 * CALIAN-owned read-only natural-language database adapter.
 * Does not alter the Python A2A executor or Fouad's GenerateSQL implementation.
 * For simple requests, generate a deterministic query. For more complex SINGLE-TABLE
 * requests, ask local Ollama for a JSON PLAN, and compile SQL from validated columns.
 */

export type SqlExecutor = (sql: string) => Promise<unknown>;
export type PlanGenerator = (question: string, table: string, columns: string[]) => Promise<unknown>;
export type SqlTranslation = { sql: string; method: 'deterministic' | 'ollama-plan' };

const IDENTIFIER = /^[A-Za-z_][A-Za-z_0-9]*$/;
const MUTATING_INTENT = /\b(?:delete|remove|drop|truncate|insert|update|alter|replace|grant|revoke|overwrite|erase|modify|create|execute|run a command)\b/i;
const SQL_PREFIX = /^(?:select|with|describe|desc|explain|insert|update|delete|create|alter|drop|truncate|replace|grant|revoke|call|set|use)\b/i;
const SHOW_SQL = /^show\s+(?:tables?|databases?|columns?|index(?:es)?|create|full|status|variables|processlist|grants|engines)\b/i;

export function isDirectSql(message: string): boolean { return SQL_PREFIX.test(message.trim()) || SHOW_SQL.test(message.trim()); }

function quoteIdentifier(name: string): string {
  if (!IDENTIFIER.test(name)) throw new Error(`Invalid SQL identifier: ${name}`);
  return '`' + name + '`';
}
function quotedTable(name: string): string {
  const chunks = name.split('.');
  if (chunks.length > 2 || !chunks.every(x => IDENTIFIER.test(x))) throw new Error('Invalid table name');
  return chunks.map(quoteIdentifier).join('.');
}
function namedTable(message: string): string | null {
  const quoted = message.match(/[`"]([A-Za-z_][A-Za-z_0-9]*(?:\.[A-Za-z_][A-Za-z_0-9]*)?)[`"](?!\w)/);
  if (quoted) return quoted[1];
  const matches = [...message.matchAll(/\b(?:from|in|within|table|of)\s+([A-Za-z_][A-Za-z_0-9]*(?:\.[A-Za-z_][A-Za-z_0-9]*)?)(?=\b)/gi)]
   .map(m => m[1]).filter(x => !/^(?:the|a|an|my|our|this|that|database|table|records|rows|entries|all|each|which|how|what)$/i.test(x));
  const underscored = matches.find(x => x.includes('_') || x.includes('.'));
  return underscored || matches[0] || null;
}
function countIntent(question: string): boolean {
 return /\bhow many\s+(?:(?:total|matching|all)\s+)?(?:rows?|records?|entries?)\b/i.test(question) ||
        /\b(?:count|number of|total number of)\s+(?:(?:all|the)\s+)?(?:rows?|records?|entries?)\b/i.test(question);
}
function listIntent(question: string): boolean {
 return /\b(?:show|list|display|fetch|retrieve|give me)\b/i.test(question) && /\b(?:rows?|records?|entries?)\b/i.test(question);
}
function maxRows(): number {
 const n = Number(process.env.CALIAN_DB_NL_MAX_ROWS || '100');
 return Number.isInteger(n) && n > 0 && n <= 500 ? n : 100;
}
function desiredLimit(question: string): number {
 const n = question.match(/\b(?:first|top|show|list|display|fetch|retrieve|give me)\s+(?:me\s+)?(?:the\s+)?(\d{1,4})\b/i);
 return n ? Math.max(1, Math.min(maxRows(), Number(n[1]))) : Math.min(maxRows(), 20);
}

/** Parse the A2A ExecuteSQL result for information_schema.columns metadata. */
export function extractColumnNames(payload: unknown): string[] {
 const found = new Set<string>();
 const seen = new Set<unknown>();
 function visit(v: unknown, depth: number): void {
  if (depth > 16 || v == null || seen.has(v) || found.size > 250) return;
  if (typeof v === 'string') {
   if (v.length > 250000) return;
   try { visit(JSON.parse(v), depth + 1); } catch { /* non-JSON message */ }
   return;
  }
  if (typeof v !== 'object') return;
  seen.add(v);
  if (Array.isArray(v)) { for (const x of v.slice(0,500)) visit(x,depth+1); return; }
  const o = v as Record<string, unknown>;
  for (const key of ['COLUMN_NAME','column_name','Field','field']) {
   const value = o[key];
   if (typeof value === 'string' && IDENTIFIER.test(value)) found.add(value);
  }
  for (const value of Object.values(o)) visit(value,depth+1);
 }
 visit(payload,0);
 return [...found];
}

function safeSqlValue(value: unknown): string {
 if (value === null) return 'NULL';
 if (typeof value === 'number' && Number.isFinite(value) && Math.abs(value) < 1e15) return String(value);
 if (typeof value === 'boolean') return value ? '1' : '0';
 // Fail closed instead of accepting arbitrary LLM-generated SQL fragments.
 if (typeof value !== 'string' || value.length > 128 || !/^[\p{L}\p{N} _.,:@\-]+$/u.test(value)) throw new Error('Unsafe or unsupported filter value');
 return `'${value}'`;
}

/** Compile a structured JSON plan; NEVER execute SQL text supplied by Ollama. */
export function compileReadOnlyPlan(raw: unknown, table: string, availableColumns: string[]): string {
 if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('Ollama returned an invalid query plan');
 const p = raw as Record<string, any>;
 if (p.table !== table) throw new Error('Ollama selected a different table; refusing execution');
 const columns = new Map(availableColumns.map(c => [c.toLowerCase(),c]));
 const col = (value: unknown): string => {
  if (typeof value !== 'string' || !IDENTIFIER.test(value)) throw new Error('Invalid column name from Ollama');
  const actual = columns.get(value.toLowerCase());
  if (!actual) throw new Error(`Unknown column requested by Ollama: ${value}`);
  return quoteIdentifier(actual);
 };
 const action = p.operation;
 if (!['count','list','aggregate'].includes(action)) throw new Error('Only count, list, and aggregate read-only operations are supported');
 let select: string;
 if (action === 'count') select = 'COUNT(*) AS total_records';
 else if (action === 'aggregate') {
  const fun = String(p.aggregate?.function || '').toUpperCase();
  if (!['SUM','AVG','MIN','MAX','COUNT'].includes(fun)) throw new Error('Unsupported aggregate');
  select = `${fun}(${col(p.aggregate?.column)}) AS aggregate_result`;
 } else {
  const selected = Array.isArray(p.columns) ? p.columns : [];
  select = selected.length ? selected.slice(0,20).map(col).join(', ') : '*';
 }
 const where: string[] = [];
 if (p.filters !== undefined) {
  if (!Array.isArray(p.filters) || p.filters.length > 5) throw new Error('Too many filters');
  for (const f of p.filters) {
   const field = col(f?.column);
   const op = f?.operator;
   if (!['=','!=','>','>=','<','<=','contains','starts_with'].includes(op)) throw new Error('Unsafe filter operator');
   if (f.value == null) {
    if (op !== '=' && op !== '!=') throw new Error('Unsupported NULL comparison');
    where.push(`${field} IS ${op === '!=' ? 'NOT ' : ''}NULL`);
   } else if (op === 'contains' || op === 'starts_with') {
    if (typeof f.value !== 'string') throw new Error('Text filter expected');
    const v = safeSqlValue(f.value);
    where.push(`${field} LIKE ${op === 'contains' ? `CONCAT('%', ${v}, '%')` : `CONCAT(${v}, '%')`}`);
   } else where.push(`${field} ${op} ${safeSqlValue(f.value)}`);
  }
 }
 let sql = `SELECT ${select} FROM ${quotedTable(table)}`;
 if (where.length) sql += ` WHERE ${where.join(' AND ')}`;
 if (action === 'list') {
  if (p.orderBy != null) {
   const ordering = p.orderBy as Record<string, unknown>;
   if (!ordering || typeof ordering !== 'object') throw new Error('Invalid ORDER BY');
   const direction = String(ordering.direction || 'ASC').toUpperCase();
   if (!['ASC','DESC'].includes(direction)) throw new Error('Unsafe ORDER BY direction');
   sql += ` ORDER BY ${col(ordering.column)} ${direction}`;
  }
  const n = Number(p.limit);
  const limit = Number.isInteger(n) && n > 0 ? Math.min(n,maxRows()) : Math.min(maxRows(),20);
  sql += ` LIMIT ${limit}`;
 }
 return sql + ';';
}

export async function translateNaturalLanguage(
 question: string,
 queryMetadata: SqlExecutor,
 generatePlan: PlanGenerator
): Promise<SqlTranslation> {
 if (typeof question !== 'string' || question.length > 4000 || !question.trim()) throw new Error('Invalid database question');
 if (MUTATING_INTENT.test(question)) throw new Error('English-to-SQL supports read-only questions only. Direct SQL mode is unchanged.');
 const table = namedTable(question);
 if (!table) throw new Error('Please name the table in your question (for example, "How many records are in contxt_oi_assoc?").');
 const quoted = quotedTable(table);
 if (countIntent(question) && !/\b(?:where|whose|having|with|matching|filter|group|per|by|for each|only|distinct|unique)\b/i.test(question)) {
  return {sql:`SELECT COUNT(*) AS total_records FROM ${quoted};`,method:'deterministic'};
 }
 if (listIntent(question) && !/\b(?:latest|newest|oldest|last|where|whose|matching|filter|sorted|order|by|group|distinct|unique|with)\b/i.test(question)) {
  return {sql:`SELECT * FROM ${quoted} LIMIT ${desiredLimit(question)};`,method:'deterministic'};
 }
 // Only query metadata for the named table; never join other tables on an LLM guess.
 const names = table.split('.');
 const tbl = names[names.length-1];
 const whereSchema = names.length === 2 ? `TABLE_SCHEMA = '${names[0]}'` : 'TABLE_SCHEMA = DATABASE()';
 const infoSql = `SELECT COLUMN_NAME AS column_name FROM information_schema.columns WHERE ${whereSchema} AND TABLE_NAME = '${tbl}' ORDER BY ORDINAL_POSITION;`;
 const metadata = await queryMetadata(infoSql);
 const columns = extractColumnNames(metadata);
 if (!columns.length) throw new Error(`Could not verify columns for ${table} via DBAgent. No speculative SQL was executed. Try a simple count or first-N records question.`);
 const plan = await generatePlan(question,table,columns);
 return {sql:compileReadOnlyPlan(plan,table,columns),method:'ollama-plan'};
}
