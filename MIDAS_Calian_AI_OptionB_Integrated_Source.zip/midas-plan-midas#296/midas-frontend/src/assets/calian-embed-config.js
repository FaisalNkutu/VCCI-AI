/* Administrator-controlled, runtime-editable Calian AI iframe address.
 * Local MIDAS development uses an independent Angular 19 dev server on port 4300.
 * Production: replace the empty string with an approved HTTPS Calian frontend URL.
 * Do not place passwords, API tokens or access tokens here.
 */
window.__MIDAS_CALIAN_EMBED_URL__ =
  /^(localhost|127\.0\.0\.1)$/i.test(window.location.hostname)
    ? 'http://127.0.0.1:4300/'
    : '';
