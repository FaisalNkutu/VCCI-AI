import { Component, inject } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { APP_PREF_KEY } from '@/app.guard';

// The URL comes from a separately deployed, administrator-controlled asset.
// Never accept a chatbot URL from route/query parameters or untrusted messages.
function resolveCalianUrl(raw: unknown): string | null {
  if (typeof raw !== 'string' || !raw.trim()) return null;
  try {
    const url = new URL(raw.trim(), window.location.origin);
    const loopback = ['localhost', '127.0.0.1'].includes(url.hostname);
    // Use HTTPS everywhere except a local development instance.
    if (url.protocol !== 'https:' && !(loopback && url.protocol === 'http:')) return null;
    if (url.username || url.password || url.hash) return null;
    return url.href;
  } catch {
    return null;
  }
}

@Component({
  selector: 'app-calian-ai',
  standalone: true,
  template: `
    <section class="flex h-full min-h-0 w-full flex-col bg-zinc-950 text-white" aria-label="Calian AI workspace">
      <header class="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-700 bg-zinc-900 px-5 py-3">
        <div class="flex items-center gap-3">
          <span class="rounded bg-sky-900 px-2 py-1 text-xs font-bold text-sky-200">MIDAS</span>
          <h1 class="text-lg font-semibold">Calian AI Assistant</h1>
        </div>
        <nav class="flex flex-wrap items-center gap-4 text-sm" aria-label="Calian workspace actions">
          @if (chatbotUrl) {
            <a [href]="chatbotUrl" target="_blank" rel="noopener noreferrer"
               class="text-sky-300 underline underline-offset-4 hover:text-white">
              Open in separate tab
            </a>
          }
          <button type="button" (click)="switchWorkspace()"
                  class="rounded-md border border-zinc-500 px-3 py-1.5 text-white hover:bg-zinc-700">
            Switch workspace
          </button>
        </nav>
      </header>

      @if (trustedChatbotUrl) {
        <iframe
          class="min-h-0 w-full flex-1 border-0 bg-zinc-950"
          [src]="trustedChatbotUrl"
          title="Calian AI Assistant embedded application"
          allow="camera; microphone; fullscreen; display-capture"
          referrerpolicy="no-referrer"
          allowfullscreen>
        </iframe>
      } @else {
        <div class="flex min-h-0 flex-1 items-center justify-center px-6">
          <div class="max-w-2xl rounded-lg border border-amber-700 bg-zinc-900 p-6">
            <h2 class="mb-2 text-lg font-semibold">Calian AI needs a deployment URL</h2>
            <p class="text-sm text-zinc-300">
              Configure <code>window.__MIDAS_CALIAN_EMBED_URL__</code> in
              <code>src/assets/calian-embed-config.js</code> with the approved HTTPS Calian AI address.
              Local MIDAS development automatically uses http://127.0.0.1:4300/.
            </p>
            <p class="mt-3 text-xs text-amber-200">Only HTTPS addresses or loopback HTTP addresses are permitted.</p>
          </div>
        </div>
      }
    </section>
  `
})
export class CalianAiComponent {
  private readonly router = inject(Router);
  private readonly sanitizer = inject(DomSanitizer);

  readonly chatbotUrl = resolveCalianUrl(
    (window as Window & { __MIDAS_CALIAN_EMBED_URL__?: string }).__MIDAS_CALIAN_EMBED_URL__
  );
  // Only the validated, administrator-controlled URL may be trusted as an iframe resource.
  readonly trustedChatbotUrl: SafeResourceUrl | null = this.chatbotUrl
    ? this.sanitizer.bypassSecurityTrustResourceUrl(this.chatbotUrl)
    : null;

  switchWorkspace(): void {
    localStorage.removeItem(APP_PREF_KEY);
    void this.router.navigateByUrl('/');
  }
}
