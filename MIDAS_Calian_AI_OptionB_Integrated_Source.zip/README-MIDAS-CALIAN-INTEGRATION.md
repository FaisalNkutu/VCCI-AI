# MIDAS + Calian AI integration (Option B: iframe)

## What is implemented

- Preserves MIDAS's original Angular 21 advanced-metrics and LVCTS workspaces and its existing `MidasAiComponent`.
- Adds **Calian AI Assistant** as a third choice on the MIDAS workspace selector.
- Adds `/calian-ai` as a MIDAS route, with a full-height iframe to the independently running Angular 19 Calian frontend.
- Preserves the workspace selection preference. **Switch workspace** clears the preference and reopens the selection screen.
- Hides the MIDAS floating AI panel *only* while Calian is open, avoiding two overlapping assistants.
- Provides an **Open in separate tab** link for troubleshooting and accessibility.
- Sets iframe media permission delegation for camera, microphone, fullscreen, and display-capture. Browser prompts, HTTPS, and any extra Permissions-Policy settings still apply.
- Does not merge MIDAS and Calian `package.json`, their pnpm/npm lockfiles, or their Angular toolchains.
- Makes the iframe URL runtime configurable via `midas-frontend/src/assets/calian-embed-config.js`.
- Adds an *optional* server-side `CALIAN_EMBED_PARENT_ORIGIN` allowlist for the packaged Calian UI's CSP `frame-ancestors` header.
- Does **not** change agent selection, multi-agent orchestration, speech, LiveKit, backend database services, or video gateway logic.

## Local Windows setup

1. Extract this ZIP to a local folder. The two source code projects must remain alongside this README and launcher.
2. Calian prerequisites: In `Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES` run `npm install` if necessary. Configure the original `.env` and required agent services as in your working Calian setup. **Keep private credentials out of the ZIP and screenshots.**
3. MIDAS prerequisites: In `midas-plan-midas#296\midas-frontend` run `pnpm install --frozen-lockfile` **only after** the Simfront private registry / lockfile issue has been resolved. Use the organization-approved registry and committed lockfile; do not disable integrity verification or delete the lockfile.
4. Run `START-MIDAS-CALIAN-DEV-WINDOWS.bat`. It starts the Calian backend (8797), Calian Angular (4300), and MIDAS Angular (4200) if the ports are free and dependencies are installed. Electron is not started.
5. Navigate to `http://127.0.0.1:4200/` and choose **Calian AI Assistant**, or open `http://127.0.0.1:4200/calian-ai` directly.
6. Run `powershell -NoProfile -ExecutionPolicy Bypass -File .\TEST-MIDAS-CALIAN-LOCAL.ps1` for HTTP smoke checks. Then test interactive behavior manually.

### If Calian is already running successfully

No need to start a second Calian. The launcher skips occupied ports 8797/4300. If your already-running Calian uses different ports, edit only `src/assets/calian-embed-config.js` and ensure its own WebSocket/backend routing remains correct. Calian dev frontend should be at `http://127.0.0.1:4300/` for the provided default.

### Current MIDAS package-install blocker

Previous screenshots show `ERR_PNPM_TARBALL_URL_MISMATCH`, after the scoped `@simfront` registry was corrected. This bundle deliberately does **not** regenerate `pnpm-lock.yaml` or bypass supply-chain verification. The package installation issue remains outstanding until the approved Artifactory metadata and lockfile tarball URLs are reconciled by the project owner.

## Production deployment

- Build and host MIDAS independently from Calian. Example public addresses: `https://midas.example.com` and `https://calian.example.com` (illustrative only).
- Set the production URL in MIDAS's `src/assets/calian-embed-config.js` to the actual approved HTTPS Calian UI origin. Ship this updated asset with MIDAS. Do not place secrets in the JavaScript file.
- For packaged Calian UI served by the Node backend, set `CALIAN_EMBED_PARENT_ORIGIN=https://midas.example.com` in Calian's private environment. The added CSP header allows framing only by `self` and that origin. The dev Angular server on 4300 manages its own headers, so production deployment must independently verify resulting headers.
- Configure Calian's `CALIAN_PUBLIC_ORIGIN` to the actual trusted HTTPS Calian origin to satisfy its WebSocket origin checks, and reverse-proxy both `/api/` and `/ws` from the Calian host to its backend, including WebSocket upgrade headers. Ensure `/api/video/...` and LiveKit connections are correctly routed as required by the existing video service.
- **Not production-ready by itself:** MIDAS's workspace preference guard is not an authentication mechanism. Place *both* sites and all Calian API/WebSocket/video endpoints behind company-approved SSO / reverse-proxy authorization. Explicitly implement per-user sessions and agent permissions, including external invited user scopes. Use same-site identity or short-lived server-to-server session exchange where appropriate. An iframe does not share the parent site's authentication automatically.
- Allow framing in Calian's `Content-Security-Policy: frame-ancestors` response header, and allow the Calian origin in MIDAS's `frame-src` / applicable CSP configuration. Verify no conflicting `X-Frame-Options` header is supplied by a reverse proxy. Test browser camera/microphone permissions with HTTPS, including LiveKit / group meetings. Set restrictive `Permissions-Policy` allowing authorized origins.
- Set cookies `Secure`, `HttpOnly`, suitable `SameSite`; avoid embedding long-lived tokens in URLs, query strings, localStorage, or `postMessage` payloads. If cross-site embedding is unavoidable, assess browser third-party-cookie restrictions and prefer a same-site deployment instead.
- Restrict the Calian backend to internal loopback/internal networking. Do not expose its unauthenticated development port 8797 to the public Internet.

## Manual acceptance tests

1. MIDAS's original Adv Metrics and LVCTS workspaces still open normally.
2. Workspace chooser shows **Calian AI Assistant**; selecting it opens `/calian-ai` in MIDAS without Electron.
3. Calian loads with the existing conversations view; the MIDAS floating assistant does not overlay it.
4. Chat with the local Ollama agent; confirm a visible answer.
5. Refresh agents, select Auto, and verify the chosen agent and returned response.
6. Ask a multi-step question and verify sequential agent orchestration (with all agent services running).
7. Test backend `/api/health` and browser WebSocket `/ws` in DevTools (no errors).
8. Run a one-to-one call, a group call, and camera/mic prompts with authorized users; verify LiveKit / gateway separately.
9. Test **Open in separate tab** and **Switch workspace**; refresh and confirm preference behavior.
10. Test unauthorized user access: embedding MIDAS must *not* bypass Calian API / WebSocket authorization (after SSO is implemented).

## Modified code locations

MIDAS:
- `midas-frontend/src/app/components/calian-ai/calian-ai.component.ts` (new)
- `midas-frontend/src/app/app.routes.ts`
- `midas-frontend/src/app/app.guard.ts`
- `midas-frontend/src/app/components/selection/selection.component.ts`
- `midas-frontend/src/app/app.component.ts` and `app.component.html`
- `midas-frontend/src/index.html`
- `midas-frontend/src/assets/calian-embed-config.js` (new)

Calian:
- `CALIAN_AI_ELECTRON_THEMES/server/index.ts`: optional embed-origin CSP header only

**Status:** source-level integration implemented; not compiled or end-to-end tested in this environment because MIDAS depends on unavailable private Simfront packages and your running services are local to your machine.
