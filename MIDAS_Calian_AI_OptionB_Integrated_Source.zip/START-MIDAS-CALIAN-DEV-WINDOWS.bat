@echo off
setlocal EnableExtensions
set "ROOT=%~dp0"
set "MIDAS=%ROOT%midas-plan-midas#296\midas-frontend"
set "CALIAN=%ROOT%Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES"

echo ===============================================================
echo MIDAS + CALIAN AI Browser Development ^(Option B iframe^)
echo ===============================================================
if not exist "%MIDAS%\angular.json" (
  echo ERROR: MIDAS Angular folder missing: "%MIDAS%"
  pause
  exit /b 1
)
if not exist "%CALIAN%\angular.json" (
  echo ERROR: Calian Angular folder missing: "%CALIAN%"
  pause
  exit /b 1
)
where npm >nul 2>&1 || (echo ERROR: npm not found on PATH. & pause & exit /b 1)
where pnpm >nul 2>&1 || (echo ERROR: pnpm not found on PATH. & pause & exit /b 1)

if not exist "%CALIAN%\node_modules\.bin\ng.cmd" (
  echo.
  echo ERROR: Calian node_modules missing.
  echo In "%CALIAN%" run: npm install
  echo Then run this launcher again.
  pause
  exit /b 1
)

powershell -NoProfile -Command "if (Get-NetTCPConnection -State Listen -LocalPort 8797 -ErrorAction SilentlyContinue) { exit 0 } else { exit 1 }" >nul 2>&1
if errorlevel 1 (
  echo Starting Calian backend on 127.0.0.1:8797...
  start "Calian Backend" cmd /k "cd /d ""%CALIAN%"" && npm run dev:server"
) else (
  echo Calian backend port 8797 already in use; not launching a duplicate.
)

powershell -NoProfile -Command "if (Get-NetTCPConnection -State Listen -LocalPort 4300 -ErrorAction SilentlyContinue) { exit 0 } else { exit 1 }" >nul 2>&1
if errorlevel 1 (
  echo Starting Calian browser UI on 127.0.0.1:4300...
  start "Calian Angular Browser" cmd /k "cd /d ""%CALIAN%"" && npm run dev:client"
) else (
  echo Calian browser port 4300 already in use; not launching a duplicate.
)

if not exist "%MIDAS%\node_modules\.bin\ng.cmd" (
  echo.
  echo IMPORTANT: MIDAS dependencies are not installed yet.
  echo The previous private-registry pnpm integrity issue must be resolved safely.
  echo Check MIDAS's pnpm-lock.yaml against the approved Simfront Artifactory.
  echo Then run: cd /d "%MIDAS%"
  echo           pnpm install --frozen-lockfile
  echo and rerun this launcher. No lockfile was modified by this script.
  echo.
  echo You can open Calian independently at http://127.0.0.1:4300/
  pause
  exit /b 2
)

powershell -NoProfile -Command "if (Get-NetTCPConnection -State Listen -LocalPort 4200 -ErrorAction SilentlyContinue) { exit 0 } else { exit 1 }" >nul 2>&1
if errorlevel 1 (
  echo Starting MIDAS on 127.0.0.1:4200...
  start "MIDAS Angular" cmd /k "cd /d ""%MIDAS%"" && pnpm start -- --host 127.0.0.1 --port 4200"
) else (
  echo MIDAS port 4200 already in use; not launching a duplicate.
)
echo.
echo MIDAS integration: http://127.0.0.1:4200/calian-ai
echo Calian standalone: http://127.0.0.1:4300/
echo Open the MIDAS URL after both Angular dev servers report ready.
echo.
pause
endlocal
