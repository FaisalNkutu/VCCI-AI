CALIAN AI - DIRECT OLLAMA ROUTING REPAIR

1. On Windows, ensure Ollama is running and llama3.2:latest is installed.
   Test: ollama run llama3.2:latest "Translate Good morning into French. Reply only the translation."
2. Double-click BUILD-CALIAN-WINDOWS.bat. Requires Node.js/npm, not Python or PyInstaller.
3. Find the newly built portable CALIAN AI .exe in CALIAN_AI_ELECTRON_THEMES\release.
4. Start it and manually select Local Ollama Assistant; enter the translation prompt.
5. Direct Ollama requests use POST http://127.0.0.1:11434/api/chat through the bundled Node backend.

IMPORTANT LIMITATIONS:
- A Windows EXE is NOT included in this source ZIP. Build it on Windows with the script.
- This package's Python router provides /agents and /router/select, but no A2A execution endpoint.
- AI Core agents still require a running AI Core registry and executable agent services.
- Direct Ollama chat works without the Python router. Auto selection remains available.
- Do not delete existing CALIAN AI builds. Use the newly built EXE for testing.
