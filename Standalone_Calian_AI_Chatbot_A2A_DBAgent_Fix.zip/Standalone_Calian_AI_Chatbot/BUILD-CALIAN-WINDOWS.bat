@echo off
setlocal
cd /d "%~dp0CALIAN_AI_ELECTRON_THEMES"
where node >nul 2>&1 || (echo ERROR: Install Node.js LTS on the build PC. & pause & exit /b 1)
where npm >nul 2>&1 || (echo ERROR: npm not found. & pause & exit /b 1)
echo Building portable CALIAN AI with built-in Node backend and direct Ollama support...
call npm install || (echo npm install failed & pause & exit /b 1)
call npm run dist:win || (echo Build failed & pause & exit /b 1)
echo.
echo SUCCESS: Portable CALIAN AI executable is in CALIAN_AI_ELECTRON_THEMES\release
pause
