@echo off
setlocal
cd /d "%~dp0CALIAN_AI_ELECTRON_THEMES"
where node >nul 2>&1 || (echo Node.js required & pause & exit /b 1)
call npm install
if errorlevel 1 (echo npm install failed & pause & exit /b 1)
call npm run dist:win
if errorlevel 1 (echo Build failed & pause & exit /b 1)
echo Built portable executable in CALIAN_AI_ELECTRON_THEMES\release
pause
