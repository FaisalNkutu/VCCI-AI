# Standalone Calian AI Chatbot

**Windows Angular + Electron desktop application with direct Ollama chat, a local Python agent-selection router, and optional AI Core discovery.**

> This package is a renamed copy of `CALIAN_AI_OLLAMA_FIXED_SOURCE(2).zip`, with documentation added. Existing application code and launch scripts have been preserved. The included architecture documents distinguish the **current source implementation** from the **larger intended Paradigm/RabbitMQ architecture**.

## 1. Quick start (Windows 10/11)

Install **Node.js + npm**, **Python 3 + pip**, and **Ollama**. Install Ollama's `llama3.2:latest` model before starting the application. Keep the extracted project in a normal writable folder (for example, your Downloads or Projects folder).

Open PowerShell and check:

```powershell
node --version
npm --version
python --version
ollama list
```

If `llama3.2:latest` is missing, run `ollama pull llama3.2`. Ollama normally runs in the background on Windows. Check its API with `Invoke-RestMethod http://127.0.0.1:11434/api/tags`. Run `ollama serve` **only if** the service is not already running.

### Start in this order

1. **Ollama:** Confirm `llama3.2:latest` is installed and the local Ollama API responds at `http://127.0.0.1:11434`.
2. **Python router:** Double-click **`START-PYTHON-ROUTER.bat`** at the extracted package root. Leave its terminal open. It installs `PYTHON_BACKEND/requirements-local.txt` and starts FastAPI on `127.0.0.1:9999`.
3. **CALIAN.AI desktop:** Double-click **`START-CALIAN-ELECTRON.bat`** at the extracted package root. Leave its terminal open. The script installs npm packages if necessary and runs `npm run dev` from `CALIAN_AI_ELECTRON_THEMES`.
4. In the desktop application, select **Local Ollama Assistant** and ask: `Translate boy into French` (expected: `garçon`).
5. Select **Intelligent Auto Select** to test routing. You can tick **Test auto-selection only (do not execute agent)** to verify agent selection without relying on external execution endpoints.

### Verify services

| Component | Default address / check | Meaning |
| --- | --- | --- |
| Ollama | `http://127.0.0.1:11434/api/tags` | Local model server |
| Python router | `http://127.0.0.1:9999/health` and `/docs` | Selection-only FastAPI service |
| Angular dev UI | `http://127.0.0.1:4300` | Development UI |
| Electron/Express bridge | `http://127.0.0.1:8797/api/health` | Local Node backend; serves packaged UI |
| AI Core registry | `http://127.0.0.1:9801/api/ai-core/agents` (default in source) | **Optional external integration**, not bundled |

**Do not send API requests to port 8797 using an invented path.** The bundled Node bridge implements `POST /api/ollama/chat`, not `/api/a2a` or `/api/a2a/local-ollama`.

## 2. Build a portable Windows executable

Double-click **`BUILD-CALIAN-WINDOWS.bat`** at the extracted root. It runs `npm install` and `npm run dist:win`. When successful, look in `CALIAN_AI_ELECTRON_THEMES/release/` for the portable executable. The packaging configuration also uses `electron/main.cjs` and includes the compiled Node backend.

Building requires Node.js/npm. **Running the built portable app does not require starting Angular's development server**, but Ollama must still be available for direct chat. Python routing is a separate process and is required for Ollama-based agent-selection behavior.

## 3. Architecture: implemented vs intended

See **`docs/Standalone_Calian_AI_Architecture.pdf`** for the updated architecture diagram and **`docs/CALIAN_AI_Integrated_Architecture_Startup_Guide.pdf`** for the original five-page enterprise reference diagram and startup guide.

**Implemented in this ZIP:** Angular UI; Electron shell; bundled Express/Node bridge; direct `POST /api/ollama/chat` forwarding to local Ollama; Python FastAPI selection router on port 9999; local Ollama Assistant agent identity; AI Core registry HTTP integration configuration. The Python router's `/agents` endpoint declares a local routing identity, **not** a live North A2A execution endpoint.

**External / not implemented in this ZIP:** RabbitMQ AMQP client; Micronaut/Paradigm AI Core service; six enterprise agent implementations; live North A2A execution service. The original architecture PDF describes a **target or broader deployment** where one North Agent and six Paradigm agents are discoverable via RabbitMQ. Do not assume that architecture is bundled or that discovery guarantees execution. Seven agents appeared in a previous running environment with separate services, but the ZIP alone does not provide them.

### Intended RabbitMQ role

For a future integration, use RabbitMQ **between the chatbot integration service and AI Core**, primarily for asynchronous requests, responses, events, and agent registry updates. Keep direct Ollama HTTP calls working independently. This package does **not** currently require RabbitMQ for local chat or selection. Avoid claiming RabbitMQ integration until the producer, consumer, queues/exchanges, message schema, correlation IDs, and error handling have been implemented and tested on both sides.

## 4. Environment settings

The bundled `CALIAN_AI_ELECTRON_THEMES/server/index.ts` currently defaults to:

```text
PORT=8797
PYTHON_SERVICE_URL=http://127.0.0.1:9999
OLLAMA_ROUTER_URL=http://127.0.0.1:9999
AI_CORE_REGISTRY_URL=http://127.0.0.1:9801/api/ai-core/agents
```

`START-PYTHON-ROUTER.bat` sets:

```text
OLLAMA_ENABLED=true
OLLAMA_URL=http://127.0.0.1:11434
OLLAMA_MODEL=llama3.2:latest
PORT=9999
```

Check `CALIAN_AI_ELECTRON_THEMES/.env.example` for additional examples. **Do not change ports or credentials just to match a diagram**; verify your live service endpoints first. The original architecture PDF's `North A2A agent` is a separate service, not supplied by this source ZIP.

## 5. Troubleshooting

| Symptom | First check |
| --- | --- |
| Ollama not responding | `ollama list`; `Invoke-RestMethod http://127.0.0.1:11434/api/tags`; avoid starting a second `ollama serve` |
| Python/A2A count missing | Check the router terminal and `http://127.0.0.1:9999/health` |
| 404 on `/api/a2a` | This is not a supported path in this build; use `/api/ollama/chat` for direct local chat |
| AI Core registry HTTP 502 | AI Core registry service at the configured URL is not reachable; this is separate from local Ollama |
| Only one agent discovered | Expected without separately running AI Core discovery services |
| Agent selected but not executed | Selection and execution are separate; ensure a real agent execution endpoint exists |
| Desktop does not launch | Check Node/npm and the terminal opened by `START-CALIAN-ELECTRON.bat` |
| Windows EXE build appears stalled | Wait for packaging; inspect the console for a final success/error and check the `release` folder |
| Port 8797 already in use | Close the prior CALIAN.AI instance before starting another; do not kill unrelated processes |

## 6. Suggested smoke tests

- Local chat: `Translate boy into French` → `garçon`.
- Local chat: `Translate girl into Russian` → `девочка`.
- Auto-selection only: `Roll two dice` → Dice Agent **only if that agent is present in the discovered registry**.
- External agent execution: uncheck selection-only and verify actual results **only after** the appropriate AI Core agent execution service is running.

## 7. Source layout

```text
Standalone_Calian_AI_Chatbot/
  START-PYTHON-ROUTER.bat
  START-CALIAN-ELECTRON.bat
  BUILD-CALIAN-WINDOWS.bat
  BUILD-ON-WINDOWS.bat
  PYTHON_BACKEND/
    main.py
    agent_router.py
    requirements-local.txt
    ...
  CALIAN_AI_ELECTRON_THEMES/
    package.json
    electron/main.cjs
    server/index.ts
    src/
    ...
  docs/
    Standalone_Calian_AI_Architecture.pdf
    CALIAN_AI_Integrated_Architecture_Startup_Guide.pdf
  README.md
```

## 8. Safe operational rules

Keep the working source backed up. Start Ollama only once. Do not delete or overwrite existing AI Core, RabbitMQ, or Python service installations. A green connection indicator or successful routing decision is not proof that every enterprise agent executes. Add and verify the RabbitMQ bridge separately before changing the existing direct chat path.


## Configurable service URLs (no source edits needed)

The desktop application defaults to the working local settings. To change URLs, copy
`CALIAN_AI_ELECTRON_THEMES/.env.example` to `CALIAN_AI_ELECTRON_THEMES/.env`
for source/development runs. Configure `PORT`, `PYTHON_SERVICE_URL`,
`OLLAMA_ROUTER_URL`, `OLLAMA_URL`, `OLLAMA_MODEL`, and `AI_CORE_REGISTRY_URL`.

For the **packaged Windows app**, create a text file named `calian.env` next to
`CALIAN AI.exe` (the portable executable) with the same `KEY=value` entries.
Alternatively place `calian.env` in the application's Electron user-data directory.
Restart the app after changing configuration. OS environment variables override
values in configuration files. Do not put secrets in the release ZIP.

The local web API remains bound to `127.0.0.1`. The trusted upstream URL
allowlist is retained; this configuration does not permit arbitrary URLs from
the UI. The Python router, Ollama, and AI Core must be running at their configured
addresses for their respective features to work.
