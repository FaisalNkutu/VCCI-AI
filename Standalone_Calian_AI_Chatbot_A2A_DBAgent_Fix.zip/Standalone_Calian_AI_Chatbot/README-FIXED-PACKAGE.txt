CALIAN.AI corrected Windows packaging (2026-11-04)

The original ZIP started the Node/Electron backend but did not bundle or start Python.
The bundled Python app was a SELECTION-ONLY router and had no A2A execution endpoint.

On the Windows BUILD machine (Python, Node/npm installed):
  1. Run BUILD-CALIAN-WINDOWS.bat
  2. Find the portable executable in CALIAN_AI_ELECTRON_THEMES\release
  3. Launch it. Electron starts its bundled Python router on 127.0.0.1:9999 and its Node backend on 127.0.0.1:8797.
  4. Local Ollama execution goes directly from the Node backend to Ollama at 127.0.0.1:11434.

The TARGET machine does not need Python or Node installed. It DOES need Ollama and llama3.2:latest for local translation; these are not bundled. The remote/enterprise Paradigm AI Core and original North A2A service are NOT bundled and remain separately configured. The local router is NOT a replacement for the original Python A2A execution service. Existing enterprise agents require their original endpoints and registry configuration.

For development, START-PYTHON-ROUTER.bat and START-CALIAN-ELECTRON.bat remain available. Do not run START-PYTHON-ROUTER.bat while using the packaged executable (both use port 9999).

IMPORTANT: Build has not been executed or tested on Windows here. This is a corrected source package for local build and validation, not a verified working .exe.
