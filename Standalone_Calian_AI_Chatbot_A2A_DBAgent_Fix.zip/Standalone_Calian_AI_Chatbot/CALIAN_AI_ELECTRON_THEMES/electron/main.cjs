const {app,BrowserWindow,dialog}=require('electron');
const {spawn}=require('node:child_process');
const path=require('node:path');
const fs=require('node:fs');
let backend;
const dev=!app.isPackaged;
// Configuration: environment variables override .env; packaged users may place
// calian.env alongside the executable or in Electron's userData directory.
function readConfig(file){
 if(!fs.existsSync(file))return {};
 const result={};
 for(const line of fs.readFileSync(file,'utf8').split(/\r?\n/)){
  const m=line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
  if(!m)continue;
  let value=m[2];if((value.startsWith('"')&&value.endsWith('"'))||(value.startsWith("'")&&value.endsWith("'")))value=value.slice(1,-1);
  result[m[1]]=value;
 }
 return result;
}
const config={...readConfig(path.join(app.getAppPath(),'.env')),...readConfig(path.join(path.dirname(process.execPath),'calian.env')),...readConfig(path.join(app.getPath('userData'),'calian.env')),...process.env};
const port=Number(config.PORT||8797);
if(!Number.isInteger(port)||port<1||port>65535)throw new Error('Invalid PORT');
const host='127.0.0.1'; // Keep local desktop API bound to loopback.
const backendURL=`http://${host}:${port}`;
function startBackend(){if(dev)return;
 const executable=process.execPath;
 const script=path.join(app.getAppPath(),'dist','backend.cjs');
 const staticDir=path.join(app.getAppPath(),'dist','calian','browser');
 backend=spawn(executable,[script],{env:{...config,ELECTRON_RUN_AS_NODE:'1',CALIAN_STATIC_DIR:staticDir,PORT:String(port),HOST:host},stdio:'ignore',windowsHide:true});
 backend.on('error',e=>dialog.showErrorBox('Backend startup failed',e.message));
}
async function waitBackend(){for(let i=0;i<80;i++){try{const r=await fetch(`${backendURL}/api/health`);if(r.ok)return;}catch{}await new Promise(r=>setTimeout(r,250));}throw new Error(`Backend did not start at ${backendURL}`);}
app.whenReady().then(async()=>{try{startBackend();await waitBackend();const win=new BrowserWindow({width:1440,height:920,minWidth:950,minHeight:650,backgroundColor:'#111827',webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}});await win.loadURL(dev?'http://127.0.0.1:4300':backendURL);}catch(e){dialog.showErrorBox('CALIAN AI startup',String(e));app.quit();}});
app.on('window-all-closed',()=>app.quit());
app.on('before-quit',()=>{if(backend)backend.kill();});
