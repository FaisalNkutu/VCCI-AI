# CALIAN AI — Angular Material 3 Workbench

Angular 19 standalone frontend converted from the supplied React UI. Angular Material components and Material 3 `mat.theme` Sass mixins provide light/dark design tokens. Existing Express backend (`server/index.ts`) is retained unchanged.

## Requirements
- Node.js 20.11+ (Node 22 LTS recommended), npm
- Python A2A service at `http://127.0.0.1:9999` by default
- Optional AI Core registry (see `.env.example`)

## Start
1. `npm install`
2. Copy `.env.example` to `.env` and configure endpoints as needed.
3. `npm run dev`
4. Open `http://127.0.0.1:4200`

Angular dev server proxies `/api` to Express at port 8787. Run `npm run build` to produce the Angular production frontend in `dist/calian/browser`. The Express server retains its original API endpoints; production hosting of Angular static assets requires a web server or additional Express static-host configuration.

## Features
- Live Python/A2A and AI Core agent discovery; friendly names
- Manual routing and automatic routing, with safe selection-only test enabled by default
- Streaming A2A JSON-RPC v1.0/SSE; AI Core execution through the existing Express adapter
- Shared context and last 12 turns; session reset, transcript JSON export, diagnostics
- Material 3 light/dark themes; Material cards, form fields, tabs, buttons, icons, checkbox, snack bar

## Important
This is a source conversion; it has not been verified against running Python or Java services in this environment. Java Paradigm callback support and AI Core execution retain the existing backend prerequisites and limitations. No credentials are bundled.


### Environment configuration
See `.env.example` and the top-level README. In development copy it to `.env`; for a packaged executable create `calian.env` beside the EXE. The Angular development proxy now reads `PORT` from `.env`.
