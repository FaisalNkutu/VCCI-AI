require('dotenv').config();
const port=Number(process.env.PORT||8797);
module.exports={'/api':{target:`http://127.0.0.1:${port}`,secure:false,changeOrigin:true}};
