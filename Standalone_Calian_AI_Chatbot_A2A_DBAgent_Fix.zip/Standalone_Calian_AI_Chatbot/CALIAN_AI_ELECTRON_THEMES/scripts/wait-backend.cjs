require('dotenv').config();
const net=require('node:net');
const ports=[4300,Number(process.env.PORT||8797)];
async function wait(port){for(let i=0;i<120;i++){
 const ready=await new Promise(resolve=>{const s=net.connect({host:'127.0.0.1',port});s.once('connect',()=>{s.destroy();resolve(true)});s.once('error',()=>resolve(false));s.setTimeout(1000,()=>{s.destroy();resolve(false)});});
 if(ready)return;await new Promise(r=>setTimeout(r,500));
}throw new Error(`Service not ready on port ${port}`);}
(async()=>{for(const p of ports)await wait(p)})().catch(e=>{console.error(e.message);process.exit(1)});
