CALIAN.AI targeted DBAgent A2A JSON-RPC correction

PROBLEM
The Java AI Core build now succeeds, but the CALIAN.AI Electron backend forwarded
selected AI Core agent requests as {message, contextId, context}. Python A2A server
(port 5022) rejects these with JSON-RPC error -32600 (missing method).

CHANGE
CALIAN_AI_ELECTRON_THEMES/server/index.ts now wraps requests to endpoints on
port 5022 in A2A 0.3+ JSON-RPC: method message/send, role user, kind text.
Other endpoints retain the original request shape. Agent discovery, Ollama
auto-routing, RabbitMQ and Java AI Core code are not modified.

USAGE
1. Back up your CURRENT chatbot project and settings before replacing files.
2. If using THIS ZIP as your source, extract it into a NEW folder, preserving
   environment configuration from your existing working app. The bundled Python
   router is selection-only; it is NOT the separate A2A server on port 5022.
3. For an existing source project, copy only server/index.ts from this archive
   into its CALIAN_AI_ELECTRON_THEMES/server/ folder after checking the local
   source matches the supplied baseline. Do not overwrite newer custom changes
   blindly.
4. From CALIAN_AI_ELECTRON_THEMES run: npm run build:desktop
   If using the packaged Electron EXE, rebuild the Windows app as well with:
   npm run dist:win
5. Restart CALIAN.AI and try DBAgent again. A log line should contain
   [CALIAN] Sending A2A message/send ... for DBAgent

NOTES
If the DBAgent endpoint is not on port 5022, set CALIAN_A2A_EXECUTION_PORT
to the correct port in the Electron backend environment and rebuild/restart.
No live interaction with the user's server was performed, so this is a targeted
source correction, not a verified end-to-end runtime fix.
