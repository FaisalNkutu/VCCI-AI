$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$services = @()
function Ready([string]$Url) {
    try { return (Invoke-WebRequest -UseBasicParsing $Url -TimeoutSec 2).StatusCode -eq 200 }
    catch { return $false }
}
function Ensure-Service([string]$Name, [string]$Url) {
    if (Ready $Url) { Write-Host "Reusing service at $Url"; return }
    $runner = Join-Path $PSScriptRoot 'RUN-EMBEDDED-SERVICE.bat'
    $child = Start-Process -FilePath $env:ComSpec -ArgumentList ('/d /s /c ""{0}" {1}"' -f $runner,$Name) -WindowStyle Hidden -PassThru
    $script:services += $child
    $deadline = (Get-Date).AddMinutes(3)
    do {
        if (Ready $Url) { return }
        if ($child.HasExited) { throw "$Name exited. Read calian-ai-angular-material\$Name-demo.log" }
        Start-Sleep -Seconds 1
    } while ((Get-Date) -lt $deadline)
    throw "$Name did not become ready. Read calian-ai-angular-material\$Name-demo.log"
}
try {
    foreach ($tool in 'java','mvn','npm') { if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) { throw "$tool is missing from PATH. Install JDK 17+, Maven and Node.js 20.11+ first." } }
    Push-Location (Join-Path $PSScriptRoot 'calian-ai-angular-material')
    try {
        if (-not (Test-Path 'node_modules')) {
            & npm.cmd install
            if ($LASTEXITCODE -ne 0) { throw 'npm install failed' }
        }
    } finally { Pop-Location }
    Ensure-Service 'server' 'http://127.0.0.1:8787/api/health'
    Ensure-Service 'client' 'http://127.0.0.1:4200/'
    if (-not (Ready 'http://127.0.0.1:4200/api/health')) { throw 'Angular is responding, but its /api proxy cannot reach the backend.' }
    Push-Location (Join-Path $PSScriptRoot 'swing-host')
    try {
        Write-Host 'Launching embedded Chromium. First launch downloads its native runtime.'
        & mvn.cmd compile exec:exec
        if ($LASTEXITCODE -ne 0) { throw 'Swing host failed. Read the Maven output and swing-host\jcef.log.' }
    } finally { Pop-Location }
} catch {
    Write-Host $_ -ForegroundColor Red
    exit 1
} finally {
    # Only stop service trees created by this launch; reused services remain running.
    foreach ($child in $services) {
        if (-not $child.HasExited) { & taskkill.exe /PID $child.Id /T /F 2>&1 | Out-Null }
    }
}

