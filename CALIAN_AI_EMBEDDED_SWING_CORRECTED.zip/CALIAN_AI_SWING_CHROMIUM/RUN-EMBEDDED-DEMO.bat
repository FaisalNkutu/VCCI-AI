@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN-EMBEDDED-DEMO.ps1"
if errorlevel 1 pause
