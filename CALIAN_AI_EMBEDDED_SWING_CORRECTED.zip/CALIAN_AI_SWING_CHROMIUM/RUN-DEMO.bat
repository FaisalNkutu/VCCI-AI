@echo off
call "%~dp0RUN-EMBEDDED-DEMO.bat"
