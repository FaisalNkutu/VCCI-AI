# Inspection and correction report

Inspected CALIAN_AI_EMBEDDED_SWING_FIX(1).zip, including the host, launchers, Angular/backend configuration, routing implementation, hidden .env files, legacy reference structure and supplied screenshots.

## Diagnosis: established facts versus inference

- The shipped host ALREADY sets windowless_rendering_enabled=false and createBrowser(...,false,false). Adding that flag again cannot fix this archive.
- The shipped host creates about:blank, then calls loadURL after 1500 ms. Native browser creation is asynchronous. A wall-clock delay is not a browser-ready signal. The status label says "Embedded Angular" even if no navigation or JavaScript succeeds. That label in the screenshot is therefore not evidence of a loaded page.
- CefBrowser/Swing components were constructed outside the Swing event dispatch thread. The corrected host constructs them on that thread and supplies the Angular URL as the initial URL, following the official JCEF sample pattern.
- The hidden-service launcher mixes PowerShell, cmd and backslash-escaped quotes/redirection. This is fragile on Windows, especially with paths containing spaces. Its replacement uses a small batch service runner and explicit readiness checks for backend, Angular and the API proxy.
- The earlier host runs under exec:java inside Maven. The new launcher uses exec:exec to run a separate Java VM with Maven's resolved application classpath. This removes Maven's in-process classloader from native-browser startup.
- GPU/driver failure remains a plausible additional cause, not a proven diagnosis. The host defaults to --disable-gpu as a conservative workaround. It keeps windowed rendering and does not add --no-sandbox or disable web security.

The screenshots establish that Chrome could render the Angular application. They do not establish which of native creation, GPU rendering, navigation or JavaScript failed in the original JCEF process. The original runtime logs were not provided, so a single confirmed original root cause cannot honestly be claimed.

## Minimal source changes

Only the Swing host, Maven execution configuration, launchers and launch documentation changed. JCEF remains pinned to 135.0.20. Java target remains 17. The host retains its native ownership chain, navigates directly to http://127.0.0.1:4200/, records load/console errors, adds Reload/Developer tools, and waits for CEF termination during shutdown.

No Angular layout, agent discovery, protocol, backend routing, endpoint allowlist, .env, .env.example, proxy configuration or package dependencies changed. SHA-256 comparison against the original ZIP confirmed all 26 files under calian-ai-angular-material are identical. Existing Ollama settings remain exactly as supplied. External Python, AI Core and Ollama services are not included or replaced.

## Verification actually performed

PASS: original Java host compiled against the exact archived JCEF dependency.
PASS: corrected Java host compiled with JDK 17 and the exact same dependency.
PASS: Maven exec:exec launched native Chromium 135 on Windows x64.
PASS: CEF reached INITIALIZED; browser onAfterCreated fired.
PASS: native Chromium loaded a local HTTP probe at 127.0.0.1:4200 with HTTP 200 and emitted CALIAN_PROBE_OK from JavaScript. This verifies HTTP navigation and renderer JavaScript execution; it is not a full Angular UI acceptance test.
PASS: unavailable-server test produced ERR_CONNECTION_REFUSED rather than a misleading timer-based success message.
PASS: normal host close reached CEF SHUTTING_DOWN and TERMINATED.
PASS: Angular template/type compilation using @angular/compiler-cli (ngc -p tsconfig.app.json).
PASS: backend TypeScript checking with tsc --noEmit using NodeNext/ES2022.
PASS: corrected PowerShell launcher parsed without syntax errors.
PASS: all 26 original Angular/backend/config/reference files match their original SHA-256 hashes.

LIMIT: complete ng build did not finish successfully here. Initial attempts failed while fetching Google Fonts because of network restrictions. Further bundling attempts with optimization disabled and temporary Node 20 exited with code 1 without a final reported error; verbose output reached Sass deprecation warnings. No Angular sources were changed to mask this. No full Angular-in-Swing visual acceptance or seven-agent/Ollama end-to-end test is claimed. There are no supplied automated tests. The full service launcher was syntax-checked but not end-to-end verified against your external agent services.

## Launch

For your already-working Angular/backend: extract the ZIP into a new folder, leave those services running, then double-click RUN-SWING-HOST.bat. This only starts the corrected embedded Swing host.

For a fresh launch from this package: preserve your customized .env, ensure your external services are running, then use RUN-EMBEDDED-DEMO.bat. Requires JDK 17+, Maven and Node/npm; initial dependencies need internet. Healthy existing servers are reused. Only service processes started by this launcher are cleaned up when it exits.

## Primary implementation references

JCEF official windowed Swing example: https://github.com/chromiumembedded/java-cef/blob/master/java/tests/simple/MainFrame.java
JCEF windowed browser lifecycle: https://github.com/chromiumembedded/java-cef/blob/master/java/org/cef/browser/CefBrowserWr.java
JCEFMaven builder and rendering settings: https://github.com/jcefmaven/jcefmaven

