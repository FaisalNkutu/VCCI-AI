@echo off
setlocal
cd /d "%~dp0"
where java >nul 2>nul || (echo ERROR: JDK 17+ is required & pause & exit /b 1)
where mvn >nul 2>nul || (echo ERROR: Maven is required & pause & exit /b 1)
powershell.exe -NoProfile -Command "try { $r=Invoke-WebRequest -UseBasicParsing 'http://127.0.0.1:4200/' -TimeoutSec 5; if($r.StatusCode -ne 200){exit 1} } catch {exit 1}"
if errorlevel 1 (echo ERROR: Start your existing Angular server on 127.0.0.1:4200 first & pause & exit /b 1)
cd /d "%~dp0swing-host"
call mvn compile exec:exec
if errorlevel 1 pause
