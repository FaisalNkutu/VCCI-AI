package com.calian.desktop;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import javax.swing.*;
import me.friwi.jcefmaven.CefAppBuilder;
import me.friwi.jcefmaven.MavenCefAppHandlerAdapter;
import org.cef.CefApp;
import org.cef.CefClient;
import org.cef.browser.CefBrowser;
import org.cef.browser.CefFrame;
import org.cef.handler.CefDisplayHandlerAdapter;
import org.cef.handler.CefLifeSpanHandlerAdapter;
import org.cef.handler.CefLoadHandlerAdapter;
import org.cef.handler.CefLoadHandler.ErrorCode;
import org.cef.CefSettings;

/** Windowed Chromium host. Angular and all agent calls remain on their original origin. */
public final class AngularSwingHost {
    private static final String URL = "http://127.0.0.1:4200/";
    // Keep the complete native-browser ownership chain alive for the window lifetime.
    private final CefApp app;
    private final CefClient client;
    private final CefBrowser browser;
    private final JFrame frame = new JFrame("CALIAN AI | Angular Embedded in Swing");
    private final JLabel status = new JLabel("CALIAN AI | Creating embedded Chromium...");
    private boolean closing;
    private boolean failed;

    private AngularSwingHost(CefApp app) {
        this.app = app;
        client = app.createClient();
        client.addLifeSpanHandler(new CefLifeSpanHandlerAdapter() {
            @Override public void onAfterCreated(CefBrowser b) {
                report("Chromium created; loading " + URL);
            }
            @Override public void onBeforeClose(CefBrowser b) {
                if (b != AngularSwingHost.this.browser) return;
                SwingUtilities.invokeLater(() -> {
                    client.dispose();
                    app.dispose();
                });
            }
        });
        client.addLoadHandler(new CefLoadHandlerAdapter() {
            @Override public void onLoadStart(CefBrowser b, CefFrame f,
                    org.cef.network.CefRequest.TransitionType transition) {
                if (f.isMain()) SwingUtilities.invokeLater(() -> {
                    failed = false;
                    status.setText("CALIAN AI | Loading " + URL);
                });
            }
            @Override public void onLoadEnd(CefBrowser b, CefFrame f, int httpStatus) {
                if (f.isMain()) report("Main document HTTP " + httpStatus + " | " + b.getURL());
            }
            @Override public void onLoadError(CefBrowser b, CefFrame f, ErrorCode code,
                    String text, String failedUrl) {
                if (!f.isMain() || code == ErrorCode.ERR_ABORTED) return;
                SwingUtilities.invokeLater(() -> {
                    failed = true;
                    status.setText("CALIAN AI | Load failed: " + code + " | " + text);
                    System.err.println("LOAD FAILED: " + code + " " + text + " " + failedUrl);
                });
            }
        });
        client.addDisplayHandler(new CefDisplayHandlerAdapter() {
            @Override public boolean onConsoleMessage(CefBrowser b, CefSettings.LogSeverity level,
                    String message, String source, int line) {
                System.err.println("CHROMIUM " + level + " " + source + ":" + line + " " + message);
                return false;
            }
        });
        // Supply the real initial URL: loadURL before native creation can be lost.
        // Construct the JCEF Swing component and attach it on the EDT.
        browser = client.createBrowser(URL, false, false);
        JButton reload = new JButton("Reload");
        reload.addActionListener(e -> browser.reloadIgnoreCache());
        JButton tools = new JButton("Developer tools");
        tools.addActionListener(e -> browser.openDevTools());
        JPanel toolbar = new JPanel(new BorderLayout());
        toolbar.add(status, BorderLayout.CENTER);
        JPanel buttons = new JPanel();
        buttons.add(reload);
        buttons.add(tools);
        toolbar.add(buttons, BorderLayout.EAST);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.add(toolbar, BorderLayout.NORTH);
        frame.add(browser.getUIComponent(), BorderLayout.CENTER);
        frame.setMinimumSize(new Dimension(900, 650));
        frame.setSize(1280, 850);
        frame.setLocationRelativeTo(null);
        frame.addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) {
                if (closing) return;
                closing = true;
                browser.close(true);
                frame.dispose();
                // App disposal follows native onBeforeClose; no premature System.exit.
            }
        });
        frame.setVisible(true);
        Timer watchdog = new Timer(30000, e -> {
            if (!closing && !failed && browser.getURL().equals("about:blank"))
                status.setText("CALIAN AI | No navigation yet; inspect logs or use Reload");
        });
        watchdog.setRepeats(false);
        watchdog.start();
    }

    private void report(String message) {
        System.out.println(message);
        SwingUtilities.invokeLater(() -> {
            if (!closing && !failed) status.setText("CALIAN AI | " + message);
        });
    }

    public static void main(String[] args) throws Exception {
        CefAppBuilder builder = new CefAppBuilder();
        builder.setInstallDir(new File(System.getProperty("calian.jcefDir", new File(System.getProperty("user.home"), ".calian-jcef").getPath())));
        builder.getCefSettings().windowless_rendering_enabled = false;
        builder.getCefSettings().log_file = new File("jcef.log").getAbsolutePath();
        builder.getCefSettings().log_severity = CefSettings.LogSeverity.LOGSEVERITY_INFO;
        // Conservative Windows driver workaround; does not disable Chromium sandbox/security.
        if (!Boolean.getBoolean("calian.enableGpu")) builder.addJcefArgs("--disable-gpu");
        builder.setAppHandler(new MavenCefAppHandlerAdapter() {
            @Override public void stateHasChanged(CefApp.CefAppState state) {
                System.out.println("CEF state: " + state);
                if (state == CefApp.CefAppState.TERMINATED) System.exit(0);
            }
        });
        CefApp app = builder.build();
        SwingUtilities.invokeAndWait(() -> new AngularSwingHost(app));
    }
}
