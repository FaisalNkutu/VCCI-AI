# CALIAN AI: corrected embedded Swing host

## Use your already-working Angular and backend
1. Extract this ZIP into a new folder.
2. Keep your working Angular server (127.0.0.1:4200), backend, Ollama and agent services running.
3. Double-click RUN-SWING-HOST.bat in CALIAN_AI_SWING_CHROMIUM.

This is the smallest launch path. It only compiles and starts the corrected JCEF host.
It uses the existing Angular origin and therefore its existing /api proxy and routing.

## Start Angular and backend from this package instead
1. Close earlier demo servers before switching to this copy. Copy any customized .env from your working project into calian-ai-angular-material; do not overwrite it with .env.example.
2. Keep Ollama and your external Python / AI Core agent services running.
3. Double-click RUN-EMBEDDED-DEMO.bat.

Requires Windows x64, JDK 17+, Maven on PATH, and Node.js 20.19.x or 22.x with npm.
First launch needs internet for npm, Maven and the native Chromium download.
The launcher reuses healthy existing servers and stops only servers it started when the host exits.
RUN-DEMO.bat now forwards to the corrected launcher. The legacy native-swing folder is not used.

## If a window still looks blank
Use the host's Developer tools button and inspect Console / Network. Reload retries the page.
A main-document HTTP 200 is not proof Angular bootstrapped successfully.
The Java console records Chromium creation, main-document status and JavaScript console messages.
Native logs are in swing-host/jcef.log when launched with the supplied scripts.
Service logs are calian-ai-angular-material/server-demo.log and client-demo.log.
The host defaults to --disable-gpu as a Windows graphics-driver workaround.
To compare hardware acceleration, launch manually from swing-host:
  set JAVA_TOOL_OPTIONS=-Dcalian.enableGpu=true
  mvn compile exec:exec
Do not delete the existing native runtime cache merely because the screen is blank.

See PATCH-REPORT.md for findings, changed files and the limits of verification.
