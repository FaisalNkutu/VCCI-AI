@echo off
setlocal
cd /d "%~dp0calian-ai-angular-material"
call npm run dev:%1 > "%~1-demo.log" 2>&1
exit /b %errorlevel%

