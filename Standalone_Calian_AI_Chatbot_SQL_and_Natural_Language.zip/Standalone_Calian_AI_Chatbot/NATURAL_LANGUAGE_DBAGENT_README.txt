CALIAN.AI -- DBAgent SQL + NATURAL-LANGUAGE ROUTING UPDATE
===========================================================

This builds directly on the working A2A DBAgent fix. The A2A JSON-RPC
message/send transport has NOT been changed; existing SQL functionality
is preserved.

Changes:
- Intelligent Auto Select recognizes explicit database questions in English
  and routes them to the discovered DBAgent without invoking the selection LLM.
- The local Ollama routing prompt now describes DBAgent's NL2SQL capability,
  so less explicit database questions can be assigned to DBAgent too.
- Other agents and their execution paths are left unchanged.
- A sample "Ask DBAgent in English" prompt was added to the welcome screen.

IMPORTANT DEPENDENCY:
This update forwards natural-language questions verbatim to the Python A2A
DBAgent service. It does NOT create SQL itself. The A2A DBAgent implementation
on port 5022 must support NL2SQL and have working database access and schema
information. This was NOT verified in a live Docker environment.

HOW TO BUILD (on the Windows PC)
1. Back up your currently working CALIAN_AI_ELECTRON_THEMES folder.
2. Copy the updated server/index.ts and src/app/app.component.html from this ZIP
   into the same locations in your currently working project.
   Do not overwrite other files if your installed project contains newer changes.
3. In PowerShell, go into CALIAN_AI_ELECTRON_THEMES and run:
      npm run dist:win
4. Start the rebuilt executable. Ensure Python A2A DBAgent on 5022, the agent
   registry and Ollama are running as before.

TEST CASES
- Intelligent Auto Select, SQL:
      SELECT COUNT(*) FROM context_ol_assoc;
- Intelligent Auto Select, natural language:
      How many records are in context_ol_assoc?
- Intelligent Auto Select, natural language:
      Show me the latest 10 records from context_ol_assoc.
- Manually select DBAgent and ask the same English question.
- Regression: use Dice Agent, Local Ollama Assistant and the other agents.

EXPECTED ROUTING (for explicit database requests):
   DBAgent / database-intent

IF ROUTING WORKS BUT THE SQL ANSWER DOES NOT:
The problem is within the Python NL2SQL DBAgent executor or its database
configuration, not in the Angular/Electron routing code. Inspect DBAgent
container logs, SQL generation rules and configured database schema before
making other changes.

SECURITY:
Restrict NL2SQL execution to appropriate read-only database credentials
and have the DBAgent verify generated SQL before execution. Do not permit
arbitrary generated data-changing SQL for users without explicit permission.
