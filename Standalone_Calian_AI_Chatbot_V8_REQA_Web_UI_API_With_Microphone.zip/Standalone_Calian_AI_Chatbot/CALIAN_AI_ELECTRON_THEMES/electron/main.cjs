const {app,BrowserWindow,dialog}=require('electron');
const {spawn}=require('node:child_process');
const net=require('node:net');
const {randomUUID}=require('node:crypto');
const path=require('node:path');
const fs=require('node:fs');
let backend;
const dev=!app.isPackaged;
// Packaged CALIAN runs on its own free loopback port, rather than attaching to an
// older CALIAN process accidentally left on 8797.  Development keeps port 8797.
const instanceId=randomUUID();
function readConfig(file){
 if(!fs.existsSync(file))return {};
 const result={};
 for(const line of fs.readFileSync(file,'utf8').split(/\r?\n/)){
  const m=line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
  if(!m)continue;
  let value=m[2];if((value.startsWith('"')&&value.endsWith('"'))||(value.startsWith("'")&&value.endsWith("'")))value=value.slice(1,-1);
  result[m[1]]=value;
 }
 return result;
}
const config={...readConfig(path.join(app.getAppPath(),'.env')),...readConfig(path.join(path.dirname(process.execPath),'calian.env')),...readConfig(path.join(app.getPath('userData'),'calian.env')),...process.env};
const explicitlyConfiguredPort=config.PORT != null && config.PORT !== '';
const configuredPort=Number(config.PORT||8797);
if(!Number.isInteger(configuredPort)||configuredPort<1||configuredPort>65535)throw new Error('Invalid PORT');
const host='127.0.0.1';
function reserveAvailablePort(port){return new Promise((resolve,reject)=>{
 const test=net.createServer();
 test.once('error',reject);
 test.listen(port,host,()=>{
  const addr=test.address();
  const selected=addr&&typeof addr==='object'?addr.port:null;
  test.close(()=>selected?resolve(selected):reject(new Error('Unable to allocate CALIAN backend port')));
 });
});}
function startBackend(port){
 if(dev)return;
 const executable=process.execPath;
 const script=path.join(app.getAppPath(),'dist','backend.cjs');
 const staticDir=path.join(app.getAppPath(),'dist','calian','browser');
 backend=spawn(executable,[script],{env:{...config,ELECTRON_RUN_AS_NODE:'1',CALIAN_STATIC_DIR:staticDir,PORT:String(port),HOST:host,CALIAN_INSTANCE_ID:instanceId},stdio:'ignore',windowsHide:true});
 backend.on('error',e=>dialog.showErrorBox('Backend startup failed',e.message));
}
async function waitBackend(url){
 for(let i=0;i<80;i++){
  try{
   const r=await fetch(`${url}/api/health`,{signal:AbortSignal.timeout(1200)});
   if(r.ok){const health=await r.json();
    if(dev || (health.instanceId===instanceId && health.nlAdapterVersion==='8-reqa-web-ui-voice-v1'))return;
   }
  }catch{}
  await new Promise(r=>setTimeout(r,250));
 }
 throw new Error(`CALIAN V8+Voice backend failed to start at ${url}. The app will not attach to an older server.`);
}
app.whenReady().then(async()=>{try{
 // If PORT is not configured, use a fresh free port per packaged instance.
 // For a configured PORT, fail on collisions instead of silently reusing an old backend.
 const port=dev?configuredPort:await reserveAvailablePort(explicitlyConfiguredPort?configuredPort:0);
 const backendURL=`http://${host}:${port}`;
 startBackend(port);
 await waitBackend(backendURL);
 const win=new BrowserWindow({width:1440,height:920,minWidth:950,minHeight:650,backgroundColor:'#111827',webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}});
 await win.loadURL(dev?'http://127.0.0.1:4300':backendURL);
}catch(e){dialog.showErrorBox('CALIAN AI startup',String(e));app.quit();}});
app.on('window-all-closed',()=>app.quit());
app.on('before-quit',()=>{if(backend)backend.kill();});
