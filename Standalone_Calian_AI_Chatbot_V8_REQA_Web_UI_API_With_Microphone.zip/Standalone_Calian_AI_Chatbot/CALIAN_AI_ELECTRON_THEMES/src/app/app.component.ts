import { Component, OnInit, ViewChild, ElementRef, AfterViewChecked, NgZone, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SocketService } from './socket.service';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatTabsModule } from '@angular/material/tabs';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { Agent, Turn, SharedContext, normalizePythonAgents, normalizeCoreAgents, a2aRequest, coreText } from './protocol';
// The browser's Web Speech API is optional. Electron on Windows uses its native
// speech fallback instead; nothing is installed inside Fouad's Python container.
interface CalianBrowserSpeech {
 lang: string; continuous: boolean; interimResults: boolean;
 onresult: ((event: {results: ArrayLike<{[index: number]: {transcript: string}}>} ) => void) | null;
 onerror: ((event: {error?: string}) => void) | null;
 onend: (() => void) | null;
 start(): void; stop(): void;
}
type CalianSpeechConstructor = new () => CalianBrowserSpeech;
@Component({selector:'app-root',standalone:true,imports:[CommonModule,FormsModule,MatToolbarModule,MatButtonModule,MatIconModule,MatCardModule,MatFormFieldModule,MatInputModule,MatListModule,MatTabsModule,MatCheckboxModule,MatProgressSpinnerModule,MatTooltipModule,MatSidenavModule,MatSnackBarModule],templateUrl:'./app.component.html',styleUrl:'./app.component.scss'})
export class AppComponent implements OnInit,AfterViewChecked,OnDestroy {
 @ViewChild('messagesEnd') messagesEnd?:ElementRef<HTMLElement>;
 agents:Agent[]=[]; selected='auto'; search=''; history:Turn[]=[]; prompt=''; userContext=''; taskContext=''; systemInstructions=''; contextId=crypto.randomUUID(); previousAgentId:string|null=null; busy=false; discovering=false; error=''; notice=''; partial=''; inspectorOpen=true; mobileOpen=false; dark=true; theme:'corporate'|'royal'|'modern'|'classic'='corporate'; lastRoute='No routing decision yet'; pythonOnline=false; selectionOnly=false; inspectorTab=0;
 constructor(private socket:SocketService,private snack:MatSnackBar,private zone:NgZone){}
 voiceActive=false; voiceStatus=''; voiceError='';
 private voiceSessionId='';
 private speechRecognition:CalianBrowserSpeech|null=null;
 ngOnDestroy(){ this.stopVoice(); }

 // A click-to-dictate control: transcription is inserted into the composer,
 // NEVER sent automatically. The user can review/edit before pressing Send.
 toggleVoice(){
  if(this.voiceActive){this.stopVoice();return;}
  if(this.busy)return;
  this.voiceError='';
  this.voiceSessionId=crypto.randomUUID();
  this.voiceActive=true;
  const w=window as Window & {SpeechRecognition?:CalianSpeechConstructor;webkitSpeechRecognition?:CalianSpeechConstructor};
  const engine=w.SpeechRecognition||w.webkitSpeechRecognition;
  // Electron's Chromium often exposes no working Web Speech backend.
  // Windows SAPI via our own local Node server works without web services.
  if(engine && !navigator.userAgent.includes('Electron/')) this.startBrowserSpeech(engine);
  else void this.startWindowsSpeech(this.voiceSessionId);
 }
 private startBrowserSpeech(Constructor:CalianSpeechConstructor){
  const base=this.prompt.trim();
  const prefix=base?base+' ':'';
  try{
   const r=new Constructor();
   this.speechRecognition=r;
   r.lang=navigator.language||'en-US';
   r.continuous=false;
   r.interimResults=true;
   r.onresult=event=>this.zone.run(()=>{
    let spoken='';
    for(let i=0;i<event.results.length;i++){const alternate=event.results[i][0];if(alternate?.transcript)spoken+=alternate.transcript+' ';}
    if(spoken.trim())this.prompt=prefix+spoken.trim();
   });
   r.onerror=event=>this.zone.run(()=>{
    if(event.error!=='no-speech')this.voiceError=`Microphone transcription: ${event.error||'speech recognition failed'}. Check browser microphone permission.`;
    else this.voiceStatus='No speech detected. Try again.';
   });
   r.onend=()=>this.zone.run(()=>{this.speechRecognition=null;this.voiceActive=false;if(this.voiceStatus==='Listening…')this.voiceStatus='Dictation finished. Review the text, then press Send.';});
   this.voiceStatus='Listening…';
   r.start();
  }catch(e){this.speechRecognition=null;this.voiceActive=false;this.voiceError=`Microphone unavailable: ${String(e)}`;}
 }
 private async startWindowsSpeech(sessionId:string){
  this.voiceStatus='Listening with Windows Speech (up to 15 seconds)…';
  try{
   const response=await this.post('/api/speech/recognize',{sessionId});
   if(this.voiceSessionId!==sessionId||!this.voiceActive)return;
   const spoken=typeof response.transcript==='string'?response.transcript.trim():'';
   if(spoken){const existing=this.prompt.trim();this.prompt=existing?`${existing} ${spoken}`:spoken;this.voiceStatus='Speech added. Review or edit, then press Send.';}
   else this.voiceStatus='No speech recognized. Try again.';
  }catch(e){
   if(this.voiceSessionId===sessionId&&this.voiceActive)this.voiceError=`Voice transcription failed: ${e instanceof Error?e.message:String(e)}`;
  }finally{
   if(this.voiceSessionId===sessionId){this.voiceActive=false;}
  }
 }
 stopVoice(){
  if(!this.voiceActive)return;
  this.voiceActive=false;
  this.voiceStatus='Dictation stopped.';
  if(this.speechRecognition){try{this.speechRecognition.stop();}catch{}this.speechRecognition=null;}
  else if(this.voiceSessionId){void this.post('/api/speech/stop',{sessionId:this.voiceSessionId}).catch(()=>{});}
 }

 ngOnInit(){
  const saved=localStorage.getItem('calian-ui-theme');
  if(saved && ['corporate','royal','modern','classic'].includes(saved)) this.setTheme(saved as typeof this.theme);
  void this.refresh();
 }
 setTheme(value:'corporate'|'royal'|'modern'|'classic'){
  this.theme=value;
  this.dark=value!=='classic';
  localStorage.setItem('calian-ui-theme',value);
 }
 toggleBrightness(){this.setTheme(this.dark?'classic':'corporate');}
 ngAfterViewChecked(){ /* Scroll only after new turns or streaming updates, not on every change detection. */ }
 get pythonCount(){return this.agents.filter(a=>a.type==='north').length;}
 get coreCount(){return this.agents.filter(a=>a.type==='aicore').length;}
 get selectedAgent(){return this.agents.find(a=>`${a.type}:${a.id}`===this.selected);}
 get filteredAgents(){return this.agents.filter(a=>(a.name+' '+a.id+' '+a.type).toLowerCase().includes(this.search.toLowerCase()));}
 get context():SharedContext{return {userContext:this.userContext,taskContext:this.taskContext,systemInstructions:this.systemInstructions,conversationHistory:this.history.slice(-12).map(({role,content,agentId})=>({role,content,...(agentId?{agentId}:{})})),agentResults:[]};}
 private async get(path:string){return this.socket.request(path);}
 private async post(path:string,body:unknown){return this.socket.request(path,'POST',body);}
 private scroll(){setTimeout(()=>this.messagesEnd?.nativeElement.scrollIntoView({behavior:'smooth',block:'end'}),30);}
 private stamp(){return new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});}
 async refresh(){this.discovering=true;this.error='';const [py,core]=await Promise.allSettled([this.get('/api/agents'),this.get('/api/ai-core/agents')]);this.pythonOnline=py.status==='fulfilled';this.agents=[...(py.status==='fulfilled'?normalizePythonAgents(py.value):[]),...(core.status==='fulfilled'?normalizeCoreAgents(core.value):[])];if(py.status==='rejected')this.error=`Python service: ${String(py.reason)}`;if(core.status==='rejected')this.notice=`AI Core registry unavailable: ${String(core.reason)}`;this.discovering=false;}
 selectAgent(value:string){this.selected=value;this.mobileOpen=false;}
 reset(){this.contextId=crypto.randomUUID();this.previousAgentId=null;this.history=[];this.partial='';this.error='';this.lastRoute='No routing decision yet';this.snack.open('New conversation created','Dismiss',{duration:2500});}
 exportTranscript(){const blob=new Blob([JSON.stringify({exportedAt:new Date().toISOString(),contextId:this.contextId,userContext:this.userContext,taskContext:this.taskContext,systemInstructions:this.systemInstructions,history:this.history},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`calian-session-${this.contextId.slice(0,8)}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
 copyId(){void navigator.clipboard.writeText(this.contextId);this.snack.open('Session ID copied','Dismiss',{duration:2000});}
 onKeydown(event:KeyboardEvent){if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();void this.send();}}
 async send(){const message=this.prompt.trim();if(!message||this.busy||this.voiceActive)return;this.busy=true;this.prompt='';this.error='';this.partial='';const context=this.context;this.history.push({role:'user',content:message,time:this.stamp()});this.scroll();let agent=this.selectedAgent;
 try{
 if(this.selected==='auto'){
  if(!this.agents.length)throw new Error('No discovered agents available. Refresh discovery.');
  const routed=await this.post('/api/router/select',{message,contextId:this.contextId,...(this.previousAgentId?{previousAgentId:this.previousAgentId}:{}),context,agents:this.agents.map(a=>({id:a.id,name:a.name,type:a.type,description:String(a.raw?.['description']||''),commands:a.commands||[]}))});
  if(!routed.agent)throw new Error(`No matching agent: ${routed.reason||'router returned no agent'}`);
  agent=this.agents.find(a=>a.id===routed.agent.id&&a.type===routed.agent.type);
  if(!agent)throw new Error('Router selected an agent not present in the discovered registry');
  this.lastRoute=`${agent.name} · Router: ${routed.method||'unknown'} · ${routed.reason||'Automatic selection'}${typeof routed.confidence==='number'?` · ${(routed.confidence*100).toFixed(0)}% confidence`:''}`;
  if(this.selectionOnly){const confidence=typeof routed.confidence==='number'?` (${(routed.confidence*100).toFixed(0)}% confidence)`:'';this.previousAgentId=agent.id;this.history.push({role:'assistant',content:`Auto-selected: ${agent.name}${confidence}\nSource: ${agent.type==='aicore'?'AI Core / Paradigm':'Python / A2A'}\nRouter: ${routed.method||'unknown'}\nReason: ${routed.reason||'Metadata match'}\nSelection only — agent execution was not attempted.`,agentId:agent.id,name:'Auto-selection result',time:this.stamp()});this.snack.open(`Routing successful: ${agent.name}`,'Dismiss',{duration:3500});return;}
 }else this.lastRoute=`Manual selection · ${agent?.name||'unknown'}`;
 if(!agent)throw new Error('Select an agent or refresh discovery');
 let answer='';
 if(agent.id==='local-ollama' && agent.type==='north'){const response=await this.post('/api/ollama/chat',{message,contextId:this.contextId,context});answer=String(response.text||'');}
 else if(agent.type==='aicore'){answer=coreText(await this.post('/api/ai-core/execute',{agentId:agent.id,message,contextId:this.contextId,context}));}
 else {answer=await this.socket.a2a(a2aRequest(agent.id,message,this.contextId,context),text=>{this.partial=text;this.scroll();});}
 this.previousAgentId=agent.id;this.history.push({role:'assistant',content:answer||'Agent returned no text response.',agentId:agent.id,name:agent.name,time:this.stamp()});this.partial='';
 }catch(e){this.error=e instanceof Error?e.message:String(e);this.partial='';}finally{this.busy=false;this.scroll();}}
}
