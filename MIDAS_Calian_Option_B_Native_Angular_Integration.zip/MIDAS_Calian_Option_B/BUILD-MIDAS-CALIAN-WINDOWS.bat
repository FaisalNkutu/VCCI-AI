@echo off
setlocal
cd /d "%~dp0midas-frontend"
echo Building integrated MIDAS with Calian AI route...
echo Requires existing MIDAS private @simfront dependencies and pnpm install.
where pnpm >nul 2>&1
if errorlevel 1 (echo pnpm not found. & exit /b 1)
call pnpm run build
if errorlevel 1 (echo Build failed. Review Angular errors. & exit /b 1)
echo Built MIDAS frontend in target\dist
