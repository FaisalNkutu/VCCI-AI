@echo off
setlocal
cd /d "%~dp0midas-frontend"
echo Start the Calian Node backend on 127.0.0.1:8797 first.
echo MIDAS frontend dev server uses /calian/ws and /calian/api/* proxy paths.
where pnpm >nul 2>&1
if errorlevel 1 (
 echo pnpm was not found. Install/enable pnpm and install the MIDAS private dependencies before running.
 exit /b 1
)
call pnpm run start:calian
