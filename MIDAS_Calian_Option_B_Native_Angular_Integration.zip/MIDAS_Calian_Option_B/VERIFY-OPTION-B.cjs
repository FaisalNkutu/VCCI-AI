// Dependency-free source verification (does not replace an Angular build or live tests).
const fs=require('node:fs');const path=require('node:path');
const read=f=>fs.readFileSync(path.join(__dirname,f),'utf8');
const files={routes:read('midas-frontend/src/app/app.routes.ts'),picker:read('midas-frontend/src/app/components/selection/selection.component.ts'),chat:read('midas-frontend/src/app/components/calian-chat/calian-chat.component.ts'),template:read('midas-frontend/src/app/components/calian-chat/calian-chat.component.html'),socket:read('midas-frontend/src/app/components/calian-chat/socket.service.ts'),proxy:read('midas-frontend/proxy.calian.dev.cjs')};
const checks={
 'native Calian Angular route': files.routes.includes("path: 'calian'") && files.routes.includes('CalianChatComponent'),
 'Calian selection entry': files.picker.includes("selectApp('calian')"),
 'multi-agent orchestration reused': files.chat.includes("/api/orchestration/execute"),
 'manual agent routing preserved': files.chat.includes("/api/router/select"),
 'agent execution trace UI': files.template.includes('agent-execution-trace'),
 'same-origin WebSocket': files.socket.includes('/calian/ws') && !files.socket.includes('isDev'),
 'scoped development proxy': files.proxy.includes("'/calian/api/**'") && files.proxy.includes("'/calian/ws'"),
 'video excluded from MIDAS screen': !files.template.includes('app-video-center'),
 'no Electron dependency in imported UI': !files.chat.includes('electron'),
};
let failed=0;for(const [k,v] of Object.entries(checks)){console.log(`${v?'PASS':'FAIL'} ${k}`);if(!v)failed++;}
if(failed)process.exit(1);console.log(`Passed ${Object.keys(checks).length} source checks. Run Angular build and browser integration tests next.`);
