import { CpContainerComponent } from '@/dashboards/combat-power/cp-container.component';
import { CmContainerComponent } from '@/dashboards/control-measure/cm-container.component';
import { EnemyEngageContainerComponent } from '@/dashboards/enemy-engagement/enemy-engage-container.component';
import { FratricideContainerComponent } from '@/dashboards/fratricide/fratricide-container.component';
import { HHourContainerComponent } from '@/dashboards/h-hour/h-hour-container.component';
import { PoeContainerComponent } from '@/dashboards/poe/poe-container.component';
import { RomContainerComponent } from '@/dashboards/rate-of-movement/rom-container.component';
import { SummaryContainerComponent } from '@/dashboards/summary/summary-container.component';
import { UnitWatchContainerComponent } from '@/dashboards/unit-watch/unit-watch-container.component';
import { HRContainerComponent } from '@/reports/holdings-rollup/hr-container.component';
import { C2ContainerComponent } from './dashboards/c2-compare/c2-container.component';
import { routes as defRoutes } from '@/utils/routes';
import { Routes } from '@angular/router';
import { rootRedirectGuard, updatePreferenceGuard } from '@/app.guard';
import { SelectionComponent } from '@/components/selection/selection.component';
import { AdvMetricsComponent } from '@/components/adv-metrics.component';
import { LvctsComponent } from '@/lvcts/core/lvcts.component';
import { TraineeReportComponent } from '@/lvcts/trainee/trainee-report.component';
import { UnitComponent } from '@/lvcts/unit/unit.component';
import { TraineeComponent } from '@/lvcts/trainee/trainee.component';

export const routes: Routes = [
  {
    path: '',
    component: SelectionComponent,
    canActivate: [rootRedirectGuard]
  },

  { path: 'select', component: SelectionComponent },

  // --- LVCTS APP ---
  {
    path: 'lvcts',
    component: LvctsComponent,
    canActivate: [updatePreferenceGuard('lvcts')],
    canActivateChild: [updatePreferenceGuard('lvcts')],
    children: [
      {
        path: '',
        redirectTo: 'trainee',
        pathMatch: 'full'
      },
      {
        path: 'trainee',
        component: TraineeComponent,
        children: [
          {
            path: ':traineeId',
            component: TraineeReportComponent
          }
        ]
      },
      { path: 'unit', component: UnitComponent },
    ]
  },

  // --- ADV METRICS APP ---
  {
    path: 'advmetrics',
    component: AdvMetricsComponent,
    canActivate: [updatePreferenceGuard('advmetrics')],
    canActivateChild: [updatePreferenceGuard('advmetrics')],
    children: [
      {
        path: '',
        redirectTo: defRoutes.SUM.route,
        pathMatch: 'full'
      },
      { path: 'c2', component: C2ContainerComponent },
      { path: defRoutes.SUM.route, component: SummaryContainerComponent },
      { path: defRoutes.HH.route, component: HHourContainerComponent },
      { path: defRoutes.ROM.route, component: RomContainerComponent },
      { path: defRoutes.POE.route, component: PoeContainerComponent },
      { path: defRoutes.CM.route, component: CmContainerComponent },
      { path: defRoutes.FRAT.route, component: FratricideContainerComponent },
      { path: defRoutes.ENG.route, component: EnemyEngageContainerComponent },
      { path: defRoutes.CP.route, component: CpContainerComponent },
      { path: defRoutes.UW.route, component: UnitWatchContainerComponent },
      { path: defRoutes.HR.route, component: HRContainerComponent },
    ]
  },

  // --- CALIAN AI: native Angular21 component (no iframe, no Electron) ---
  {
    path: 'calian',
    canActivate: [updatePreferenceGuard('calian')],
    loadComponent: () => import('./components/calian-chat/calian-chat.component')
      .then(m => m.CalianChatComponent)
  },

  // --- CATCH-ALL (MUST BE LAST) ---
  {
    path: '**',
    redirectTo: ''
  }
];
