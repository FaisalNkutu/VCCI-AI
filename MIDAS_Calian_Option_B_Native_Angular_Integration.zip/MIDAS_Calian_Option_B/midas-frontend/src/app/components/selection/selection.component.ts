import { Component, inject } from '@angular/core';
import { Router } from '@angular/router';
import { APP_PREF_KEY } from '@/app.guard';
import { MatIcon } from '@angular/material/icon';
import { NgOptimizedImage } from '@angular/common';

export type AppType = 'advmetrics' | 'lvcts' | 'calian';

@Component({
  selector: 'app-selection',
  imports: [
    MatIcon,
    NgOptimizedImage
  ],
  template: `
    <div class="flex h-screen w-full items-center justify-center bg-zinc-900">

      <div class="flex flex-col w-[400px] rounded-lg bg-zinc-800 shadow-2xl border border-zinc-700 p-8">

        <div class="flex items-center justify-center gap-3 mb-6">
          <img ngSrc="assets/midas_icon.png" height="52" width="52" alt="MIDAS Logo">
          <div class="flex flex-col text-left">
            <div class="text-xl font-bold text-white leading-tight">MIDAS</div>
            <span class="text-xs text-zinc-300">Military Data Analytics</span>
          </div>
        </div>

        <hr class="border-zinc-600 mb-6"/>

        <div class="text-center mb-8">
          <h2 class="text-md font-bold text-white">Welcome to the Workspace</h2>
          <p class="text-xs text-zinc-400 mt-1">Please select an application environment</p>
        </div>

        <div class="flex flex-col gap-4">

          <button (click)="selectApp('advmetrics')"
                  class="flex items-center justify-center gap-3 h-12 w-full rounded-md bg-zinc-800 border border-zinc-500 text-white text-md font-medium hover:cursor-pointer hover:bg-zinc-400 transition-colors focus:outline-none">
            <mat-icon style="color:floralwhite">dashboard</mat-icon>
            Advance Metrics Application
          </button>

          <button (click)="selectApp('calian')"
                  class="flex items-center justify-center gap-3 h-12 w-full rounded-md bg-zinc-800 border border-blue-500 text-white text-md font-medium hover:cursor-pointer hover:bg-zinc-700 transition-colors focus:outline-none">
            <mat-icon style="color: #93c5fd">psychology</mat-icon>
            Calian AI — Intelligent Chatbot
          </button>

          <button (click)="selectApp('lvcts')"
                  class="flex items-center justify-center gap-3 h-12 w-full rounded-md bg-zinc-800 border border-zinc-500 text-white text-md font-medium hover:cursor-pointer hover:bg-zinc-400 transition-colors focus:outline-none">
            <mat-icon style="color:floralwhite">public</mat-icon>
            LVCTS Application
          </button>

        </div>
      </div>
    </div>
  `
})
export class SelectionComponent {
  private router = inject(Router);

  selectApp(app: AppType) {
    localStorage.setItem(APP_PREF_KEY, app);
    this.router.navigate([`/${app}`]).then();
  }
}
