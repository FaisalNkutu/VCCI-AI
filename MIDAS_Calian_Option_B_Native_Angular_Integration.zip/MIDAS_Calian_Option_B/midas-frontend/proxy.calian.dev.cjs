// Development only — MIDAS Angular21 -> loopback Calian Node backend.
// Run Calian on 127.0.0.1:8797. Never publish its unauthenticated /ws.
module.exports = {
  '/calian/api/**': {
    target: 'http://127.0.0.1:8797',
    changeOrigin: true,
    secure: false,
    pathRewrite: { '^/calian': '' },
  },
  '/calian/ws': {
    target: 'http://127.0.0.1:8797',
    changeOrigin: true,
    secure: false,
    ws: true,
    pathRewrite: { '^/calian': '' },
  }
};
