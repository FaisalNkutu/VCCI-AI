# MIDAS + Calian AI — Option B (native Angular component migration)

## What is implemented

- Imported Calian V8 **chat UI**, automatic multi-agent chaining (CIMAO), manual routing, agent discovery, context inspector, execution trace, theme picker, microphone transcription and optional speech readback **into MIDAS Angular 21** as native source files.
- New lazy-loaded MIDAS route `/calian` and a **Calian AI** button in the MIDAS application chooser. The back link uses `/select` to bypass the saved preference redirect.
- Existing MIDAS dashboards, MIDAS AI, LVCTS, Micronaut APIs, and existing Calian backend are unchanged.
- The floating MIDAS AI widget is hidden while `/calian` is active to avoid overlap.
- **No Electron process, iframe, or video-calling UI is required** in the browser integration.
- Local Calian Node backend remains separate, connected through a **same-origin** `/calian/ws` reverse proxy. Agent request paths remain `/api/*` *inside* the RPC envelope and are handled by the existing backend unchanged.
- Speech status/transcription HTTP calls use `/calian/api/speech/*` via the reverse proxy.

## Source structure

`midas-frontend/src/app/components/calian-chat/` contains component, template, component-scoped SCSS, `socket.service.ts`, `protocol.ts`, and `result-speech.ts` copied/adapted from Calian V8.

## Local development

1. Start the existing **Calian Node backend** on host loopback `127.0.0.1:8797` using the original private `calian.env` or equivalent. Do NOT copy secrets into MIDAS Angular or publish this port.
2. In `midas-frontend`, install its normal **private @simfront dependencies** per the MIDAS project setup (`pnpm install`).
3. Run `pnpm run start:calian` to serve MIDAS with `proxy.calian.dev.cjs`.
4. Visit the MIDAS app, select `Calian AI — Intelligent Chatbot` or navigate to `/calian`.
5. Confirm agent discovery, intelligent auto mode, handoff trace, manual mode, new conversation, voice controls.
6. Open browser developer tools > Network > WS. Check that `ws(s)://<MIDAS-host>/calian/ws` connects; you should never see the browser connect directly to `localhost:8797`.

### Proxy caveat

The Angular 21 Vite dev-server requires `/calian/api/**` and `/calian/ws` selectors, not a blanket `/calian` selector (which would hijack the chatbot route). The supplied proxy uses Angular's supported `pathRewrite` convention; confirm that `/calian/api/speech/status` reaches `/api/speech/status` and `/calian/ws` upgrades to `/ws` on your local backend. This package was not browser-built end to end in this environment.

The MIDAS `anyComponentStyle` production budget has been adjusted for the imported theme-heavy Calian component (warning 16 kB/error 32 kB); review optimization and CSS size during the real build.

## Production deployment and security **REQUIRED**

MIDAS code supplied here does **not** show a completed employee SSO / external guest authorization implementation. Calian backend's `/ws` is also desktop-oriented and does not enforce user-scoped agent permissions. Consequently, **do not expose the reverse proxy to employees, guests, or the public internet as supplied**.

Before production: (a) enforce enterprise SSO or existing MIDAS identity at the gateway; (b) authorize each WebSocket upgrade and HTTP request, **not merely the navigation route**; (c) propagate a trusted user identity to Calian; (d) enforce per-user/per-agent/per-simulation and DBAgent authorization in Calian, including agent-to-agent handoffs; (e) rate-limit and audit, protect secrets, configure CSP/Origin and CSRF controls; (f) restrict or disable database-agent execution for guests. Never put LiveKit/DBAgent/API credentials in the browser.

The example `midas-frontend/calian-proxy.nginx.example.conf` documents HTTPS reverse proxy locations, but intentionally does NOT claim to implement authentication. Integrate it only under your organization's existing auth policies.

## Regression tests

- MIDAS selection, `/advmetrics`, `/lvcts`, data dashboards and MIDAS floating AI still work.
- Calian navigation `/calian`, agent registry, auto/manual selection, multi-agent execution trace, context persistence for a conversation, graceful error when Calian backend unavailable.
- Dev/prod WS upgrade supports `/calian/ws`, and `/calian/api/speech/*` maps to backend `/api/speech/*`.
- Calian backend `/api/orchestration/execute` responds using actual configured agents; try a basic two-agent request and verify the trace.
- Verify user permissions and reject unauthorized users before any external deployment.

## Known limitations

- Native Angular component migration is **source-integrated**, not yet a verified end-to-end build. MIDAS private `@simfront` packages and full Angular21 toolchain are required to compile.
- The Calian Electron executable and its video features are **unchanged** in their own project. Video is intentionally excluded from the MIDAS route.
- `midas-frontend/src/app/app.config.ts` still uses MIDAS's existing `http://localhost:10001` API URL; for remote users MIDAS itself needs a normal HTTPS same-origin API strategy.
- Calian Node and model/agent services must be reachable on the server; the browser route does not run Ollama or other agents itself.
