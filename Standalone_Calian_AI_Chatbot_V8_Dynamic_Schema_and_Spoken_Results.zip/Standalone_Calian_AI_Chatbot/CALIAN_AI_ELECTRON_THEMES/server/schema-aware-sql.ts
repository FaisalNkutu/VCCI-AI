/**
 * CALIAN-owned automatic MariaDB/MySQL schema discovery and speech-name matching.
 * The REQA and Fouad images are not modified. Metadata and final SELECT requests
 * use the SAME existing read-only execute_sql bridge as literal SQL.
 *
 * Supports any accessible table in the CURRENT database, not arbitrary servers.
 * Requires information_schema visibility and Docker's existing reqa-api bridge.
 */
import {compileReadOnlyPlan} from './db-natural-language';

export type DbRows = {success:boolean;rows:unknown[];error:string};
export type ExecuteSql = (sql:string)=>Promise<DbRows>;
export type PlanMaker = (question:string,table:string,columns:string[])=>Promise<unknown>;
export type Translation = {sql:string;method:'schema-count'|'schema-list'|'schema-ollama-plan';table:string;matchScore:number;catalogSize:number};

const VALID_NAME=/^[A-Za-z_][A-Za-z_0-9]{0,127}$/;
const DANGEROUS= /\b(?:delete|drop|truncate|insert|update|alter|replace|grant|revoke|erase|remove|overwrite|create|execute|call|shutdown)\b/i;
const cached=new Map<string,{time:number;tables:string[]}>();
const CACHE_MS=120000;
const PAGE=1000;
const MAX_TABLES=5000;
const MAX_LIMIT=100;
function quoteTable(name:string):string {
 const parts=name.split('.');
 if(parts.length<1||parts.length>2)return identifier(name); // identifier() fails closed
 return parts.map(identifier).join('.');
}

function identifier(name:string):string {
 if(!VALID_NAME.test(name))throw new Error(`Unsupported database identifier: ${name}`);
 return '`'+name+'`';
}
function getField(row:unknown, field:string):unknown {
 if(!row||typeof row!=='object'||Array.isArray(row))return undefined;
 const obj=row as Record<string,unknown>;
 const key=Object.keys(obj).find(k=>k.toLowerCase()===field.toLowerCase());
 return key?obj[key]:undefined;
}
function requireRows(value:DbRows,description:string):unknown[]{
 if(!value.success)throw new Error(`${description} failed: ${value.error||'Database rejected the query'}`);
 if(!Array.isArray(value.rows))throw new Error(`${description} returned invalid rows`);
 return value.rows;
}
/** Cache for 2 minutes; switching to a new DB model refreshes automatically. */
export async function discoverTables(execute:ExecuteSql,cacheKey='default',fresh=false):Promise<string[]> {
 const hit=cached.get(cacheKey);
 if(!fresh&&hit&&hit.time>Date.now())return [...hit.tables];
 const names=new Map<string,string>();
 for(let offset=0;offset<MAX_TABLES;offset+=PAGE){
  // No DATABASE() function: the existing REQA read-only SQL validator permits
  // SELECT queries but intentionally disallows arbitrary SQL function calls.
  // Discover visible non-system schemas; duplicate table names require clarification.
  const selected=(process.env.CALIAN_SCHEMA_DATABASE||'').trim();
  if(selected && !VALID_NAME.test(selected))throw new Error('CALIAN_SCHEMA_DATABASE must be a safe database identifier');
  const where=selected ? `TABLE_SCHEMA = '${selected}'` : "TABLE_SCHEMA NOT IN ('mysql','sys','information_schema','performance_schema')";
  const sql=`SELECT TABLE_SCHEMA AS schema_name, TABLE_NAME AS table_name FROM INFORMATION_SCHEMA.TABLES WHERE ${where} ORDER BY TABLE_SCHEMA, TABLE_NAME LIMIT ${PAGE} OFFSET ${offset};`;
  const rows=requireRows(await execute(sql),'Database schema discovery');
  for(const r of rows){
   const name=getField(r,'table_name');
   const schema=getField(r,'schema_name');
   if(typeof schema==='string'&&VALID_NAME.test(schema)&&typeof name==='string'&&VALID_NAME.test(name)){
    const full=`${schema}.${name}`;names.set(full.toLowerCase(),full);
   }
  }
  if(rows.length<PAGE)break;
 }
 if(!names.size)throw new Error('The current database exposes no readable tables through INFORMATION_SCHEMA. Check the connected database and metadata permissions.');
 const tables=[...names.values()].sort();
 cached.set(cacheKey,{time:Date.now()+CACHE_MS,tables});
 return tables;
}
export function clearSchemaCache(){cached.clear();}
const noise=new Set(['the','a','an','my','our','this','that','table','tables','database','records','record','rows','row','entries','entry','of','from','in','within','with','for','by','show','me','give','list','display','fetch','retrieve','first','top','latest','last','please','how','many','are','there','is','all','some','count','number','total','and','on','ten','five','two','one','three','four','six','seven','eight','nine','twenty','thirty','forty','fifty','hundred']);
// Generic linguistic abbreviations, not table-specific mappings or a fixed catalog.
const abbreviations:Record<string,string>={
 context:'contxt',contexts:'contxt',contxt:'contxt',
 association:'assoc',associated:'assoc',associations:'assoc',assoc:'assoc',
 organisation:'org',organization:'org',organisations:'org',organizations:'org',org:'org',
 information:'info',info:'info',identifier:'id',identification:'id',
 transaction:'txn',transactions:'txn',txn:'txn',
 reference:'ref',ref:'ref',configuration:'config',config:'config'
};
function chunks(raw:string):string[]{
 const words=(raw.toLowerCase().replace(/[`"']/g,' ').replace(/[._/-]/g,' ').match(/[a-z0-9]+/g)||[])
 .filter(t=>!noise.has(t));
 const merged:string[]=[];
 for(let i=0;i<words.length;i++){
  if(words[i].length===1&&/^[a-z]$/.test(words[i])){
   let w=words[i];while(i+1<words.length&&words[i+1].length===1&&/^[a-z]$/.test(words[i+1]))w+=words[++i];
   merged.push(w);
  }else merged.push(words[i]);
 }
 return merged.map(t=>abbreviations[t]||t);
}
function dice(a:string,b:string):number{
 if(a===b)return 1;
 if(a.length<2||b.length<2)return 0;
 const pairs=(s:string)=>{const bag=new Map<string,number>();for(let i=0;i<s.length-1;i++){const pair=s.slice(i,i+2);bag.set(pair,(bag.get(pair)||0)+1);}return bag;};
 const x=pairs(a),y=pairs(b);let hits=0;
 for(const [pair,count] of x)hits+=Math.min(count,y.get(pair)||0);
 return 2*hits/(a.length+b.length-2);
}
function matchingPhrase(question:string):string{
 // A named database table normally follows from/in/of/table. Avoid adding other
 // English instructions to the identifier comparison.
 const matches=[
  ...question.matchAll(/\b(?:from|within|in|of)\s+(?:the\s+)?(?:table\s+)?([^?.;]{2,120})/gi),
  ...question.matchAll(/\btable\s+(?:called\s+|named\s+)?([^?.;]{2,120})/gi)
 ];
 for(const match of matches){
  let phrase=match[1].split(/\b(?:where|whose|which|with|having|ordered|sorted|limited|limit|containing|that)\b/i)[0];
  phrase=phrase.replace(/\s+(?:tables?|database)\b.*$/i,'').trim();
  if(phrase&&chunks(phrase).length)return phrase;
 }
 return question;
}
export type TableMatch={name:string;score:number;alternatives:string[]};
export function resolveTable(question:string,tables:string[]):TableMatch{
 if(!tables.length)throw new Error('The schema catalog is empty');
 // Explicit SQL-style identifier (e.g. contxt_oi_assoc) must be exact, never guess.
 const explicit=(question.match(/[`"]([a-z_][a-z_0-9]+)[`"]|\b([a-z_][a-z_0-9]*_[a-z_0-9]+)\b/i)||[]);
 const namedSchema=question.match(/\b([a-z_][a-z_0-9]*)\.([a-z_][a-z_0-9]*)\b/i);
 const target=(namedSchema?`${namedSchema[1]}.${namedSchema[2]}`:explicit[1]||explicit[2]||'').toLowerCase();
 if(target){
  const exact=tables.filter(t=>t.toLowerCase()===target || (!target.includes('.')&&t.split('.').pop()?.toLowerCase()===target));
  if(exact.length===1)return {name:exact[0],score:1,alternatives:[]};
  if(exact.length>1)throw new Error(`Several accessible databases contain table '${target}': ${exact.slice(0,6).join(', ')}. Specify database.table; no SQL was executed.`);
  throw new Error(`Table '${target}' was not found in accessible database metadata. CALIAN will not silently substitute another table.`);
 }
 const phrase=matchingPhrase(question);
 const tokens=chunks(phrase);
 if(!tokens.length)throw new Error('No table name was recognized. Say, for example, “show ten records from the context O I association table.”');
 const joined=tokens.join('');
 const ranked=tables.map(t=>{
  const ts=chunks(t.split('.').pop()||t);const tj=ts.join('');
  const intersect=ts.filter(w=>tokens.includes(w)).length;
  const containment=intersect/Math.max(ts.length,tokens.length);
  const sim=joined===tj?1:0.60*dice(joined,tj)+0.40*containment;
  return {name:t,score:sim};
 }).sort((a,b)=>b.score-a.score||a.name.localeCompare(b.name));
 const best=ranked[0],second=ranked[1];
 // High threshold plus distinct lead: prefer an explicit clarification to a wrong query.
 if(best.score<0.70||(second&&best.score-second.score<0.13)){
  const suggestions=ranked.slice(0,3).map(r=>r.name).join(', ');
  throw new Error(`Could not uniquely match spoken table name '${phrase.trim()}' to the current database. Closest tables: ${suggestions}. Please clarify; no SQL was executed.`);
 }
 return {name:best.name,score:best.score,alternatives:ranked.slice(1,4).map(r=>r.name)};
}
const namedNumbers:Record<string,string>={one:'1',two:'2',three:'3',four:'4',five:'5',six:'6',seven:'7',eight:'8',nine:'9',ten:'10',eleven:'11',twelve:'12',fifteen:'15',twenty:'20',thirty:'30',forty:'40',fifty:'50',hundred:'100'};
export function recognizeNumberWords(text:string):string{
 return text.replace(/\b(one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|fifteen|twenty|thirty|forty|fifty|hundred)\b/gi,w=>namedNumbers[w.toLowerCase()]||w);
}
function rowLimit(question:string):number{
 const match=question.match(/\b(?:show|list|fetch|display|give me|first|top|retrieve|select)\s+(?:me\s+)?(?:the\s+)?(\d{1,4})\b/i)
  ||question.match(/\b(\d{1,4})\s+(?:records?|rows?|entries?)\b/i);
 return match?Math.max(1,Math.min(MAX_LIMIT,Number(match[1]))):20;
}
function isCount(q:string):boolean{return /\b(?:how many|count|number of|total number of)\b/i.test(q) && /\b(?:records?|rows?|entries?|items?)\b/i.test(q);}
function isList(q:string):boolean{return /\b(?:show|list|display|fetch|retrieve|give me|select)\b/i.test(q)&&/\b(?:records?|rows?|entries?|items?)\b/i.test(q);}
function hasConditions(q:string):boolean{return /\b(?:where|whose|having|matching|filter|group|per|by|for each|only|distinct|unique|latest|newest|oldest|last|with|without|sorted|ordered|average|sum|minimum|maximum)\b/i.test(q);}
async function tableColumns(execute:ExecuteSql,table:string):Promise<string[]>{
 const [schema,name]=table.split('.');
 if(!schema||!name)throw new Error('Schema-qualified table name required');
 identifier(schema);identifier(name);
 // Both names were returned from information_schema and restricted to safe identifiers.
 const sql=`SELECT COLUMN_NAME AS column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '${schema}' AND TABLE_NAME = '${name}' ORDER BY ORDINAL_POSITION LIMIT 1000;`;
 const rows=requireRows(await execute(sql),'Column metadata discovery');
 return [...new Set(rows.map(r=>getField(r,'column_name')).filter((x):x is string=>typeof x==='string'&&VALID_NAME.test(x)))];
}
/** Default: deterministic, verified, read-only queries; Ollama receives actual column names. */
export async function schemaAwareTranslate(question:string,execute:ExecuteSql,planMaker:PlanMaker,cacheKey='default'):Promise<Translation>{
 if(!question.trim()||question.length>4000)throw new Error('Database question must be 1–4000 characters');
 if(DANGEROUS.test(question))throw new Error('This assistant generates read-only SQL only. Database changes are blocked.');
 const catalog=await discoverTables(execute,cacheKey);
 let match:TableMatch;
 try{match=resolveTable(question,catalog);}
 catch(e){
  // A database model could have changed since the last request. Refresh once.
  if(cached.get(cacheKey)?.time && catalog.length){
   const updated=await discoverTables(execute,cacheKey,true);
   match=resolveTable(question,updated);
  }else throw e;
 }
 const table=quoteTable(match.name);
 const normalized=recognizeNumberWords(question);
 if(isCount(normalized)&&!hasConditions(normalized)){
  return {sql:`SELECT COUNT(*) AS total_records FROM ${table};`,method:'schema-count',table:match.name,matchScore:match.score,catalogSize:catalog.length};
 }
 if(isList(normalized)&&!hasConditions(normalized)){
  return {sql:`SELECT * FROM ${table} LIMIT ${rowLimit(normalized)};`,method:'schema-list',table:match.name,matchScore:match.score,catalogSize:catalog.length};
 }
 const columns=await tableColumns(execute,match.name);
 if(!columns.length)throw new Error(`No columns could be discovered for ${match.name}. No speculative SQL was run.`);
 const plan=await planMaker(normalized,match.name,columns);
 return {sql:compileReadOnlyPlan(plan,match.name,columns),method:'schema-ollama-plan',table:match.name,matchScore:match.score,catalogSize:catalog.length};
}
