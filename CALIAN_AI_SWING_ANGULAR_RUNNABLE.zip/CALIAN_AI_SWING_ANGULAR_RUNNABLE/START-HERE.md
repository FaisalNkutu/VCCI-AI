# CALIAN Angular Material chatbot embedded in Java Swing

## Prerequisites
- Windows with JDK 17 or newer, Maven 3.9+, Node.js 20.11+ (22 recommended), npm.
- The existing Python A2A service, if live agent communication is required.

## Run — two terminals

Terminal 1:
```powershell
cd calian-ai-angular-material
npm install
Copy-Item .env.example .env
npm run dev
```
Wait until the Angular dev server reports localhost:4200 and the Express server reports port 8787.

Terminal 2 (from the extracted package root):
```powershell
cd swing-host
mvn compile exec:java
```

This opens a standalone Java Swing window containing the Angular Material UI.

## NetBeans
Open Project -> select `swing-host` (Maven project). Run with the Maven goal `compile exec:java`. Start the Angular/backend development server first.

## Architecture
Swing JFrame -> JavaFX JFXPanel / WebView -> Angular on localhost:4200 -> /api proxy -> existing Express on localhost:8787 -> existing Python A2A and AI Core endpoints.

## Notes / limitations
- The embedded renderer here is JavaFX WebView, not Chromium/JCEF. Its WebKit version may not support every feature required by Angular 19, so verify rendering and streaming on your machine. If it fails, switch to JCEF/JxBrowser for modern Chromium support.
- This is a standalone host, not a modification of your existing VCCI application.
- No direct JavaScript-to-Java bridge is included. Agent operations use the existing HTTP API. The Java Paradigm callbacks must still be connected to the backend for that discovery path.
- No live A2A, SSE, or AI Core integration was tested in this packaging environment.
- The original Angular project's Express API and environment configuration are preserved.
