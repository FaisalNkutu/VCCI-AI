package com.calian.desktop;

import javafx.application.Platform;
import javafx.concurrent.Worker;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Scene;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;

import javax.swing.*;
import java.awt.*;

/** Standalone Swing host. Existing VCCI classes are not modified. */
public final class AngularSwingHost {
    private static final String DEFAULT_URL = "http://127.0.0.1:4200";

    public static void main(String[] args) {
        String url = args.length > 0 ? args[0] : DEFAULT_URL;
        SwingUtilities.invokeLater(() -> createWindow(url));
    }

    private static void createWindow(String url) {
        JFrame frame = new JFrame("CALIAN AI — Angular Material Chatbot");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(1280, 850);
        frame.setMinimumSize(new Dimension(800, 600));
        frame.setLocationRelativeTo(null);

        JFXPanel browserPanel = new JFXPanel();
        JPanel root = new JPanel(new BorderLayout());
        root.add(browserPanel, BorderLayout.CENTER);

        JLabel status = new JLabel(" Connecting to " + url + " ...");
        JButton reload = new JButton("Reload");
        JPanel toolbar = new JPanel(new BorderLayout());
        toolbar.add(status, BorderLayout.CENTER);
        toolbar.add(reload, BorderLayout.EAST);
        root.add(toolbar, BorderLayout.SOUTH);
        frame.setContentPane(root);
        frame.setVisible(true);

        Platform.setImplicitExit(false);
        Platform.runLater(() -> {
            WebView view = new WebView();
            WebEngine engine = view.getEngine();
            engine.setJavaScriptEnabled(true);
            engine.getLoadWorker().stateProperty().addListener((obs, oldState, newState) -> {
                SwingUtilities.invokeLater(() -> status.setText(" " + newState + " — " + url));
                if (newState == Worker.State.FAILED) {
                    Throwable error = engine.getLoadWorker().getException();
                    SwingUtilities.invokeLater(() -> status.setText(" Failed: " + (error == null ? "Check npm run dev" : error.getMessage())));
                }
            });
            browserPanel.setScene(new Scene(view));
            reload.addActionListener(event -> Platform.runLater(engine::reload));
            engine.load(url);
        });
    }
}
