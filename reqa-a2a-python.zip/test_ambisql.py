

import os

from ambisql.graph_lab import Datagora, LLM

from config.settings import get_settings
settings = get_settings()



def mysql_of(database):
    """The connection to the database the question is asked of."""
    return {
        "host": settings.DB_HOST,
        "port": settings.DB_PORT,
        "database": database,
        "user": settings.DB_USER,
        "password": settings.DB_PASSWORD
    }


def model(name, url=settings.ollama_base_url , model_name=settings.ollama_model):
    """A model served by Ollama, without any settings file."""
    return LLM(name, {"api": "ollama", "url": url, "model": model_name,
                      "num_ctx": 16384, "timeout": 600})



print(f"ENV={os.environ}")

database = "calian_more_tables"

dg =Datagora(
        mysql=mysql_of(settings.DB_NAME),
        name=settings.DB_NAME,
        reasoner=model("reasoner"),
        sql=model("sql", settings.ollama_base_url, settings.ollama_sql_model),
        neo4j_uri= settings.NEO4J_HOST ,
        neo4j_user=settings.NEO4J_USER,
        neo4j_password=settings.NEO4J_PASSWORD,
        qdrant_url= f"{settings.QDRANT_HOST}:{settings.QDRANT_PORT}",
        # None is the default, <database>_corpus
        qdrant_collection=database + "_corpus",
        embed_url=settings.ollama_embed_url,
        embed_model=settings.ollama_embed_model,
        descriptions=str(dictionary) if database == "datagora_lib" and dictionary.exists() else None,
        reformulate=True,
        judge="single",
        context={"location": "Montreal", "timezone": "America/Toronto"},
    )

out = dg.ask("Show 5 events of detection by air units")
if out.waiting:        
    print( f"Question was Ambiguous. Choices={out.options}" )                          # the question was ambiguous
    out = dg.ask(out.question, choice=out.options[0].label)

print(out.answer)
print(out.sql)
print(out.rows)



