import sqlglot
from sqlglot import exp

# 1. Define a SQL statement containing a Foreign Key constraint
sql = """
CREATE TABLE Orders (
    OrderID INT PRIMARY KEY,
    CustomerID INT,
    OrderDate DATE,
    CONSTRAINT fk_customer 
        FOREIGN KEY (CustomerID) 
        REFERENCES Customers(id)
);
"""

# 2. Parse the SQL string into an AST
expression = sqlglot.parse_one(sql)

# 3. Find and inspect the Foreign Key constraints
for fk in expression.find_all(exp.ForeignKey):
    # Extract source columns inside the FOREIGN KEY (...) definition
    source_cols = [col.name for col in fk.find(exp.Schema).find_all(exp.Identifier)]
    
    # Extract the referenced table and target columns inside REFERENCES ...(...)
    reference = fk.find(exp.Reference)
    referenced_table = reference.this.name
    referenced_cols = [col.name for col in reference.find_all(exp.Identifier)]

    # Print parsed details
    print(f"Source Columns:     {source_cols}")
    print(f"Referenced Table:   {referenced_table}")
    print(f"Referenced Columns: {referenced_cols}")