# =============================================================================
# OPTIONAL EFFICIENCY UPGRADE for agent/pipeline.py :: _try_auto_answer()
# =============================================================================
# Your merged master already implements silent auto-answering. This drop-in
# replacement keeps its exact contract (same callers, same explanation keys)
# and adds two efficiency/fidelity levers:
#
#   1. CANDIDATES SORTED BY COSINE to the original question (via the same
#      embedder schema_rag already holds) — the rewrite closest to what the
#      user actually asked is tried FIRST. Today candidates run in the
#      LLM's arbitrary output order, so a drifted rewrite (e.g. one that
#      invents a JOIN to combat_power_metrics_spec nobody asked for) can
#      consume a full 15-60s pipeline run — and, worse, WIN before a more
#      faithful one is ever tried.
#
#   2. HARD CAP on attempts (REQA_AUTO_ANSWER_MAX_TRIES, default 2) — worst
#      case on failure becomes bounded (~2 extra runs), instead of up to 3.
#
# Replace the existing _try_auto_answer method with this one.
# =============================================================================

    def _try_auto_answer(self, original_question: str, schema_chunks,
                         error_feedback: str = "") -> Optional[PipelineResult]:
        """
        Silent background auto-answer: instead of returning a failure with a
        list of suggestions for the user to pick from, pick the best
        equivalent question ourselves, answer it, and return that answer.

        v2.2 efficiency pass:
          - candidates are SORTED by embedding cosine to the ORIGINAL
            question (closest first), so the most faithful rewrite is tried
            first and a drifted one can no longer win by output-order luck;
          - attempts are capped (REQA_AUTO_ANSWER_MAX_TRIES, default 2) to
            bound worst-case latency on failures.

        The confidence gate (REQA_AUTO_ANSWER_MIN_CONF, default 0.6) is what
        keeps this from silently serving a drifted/wrong answer -- if even the
        best reformulation is doubtful, we fall back to the normal failure
        behaviour instead of guessing. Returns None if nothing qualifies.
        """
        min_conf = float(os.getenv("REQA_AUTO_ANSWER_MIN_CONF", "0.6"))
        max_tries = int(os.getenv("REQA_AUTO_ANSWER_MAX_TRIES", "2"))
        try:
            candidates = _llm_reformulations(
                original_question, schema_chunks,
                getattr(self.sql_generator, "llm", None),
                error_feedback=error_feedback,
            )
        except Exception as exc:
            logger.warning(f"_try_auto_answer: reformulation failed: {exc}")
            return None

        # Deduplicate, drop the original question itself
        seen, cleaned = set(), []
        for cand in candidates or []:
            cand = (cand or "").strip()
            key = cand.lower()
            if not cand or key in seen or key == (original_question or "").strip().lower():
                continue
            seen.add(key)
            cleaned.append(cand)
        if not cleaned:
            return None

        # Sort by cosine similarity to the ORIGINAL question, closest first.
        # Fail-safe: if the embedder is unavailable or errors, keep the
        # LLM's output order (previous behaviour) rather than aborting.
        embedder = getattr(self.schema_rag, "embedder", None)
        if embedder is not None and len(cleaned) > 1:
            try:
                import numpy as np
                q_vec = np.asarray(embedder.embed(original_question), dtype=float)
                q_norm = float(np.linalg.norm(q_vec)) or 1.0

                def _sim(c: str) -> float:
                    v = np.asarray(embedder.embed(c), dtype=float)
                    return float(q_vec @ v / (q_norm * (float(np.linalg.norm(v)) or 1.0)))

                sims = {c: _sim(c) for c in cleaned}
                cleaned.sort(key=lambda c: sims[c], reverse=True)
                logger.info("AUTO-ANSWER candidate order: "
                            + " | ".join(f"{sims[c]:.2f} {c[:60]!r}" for c in cleaned))
            except Exception as exc:
                logger.warning(f"_try_auto_answer: similarity ranking failed, "
                               f"keeping LLM order: {exc}")

        for cand in cleaned[:max_tries]:
            try:
                res = self.run(cand, allow_reformulation=False)
            except Exception as exc:
                logger.warning(f"_try_auto_answer: candidate run failed ({cand!r}): {exc}")
                continue
            conf = ((res.explanation or {}).get("confidence") or {}).get("score")
            if res.success and (conf is None or conf >= min_conf):
                res.explanation = res.explanation or {}
                res.explanation["answered_reformulation"] = cand
                res.explanation["original_question"] = original_question
                logger.info(f"AUTO-ANSWER via reformulation={cand!r} conf={conf}")
                return res
        return None

# =============================================================================
# NOTE — check the embedder attribute name: this uses self.schema_rag.embedder.
# If your SchemaRAG exposes it differently (self.schema_rag._embedder, or the
# pipeline holds its own), adjust the getattr line. The fallback keeps the
# old behaviour if the attribute is absent, so a wrong name degrades
# gracefully instead of breaking auto-answer.
# =============================================================================
