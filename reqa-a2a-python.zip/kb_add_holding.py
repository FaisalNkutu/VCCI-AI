#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
kb_add_holding.py (v3.1) -- Anchor the dataset's actual semantics of
"material expenditure" into the KB.

Findings established on the calian database (2026-07-28):
  * holding (202,367 rows) is a FROZEN INITIAL ALLOCATION: total_qty
    equals on_hand_qty on every row, a single time snapshot per item, and
    not one (unit, type) pair whose stock ever varies -> holdings describe
    what units HAVE, never what they have SPENT.
  * Actual consumption lives in act_ot_assoc (44,483 rows with qty > 0):
    quantities of materiel employed as resources (cat_code = 'RES') by
    activities. Validated on data: CM = 23,635 / EQ = 20,848 expended.
  * No platoon echelon exists anywhere: obj_item_stat.size_code is NULL
    for all 31,976 units, and unit names identify individual soldiers/
    vehicles ('CA Rifleman_17749'), not platoons.

What this script installs:

  1. RETRIEVAL KEYWORDS on `holding` ("material expenditure",
     "holdings", "on hand", ...) so stock/expenditure questions retrieve
     the table -- also required by the negative pre-flight, which only
     consults retrieved tables.
  2. POSITIVE gold sample queries for what the data CAN answer:
     expenditure by materiel category / by named unit (act_ot_assoc),
     holdings by category / by named unit (holding).
  3. UNANSWERABLE entries (sql: null -> class UNANSWERABLE) for the
     "per platoon" phrasings, with the documented reason. With
     REQA_NEGATIVE_PREFLIGHT=1 the pipeline declines in ~2 s and offers
     the answerable alternatives instead. These entries are MIRRORED onto
     mat_stat and cons_mat_type because those are the tables retrieval
     actually returns for this phrasing (observed in production) --
     holding is not always in the top-5.

Idempotent; the original KB is backed up as .bak. After running:
validate the positive SQL in SQLTools, re-ingest Qdrant (Re-index),
set REQA_NEGATIVE_PREFLIGHT=1 in .env, then
`docker compose restart api a2a`.

Usage: python kb_add_holding.py [path/to/KB_full_update2.json]
"""

import json
import shutil
import sys
from pathlib import Path

KEYWORDS_TO_ADD = [
    "material expenditure", "expenditure", "consumption", "consumed",
    "expended", "holdings", "on hand", "on hand quantity", "stock",
    "stock level", "supplies", "inventory",
]

UNANSWERABLE_WHY_PLATOON = (
    "No platoon-level grouping is possible in this dataset: the unit "
    "echelon field (obj_item_stat.size_code) is NULL for all 31,976 "
    "units, and unit names identify individual soldiers/vehicles "
    "('CA Rifleman_17749'), not platoons. Material expenditure IS "
    "available by materiel category or by named unit, via activity "
    "resource associations (act_ot_assoc.qty) -- ask for one of those "
    "instead."
)


def main() -> None:
    kb_path = Path(sys.argv[1] if len(sys.argv) > 1 else "RAG/KB_full_update2.json")
    if not kb_path.exists():
        sys.exit(f"KB not found: {kb_path}")

    data = json.loads(kb_path.read_text(encoding="utf-8"))
    tables = data.get("tables", data)
    holding = tables.get("holding")
    if holding is None:
        sys.exit("Table 'holding' is missing from the KB.")

    # Detect obj_item's display-name column dynamically (name_txt expected).
    oi_cols = list((tables.get("obj_item", {}).get("columns") or {}).keys())
    name_col = next((c for c in oi_cols if "name" in c.lower()), None)
    unit_select = f"oi.{name_col} AS unit_name, " if name_col else ""
    unit_group = f", oi.{name_col}" if name_col else ""
    print(f"obj_item name column: {name_col or '(none -- id only)'}")

    sql_hold_cat = (
        "SELECT mt.cat_code, SUM(h.on_hand_qty) AS on_hand_total "
        "FROM holding h "
        "JOIN mat_type mt ON mt.mat_type_id = h.obj_type_id "
        "GROUP BY mt.cat_code;"
    )
    # Grouped by NAMED unit, with no echelon filter: size_code is NULL for
    # every unit in this dataset (verified), so any 'PLT' filter would
    # always return an empty result.
    sql_hold_unit = (
        f"SELECT h.obj_item_id, {unit_select}mt.cat_code, "
        "SUM(h.on_hand_qty) AS on_hand_total "
        "FROM holding h "
        "JOIN obj_item oi ON oi.obj_item_id = h.obj_item_id "
        "JOIN mat_type mt ON mt.mat_type_id = h.obj_type_id "
        f"GROUP BY h.obj_item_id{unit_group}, mt.cat_code;"
    )

    # -- Expenditure through activities (VALIDATED on data: 44,483
    #    act_ot_assoc rows with qty > 0). cat_code = 'RES' = resource
    #    employed by the activity -- THE representation of consumption in
    #    this dataset.
    sql_exp_cat = (
        "SELECT mt.cat_code, SUM(a.qty) AS expended_qty "
        "FROM act_ot_assoc a "
        "JOIN mat_type mt ON mt.mat_type_id = a.obj_type_id "
        "WHERE a.cat_code = 'RES' AND a.qty > 0 "
        "GROUP BY mt.cat_code;"
    )
    # Attribution to a NAMED unit via the activity-unit association
    # (act_oi_assoc, role 'RES' = resource/performer). NOTE: when an
    # activity involves several units, the quantity is attributed to each
    # of them (read as "expenditure involving that unit").
    sql_exp_unit = (
        f"SELECT {unit_select}mt.cat_code, "
        "SUM(a.qty) AS expended_qty "
        "FROM act_ot_assoc a "
        "JOIN mat_type mt ON mt.mat_type_id = a.obj_type_id "
        "JOIN act_oi_assoc ao ON ao.act_id = a.act_id AND ao.cat_code = 'RES' "
        "JOIN obj_item oi ON oi.obj_item_id = ao.obj_item_id "
        "WHERE a.cat_code = 'RES' AND a.qty > 0 "
        f"GROUP BY mt.cat_code{unit_group};"
    )

    new_queries = [
        # -- What the database CAN answer (POSITIVE) ----------------------
        {
            "question": "What is the total material expenditure for each materiel category?",
            "sql": sql_exp_cat,
            "level": "advanced", "kind": "group_by_enum",
            "expected_outcome": "rows",
            "business_need": ("Consumption tracking: quantities of materiel employed "
                              "as resources by activities (act_ot_assoc, cat 'RES'), "
                              "by materiel category."),
        },
        {
            "question": "Show the material expenditure of each unit by materiel category",
            "sql": sql_exp_unit,
            "level": "advanced", "kind": "group_by_enum",
            "expected_outcome": "rows",
            "business_need": ("Per-unit consumption: materiel employed by activities "
                              "each named unit participates in (approximate "
                              "attribution when several units share an activity)."),
        },
        {
            "question": "What is the total on-hand quantity for each materiel category?",
            "sql": sql_hold_cat,
            "level": "intermediate", "kind": "group_by_enum",
            "expected_outcome": "rows",
            "business_need": "Inventory overview: current holdings by materiel category.",
        },
        {
            "question": "Show the materiel holdings of every unit by category",
            "sql": sql_hold_unit,
            "level": "advanced", "kind": "group_by_enum",
            "expected_outcome": "rows",
            "business_need": ("Per-unit logistics picture: what each named unit "
                              "currently holds (initial allocation)."),
        },
        # -- What the database CANNOT answer (UNANSWERABLE) ---------------
        # sql: None -> query_class() = UNANSWERABLE -> never used as a
        # few-shot, never offered as a suggestion, never embedded, but
        # matched by best_negative_match(). Two stored phrasings: the
        # token-overlap matching (>= 0.85) requires the long variant
        # ("ignoring resupply events") to have its own entry -- 5 shared
        # tokens out of 8 would not clear the threshold against the short
        # phrasing alone.
        {
            "question": "Show the breakdown of material expenditure for every platoon",
            "sql": None,
            "kind": "unanswerable_from_schema",
            "guidance": UNANSWERABLE_WHY_PLATOON,
        },
        {
            "question": ("Show the breakdown of material expenditure for every "
                         "platoon ignoring resupply events"),
            "sql": None,
            "kind": "unanswerable_from_schema",
            "guidance": UNANSWERABLE_WHY_PLATOON,
        },
    ]

    backup = kb_path.with_suffix(kb_path.suffix + ".bak")
    shutil.copy2(kb_path, backup)

    kw = list(holding.get("keywords") or [])
    added_kw = [k for k in KEYWORDS_TO_ADD if k.lower() not in {x.lower() for x in kw}]
    holding["keywords"] = kw + added_kw

    sq = holding.setdefault("sample_queries", [])
    existing_q = {(q.get("question") or "").strip().lower()
                  for q in sq if isinstance(q, dict)}
    added_sq = [q for q in new_queries
                if q["question"].strip().lower() not in existing_q]
    sq.extend(added_sq)

    # Mirror the UNANSWERABLE entries onto the tables retrieval ACTUALLY
    # returns for the "expenditure/platoon" phrasings (mat_stat,
    # cons_mat_type -- observed in production): the negative pre-flight
    # only consults the top-5 retrieved tables, and holding is not always
    # among them. No side effects: entries without SQL are excluded from
    # few-shots, suggestions AND embeddings by the v3.0 class filters.
    negatives = [q for q in new_queries if q.get("sql") is None]
    mirrored = 0
    for tname in ("mat_stat", "cons_mat_type", "obj_item_stat", "act_event"):
        entry = tables.get(tname)
        if entry is None:
            continue
        tsq = entry.setdefault("sample_queries", [])
        texisting = {(q.get("question") or "").strip().lower()
                     for q in tsq if isinstance(q, dict)}
        for q in negatives:
            if q["question"].strip().lower() not in texisting:
                tsq.append(dict(q))
                mirrored += 1
    print(f"Refusal entries mirrored onto mat_stat/cons_mat_type/obj_item_stat/act_event: {mirrored}")

    kb_path.write_text(json.dumps(data, ensure_ascii=False, indent=2),
                       encoding="utf-8")

    print(f"Keywords added        : {len(added_kw)}")
    print(f"Sample queries added  : {len(added_sq)} "
          f"(2 expenditure via activities + 2 holdings + 2 per-platoon refusals)")
    print(f"Backup saved          : {backup}\n")
    print("=== POSITIVE SQL TO VALIDATE IN SQLTOOLS (MANDATORY before re-index) ===\n")
    print("-- Expenditure by category:\n" + sql_exp_cat + "\n")
    print("-- Expenditure by unit:\n" + sql_exp_unit + "\n")
    print("-- Holdings by category:\n" + sql_hold_cat + "\n")
    print("-- Holdings by unit:\n" + sql_hold_unit + "\n")
    print("Then: set REQA_NEGATIVE_PREFLIGHT=1 in .env, re-ingest Qdrant "
          "(docker compose up ingest), docker compose restart api a2a")


if __name__ == "__main__":
    main()