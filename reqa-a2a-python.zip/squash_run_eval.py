"""
Systematic evaluation harness for the REQA-SQL pipeline.

Instead of discovering bugs one at a time through the UI, this script
automatically asks a series of questions (drawn from the curated
sample_queries in KB_full_update.json) against the real API, and produces
a clear report of what passes / fails, with the details of every failure.

Usage:
    python squash_run_eval.py --api-url http://localhost:8080 --sample-per-table 2
    python squash_run_eval.py --tables act,act_task,geo_point --sample-per-table 3
    python squash_run_eval.py --domain "Geography, Facilities & Infrastructure"
    python squash_run_eval.py --limit 20          # quick smoke test
    python squash_run_eval.py --resume            # resume an interrupted run

Writes a CSV (eval_results.csv by default) incrementally -- a long run can
be interrupted (Ctrl+C) and resumed without losing the work already done,
via --resume.
"""
import argparse
import csv
import json
import sys
import time
from pathlib import Path

import requests


def load_questions(kb_path: str, tables: list[str] | None, domain: str | None,
                    sample_per_table: int) -> list[dict]:
    """
    Returns a list of {"table": ..., "question": ...} items to test, drawn
    from the sample_queries already present in KB_full_update.json.
    """
    with open(kb_path, encoding="utf-8") as f:
        kb = json.load(f)

    items = []
    for table_name, entry in sorted(kb.items()):
        if tables and table_name not in tables:
            continue
        if domain:
            table_domains = entry.get("domain", [])
            if domain not in table_domains:
                continue

        sample_qs = entry.get("sample_queries", [])
        picked = [
            sq["question"] for sq in sample_qs[:sample_per_table]
            if isinstance(sq, dict) and sq.get("question")
        ]
        for q in picked:
            items.append({"table": table_name, "question": q})

    return items


def sql_targets_table(sql: str, table: str) -> bool:
    """
    Rough semantic sanity check: does the generated SQL actually reference
    the table the question was about? Catches "silent wrong-table" answers
    that execute fine (success=True) but query a different table entirely
    -- e.g. a question about `act` answered with "SELECT * FROM act_task",
    observed in real runs. Word-boundary match so `act` doesn't falsely
    match inside `act_task`.
    """
    import re as _re
    if not sql or not table:
        return False
    return bool(_re.search(rf"\b{_re.escape(table)}\b", sql, _re.IGNORECASE))


GLOBAL_ROW_TABLE = "__GLOBAL__"


def load_custom_questions(spec: str) -> list:
    """
    Load an ad-hoc question list, bypassing the KB entirely. Accepts:

      * an INLINE bracketed list:
            --questions '["How many act records?", "Show fire events"]'
        items may also be {"question": ..., "table": ...} dicts -- providing
        the table enables the table_match column;

      * a PATH to a .json file with the same structure;

      * a PATH to a .txt file, one question per line ('#' comments and
        blank lines skipped) -- the most PowerShell-friendly option, since
        inline JSON quoting on Windows shells is notoriously painful.

    Items without a table are recorded under table="custom" (analyzers
    keep them; table_match is left blank since there is no expected table).
    """
    import os as _os

    if spec.strip().startswith("["):
        data = json.loads(spec)
    elif _os.path.exists(spec):
        if spec.lower().endswith(".json"):
            with open(spec, encoding="utf-8") as f:
                data = json.load(f)
        else:
            with open(spec, encoding="utf-8") as f:
                data = [ln.strip() for ln in f
                        if ln.strip() and not ln.strip().startswith("#")]
    else:
        raise SystemExit(f"[!] --questions: '{spec[:60]}' is neither a bracketed "
                         f"list nor an existing file")

    items = []
    for entry in data:
        if isinstance(entry, dict):
            q = (entry.get("question") or "").strip()
            t = (entry.get("table") or "").strip() or "custom"
        else:
            q, t = str(entry).strip(), "custom"
        if q:
            items.append({"table": t, "question": q})
    if not items:
        raise SystemExit("[!] --questions: no usable question found")
    return items


def load_already_tested(output_path: Path) -> set[tuple[str, str]]:
    if not output_path.exists():
        return set()
    done = set()
    with open(output_path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if row.get("table") == GLOBAL_ROW_TABLE:
                continue  # summary footer, not a tested question
            # Infra failures (circuit breaker, connection refused, client
            # timeout) mean the question was never actually evaluated --
            # the LLM never saw it. --resume must RETRY those, not skip
            # them, otherwise an outage permanently poisons the file.
            err = (row.get("error") or "").lower()
            if ((row.get("success") or "").lower() != "true"
                    and ("circuit breaker" in err or "connection refused" in err
                         or "httpconnectionpool" in err or "max retries" in err
                         or "client timeout" in err)):
                continue
            done.add((row["table"], row["question"]))
    return done


def run_one_query(api_url: str, api_key: str, question: str, timeout: int) -> dict:
    headers = {"X-API-Key": api_key} if api_key else {}
    t0 = time.time()
    try:
        resp = requests.post(
            f"{api_url}/query",
            json={"question": question},
            headers=headers,
            timeout=timeout,
        )
        resp.raise_for_status()
        data = resp.json()
        elapsed = time.time() - t0
        conf_block = (data.get("explanation") or {}).get("confidence", {}) or {}
        confidence   = conf_block.get("score")
        score_strict = conf_block.get("score_strict")
        rag_conf     = conf_block.get("rag_conf")
        gen_conf     = conf_block.get("gen_conf")
        sem_conf     = conf_block.get("sem_conf")
        return {
            "success": data.get("success", False),
            "attempts": data.get("attempts", 0),
            "row_count": data.get("row_count", 0),
            "confidence": confidence,
            "score_strict": score_strict,
            "rag_conf": rag_conf,
            "gen_conf": gen_conf,
            "sem_conf": sem_conf,
            "error": data.get("error", "")[:300],
            "sql": data.get("sql", "")[:300],
            "elapsed": round(elapsed, 2),
        }
    except requests.exceptions.Timeout:
        return {"success": False, "attempts": 0, "row_count": 0, "confidence": None,
                 "score_strict": None, "rag_conf": None, "gen_conf": None, "sem_conf": None,
                 "error": f"CLIENT TIMEOUT (>{timeout}s)", "sql": "", "elapsed": round(time.time() - t0, 2)}
    except Exception as e:
        return {"success": False, "attempts": 0, "row_count": 0, "confidence": None,
                 "score_strict": None, "rag_conf": None, "gen_conf": None, "sem_conf": None,
                 "error": f"CLIENT ERROR: {str(e)[:250]}", "sql": "", "elapsed": round(time.time() - t0, 2)}


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--api-url", default="http://localhost:8080")
    parser.add_argument("--api-key", default="")
    parser.add_argument("--kb", default="RAG/KB_full_update.json")
    parser.add_argument("--tables", default=None, help="Comma-separated list of tables (default: all)")
    parser.add_argument("--domain", default=None, help="Filter on a specific domain")
    parser.add_argument("--sample-per-table", type=int, default=2, help="Number of sample_queries tested per table")
    parser.add_argument("--limit", type=int, default=None, help="Max total number of questions (smoke test)")
    parser.add_argument("--timeout", type=int, default=400)
    parser.add_argument("--output", default="eval_results.csv")
    parser.add_argument("--resume", action="store_true", help="Skip (table, question) pairs already present in --output")
    parser.add_argument("--questions", default=None,
                        help="Ad-hoc question list, bypassing the KB: an inline "
                             "bracketed JSON list, a .json file, or a .txt file "
                             "(one question per line)")
    args = parser.parse_args()

    tables = [t.strip() for t in args.tables.split(",")] if args.tables else None
    if args.questions:
        items = load_custom_questions(args.questions)
    else:
        items = load_questions(args.kb, tables, args.domain, args.sample_per_table)

    if args.limit:
        items = items[: args.limit]

    output_path = Path(args.output)

    # Never mix two separate runs in one file: if the output already exists
    # and we're NOT resuming it, write to an auto-versioned name instead
    # (eval_results_v2.csv, _v3, ...). --resume keeps appending to the
    # existing file on purpose (that's its whole point).
    if output_path.exists() and not args.resume:
        base, suffix = output_path.stem, output_path.suffix or ".csv"
        n = 2
        while True:
            candidate = output_path.with_name(f"{base}_v{n}{suffix}")
            if not candidate.exists():
                break
            n += 1
        print(f"[!] {output_path} already exists -- writing to {candidate} instead "
              f"(use --resume to continue the existing file).")
        output_path = candidate

    already_done = load_already_tested(output_path) if args.resume else set()
    if already_done:
        items = [it for it in items if (it["table"], it["question"]) not in already_done]
        print(f"[resume] {len(already_done)} question(s) already tested, skipped.")

    print(f"{len(items)} question(s) to test.\n")

    file_exists = output_path.exists()
    if file_exists:
        with open(output_path, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            kept = [r for r in reader if r.get("table") != GLOBAL_ROW_TABLE]
            old_fields = reader.fieldnames or []
        with open(output_path, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=old_fields)
            w.writeheader()
            w.writerows(kept)
    fieldnames = ["table", "question", "success", "attempts", "row_count", "confidence", "score_strict", "rag_conf", "gen_conf", "sem_conf", "table_match", "error", "sql", "elapsed"]

    with open(output_path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if not file_exists:
            writer.writeheader()

        passed = 0
        for i, item in enumerate(items, 1):
            result = run_one_query(args.api_url, args.api_key, item["question"], args.timeout)
            result["table_match"] = (
                sql_targets_table(result.get("sql", ""), item["table"])
                if item["table"] != "custom" else ""
            )
            row = {**item, **result}
            writer.writerow(row)
            f.flush()

            status = "OK  " if result["success"] else "FAIL"
            passed += result["success"]
            print(f"[{i}/{len(items)}] {status}  {item['table']:35}  {result['elapsed']:>6.1f}s  "
                  f"conf={result['confidence']} sem={result['sem_conf']}  {item['question'][:60]}")
            if not result["success"]:
                print(f"          -> {result['error'][:150]}")

    print(f"\n=== Done: {passed}/{len(items)} passed ({passed/len(items)*100:.1f}%) ===" if items else "\nNothing to test.")

    # ------------------------------------------------------------------
    # Global summary footer: one __GLOBAL__ row appended at the end of
    # the CSV so the file is self-contained when shared. Computed over
    # the WHOLE file (not just this session's items), so it stays correct
    # across --resume runs. Any previous __GLOBAL__ row was purged before
    # this run started writing.
    # ------------------------------------------------------------------
    def _mean(values):
        vals = [float(v) for v in values if v not in (None, "", "None")]
        return round(sum(vals) / len(vals), 4) if vals else ""

    with open(output_path, newline="", encoding="utf-8") as f:
        all_rows = [r for r in csv.DictReader(f) if r.get("table") != GLOBAL_ROW_TABLE]

    total_q  = len(all_rows)
    total_ok = sum(1 for r in all_rows if (r.get("success") or "").lower() == "true")
    matches  = [r for r in all_rows if (r.get("success") or "").lower() == "true"]
    match_ok = sum(1 for r in matches if (r.get("table_match") or "").lower() == "true")

    global_row = {
        "table":        GLOBAL_ROW_TABLE,
        "question":     f"GLOBAL SUMMARY over {total_q} questions",
        "success":      f"{total_ok}/{total_q}",
        "attempts":     "",
        "row_count":    "",
        "confidence":   _mean(r.get("confidence") for r in all_rows),
        "score_strict": _mean(r.get("score_strict") for r in all_rows),
        "rag_conf":     _mean(r.get("rag_conf") for r in all_rows),
        "gen_conf":     _mean(r.get("gen_conf") for r in all_rows),
        "sem_conf":     _mean(r.get("sem_conf") for r in all_rows),
        "table_match":  f"{match_ok}/{len(matches)}" if matches else "",
        "error":        f"pass_rate={total_ok/total_q*100:.1f}%" if total_q else "",
        "sql":          "",
        "elapsed":      "",
    }
    with open(output_path, "a", newline="", encoding="utf-8") as f:
        csv.DictWriter(f, fieldnames=fieldnames).writerow(global_row)

    if total_q:
        print(f"[GLOBAL] pass_rate={total_ok}/{total_q} ({total_ok/total_q*100:.1f}%)  "
              f"mean_conf={global_row['confidence']}  mean_sem={global_row['sem_conf']}  "
              f"table_match={global_row['table_match']}")
    print(f"Results written to: {output_path}")


if __name__ == "__main__":
    main()
