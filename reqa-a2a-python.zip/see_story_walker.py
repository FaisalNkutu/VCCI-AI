#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
seed_story_walker.py -- GRAPH-driven synthetic data: instead of filling
tables independently, walk the FK graph and generate CONNECTED STORIES.

A story is one connected component of fictional rows:

    root row (e.g. one `act`: "SEED SEIZE OBJECTIVE GOLD")
      └─ child rows referencing IT (act_stat progression, act_ot_assoc
         consumptions, act_oi_assoc participants, act_loc_assoc...)
           └─ grandchild rows referencing THOSE (fire_event under
              act_event, blob under tx_event, ...)

Three coherence guarantees the flat seeder cannot give:
  * CONNECTIVITY -- every generated row is FK-reachable from its story
    root: "what happened during activity X?" returns a full, joined
    picture, not orphans;
  * ONE PROTAGONIST PER STORY -- every FK pointing at a unit-like entity
    (org / obj_item / unit) is bound to the SAME real unit for the whole
    story: the story is "about" someone;
  * ONE TIMELINE PER STORY -- sim times share a per-story base offset
    (story 1 = 100000+, story 2 = 200000+ ...), so stories are disjoint
    operations and ORDER BY time reads as a chronology.

The graph comes from the same source of truth as the integrity engine:
information_schema FK metadata (identical edges to the Neo4j :FK layer
used by join_path_hints -- a Cypher cross-check query is printed with
--show-graph). Integrity and the JC3IEDM overlay are inherited from
seed_synthetic_data.py: this module only decides WHICH rows to create
and HOW they connect; every value still goes through the same
FK-sampling / enum-intersection / SEED-marker machinery.

Safety model identical to the flat seeder: review-first
(seed_stories.sql + seed_stories_cleanup.sql), --apply to execute,
fictional ids >= 900001, fully reversible.

Usage:
  python seed_story_walker.py --db root:pass@host:3306/calian
  python seed_story_walker.py --db ... --root act --stories 3 --children 3 --depth 3
  python seed_story_walker.py --db ... --show-graph        # edges + Cypher check
  python seed_story_walker.py --db ... --apply
"""

from __future__ import annotations

import argparse
import random
import re
import sys
from collections import defaultdict

import seed_synthetic_data as base   # integrity engine + JC3IEDM overlay

# Tables that represent "actors" -- any FK pointing at one of them is
# bound to the story's single protagonist (JC3IEDM: OBJECT-ITEM and its
# ORGANISATION/UNIT subtypes).
PROTAGONIST_TABLES = {"org", "obj_item", "unit"}

STORY_TIME_BLOCK = 100000     # per-story simulation-time base offset


def build_edges(schema: dict) -> dict:
    """{parent_table: [(child_table, fk_col, parent_col)]} -- reverse FK
    edges, restricted to tables present in the introspected set."""
    children = defaultdict(list)
    for child, info in schema.items():
        for col, (pt, pc) in info["fks"].items():
            if pt in schema and pt != child:
                children[pt].append((child, col, pc))
    return children


def fetch_neo4j_edges(uri: str, user: str, password: str,
                      cypher: str) -> set | None:
    """Undirected table-pair set {(a, b), ...} from the VERIFIED join
    graph in Neo4j (the same layer join_path_hints reads). None on any
    failure -- the caller then walks the full information_schema graph.

    The default Cypher matches a plain (:Table)-[:FK]->(:Table) model;
    override with --cypher if your ingestion uses different labels."""
    try:
        from neo4j import GraphDatabase
        driver = GraphDatabase.driver(uri, auth=(user, password))
        with driver.session() as session:
            pairs = set()
            for rec in session.run(cypher):
                vals = list(rec.values())
                if len(vals) >= 2 and vals[0] and vals[1]:
                    a, b = str(vals[0]).lower(), str(vals[1]).lower()
                    pairs.add((a, b))
                    pairs.add((b, a))       # undirected filter
        driver.close()
        return pairs
    except Exception as e:
        print(f"Neo4j graph unavailable ({e}); walking the full "
              f"information_schema FK graph instead.")
        return None


def filter_edges_by_graph(children: dict, verified: set) -> tuple:
    """Keep only reverse-FK edges whose table pair exists in the
    VERIFIED Neo4j graph. Returns (filtered_children, dropped_list)."""
    filtered = defaultdict(list)
    dropped = []
    for pt, edges in children.items():
        for child, fk_col, pcol in edges:
            if (pt, child) in verified:
                filtered[pt].append((child, fk_col, pcol))
            else:
                dropped.append(f"{pt} <- {child}.{fk_col}")
    return filtered, dropped


def make_row(table: str, schema: dict, rng, next_id: dict,
             bindings: dict, protagonist: dict, existing: dict,
             story_base: int, timeline: dict, mission: str):
    """One fictional row for `table`, coherent with its story context.

    bindings    : {(parent_table, parent_col): value} -- FK values fixed
                  by the story ancestors (the connectivity guarantee);
    protagonist : {(table, col): value} for unit-like parents;
    mission     : the story's name, echoed into text columns."""
    info = schema[table]
    row = {}
    for col in info["columns"]:
        name = col["name"]
        fk = info["fks"].get(name)
        if fk:
            key = fk
            if key in bindings:                       # ancestor of THIS story
                row[name] = bindings[key]
            elif fk[0] in PROTAGONIST_TABLES and protagonist.get(fk):
                row[name] = protagonist[fk]           # same actor everywhere
            else:
                pool = existing.get(fk) or []
                if pool:
                    row[name] = rng.choice(pool)
                elif col["nullable"]:
                    row[name] = None
                else:
                    return None                       # unresolvable NOT NULL FK
        elif col["key"] == "PRI" and col["data_type"] in base._NUM_TYPES:
            next_id[table] += 1
            row[name] = next_id[table]
        else:
            sem = base.semantic_value(col, table, rng, next_id[table]
                                      - base.ID_BASE, timeline)
            rule = base._match_rule(table, name)
            if sem is not None and rule and "timeline" in rule:
                sem += story_base                     # per-story time block
            if sem is not None:
                row[name] = sem
            elif ("descr" in name.lower() or name.lower() == "name_txt") \
                    and col["data_type"] in base._TEXT_TYPES:
                text = f"SEED [{mission}] {table} record"
                m = re.search(r"\((\d+)\)", col["column_type"])
                row[name] = text[:int(m.group(1))] if m else text
            elif col["nullable"] and rng.random() < 0.1:
                row[name] = None
            else:
                row[name] = base.gen_value(col, table, rng,
                                           next_id[table] - base.ID_BASE)
    return row


def walk_story(story_ix: int, root: str, schema: dict, children: dict,
               existing: dict, rng, next_id: dict, n_children: int,
               depth: int, n_roots: int = 1):
    """Generate one connected story; returns (rows, summary_lines).
    rows = [(table, row_dict)] in creation (=insertable) order."""
    mission = f"{rng.choice(base._TASK_VERBS)} {rng.choice(base._OBJECTIVES)}"
    story_base = story_ix * STORY_TIME_BLOCK
    timeline: dict = {}

    # One protagonist for the whole story: a REAL unit-like id per
    # protagonist table (sampled from the live database).
    protagonist = {}
    for t, info in schema.items():
        for col, fk in info["fks"].items():
            if fk[0] in PROTAGONIST_TABLES and fk not in protagonist:
                pool = existing.get(fk) or []
                if pool:
                    protagonist[fk] = rng.choice(pool)

    rows, summary = [], [f"story {story_ix}: mission '{mission}'"
                         + (f", protagonist(s) "
                            f"{sorted(set(protagonist.values()))}"
                            if protagonist else "")]

    def spawn(table: str, bindings: dict, level: int, count: int):
        made_here = 0
        for _ in range(count):
            row = make_row(table, schema, rng, next_id, bindings,
                           protagonist, existing, story_base, timeline,
                           mission)
            if row is None:
                continue
            rows.append((table, row))
            made_here += 1
            if level < depth:
                # This row becomes the bound ancestor for its children.
                # Branch width narrows with depth: root children get
                # n_children rows each, grandchildren one fewer, etc.
                for child, fk_col, pcol in children.get(table, []):
                    if pcol in row and row[pcol] is not None:
                        child_bind = dict(bindings)
                        child_bind[(table, pcol)] = row[pcol]
                        spawn(child, child_bind, level + 1,
                              max(1, n_children - (level - 1)))
        if made_here:
            summary.append(f"  L{level} {table}: {made_here} row(s)")

    # n_roots root rows per story: one mission composed of several
    # activities (e.g. 4 acts under 'SEIZE OBJECTIVE GOLD'), each
    # spawning its own child subtree.
    spawn(root, {}, 1, n_roots)
    return rows, summary


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Graph-driven connected-story seeding "
                    "(review-first; --apply to execute).")
    ap.add_argument("--db", required=True,
                    help="user:password@host:port/database")
    ap.add_argument("--tables", default=",".join(base.DEFAULT_TABLES))
    ap.add_argument("--root", default="act",
                    help="story root table (default: act)")
    ap.add_argument("--stories", type=int, default=3)
    ap.add_argument("--roots", type=int, default=1,
                    help="root rows (e.g. activities) per story -- total "
                         "root rows = stories x roots (default 1)")
    ap.add_argument("--children", type=int, default=3,
                    help="rows per child table under each parent row")
    ap.add_argument("--depth", type=int, default=3,
                    help="max FK-walk depth from the root")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--show-graph", action="store_true",
                    help="print FK edges + a Neo4j Cypher cross-check, then exit")
    ap.add_argument("--neo4j", default="",
                    help="Use the VERIFIED join graph as an edge filter: "
                         "user:password@bolt://host:7687")
    ap.add_argument("--cypher",
                    default="MATCH (a:Table)-[:FK]->(b:Table) "
                            "RETURN a.name, b.name",
                    help="Cypher returning verified (parent, child) table "
                         "pairs (adapt to your graph model)")
    ap.add_argument("--apply", action="store_true")
    args = ap.parse_args()

    m = re.match(r"([^:]+):([^@]*)@([^:/]+):?(\d+)?/(.+)", args.db)
    if not m:
        print("--db format: user:password@host:port/database", file=sys.stderr)
        return 2
    user, pwd, host, port, db = m.groups()
    import pymysql
    conn = pymysql.connect(host=host, port=int(port or 3306), user=user,
                           password=pwd, database=db)

    tables = [t.strip() for t in args.tables.split(",") if t.strip()]
    schema = base.introspect(conn, db, tables)
    children = build_edges(schema)

    # Optional: restrict the walk to the VERIFIED join graph (Neo4j --
    # the same curated layer join_path_hints reads). Fail-safe: any
    # connection/model problem falls back to the full FK graph.
    if args.neo4j:
        nm = re.match(r"([^:]+):([^@]*)@(.+)", args.neo4j)
        if nm:
            verified = fetch_neo4j_edges(nm.group(3), nm.group(1),
                                         nm.group(2), args.cypher)
            if verified:
                children, dropped = filter_edges_by_graph(children, verified)
                print(f"Neo4j verified-graph filter: "
                      f"{sum(len(v) for v in children.values())} edge(s) "
                      f"kept, {len(dropped)} dropped")
                for d in dropped:
                    print(f"  dropped (not in verified graph): {d}")
        else:
            print("--neo4j format: user:password@bolt://host:7687",
                  file=sys.stderr)

    if args.show_graph:
        print("FK edges inside the set (parent -> child.fk_col):")
        for pt in sorted(children):
            for child, fk_col, pcol in children[pt]:
                print(f"  {pt}.{pcol} <- {child}.{fk_col}")
        print("\nNeo4j cross-check (should list the same edges):")
        print("  MATCH (a:Table)-[r:FK]->(b:Table) "
              "WHERE a.name IN $tables AND b.name IN $tables "
              "RETURN a.name, b.name, r.columns;")
        return 0

    if args.root not in schema:
        print(f"Root table '{args.root}' not in the introspected set.",
              file=sys.stderr)
        return 2

    # Sample real parent pools (protagonists + out-of-set FKs).
    existing: dict = {}
    for t, info in schema.items():
        for c, fk in info["fks"].items():
            if fk not in existing:
                existing[fk] = base.sample_existing(conn, fk[0], fk[1])

    rng = random.Random(args.seed)
    next_id = defaultdict(lambda: base.ID_BASE)
    all_rows, order_seen = [], []
    for s in range(1, args.stories + 1):
        rows, summary = walk_story(s, args.root, schema, children,
                                   existing, rng, next_id,
                                   args.children, args.depth, args.roots)
        print("\n".join(summary))
        all_rows.extend(rows)
        for t, _ in rows:
            if t not in order_seen:
                order_seen.append(t)

    inserts = []
    for t, row in all_rows:
        cols = ", ".join(f"`{c}`" for c in row)
        vals = ", ".join(base.sql_literal(v) for v in row.values())
        inserts.append(f"INSERT INTO `{t}` ({cols}) VALUES ({vals});")

    cleanup = []
    for t in reversed(order_seen):
        pk = next((c["name"] for c in schema[t]["columns"]
                   if c["key"] == "PRI"
                   and c["data_type"] in base._NUM_TYPES), None)
        if pk:
            cleanup.append(f"DELETE FROM `{t}` WHERE `{pk}` > {base.ID_BASE};")

    with open("seed_stories.sql", "w", encoding="utf-8") as fh:
        fh.write("-- FICTIONAL connected stories (graph walk; marker SEED,"
                 " ids >= 900001)\nSTART TRANSACTION;\n"
                 + "\n".join(inserts) + "\nCOMMIT;\n")
    with open("seed_stories_cleanup.sql", "w", encoding="utf-8") as fh:
        fh.write("START TRANSACTION;\n" + "\n".join(cleanup) + "\nCOMMIT;\n")
    print(f"\nWritten: seed_stories.sql ({len(inserts)} INSERTs), "
          f"seed_stories_cleanup.sql ({len(cleanup)} DELETEs)")

    if args.apply:
        cur = conn.cursor()
        try:
            for stmt in inserts:
                cur.execute(stmt)
            conn.commit()
            print(f"APPLIED: {len(inserts)} rows.")
        except Exception as e:
            conn.rollback()
            print(f"ROLLED BACK on error: {e}", file=sys.stderr)
            return 1
    else:
        print("Nothing applied (review seed_stories.sql, then --apply).")
    return 0


if __name__ == "__main__":
    sys.exit(main())