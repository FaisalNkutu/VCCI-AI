"""
Persistent, multi-process-safe job store for the /query/start +
/query/status polling pattern.

Replaces the original in-memory dict, which only worked correctly with a
SINGLE uvicorn worker process. With --workers > 1 (or any multi-process
deployment), each worker has its own separate memory: a job created by
worker A (handling /query/start) is invisible to worker B (handling the
next /query/status poll), producing a 404 "job_id not found" even though
the job genuinely exists and is running fine -- confirmed as the actual
root cause of a real deployment (Docker Compose, `--workers 2`).

SQLite is used because:
- It's stdlib (no new dependency, no extra service to run/maintain).
- The db file lives on disk, shared by ALL worker processes within the
  same container (they all see the same filesystem).
- WAL (Write-Ahead Logging) mode + a busy_timeout let multiple processes
  read/write concurrently without "database is locked" errors under the
  light read/write load this polling pattern produces (a handful of
  small reads/writes per second, not a high-throughput OLTP workload).

If this ever runs across MULTIPLE CONTAINERS/hosts (not just multiple
worker processes within one container), swap this for a shared external
store (Redis, a real DB table, ...) instead -- a local SQLite file is not
visible across separate machines.
"""

from __future__ import annotations

import datetime
import decimal
import json
import logging
import sqlite3
import time
from pathlib import Path

DB_PATH = Path(__file__).parent / "jobs.sqlite3"

_JOB_TTL_SECONDS = 3600  # purge finished jobs older than this


def _json_default(obj):
    """
    Fallback encoder for json.dumps() covering the value types pymysql
    commonly returns for DB rows that plain json.dumps() can't handle
    natively:
      - decimal.Decimal (DECIMAL/NUMERIC columns) -> float
      - datetime.date / datetime.datetime / datetime.time -> isoformat string
      - bytes/bytearray (BLOB columns) -> decoded string (best-effort)

    Needed specifically in finish_job(), which persists the pipeline's
    actual result -- including real row data fetched from MariaDB. The
    previous version used a bare json.dumps(result) with no fallback,
    which raised "TypeError: Object of type Decimal is not JSON
    serializable" the moment any query touched a DECIMAL column (verified
    against a real query on combat_power_metrics_results) -- a regression
    introduced by moving off the in-memory dict (where a Pydantic model's
    own JSON encoder handled this transparently) to raw json.dumps() here.
    """
    if isinstance(obj, decimal.Decimal):
        return float(obj)
    if isinstance(obj, (datetime.date, datetime.datetime, datetime.time)):
        return obj.isoformat()
    if isinstance(obj, (bytes, bytearray)):
        try:
            return obj.decode("utf-8")
        except UnicodeDecodeError:
            return obj.hex()
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


def _reset_db_files() -> None:
    """Delete the job-store db and its WAL/SHM side files.

    The job store only holds transient job status for the polling
    pattern -- it is DISPOSABLE by design. A corrupted file (container
    killed mid-write, stale -wal/-shm from a previous run, bind-mount
    quirks) must never be able to crash-loop the whole API at startup.
    """
    for suffix in ("", "-wal", "-shm"):
        try:
            Path(str(DB_PATH) + suffix).unlink(missing_ok=True)
        except OSError:
            pass


def _get_conn() -> sqlite3.Connection:
    # A fresh connection per call -- sqlite3 connections are not safe to
    # share across threads/processes, and opening one is cheap. busy_timeout
    # makes concurrent writers from other workers wait briefly instead of
    # immediately raising "database is locked".
    conn = sqlite3.connect(DB_PATH, timeout=5.0)
    try:
        conn.execute("PRAGMA journal_mode=WAL;")
    except sqlite3.DatabaseError as exc:
        # sqlite3.DatabaseError covers both "disk I/O error"
        # (OperationalError) and "file is not a database".
        # Either way it almost always means the EXISTING file (or
        # its -wal/-shm side files) is corrupted -- observed in production:
        # the API crash-looped at import time on this exact line. The store
        # is disposable, so recreate it instead of dying.
        logging.getLogger("JOB_STORE").warning(
            "journal_mode=WAL failed (%s); recreating the job-store db", exc
        )
        try:
            conn.close()
        except Exception:
            pass
        _reset_db_files()
        conn = sqlite3.connect(DB_PATH, timeout=5.0)
        try:
            conn.execute("PRAGMA journal_mode=WAL;")
        except sqlite3.DatabaseError:
            # Last resort: run without WAL rather than not running at all.
            # (Slightly more lock contention between workers, still correct
            # thanks to busy_timeout.)
            conn.execute("PRAGMA journal_mode=DELETE;")
    conn.execute("PRAGMA busy_timeout=5000;")
    return conn


def init_db() -> None:
    """Create the jobs table if it doesn't exist yet. Safe to call from
    every worker process at startup -- CREATE TABLE IF NOT EXISTS is a
    no-op if another worker already created it."""
    with _get_conn() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS jobs (
                job_id     TEXT PRIMARY KEY,
                status     TEXT NOT NULL,
                stage_json TEXT NOT NULL,
                result_json TEXT,
                created_at REAL NOT NULL
            )
            """
        )


def create_job(job_id: str) -> None:
    with _get_conn() as conn:
        conn.execute(
            "INSERT INTO jobs (job_id, status, stage_json, result_json, created_at) VALUES (?, ?, ?, ?, ?)",
            (job_id, "running", json.dumps({"stage": "starting"}), None, time.time()),
        )


def update_stage(job_id: str, stage: dict) -> None:
    with _get_conn() as conn:
        conn.execute(
            "UPDATE jobs SET stage_json = ? WHERE job_id = ?",
            (json.dumps(stage), job_id),
        )


def finish_job(job_id: str, status: str, result: dict) -> None:
    """status: 'done' or 'error'."""
    with _get_conn() as conn:
        conn.execute(
            "UPDATE jobs SET status = ?, result_json = ? WHERE job_id = ?",
            (status, json.dumps(result, default=_json_default), job_id),
        )


def get_job(job_id: str) -> dict | None:
    with _get_conn() as conn:
        row = conn.execute(
            "SELECT status, stage_json, result_json FROM jobs WHERE job_id = ?",
            (job_id,),
        ).fetchone()
    if row is None:
        return None
    status, stage_json, result_json = row
    return {
        "status": status,
        "stage": json.loads(stage_json) if stage_json else None,
        "result": json.loads(result_json) if result_json else None,
    }


def purge_old_jobs() -> None:
    cutoff = time.time() - _JOB_TTL_SECONDS
    with _get_conn() as conn:
        conn.execute("DELETE FROM jobs WHERE created_at < ?", (cutoff,))