#
#  a2a_nl2sql_agent.py
#
#       NL2SQL Agent
#       This file defines the A2A agent protocol used to communicate with NL2SQL
#      

from __future__ import annotations
import sys
import os
import json
import time
sys.path.insert(0,"a2a_common")
import a2a_common.a2a_base_agent_setup # make sure to import this 1st to apply the workaround 

from pydantic import ConfigDict
from google.adk.agents.base_agent_config import BaseAgentConfig
from google.adk.agents import BaseAgent, Agent, SequentialAgent
from typing import Type
from typing import Callable
from typing_extensions import override
from a2a.types import (
    AgentCapabilities,
    AgentCard,
    AgentSkill,
    TransportProtocol,
    DataPart
)
import traceback
import argparse
import re
from google.genai import types
from google.adk.events.event import Event



from common_pipeline import get_pipeline_instance as get_pipeline_instance
from ingest import ingest as ingest
import shlex
from ingest import get_ingest_parser as get_ingest_parser

#=======================   config.json  ====================================================
sys.path.insert(0, "../") # add this path to get the config in root dir
from config.settings import get_settings
settings = get_settings()
#===========================================================================================

from a2a_common.a2a_base_agent_setup import A2AAgentBaseSetup, init_asyncio
from dotenv import load_dotenv

from agent.rated_rules import RatedRulesRAG
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct, PointIdsList, PayloadSchemaType

VERBOSE_DEBUG = True
import logging
logging.basicConfig(level=logging.INFO,format='A2A %(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("A2A") 




#
#   A2ANL2SQLAgentConfig()
#       this config is currently not really needed
#       Its here only to make sure the code run as the samples it is based on
#       #Todo: Investigate, Get rid of this config, or use it for a reason
#
class A2ANL2SQLAgentConfig(BaseAgentConfig):
  model_config = ConfigDict(
      extra="ignore",
  )
  agent_class: str = "A2ANL2SQLAgent"
  used_skill: str = ""


class A2ANL2SQLAgent(BaseAgent):
    agent_card : AgentCard = None
    used_skill: str = ""
    name : str = "NL2SQL"
    tool_invoke_callback: Callable[[str], int] = None
    tool_callback_dict: dict = {}

    #
    # Todo: It makes sense to use functions as tools for A2AFragoCoreAgent    
    # But this needs more clarification if inheriting from BaseAgent
    #
    #  tools:  Callable[..., Any] = [tool_receive, tool_ask]    
    # config_type: ClassVar[type[BaseAgentConfig]] = A2AFragoCoreAgentConfig


    @override
    @classmethod
    def _parse_config(
        cls: Type[A2AFragoCoreAgent],
        config: A2AFragoCoreAgentConfig,
        config_abs_path: str,
        kwargs: Dict[str, Any],
    ) -> Dict[str, Any]:
        if config.used_skill:
            kwargs["used_skill"] = config.used_skill
        return kwargs



    
    #
    #       fix_response_serialization()
    #
    #   Fix the parts that would fail JSOn serialization.
    #
    #   Example, In the following line, Decimal("100.00") makes JSon dump throw an exception.
    #    "rows": [
    #        {"cpower_metrics_result_id": 1, "cpower": Decimal("100.00")
    #        },
    #   
    #   So we remove Decimal(), and keep it as a float number
    #
    def fix_response_serialization(self,  skill_response ):
        
        if "rows" in skill_response.keys():
            nrows = len(skill_response["rows"])
            for i in range(0, nrows ):
                fixed_row = {}
                for key, val, in skill_response["rows"][i].items():
                    
                    if isinstance(val, int) or isinstance(val, float) or isinstance(val, str):
                        fixed_row[key] = val                    
                    else: # Change to string every type that we don't know so it can be json.dump()
                        fixed_row[key] = str(val)                                        

                skill_response["rows"][i] = fixed_row
        return skill_response



    #
    #
    #
    @override
    async def _run_async_impl(self, ctx: InvocationContext ) -> AsyncGenerator[Event, None]:

        logger.info ("\n\n\n\n========================== A2ANL2SQLAgent _run_async_impl ============================")
        logger.info( "INVOCATION CONTEXT=" + str(ctx)  )
            
        used_skill = None
        i = 0

        response = None
        resp_json = {}
        resp_json["Success"] = False           
        resp_json["used_skill"] = None

        for part in ctx.user_content.parts:
            json_dict = json.loads( part.text )
            for key, val in json_dict.items():
                logger.info("\n======= KEY=" + str(key) + " ================\n" )
                
                if key == "GenerateSQL":
                    used_skill = "GenerateSQL"    

                    func = self.tool_callback_dict["GenerateSQL"]
                    req = json_dict["GenerateSQL"]
                    options = req["options"]
                    logger.info( f"req={req}" )
                    logger.info( f"options={options}" )
                    debug = options["debug"]


                    skill_response = await func( req, None, options=options )                
                    logger.info(f"=============  Skill {used_skill} ===============================")
                    logger.info(f"Response = {skill_response}") 
                    logger.info(f"===========================================================================")

                    resp_json["used_skill"] = used_skill
                    if skill_response["success"]:
                        resp_json["Success"] = True
                    resp_json["Request"] = req
                    logger.info(f"skill_response={skill_response}")
                    resp_json["Response"] = self.fix_response_serialization( skill_response )
                
                elif key == "Ingest":
                    used_skill = "Ingest"    
                    func = self.tool_callback_dict["Ingest"]
                    req = json_dict["Ingest"]
                    options = req["options"]
                    

                    logger.info( f"req={req}" )
                    logger.info( f"options={options}" )
                    debug = options["debug"]


                    skill_response = await func( req, None, options=options )
                    logger.info(f"=============  Skill {used_skill} ===============================")
                    logger.info(f"Response = {skill_response}") 
                    logger.info(f"===========================================================================")

                    resp_json["used_skill"] = used_skill
                    if skill_response["success"]:
                        resp_json["Success"] = True
                    resp_json["Request"] = req
                    resp_json["Response"] = self.fix_response_serialization( skill_response )

        

        logger.info(f"\n\nRESP_JSON={resp_json}\n\n")

        yield Event(
            invocation_id=ctx.invocation_id,
            author=self.name,
            content=types.ModelContent(
                parts=[             
                    types.Part(
                        text =  json.dumps( resp_json ) 
                    )                                 
                ]
           ),

           
            
        )


    #
    # get_agent_card(a2a_full_url)
    #   a2a_full_url is for when the agent is running under Uvicorn mount in /a2a for example.
    #   in this case the /a2a must be omitted in the config, but must be included here.
    #   the API
    #
    def get_agent_card(self, a2a_full_url=None):
        settings = get_settings()
        if a2a_full_url == None:
            a2a_full_url = f"{settings.A2A_HOST}:{settings.A2A_PORT}{settings.A2A_PATH}"
        
        logger.info("=================================================================")
        logger.info(f"get_agent_card URL={a2a_full_url}")
        logger.info("=================================================================")

        generate_sql_request ={ 
            "GenerateSQL" :  
            {
                "Request": "GenerateSQL",
                "Query": "How many OPFOR units are in this exercise?",
                "options" : {  'debug' : False, 'force' : False  }
            }
        }

        ingest_request = {
            "Ingest": {
                "Request": "Ingest",
                "Operation" : "Set",
                "INGEST_OPTIONS" : " --verbose --neo4j-import --reindex",
                "Rules" : [ {} ],                
                "options": {  'debug' : False, 'force' : False, "langfuse_tag" : "ingest" }
            }
        }

        self.agent_card = AgentCard(
            name='NL2SQL',        
            url=f"{a2a_full_url}",            
            description='Natural Language to SQL',
            version='1.0',
            capabilities=AgentCapabilities(streaming=True),
            default_input_modes=['text/plain'],
            default_output_modes=['text/plain'],
            preferred_transport=TransportProtocol.jsonrpc,           
            skills=[
                AgentSkill(
                    id="text-to-sql",
                    name="Natural Language to SQL",
                    description=(
                        "Converts a natural language question into a SQL query, "
                        "executes it against MariaDB, and returns a human-readable answer."
                    ),
                    tags=["sql", "database", "mariadb", "text-to-sql"],
                    examples=[
                        json.dumps(generate_sql_request)
                    ],
                    inputModes=["text"],
                    outputModes=["text"], ),

                AgentSkill(
                    id="trigger-ingest",
                    name="Trigger the database ingest",
                    description=(
                        "Trigger the ingest, to update the database definitions"
                        "this is a maintenance/developper function"
                    ),
                    tags=["sql", "ingest", "mariadb", "update"],
                    examples=[
                       json.dumps(ingest_request)
                    ],
                    inputModes=["text"],
                    outputModes=["text"], )  
            ], # end all skills
            )

        return self.agent_card


#
#   dummy Callback, because we are in a test main here, not the full project
#
async def response_callback_dummy(json):
    logger.info( "========= response_callback_dummy(" + str(json) + ") ========== " )
    return { "Success" : True }


NL2SQL_AGENT_SETUP_INSTANCE = None
def get_a2a_agent_instance( skill_tool_callback_dict ):
    global NL2SQL_AGENT_SETUP_INSTANCE

   
    if NL2SQL_AGENT_SETUP_INSTANCE == None:        
        logger.info("== CREATING A2A NL2SQL Agent ===")        
        load_dotenv()
        settings = get_settings()

        logger.info( f"DB_NAME={settings.DB_NAME}")
        logger.info( f"A2A_HOST={settings.A2A_HOST}")
        logger.info( f"A2A_PORT={settings.A2A_PORT}")
        logger.info( f"A2A_PATH={settings.A2A_PATH}")


        # Create the Frag Core ADK Agent    
        nl2sql_agent = A2ANL2SQLAgent()       
        agent_setup = A2AAgentBaseSetup( nl2sql_agent, nl2sql_agent.get_agent_card() , settings.A2A_PORT , skill_tool_callback_dict )
        agent_setup.start_daemon()
        NL2SQL_AGENT_SETUP_INSTANCE = agent_setup
    return NL2SQL_AGENT_SETUP_INSTANCE


PRETEND = False



async def run_pipeline( req, logfunc, **kwargs ):
    global PRETEND  
    #jsonreq = {"GenerateSQL": {"Request": "GenerateSQL", "Query": "Show the 10 rows from combat_power_metrics_results", "options": {"debug": true}}}
    logger.info( f"run_pipeline({req})" )
    jsonrval = {}    
    question = req["Query"]
    options = req["options"]
    force = options.get("force",False)
    pipeline_type = options.get("pipeline", "base")



    pipeline = get_pipeline_instance( req["Query"], pipeline = pipeline_type )   
    pipeline.force = force



    pipeline.set_current_request( req )

    if PRETEND == False:
        result = pipeline.run(question, logfunc, **kwargs)
        jsonrval["success"]     = result.success
        jsonrval["answer"]      = result.answer
        jsonrval["sql"]         = result.sql
        jsonrval["rows"]        = result.rows
        jsonrval["row_count"]   = result.row_count
        jsonrval["attempts"]    = result.attempts
        jsonrval["error"]       = result.error
        jsonrval["explanation"] = result.explanation
        jsonrval["debug"]       = result.debug
    else:
        jsonrval["success"]     = True
        jsonrval["answer"]      = "Found 1 row"
        jsonrval["sql"]         = "SELECT * from act"
        jsonrval["rows"]        = [ {"a" : "b"} ]
        jsonrval["row_count"]   = 1
        jsonrval["attempts"]    = 1
        jsonrval["error"]       = None
        jsonrval["explanation"] = "Pretend=True"
        jsonrval["debug"]       = result.debug



    return jsonrval




async def run_ingest(req, logfunc, **kwargs):    
    settings = get_settings()    
    options =  req["options"]
    reindex = force_reindex = options.get("reindex", False)
        
    INGEST_OPTIONS = req["INGEST_OPTIONS"]
    logger.info(f"INGEST_OPTIONSN={INGEST_OPTIONS}")


    # these 2 mandatory args SCHEMA_FILE and KB_FILE cannot be passed by the ingest request. settings/.env wil always be used
    INGEST_OPTIONS = f"{settings.SCHEMA_FILE} --kb={settings.KB_FILE} {INGEST_OPTIONS}"
    args_list = shlex.split(INGEST_OPTIONS)
    parser = get_ingest_parser()

    # 4. Pass the tokenized list directly to parse_args()
    args = parser.parse_args(args_list)
                      
    answer =  f"ARGS={args}"  
    logger.info(f"\n\n{answer}\n")
    

    jsonrval = {}  
    jsonrval["success"]     = True
    jsonrval["error"]       = None
    jsonrval["explanation"] = f"QDRANT_COLLECTION={settings.QDRANT_COLLECTION}\n"

    try:
        ingest( args,   force_reindex=force_reindex  )        
        jsonrval["explanation"] += f"ingest {args}\n"

    except Exception as e:
        jsonrval["success"]     = False
        jsonrval["error"]       = traceback.format_exc()
    

    
    client = QdrantClient(host=settings.QDRANT_HOST, port=settings.QDRANT_PORT)
    
    delete_all_rules = req.get("delete_all_rules", False)
    if delete_all_rules:
        jsonrval["explanation"] += "delete_all_rules"
        logger.info("DELETE ALL RULES")
        RatedRulesRAG.delete_all(client)

    rules = req.get("Rules", [])
    logger.info(f"INGEST RULES={rules}")

    num_rules_ingested = 0
    for rule in rules:
        logger.info( f"\ningest rule: {rule}\n"     )
        rrstats = RatedRulesRAG.ingest_rule(client, rule)
        num_rules_ingested += 1
        
    jsonrval["explanation"] += f"ingest {num_rules_ingested} rules\n"


    jsonrval["debug"]       = ""
    jsonrval["answer"]      = answer    

    return jsonrval

    




#
#
#       Main: Test script for running this agent.
#
#
if __name__=="__main__":
    logger.info("===================================== a2a_nl2sql_agent.py main ==============================================================")    
  #  print(f"{os.environ}")

    skill_tool_callback_dict = { "GenerateSQL" : run_pipeline, "default" : run_pipeline, "Ingest" : run_ingest }
    agent = get_a2a_agent_instance(skill_tool_callback_dict)
  
    while True:
        time.sleep(1)




