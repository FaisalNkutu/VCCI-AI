import csv
import json


def csv_to_dict(input_csv_path: str, output_json_path: str):

    result = {}

    with open(input_csv_path, mode="r", encoding="utf-8") as f:
        reader = csv.DictReader(f)

        for row in reader:
            key = row["Acronym"]
            value = row["Definition"]
            result[key] = value

    # sauvegarde JSON
    with open(output_json_path, mode="w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    return result


# =========================
# EXEMPLE D'UTILISATION
# =========================

data = csv_to_dict(
    "table_names.csv",
    "RAG/table_def2.json"
)

print(data)