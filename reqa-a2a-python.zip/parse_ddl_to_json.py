"""
Parse the MariaDB dump (calian_full_nodata.sql) and extract every table
with its full column information into ONE JSON file -- the raw material
for a later KB_full_update.json enrichment step.

Extracted per table:
    columns        : name -> {data_type, raw_type, allowed_values (ENUM),
                              not_null, default, auto_increment, unsigned,
                              max_length (varchar/char)}
    primary_key    : list of PK column names
    indexes        : index name -> [columns]

Zero dependencies (regex on mysqldump's very regular output format --
one column per line, backticked identifiers).

Usage:
    python parse_ddl_to_json.py --ddl tables_def/calian_full_nodata.sql \
                                --output RAG/schema_from_ddl.json
"""
import argparse
import json
import re


def parse_enum_values(raw: str) -> list:
    """enum('A','B''C',...) -> ['A', "B'C", ...] (handles '' escapes)."""
    m = re.match(r"^enum\((.*)\)$", raw.strip(), re.IGNORECASE | re.DOTALL)
    if not m:
        return []
    return [v.replace("''", "'") for v in re.findall(r"'((?:[^']|'')*)'", m.group(1))]


def normalize_type(raw_type: str) -> tuple:
    """
    'int(10) unsigned' -> ('INTEGER', None) ; 'varchar(80)' -> ('VARCHAR', 80)
    'enum(...)'        -> ('ENUM', None)    ; 'decimal(12,3)' -> ('DECIMAL', None)
    """
    t = raw_type.strip().lower()
    if t.startswith("enum("):
        return "ENUM", None
    base = re.match(r"([a-z]+)", t).group(1)
    length = None
    if base in ("varchar", "char"):
        lm = re.match(r"[a-z]+\((\d+)\)", t)
        length = int(lm.group(1)) if lm else None
    mapping = {
        "int": "INTEGER", "bigint": "BIGINT", "smallint": "SMALLINT",
        "tinyint": "TINYINT", "mediumint": "INTEGER",
        "decimal": "DECIMAL", "float": "FLOAT", "double": "DOUBLE",
        "varchar": "VARCHAR", "char": "CHAR",
        "text": "TEXT", "mediumtext": "TEXT", "longtext": "TEXT", "tinytext": "TEXT",
        "datetime": "DATETIME", "timestamp": "TIMESTAMP", "date": "DATE", "time": "TIME",
        "blob": "BLOB", "mediumblob": "BLOB", "longblob": "BLOB",
    }
    return mapping.get(base, base.upper()), length


def parse_column_line(line: str) -> tuple:
    """One mysqldump column line -> (name, info dict) or (None, None)."""
    m = re.match(r"^`([^`]+)`\s+(.*?),?$", line.strip())
    if not m:
        return None, None
    name, rest = m.group(1), m.group(2)

    # type = everything up to the first recognized attribute keyword
    type_m = re.match(
        r"^(enum\(.*?\)|[a-z]+(?:\(\s*\d+(?:\s*,\s*\d+)?\s*\))?)"
        r"(\s+unsigned)?",
        rest, re.IGNORECASE | re.DOTALL,
    )
    if not type_m:
        return None, None
    raw_type = type_m.group(1)
    unsigned = bool(type_m.group(2))
    attrs = rest[type_m.end():]

    data_type, max_length = normalize_type(raw_type)
    default = None
    dm = re.search(r"DEFAULT\s+(NULL|'(?:[^']|'')*'|-?\d+(?:\.\d+)?)", attrs, re.IGNORECASE)
    if dm:
        d = dm.group(1)
        default = None if d.upper() == "NULL" else d.strip("'").replace("''", "'")

    info = {
        "data_type": data_type,
        "raw_type": re.sub(r"\s+", " ", raw_type)[:120] if data_type != "ENUM" else "ENUM",
        "not_null": bool(re.search(r"\bNOT NULL\b", attrs, re.IGNORECASE)),
        "auto_increment": bool(re.search(r"\bAUTO_INCREMENT\b", attrs, re.IGNORECASE)),
    }
    if unsigned:
        info["unsigned"] = True
    if max_length is not None:
        info["max_length"] = max_length
    if default is not None:
        info["default"] = default
    if data_type == "ENUM":
        info["allowed_values"] = parse_enum_values(raw_type)
    return name, info


def parse_ddl(sql_text: str) -> dict:
    schema = {}
    # each table block: CREATE TABLE `name` ( ...body... ) ENGINE=...;
    for tm in re.finditer(
        r"CREATE TABLE `([^`]+)`\s*\((.*?)\)\s*ENGINE=",
        sql_text, re.DOTALL,
    ):
        table, body = tm.group(1), tm.group(2)
        entry = {"columns": {}, "primary_key": [], "indexes": {}}

        # split body on lines (mysqldump: one definition per line)
        for line in body.splitlines():
            line = line.strip().rstrip(",")
            if not line:
                continue
            if line.upper().startswith("PRIMARY KEY"):
                entry["primary_key"] = re.findall(r"`([^`]+)`", line)
            elif re.match(r"^(UNIQUE\s+)?KEY\b", line, re.IGNORECASE):
                cols = re.findall(r"`([^`]+)`", line)
                if cols:
                    entry["indexes"][cols[0]] = cols[1:]
            elif re.match(r"^(CONSTRAINT|FOREIGN KEY)\b", line, re.IGNORECASE):
                continue  # FKs already covered by the KB's relationships
            elif line.startswith("`"):
                name, info = parse_column_line(line)
                if name:
                    entry["columns"][name] = info
        schema[table] = entry
    return schema


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--ddl", required=True, help="Path to the .sql dump")
    parser.add_argument("--output", default="RAG/schema_from_ddl.json")
    args = parser.parse_args()

    with open(args.ddl, encoding="utf-8", errors="replace") as f:
        schema = parse_ddl(f.read())

    n_cols = sum(len(t["columns"]) for t in schema.values())
    n_enums = sum(1 for t in schema.values() for c in t["columns"].values()
                  if c["data_type"] == "ENUM")
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(schema, f, indent=1, ensure_ascii=False)

    print(f"{len(schema)} tables, {n_cols} columns ({n_enums} ENUM) "
          f"-> {args.output}")


if __name__ == "__main__":
    main()
