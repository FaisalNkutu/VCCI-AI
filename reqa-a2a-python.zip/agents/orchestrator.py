"""
OrchestratorAgent — Coordinates all specialist agents to answer a question.

The orchestrator has no LLM of its own.
It delegates to specialist agents and assembles the final result.

Agent execution flow:
  User Question
    → SchemaAgent    (MCP: semantic schema search)
    → SQLAgent       (LLM Codestral + MCP: generate + validate SQL, retry loop)
    → ExecutorAgent  (MCP: execute SQL safely)
    → RendererAgent  (LLM Mistral: format results as natural language)
    → OrchestratorResult

Cross-cutting: CircuitBreaker opens after N consecutive DB failures.
The execution trace is recorded for observability.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from agent.circuit_breaker import CircuitBreaker
from agent.llm.base import BaseLLM
from agents.executor_agent import ExecutorAgent
from agents.renderer_agent import RendererAgent
from agents.schema_agent import SchemaAgent
from agents.sql_agent import SQLAgent


@dataclass
class OrchestratorResult:
    success: bool
    answer: str
    sql: str = ""
    rows: list = field(default_factory=list)
    row_count: int = 0
    attempts: int = 0
    error: str = ""
    trace: list[str] = field(default_factory=list)


class OrchestratorAgent:
    """
    Top-level coordinator that sequences specialist agents and applies resilience logic.

    Each specialist agent is autonomous: it has its own LLM and/or MCP tools,
    its own system prompt, and its own decision logic. The orchestrator only
    decides the order of calls and how to handle failures between agents.
    """

    def __init__(
        self,
        sql_llm: BaseLLM,
        render_llm: BaseLLM,
        circuit_breaker: CircuitBreaker,
        max_rows: int = 100,
        max_retries: int = 3,
        top_k_tables: int = 5,
    ) -> None:
        self._schema_agent = SchemaAgent()
        self._sql_agent = SQLAgent(sql_llm, max_rows=max_rows, max_retries=max_retries)
        self._executor_agent = ExecutorAgent(max_rows=max_rows)
        self._renderer_agent = RendererAgent(render_llm)
        self._cb = circuit_breaker
        self._top_k = top_k_tables

    async def run(self, question: str) -> OrchestratorResult:
        trace: list[str] = []

        # ── Circuit breaker guard ─────────────────────────────────────────────
        if self._cb.is_open():
            return OrchestratorResult(
                success=False,
                answer="Service temporarily unavailable — too many consecutive failures.",
                error="Circuit breaker open",
                trace=["orchestrator: circuit breaker open — refusing request"],
            )

        # ── 1. Schema retrieval (MCP only, no LLM) ────────────────────────────
        trace.append("orchestrator → schema_agent")
        schema_msg = await self._schema_agent.run(question, top_k=self._top_k)
        if not schema_msg.success:
            return OrchestratorResult(
                success=False,
                answer="Failed to retrieve schema context.",
                error=schema_msg.error,
                trace=trace + [f"schema_agent: error — {schema_msg.error}"],
            )
        n_tables = len(schema_msg.content.get("all_tables", []))
        trace.append(f"schema_agent ✓ — {n_tables} tables indexed, top: {schema_msg.content.get('top_tables', [])}")

        # ── 2. SQL generation + validation (LLM Codestral + MCP) ─────────────
        trace.append("orchestrator → sql_agent")
        sql_msg = await self._sql_agent.run(
            question,
            schema_msg.content["schema_context"],
            schema_msg.content["all_tables"],
        )
        if not sql_msg.success:
            reason = sql_msg.content.get("reason") or sql_msg.error
            trace.append(f"sql_agent ✗ — {sql_msg.content.get('attempts', 0)} attempt(s): {reason}")
            return OrchestratorResult(
                success=False,
                answer=f"Could not generate a valid SQL query: {reason}",
                error=sql_msg.error,
                attempts=sql_msg.content.get("attempts", 0),
                trace=trace,
            )
        sql = sql_msg.content["sql"]
        trace.append(f"sql_agent ✓ — SQL validated in {sql_msg.content['attempts']} attempt(s)")

        # ── 3. Execution (MCP only) ───────────────────────────────────────────
        trace.append("orchestrator → executor_agent")
        exec_msg = await self._executor_agent.run(sql)
        if not exec_msg.success:
            self._cb.record_failure()
            trace.append(f"executor_agent ✗ — {exec_msg.error}")
            return OrchestratorResult(
                success=False,
                answer="Query execution failed.",
                sql=sql,
                error=exec_msg.error,
                attempts=sql_msg.content.get("attempts", 0),
                trace=trace,
            )
        rows: list[dict] = exec_msg.content["rows"]
        trace.append(f"executor_agent ✓ — {len(rows)} row(s) returned")

        # ── 4. Rendering (LLM Mistral, no MCP) ───────────────────────────────
        trace.append("orchestrator → renderer_agent")
        render_msg = await self._renderer_agent.run(question, sql, rows)

        self._cb.record_success()
        trace.append("renderer_agent ✓ — answer ready")

        return OrchestratorResult(
            success=True,
            answer=render_msg.content["answer"],
            sql=sql,
            rows=rows,
            row_count=len(rows),
            attempts=sql_msg.content.get("attempts", 0),
            trace=trace,
        )
