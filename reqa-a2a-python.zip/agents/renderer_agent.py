"""
RendererAgent — Converts raw SQL results into a natural language answer.

Has its own LLM (Mistral — general-purpose, good at natural language).
No MCP — the rendering is purely LLM-based.
"""
from __future__ import annotations

from agent.llm.base import BaseLLM
from agents.base_agent import AgentMessage

_SYSTEM = """You are a data analyst assistant. Write ONE short sentence answering the user's question based solely on the data provided.

Rules:
- Write exactly ONE sentence summarizing the result (count, status, key finding)
- ONLY use information from the provided data — never invent or add anything
- Do not describe values not present in the data
- If results are empty, say so in one sentence"""


def _markdown_table(rows: list[dict]) -> str:
    if not rows:
        return ""
    headers = list(rows[0].keys())
    lines = ["| " + " | ".join(headers) + " |"]
    lines.append("| " + " | ".join("---" for _ in headers) + " |")
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(h, "")) for h in headers) + " |")
    return "\n".join(lines)


class RendererAgent:
    """
    Autonomous rendering agent.
    Has its own LLM (general-purpose model for natural language generation).
    """

    def __init__(self, llm: BaseLLM) -> None:
        self.llm = llm

    async def run(self, question: str, sql: str, rows: list[dict]) -> AgentMessage:
        if not rows:
            return AgentMessage(
                role="renderer_agent",
                success=True,
                content={"answer": "No results found.", "table": ""},
            )

        table = _markdown_table(rows)
        content = f"Question: {question}\n\nData ({len(rows)} row(s)):\n{table}"
        self.llm.set_langfuse_trace_step("RENDER_AGENT")
        intro = self.llm.complete(_SYSTEM, [{"role": "user", "content": content}], max_tokens=60)

        return AgentMessage(
            role="renderer_agent",
            success=True,
            content={"answer": f"{intro.strip()}\n\n{table}", "table": table},
        )
