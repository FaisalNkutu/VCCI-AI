"""
ExecutorAgent — Executes validated SQL via the database MCP server.

No LLM — pure MCP tool use.
Delegates execution entirely to the database_server MCP tool execute_sql.
"""
from __future__ import annotations

from agents.base_agent import AgentMessage, MCPClient


class ExecutorAgent:
    """
    Autonomous execution agent.
    Calls execute_sql via MCP and returns rows as a structured message.
    """

    def __init__(self, max_rows: int = 100) -> None:
        self.max_rows = max_rows

    async def run(self, sql: str) -> AgentMessage:
        async with MCPClient("database_server.py") as db:
            result = await db.call_tool("execute_sql", {"sql": sql, "max_rows": self.max_rows})

        if not result.get("success"):
            return AgentMessage(
                role="executor_agent",
                success=False,
                error=result.get("error", "Unknown execution error"),
                content={"rows": [], "row_count": 0},
            )

        rows: list[dict] = result.get("rows", [])
        return AgentMessage(
            role="executor_agent",
            success=True,
            content={"rows": rows, "row_count": len(rows)},
        )
