"""
SQLAgent — Generates and validates SQL using an LLM + MCP database tools.

This is the most "agentic" component: it has its own decision loop.
  1. LLM (Codestral) generates SQL from question + schema context
  2. MCP tool check_sql_syntax   → syntax + SELECT-only policy
  3. MCP tool explain_sql        → MariaDB EXPLAIN dry-run
  If validation fails → retry with error feedback (up to max_retries)
"""
from __future__ import annotations

from agent.llm.base import BaseLLM
from agents.base_agent import AgentMessage, MCPClient

_SYSTEM = """You are an expert SQL developer for MariaDB 11.4.
Your job: write a single valid MariaDB SELECT query that answers the user's question.

STRICT RULES:
1. Output ONLY the raw SQL — no markdown fences (```), no explanation, no comments
2. Only SELECT statements — never INSERT, UPDATE, DELETE, DROP, CREATE, ALTER, TRUNCATE
3. Use only the tables and columns listed in the schema context
4. Always alias every table (e.g. products p, categories c)
5. Add LIMIT {max_rows} at the end unless the user explicitly asks for all rows
6. Use MariaDB syntax: IFNULL, DATE_FORMAT, GROUP_CONCAT, DATEDIFF, etc.
7. Prefer JOINs over subqueries for readability
8. If the question is impossible to answer with the available schema, reply EXACTLY:
   IMPOSSIBLE: <one-line reason>"""


class SQLAgent:
    """
    Autonomous SQL generation agent.

    Has its own LLM (specialized for code/SQL — Codestral recommended).
    Maintains a retry loop and uses MCP tools for each validation step,
    feeding error messages back to the LLM for self-correction.
    """

    def __init__(self, llm: BaseLLM, max_rows: int = 100, max_retries: int = 3) -> None:
        self.llm = llm
        self.max_rows = max_rows
        self.max_retries = max_retries
        self._system = _SYSTEM.format(max_rows=max_rows)

    async def run(
        self,
        question: str,
        schema_context: str,
        all_tables: list[str],
    ) -> AgentMessage:
        tables_line = ", ".join(all_tables) if all_tables else "(see schema below)"
        error_feedback = ""

        async with MCPClient("database_server.py") as db:
            for attempt in range(1, self.max_retries + 1):

                # ── LLM generates SQL ─────────────────────────────────────────
                messages: list[dict] = [{"role": "user", "content": (
                    f"All available tables: {tables_line}\n\n"
                    f"Detailed schema (most relevant tables for this question):\n{schema_context}\n\n"
                    f"Question: {question}"
                )}]

                if error_feedback:
                    messages.append({"role": "assistant", "content": "-- previous attempt failed"})
                    messages.append({
                        "role": "user",
                        "content": f"Previous SQL failed with:\n{error_feedback}\n\nFix and try again.",
                    })

                self.llm.set_langfuse_trace_step("SQLAGENT_GENERATE")
                sql = self.llm.complete(self._system, messages, max_tokens=1024).strip()

                if sql.upper().startswith("IMPOSSIBLE:"):
                    return AgentMessage(
                        role="sql_agent",
                        success=False,
                        error=sql,
                        content={"sql": "", "attempts": attempt, "reason": sql[11:].strip()},
                    )

                # ── MCP: static syntax + SELECT-only check ────────────────────
                syntax = await db.call_tool("check_sql_syntax", {"sql": sql})
                if not syntax.get("valid"):
                    error_feedback = f"Syntax/policy error: {syntax.get('error', '')}"
                    continue

                # ── MCP: EXPLAIN dry-run ──────────────────────────────────────
                explain = await db.call_tool("explain_sql", {"sql": sql})
                if not explain.get("success"):
                    error_feedback = f"EXPLAIN failed: {explain.get('error', '')}"
                    continue

                return AgentMessage(
                    role="sql_agent",
                    success=True,
                    content={"sql": sql, "attempts": attempt},
                )

        return AgentMessage(
            role="sql_agent",
            success=False,
            error=error_feedback,
            content={"sql": "", "attempts": self.max_retries},
        )
