"""
Base building blocks shared by all agents:
  - MCPClient  async context manager for stdio MCP sessions
  - AgentMessage  typed inter-agent communication envelope
"""
from __future__ import annotations

import json
from contextlib import AsyncExitStack
from dataclasses import dataclass, field
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

MCP_SERVERS_DIR = Path(__file__).parent.parent / "mcp_servers"


@dataclass
class AgentMessage:
    """Typed envelope passed between agents."""
    role: str
    content: dict = field(default_factory=dict)
    error: str = ""
    success: bool = True


class MCPClient:
    """
    Async context manager that opens a stdio MCP session to a server script.

    A new subprocess is spawned on __aenter__ and terminated on __aexit__.
    Multiple tool calls can be made within the same session.

    Usage:
        async with MCPClient("database_server.py") as mcp:
            result = await mcp.call_tool("execute_sql", {"sql": "SELECT 1"})
    """

    def __init__(self, server_script: str) -> None:
        self._script = str(MCP_SERVERS_DIR / server_script)
        self._session: ClientSession | None = None
        self._stack: AsyncExitStack | None = None

    async def __aenter__(self) -> MCPClient:
        self._stack = AsyncExitStack()
        server_params = StdioServerParameters(command="python3", args=[self._script])
        read, write = await self._stack.enter_async_context(stdio_client(server_params))
        self._session = await self._stack.enter_async_context(ClientSession(read, write))
        await self._session.initialize()
        return self

    async def __aexit__(self, *args: object) -> None:
        if self._stack:
            await self._stack.aclose()

    async def call_tool(self, name: str, arguments: dict) -> dict:
        assert self._session is not None, "MCPClient must be used as async context manager"
        result = await self._session.call_tool(name, arguments)
        return json.loads(result.content[0].text)
