"""
SchemaAgent — Retrieves relevant table schemas via the schema MCP server.

This agent has no LLM — it is a pure retrieval agent.
It opens an MCP session to schema_server.py and calls two tools:
  1. search_schema  → top-k tables semantically relevant to the question
  2. list_all_tables → complete table list for SQL generator context
"""
from __future__ import annotations

from agents.base_agent import AgentMessage, MCPClient


class SchemaAgent:
    """
    Autonomous retrieval agent.
    Uses the schema MCP server (Qdrant + fastembed) to find relevant schemas.
    """

    async def run(self, question: str, top_k: int = 5) -> AgentMessage:
        async with MCPClient("schema_server.py") as mcp:
            schema_result = await mcp.call_tool("search_schema", {"query": question, "top_k": top_k})
            tables_result = await mcp.call_tool("list_all_tables", {})

        table_schemas: list[dict] = schema_result.get("tables", [])
        all_tables: list[str] = tables_result.get("tables", [])

        schema_context = "\n\n".join(
            t.get("description", "") for t in table_schemas if t
        )

        return AgentMessage(
            role="schema_agent",
            success=True,
            content={
                "schema_context": schema_context,
                "all_tables": [t for t in all_tables if t],
                "top_tables": [t.get("table", "") for t in table_schemas if t],
            },
        )
