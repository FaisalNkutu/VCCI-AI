"""
FastAPI entry point.

Start with:
    uvicorn api:app --reload --port 8080

v1 endpoints  (single-agent pipeline — unchanged):
    POST /query                    {"question": "..."}
    POST /query/start              {"question": "..."} — returns {"job_id": "..."} immediately
    GET  /query/status/{job_id}    poll for live progress + final result
    GET  /health
    GET  /.well-known/agent.json   A2A Agent Card
    POST /tasks/send               A2A task endpoint

v2 endpoints  (multi-agent + MCP):
    POST /v2/query                 {"question": "..."} — returns trace
    POST /v2/tasks/send             A2A task endpoint (multi-agent)


a2a endpoints (Both)
    port 5022 -> AgentCard

"""

import uuid

from fastapi import FastAPI, HTTPException, Security, Request, Depends, BackgroundTasks
from contextlib import asynccontextmanager
from fastapi.security import APIKeyHeader
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from qdrant_client import QdrantClient

from config.settings import get_settings

settings = get_settings()
from agent.embedder import Embedder
from agent.schema_rag import SchemaRAG
from agent.sql_generator import SQLGenerator
from agent.static_check import StaticChecker
from agent.dry_run import DryRunner
from agent.executor import Executor
from agent.renderer import Renderer
from agent.circuit_breaker import CircuitBreaker
from agent.pipeline import Pipeline
import traceback
import sys
sys.path.insert(0,"a2a_common")
from common_pipeline import get_pipeline_instance as get_pipeline_instance


try:
    from agents.orchestrator import OrchestratorAgent
    _ORCHESTRATOR_AVAILABLE = True
except ImportError:
    _ORCHESTRATOR_AVAILABLE = False
    OrchestratorAgent = None



import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("API")
logger.setLevel(logging.INFO)
logger.disabled = False

# ── API Key authentication ────────────────────────────────────────────────────
_API_KEY_HEADER = APIKeyHeader(name="X-API-Key", auto_error=False)

async def _require_api_key(api_key: str = Security(_API_KEY_HEADER)) -> None:
    """No-op when API_KEY is unset (local dev). Enforced when API_KEY is configured."""
    expected = settings.api_key
    if not expected:
        return  # auth disabled
    if not api_key or api_key != expected:
        raise HTTPException(status_code=403, detail="Invalid or missing API key.")



pipeline = get_pipeline_instance()

# ── Multi-agent orchestrator (v2) ─────────────────────────────────────────────
if _ORCHESTRATOR_AVAILABLE:
    try:
        # Reuse the LLM instances the v1 pipeline already built: they are
        # created inside get_pipeline_instance() (see the "BUILD LLM ..."
        # startup logs) and no module-level sql_llm / render_llm variable
        # exists here. Referencing those undefined names was a merge
        # artifact that crashed this block with a NameError at every
        # startup and silently disabled ALL v2 endpoints (501). Sharing
        # the pipeline's instances also avoids opening a second set of
        # connections to the same Ollama server with duplicated settings.
        orchestrator = OrchestratorAgent(
            sql_llm        = pipeline.sql_generator.llm,
            render_llm     = getattr(pipeline.renderer, "llm",
                                     pipeline.sql_generator.llm),
            circuit_breaker= CircuitBreaker(settings.circuit_breaker_threshold),
            max_rows       = settings.max_rows,
            max_retries    = settings.max_sql_retries,
            top_k_tables   = settings.top_k_tables,
        )
    except Exception as e:
        orchestrator = None
        traceback.print_exc()
        logger.warning("agents.orchestrator not found — v2 endpoints will return 501.")    
    
else:
    orchestrator = None
    logger.warning("agents.orchestrator not found — v2 endpoints will return 501.")






app = FastAPI(
#    lifespan = lifespan,
    title="REQA-SQL Agent",
    version="2.0.0",
    description=(
        "Local Text-to-SQL agent.\n\n"
        "**v1** (`/query`, `/query/start`+`/query/status`, `/tasks/send`) — single-agent pipeline.\n\n"
        "**v2** (`/v2/query`, `/v2/tasks/send`) — multi-agent system with MCP tool servers."
    ),
    redirect_slashes=False
)



@app.exception_handler(Exception)
async def _generic_error_handler(request: Request, exc: Exception):
    """Hide internal stack traces — return a generic message instead."""
    logger.error(f"Unhandled error on {request.url.path}: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error. Check server logs for details."},
    )


class QueryRequest(BaseModel):
    question: str
    options: dict = {}


class QueryResponse(BaseModel):
    success: bool
    answer: str
    sql: str
    rows: list = []
    row_count: int
    attempts: int
    error: str
    explanation: dict = {}
    debug: dict = {}


@app.post("/query", response_model=QueryResponse, dependencies=[Depends(_require_api_key)])
def query(req: QueryRequest):

    logger.info(f"query: {req.question!r}")

    if not req.question.strip():
        raise HTTPException(status_code=400, detail="question cannot be empty")

    result = pipeline.run(req.question, options=req.options)
    return QueryResponse(
        success     = result.success,
        answer      = result.answer,
        sql         = result.sql,
        rows        = result.rows,
        row_count   = result.row_count,
        attempts    = result.attempts,
        error       = result.error,
        explanation = result.explanation,
        debug       = result.debug,
    )


# ── Async job + polling (live progress) ───────────────────────────────────────
#
# /query blocks for the full pipeline duration (up to several minutes with
# retries) — the caller gets zero feedback until it's done or times out.
# These two endpoints split that into:
#   1. POST /query/start           -- starts the pipeline in the background,
#                                      returns a job_id immediately (~instant)
#   2. GET  /query/status/{job_id} -- cheap, fast poll returning the CURRENT
#                                      stage (schema_rag / sql_generation /
#                                      static_check / explain / execution /
#                                      rendering, with attempt N of max) while
#                                      running, and the final result once done.
#
# Backed by job_store.py (SQLite on disk), NOT an in-memory dict. This
# deployment runs `uvicorn --workers 2` (confirmed via `docker inspect
# reqa-api --format "{{.Config.Cmd}}"` while debugging a real 404: a job
# created by worker A handling /query/start was invisible to worker B
# handling the next /query/status poll, since each worker process has its
# own separate memory). An in-memory dict silently breaks under any
# multi-worker/multi-process deployment; SQLite is shared on disk across
# all workers in the same container, so this actually works with --workers
# N for any N.

import job_store

job_store.init_db()


class JobStartResponse(BaseModel):
    job_id: str


class JobStatusResponse(BaseModel):
    status: str                 # "running" | "done" | "error"
    stage: dict | None = None
    result: QueryResponse | None = None


def _run_job(job_id: str, question: str) -> None:
    try:
        result = pipeline.run(
            question,
            progress_callback=lambda stage: job_store.update_stage(job_id, stage),
        )
        response = QueryResponse(
            success     = result.success,
            answer      = result.answer,
            sql         = result.sql,
            rows        = result.rows,
            row_count   = result.row_count,
            attempts    = result.attempts,
            error       = result.error,
            explanation = result.explanation,
        )
        job_store.finish_job(job_id, "done", response.model_dump())
    except Exception as e:
        # Mirrors the app-level exception_handler's philosophy: log the
        # real error server-side, but don't let a raw stack trace leak
        # into the polled response.
        logger.error(f"Background job {job_id} failed: {e}", exc_info=True)
        error_response = QueryResponse(
            success=False, answer="", sql="", rows=[], row_count=0,
            attempts=0, error="Internal server error. Check server logs for details.",
        )
        job_store.finish_job(job_id, "error", error_response.model_dump())


@app.post("/query/start", response_model=JobStartResponse, dependencies=[Depends(_require_api_key)])
def query_start(req: QueryRequest, background_tasks: BackgroundTasks):
    logger.info(f"query_start: {req.question!r}")

    if not req.question.strip():
        raise HTTPException(status_code=400, detail="question cannot be empty")

    job_store.purge_old_jobs()

    job_id = str(uuid.uuid4())
    job_store.create_job(job_id)

    background_tasks.add_task(_run_job, job_id, req.question.strip())
    return JobStartResponse(job_id=job_id)


@app.get("/query/status/{job_id}", response_model=JobStatusResponse, dependencies=[Depends(_require_api_key)])
def query_status(job_id: str):
    job = job_store.get_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="job_id not found (expired or invalid)")
    return JobStatusResponse(
        status=job["status"],
        stage=job["stage"],
        result=job["result"],
    )


@app.get("/health")
def health():
    provider = settings.LLM_PROVIDER
    if provider == "ollama":
        return {
            "status": "ok",
            "llm_provider": provider,
            "sql_model": settings.ollama_sql_model,
            "render_model": settings.ollama_render_model,
        }
    return {"status": "ok", "llm_provider": provider, "model": settings.OPENAI_COMPAT_MODEL}


# ── A2A ───────────────────────────────────────────────────────────────────────
from a2a.types import (
    AgentCapabilities,
    AgentCard,
    AgentSkill,
    TransportProtocol,
    DataPart
)

"""
@app.post("/a2a")
def a2a_request():
    return {"SUCCESS": True}

"""

"""
@app.get("/.well-known/agent-card.json", response_model=AgentCard)
def agent_card():
    return A2A_AGENT.agent_card
   """ 


"""
@app.post("/tasks/send", response_model=Task, dependencies=[Depends(_require_api_key)])
def tasks_send(req: TaskSendRequest):
    text_parts = [p for p in req.message.parts if p.type == "text"]

    if not text_parts or not text_parts[0].text.strip():
        return Task(
            id=req.id,
            status=TaskStatus(state=TaskState.FAILED),
            artifacts=[Artifact(
                name="error",
                parts=[TextPart(text="Message must contain a non-empty text part.")],
            )],
        )

    result = pipeline.run(text_parts[0].text.strip())

    return Task(
        id=req.id,
        status=TaskStatus(state=TaskState.COMPLETED if result.success else TaskState.FAILED),
        artifacts=[Artifact(
            name="answer",
            parts=[TextPart(text=result.answer)],
        )],
        metadata={
            "sql": result.sql,
            "row_count": result.row_count,
            "attempts": result.attempts,
            "error": result.error,
        },
    )
"""

# ── v2: Multi-agent + MCP ─────────────────────────────────────────────────────

class V2QueryResponse(BaseModel):
    success: bool
    answer: str
    sql: str
    row_count: int
    attempts: int
    error: str
    trace: list[str]


@app.post("/v2/query", response_model=V2QueryResponse, tags=["v2 multi-agent"], dependencies=[Depends(_require_api_key)])
async def v2_query(req: QueryRequest):
    """
    Multi-agent Text-to-SQL endpoint.

    Runs the OrchestratorAgent which coordinates:
    - SchemaAgent     (MCP → schema_server.py → Qdrant)
    - SQLAgent        (LLM Codestral + MCP → database_server.py)
    - ExecutorAgent   (MCP → database_server.py → MariaDB)
    - RendererAgent   (LLM Mistral)

    Returns the full agent execution trace for observability.
    """

    logger.info(f"v2_query: {req.question!r}")

    if not req.question.strip():
        raise HTTPException(status_code=400, detail="question cannot be empty")
    if orchestrator is None:
        raise HTTPException(status_code=501, detail="v2 multi-agent orchestrator not available")
    result = await orchestrator.run(req.question)
    return V2QueryResponse(
        success   = result.success,
        answer    = result.answer,
        sql       = result.sql,
        row_count = result.row_count,
        attempts  = result.attempts,
        error     = result.error,
        trace     = result.trace,
    )

"""
@app.post("/v2/tasks/send", response_model=Task, tags=["v2 multi-agent"], dependencies=[Depends(_require_api_key)])
async def v2_tasks_send(req: TaskSendRequest):
    # A2A task endpoint backed by the multi-agent orchestrator.
    if orchestrator is None:
        raise HTTPException(status_code=501, detail="v2 multi-agent orchestrator not available")

    text_parts = [p for p in req.message.parts if p.type == "text"]

    if not text_parts or not text_parts[0].text.strip():
        return Task(
            id=req.id,
            status=TaskStatus(state=TaskState.FAILED),
            artifacts=[Artifact(
                name="error",
                parts=[TextPart(text="Message must contain a non-empty text part.")],
            )],
        )

    result = await orchestrator.run(text_parts[0].text.strip())

    return Task(
        id=req.id,
        status=TaskStatus(state=TaskState.COMPLETED if result.success else TaskState.FAILED),
        artifacts=[Artifact(
            name="answer",
            parts=[TextPart(text=result.answer)],
        )],
        metadata={
            "sql":       result.sql,
            "row_count": result.row_count,
            "attempts":  result.attempts,
            "error":     result.error,
            "trace":     result.trace,
        },
    )
"""
