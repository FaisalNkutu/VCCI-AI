"""
Schema ingestion script — run ONCE before starting the agent.

Usage:
    python ingest.py path/to/schema.sql

What it does:
    1. Parses all CREATE TABLE statements from the SQL file
    2. Merges structure with the existing, already-rich KB_full.json
       (label, description, keywords, columns, primary_key, relationships,
       domain, sample_queries — see RAG/ offline generation scripts)
    3. Builds a rich text description for each table (columns, types, constraints, FKs)
    4. Embeds each description locally (fastembed, no external API)
    5. Upserts into Qdrant

Re-running recreates the collection (safe to run multiple times).

--- v3 (enriched KB: 6 733 sample queries, 54 kinds) ---
The KB now mixes THREE families that must not be treated alike:
  * answerable queries      -> valid SQL returning rows      (indexable)
  * "No Results Found"      -> valid SQL returning NOTHING   (evaluation only)
  * "Invalid/Unsupported"   -> fails at execution, or has NO sql at all,
                               and includes DELETE statements written on
                               purpose to exercise read-only guardrails
Only the first family reaches the Qdrant payload, via
retrieval_safe_sample_queries(). This matters here specifically because
schema_rag.best_sample_query() reads payload["sample_queries"] and
pipeline.py executes the match VERBATIM: an unfiltered payload would put
a DELETE one lexical match away from the database. The run also prints a
query profile so a KB regression is visible at ingestion time rather than
as a silent retrieval-quality drop weeks later.

--- v2.2 (single KB path) ---
One and only one knowledge base file: RAG/KB_full_update2.json. It is the
INPUT of every run, and the OUTPUT only when reconciliation actually
changed something (new tables scaffolded, removed tables pruned, or
--domain/--desc overrides applied). In the steady state — complete KB,
stable schema, no overrides — ingestion is read-only on the KB: the file
is read, Qdrant is written, the reference file is not touched. The separate KB_full.json output and its
accumulating timestamped .bak.json copies are gone. Consequences:
  - the file is self-completing: tables present in the SQL but missing
    from the KB are scaffolded and PERSISTED back into the same file, so
    the first full-schema run fills the KB up to the SQL's table count;
  - single rotating backup (KB_full_update2.bak.json, overwritten each
    run) kept as the only safety net -- an in-place write on the sole
    copy would otherwise be destroyed by a crash mid-write or a wrong
    SQL file combined with --allow-mass-delete. Delete the marked block
    in ingest() to remove even that.
  - IMPORTANT companion change: RAG/knowledge_base.py's KB_PATH must
    point to the same file (KB_full_update2.json), or the pipeline's DDL
    builder will read a different KB than the one being maintained here.

--- v2.1 (KB_full_update.json v2 compatibility pass) ---
ingest.py delegates all format-sensitive work (embedding text, KB entry
access) to RAG/knowledge_base.py, so the v2 KB format (dict sample_queries,
dict allowed_values, composite keys) is absorbed there, not here. Two fixes
land in THIS file:

  1. reconcile_data() now deep-copies each KB entry before mutating it.
     get_table_kb_from_d() returns the LIVE object from kb_full_in — which
     is the very dict cached by knowledge_base.load_kb()'s lru_cache. The
     previous code mutated it in place (pop/setdefault/column writes) and
     assigned that same live object into kb_full_out, which (a) corrupted
     the in-process KB cache for any later call in the same session (the
     Streamlit case exactly), and (b) silently bypassed the deepcopy of
     kb_full_out for every already-existing table.

  2. (companion fix in knowledge_base.py v2.1.1, not here, but required
     for correct v2 ingestion) table_embedding_tokens() now emits sample
     questions and related tables BEFORE the column/enum blocks and caps
     enum value lists at 12 in the embedding text — with the v2 KB, a
     single column like obj_item_stat.country_code (~200 decoded values)
     exceeded fastembed's ~512-token window on its own, silently
     truncating the sample questions (the strongest retrieval signal)
     out of every large table's embedding.

--- Updated for the new KB_full.json schema (knowledge_base.py) ---
The legacy flat "referenced_by": ["table.column", ...] field is replaced by
"relationships": [{role, name, type, related_table, cardinality, join_on}, ...].

--- HTML parsing removed ---
The old --html pipeline (extract_keys_from_html, deriving primary keys /
foreign keys / referenced_by from the DeZign HTML export at ingest time) has
been removed. KB_full.json is now built and enriched OFFLINE, once, by the
dedicated RAG/ generation scripts (schema extraction, relationships,
descriptions, keywords, domains, sample_queries) and merged via
RAG/kb_full_update.py. ingest.py's job is simply to trust that already-rich
KB as the source of truth for label/description/columns/primary_key/
relationships/domain/keywords/sample_queries, and to match it up against
whatever tables currently exist in the SQL schema file — it no longer
re-derives any of that metadata itself.
"""

import sys
import argparse
from pathlib import Path
import copy
import shutil
import uuid
from datetime import datetime
import sqlglot
from sqlglot import exp
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct, PointIdsList, PayloadSchemaType
from config.settings import get_settings

settings = get_settings()
from agent.embedder import Embedder


import json 

from RAG.knowledge_base import table_embedding_tokens
from RAG.knowledge_base import table_embedding_payload
from RAG.knowledge_base import load_kb as load_kb
from RAG.knowledge_base import get_table_kb_from_d as get_table_kb_from_d
from RAG.knowledge_base import is_excluded_table
from RAG.knowledge_base import KB_PATH as RUNTIME_KB_PATH
# v3 (enriched KB): only the answerable queries may reach Qdrant.
from RAG.knowledge_base import retrieval_safe_sample_queries, query_profile_from_entry
from RAG.data_catalog_builder import load_json as load_json
from RAG.data_catalog_builder import save_json as save_json

# The one and only knowledge base file — read as input at the start of
# each run, written back (reconciled/enriched) at the end. No separate
# output file, no accumulating timestamped backups. Kept as a single
# constant so the CLI (--kb default), programmatic callers
# (ingest_from_sql_file) and the in-place write all resolve to the same
# file. RAG/knowledge_base.py's KB_PATH must point to this same file.
# Keep command-line defaults and Streamlit ingestion aligned with the runtime
# KB selected through KB_FILE in .env.  A caller may still explicitly pass
# --kb to test a different file deliberately.
KB_PATH = str(RUNTIME_KB_PATH)

# Safety threshold for the "remove tables no longer in the SQL" step: if
# more than this fraction of the existing KB's tables would be deleted in
# one run, abort instead of silently wiping out most of the KB — most
# likely caused by pointing --kb at the wrong/an incomplete SQL file.
MAX_DELETE_FRACTION = 0.30



sys.path.insert(0,"neo4j/neo4j-server")
from import_data import import_neo4j_database_file
from export_data import export_neo4j_database_file


# ── Schema parser ─────────────────────────────────────────────────────────────
def _col_constraints(node: exp.ColumnDef) -> list[str]:
    parts = []
    for c in node.constraints:
        k = c.kind
        if isinstance(k, exp.NotNullColumnConstraint):
            parts.append("NOT NULL")
        elif isinstance(k, exp.PrimaryKeyColumnConstraint):
            parts.append("PRIMARY KEY")
        elif isinstance(k, exp.UniqueColumnConstraint):
            parts.append("UNIQUE")
        elif isinstance(k, exp.AutoIncrementColumnConstraint):
            parts.append("AUTO_INCREMENT")
        elif isinstance(k, exp.DefaultColumnConstraint):
            try:
                parts.append(f"DEFAULT {k.this.sql('mysql')}")
            except Exception:
                pass
        elif isinstance(k, exp.CommentColumnConstraint):
            try:
                parts.append(f"-- {k.this.name}")
            except Exception:
                pass
        elif isinstance(k, exp.CheckColumnConstraint):
            try:
                parts.append(f"CHECK({k.this.sql('mysql')})")
            except Exception:
                pass
    return parts


def parse_sql_to_documents(sql_content: str) -> list[dict]:
    """
    Pure SQL parsing — no KB lookups here. "domain" and "column_knowledge"
    are filled in later by reconcile_data(), from kb_full_out (the already-
    rich, offline-generated KB), not re-derived here.
    """
    documents = []

    try:
        statements = sqlglot.parse(sql_content, dialect="mysql")
    except Exception as e:
        print(f"[ingest] sqlglot warning: {e}")
        return []

    for stmt in statements:
        if not isinstance(stmt, exp.Create):
            continue
        kind = stmt.args.get("kind")
        kind_str = kind.name if hasattr(kind, "name") else kind
        if not kind or kind_str != "TABLE":
            continue

        schema_node = stmt.this
        if not isinstance(schema_node, exp.Schema):
            continue

        table_name = schema_node.this.name
        col_lines, fk_lines, idx_lines = [], [], []
        structured_cols: list[dict] = []

        for node in schema_node.expressions:
            if isinstance(node, exp.ColumnDef):
                if not node.name or node.name.upper().startswith("IDX_"):
                    print(f"[ingest][warning] suspicious column in {table_name}: {node.name}")
                    continue
                col_type = node.kind.sql("mysql") if node.kind else "UNKNOWN"
                constraints = _col_constraints(node)
                nullable = (
                    "NO" if ("NOT NULL" in constraints or "PRIMARY KEY" in constraints)
                    else "YES"
                )

                structured_cols.append({
                    "name": node.name,
                    "type": col_type,
                    "nullable": nullable,
                })

                line = f"  - {node.name} {col_type}"
                if constraints:
                    line += "  [" + ", ".join(constraints) + "]"
                col_lines.append(line)

            elif isinstance(node, exp.ForeignKey):
                # Kept purely for the human-readable description text below
                # (not used to build KB relationships anymore — those come
                # from the already-rich KB_full.json).
                fk_cols = [c.name for c in node.expressions]
                ref = node.args.get("reference")
                if ref:
                    try:
                        ref_table = ref.this.name
                        ref_cols  = [c.name for c in ref.expressions]
                        fk_lines.append(
                            f"  - ({', '.join(fk_cols)}) -> {ref_table}({', '.join(ref_cols)})"
                        )
                    except Exception:
                        pass

            elif isinstance(node, exp.Index):
                try:
                    idx_cols = [c.name for c in node.expressions]
                    idx_lines.append(f"  - INDEX({', '.join(idx_cols)})")
                except Exception:
                    pass

        parts = [f"Table: {table_name}"]
        if col_lines:
            parts.append("Columns:")
            parts.extend(col_lines)
        if fk_lines:
            parts.append("Foreign keys:")
            parts.extend(fk_lines)
        if idx_lines:
            parts.append("Indexes:")
            parts.extend(idx_lines)

        documents.append({
             "table":            table_name,
             "description":      "\n".join(parts),
             "domain":           [],   # filled in by reconcile_data() from kb_full_out
             "columns":          structured_cols,
             "relationships":    [],   # filled in by reconcile_data() from kb_full_out -- stored
                                        # as-is (structured dicts), never flattened to text.
                                        # build_ddl_with_kb() renders it for the DDL comment,
                                        # schema_rag.py consumes it directly for FK-expansion
                                        # and JOIN hints -- no string parsing anywhere.
             "primary_key":      "",   # filled in by reconcile_data() from kb_full_out
             "column_knowledge": {},   # filled in by reconcile_data() from kb_full_out
             "sample_queries": [],     # filled in by reconcile_data() from kb_full_out
         })

    return documents


#
#   save_intermediates_kb()
#       save the KB_full.json in 1 file per table.
#       We need this because the KB_full is absolutely "undiffable"
#       a 1st version will be saved and from there we can track the changes
#
#  _table_point_id()
#
#      Stable, deterministic Qdrant point id derived from the table name
#      (uuid5 with a fixed namespace), NOT a loop index. The same table
#      name always maps to the same point id across runs, regardless of
#      what else is or isn't in that particular run's document set --
#      required for both the upsert step (re-ingesting "act" must update
#      "act"'s own point) and the orphan-pruning step below (must be able
#      to compute a removed table's id without it being in `documents`
#      anymore).
#
def _table_point_id(table_name: str) -> str:
    return str(uuid.uuid5(uuid.NAMESPACE_DNS, f"reqa-sql-table:{table_name}"))








def save_intermediates_kb( kb_full, folder ):
    for key, val in kb_full.items():
        base_path = Path(folder)
        fname = base_path / f"kb_{key}.json"
        save_json( val, fname )


#===============================================================================================================================
#
#   reconcile_data(documents, kb_full_out, **kwargs)
#
#       Matches the tables parsed from the SQL file against the already-rich
#       KB_full.json (kb_full_in). For each table:
#         - if it already exists in the KB, its curated metadata (label,
#           description, keywords, columns, primary_key, relationships,
#           domain, sample_queries) is trusted as-is and simply carried
#           over into kb_full_out.
#         - if it's genuinely new (not in the KB yet), a minimal scaffold
#           entry is created from the SQL structure alone, to be enriched
#           later by the offline RAG/ generation scripts.
#       Tables present in the KB but no longer in the SQL file are dropped.
#
#       **kwargs:
#                kb_full_in   # the existing KB_full.json to reconcile against
#                domain_map   # optional Domain_map.json override
#                descriptions # optional all_tables_descriptions.json override
#
#================================================================================================================================
def reconcile_data(documents, kb_full_out, **kwargs):

    new_tables = []
    kb_full_in = kwargs.get('kb_full_in', {})
    domain_map = kwargs.get('domain_map', {})
    descriptions = kwargs.get('descriptions', {})
    allow_mass_delete = kwargs.get('allow_mass_delete', False)

    all_docs_keys = []

    for i, doc in enumerate(documents):
        table_name = doc["table"]
        all_docs_keys.append( table_name  )
        print(f" === reconcile data for table `{table_name}` === ")

        # v2.1 FIX: deep-copy the entry before any mutation.
        # get_table_kb_from_d() returns the LIVE dict from kb_full_in for
        # existing tables — and kb_full_in is the very object cached by
        # knowledge_base.load_kb()'s lru_cache. Mutating it in place (the
        # pop/setdefault/column writes below) corrupted the in-process KB
        # cache for any later call in the same session (Streamlit), and
        # assigning the live object into kb_full_out silently bypassed the
        # deepcopy for every already-existing table.
        kbfull_entry = copy.deepcopy( get_table_kb_from_d( kb_full_in, table_name ) )
        # defensive migration: drop any stale legacy field from an
        # older-schema KB entry that might still be lying around
        kbfull_entry.pop("referenced_by", None)

        if is_excluded_table( table_name ):
            print( f"SKIP  `{table_name}` -- because its a metrics table" )  
            continue

        if len(kbfull_entry['label']) == 0:
            print(f"NEW TABLE  `{table_name}` -- not yet in KB_full.json, scaffolding a minimal entry")
            new_tables.append( table_name  )
            kbfull_entry["label"] = table_name.replace("_", " ")
            kbfull_entry["description"] = kbfull_entry["label"]
            kbfull_entry.setdefault("keywords", [])
            kbfull_entry.setdefault("domain", [])
            kbfull_entry.setdefault("relationships", [])
            kbfull_entry.setdefault("primary_key", "")
            for column in doc["columns"]:
                col_name = column["name"]
                col_desc = col_name.replace("_", " ")
                kbfull_entry["columns"][col_name] = {
                    "data_type": column.get("type", ""),
                    "description": col_desc,
                }
        # else: table already fully documented by the offline generation
        # scripts -- trust it as-is, nothing to rebuild here.

        # optional overrides, only applied if explicitly supplied
        if table_name in domain_map:
            kbfull_entry["domain"] = domain_map[table_name]
        if table_name in descriptions:
            kbfull_entry["description"] = descriptions[table_name]

        # Relationships are stored exactly as they come from the KB --
        # structured dicts, never flattened to text. This is the single
        # source of truth consumed both by build_ddl_with_kb() (DDL comment
        # rendering) and schema_rag.py (FK-expansion, JOIN hints), so there
        # is no intermediate string format that can drift out of sync or
        # break silently on a formatting change.
        doc["relationships"] = kbfull_entry.get("relationships", [])
        doc["primary_key"] = kbfull_entry.get("primary_key", "")

        # Enrich the document with domain and column knowledge straight
        # from the (trusted) KB entry, for the embedding text.
        doc["domain"] = kbfull_entry.get("domain", [])
        doc["column_knowledge"] = kbfull_entry.get("columns", {})

        # sample_queries were previously only ever consumed via
        # table_embedding_tokens() (folded into the embedding text) and via
        # a fresh KB lookup at DDL-build time (build_ddl_with_kb's few-shot
        # section) -- they were never actually part of the Qdrant payload
        # itself. That meant nothing downstream that only has `payload` in
        # hand (the reranker, schema_rag's own retrieval-time matching) could
        # see them at all. Stored here so they're available wherever the
        # payload is, not just via a second KB round-trip.
        # v2 note: these are now {question, sql, level, kind} dicts, which
        # serialize cleanly into the Qdrant payload as-is.
        # v3: NO LONGER as-is. The enriched KB mixes answerable queries with
        # "No Results Found" (valid SQL, answers nothing), "Invalid/
        # Unsupported" (fails at execution, includes DELETE statements) and
        # entries whose sql is None. They stay in the KB file -- they are the
        # evaluation set -- but must not be indexed: schema_rag's
        # best_sample_query() reads this payload and pipeline.py executes the
        # match verbatim.
        doc["sample_queries"] = retrieval_safe_sample_queries(kbfull_entry)

        kb_full_out[table_name] = kbfull_entry

    #
    #   Remove the (old) tables that are in KB_full and not in the SQL.
    #   Safety check first: if this run would wipe out a large fraction of
    #   the existing KB, it's much more likely --kb points at the wrong
    #   file, or sql_file is an incomplete/partial schema dump, than a
    #   genuine mass table removal. Abort loudly instead of silently
    #   deleting most of the KB (use --allow-mass-delete to override).
    #
    existing_count = len(kb_full_out)
    keys_to_remove = [key for key in kb_full_out if key not in all_docs_keys]

    if existing_count > 0 and keys_to_remove:
        delete_fraction = len(keys_to_remove) / existing_count
        if delete_fraction > MAX_DELETE_FRACTION and not allow_mass_delete:
            raise RuntimeError(
                f"[ingest] SAFETY ABORT: this run would remove {len(keys_to_remove)}/{existing_count} "
                f"tables ({delete_fraction:.0%}) from the KB — well above the {MAX_DELETE_FRACTION:.0%} "
                f"safety threshold. This usually means --kb points at the wrong file, or sql_file is an "
                f"incomplete schema dump, not a genuine mass table removal.\n"
                f"Tables that would be removed: {keys_to_remove}\n"
                f"If this is really intended, re-run with --allow-mass-delete."
            )

    print( f"REMOVE these tables from the KB {keys_to_remove}" )
    for key in keys_to_remove:
        del kb_full_out[key]

    return documents, kb_full_out, new_tables, keys_to_remove


# --- Ingestion -----------------------------------------------------------------
def ingest(args: argparse.Namespace, force_reindex: bool = False) -> None:

    # mandatory sql file
    sql_file = args.sql_file

    # Resolve --kb explicitly against the shared constant, so a caller
    # passing kb=None (or omitting it) always gets the same file as the
    # CLI default — see ingest_from_sql_file() for the bug this avoids.
    kb_path = args.kb or KB_PATH
    kb_full_in = load_kb(kb_path)

    domain_map_in = {}
    descriptions_in = {}

    kb_full_out = copy.deepcopy( kb_full_in )

    if args.domain is not None:
        domain_map_in = load_json( args.domain )
    if args.desc is not None:
        descriptions_in = load_json( args.desc )

    # v3: report what the KB actually contributes vs what is indexable, so a
    # KB regression (a regenerated file with no answerable query left for
    # some table) is visible HERE rather than as a silent retrieval-quality
    # drop weeks later. Only the "positive" family is embedded and indexed.
    _prof = {"positive": 0, "empty": 0, "invalid": 0, "unanswerable": 0}
    _no_positive = []
    for _t, _e in kb_full_in.items():
        _p = query_profile_from_entry(_e)
        for _k in _prof:
            _prof[_k] += _p.get(_k, 0)
        if not _p.get("positive"):
            _no_positive.append(_t)
    print(f"[ingest] KB query profile: {_prof['positive']} indexable, "
          f"{_prof['empty']} empty-result, {_prof['invalid']} invalid, "
          f"{_prof['unanswerable']} without SQL -- only the first family is indexed")
    if _no_positive:
        print(f"[ingest][warn] {len(_no_positive)} table(s) with NO usable sample "
              f"query: {_no_positive[:10]}")

    all_table_names = list(kb_full_out.keys())
    print( f"=================================== KB_full {len(all_table_names)} Tables ==============================================")
    print( f"{[*kb_full_out]}" )
    print( f"===========================================================================================================")

    sql_content = Path(sql_file).read_text(encoding="utf-8")
    documents = parse_sql_to_documents(sql_content)

    if not documents:
        print("[ingest] No CREATE TABLE statements found -- check your SQL file.")
        sys.exit(1)

    #
    # reconcile the SQL-parsed tables against the already-rich KB
    #
    documents, kb_full_out, new_tables, keys_to_remove = reconcile_data( documents, kb_full_out,
                               kb_full_in=kb_full_in,
                               domain_map = domain_map_in,
                               descriptions = descriptions_in,
                               allow_mass_delete = getattr(args, "allow_mass_delete", False) )

    # Write back ONLY when reconciliation actually changed something:
    # scaffolded new tables, pruned removed ones, or applied --domain/
    # --desc overrides. In the steady state (complete KB, stable schema,
    # no overrides) the reconciled output is identical to the input and
    # rewriting it would be a pointless touch of the reference file —
    # ingestion is then a pure read-only consumer of the KB: it reads the
    # file, writes Qdrant, and leaves the reference alone.
    kb_changed = bool(new_tables or keys_to_remove or domain_map_in or descriptions_in)

    if kb_changed:
        # Single rotating backup first (overwritten each run, never
        # accumulates): the write below replaces the sole copy of the KB,
        # so without this, a crash mid-write or a wrong SQL file combined
        # with --allow-mass-delete would destroy it with no way back.
        out_path = Path(kb_path)
        if out_path.exists():
            shutil.copy2(out_path, out_path.with_suffix(".bak.json"))
            print(f"[ingest] Rotating backup written to {out_path.with_suffix('.bak.json')}")

        save_intermediates_kb( kb_full_out, "RAG/intermediate" )
        save_json( kb_full_out, kb_path )
        print(f"[ingest] KB updated in place: {kb_path} ({len(kb_full_out)} tables, "
              f"{len(new_tables)} scaffolded, {len(keys_to_remove)} pruned)")

        # The in-process cache now holds the PRE-run KB — clear it so any
        # later call in the same session (Streamlit) reloads the fresh file.
        load_kb.cache_clear()
    else:
        print(f"[ingest] KB unchanged ({len(kb_full_out)} tables) -- nothing written.")

    print(f"{len(new_tables)} NEW TABLES")
    for table in new_tables:
        print(table)

    table_names = [d["table"] for d in documents]
    print(f"[ingest] Parsed {len(documents)} tables: {table_names}")

    if getattr(args, "payload_debug", False):
        debug_doc = documents[0]
        debug_entry = kb_full_out.get(debug_doc["table"], {})
        debug_payload = table_embedding_payload(
            debug_doc["table"],
            debug_doc["description"],
            kb_entry=debug_entry,
            strip_enums=args.strip_enums,
        )
        kb_relationships = debug_entry.get("relationships") or []
        kb_primary_key = debug_entry.get("primary_key") or ""
        kb_columns = debug_entry.get("columns") or {}
        missing = [
            field for field in ("relationships", "primary_key", "column_knowledge")
            if field not in debug_payload
        ]
        print(
            "\n================ KB -> QDRANT PAYLOAD DEBUG ================\n"
            f"TABLE: {debug_doc['table']}\n"
            f"KB relationships: {len(kb_relationships)}\n"
            f"KB primary_key present: {bool(kb_primary_key)}\n"
            f"KB column metadata fields: {len(kb_columns)}\n"
            f"Qdrant payload keys: {sorted(debug_payload.keys())}\n"
            f"Qdrant relationships present: {'relationships' in debug_payload}\n"
            f"Qdrant primary_key present: {'primary_key' in debug_payload}\n"
            f"Qdrant column_knowledge present: {'column_knowledge' in debug_payload}\n"
            f"MISSING FROM Qdrant PAYLOAD: {missing}\n"
            "No embedding model loaded; Qdrant was not changed.\n"
            "============================================================\n"
        )
        return

    print("[ingest] Loading embedding model (first run downloads ~130 MB)...")
    embedder = Embedder()

    client = QdrantClient(host=settings.QDRANT_HOST, port=settings.QDRANT_PORT)

    # Sample query generation is intentionally NOT run here -- it blocks for
    # several minutes on large schemas. Use the dedicated Streamlit button
    # "Generate Sample Queries" or call generate_all_missing_sample_queries()
    # directly after ingestion.

    if not args.dry:
        # force_reindex distinguishes the two modes exposed by the
        # Streamlit UI's "Index" vs "Re-index" buttons -- previously this
        # parameter was accepted but never actually read here, so the
        # collection was unconditionally dropped and recreated on EVERY
        # call regardless of which button was clicked, making the two
        # buttons behave identically (always fully destructive).
        #
        # Now: "Re-index" (force_reindex=True) always wipes and rebuilds
        # from scratch, as its label promises. "Index" (force_reindex=
        # False) reuses the existing collection if one is already present
        # -- points for the tables in this run are upserted (by id) into
        # it rather than the whole collection being destroyed -- and only
        # creates a fresh collection if none exists yet.
        collection_exists = client.collection_exists(settings.QDRANT_COLLECTION)
        if force_reindex or not collection_exists:
            if collection_exists:
                client.delete_collection(settings.QDRANT_COLLECTION)
            # Read DIMENSION from the actual `embedder` instance, not the
            # Embedder class. The class attribute is only a fallback for the
            # __init__ now resolves the real
            # dimension for whatever model string was actually passed in and
            # stores it as an instance attribute. Reading the class attribute
            # here would silently create a Qdrant collection sized for the
            # WRONG vector length the moment anyone swaps to a different model
          
            
            
            client.create_collection(
                collection_name=settings.QDRANT_COLLECTION,
                vectors_config=VectorParams(size=embedder.DIMENSION, distance=Distance.COSINE),
            )


            client.create_payload_index(
                collection_name=settings.QDRANT_COLLECTION,
                field_name="category",
                field_schema=PayloadSchemaType.KEYWORD,
                )


            


            print(f"[ingest] Qdrant collection '{settings.QDRANT_COLLECTION}' (re)created.")
        else:
            print(f"[ingest] Qdrant collection '{settings.QDRANT_COLLECTION}' already exists "
                  f"-- upserting into it (pass recreate_collection=True / use 'Re-index' to rebuild from scratch).")

            # Keep the Qdrant collection consistent with KB_full.json's own
            # pruning: reconcile_data() already removes tables no longer
            # present in the current SQL from the KB file, but the
            # non-destructive "Index" path above only upserts the CURRENT
            # tables -- it never touched points for tables that disappeared
            # from a PREVIOUS, larger ingest run. Without this, indexing
            # "Full" then "Minimal" (via Index, not Re-index) would leave
            # "Full"-only tables as orphaned points, still retrievable by
            # schema_rag even though they'd already been pruned from
            # KB_full_update.json -- the two stores silently diverging.
            # Verified end-to-end: without this block, indexing Full (3
            # tables) then Minimal (1 table) via Index left all 3 tables'
            # points in Qdrant; with it, only the 1 current table remains.
            if keys_to_remove:
                orphan_ids = [_table_point_id(t) for t in keys_to_remove]
                client.delete(
                    collection_name=settings.QDRANT_COLLECTION,
                    points_selector=PointIdsList(points=orphan_ids),
                )
                print(f"[ingest] Pruned {len(orphan_ids)} orphaned Qdrant point(s) "
                      f"for table(s) no longer in the SQL: {keys_to_remove}")

    points = []
    payload_debug_printed = False
    if args.no_tables == False:
        for doc in documents:        
            # Pass the already-reconciled KB entry directly (kb_full_out was
            # just built/saved above) instead of letting table_embedding_tokens
            # re-fetch it from disk internally -- avoids a redundant read and
            # removes the implicit "save must happen before this loop" coupling.
            kb_entry = kb_full_out.get(doc["table"], {})
            embedding_text = table_embedding_tokens(doc["table"], doc["description"], kb_entry=kb_entry)
            vector = embedder.embed(embedding_text)
            qdrant_payload_doc = table_embedding_payload(doc["table"], doc["description"], kb_entry=kb_entry, strip_enums=False)
            if args.verbose:
                print( "\n===================== EMBEDDING_TEXT ========\n"
                        + str(embedding_text) )
                print( "\n===================== PAYLOAD ================\n"
                + str(doc) )
                if not payload_debug_printed:
                    kb_fields = {
                        "relationships": kb_entry.get("relationships") or [],
                        "primary_key": kb_entry.get("primary_key") or "",
                        "column_metadata": kb_entry.get("columns") or {},
                    }
                    payload_fields = sorted(qdrant_payload_doc.keys())
                    omitted = [
                        field for field in ("relationships", "primary_key", "column_knowledge")
                        if field not in qdrant_payload_doc
                    ]
                    print(
                        "\n================ KB -> QDRANT PAYLOAD DEBUG ================\n"
                        f"TABLE: {doc['table']}\n"
                        f"KB relationships: {len(kb_fields['relationships'])}\n"
                        f"KB primary_key present: {bool(kb_fields['primary_key'])}\n"
                        f"KB column metadata fields: {len(kb_fields['column_metadata'])}\n"
                        f"Qdrant payload keys: {payload_fields}\n"
                        f"Qdrant relationships present: {'relationships' in qdrant_payload_doc}\n"
                        f"Qdrant primary_key present: {'primary_key' in qdrant_payload_doc}\n"
                        f"Qdrant column_knowledge present: {'column_knowledge' in qdrant_payload_doc}\n"
                        f"MISSING FROM Qdrant PAYLOAD: {omitted}\n"
                        "============================================================\n"
                    )
                    payload_debug_printed = True

            point_id = _table_point_id(doc['table'])

            points.append(PointStruct(id=point_id, vector=vector, payload=qdrant_payload_doc))
            #print(f"[ingest] {doc['table']}  id={point_id}")

        if args.dry:
            print(f"[ingest] {len(points)} SKIPPED (Dry Run).")
        else:
            client.upsert(collection_name=settings.QDRANT_COLLECTION, points=points)
            print(f"[ingest] {len(points)} table schemas ingested into Qdrant (KB-enriched embeddings).")
        # print(f"[ingest] points={points}")





def ingest_from_sql_file(sql_file: str, force_reindex: bool = False, allow_mass_delete: bool = False) -> None:
    """
    Programmatic wrapper for use by Streamlit or other callers.
    Avoids the argparse.Namespace requirement of ingest().

    Uses KB_PATH explicitly (same default as the CLI's --kb argument)
    rather than kb=None — passing None here used to silently fall through
    to knowledge_base.py's own default, a *different* file than the CLI
    default, causing Streamlit-triggered ingests to read from the wrong
    KB without any warning. Both now point to the same single file.

    allow_mass_delete: explicit opt-in override for the mass-deletion
    safety check in reconcile_data(). Since kb_full_in is always reloaded
    fresh from the KB file (the full curated reference), not from
    whatever a *previous* ingest run just indexed, a dataset that
    legitimately has fewer TABLES than the reference (not just fewer rows
    of data) will look, from pure table-count arithmetic, identical to
    someone having pointed --kb at the wrong file or supplied an
    incomplete SQL dump by accident -- the two cases are indistinguishable
    without knowing the intent. Exposed as an explicit, opt-in checkbox in
    the Streamlit UI (rather than silently allowed or silently blocked)
    so the person indexing a smaller dataset makes that call deliberately,
    not by having the safety guard silently overridden or a legitimate
    smaller dataset silently rejected.
    """
    ns = argparse.Namespace(
        sql_file=sql_file,
        kb=KB_PATH,
        domain=None,
        desc=None,
        dry=False,
        verbose=False,
        allow_mass_delete=allow_mass_delete,
        strip_enums=False,
        reindex=recreate_collection
    )
    ingest(ns, force_reindex=force_reindex)



def get_ingest_parser():
    parser = argparse.ArgumentParser(description="Ingest SQL schema into Qdrant. output is fixed to RAG/ directory, "
                                                  "where the program will use the modified files. --kb optional")
    parser.add_argument("sql_file", help="Path to your .sql schema file")   
    parser.add_argument("--kb", default=settings.KB_FILE, help="Path to THE knowledge base file (read as input, written back in place at the end of the run)")
    parser.add_argument("--domain", help="Path to Domain_map.json. optional override, will merge into KB_full.json")
    parser.add_argument("--desc", help="Path to all_tables_descriptions.json. optional override, will merge into KB_full.json")    
    parser.add_argument('--dry', action='store_true', help="Do not ingest, just dry run")
    parser.add_argument('--no-tables', action='store_true', help="Do not ingest tables. (only RR)")
    
   

    parser.add_argument('--verbose', action='store_true', help="More Print Verbosity")
    parser.add_argument('--payload-debug', dest='payload_debug', action='store_true',
                        help="Print KB versus Qdrant payload fields without loading embeddings or writing Qdrant")
    parser.add_argument('--allow-mass-delete', dest='allow_mass_delete', action='store_true',   
                         help=f"Override the safety abort that triggers when a run would remove more than "
                              f"{int(MAX_DELETE_FRACTION*100)}% of the existing KB's tables.")
    parser.add_argument('--strip_enums', action='store_true', help="Strip enum values from ddl inserted in qdrant")
    parser.add_argument('--reindex', action='store_true', help="Force to recreate the qdrant collection")


    parser.add_argument('--neo4j-database-file',  default="full_database_export.json", help="File name to Import neo4j data (no path supported, must be inside neo4j import folder)")
    parser.add_argument('--neo4j-import', action='store_true', help="Import the neo4j database file to populate the neo4j graph")
    parser.add_argument('--neo4j-export', action='store_true', help="Import the neo4j database file to populate the neo4j graph")

    return parser
    



# python ingest.py RAG/input/calian_nodata.sql --kb=RAG/KB_full_update.json --domain=RAG/input/Domain_map.json --verbose
if __name__ == "__main__":
    

    parser = get_ingest_parser()

    args = parser.parse_args()    
    print("=========================== INGEST ====================================================")
    print( f"{args}" )


    if args.neo4j_import:
        import_neo4j_database_file( args.neo4j_database_file,  f"{settings.NEO4J_HOST}:{settings.NEO4J_PORT}" , ("neo4j", settings.NEO4J_PASSWORD)  )

    elif args.neo4j_export:
        export_neo4j_database_file( args.neo4j_database_file,  f"{settings.NEO4J_HOST}:{settings.NEO4J_PORT}" , ("neo4j", settings.NEO4J_PASSWORD)  )

    ingest(args, args.reindex)
