"""
General-purpose analyzer for ANY run_eval.py output CSV (any domain, any
table set) -- successor of analyze_blue_tables_eval.py, aware of every
column the harness now produces:

  confidence, score_strict, rag_conf, gen_conf, sem_conf, table_match
  (+ the __GLOBAL__ summary footer row, which is skipped and recomputed)

What it reports:
  1. Per-table pass/quality-fail/outage breakdown with per-table score
  2. Failure taxonomy (static vs DB-level, hallucinated names, syntax, ...)
  3. Confidence panel: mean of every component, over all evaluated
     questions and over passes only
  4. SEMANTIC AUDIT -- the lists that matter for trust:
       a. passed questions whose SQL doesn't reference the target table
       b. passed questions with sem_conf < 1.0 (intent not satisfied)
       c. questions where score and score_strict diverge > 0.25
          (prime false-positive suspects)
  5. A PNG report (per-table bars + failure categories + component means)

Backward compatible: on older CSVs missing the new columns, the related
sections are skipped gracefully instead of crashing.

Usage:
    python analyze_eval.py --input eval_ops_cc_v3.csv
    python analyze_eval.py --input eval.csv --output report.png --top-n 10
"""
import argparse
import csv
from collections import defaultdict

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# ---------------------------------------------------------------------------
# Failure taxonomy
# ---------------------------------------------------------------------------

def categorize_failure(error: str) -> str:
    e = (error or "").lower()
    if ("circuit breaker" in e or "connection refused" in e
            or "httpconnectionpool" in e or "max retries" in e
            or "client timeout" in e):
        return "infra"
    if "unknown column(s)" in e:
        return "static_unknown_column"      # our column validation (pre-DB)
    if "unknown table(s)" in e:
        return "static_unknown_table"       # our table validation (pre-DB)
    if "1054" in e or "unknown column" in e:
        return "db_unknown_column"          # slipped through to MariaDB
    if "doesn't exist" in e or "1146" in e:
        return "db_unknown_table"
    if "not a select" in e:
        return "not_select"
    if "forbidden" in e:
        return "forbidden_keyword"
    if "impossible" in e:
        return "impossible"
    if "parse error" in e or "syntax" in e or "expecting" in e or "tokenizing" in e:
        return "syntax"
    return "other"


CATEGORY_LABELS = {
    "static_unknown_table":  "Unknown table (caught by static check)",
    "static_unknown_column": "Unknown column (caught by static check)",
    "db_unknown_table":      "Unknown table (reached MariaDB)",
    "db_unknown_column":     "Unknown column (reached MariaDB)",
    "syntax":                "SQL syntax error",
    "not_select":            "Not a SELECT",
    "forbidden_keyword":     "Forbidden keyword",
    "impossible":            "LLM declared impossible",
    "other":                 "Other",
}

COLORS = {"passed": "#1baf7a", "quality": "#e34948", "infra": "#898781"}
CAT_COLORS = ["#e34948", "#eb6834", "#eda100", "#4a3aa7", "#2a78d6",
              "#8a4fbe", "#c23b80", "#5b8c5a", "#666666"]


def _f(value):
    """Parse a float cell that may be empty/None/'None'."""
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------

def load(csv_path):
    rows = []
    with open(csv_path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            table = (row.get("table") or "").strip()
            if not table or table == "__GLOBAL__":
                continue
            success = (row.get("success") or "").strip().lower() == "true"
            cat = None if success else categorize_failure(row.get("error", ""))
            rows.append({
                "table": table,
                "question": row.get("question", ""),
                "success": success,
                "category": cat,
                "confidence": _f(row.get("confidence")),
                "score_strict": _f(row.get("score_strict")),
                "rag_conf": _f(row.get("rag_conf")),
                "gen_conf": _f(row.get("gen_conf")),
                "sem_conf": _f(row.get("sem_conf")),
                "table_match": (row.get("table_match") or "").strip().lower() == "true"
                               if row.get("table_match") not in (None, "") else None,
                "sql": row.get("sql", ""),
                "error": row.get("error", ""),
            })
    return rows


# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------

def mean(vals):
    vals = [v for v in vals if v is not None]
    return round(sum(vals) / len(vals), 4) if vals else None


def print_report(rows, top_n=8):
    per_table = defaultdict(lambda: {"p": 0, "q": 0, "i": 0})
    cats = defaultdict(int)
    for r in rows:
        if r["success"]:
            per_table[r["table"]]["p"] += 1
        elif r["category"] == "infra":
            per_table[r["table"]]["i"] += 1
        else:
            per_table[r["table"]]["q"] += 1
            cats[r["category"]] += 1

    total = len(rows)
    passed = sum(1 for r in rows if r["success"])
    infra = sum(1 for r in rows if r["category"] == "infra")
    evaluated = total - infra

    # ----- 1. per-table -----
    print(f"{'table':32} {'pass':>4} {'qual':>4} {'infra':>5} {'tot':>4} {'score':>7}")
    def key(item):
        t, s = item
        tot = sum(s.values())
        return (-(s["p"] / tot if tot else 0), t)
    for t, s in sorted(per_table.items(), key=key):
        tot = sum(s.values())
        print(f"{t:32} {s['p']:>4} {s['q']:>4} {s['i']:>5} {tot:>4} {s['p']/tot*100:>6.1f}%")

    print("-" * 62)
    print(f"raw global score      = {passed}/{total} = {passed/total*100:.1f}%")
    if infra:
        print(f"adjusted global score = {passed}/{evaluated} = {passed/evaluated*100:.1f}%   ({infra} outage questions excluded)")

    # ----- 2. failure taxonomy -----
    if cats:
        print("\nQuality failures by category:")
        for c, n in sorted(cats.items(), key=lambda kv: -kv[1]):
            print(f"  {CATEGORY_LABELS.get(c, c):45} {n}")

    # ----- 3. confidence panel -----
    ev = [r for r in rows if r["category"] != "infra"]
    ok = [r for r in ev if r["success"]]
    print("\nConfidence components (mean over evaluated / over passes only):")
    for field in ("confidence", "score_strict", "rag_conf", "gen_conf", "sem_conf"):
        m_all, m_ok = mean(r[field] for r in ev), mean(r[field] for r in ok)
        if m_all is None:
            print(f"  {field:14} (column absent in this CSV -- older harness version)")
        else:
            print(f"  {field:14} {m_all:>7}   /   {m_ok if m_ok is not None else '-':>7}")

    # ----- 4. semantic audit -----
    print("\n=== SEMANTIC AUDIT ===")
    wrong_table = [r for r in ok if r["table_match"] is False]
    print(f"a. Passed but SQL doesn't reference the target table: {len(wrong_table)}")
    for r in wrong_table[:top_n]:
        print(f"   - {r['table']:25} {r['question'][:55]}")
        print(f"     SQL: {r['sql'][:90]}")

    low_sem = [r for r in ok if r["sem_conf"] is not None and r["sem_conf"] < 1.0]
    print(f"b. Passed with sem_conf < 1.0 (intent not fully satisfied): {len(low_sem)}")
    for r in sorted(low_sem, key=lambda r: r["sem_conf"])[:top_n]:
        print(f"   - [{r['sem_conf']:.2f}] {r['table']:25} {r['question'][:50]}")
        print(f"     SQL: {r['sql'][:90]}")

    divergent = [r for r in ok
                 if r["confidence"] is not None and r["score_strict"] is not None
                 and (r["confidence"] - r["score_strict"]) > 0.25]
    print(f"c. score vs score_strict divergence > 0.25 (false-positive suspects): {len(divergent)}")
    for r in sorted(divergent, key=lambda r: r["score_strict"])[:top_n]:
        print(f"   - [score={r['confidence']:.2f} strict={r['score_strict']:.2f}] {r['table']:20} {r['question'][:45]}")

    return per_table, cats, ev


# ---------------------------------------------------------------------------
# Chart
# ---------------------------------------------------------------------------

def plot(per_table, cats, ev, rows, output, title):
    def key(item):
        t, s = item
        tot = sum(s.values())
        return (-(s["p"] / tot if tot else 0), t)
    ordered = sorted(per_table.items(), key=key)
    labels, p, q, i = [], [], [], []
    for t, s in ordered:
        tot = sum(s.values())
        labels.append(f"{t}  {s['p']}/{tot} ({s['p']/tot*100:.0f}%)")
        p.append(s["p"]); q.append(s["q"]); i.append(s["i"])

    total, passed = len(rows), sum(1 for r in rows if r["success"])
    infra = sum(1 for r in rows if r["category"] == "infra")
    n_tables = len(ordered)

    has_components = any(r["sem_conf"] is not None for r in ev)
    n_panels = 3 if has_components else 2
    heights = [max(2.2, 0.42 * n_tables), 1.4] + ([1.2] if has_components else [])
    fig, axes = plt.subplots(n_panels, 1, figsize=(11, sum(heights) + 2),
                             gridspec_kw={"height_ratios": heights})
    ax1, ax2 = axes[0], axes[1]

    sub = f"raw = {passed}/{total} = {passed/total*100:.1f}%"
    if infra:
        sub += f"    |    adjusted (excl. outage) = {passed}/{total-infra} = {passed/(total-infra)*100:.1f}%"
    fig.suptitle(f"{title}\n{sub}", fontsize=11)

    y = range(len(labels))[::-1]
    ax1.barh(y, p, color=COLORS["passed"], label=f"Passed ({sum(p)})")
    ax1.barh(y, q, left=p, color=COLORS["quality"], label=f"Quality failures ({sum(q)})")
    ax1.barh(y, i, left=[a+b for a, b in zip(p, q)], color=COLORS["infra"], label=f"Outage ({sum(i)})")
    ax1.set_yticks(list(y)); ax1.set_yticklabels(labels, fontsize=8.5)
    ax1.legend(loc="lower right", fontsize=8)
    ax1.set_title("per-table score = passed / asked", fontsize=10, loc="left")

    cs = sorted(cats.items(), key=lambda kv: -kv[1])
    ax2.barh(range(len(cs))[::-1], [n for _, n in cs], color=CAT_COLORS[:len(cs)])
    ax2.set_yticks(range(len(cs))[::-1])
    ax2.set_yticklabels([CATEGORY_LABELS.get(c, c) for c, _ in cs], fontsize=9)
    ax2.set_title(f"Quality failures by category ({sum(n for _, n in cs)})", fontsize=10, loc="left")

    if has_components:
        ax3 = axes[2]
        comp = ["confidence", "score_strict", "rag_conf", "gen_conf", "sem_conf"]
        means = [mean(r[c] for r in ev) or 0 for c in comp]
        ax3.bar(comp, means, color="#2a78d6")
        for x, m in enumerate(means):
            ax3.text(x, m + 0.02, f"{m:.2f}", ha="center", fontsize=9)
        ax3.set_ylim(0, 1.15)
        ax3.set_title("Mean confidence components (evaluated questions)", fontsize=10, loc="left")

    plt.tight_layout(rect=[0, 0, 1, 0.95])
    plt.savefig(output, dpi=150, bbox_inches="tight")
    print(f"\nChart written to: {output}")


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--input", default="eval_results.csv")
    parser.add_argument("--output", default=None, help="PNG path (default: <input>_report.png)")
    parser.add_argument("--top-n", type=int, default=8, help="Max items listed per audit section")
    args = parser.parse_args()

    rows = load(args.input)
    if not rows:
        print(f"No data rows found in {args.input}")
        return

    per_table, cats, ev = print_report(rows, top_n=args.top_n)
    output = args.output or args.input.rsplit(".", 1)[0] + "_report.png"
    plot(per_table, cats, ev, rows, output, title=f"Evaluation report — {args.input}")


if __name__ == "__main__":
    main()
