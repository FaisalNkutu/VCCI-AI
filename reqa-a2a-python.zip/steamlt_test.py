import streamlit as st

st.set_page_config(
    page_title="Test Streamlit",
    page_icon="🚀",
    layout="centered"
)

st.title("🚀 Test Streamlit")

st.write("Si vous voyez cette page, Streamlit fonctionne correctement !")

nom = st.text_input("Votre nom")

if nom:
    st.success(f"Bonjour {nom} !")

if st.button("Cliquez ici"):
    st.balloons()
    st.write("Le bouton fonctionne 🎉")