
import sys
import argparse
from pathlib import Path
from datetime import datetime
from qdrant_client import QdrantClient
from config.settings import get_settings

settings = get_settings()
from agent.embedder import Embedder

def _neo4j_point_id(table_name: str) -> str:
    return str(uuid.uuid5(uuid.NAMESPACE_DNS, f"neo4j-node:{table_name}"))




def ingest_neo4j( client : QdrantClient ):
    embedding = "Personnel Person Org Reporting Org"
    payload = "Example to find a Person: from obj_type WHERE 'cat_code'=PE"



def query_neo4j(client : QdrantClient, limit = 5):

    search_result = client.search(
        collection_name=settings.QDRANT_COLLECTION,
        query_vector=[0.02, 0.59, 0.71, 0.40],
        query_filter=Filter(
            must=[
                FieldCondition(
                    key="category",
                    match=MatchValue(value="electronics")
            )   
            ]
        ),
        limit=limit
    )

