"""
Evaluate EVERY domain in one command, with a per-domain performance summary.

Discovers all domains present in KB_full_update.json, runs the evaluation
domain by domain (one CSV per domain, each with its own __GLOBAL__ footer),
then prints a final cross-domain table: pass rate (raw + adjusted for
server outages), mean confidence and mean semantic score per domain --
the application's performance map, domain by domain.

Reuses run_eval.py's helpers (same folder required): question loading,
API calls, table_match, resume bookkeeping.

Usage:
    python run_eval_by_domain.py
    python run_eval_by_domain.py --sample-per-table 2
    python run_eval_by_domain.py --limit-per-domain 10      # smoke test
    python run_eval_by_domain.py --resume                   # continue interrupted run
"""
import argparse
import csv
import json
import re
from pathlib import Path

import run_eval

FIELDNAMES = ["table", "question", "success", "attempts", "row_count",
              "confidence", "score_strict", "rag_conf", "gen_conf", "sem_conf",
              "table_match", "error", "sql", "elapsed"]

GLOBAL_ROW = getattr(run_eval, "GLOBAL_ROW_TABLE", "__GLOBAL__")


def discover_domains(kb_path: str) -> list:
    with open(kb_path, encoding="utf-8") as f:
        kb = json.load(f)
    domains = set()
    for entry in kb.values():
        for d in entry.get("domain", []) or []:
            domains.add(d)
    return sorted(domains)


def select_domains(all_domains: list, include: str = "", exclude: str = "",
                   batch_size: int = 0, batch_num: int = 0,
                   first: int = 0, last: int = 0,
                   from_domain: str = "", to_domain: str = "") -> list:
    """
    Resolve the domain selection:

      include    -- comma-separated list; each token matches a domain by
                    case-insensitive SUBSTRING ("ops" -> "Air Operations...",
                    ambiguous tokens abort with the list of candidates, so
                    long official names never need to be typed in full);
      exclude    -- same matching, removes domains from the selection;
      batch_size + batch_num -- split the (post include/exclude) list into
                    consecutive batches of batch_size (alphabetical order)
                    and keep only batch #batch_num (1-based) -- lets a huge
                    campaign run in installments across days.
    """
    selected = list(all_domains)

    def _match(token: str) -> list:
        t = token.strip().lower()
        return [d for d in all_domains if t and t in d.lower()]

    def _match_one(token: str, flag: str) -> str:
        hits = _match(token)
        if not hits:
            raise SystemExit(
                f"[!] {flag}: '{token.strip()}' matches nothing. Available:\n  - "
                + "\n  - ".join(all_domains))
        if len(hits) > 1:
            raise SystemExit(
                f"[!] {flag}: '{token.strip()}' is ambiguous, matches:\n  - "
                + "\n  - ".join(hits) + "\nBe more specific.")
        return hits[0]

    # Alphabetical RANGE: from one domain up to another (both inclusive,
    # same substring matching as --domains). Open-ended: --from alone runs
    # to the end, --to alone from the beginning.
    if from_domain or to_domain:
        i = selected.index(_match_one(from_domain, "--from")) if from_domain else 0
        j = selected.index(_match_one(to_domain, "--to")) if to_domain else len(selected) - 1
        if i > j:
            raise SystemExit(f"[!] --from '{selected[i]}' comes AFTER --to '{selected[j]}' "
                             f"in alphabetical order -- swap them")
        selected = selected[i:j + 1]


    if include:
        picked = []
        for token in include.split(","):
            hits = _match(token)
            if not hits:
                raise SystemExit(
                    f"[!] --domains: '{token.strip()}' matches nothing. Available:\n  - "
                    + "\n  - ".join(all_domains))
            if len(hits) > 1:
                raise SystemExit(
                    f"[!] --domains: '{token.strip()}' is ambiguous, matches:\n  - "
                    + "\n  - ".join(hits) + "\nBe more specific.")
            if hits[0] not in picked:
                picked.append(hits[0])
        selected = picked

    if exclude:
        for token in exclude.split(","):
            for hit in _match(token):
                if hit in selected:
                    selected.remove(hit)

    if first and last:
        raise SystemExit("[!] --first and --last are mutually exclusive")
    if first and first > 0:
        selected = selected[:first]
    if last and last > 0:
        selected = selected[-last:]

    if batch_size and batch_size > 0:
        if batch_num < 1:
            raise SystemExit("[!] --batch requires a 1-based batch number (use with --batch-size)")
        start = (batch_num - 1) * batch_size
        chunk = selected[start:start + batch_size]
        if not chunk:
            n_batches = (len(selected) + batch_size - 1) // batch_size
            raise SystemExit(f"[!] batch {batch_num} is empty -- only {n_batches} batch(es) "
                             f"of size {batch_size} over {len(selected)} domain(s)")
        selected = chunk

    return selected


def safe_filename(domain: str) -> str:
    return re.sub(r"[^a-zA-Z0-9]+", "_", domain).strip("_").lower()


def is_infra(error: str) -> bool:
    e = (error or "").lower()
    return ("circuit breaker" in e or "connection refused" in e
            or "httpconnectionpool" in e or "max retries" in e
            or "client timeout" in e)


def _mean(values):
    vals = [float(v) for v in values if v not in (None, "", "None")]
    return round(sum(vals) / len(vals), 4) if vals else None


def purge_global_rows(path: Path) -> None:
    if not path.exists():
        return
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        kept = [r for r in reader if r.get("table") != GLOBAL_ROW]
        fields = reader.fieldnames or FIELDNAMES
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(kept)


def run_domain(domain: str, args) -> dict:
    """Run one domain's evaluation; returns its summary stats."""
    output = Path(args.output_dir) / f"eval_domain_{safe_filename(domain)}.csv"

    # Never mix runs: version the file if it exists and we're not resuming
    if output.exists() and not args.resume:
        n = 2
        while True:
            cand = output.with_name(f"{output.stem}_v{n}{output.suffix}")
            if not cand.exists():
                break
            n += 1
        print(f"  [!] {output.name} exists -- writing to {cand.name} (use --resume to continue it)")
        output = cand

    purge_global_rows(output)

    items = run_eval.load_questions(args.kb, None, domain, args.sample_per_table)
    if args.limit_per_domain:
        items = items[: args.limit_per_domain]

    done = run_eval.load_already_tested(output) if args.resume else set()
    if done:
        items = [it for it in items if (it["table"], it["question"]) not in done]
        print(f"  [resume] {len(done)} already tested, skipped.")

    file_exists = output.exists()
    passed_now = 0
    with open(output, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        if not file_exists:
            writer.writeheader()
        for i, item in enumerate(items, 1):
            result = run_eval.run_one_query(args.api_url, args.api_key, item["question"], args.timeout)
            result["table_match"] = run_eval.sql_targets_table(result.get("sql", ""), item["table"])
            writer.writerow({**item, **result})
            f.flush()
            status = "OK  " if result["success"] else "FAIL"
            passed_now += bool(result["success"])
            print(f"  [{i}/{len(items)}] {status}  {item['table']:32} {result['elapsed']:>6.1f}s  "
                  f"conf={result['confidence']} sem={result['sem_conf']}  {item['question'][:48]}")
            if not result["success"]:
                print(f"            -> {(result['error'] or '')[:130]}")

    # Stats over the WHOLE file (correct across --resume)
    with open(output, newline="", encoding="utf-8") as f:
        rows = [r for r in csv.DictReader(f) if r.get("table") != GLOBAL_ROW]
    total = len(rows)
    ok = sum(1 for r in rows if (r.get("success") or "").lower() == "true")
    infra = sum(1 for r in rows
                if (r.get("success") or "").lower() != "true" and is_infra(r.get("error", "")))
    evaluated = total - infra
    matches_ok = sum(1 for r in rows if (r.get("success") or "").lower() == "true"
                     and (r.get("table_match") or "").lower() == "true")

    stats = {
        "domain": domain, "file": output.name,
        "passed": ok, "total": total, "infra": infra,
        "raw": ok / total * 100 if total else 0.0,
        "adjusted": ok / evaluated * 100 if evaluated else 0.0,
        "mean_conf": _mean(r.get("confidence") for r in rows),
        "mean_sem": _mean(r.get("sem_conf") for r in rows),
        "table_match": f"{matches_ok}/{ok}" if ok else "-",
    }

    # __GLOBAL__ footer in the per-domain CSV, same shape as run_eval's
    with open(output, "a", newline="", encoding="utf-8") as f:
        csv.DictWriter(f, fieldnames=FIELDNAMES).writerow({
            "table": GLOBAL_ROW,
            "question": f"GLOBAL SUMMARY over {total} questions",
            "success": f"{ok}/{total}",
            "confidence": stats["mean_conf"],
            "score_strict": _mean(r.get("score_strict") for r in rows),
            "rag_conf": _mean(r.get("rag_conf") for r in rows),
            "gen_conf": _mean(r.get("gen_conf") for r in rows),
            "sem_conf": stats["mean_sem"],
            "table_match": stats["table_match"],
            "error": f"pass_rate={stats['raw']:.1f}%",
        })
    return stats


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--api-url", default="http://localhost:8080")
    parser.add_argument("--api-key", default="")
    parser.add_argument("--kb", default="RAG/KB_full_update.json")
    parser.add_argument("--sample-per-table", type=int, default=2)
    parser.add_argument("--limit-per-domain", type=int, default=None)
    parser.add_argument("--timeout", type=int, default=400)
    parser.add_argument("--output-dir", default=".")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--domains", default="",
                        help="Comma-separated domain list (case-insensitive substring "
                             "match, e.g. --domains \"operations,air\")")
    parser.add_argument("--exclude", default="",
                        help="Comma-separated domains to skip (same matching)")
    parser.add_argument("--batch-size", type=int, default=0,
                        help="Split the selection into batches of this many domains")
    parser.add_argument("--batch", type=int, default=0,
                        help="Which batch to run (1-based, requires --batch-size)")
    parser.add_argument("--from", dest="from_domain", default="",
                        help="Start of an alphabetical range of domains (inclusive, "
                             "substring match) -- combine with --to")
    parser.add_argument("--to", dest="to_domain", default="",
                        help="End of the alphabetical range (inclusive)")
    parser.add_argument("--first", type=int, default=0,
                        help="Keep only the FIRST N domains (alphabetical) of the selection")
    parser.add_argument("--last", type=int, default=0,
                        help="Keep only the LAST N domains (alphabetical) of the selection")
    parser.add_argument("--list", action="store_true",
                        help="List the resolved domain selection and exit without running")
    args = parser.parse_args()

    all_domains = discover_domains(args.kb)
    domains = select_domains(all_domains, args.domains, args.exclude,
                             args.batch_size, args.batch,
                             first=args.first, last=args.last,
                             from_domain=args.from_domain, to_domain=args.to_domain)
    print(f"{len(domains)} domain(s) selected (out of {len(all_domains)}):")
    for d in domains:
        print(f"  - {d}")
    print()
    if args.list:
        return

    summaries = []
    for domain in domains:
        print(f"=== {domain} ===")
        try:
            summaries.append(run_domain(domain, args))
        except KeyboardInterrupt:
            print("\nInterrupted -- partial results kept; relaunch with --resume to continue.")
            break
        except Exception as e:
            print(f"  [!] domain failed unexpectedly: {str(e)[:150]}")
            summaries.append({"domain": domain, "file": "-", "passed": 0, "total": 0,
                              "infra": 0, "raw": 0.0, "adjusted": 0.0,
                              "mean_conf": None, "mean_sem": None, "table_match": "-"})
        print()

    print("=" * 100)
    print("PERFORMANCE PAR DOMAINE")
    print("=" * 100)
    print(f"{'domain':45} {'pass':>9} {'raw':>7} {'adj*':>7} {'conf':>6} {'sem':>6} {'tbl_match':>10}")
    tp = tt = ti = 0
    for s in sorted(summaries, key=lambda s: -s["adjusted"]):
        conf = f"{s['mean_conf']:.2f}" if s["mean_conf"] is not None else "-"
        sem = f"{s['mean_sem']:.2f}" if s["mean_sem"] is not None else "-"
        print(f"{s['domain'][:45]:45} {s['passed']:>4}/{s['total']:<4} {s['raw']:>6.1f}% "
              f"{s['adjusted']:>6.1f}% {conf:>6} {sem:>6} {s['table_match']:>10}")
        tp += s["passed"]; tt += s["total"]; ti += s["infra"]
    print("-" * 100)
    ev = tt - ti
    if tt:
        print(f"{'TOTAL':45} {tp:>4}/{tt:<4} {tp/tt*100:>6.1f}% "
              f"{(tp/ev*100 if ev else 0):>6.1f}%")
    print("\n* adj = excluding server-outage questions (never actually evaluated)")

    # ── Cross-domain summary CSV ─────────────────────────────────────────
    # The final table above, persisted: one row per domain + a TOTAL row.
    # This is THE deliverable file for reports ("application performance,
    # domain by domain").
    summary_path = Path(args.output_dir) / "eval_domains_summary.csv"
    with open(summary_path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=[
            "domain", "passed", "total", "outage", "raw_pass_rate",
            "adjusted_pass_rate", "mean_confidence", "mean_sem_conf",
            "table_match", "csv_file",
        ])
        w.writeheader()
        for s in sorted(summaries, key=lambda s: -s["adjusted"]):
            w.writerow({
                "domain": s["domain"],
                "passed": s["passed"], "total": s["total"], "outage": s["infra"],
                "raw_pass_rate": f"{s['raw']:.1f}%",
                "adjusted_pass_rate": f"{s['adjusted']:.1f}%",
                "mean_confidence": s["mean_conf"] if s["mean_conf"] is not None else "",
                "mean_sem_conf": s["mean_sem"] if s["mean_sem"] is not None else "",
                "table_match": s["table_match"],
                "csv_file": s["file"],
            })
        if tt:
            w.writerow({
                "domain": "TOTAL", "passed": tp, "total": tt, "outage": ti,
                "raw_pass_rate": f"{tp/tt*100:.1f}%",
                "adjusted_pass_rate": f"{(tp/ev*100 if ev else 0):.1f}%",
                "mean_confidence": "", "mean_sem_conf": "",
                "table_match": "", "csv_file": "",
            })
    print(f"Cross-domain summary written to: {summary_path}")


if __name__ == "__main__":
    main()
