"""
Genere un script run_eval_<domaine>.py DEDIE pour chaque domaine reellement
present dans KB_full_update.json -- au lieu de deviner les noms de domaines,
ce script les decouvre en lisant ton vrai fichier.

Usage:
    python generate_domain_eval_scripts.py
    python generate_domain_eval_scripts.py --kb RAG/KB_full_update.json --output-dir .

Chaque script genere (ex: run_eval_operations_command_control.py) teste
UNIQUEMENT son domaine, sans avoir besoin de passer --domain a la main :

    python run_eval_operations_command_control.py
    python run_eval_operations_command_control.py --limit 10
    python run_eval_operations_command_control.py --resume

Necessite run_eval.py dans le meme dossier (les scripts generes reutilisent
directement ses fonctions load_questions()/run_one_query()/etc.).
"""
import argparse
import json
import re
from pathlib import Path

TEMPLATE = '''"""
Test systematique du domaine : {domain}

Genere automatiquement par generate_domain_eval_scripts.py -- pour changer
le comportement commun a TOUS les domaines (timeout, format du rapport...),
modifie plutot run_eval.py lui-meme, dont ce fichier ne fait que reutiliser
les fonctions avec ce domaine precis fixe en dur.

Usage:
    python {script_name}
    python {script_name} --limit 10
    python {script_name} --resume
"""
import argparse
import csv
from pathlib import Path

import run_eval

DOMAIN = {domain!r}
DEFAULT_OUTPUT = "eval_domain_{safe_name}.csv"


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--api-url", default="http://localhost:8080")
    parser.add_argument("--api-key", default="")
    parser.add_argument("--kb", default="RAG/KB_full_update.json")
    parser.add_argument("--sample-per-table", type=int, default=2)
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--timeout", type=int, default=400)
    parser.add_argument("--output", default=DEFAULT_OUTPUT)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()

    items = run_eval.load_questions(args.kb, None, DOMAIN, args.sample_per_table)
    if args.limit:
        items = items[: args.limit]

    output_path = Path(args.output)
    already_done = run_eval.load_already_tested(output_path) if args.resume else set()
    if already_done:
        items = [it for it in items if (it["table"], it["question"]) not in already_done]
        print(f"[resume] {{len(already_done)}} deja testee(s), ignorees.")

    print(f"Domaine: {{DOMAIN}}")
    print(f"{{len(items)}} question(s) a tester.\\n")

    file_exists = output_path.exists()
    fieldnames = ["table", "question", "success", "attempts", "row_count", "confidence", "error", "sql", "elapsed"]

    with open(output_path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if not file_exists:
            writer.writeheader()

        passed = 0
        for i, item in enumerate(items, 1):
            result = run_eval.run_one_query(args.api_url, args.api_key, item["question"], args.timeout)
            row = {{**item, **result}}
            writer.writerow(row)
            f.flush()

            status = "OK  " if result["success"] else "FAIL"
            passed += result["success"]
            print(f"[{{i}}/{{len(items)}}] {{status}}  {{item['table']:35}}  {{result['elapsed']:>6.1f}}s  {{item['question'][:60]}}")
            if not result["success"]:
                print(f"          -> {{result['error'][:150]}}")

    if items:
        print(f"\\n=== {{DOMAIN}}: {{passed}}/{{len(items)}} reussies ({{passed/len(items)*100:.1f}}%) ===")
    else:
        print("\\nRien a tester.")
    print(f"Resultats ecrits dans: {{output_path}}")


if __name__ == "__main__":
    main()
'''


def discover_domains(kb_path: str) -> list[str]:
    with open(kb_path, encoding="utf-8") as f:
        kb = json.load(f)
    domains = set()
    for entry in kb.values():
        for d in entry.get("domain", []):
            domains.add(d)
    return sorted(domains)


def safe_filename(domain: str) -> str:
    return re.sub(r"[^a-zA-Z0-9]+", "_", domain).strip("_").lower()


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--kb", default="RAG/KB_full_update.json")
    parser.add_argument("--output-dir", default=".")
    args = parser.parse_args()

    domains = discover_domains(args.kb)
    print(f"{len(domains)} domaine(s) trouve(s) dans {args.kb} :\n")

    output_dir = Path(args.output_dir)
    for domain in domains:
        safe_name = safe_filename(domain)
        script_name = f"run_eval_{safe_name}.py"
        script_path = output_dir / script_name

        content = TEMPLATE.format(domain=domain, safe_name=safe_name, script_name=script_name)
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(content)

        print(f"  {script_name:55} <- {domain}")

    print(f"\n{len(domains)} script(s) genere(s) dans {output_dir.resolve()}")
    print("Place-les a cote de run_eval.py, puis lance par exemple :")
    if domains:
        print(f"  python run_eval_{safe_filename(domains[0])}.py --limit 10")


if __name__ == "__main__":
    main()
