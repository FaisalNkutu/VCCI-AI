from query_analysis.query_analyser import QueryAnalyzer
from query_analysis.grounding_builder import GroundingBuilder

from agent.term_grounding import ground_terms

analyzer = QueryAnalyzer()

grounding_builder = GroundingBuilder()

query = (
    'What units are using the "M777 Group" howitzer?'
)

analysis = analyzer.analyze(query)

grounding = grounding_builder.build(
    analysis
)

print("\n" + "=" * 80)
print("V4 ANALYSIS")
print("=" * 80)
print(analysis)

print("\n" + "=" * 80)
print("V4 GROUNDING")
print("=" * 80)
print(grounding)

print("\n" + "=" * 80)
print("CURRENT GROUNDING")
print("=" * 80)

tg = ground_terms(query)

print(tg)