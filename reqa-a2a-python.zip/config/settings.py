from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field
import os

from dotenv import load_dotenv

load_dotenv()

EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL")
RERANKER_MODEL = os.getenv("RERANKER_MODEL")



class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # ─────────────────────────────────────────────────────────────
    # MariaDB
    # ─────────────────────────────────────────────────────────────

    DB_HOST: str = Field("localhost", alias="DB_HOST")
    DB_PORT: int = Field(3306, alias="DB_PORT")
    DB_NAME: str = Field("calian", alias="DB_NAME")

    # ⚠️ IMPORTANT: secure fallback
    DB_USER: str = Field(
        default_factory=lambda: os.getenv("DB_USER", "root"),
        alias="DB_USER",
    )

    DB_PASSWORD: str = Field(
        default_factory=lambda: os.getenv("DB_PASSWORD", ""),
        alias="DB_PASSWORD",
    )

    # ─────────────────────────────────────────────────────────────
    # Qdrant
    # ─────────────────────────────────────────────────────────────

    QDRANT_HOST: str = Field(
        default_factory=lambda: os.getenv("QDRANT_HOST", "qdrant"),
        alias="QDRANT_HOST")
    
    QDRANT_PORT: int = Field( 
            default_factory=lambda: os.getenv("QDRANT_PORT", 6333 ),
            alias="QDRANT_PORT")
    
    QDRANT_COLLECTION: str = Field(
        default_factory=lambda: os.getenv("QDRANT_COLLECTION", "collection" ),
        alias="QDRANT_COLLECTION")
  

    # ─────────────────────────────────────────────────────────────
    # Ollama
    # ─────────────────────────────────────────────────────────────

    ollama_base_url: str = Field("http://ollama:11434", alias="OLLAMA_BASE_URL")
    ollama_sql_model: str = Field("codestral", alias="OLLAMA_SQL_MODEL")
    ollama_render_model: str = Field("mistral", alias="OLLAMA_RENDER_MODEL")
    ollama_model: str = Field("mistral", alias="OLLAMA_MODEL")
    ollama_embed_url: str = Field("http://localhost:11434", alias="OLLAMA_EMBED_URL")
    ollama_embed_model: str = Field("nomic-embed-text", alias="OLLAMA_EMBED_MODEL")
    LLM_PROVIDER: str = Field("ollama", alias="LLM_PROVIDER")

    # ─────────────────────────────────────────────────────────────
    # RAG
    # ─────────────────────────────────────────────────────────────

    top_k_tables: int = Field(8, alias="TOP_K_TABLES")
    embedding_model: str = Field(EMBEDDING_MODEL, alias="EMBEDDING MODEL")

    use_query_expansion: bool = Field(True, alias="USE_QUERY_EXPANSION")
    use_reranker: bool = Field(True, alias="USE_RERANKER")
    reranker_model: str = Field(RERANKER_MODEL, alias="RERANKER_MODEL")

    expansion_count: int = Field(3, alias="EXPANSION_COUNT")
    retrieval_candidates: int = Field(20, alias="RETRIEVAL_CANDIDATES")

    # ─────────────────────────────────────────────────────────────
    # Pipeline
    # ─────────────────────────────────────────────────────────────

    max_sql_retries: int = Field(3, alias="MAX_SQL_RETRIES")
    max_rows: int = Field(10, alias="MAX_ROWS")
    circuit_breaker_threshold: int = Field(3, alias="CIRCUIT_BREAKER_THRESHOLD")
    circuit_breaker_timeout: int = Field(60, alias="CIRCUIT_BREAKER_TIMEOUT")

    # ─────────────────────────────────────────────────────────────
    # API
    # ─────────────────────────────────────────────────────────────
    reqa_api_host : str = Field("http://127.0.0.1", alias="REQA_API_HOST")

    # Si non vide, tous les endpoints POST exigent le header X-API-Key.
    # Leave empty to disable (local development only).
    api_key: str = Field("", alias="API_KEY")

    # ─────────────────────────────────────────────────────────────
    # Logging
    # ─────────────────────────────────────────────────────────────

    log_level: str = Field("INFO", alias="LOG_LEVEL")




    # ─────────────────────────────────────────────────────────────
    # A2A
    # ─────────────────────────────────────────────────────────────
   
    A2A_HOST: str = Field(    
                    default_factory=lambda: os.getenv("A2A_HOST", "http://127.0.0.1"),
                    alias="A2A_HOST")        
    A2A_PORT: int = Field(8080, alias="A2A_PORT")
    A2A_PATH: str = Field(    
                    default_factory=lambda: os.getenv("A2A_PATH", "http://127.0.0.1"),
                    alias="A2A_PATH")        

    # ─────────────────────────────────────────────────────────────
    # A2A
    # ─────────────────────────────────────────────────────────────
   
    NEO4J_HOST: str = Field(    
                    default_factory=lambda: os.getenv("NEO4J_HOST", "neo4j://127.0.0.1"),
                    alias="NEO4J_HOST")        
    NEO4J_USER: str = Field(    
                    default_factory=lambda: os.getenv("NEO4J_USER", "neo4j"),
                    alias="NEO4J_USER")        
    NEO4J_PORT: int = Field(8080, alias="NEO4J_PORT")
    NEO4J_PASSWORD: str = Field(    
                    default_factory=lambda: os.getenv("NEO4J_PASSWORD", "secretpassword"),
                    alias="NEO4J_PASSWORD")    

    #
    #   RAG Options
    # 

    LANGFUSE_ENABLED : int = Field(    
                    default_factory=lambda: os.getenv("LANGFUSE_ENABLED", 0 ),
                    alias="LANGFUSE_ENABLED")    


    RAG_MAX_SCHEMA_CONTEXT_CHARS  : int = Field(    
                    default_factory=lambda: os.getenv("RAG_MAX_SCHEMA_CONTEXT_CHARS", 32768 ),
                    alias="RAG_MAX_SCHEMA_CONTEXT_CHARS")    

    EXCLUDE_METRICS_TABLES  : int = Field(    
                    default_factory=lambda: os.getenv("EXCLUDE_METRICS_TABLES", 0 ),
                    alias="EXCLUDE_METRICS_TABLES")    
    SCHEMA_FILE  : str = Field(    
                    default_factory=lambda: os.getenv("SCHEMA_FILE","RAG/calian_20260812.sql" ),
                    alias="SCHEMA_FILE")    


    KB_FILE  : str = Field(    
                    default_factory=lambda: os.getenv("KB_FILE","RAG/KB_production_rezwan.json" ),
                    alias="KB_FILE")    

    
# ─────────────────────────────────────────────────────────────────────────────
# SINGLETON CACHE
# ─────────────────────────────────────────────────────────────────────────────

_settings: Settings | None = None


def get_settings() -> Settings:
    global _settings
    
    if _settings is None:
        try:
            _settings = Settings()            
        except Exception as e:
            raise RuntimeError(
                "Configuration error: missing environment variables. "
                "Check your .env file (DB_USER, DB_PASSWORD, etc.)."
            ) from e

    print("======================= get_settings() ==========================================")   
    return _settings
