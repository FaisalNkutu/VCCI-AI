"""
Live progress tracker for domain evaluation runs (run_eval_by_domain.py /
run_eval.py). Run it anytime in a second terminal -- read-only, it never
disturbs a running eval.

Shows, per domain CSV found:
    done/expected questions, pass rate, infra failures (outage/circuit
    breaker), mean confidence & sem_conf -- plus a TOTAL line, an ETA
    based on the mean per-question time, and a CASCADE ALERT when the
    latest results are all infra failures (LLM down: stop the run, fix,
    then --resume).

Usage:
    python watch_eval.py                          # one snapshot
    python watch_eval.py --sample-per-table 7     # accurate expected totals
    python watch_eval.py --loop 60                # refresh every 60s
"""
import argparse
import csv
import os
import glob
import json
import re
import time


def is_infra(error: str) -> bool:
    e = (error or "").lower()
    return ("circuit breaker" in e or "connection refused" in e
            or "httpconnectionpool" in e or "max retries" in e
            or "client timeout" in e)


def safe_filename(domain: str) -> str:
    return re.sub(r"[^a-zA-Z0-9]+", "_", domain).strip("_").lower()


def expected_per_domain(kb_path: str, per_table: int) -> dict:
    try:
        with open(kb_path, encoding="utf-8") as f:
            kb = json.load(f)
    except Exception:
        return {}
    counts: dict = {}
    for entry in kb.values():
        for d in entry.get("domain") or []:
            counts[safe_filename(d)] = counts.get(safe_filename(d), 0) + 1
    return {k: n * per_table for k, n in counts.items()}


def _mean(vals):
    vals = [float(v) for v in vals if v not in (None, "", "None")]
    return sum(vals) / len(vals) if vals else None


def snapshot(args):
    expected = expected_per_domain(args.kb, args.sample_per_table)
    files = sorted(glob.glob("eval_domain_*.csv"))
    if not files:
        print("Aucun eval_domain_*.csv pour l'instant.")
        return

    print(f"{'fichier':52} {'fait':>9} {'OK':>4} {'infra':>5} {'conf':>5} {'sem':>5}")
    print("-" * 88)

    t_done = t_ok = t_infra = 0
    elapsed_vals = []
    newest_file, newest_rows, newest_mtime = None, [], 0.0

    for f in files:
        with open(f, newline="", encoding="utf-8") as fh:
            rows = [r for r in csv.DictReader(fh) if r.get("table") != "__GLOBAL__"]
        if not rows:
            continue
        ok = sum(1 for r in rows if (r.get("success") or "").lower() == "true")
        infra = sum(1 for r in rows if (r.get("success") or "").lower() != "true"
                    and is_infra(r.get("error", "")))
        conf = _mean(r.get("confidence") for r in rows)
        sem = _mean(r.get("sem_conf") for r in rows)
        elapsed_vals += [float(r["elapsed"]) for r in rows
                         if r.get("elapsed") not in (None, "", "None")]

        # expected count: strip eval_domain_ prefix and any _vN suffix
        key = re.sub(r"^eval_domain_", "", f[:-4])
        key = re.sub(r"_v\d+$", "", key)
        exp = expected.get(key)
        done_str = f"{len(rows)}/{exp}" if exp else str(len(rows))

        print(f"{f[:52]:52} {done_str:>9} {ok:>4} {infra:>5} "
              f"{conf:>5.2f}" if conf is not None else
              f"{f[:52]:52} {done_str:>9} {ok:>4} {infra:>5}    - ", end="")
        print(f" {sem:>5.2f}" if sem is not None else "     -")

        t_done += len(rows); t_ok += ok; t_infra += infra
        # the ACTIVE file is the most recently modified one, not the last
        # alphabetical (robust even if the run order ever changes)
        mtime = os.path.getmtime(f)
        if newest_file is None or mtime > newest_mtime:
            newest_file, newest_rows, newest_mtime = f, rows, mtime

    print("-" * 88)
    evaluated = t_done - t_infra
    rate = f"{t_ok/evaluated*100:.0f}%" if evaluated else "-"
    print(f"{'TOTAL':52} {t_done:>9} {t_ok:>4} {t_infra:>5}   (pass ajuste: {rate})")

    total_expected = sum(expected.values()) if expected else 0
    if total_expected and elapsed_vals:
        remaining = max(0, total_expected - t_done)
        avg = sum(elapsed_vals) / len(elapsed_vals)
        eta_h = remaining * avg / 3600
        print(f"Reste ~{remaining} questions x {avg:.0f}s en moyenne ≈ {eta_h:.1f} h")

    # Cascade alert: the last rows of the most recent file are all infra
    if newest_rows:
        tail = newest_rows[-3:]
        if len(tail) == 3 and all(
            (r.get("success") or "").lower() != "true" and is_infra(r.get("error", ""))
            for r in tail
        ):
            print("\n⚠  CASCADE ALERT: les dernieres questions sont toutes en echec infra "
                  f"(circuit breaker / LLM injoignable) dans {newest_file}.")
            print("   -> Arreter le run (Ctrl+C), verifier le LLM, puis relancer avec --resume.")


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--kb", default="RAG/KB_full_update.json")
    parser.add_argument("--sample-per-table", type=int, default=7,
                        help="Used to compute expected totals per domain (match the run's value)")
    parser.add_argument("--loop", type=int, default=0,
                        help="Refresh every N seconds (0 = single snapshot)")
    args = parser.parse_args()

    while True:
        print(f"\n===== {time.strftime('%H:%M:%S')} =====")
        snapshot(args)
        if not args.loop:
            break
        time.sleep(args.loop)


if __name__ == "__main__":
    main()
