"""
MCP Server — Database Tools

Exposes three tools to agents via the Model Context Protocol (stdio transport):
  - check_sql_syntax(sql)           static validation via sqlglot (SELECT-only)
  - explain_sql(sql)                MariaDB EXPLAIN dry-run (no data touched)
  - execute_sql(sql, max_rows=100)  real query execution, returns rows as JSON

Run standalone:
    python mcp_servers/database_server.py
"""
import asyncio
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import pymysql
import pymysql.cursors
import sqlglot
from sqlglot import exp
from dotenv import load_dotenv
from mcp.server import NotificationOptions, Server
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server
import mcp.types as types

load_dotenv()

DB_PARAMS = dict(
    host=os.getenv("DB_HOST", "localhost"),
    port=int(os.getenv("DB_PORT", "3306")),
    database=os.getenv("DB_NAME", "example_db"),
    user=os.getenv("DB_USER", "example_user"),
    password=os.getenv("DB_PASSWORD", "test"),
)

server = Server("database-server")


@server.list_tools()
async def list_tools() -> list[types.Tool]:
    return [
        types.Tool(
            name="check_sql_syntax",
            description=(
                "Validates SQL syntax using sqlglot (MariaDB dialect) "
                "and enforces SELECT-only policy. Returns {valid, error}."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "sql": {"type": "string", "description": "SQL query to validate"},
                },
                "required": ["sql"],
            },
        ),
        types.Tool(
            name="explain_sql",
            description=(
                "Runs MariaDB EXPLAIN on a query — dry-run, zero data read. "
                "Returns {success, error}."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "sql": {"type": "string", "description": "SQL query to explain"},
                },
                "required": ["sql"],
            },
        ),
        types.Tool(
            name="execute_sql",
            description=(
                "Executes a SELECT SQL query against MariaDB and returns rows as JSON. "
                "Returns {success, rows, error}."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "sql": {"type": "string", "description": "SQL SELECT query to execute"},
                    "max_rows": {
                        "type": "integer",
                        "description": "Maximum rows to return",
                        "default": 100,
                    },
                },
                "required": ["sql"],
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict | None) -> list[types.TextContent]:
    args = arguments or {}

    # ── check_sql_syntax ──────────────────────────────────────────────────────
    if name == "check_sql_syntax":
        sql = args.get("sql", "").strip().strip("`")
        if sql.lower().startswith("sql"):
            sql = sql[3:].strip()

        try:
            stmts = sqlglot.parse(sql, dialect="mysql")
        except Exception as e:
            return [_text({"valid": False, "error": f"Parse error: {e}"})]

        if not stmts or stmts[0] is None:
            return [_text({"valid": False, "error": "Empty or unparseable SQL"})]

        if not isinstance(stmts[0], exp.Select):
            kind = type(stmts[0]).__name__
            return [_text({"valid": False, "error": f"Only SELECT allowed — got {kind}"})]

        return [_text({"valid": True, "error": ""})]

    # ── explain_sql ───────────────────────────────────────────────────────────
    elif name == "explain_sql":
        sql = args.get("sql", "")
        conn = None
        try:
            conn = pymysql.connect(**DB_PARAMS)
            with conn.cursor() as cur:
                cur.execute(f"EXPLAIN {sql}")
                cur.fetchall()
            return [_text({"success": True, "error": ""})]
        except pymysql.Error as e:
            return [_text({"success": False, "error": str(e)})]
        finally:
            if conn:
                conn.close()

    # ── execute_sql ───────────────────────────────────────────────────────────
    elif name == "execute_sql":
        sql = args.get("sql", "")
        max_rows = int(args.get("max_rows", 100))
        conn = None
        try:
            conn = pymysql.connect(**DB_PARAMS, cursorclass=pymysql.cursors.DictCursor)
            with conn.cursor() as cur:
                cur.execute(sql)
                rows = cur.fetchmany(max_rows)
            return [_text({"success": True, "rows": [dict(r) for r in rows], "error": ""})]
        except pymysql.Error as e:
            return [_text({"success": False, "rows": [], "error": str(e)})]
        finally:
            if conn:
                conn.close()

    return [_text({"error": f"Unknown tool: {name}"})]


def _default(o):
    import decimal, datetime
    if isinstance(o, decimal.Decimal):
        return float(o)
    if isinstance(o, (datetime.datetime, datetime.date)):
        return o.isoformat()
    raise TypeError(f"Object of type {type(o).__name__} is not JSON serializable")


def _text(obj: dict) -> types.TextContent:
    return types.TextContent(type="text", text=json.dumps(obj, default=_default))


async def main() -> None:
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="database-server",
                server_version="1.0.0",
                capabilities=server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )


if __name__ == "__main__":
    asyncio.run(main())
