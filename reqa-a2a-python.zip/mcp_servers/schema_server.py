"""
MCP Server — Schema / RAG Tools

Exposes two tools to agents via the Model Context Protocol (stdio transport):
  - search_schema(query, top_k=5)  semantic search in Qdrant (fastembed)
  - list_all_tables()              returns every indexed table name

Run standalone:
    python mcp_servers/schema_server.py
"""
import asyncio
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import load_dotenv
from qdrant_client import QdrantClient
from mcp.server import NotificationOptions, Server
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server
import mcp.types as types

from agent.embedder import Embedder

load_dotenv()

QDRANT_HOST = os.getenv("QDRANT_HOST", "localhost")
QDRANT_PORT = int(os.getenv("QDRANT_PORT", "6333"))
QDRANT_COLLECTION = os.getenv("QDRANT_COLLECTION", "schema")
TOP_K_DEFAULT = int(os.getenv("TOP_K_TABLES", "5"))

# Lazy singletons — initialized on first tool call to avoid startup cost
_qdrant: QdrantClient | None = None
_embedder: Embedder | None = None


def _clients() -> tuple[QdrantClient, Embedder]:
    global _qdrant, _embedder
    if _qdrant is None:
        _qdrant = QdrantClient(host=QDRANT_HOST, port=QDRANT_PORT)
    if _embedder is None:
        _embedder = Embedder()
    return _qdrant, _embedder


server = Server("schema-server")


@server.list_tools()
async def list_tools() -> list[types.Tool]:
    return [
        types.Tool(
            name="search_schema",
            description=(
                "Semantic search in Qdrant to find the most relevant table schemas "
                "for a natural language question. Returns {tables: [{table, description}]}."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Natural language question"},
                    "top_k": {
                        "type": "integer",
                        "description": "Number of most relevant tables to return",
                        "default": 5,
                    },
                },
                "required": ["query"],
            },
        ),
        types.Tool(
            name="list_all_tables",
            description=(
                "Returns the complete list of table names indexed in Qdrant. "
                "Used to give the SQL agent full table awareness. Returns {tables: [str]}."
            ),
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict | None) -> list[types.TextContent]:
    args = arguments or {}
    qdrant, embedder = _clients()

    if name == "search_schema":
        query = args.get("query", "")
        top_k = int(args.get("top_k", TOP_K_DEFAULT))
        vector = embedder.embed(query)
        results = qdrant.query_points(
            collection_name=QDRANT_COLLECTION,
            query=vector,
            limit=top_k,
        )
        payloads = [r.payload for r in results.points]
        return [_text({"tables": payloads})]

    elif name == "list_all_tables":
        records, _ = qdrant.scroll(
            collection_name=QDRANT_COLLECTION,
            limit=200,
            with_payload=True,
        )
        names = [r.payload.get("table", "") for r in records if r.payload]
        return [_text({"tables": names})]

    return [_text({"error": f"Unknown tool: {name}"})]


def _text(obj: dict) -> types.TextContent:
    return types.TextContent(type="text", text=json.dumps(obj))


async def main() -> None:
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="schema-server",
                server_version="1.0.0",
                capabilities=server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )


if __name__ == "__main__":
    asyncio.run(main())
