"""
Test systematique des tables "bleues" du diagramme ER (noyau evenementiel /
taches : act, evenements, taches simulateur, messagerie).

Meme fonctionnement que les autres run_eval_<domaine>.py : reutilise
directement les fonctions de run_eval.py (qui doit etre dans le meme
dossier), avec la liste de tables fixee en dur ci-dessous.

Usage:
    python run_eval_blue_tables.py
    python run_eval_blue_tables.py --limit 10
    python run_eval_blue_tables.py --sample-per-table 7
    python run_eval_blue_tables.py --resume

v2 (fix fieldnames): run_eval.run_one_query() retourne desormais les 4
composantes de confiance (rag_conf, gen_conf, sem_conf, score_strict) en
plus du score global -- le fieldnames fige de la version precedente
faisait planter csv.DictWriter ("dict contains fields not in fieldnames").
Corrections :
  - fieldnames etendu avec les 4 colonnes *_conf ;
  - si run_eval.py expose EVAL_FIELDNAMES, on l'utilise comme source
    unique de verite ;
  - garde anti-desalignement : refuse d'append dans un CSV existant a
    l'ancien en-tete au lieu de produire des lignes desalignees ;
  - extrasaction="ignore" en ceinture : une future nouvelle cle de
    run_one_query() ne fera plus planter le batch.
"""
import argparse
import csv
from pathlib import Path

import run_eval

# Tables bleues identifiees sur le diagramme ER (voir extraction du schema).
# NB: liste basee sur une lecture visuelle du diagramme -- si une table
# bleue etait coupee sur les bords de la capture, elle manque ici; il
# suffit de l'ajouter a cette liste.
BLUE_TABLES = [
    "act",
    "action_group",
    "act_stat",
    "act_task",
    "act_event",
    "move_act_task",
    "simulator_task",
    "simulator_task_trigger",
    "simulator_task_event",
    "fire_event",
    "comms_event",
    "comms_event_msg_type_assoc",
    "tx_event",
    "rx_event",
    "msg_type",
]

DEFAULT_OUTPUT = "eval_blue_tables.csv"

# Source unique de verite si run_eval.py l'expose ; sinon liste locale
# alignee sur ce que run_one_query() retourne aujourd'hui.
FIELDNAMES = getattr(run_eval, "EVAL_FIELDNAMES", [
    "table", "question", "success", "attempts", "row_count",
    "confidence", "rag_conf", "gen_conf", "sem_conf", "score_strict",
    "error", "sql", "elapsed",
])


def check_existing_header(output_path: Path) -> None:
    """Refuse d'append dans un CSV existant dont l'en-tete ne correspond
    pas a FIELDNAMES (ancien format sans les colonnes *_conf)."""
    if not output_path.exists():
        return
    with open(output_path, newline="", encoding="utf-8") as f_check:
        existing_header = next(csv.reader(f_check), [])
    if existing_header and existing_header != FIELDNAMES:
        raise SystemExit(
            f"[!] {output_path} a un en-tete different ({len(existing_header)} colonnes "
            f"vs {len(FIELDNAMES)} attendues). Renomme/supprime le fichier, ou relance "
            f"avec --output eval_blue_tables_v2.csv"
        )


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--api-url", default="http://localhost:8080")
    parser.add_argument("--api-key", default="")
    parser.add_argument("--kb", default="RAG/KB_full_update.json")
    parser.add_argument("--sample-per-table", type=int, default=2)
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--timeout", type=int, default=400)
    parser.add_argument("--output", default=DEFAULT_OUTPUT)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()

    items = run_eval.load_questions(args.kb, BLUE_TABLES, None, args.sample_per_table)
    if args.limit:
        items = items[: args.limit]

    # Signaler les tables demandees mais introuvables dans le KB -- une
    # simple faute de frappe dans BLUE_TABLES ne doit pas passer inapercue
    # (load_questions() les ignore silencieusement sinon).
    found_tables = {it["table"] for it in items}
    missing = [t for t in BLUE_TABLES if t not in found_tables]
    if missing:
        print(f"[!] {len(missing)} table(s) absentes du KB (ou sans sample_queries): {missing}\n")

    output_path = Path(args.output)
    check_existing_header(output_path)

    already_done = run_eval.load_already_tested(output_path) if args.resume else set()
    if already_done:
        items = [it for it in items if (it["table"], it["question"]) not in already_done]
        print(f"[resume] {len(already_done)} deja testee(s), ignorees.")

    print(f"Tables ciblees: {len(BLUE_TABLES)} (bleues du diagramme ER)")
    print(f"{len(items)} question(s) a tester.\n")

    file_exists = output_path.exists()

    with open(output_path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES, extrasaction="ignore")
        if not file_exists:
            writer.writeheader()

        passed = 0
        for i, item in enumerate(items, 1):
            result = run_eval.run_one_query(args.api_url, args.api_key, item["question"], args.timeout)
            row = {**item, **result}
            writer.writerow(row)
            f.flush()

            status = "OK  " if result["success"] else "FAIL"
            passed += result["success"]
            print(f"[{i}/{len(items)}] {status}  {item['table']:35}  {result['elapsed']:>6.1f}s  {item['question'][:60]}")
            if not result["success"]:
                print(f"          -> {result['error'][:150]}")

    if items:
        print(f"\n=== Tables bleues: {passed}/{len(items)} reussies ({passed/len(items)*100:.1f}%) ===")
    else:
        print("\nRien a tester.")
    print(f"Resultats ecrits dans: {output_path}")

    # Mini-breakdown par table (les colonnes *_conf detaillees sont dans le CSV)
    if items:
        from collections import defaultdict
        by_table = defaultdict(lambda: [0, 0])
        with open(output_path, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                if row["table"] in BLUE_TABLES:
                    by_table[row["table"]][1] += 1
                    if row["success"] in ("True", "1", "true"):
                        by_table[row["table"]][0] += 1
        print("\nPar table (cumul du CSV):")
        for t in BLUE_TABLES:
            if t in by_table:
                p, n = by_table[t]
                print(f"  {t:35} {p:>2}/{n:<2} ({p/n*100:>5.1f}%)")


if __name__ == "__main__":
    main()