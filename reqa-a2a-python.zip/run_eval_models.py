#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_eval_models.py -- Multi-model SQL-generator benchmark for the REQA
pipeline: evaluates the SAME question set against SEVERAL generator
models, one after the other, and produces a single comparison table.

Why sequential and not truly parallel: the Ollama server has one GPU.
Two generators loaded together do not fit in VRAM, and model swapping
between alternated requests would distort the very latency numbers the
comparison is meant to measure. Sequential runs give every model the
same, fair conditions (dedicated GPU, warm cache).

For each model in --models, the script:
  1. checks the model exists on the Ollama server (/api/tags);
  2. rewrites OLLAMA_SQL_MODEL in the .env file (backup kept);
  3. recreates the api/a2a containers (a plain restart does NOT reload
     .env -- learned the hard way);
  4. waits for the API to come back, then warms the model up (first
     load into VRAM takes 30-60 s and must not pollute the timings);
  5. runs run_eval.py on the chosen question subset;
  6. collects the scores (success rate, confidences, grounding,
     hallucination rate, latency).

At the end: model_comparison.md + model_comparison.csv, ranked by
global score, and the .env is restored to its ORIGINAL model unless
--keep-last is given.

Usage (from the project root, next to run_eval.py and .env):
  python run_eval_models.py --models codestral:latest granite4.1:30b devstral
  python run_eval_models.py --models granite4.1:30b --only q1,q5,q9,q17,q21
  python run_eval_models.py --models a b c --keep-last   # adopt the last model

Requires: run_eval.py (v4+) in the same directory, docker compose, and
the queries JSON (default mds_queries.json).
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

import run_eval  # same directory -- reuses summarize_confidences etc.



def _slug(model: str) -> str:
    return re.sub(r"[^a-zA-Z0-9]+", "_", model).strip("_")


def read_env(env_path: Path) -> dict:
    vals = {}
    for line in env_path.read_text(encoding="utf-8").splitlines():
        m = re.match(r"\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$", line)
        if m and not line.lstrip().startswith("#"):
            vals[m.group(1)] = m.group(2)
    return vals


def set_env_model(env_path: Path, model: str) -> None:
    """Rewrite OLLAMA_SQL_MODEL=... in place (first backup: .env.bak)."""
    backup = env_path.with_suffix(env_path.suffix + ".bak")
    if not backup.exists():
        backup.write_text(env_path.read_text(encoding="utf-8"),
                          encoding="utf-8")
    text = env_path.read_text(encoding="utf-8")
    new, n = re.subn(r"(?m)^(\s*OLLAMA_SQL_MODEL\s*=).*$",
                     rf"\g<1>{model}", text)
    if n == 0:
        new = text.rstrip("\n") + f"\nOLLAMA_SQL_MODEL={model}\n"
    env_path.write_text(new, encoding="utf-8")


def ollama_models(base_url: str) -> set:
    with urllib.request.urlopen(f"{base_url.rstrip('/')}/api/tags",
                                timeout=10) as r:
        data = json.load(r)
    return {m.get("name") for m in data.get("models", [])}


def warm_up(base_url: str, model: str, timeout: float = 300.0) -> float:
    """Load the model into VRAM with a trivial generation; returns the
    load+first-token time in seconds (interesting data point by itself)."""
    t0 = time.monotonic()
    req = urllib.request.Request(
        f"{base_url.rstrip('/')}/api/generate",
        data=json.dumps({"model": model, "prompt": "SELECT 1;",
                         "stream": False,
                         "options": {"num_predict": 8}}).encode(),
        headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout):
        pass
    return round(time.monotonic() - t0, 1)


def recreate_api() -> None:
    subprocess.run(["docker", "compose", "up", "-d", "--force-recreate",
                    "api", "a2a"], check=True)


def wait_api(api: str, timeout_s: float = 180.0) -> bool:
    """Poll until the FastAPI app answers (any HTTP status < 500)."""
    deadline = time.monotonic() + timeout_s
    for path in ("/docs", "/"):
        while time.monotonic() < deadline:
            try:
                req = urllib.request.Request(f"{api.rstrip('/')}{path}")
                with urllib.request.urlopen(req, timeout=5) as r:
                    if r.status < 500:
                        return True
            except urllib.error.HTTPError as e:
                if e.code < 500:
                    return True
            except Exception:
                pass
            time.sleep(3)
    return False


def run_eval_subprocess(args, model: str) -> Path:
    """Run run_eval.py for one model; returns the results JSON path."""
    out_prefix = f"eval_{_slug(model)}"
    cmd = [sys.executable, "run_eval.py",
           "--queries", args.queries, "--api", args.api,
           "--timeout", str(args.timeout), "--out", out_prefix]
    if args.only:
        cmd += ["--only", args.only]
    if args.verify_db:
        cmd += ["--verify-db", args.verify_db]
    subprocess.run(cmd)          # non-zero exit = some failures: still report
    return Path(f"{out_prefix}.json")


def summarize_model(model: str, results_path: Path, load_s: float) -> dict:
    records = json.loads(results_path.read_text(encoding="utf-8"))
    stats = run_eval.summarize_confidences(records)
    lat = [r["elapsed"] for r in records if r.get("elapsed") is not None]
    outcomes = {}
    for r in records:
        outcomes[r["outcome"]] = outcomes.get(r["outcome"], 0) + 1
    return {
        "model": model,
        "questions": stats["questions"],
        "success": stats["passed"],
        "success_rate": stats["success_rate"],
        "empty_success": outcomes.get("empty_success", 0),
        "failed": outcomes.get("failed", 0),
        "timeout": outcomes.get("timeout", 0),
        "mean_confidence": stats.get("mean_confidence"),
        "mean_grounding": stats.get("mean_grounding"),
        "hallucination_rate": stats.get("hallucination_rate"),
        "avg_latency_s": round(sum(lat) / len(lat), 1) if lat else None,
        "max_latency_s": round(max(lat), 1) if lat else None,
        "model_load_s": load_s,
        "global_score": stats.get("global_score"),
    }


def _pct(v):
    return "n/a" if v is None else f"{v * 100:.1f}%"


def write_comparison(rows: list, out_md: Path, out_csv: Path,
                     started: str) -> None:
    rows = sorted(rows, key=lambda r: (r.get("global_score") or 0),
                  reverse=True)
    with open(out_csv, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    lines = [
        "# SQL-generator model comparison", "",
        f"- Started: {started}",
        f"- Models: {', '.join(r['model'] for r in rows)}", "",
        "| Model | Success | Empty | Fail | Timeout | Conf | Grounding "
        "| Halluc. | Avg lat. | Max lat. | Load | **Global** |",
        "|---|---|---|---|---|---|---|---|---|---|---|---|",
    ]
    for r in rows:
        lines.append(
            f"| **{r['model']}** "
            f"| {r['success']}/{r['questions']} ({_pct(r['success_rate'])}) "
            f"| {r['empty_success']} | {r['failed']} | {r['timeout']} "
            f"| {_pct(r['mean_confidence'])} | {_pct(r['mean_grounding'])} "
            f"| {_pct(r['hallucination_rate'])} "
            f"| {r['avg_latency_s']}s | {r['max_latency_s']}s "
            f"| {r['model_load_s']}s | **{_pct(r['global_score'])}** |")
    lines += ["",
              "Winner = highest global score (success rate x confidence) "
              "with acceptable latency; check grounding/hallucination "
              "before adopting.", ""]
    out_md.write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Benchmark several SQL-generator models sequentially.")
    ap.add_argument("--models", nargs="+", required=True,
                    help="Ollama model names, e.g. codestral:latest "
                         "granite4.1:30b devstral")
    ap.add_argument("--queries", default="mds_queries.json")
    ap.add_argument("--only", default="",
                    help="Question subset, e.g. q1,q5,q9,q17,q21")
    ap.add_argument("--api", default="http://localhost:8080")
    ap.add_argument("--timeout", type=float, default=400.0)
    ap.add_argument("--verify-db", default="")
    ap.add_argument("--env-file", default=".env")
    ap.add_argument("--keep-last", action="store_true",
                    help="Leave the LAST tested model configured instead "
                         "of restoring the original one")
    ap.add_argument(
    "--tables",
    nargs="+",
    default=[],
    help="Restrict evaluation to questions targeting these tables"
    )

    ap.add_argument(
        "--tables-file",
        help="JSON file containing a list of tables to evaluate"
    )
    args = ap.parse_args()

    env_path = Path(args.env_file)
    if not env_path.exists():
        print(f".env not found: {env_path}", file=sys.stderr)
        return 2
    env = read_env(env_path)
    base_url = env.get("OLLAMA_BASE_URL", "http://ollama:11434")
    original_model = env.get("OLLAMA_SQL_MODEL", "")
    print(f"Ollama: {base_url} | current model: {original_model}")

    try:
        available = ollama_models(base_url)
        missing = [m for m in args.models if m not in available]
        if missing:
            print(f"NOT on the Ollama server (ollama pull first): {missing}",
                  file=sys.stderr)
            return 2
    except Exception as e:
        print(f"Warning: could not list Ollama models ({e}); continuing.")

    started = time.strftime("%Y-%m-%d %H:%M:%S")
    rows = []
    try:
        for i, model in enumerate(args.models, 1):
            print(f"\n{'=' * 66}\n[{i}/{len(args.models)}] MODEL: {model}\n"
                  f"{'=' * 66}")
            set_env_model(env_path, model)
            recreate_api()
            if not wait_api(args.api):
                print(f"API did not come back for {model} -- skipping.",
                      file=sys.stderr)
                continue
            try:
                load_s = warm_up(base_url, model)
                print(f"Model warm-up (load into VRAM): {load_s}s")
            except Exception as e:
                load_s = None
                print(f"Warm-up failed ({e}); timings for the first "
                      f"question will include the model load.")
            results = run_eval_subprocess(args, model)
            if results.exists():
                rows.append(summarize_model(model, results, load_s))
    finally:
        if not args.keep_last and original_model:
            print(f"\nRestoring original model: {original_model}")
            set_env_model(env_path, original_model)
            recreate_api()

    if not rows:
        print("No results collected.", file=sys.stderr)
        return 1
    write_comparison(rows, Path("model_comparison.md"),
                     Path("model_comparison.csv"), started)
    print("\n" + Path("model_comparison.md").read_text(encoding="utf-8"))
    print("Files: model_comparison.md  model_comparison.csv "
          "+ eval_<model>.{md,json,csv} per model")
    return 0


if __name__ == "__main__":
    sys.exit(main())