"""
Analyze the blue-tables evaluation CSV (eval_blue_tables.csv) and produce
the same visual report as the inline chart: per-table stacked bars
(passed / quality failures / server-outage failures), failure-category
breakdown, and the scoring formulas.

Metrics:
    per-table score       = passed / questions asked on that table
    raw global score      = sum(passed) / sum(questions)
    adjusted global score = sum(passed) / (sum(questions) - outage failures)

Usage:
    python analyze_blue_tables_eval.py                          # reads eval_blue_tables.csv
    python analyze_blue_tables_eval.py --input other.csv
    python analyze_blue_tables_eval.py --output report.png
"""
import argparse
import csv
from collections import defaultdict

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# ---------------------------------------------------------------------------
# Failure categorization -- mirrors what we observed in the real run
# ---------------------------------------------------------------------------

def categorize_failure(error: str) -> str:
    """
    Classify a failure row into one of two big families, and quality
    sub-categories:

    - "infra"  : the remote Ollama server was unreachable / circuit breaker
                 open. NOT a pipeline-quality failure -- these questions were
                 never actually evaluated.
    - quality  : the pipeline genuinely produced a bad answer, split into
                 the sub-categories seen in the run.
    """
    err = (error or "").lower()

    if "circuit breaker open" in err or "connection refused" in err or "httpconnectionpool" in err:
        return "infra"
    if "doesn't exist" in err and ("table1" in err or "main_table" in err
                                    or "your_table_name" in err or "activities" in err):
        return "hallucinated_table"
    if "doesn't exist" in err:
        return "hallucinated_table"
    if "not a select statement" in err:
        return "not_select"
    if "forbidden keyword" in err:
        return "forbidden_keyword"
    if "parse error" in err or "syntax" in err:
        return "syntax_error"
    return "other"


CATEGORY_LABELS = {
    "hallucinated_table": 'Hallucinated table ("table1", ...)',
    "syntax_error":       "SQL syntax error",
    "not_select":         "Not a SELECT",
    "forbidden_keyword":  "Forbidden keyword",
    "other":              "Other",
}

COLORS = {
    "passed":  "#1baf7a",
    "quality": "#e34948",
    "infra":   "#898781",
    "cats":    ["#e34948", "#eb6834", "#eda100", "#4a3aa7", "#2a78d6"],
}


# ---------------------------------------------------------------------------
# CSV parsing + per-table aggregation
# ---------------------------------------------------------------------------

def load_results(csv_path: str):
    per_table = defaultdict(lambda: {"passed": 0, "quality": 0, "infra": 0})
    cat_counts = defaultdict(int)
    conf_all, conf_passed = [], []

    with open(csv_path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            table = (row.get("table") or "").strip()
            if not table:
                continue  # trailing empty line

            success = (row.get("success") or "").strip().lower() == "true"
            cat = None if success else categorize_failure(row.get("error", ""))

            if success:
                per_table[table]["passed"] += 1
            elif cat == "infra":
                per_table[table]["infra"] += 1
            else:
                per_table[table]["quality"] += 1
                cat_counts[cat] += 1

            # Global confidence: only over questions that were actually
            # evaluated (outage rows have no meaningful confidence -- the
            # pipeline never ran). Failed-but-evaluated questions count
            # with their real confidence (0.0), pulling the average down
            # honestly rather than being silently skipped.
            if cat != "infra":
                try:
                    c = float(row.get("confidence"))
                except (TypeError, ValueError):
                    continue
                conf_all.append(c)
                if success:
                    conf_passed.append(c)

    confidence = {
        "mean_all": sum(conf_all) / len(conf_all) if conf_all else 0.0,
        "mean_passed": sum(conf_passed) / len(conf_passed) if conf_passed else 0.0,
        "n_evaluated": len(conf_all),
        "n_passed": len(conf_passed),
    }
    return dict(per_table), dict(cat_counts), confidence


# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------

def print_summary(per_table: dict, cat_counts: dict, confidence: dict) -> None:
    total = passed = infra = 0
    print(f"{'table':32} {'passed':>6} {'quality':>8} {'outage':>7} {'total':>6} {'score':>7}")
    # sort: best score first, outage-only tables last
    def sort_key(item):
        t, s = item
        tot = s["passed"] + s["quality"] + s["infra"]
        return (-(s["passed"] / tot if tot else 0), t)

    for t, s in sorted(per_table.items(), key=sort_key):
        tot = s["passed"] + s["quality"] + s["infra"]
        score = s["passed"] / tot * 100 if tot else 0
        print(f"{t:32} {s['passed']:>6} {s['quality']:>8} {s['infra']:>7} {tot:>6} {score:>6.1f}%")
        total += tot; passed += s["passed"]; infra += s["infra"]

    raw = passed / total * 100 if total else 0
    adj = passed / (total - infra) * 100 if (total - infra) else 0
    print("-" * 72)
    print(f"raw global score      = {passed} / {total} = {raw:.1f}%")
    print(f"adjusted global score = {passed} / ({total} - {infra}) = {adj:.1f}%   (excluding server outage)")
    print(f"global confidence     = {confidence['mean_all']:.4f}   "
          f"(mean over {confidence['n_evaluated']} evaluated questions, failures counted as 0)")
    print(f"confidence of passes  = {confidence['mean_passed']:.4f}   "
          f"(mean over the {confidence['n_passed']} passed questions only)")
    print()
    print("Quality failures by category:")
    for cat, n in sorted(cat_counts.items(), key=lambda kv: -kv[1]):
        print(f"  {CATEGORY_LABELS.get(cat, cat):40} {n}")


def plot_report(per_table: dict, cat_counts: dict, confidence: dict, output: str) -> None:
    # order tables by score desc, outage-heavy last (same as printed summary)
    def sort_key(item):
        t, s = item
        tot = s["passed"] + s["quality"] + s["infra"]
        return (-(s["passed"] / tot if tot else 0), t)

    ordered = sorted(per_table.items(), key=sort_key)
    names, passed, quality, infra, labels = [], [], [], [], []
    for t, s in ordered:
        tot = s["passed"] + s["quality"] + s["infra"]
        names.append(t)
        passed.append(s["passed"]); quality.append(s["quality"]); infra.append(s["infra"])
        labels.append(f"{t}  {s['passed']}/{tot} ({s['passed']/tot*100:.0f}%)")

    total_q = sum(passed) + sum(quality) + sum(infra)
    raw = sum(passed) / total_q * 100
    adj = sum(passed) / (total_q - sum(infra)) * 100

    fig, (ax1, ax2) = plt.subplots(
        2, 1, figsize=(11, 10), gridspec_kw={"height_ratios": [3.2, 1]}
    )
    fig.suptitle(
        "Blue tables evaluation — ER diagram event/task core\n"
        f"raw global = {sum(passed)}/{total_q} = {raw:.1f}%    |    "
        f"adjusted (excl. outage) = {sum(passed)}/{total_q - sum(infra)} = {adj:.1f}%\n"
        f"global confidence = {confidence['mean_all']:.2f} (failures as 0)    |    "
        f"confidence of passed answers = {confidence['mean_passed']:.2f}",
        fontsize=11,
    )

    y = range(len(names))[::-1]
    ax1.barh(y, passed, color=COLORS["passed"], label=f"Passed ({sum(passed)})")
    ax1.barh(y, quality, left=passed, color=COLORS["quality"], label=f"Quality failures ({sum(quality)})")
    left2 = [p + q for p, q in zip(passed, quality)]
    ax1.barh(y, infra, left=left2, color=COLORS["infra"], label=f"Server outage ({sum(infra)})")
    ax1.set_yticks(list(y))
    ax1.set_yticklabels(labels, fontsize=8.5)
    ax1.set_xlabel("questions (7 sample_queries per table)")
    ax1.legend(loc="lower right", fontsize=8.5)
    ax1.set_title("per-table score = passed / questions asked", fontsize=10, loc="left")

    cats_sorted = sorted(cat_counts.items(), key=lambda kv: -kv[1])
    cat_names = [CATEGORY_LABELS.get(c, c) for c, _ in cats_sorted]
    cat_vals = [n for _, n in cats_sorted]
    ax2.barh(range(len(cat_names))[::-1], cat_vals,
             color=COLORS["cats"][: len(cat_names)])
    ax2.set_yticks(range(len(cat_names))[::-1])
    ax2.set_yticklabels(cat_names, fontsize=9)
    ax2.set_title(f"Quality failures by category ({sum(cat_vals)} total)", fontsize=10, loc="left")

    plt.tight_layout(rect=[0, 0, 1, 0.94])
    plt.savefig(output, dpi=150, bbox_inches="tight")
    print(f"\nChart written to: {output}")


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--input", default="eval_blue_tables.csv")
    parser.add_argument("--output", default="eval_blue_tables_report.png")
    args = parser.parse_args()

    per_table, cat_counts, confidence = load_results(args.input)
    print_summary(per_table, cat_counts, confidence)
    plot_report(per_table, cat_counts, confidence, args.output)


if __name__ == "__main__":
    main()
