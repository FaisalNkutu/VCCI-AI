from __future__ import annotations

import os
import time

import requests
import streamlit as st
import pandas as pd
from datetime import datetime



from agent.renderer import (
    build_column_metadata,
    _humanize_header,
    apply_time_formatting,
)

REQA_API_HOST = os.environ.get("REQA_API_HOST", "localhost")
REQA_API_PORT = os.environ.get("REQA_API_PORT", "8080")
REQA_API_KEY = os.environ.get("API_KEY", "")

# Connection timeout constants
API_HEALTH_TIMEOUT = 5
API_QUERY_TIMEOUT = 400
API_HEALTH_CHECK_TTL = 30


@st.cache_data(ttl=API_HEALTH_CHECK_TTL, show_spinner=False)
def check_api_health(url: str, api_key: str = "") -> dict:
    """Check API health endpoint with proper error handling."""
    try:
        headers = {"X-API-Key": api_key} if api_key else {}
        r = requests.get(
            f"{url}/health",
            headers=headers,
            timeout=API_HEALTH_TIMEOUT,
        )
        r.raise_for_status()
        return r.json()
    except requests.exceptions.ConnectionError as e:
        return {"_error": f"Connection failed: {str(e)[:80]}"}
    except requests.exceptions.Timeout:
        return {"_error": "API timeout (>5s) — check if API is running"}
    except requests.exceptions.HTTPError as e:
        return {"_error": f"HTTP {e.response.status_code}: {str(e)[:80]}"}
    except Exception as e:
        return {"_error": str(e)[:100]}


# ──────────────────────────────────────────────────────────────────────────────
# CONFIG
# ──────────────────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="PIPELINE-REQA-SQL-MCP",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>

/*  */
.stApp {
    background-color: white;
    color: blue;
    text-color: black;
}

/* Sidebar */
[data-testid="stSidebar"] {
    background-color: #f8f9fa;
}

/* Texte général */
html, body, [class*="css"] {
    color: white;
}

/* Inputs */
.stTextInput input,
.stTextArea textarea {
    background-color: white;
    color: gray;
    border: 1px solid #d0d0d0;
}

/* Selectbox */
.stSelectbox div[data-baseweb="select"] {
    background-color: white;
    color: white;
}

/* Radio buttons */
.stRadio label {
    color: black !important;
}

/* Tabs */
button[data-baseweb="tab"] {
    color: black !important;
}

/* Dataframe */
[data-testid="stDataFrame"] {
    background-color: white;
}

/* Expander */
.streamlit-expanderHeader {
    background-color: #f5f5f5;
    color: white;
}

/* Code blocks */
pre {
    background-color: #f8f8f8 !important;
}

.stButton > button {
    background: #F3F4F6 !important;
}

header[data-testid="stHeader"]{
    background-color: #F3F4F6;
}

div[data-testid="stButton"] button[kind="primary"] p {
            color: green !important;
            font-weight: bold; /* Optionnel : pour rendre le texte plus visible */
        }
        
div[data-testid="stRadio"] {
            display: none !important;
        }

</style>
""", unsafe_allow_html=True)


# ──────────────────────────────────────────────────────────────────────────────
# SESSION STATE
# ──────────────────────────────────────────────────────────────────────────────
if "history" not in st.session_state:
    st.session_state.history = []
if "last_result" not in st.session_state:
    st.session_state.last_result = None
if "question_input" not in st.session_state:
    st.session_state.question_input = ""

# ──────────────────────────────────────────────────────────────────────────────
# SIDEBAR
# ──────────────────────────────────────────────────────────────────────────────
import traceback


with st.sidebar:
    st.title("⚙️ Configuration")
    st.divider()

    api_url = st.text_input(
        "API URL",
        value=f"http://{REQA_API_HOST}:{REQA_API_PORT}",
        help="FastAPI endpoint URL",
    )

    mode = st.radio(
        "Execution mode",
        ["v1 — Mono-Agent-external", "v2 — Multi-Agent + MCP"],
        index=0,
        help="v1: Single agent pipeline | v2: Multi-agent with MCP",
    )
    use_v2 = mode.startswith("v2")

    st.divider()

    # ── HEALTH CHECK ──────────────────────────────────────────────────────────
    st.subheader("API Status")

    info = check_api_health(api_url, REQA_API_KEY)

    if "_error" in info:
        st.warning(f"⚠️ API Unreachable\n\n```\n{info['_error']}\n```")
        st.caption(
            "💡 Tip: Ensure the API container is running with `docker compose ps`"
        )
    else:
        col1, col2 = st.columns([3, 1])
        with col1:
            st.success("✓ Connected to API")
            st.caption(
                f"**Provider:** `{info.get('llm_provider', '?')}` | "
                f"**Models:** `{info.get('ollama_sql_model', '?')}`"
            )
        with col2:
            if st.button("🔄 Refresh", use_container_width=True):
                st.cache_data.clear()
                st.rerun()

    st.divider()

    # ── INDEXATION ────────────────────────────────────────────────────────────
    st.subheader("📚 Schema Indexation")

    # Schema selection is centralized in .env.  This prevents the UI from
    # rebuilding Qdrant with a different schema than the API/A2A services.
    ddl_file = os.getenv("SCHEMA_FILE", "calian_full_nodata.sql")
    st.caption(f"Configured schema from `.env`: `{ddl_file}`")

    # Explicit, opt-in override for the mass-deletion safety guard in
    # ingest.py's reconcile_data(). kb_full_in is always reloaded fresh
    # from the full curated KB_full_update.json, not from whatever a
    # *previous* ingest run indexed -- so a dataset that legitimately has
    # fewer TABLES than the full reference (not just fewer rows of data,
    # e.g. "Calian Minimal" vs "Calian Full") looks, from pure table-count
    # arithmetic, identical to someone having pointed at the wrong file or
    # an accidentally-incomplete SQL dump. Left unchecked by default so
    # the safety guard still protects against genuine mistakes; the person
    # indexing a deliberately smaller dataset ticks this explicitly rather
    # than the guard being silently bypassed or a legitimate smaller
    # dataset being silently rejected.
    allow_mass_delete = st.checkbox(
        "Allow removing many tables from the KB",
        value=False,
        help=(
            "Tick this if the selected dataset intentionally has far fewer "
            "tables than the full reference schema (e.g. indexing 'Minimal' "
            "after 'Full'). Leave unchecked otherwise -- it's the safety "
            "guard against accidentally indexing the wrong/an incomplete "
            "SQL file."
        ),
    )

    col_idx1, col_idx2 = st.columns(2)

    with col_idx1:
        if st.button("⚡ Index", use_container_width=True):
            try:
                with st.spinner("Indexing schema..."):
                    from ingest import ingest_from_sql_file

                    ingest_from_sql_file(
                        ddl_file,
                        allow_mass_delete=allow_mass_delete,
                    )
                st.success("✓ Schema indexed successfully")
            except FileNotFoundError as e:
                st.error(f"FileNotFoundError: {e}")
                st.code(traceback.format_exc())
            except RuntimeError as e:
                st.error(f"Safety abort: {str(e)[:300]}")
            except Exception as e:
                st.error(f"Index error: {str(e)[:100]}")

    with col_idx2:
        if st.button("♻️ Re-index", use_container_width=True):
            try:
                with st.spinner("Re-indexing schema..."):
                    from ingest import ingest_from_sql_file

                    ingest_from_sql_file(
                        ddl_file,
                        recreate_collection=True,
                        allow_mass_delete=allow_mass_delete,
                    )
                st.success("✓ Schema re-indexed successfully")
            except FileNotFoundError:
                st.error(f"File not found: {ddl_file}")
            except RuntimeError as e:
                st.error(f"Safety abort: {str(e)[:300]}")
            

            except Exception as e:
                st.error(f"Re-index error: {e}")
                st.code(traceback.format_exc())

    st.divider()
    st.caption("**REQA-SQL v2.0** — Text-to-SQL Multi-Agent + MCP")

# ──────────────────────────────────────────────────────────────────────────────
# MAIN
# ──────────────────────────────────────────────────────────────────────────────
st.title("🔍 PIPELINE-REQA-SQL-MCP")
st.caption("**Ask a question** → SQL → Execution → Explanation")

tab_query, tab_schema = st.tabs(["💬 Query", "🗂️ Schema Explorer"])

with tab_query:
    input_col, result_col = st.columns([2, 3], gap="large")

    # ──────────────────────────────────────────────────────────────────────────────
    # INPUT SECTION
    # ──────────────────────────────────────────────────────────────────────────────
    with input_col:
        st.subheader("💬 These are some examples of quick questions ...")

        examples = [
            "How many locations are recorded in this exercise?",
            "Show activity events with their category, time, and position.",
            "Count activity tasks by task category",
            "Which simulated entities are involved in each activity? Show the activity, entity, entity category, and its role in the activity",
            "Show the current holdings of 5AMB 3 Surg Coy OC",
            "Show 20 holding records with the holding ID, object item ID, object type ID, operational count, total quantity, and recorded time",
            "Show a summary of all fire events grouped by fire type",
            "What units are using the \"M777 Group\" howitzer in this exercise ?"
        ]

        st.caption("")
        for ex in examples:
            if st.button(ex, use_container_width=True, key=f"ex_{ex[:20]}"):
                st.session_state.question_input = ex

        question = st.text_area(
            "**Please, enter your question in the text area just bellow**",
            key="question_input",
            height=120,
            placeholder="Ask your question about the database...",
            help="Use natural language to query the database",
        )

        # Block submission clearly when the API is unreachable, rather than
        # letting the user wait through a spinner only to get an error --
        # mirrors the reference project's `services_ok` check before running
        # the pipeline. Reuses st.warning (already used elsewhere in this
        # file for the same purpose), so the visual language is unchanged.
        api_healthy = "_error" not in info
        if not api_healthy:
            st.warning("⚠️ API is currently unreachable — fix the connection (see sidebar) before submitting.")

        submit = st.button(
            "▶ Submit your request",
            type="primary",
            use_container_width=True,
            disabled=not question.strip() or not api_healthy,
        )

    # ──────────────────────────────────────────────────────────────────────────────
    # RESULTS SECTION
    # ──────────────────────────────────────────────────────────────────────────────
    with result_col:
        st.subheader("📊 Results")

        if submit and question.strip():
            headers = {"X-API-Key": REQA_API_KEY} if REQA_API_KEY else {}
            t0 = time.time()

            if use_v2:
                # v2 (multi-agent orchestrator) has no progress_callback
                # support yet -- unchanged single blocking call, same error
                # handling as before.
                with st.spinner("Processing your question..."):
                    try:
                        resp = requests.post(
                            f"{api_url}/v2/query",
                            json={"question": question.strip()},
                            headers=headers,
                            timeout=API_QUERY_TIMEOUT,
                        )
                        resp.raise_for_status()
                        data = resp.json()
                        elapsed = time.time() - t0
                    except requests.exceptions.Timeout:
                        st.error("❌ API request timeout (>400s)")
                        st.stop()
                    except requests.exceptions.ConnectionError:
                        st.error("❌ Cannot reach API — check if it's running")
                        st.stop()
                    except requests.exceptions.HTTPError as e:
                        status = e.response.status_code if e.response is not None else "?"
                        st.error(f"❌ API returned HTTP {status}: {str(e)[:150]}")
                        st.stop()
                    except ValueError:
                        st.error("❌ API returned an unreadable (non-JSON) response — check the API logs")
                        st.stop()
                    except Exception as e:
                        st.error(f"❌ API error: {str(e)[:150]}")
                        st.stop()

            else:
                # v1 — start the job, then poll for live progress instead of
                # blocking behind a single opaque spinner for up to 400s.
                # Falls back to the same error categories as before for both
                # the initial /query/start call and each /query/status poll.
                _STAGE_LABELS = {
                    "starting":              "Starting…",
                    "schema_rag":            "Retrieving relevant tables (RAG)…",
                    "intent_classification": "Classifying your question…",
                    "sql_generation":        "Generating SQL…",
                    "static_check":          "Validating SQL syntax…",
                    "explain":               "Checking query plan (EXPLAIN)…",
                    "execution":             "Executing query…",
                    "rendering":             "Formatting the answer…",
                    "error":                 "An error occurred…",
                }

                progress_placeholder = st.empty()
                progress_placeholder.info("⏳ Starting…")

                try:
                    start_resp = requests.post(
                        f"{api_url}/query/start",
                        json={"question": question.strip()},
                        headers=headers,
                        timeout=API_HEALTH_TIMEOUT,
                    )
                    start_resp.raise_for_status()
                    job_id = start_resp.json()["job_id"]

                    data = None
                    while True:
                        if time.time() - t0 > API_QUERY_TIMEOUT:
                            raise requests.exceptions.Timeout()

                        status_resp = requests.get(
                            f"{api_url}/query/status/{job_id}",
                            headers=headers,
                            timeout=API_HEALTH_TIMEOUT,
                        )
                        status_resp.raise_for_status()
                        status_data = status_resp.json()

                        stage = status_data.get("stage") or {}
                        label = _STAGE_LABELS.get(stage.get("stage"), "Processing…")
                        if "attempt" in stage:
                            label += f" (attempt {stage['attempt']}/{stage.get('of', '?')})"
                        progress_placeholder.info(f"⏳ {label}")

                        if status_data.get("status") in ("done", "error"):
                            data = status_data.get("result") or {}
                            break

                        time.sleep(1.0)

                    elapsed = time.time() - t0
                    progress_placeholder.empty()

                except requests.exceptions.Timeout:
                    progress_placeholder.empty()
                    st.error("❌ API request timeout (>400s)")
                    st.stop()
                except requests.exceptions.ConnectionError:
                    progress_placeholder.empty()
                    st.error("❌ Cannot reach API — check if it's running")
                    st.stop()
                except requests.exceptions.HTTPError as e:
                    progress_placeholder.empty()
                    status = e.response.status_code if e.response is not None else "?"
                    st.error(f"❌ API returned HTTP {status}: {str(e)[:150]}")
                    st.stop()
                except ValueError:
                    progress_placeholder.empty()
                    st.error("❌ API returned an unreadable (non-JSON) response — check the API logs")
                    st.stop()
                except Exception as e:
                    progress_placeholder.empty()
                    st.error(f"❌ API error: {str(e)[:150]}")
                    st.stop()

            st.session_state.last_result = {
                "question": question,
                "data": data,
                "mode": mode,
                "elapsed": elapsed,
            }
            st.session_state.history.insert(0, st.session_state.last_result)
            st.session_state.history = st.session_state.history[:20]

        # ── DISPLAY RESULTS ────────────────────────────────────────────────────────
        if st.session_state.last_result:
            entry = st.session_state.last_result
            data = entry["data"]

            # Status indicator
            if data.get("success"):

                st.success("✅ Query executed successfully")

            elif "success" not in data:

                st.error(
                    f"❌ Unexpected API response format: {str(data)[:200]}"
                )

            else:

                error_code = str(data.get("error", ""))

                if (
                    "UNSATISFIABLE_CORRELATION" in error_code
                    or error_code.startswith("IMPOSSIBLE:")
                    ):

                    st.info(
                        "🛡️ Query intentionally rejected to prevent "
                        "an unreliable or hallucinated answer."
                    )

                else:

                    st.error(
                        "❌ Query failed to execute"
                    )
            # ── Auto-answer transparency badge (v2.2) ────────────────────────────
            # Suggestions are no longer shown: on failure, pipeline.py's
            # _try_auto_answer() silently retries with LLM reformulations and
            # serves the first one that succeeds AND clears the confidence
            # gate (REQA_AUTO_ANSWER_MIN_CONF). The only UI trace is this
            # one-line badge, reading the keys the pipeline actually writes
            # (explanation["answered_reformulation"] / ["original_question"]).
            _expl = data.get("explanation") or {}
            _answered_ref = _expl.get("answered_reformulation")
            if _answered_ref:
                _conf_badge = ((_expl.get("confidence") or {}).get("score"))
                st.caption(
                    "🔁 Answered via an automatically rephrased version of your question"
                    + (f" (confidence {_conf_badge * 100:.0f}%)" if _conf_badge is not None else "")
                    + f": *{_answered_ref}*"
                )

            # ── Auto-answer transparency badge (v2.2) ────────────────────────────
            # Suggestions are no longer shown: on failure, pipeline.py's
            # _try_auto_answer() silently retries with LLM reformulations and
            # serves the first one that succeeds AND clears the confidence
            # gate (REQA_AUTO_ANSWER_MIN_CONF). The only UI trace is this
            # one-line badge, reading the keys the pipeline actually writes
            # (explanation["answered_reformulation"] / ["original_question"]).
            _expl = data.get("explanation") or {}
            _answered_ref = _expl.get("answered_reformulation")
            if _answered_ref:
                _conf_badge = ((_expl.get("confidence") or {}).get("score"))
                st.caption(
                    "🔁 Answered via an automatically rephrased version of your question"
                    + (f" (confidence {_conf_badge * 100:.0f}%)" if _conf_badge is not None else "")
                    + f": *{_answered_ref}*"
                )

            # Metrics
            col1, col2, col3, col4 = st.columns(4)
            col1.metric(
                "Rows",
                data.get("row_count", 0),
                help="Number of rows returned",
            )
            col2.metric(
                "Attempts",
                data.get("attempts", 0),
                help="SQL generation attempts",
            )
            col3.metric(
                "Time",
                f"{entry['elapsed']:.2f}s",
                help="Total execution time",
            )
            col4.metric(
                "Mode",
                "v1" if "v1" in entry["mode"] else "v2",
                help="Execution pipeline mode",
            )

            # ── Confidence banner ────────────────────────────────────────────────
            # Uses PipelineResult.explanation["confidence"] (computed in
            # pipeline.py's _compute_confidence()). Shows the global score,
            # per-component chips, and an expander with a value-dependent
            # interpretation + the successive control steps behind each score.
            # Degrades gracefully: components absent from the API response
            # (older pipeline versions) simply don't appear.
            explanation = data.get("explanation") or {}
            confidence = explanation.get("confidence") or {}
            conf_score = confidence.get("score")

            error_code = str(data.get("error", ""))
            answer_text = str(data.get("answer", ""))

            is_rejected_query = (
                "UNSATISFIABLE_CORRELATION" in error_code
                or error_code.startswith("IMPOSSIBLE:")
                or "cannot be answered" in answer_text.lower()
            )

            if is_rejected_query:

                st.info(
                    "🛡️ Confidence score not applicable because "
                    "the query was rejected before a reliable answer "
                    "could be generated."
                )

            elif conf_score is not None:
                pct = conf_score * 100
                if pct >= 80:
                    acc_cls, acc_label = "acc-high", "High confidence"
                elif pct >= 60:
                    acc_cls, acc_label = "acc-mid", "Medium confidence"
                else:
                    acc_cls, acc_label = "acc-low", "Low confidence"
                attempts_n = data.get("attempts", 1)

                # --- value-dependent one-line interpretation per component ---
                def _interpret(key, v):
                    if v is None:
                        return ""
                    if key == "rag_conf":
                        if v >= 0.8:  return "Retrieved tables match the question wording closely."
                        if v >= 0.5:  return "Reasonable schema match — the right tables were most likely found."
                        return "Weak raw similarity — tables may have been rescued via example-question matching; retrieval is the thing to double-check."
                    if key == "gen_conf":
                        if v >= 0.99: return "SQL accepted on the first attempt — strongest reliability signal."
                        if v >= 0.6:  return "One correction was needed before the SQL passed all checks."
                        if v > 0:     return "Two corrections were needed — treat this answer with extra care."
                        return "All attempts failed."
                    if key == "sem_conf":
                        if v >= 0.99: return "No inconsistency detected between question intent and SQL (note: 'nothing manifestly wrong', not 'proven correct')."
                        if v >= 0.5:  return "Some detected intents are NOT reflected in the SQL (e.g. missing COUNT/AVG/SUM, or duration not computed)."
                        return "Major mismatch — the SQL likely doesn't target the right table or ignores the question's intent."
                    if key == "score_strict":
                        gap = (conf_score - v) if conf_score is not None else 0
                        if gap > 0.25: return f"Diverges from the main score by {gap*100:.0f} pts — semantic doubt: audit this answer."
                        return "Consistent with the main score — no semantic red flag."
                    return ""

                # --- successive control steps feeding each component ---
                _steps = {
                    "rag_conf":     "Steps: question embedding → cosine similarity per table → multi-query RRF fusion → sample-query boost / rescue → cross-encoder rerank → mean cosine of retained tables.",
                    "gen_conf":     "Checkpoints each attempt must clear: ① LLM call → ② static check (syntax, forbidden keywords, table & column names) → ③ EXPLAIN dry-run (MariaDB) → ④ real execution. Each retry consumed costs 1/3 of this score.",
                    "sem_conf":     "Checks: target table present in FROM/JOIN + every intent detected in the question is satisfied in the SQL (COUNT, AVG, MAX/MIN, SUM, recency, duration, DISTINCT, grouping — synonym-aware).",
                    "score_strict": "Formula: (0.4·RAG + 0.6·Gen) × Sem — the semantic score acts as a proportional veto instead of a weighted vote.",
                }

                _component_defs = [
                    ("rag_conf",     "RAG",    "Was the right schema found?"),
                    ("gen_conf",     "Gen",    "Did the LLM get it right immediately?"),
                    ("sem_conf",     "Sem",    "Does the SQL answer the question?"),
                    ("score_strict", "Strict", "Veto-form aggregate"),
                ]
                _present = [(k, lbl, q) for k, lbl, q in _component_defs
                            if confidence.get(k) is not None]

                chips = " · ".join(
                    f"{lbl} {confidence[k] * 100:.0f}%" for k, lbl, _ in _present
                )
                st.markdown(
                    f'<div class="{acc_cls}"><b>{acc_label}</b> ({pct:.0f}%) — '
                    f'0.3·RAG + 0.4·Gen + 0.3·Sem '
                    f'({"1st try" if attempts_n == 1 else f"{attempts_n} attempts"})'
                    + (f'<br><small>{chips}</small>' if chips else "")
                    + '</div>',
                    unsafe_allow_html=True,
                )

                if _present:
                    with st.expander("📊 Confidence breakdown — what each score means", expanded=False):
                        cols = st.columns(len(_present) + 1)
                        cols[0].metric(
                            "Global score", f"{pct:.0f}%",
                            help="0.3 × rag_conf + 0.4 × gen_conf + 0.3 × sem_conf — forced to 0 when all attempts fail",
                        )
                        for i, (k, lbl, q) in enumerate(_present, start=1):
                            cols[i].metric(lbl, f"{confidence[k] * 100:.0f}%", help=q)

                        for k, lbl, q in _present:
                            v = float(confidence[k])
                            st.progress(min(max(v, 0.0), 1.0), text=f"{lbl} — {q}")
                            interp = _interpret(k, v)
                            if interp:
                                st.markdown(f"&nbsp;&nbsp;💬 *{interp}*")
                            st.caption(f"🧭 {_steps.get(k, '')}")

            # ── XAI — SQL rationale & counterfactuals ────────────────────────────
            # Renders explanation["xai"] built by pipeline._build_xai():
            # deterministic table-usage/counterfactual notes (always present
            # on new pipeline versions) + optional LLM self-explanation of
            # the SQL (only when REQA_XAI_RATIONALE=1 on the API side).
            xai = explanation.get("xai") or {}
            if xai:
                with st.expander("🧠 Why this SQL — rationale & counterfactuals", expanded=False):
                    rationale = xai.get("sql_rationale")
                    if rationale:
                        st.markdown("**LLM self-explanation of the query:**")
                        st.markdown(rationale)
                        st.caption("Generated by the model itself — treat as a plausible narrative, not ground truth.")
                        st.divider()

                    usage = xai.get("table_usage") or []
                    if usage:
                        st.markdown("**Retrieved tables → actually used in the SQL?**")
                        _origin_labels = {
                            "vector": "vector similarity",
                            "boost/rescue": "sample-query boost / rescue",
                            "fk-expansion/lexical": "FK expansion / lexical fallback",
                        }
                        for u in usage:
                            icon = "🟢" if u.get("used_in_sql") else "⚪"
                            st.markdown(
                                f"{icon} `{u.get('name', '?')}` — "
                                f"{'**used**' if u.get('used_in_sql') else 'not used'} · "
                                f"raw similarity {u.get('cosine', 0) * 100:.0f}% · "
                                f"retrieved via {_origin_labels.get(u.get('origin'), u.get('origin', '?'))}"
                            )

                    cfs = xai.get("counterfactuals") or []
                    if cfs:
                        st.markdown("**Counterfactual notes:**")
                        for c in cfs:
                            st.markdown(f"- {c}")

            st.divider()

            # ── Pipeline steps (per-attempt detail) ──────────────────────────────
            attempts_detail = explanation.get("attempts") or []
            if attempts_detail:
                with st.expander("🔍 Pipeline attempts", expanded=False):
                    for a in attempts_detail:
                        ok = a.get("failed_at") is None
                        icon = "✅" if ok else "❌"
                        stage = a.get("failed_at") or "success"
                        st.markdown(
                            f"{icon} **Attempt {a.get('n', '?')}** — stage `{stage}`",
                        )
                        if not ok and a.get("error"):
                            st.caption(a["error"][:300])

            # ── RAG — tables retrieved with relevance scores ─────────────────────
            retrieved = explanation.get("retrieved_tables") or []
            if retrieved:
                with st.expander(f"🔎 Tables retrieved by RAG ({len(retrieved)})", expanded=False):
                    for t in retrieved:
                        c_name, c_bar = st.columns([2, 3])
                        with c_name:
                            st.markdown(f"**`{t.get('name', '?')}`**")
                            st.caption(t.get("domain", "") or t.get("source", ""))
                        with c_bar:
                            score = float(t.get("score", 0) or 0)
                            st.progress(min(max(score, 0.0), 1.0), text=f"fused retrieval score {score * 100:.1f}%")

            st.divider()

            # Results display
            if data.get("rows"):
                
                ### Inspection du data content ###
                
                used_tables = [
                    t["name"]
                    for t in data["explanation"]["xai"]["table_usage"]
                    if t["used_in_sql"]
                ]
                
                
               #  st.write(
               #        data["explanation"]
               #     )

                
               # st.markdown("### Tables used")

               # for table in used_tables:
               #     st.markdown(f"- {table}")
                
                ### Fin Inspection du data content ###

                #df = pd.DataFrame(data["rows"])

                #df = apply_display_names(df)
                
                st.markdown("### 📋 Query Results")
                
                ######
                
                df = pd.DataFrame(data["rows"])

                used_tables = [
                    t["name"]
                    for t in data["explanation"]["xai"]["table_usage"]
                    if t["used_in_sql"]
                ]

                column_metadata = build_column_metadata(
                    used_tables
                )

                #
                # convert timestamps and durations
                #
                df = apply_time_formatting(df)

                #
                # apply business labels
                #
                df.columns = [
                    _humanize_header(
                        column,
                        column_metadata
                    )
                    for column in df.columns
                ]


                st.dataframe(
                    df,
                    use_container_width=True,
                    height=300
                )
                
                
                
                #st.dataframe(data["rows"], use_container_width=True, height=300)
            elif data.get("answer"):
                st.markdown("### 📝 Answer")
                st.markdown(data.get("answer", ""))

            # SQL visualization
            if data.get("sql"):
                with st.expander("🗄️ Generated SQL", expanded=False):
                    st.code(data["sql"], language="sql")

            # Multi-agent trace
            if data.get("trace") and entry["mode"].startswith("v2"):
                with st.expander("🤖 Agent Trace", expanded=False):
                    for i, step in enumerate(data["trace"], 1):
                        st.markdown(f"**Step {i}:** `{step}`")

            # Error details
            if not data.get("success") and data.get("error"):
                with st.expander("⚠️ Error Details", expanded=False):
                    st.code(data["error"], language="plaintext")

        else:
            st.info("💡 Submit a question to begin")

    # ──────────────────────────────────────────────────────────────────────────────
    # HISTORY SECTION
    # ──────────────────────────────────────────────────────────────────────────────
    if st.session_state.history:
        st.divider()
        st.subheader("📜 Query History")

        col_hist_clear, col_hist_count = st.columns([1, 3])
        with col_hist_clear:
            if st.button("🗑️ Clear", use_container_width=True):
                st.session_state.history = []
                st.session_state.last_result = None
                st.rerun()

        with col_hist_count:
            st.caption(f"**{len(st.session_state.history)}** queries in history")

        for idx, h in enumerate(st.session_state.history, 1):
            d = h["data"]
            question_preview = h["question"][:60] + (
                "..." if len(h["question"]) > 60 else ""
            )
            status_icon = "✅" if d.get("success") else "❌"

            with st.expander(f"{status_icon} **{idx}.** {question_preview}"):
                col_time, col_mode, col_rows = st.columns(3)
                col_time.caption(f"⏱️ {h['elapsed']:.2f}s")
                col_mode.caption(f"🔧 {h['mode'].split('—')[0].strip()}")
                col_rows.caption(f"📊 {d.get('row_count', 0)} rows")

                st.divider()
                
                ###############################

                if d.get("rows"):

                    df = pd.DataFrame(d["rows"])

                    used_tables = [
                        t["name"]
                        for t in d["explanation"]["xai"]["table_usage"]
                        if t["used_in_sql"]
                    ]

                    column_metadata = build_column_metadata(
                        used_tables
                    )

                    df.columns = [
                        _humanize_header(
                            c,
                            column_metadata
                        )
                        for c in df.columns
                    ]

                    st.dataframe(
                        df,
                        use_container_width=True,
                        height=200
                    )
                
                
                    
                #####################################    
                elif d.get("answer"):
                    st.markdown(d.get("answer", ""))

                if d.get("sql"):
                    st.code(d["sql"], language="sql")


# ══════════════════════════════════════════════════════════════════════════
# TAB 2 — Schema Explorer
# ══════════════════════════════════════════════════════════════════════════
# Browses KB_full_update.json directly (not via the API) -- same knowledge
# base used by ingest.py/knowledge_base.py to build the DDL context sent to
# the LLM. Lets a user sanity-check what the pipeline actually knows about
# a table (domain, columns, allowed_values, relationships) without needing
# to inspect raw JSON by hand.

# Table GROUP (colour set from the schema diagram), offered in the SAME
# selector as the KB domains: the 15 blue tables of the diagram.
blue_tables = [
    "act",
    "act_event",
    "act_stat",
    "act_task",
    "action_group",
    "comms_event",
    "comms_event_msg_type_assoc",
    "conn",
    "fire_event",
    "msg_type",
    "rx_event",
    "simulator_task",
    "simulator_task_event",
    "simulator_task_trigger",
    "tx_event",
]

TABLE_GROUPS = {
    "🔵 Blue tables (15)": blue_tables,
}

with tab_schema:
    st.subheader("🗂️ Schema Explorer — Knowledge Base")
    st.caption("Browse the KB (KB_full_update.json) used to build the schema context sent to the LLM.")

    try:
        from RAG.knowledge_base import load_kb, get_relationships, _join_sql

        kb = load_kb()

        # Domain filter — domain is a list per table (see knowledge_base.py's
        # new schema); flatten to a sorted set of individual domain tags.
        all_domains = set()
        for v in kb.values():
            d = v.get("domain", [])
            if isinstance(d, list):
                all_domains.update(d)
            elif d:
                all_domains.add(d)
        # Selector mixes KB domains and colour-based TABLE GROUPS (Blue
        # tables) in one list: groups first, then the alphabetical domains.
        sel_domain = st.selectbox(
            "Filter by domain or group based on tables color",
            ["All"] + list(TABLE_GROUPS) + sorted(all_domains),
        )

        def _table_domain_list(v):
            d = v.get("domain", [])
            return d if isinstance(d, list) else ([d] if d else [])

        if sel_domain in TABLE_GROUPS:
            group = TABLE_GROUPS[sel_domain]
            filtered = {t: kb[t] for t in sorted(group) if t in kb}
            missing = sorted(set(group) - set(kb))
            if missing:
                # Group tables absent from the KB are a coverage gap worth
                # surfacing here, not silently hiding.
                st.warning(
                    f"⚠️ {len(missing)} group table(s) not in the KB yet: "
                    + ", ".join(f"`{m}`" for m in missing)
                )
        else:
            filtered = {
                t: v for t, v in sorted(kb.items())
                if sel_domain == "All" or sel_domain in _table_domain_list(v)
            }

        st.caption(f"{len(filtered)} tables shown")

        search = st.text_input("🔍 Search table name, keyword, or description", placeholder="e.g. activity, organization...")
        if search:
            s = search.lower()
            filtered = {
                t: v for t, v in filtered.items()
                if s in t.lower()
                or s in (v.get("description", "") or "").lower()
                or any(s in kw.lower() for kw in v.get("keywords", []))
            }

        table_names = list(filtered.keys())
        if not table_names:
            st.info("No tables match the filter.")
        else:
            sel_table = st.selectbox("Select a table", table_names)

            if sel_table:
                entry = kb[sel_table]

                col_a, col_b = st.columns([2, 1])
                with col_a:
                    st.markdown(f"#### `{sel_table}` — {entry.get('label', '')}")
                    st.markdown(f"**Description:** {entry.get('description', '—')}")
                    if entry.get("keywords"):
                        st.caption("Also known as: " + ", ".join(entry["keywords"]))
                with col_b:
                    domain_list = _table_domain_list(entry)
                    st.markdown(f"**Domain:** {', '.join(f'`{d}`' for d in domain_list) or '—'}")
                    if entry.get("primary_key"):
                        st.markdown(f"**Primary key:** `{entry['primary_key']}`")

                # Relationships (structured -- see knowledge_base.py)
                # v2.1: rendered via _join_sql() (executable AND-composed
                # condition from own_column/related_column pairs), never the
                # raw DeZign join_on -- which is NOT valid SQL for composite
                # keys ("a, b = c, d") and misleads anyone copy-pasting it
                # into a SQL client. A "composite key" badge is shown when
                # the relationship spans multiple column pairs.
                parent_of = get_relationships(sel_table, "parent_of")
                child_of = get_relationships(sel_table, "child_of")
                if parent_of or child_of:
                    with st.expander(f"🔗 Relationships ({len(parent_of) + len(child_of)})", expanded=False):
                        def _render_rel(r, arrow, role_label):
                            join_sql = _join_sql(r, sel_table) or r.get("join_on", "?")
                            composite_badge = " 🔑²" if "," in str(r.get("own_column", "")) else ""
                            st.markdown(
                                f"{arrow} **{role_label}** `{r.get('related_table', '?')}`{composite_badge}  \n"
                                f"`{join_sql}`  ({r.get('type', '?')}, {r.get('cardinality', '?')})"
                            )
                        for r in parent_of:
                            _render_rel(r, "→", "parent of")
                        for r in child_of:
                            _render_rel(r, "←", "child of")

                # Columns table
                cols_kb = entry.get("columns", {})
                if cols_kb:
                    rows_data = []
                    for col_name, col_info in cols_kb.items():
                        allowed = col_info.get("allowed_values", {})
                        allowed_str = ", ".join(f"{k}={v}" for k, v in allowed.items()) if isinstance(allowed, dict) else " | ".join(allowed or [])
                        rows_data.append({
                            "Column": col_name,
                            "Type": col_info.get("data_type", ""),
                            "Description": col_info.get("description", ""),
                            "Allowed values": allowed_str or "—",
                            "Notes": col_info.get("notes", "") or "—",
                        })
                    st.dataframe(rows_data, use_container_width=True, height=400)
                else:
                    st.info("No column metadata available for this table.")

                # Sample queries
                # v2.1: show the level/kind badge carried by the v2 KB
                # ([basic] · count) so per-table coverage of the three
                # difficulty levels is auditable at a glance. Legacy plain
                # strings (no SQL attached) are shown too, flagged as such,
                # instead of being silently hidden.
                samples = entry.get("sample_queries", [])
                if samples:
                    _level_icons = {"basic": "🟢", "intermediate": "🟡", "advanced": "🔴"}
                    with st.expander(f"💡 Sample queries ({len(samples)})", expanded=False):
                        for s in samples:
                            if isinstance(s, dict) and s.get("question") and s.get("sql"):
                                lvl = s.get("level", "basic")
                                kind = s.get("kind", "")
                                badge = f"{_level_icons.get(lvl, '⚪')} `{lvl}`" + (f" · `{kind}`" if kind else "")
                                st.markdown(f"{badge}  \n**Q:** {s['question']}")
                                st.code(s["sql"], language="sql")
                            elif isinstance(s, str) and s.strip():
                                st.markdown(f"⚪ `legacy` — {s.strip()}")
                                st.caption("Plain question string (no validated SQL attached) — embedding enrichment only.")

    except Exception as e:
        st.error(f"Could not load knowledge base: {e}")
