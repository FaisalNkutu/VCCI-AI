"""Imports the package the way a production application would, from outside.

The other tests run inside the package directory, where every module
happens to be importable. That hides the failure that actually bites on
adoption: an application adds `src/` to its path, writes
`from graph_lab import Datagora`, and something breaks that never broke
here. So this one deliberately runs from elsewhere.

It also exercises the three deployment shapes a team will really meet:

  with a graph      joins imposed and audited, the full guarantee
  without a graph   MySQL only, one connection string, joins unverified
                    but everything else still checked, and said so
  credentials       passed in from the caller, never read from a file,
                    for an application that has its own secret manager

    .venv/Scripts/python src/graph_lab/test_integration.py

Under unittest it is skipped unless DATAGORA_LIVE_TESTS=on: it calls a
model and the databases, which the offline suite never does.
"""

import os

# the column index is on by default; a test never builds one in a real
# Qdrant, and the tests that need one give it directly
os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
import subprocess
import sys
import tempfile
import textwrap
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]          # .../src


CONSUMER = '''
import sys
sys.path.insert(0, r"{src}")

# this is the whole integration surface
from graph_lab import Datagora

dg = Datagora(
    mysql=dict(host="127.0.0.1", port=3306, database="{db}",
               user="{user}", password="{password}"),
    {graph_args}
)
print("HEALTH", dg.health())
print("HAS_GRAPH", dg.has_graph)

# judging SQL we already hold, without running it
bad = dg.check_sql("SELECT a || b FROM {any_table}")
print("LINT_FLAGS", len(bad))

out = dg.ask("{question}")
if out.waiting:
    out = dg.ask("{question}", choice=out.options[0].label)
print("ANSWERED", bool(out.answer))
print("SQL_NOT_EMPTY", bool(out.sql))
print("ROWS", len(out.rows))
dg.close()
print("CLOSED_CLEANLY")
'''


def run_consumer(**kw):
    """Run a fresh interpreter from a directory that is not the package."""
    code = CONSUMER.format(src=str(SRC), **kw)
    with tempfile.TemporaryDirectory() as tmp:
        script = Path(tmp) / "consumer_app.py"
        script.write_text(textwrap.dedent(code), encoding="utf-8")
        proc = subprocess.run([sys.executable, str(script)], cwd=tmp,
                              capture_output=True, text=True, timeout=900,
                              check=False)
    return proc


def report(label, proc, expect_graph):
    out = dict(line.split(" ", 1) for line in proc.stdout.splitlines()
               if " " in line and line.split(" ", 1)[0].isupper())
    ok = proc.returncode == 0 and out.get("ANSWERED") == "True"
    print(f"\n  {label}")
    if proc.returncode != 0:
        print("    FAILED to run:")
        print(textwrap.indent(proc.stderr.strip()[-700:], "      "))
        return False
    for key in ("HEALTH", "HAS_GRAPH", "LINT_FLAGS", "ANSWERED",
                "SQL_NOT_EMPTY", "ROWS", "CLOSED_CLEANLY"):
        if key in out:
            print(f"    {key:16} {out[key]}")
    if out.get("HAS_GRAPH") != str(expect_graph):
        print(f"    MISMATCH: expected HAS_GRAPH={expect_graph}")
        return False
    if out.get("LINT_FLAGS", "0") == "0":
        print("    MISMATCH: the dialect lint should have flagged '||'")
        return False
    return ok


def main():
    user = os.environ.get("MYSQL_USER", "root")
    password = os.environ.get("MYSQL_PASSWORD", "root")
    print(f"importing from outside the package: {SRC}")

    results = []

    results.append(report(
        "1. with a graph: joins imposed and audited",
        run_consumer(db="datagora_lib", user=user, password=password,
                     any_table="books", question="how many books per genre",
                     graph_args=('neo4j_uri="bolt://127.0.0.1:7687", '
                                 f'neo4j_password="{os.environ.get("NEO4J_PASSWORD", "")}",')),
        expect_graph=True))

    results.append(report(
        "2. without a graph: one MySQL connection string and nothing else",
        run_consumer(db="datagora_generic", user=user, password=password,
                     any_table="products",
                     question="how many products per category",
                     graph_args=""),
        expect_graph=False))

    print("\n" + "=" * 70)
    if all(results):
        print("  INTEGRATION OK: the package imports cleanly from outside,\n"
              "  answers with and without Neo4j, and its checks still fire.")
    else:
        raise SystemExit("integration failed")


import unittest  # noqa: E402


@unittest.skipUnless(os.environ.get("DATAGORA_LIVE_TESTS") == "on",
                     "live: a model and the databases; DATAGORA_LIVE_TESTS=on runs it")
class IntegrationTests(unittest.TestCase):
    """The same run under unittest, said skipped rather than passing with
    no test at all when the suite runs offline (review of 26 October)."""

    def test_the_package_answers_from_outside_with_and_without_a_graph(self):
        main()


if __name__ == "__main__":
    main()
