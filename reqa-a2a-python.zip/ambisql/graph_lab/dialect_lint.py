"""Catch the SQLite habits of a SQLite-trained generator before MariaDB
runs them.

The generators we use are trained and rewarded on SQLite: BIRD ships 95
SQLite databases and execution accuracy on SQLite is the entire reward
signal of Arctic-Text2SQL-R1. We run MariaDB. The divergences split in
two and only one half is self-correcting:

  loud    CAST(x AS REAL), strftime, julianday, AUTOINCREMENT raise an
          error, the repair loop sees it and the next attempt fixes it.
  silent  the statement runs, returns a plausible value, and no error
          ever reaches the loop. Measured on MariaDB 11.4:
            'a' || 'b'    SQLite 'ab'        MariaDB 0     (|| is OR)
            WHERE a || b  SQLite a string    MariaDB TRUE  (filter off)
            3 / 2         SQLite 1           MariaDB 1.5000
            date('now')   SQLite today       MariaDB NULL

Two mechanisms, both verified against sqlglot 30.7 and MariaDB 11.4:

  detect   parse the SAME text under the sqlite and the mysql dialects
           and compare the normalised trees. If they differ, the
           statement means two different things depending on who reads
           it, which is exactly the definition of the silent bug. No
           false positive on our own queries: a plain join and the
           four-CTE query both come back identical.
  repair   sqlglot.transpile(read="sqlite", write="mysql") rewrites
           || into CONCAT, strftime into DATE_FORMAT, CAST AS REAL into
           CAST AS FLOAT and substr into SUBSTRING. All four verified to
           execute on MariaDB.

What sqlglot leaves alone, and the hand-written rules cover: date('now')
and datetime('now'), which stay as written and return NULL. 3 / 2 stays
3 / 2 and is not flagged: MariaDB divides in decimals (1.5), which is
what a question about an average means. sqlglot has no MariaDB dialect;
mysql is the right target for everything used here.

Self-test from the repo root:
    .venv/Scripts/python src/graph_lab/dialect_lint.py
"""

import re

import sqlglot

# Functions that exist in SQLite and not in MariaDB. They raise, so the
# repair loop already handles them; they are reported as `loud` so a
# verdict can say "no need to reject, the error will say it".
SQLITE_ONLY = {
    "julianday", "strftime", "unixepoch", "sqlite_version",
    "last_insert_rowid", "changes", "randomblob", "zeroblob", "glob",
    "printf", "instr_rev",
}

# Silent traps that survive transpilation and need their own rule.
SILENT_RULES = [
    (re.compile(r"\bdate\s*\(\s*'now'\s*\)", re.IGNORECASE),
     "date('now') returns NULL on MariaDB, so the comparison is never "
     "true and the query returns zero rows without an error. Use "
     "CURDATE() or NOW()."),
    (re.compile(r"\bdatetime\s*\(\s*'now'\s*\)", re.IGNORECASE),
     "datetime('now') returns NULL on MariaDB. Use NOW()."),
]


def _normalise(sql, read):
    return sqlglot.parse_one(sql, read=read).sql(dialect="mysql")


# The MySQL parser canonicalises a few functions that the SQLite parser,
# not knowing them, leaves alone. The two readings then differ in text
# while meaning exactly the same thing on the engine we run against.
# Access types a lookup names the column it is reached by; anything
# else is a parser artefact rather than a difference in meaning.
LOOKUP_SAFE = ("Anonymous",)


def dialect_divergence(sql):
    """Does this statement mean two different things to the two engines?

    Returns the two readings when it does, None when it does not.

    The old test was a string comparison of the two normalised parses,
    patched by a hand-written list of function spellings. The list was
    the admission that the primitive was wrong: any MariaDB-only syntax
    the SQLite parser mangles rather than rejects came out as a
    difference in meaning. `DATE_SUB(NOW(), INTERVAL 30 DAY)` was
    rejected outright, which is the filter behind every "in the last
    thirty days" question there is.

    sqlglot's own tree diff separates the two classes cleanly, and they
    are structurally different:

      a real divergence replaces a node class for an operator BOTH
      dialects parsed, `Remove DPipe` against `Insert Or`, which is `||`
      meaning concatenation to one engine and a logical or to the other;

      an artefact is a function only one side knows (an Anonymous node),
      or the same node class reshuffled, or a one-sided removal with no
      matching insertion, which is a parser filling in a default."""
    import sqlglot
    from sqlglot.diff import Keep, Move, diff

    try:
        as_sqlite = sqlglot.parse_one(sql, read="sqlite")
    except Exception:
        return None                 # MariaDB-only syntax: not ambiguous
    as_mysql = sqlglot.parse_one(sql, read="mysql")

    edits = [e for e in diff(as_sqlite, as_mysql, delta_only=True)
             if not isinstance(e, (Move, Keep))]
    if not edits:
        return None
    removed = {type(e.expression).__name__ for e in edits
               if type(e).__name__ == "Remove"}
    inserted = {type(e.expression).__name__ for e in edits
                if type(e).__name__ == "Insert"}
    if set(LOOKUP_SAFE) & (removed | inserted):
        return None                 # one side did not know the function
    if removed and removed == inserted:
        return None                 # same class, arguments reshuffled
    if removed and not inserted:
        return None                 # a one-sided parser artefact

    # The same text on both sides, classified differently, is a parser
    # reading a keyword it does not know rather than a change of
    # meaning. TIMESTAMPDIFF(DAY, ...) gives `Remove Column DAY` against
    # `Insert Var DAY`: identical text, one side simply does not know
    # DAY is a unit. The genuine trap looks nothing like it, because the
    # text itself changes: `c.name || ' x'` against `c.name OR ' x'`.
    gone = {e.expression.sql() for e in edits if type(e).__name__ == "Remove"}
    came = {e.expression.sql() for e in edits if type(e).__name__ == "Insert"}
    if gone and gone == came:
        return None
    # the two readings written back the same, character for character: the
    # trees differ in how a parser filed a function (YEAR(...), known to
    # one dialect, anonymous to the other), not in what the statement does.
    # Ask failed three times on "WHERE YEAR(invoice_date) = 2025" for it
    # (E36, 23 October)
    a, b = as_sqlite.sql(dialect="mysql"), as_mysql.sql(dialect="mysql")
    if a == b:
        return None
    return (a, b)


def lint(sql):
    """Return (verdicts, repaired_sql_or_None).

    A verdict is (severity, message) with severity in
    REJECT / WARN / OK. REJECT means the statement means two different
    things depending on the dialect and must not run as written.
    """
    verdicts = []

    # 1. does the text mean the same thing to both engines?
    try:
        divergence = dialect_divergence(sql)
    except Exception as e:
        return [("WARN", f"not parseable by sqlglot: {type(e).__name__}: "
                         f"{str(e)[:80]}")], None

    repaired = None
    if divergence is not None:
        as_sqlite, as_mysql = divergence
        verdicts.append((
            "REJECT",
            "dialect-ambiguous: read as SQLite this is "
            f"`{as_sqlite}`, read as MariaDB it is `{as_mysql}`. "
            "The statement runs either way, so nothing would have "
            "caught it."))
        repaired = as_sqlite          # the SQLite reading, written for MySQL

    # 2. silent traps that survive transpilation
    for pattern, message in SILENT_RULES:
        if pattern.search(sql):
            verdicts.append(("REJECT", message))

    # 3. loud ones, reported but not rejected: MariaDB will say it
    for fn in sorted(SQLITE_ONLY):
        if re.search(rf"\b{fn}\s*\(", sql, re.IGNORECASE):
            verdicts.append((
                "WARN",
                f"{fn}() does not exist on MariaDB. This one is loud, the "
                f"repair loop will see the error."))

    if not verdicts:
        verdicts.append(("OK", "no dialect divergence"))
    return verdicts, repaired


def transpile(sql):
    """The SQLite reading of the statement, written for MariaDB. Use it
    to propose a fix, never to run silently in place of the model."""
    return sqlglot.transpile(sql, read="sqlite", write="mysql")[0]


def repair_message(sql):
    """The text handed back to the generator, or None when the statement
    is clean.

    Detection is the authority here, not the rewrite. MariaDB will never
    raise on these statements, so nothing downstream would confirm the
    problem: this message is the only signal the model gets. The
    transpiled form is included as a hint because we parsed the query
    anyway and it costs nothing, but the model is asked to rewrite, not
    to copy: a generator that keeps being handed corrected SQL never
    learns that it is writing for the wrong engine."""
    verdicts, repaired = lint(sql)
    blocking = [m for severity, m in verdicts if severity == "REJECT"]
    if not blocking:
        return None
    lines = ["Your SQL runs on MariaDB but does not mean what you "
             "intended. It was rejected before execution:"]
    lines += [f"  - {m}" for m in blocking]
    if repaired:
        lines.append(f"  Equivalent MariaDB form: {repaired}")
    lines.append("Rewrite the query for MariaDB. Use CONCAT for string "
                 "concatenation, CURDATE() or NOW() for the current date, "
                 "and no SQLite-only function.")
    return "\n".join(lines)


def _self_test():
    cases = [
        ("silent, the killer", "SELECT first_name || ' ' || last_name FROM t"),
        ("silent, filter off",
         "SELECT COUNT(*) FROM inventory WHERE a || b"),
        ("silent, NULL date",
         "SELECT * FROM inventory WHERE last_counted_at > date('now')"),
        ("loud, caught anyway",
         "SELECT julianday('now') - julianday(created_at) FROM t"),
        ("clean join",
         "SELECT s.supplier_name FROM suppliers s "
         "JOIN product_suppliers ps ON ps.supplier_id = s.supplier_id"),
        ("clean 4-CTE",
         "WITH in_wh AS (SELECT i.product_id FROM inventory i "
         "JOIN warehouses w ON i.warehouse_id = w.warehouse_id "
         "WHERE w.code = 'code 0001') "
         "SELECT COUNT(*) FROM in_wh"),
    ]
    worst = 0
    for label, sql in cases:
        verdicts, repaired = lint(sql)
        print(f"\n{label}\n  {sql[:78]}")
        for severity, message in verdicts:
            print(f"  [{severity}] {message[:150]}")
            worst = max(worst, {"OK": 0, "WARN": 1, "REJECT": 2}[severity])
        if repaired:
            print(f"  [FIX ] {repaired[:110]}")
    print("\nself-test done. Expected: the three silent cases REJECT, "
          "julianday WARN, the two clean queries OK.")


if __name__ == "__main__":
    _self_test()
