"""One command that says whether this installation is sound.

Meant to be run by someone who did not build it: after a deployment, a
migration, a model switch, or on a Monday morning. It reports facts and
names the command that fixes each gap, rather than leaving a reader to
work out what "0 edges" implies.

    .venv/Scripts/python src/graph_lab/audit.py
    .venv/Scripts/python src/graph_lab/audit.py --deep    # also asks a model

Exit code is 0 when everything essential is in place, 1 otherwise, so it
can gate a deployment.
"""

import argparse
import re
import sys
import time

if __package__:
    from .db_profile import DbProfile
    from .llm import LLM
    from .schema_graph import Graph
else:
    from db_profile import DbProfile
    from llm import LLM
    from schema_graph import Graph

OK, WARN, BAD = "ok  ", "warn", "FAIL"


class Report:
    def __init__(self):
        self.lines = []
        self.failed = False

    def add(self, level, what, detail, fix=""):
        self.lines.append((level, what, detail, fix))
        if level == BAD:
            self.failed = True

    def show(self):
        for level, what, detail, fix in self.lines:
            print(f"  [{level}] {what:26} {detail}")
            if fix:
                print(f"         fix: {fix}")


def is_a_placeholder(llm):
    """Is this endpoint a blank somebody was meant to fill in?

    The test used to name two exact strings, TO-BE-FILLED and JARVIS-HOST,
    which were the two placeholders in the packaged file at the time. That
    made the check a list to keep in step with a config file: rename a
    placeholder and the audit stops seeing it, which is the one moment it
    is needed.

    It reads as a placeholder instead. Nothing here is a real host name or
    a real model tag, and a value that says "set me" is not one either.
    """
    raw = f"{llm.model} {llm.url}"
    words = ("to-be-filled", "set-your", "set-me", "your-", "changeme",
             "change-me", "example.com", "placeholder", "fill-in",
             "fillme", "todo", "<", ">")
    if any(word in raw.lower() for word in words):
        return True
    # a SHOUTED segment, which is the convention every template in this
    # repository used: JARVIS-HOST, TO-BE-FILLED, YOUR-SERVER. Tested on
    # the url alone, and only on a run of three or more letters, so a real
    # host is not caught by a capitalised initial and a model tag is free
    # to shout as vendors do.
    host = raw.split()[-1] if raw.split() else ""
    return any(len(part) >= 3 and part.isupper() and part.isalpha()
               for part in re.split(r"[^A-Za-z]+", host))


def audit_models(r):
    roles = LLM.roles()
    if not roles:
        r.add(BAD, "model roles", "none configured",
              "add a `roles` block to models.json")
        return
    for role in roles:
        llm = LLM.role(role)
        if is_a_placeholder(llm):
            r.add(WARN, f"role {role}", f"{llm.name} is a placeholder",
                  "fill url and model in models.json, then "
                  f"python llm.py --set {role}=<endpoint>")
        elif llm.reachable():
            r.add(OK, f"role {role}", f"{llm.name} -> {llm.model}")
        else:
            r.add(BAD, f"role {role}", f"{llm.name} at {llm.url} unreachable",
                  f"start it, or python llm.py --set {role}=local-small")
    if roles.get("reasoner") == roles.get("sql"):
        r.add(WARN, "role split",
              "one model plays both parts",
              "the SQL specialist is a poor reasoner and the reverse; "
              "split them once both are reachable")


def audit_database(r, profile):
    try:
        con = profile.connect_mysql()
        cur = con.cursor()
        cur.execute("""SELECT COUNT(*) FROM information_schema.tables
                       WHERE table_schema=%s AND table_type='BASE TABLE'""",
                    (profile.schema,))
        tables = cur.fetchone()[0]
        cur.execute("""SELECT COUNT(DISTINCT constraint_name)
                       FROM information_schema.key_column_usage
                       WHERE table_schema=%s
                         AND referenced_table_name IS NOT NULL""",
                    (profile.schema,))
        fks = cur.fetchone()[0]
        con.close()
    except Exception as e:
        r.add(BAD, f"database {profile.name}", f"{type(e).__name__}: "
              f"{str(e)[:70]}", "check the connection and the credentials")
        return None
    if tables == 0:
        r.add(BAD, f"database {profile.name}", "no table", "")
    elif fks == 0:
        r.add(WARN, f"database {profile.name}",
              f"{tables} tables but no declared foreign key",
              "the join graph will be empty; declare them, or accept "
              "that joins cannot be verified")
    else:
        r.add(OK, f"database {profile.name}",
              f"{tables} tables, {fks} declared foreign keys")
    return tables, fks


def audit_graph(r, profile, fks):
    try:
        drv = profile.connect_neo4j()
    except Exception as e:
        r.add(WARN, f"graph {profile.name}",
              f"Neo4j unreachable ({type(e).__name__})",
              "optional: without it the engine still answers, but joins "
              "are never verified")
        return
    try:
        graph = Graph.from_profile(profile, drv)
        edges = len(graph.edges)
        if edges == 0:
            r.add(BAD, f"graph {profile.name}", "built but empty",
                  f"python build_graph.py --profile {profile.name}")
        elif fks and edges < fks:
            r.add(WARN, f"graph {profile.name}",
                  f"{edges} edges for {fks} foreign keys, the graph is stale",
                  f"python build_graph.py --profile {profile.name}")
        else:
            r.add(OK, f"graph {profile.name}", f"{edges} edges")
        # read from the edges already loaded, so it counts the same graph,
        # whichever one the database is given, the whole one included
        missing = sum(1 for edge in graph.edges if edge[7] is None)
        if missing:
            r.add(WARN, f"meanings {profile.name}",
                  f"{missing} edges have no meaning sentence",
                  "the judge and the repair messages quote it; write one "
                  "per edge once, it survives rebuilds")
    finally:
        drv.close()


def audit_page(r):
    """Every page's inline script must parse.

    It is one inline script, so a single bad character disables all of it
    at once: no database list, no example questions, no answer, and no
    error anywhere on the server, which stays perfectly healthy while the
    page does nothing. This has happened four times, always the same way,
    a newline written into a string literal instead of an escaped one.
    It costs a second to rule out and it is invisible otherwise."""
    import re
    import shutil
    import subprocess
    from pathlib import Path

    node = shutil.which("node")
    if not node:
        r.add(WARN, "page script", "not checked, node is not installed",
              "the syntax of the page cannot be verified without it")
        return
    ui = Path(__file__).parent / "ui"
    scripts = []
    for name in ("index.html", "coverage.html"):
        page = ui / name
        if not page.exists():
            continue
        found = re.search(r"<script>(.*)</script>",
                          page.read_text(encoding="utf-8"), re.DOTALL)
        label = f"page script {page.stem}"
        if not found:
            r.add(BAD, label, f"no <script> block in {name}")
            continue
        scripts.append((label, found.group(1)))
    # the helpers those pages load before their own script, which were
    # part of it until they moved to common.js: a bad character there
    # stops every page that loads it
    if (ui / "common.js").exists():
        scripts.append(("page script common",
                        (ui / "common.js").read_text(encoding="utf-8")))
    for label, script in scripts:
        proc = subprocess.run([node, "--check", "-"], input=script,
                              capture_output=True, text=True, check=False)
        if proc.returncode == 0:
            r.add(OK, label, "parses")
        else:
            first = [line for line in proc.stderr.splitlines()
                     if "Error" in line]
            detail = first[0][:70] if first else "does not parse"
            r.add(BAD, label, detail,
                  "the whole page is dead until this parses; look for a real "
                  "newline inside a string literal")


def audit_checks(r, profile):
    """The gates must actually reject. A guard nobody tested is decoration."""
    if __package__:
        from .dialect_lint import lint
    else:
        from dialect_lint import lint
    verdicts, _ = lint("SELECT a || b FROM t")
    if any(v[0] == "REJECT" for v in verdicts):
        r.add(OK, "dialect lint", "rejects a silent SQLite habit")
    else:
        r.add(BAD, "dialect lint", "did not reject '||'",
              "sqlglot may be missing: pip install sqlglot")


def audit_deep(r, profile):
    """Ask a model one real question, end to end."""
    if __package__:
        from .pipeline import Pipeline
    else:
        from pipeline import Pipeline
    pipe = Pipeline(profile)
    try:
        t0 = time.time()
        # a check of the deployment, not a question to learn from
        run = pipe.ask("how many rows are there in total", remember=False)
        took = time.time() - t0
        if run.answer:
            r.add(OK, f"end to end {profile.name}",
                  f"answered in {took:.0f}s")
        elif run.clarification and getattr(run.clarification, "options", None):
            r.add(OK, f"end to end {profile.name}",
                  f"asked a clarification in {took:.0f}s, which is a valid "
                  f"outcome")
        else:
            r.add(WARN, f"end to end {profile.name}",
                  f"no answer: {run.failed[:60]}")
    except Exception as e:
        r.add(BAD, f"end to end {profile.name}",
              f"{type(e).__name__}: {str(e)[:70]}", "")
    finally:
        pipe.close()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--deep", action="store_true",
                    help="also run one real question per database")
    ap.add_argument("--profile", default=None)
    args = ap.parse_args()

    r = Report()
    print("Datagora installation audit\n")

    audit_models(r)
    names = [args.profile] if args.profile else DbProfile.names()
    for name in names:
        profile = DbProfile.load(name)
        got = audit_database(r, profile)
        if got:
            audit_graph(r, profile, got[1])
    audit_checks(r, None)
    audit_page(r)
    if args.deep:
        for name in names:
            audit_deep(r, DbProfile.load(name))

    r.show()
    warns = sum(1 for l, *_ in r.lines if l == WARN)
    bads = sum(1 for l, *_ in r.lines if l == BAD)
    print(f"\n  {len(r.lines)} checks, {bads} failing, {warns} worth a look")
    if r.failed:
        print("  NOT READY")
        sys.exit(1)
    print("  READY" + ("  (with warnings)" if warns else ""))


if __name__ == "__main__":
    main()
