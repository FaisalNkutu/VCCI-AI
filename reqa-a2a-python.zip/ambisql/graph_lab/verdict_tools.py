"""The tools the verdict agent explores a database with, bounded and read only.

The single-call judge decided on what one prompt showed it: a cut schema,
a few values per column, and no way to look further. It said "no link"
between two tables Neo4j joins through a third it was not shown, and
offered a choice between two readings that return the same rows. The
agent (verdict_agent.py) asks instead, through these tools, and the code
checks what it concludes against what they found.

Three parts, and none of them calls a model:

  SchemaView  one reading of the schema per job, shared by every slot:
              each table whole and short, the joins as a graph (declared
              foreign keys, the knowledge base's links and the Neo4j
              graph), and the database's flavour. Read once, then only
              read, so threads share it safely.
  ToolBox     one per slot: the tools themselves. Each returns a
              ToolResult that says what it found in one line (`digest`),
              renders to a token cap with a cursor for the rest, and
              carries the Facts the verifier reuses instead of asking the
              database again.
  the guard   every SQL the agent writes is parsed before it runs: one
              SELECT, no comment, no write, no lock, no sleeping function,
              only tables of this schema. It then runs in a read-only
              transaction under a statement timeout, and is rolled back.

Every tool is bounded (rows, columns, seconds, tokens) and says when it was
cut. Nothing here names a table: test_reusable.py checks it. The words that
mark time in a schema's names live in wording.py.
"""

from __future__ import annotations

import contextlib
import datetime
import decimal
import difflib
import hashlib
import heapq
import json
import math
import os
import pathlib
import re
import time
from collections import Counter, deque
from dataclasses import dataclass, field

if __package__:
    from . import calc, focus, wording
else:
    import calc
    import focus
    import wording

TOOLS = ("search_tables", "describe_tables", "find_columns", "sample_values",
         "find_value", "join_path", "time_columns", "run_count",
         "compare_readings", "compute", "clock")

# the bounds of each tool; a caller asking for more gets the ceiling
SEARCH_TABLES, SEARCH_TABLES_MAX = 10, 25
DESCRIBE_MAX = 4
FIND_COLUMNS, FIND_COLUMNS_MAX = 15, 20
SAMPLE_VALUES, SAMPLE_VALUES_MAX = 20, 50
VALUE_WIDTH = 60
# a value shorter than this matches too much to prove anything: "SL" is in
# half the words of a schema, and its absence from a sweep proves nothing
VALUE_MIN_CHARS = 3
# the text columns a sweep reads before it stops; SWEEP_SECONDS bounds it
# too. 300 was set on a 156-table base: on 256 tables (459 text columns)
# no absence could ever be confirmed, and a full sweep takes 2 s (E38,
# 23 October)
SWEEP_COLUMNS = 1000
SWEEP_SECONDS = 15.0
SWEEP_HITS = 3
LOOKUP_SECONDS = 2.0
MATCHES_SHOWN = 4
# a number or a date, swept in the columns of its type rather than in the
# text columns (absent_everywhere)
_DAY = re.compile(r"\d{4}-\d{2}-\d{2}")
_MOMENT = re.compile(r"\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}(:\d{2}(\.\d{1,6})?)?")
_NUMBER = re.compile(r"[+-]?\d+(\.\d+)?")
WHOLE_TYPES = {"tinyint", "smallint", "mediumint", "int", "integer", "bigint",
               "year"}
INEXACT_TYPES = {"float", "double", "real"}
NUMBER_TYPES = WHOLE_TYPES | INEXACT_TYPES | {"decimal", "numeric", "dec",
                                              "fixed"}
DAY_TYPES = {"date", "datetime", "timestamp"}
# joins: how far a path may go, how many are offered, and how much dearer
# than the cheapest one an alternative may be
MAX_HOPS = 5
MAX_PATHS = 3
PATH_SLACK = 1.25
# what a join costs by where it was read: a declared foreign key is
# enforced, the graph was built from the data, the knowledge base was
# written by someone
WEIGHTS = {"fk": 1.0, "graph": 1.2, "kb": 1.5}
# a bound on the paths walked, for a dense graph
PATH_EXPANSIONS = 20000
PATH_FOUND = 60
# time: the columns read in one table and the rows each is read on
MOMENTS_MAX = 6
TIME_ROWS = 20000
# SQL
SQL_MAX_CHARS = 4000
COUNT_ROWS = 5
READINGS_MIN, READINGS_MAX = 2, 4
# readings compared: the decimals a number is rounded to, and how many
# orders of the columns are tried when two readings list them differently
CELL_DECIMALS = 4
ALIGN_TRIES = 120
ERROR_WIDTH = 200
DIGEST_WIDTH = 240
BLOCKED_NODES = ("Insert", "Update", "Delete", "Merge", "Create", "Drop",
                 "Alter", "Command", "Set", "Into", "Lock", "NextValueFor")
# functions that sleep, wait on replication, take or drop locks, move a
# sequence or read files: refused whatever sqlglot calls them
BLOCKED_FUNCTIONS = {
    "SLEEP", "BENCHMARK", "LOAD_FILE", "GET_LOCK", "RELEASE_LOCK",
    "RELEASE_ALL_LOCKS", "IS_FREE_LOCK", "IS_USED_LOCK", "MASTER_POS_WAIT",
    "SOURCE_POS_WAIT", "MASTER_GTID_WAIT", "WAIT_FOR_EXECUTED_GTID_SET",
    "WAIT_UNTIL_SQL_THREAD_AFTER_GTIDS", "NEXTVAL", "SETVAL", "LASTVAL"}
# the functions a query may call that sqlglot does not know (it reads them
# as Anonymous): what analytics need of MySQL and MariaDB, aggregates,
# windows, dates, text, numbers, JSON. The functions sqlglot knows are
# standard ones; any other unknown name is refused, a user-defined
# function (sys_exec) or a server one (UPDATEXML) alike. Named whatever
# sqlglot calls them, so that a version of it that stops knowing one does
# not refuse it.
ALLOWED_FUNCTIONS = frozenset("""
    COUNT SUM AVG MIN MAX GROUP_CONCAT STD STDDEV STDDEV_POP STDDEV_SAMP
    VARIANCE VAR_POP VAR_SAMP BIT_AND BIT_OR BIT_XOR JSON_ARRAYAGG
    JSON_OBJECTAGG ANY_VALUE MEDIAN PERCENTILE_CONT PERCENTILE_DISC
    ROW_NUMBER RANK DENSE_RANK NTILE LAG LEAD FIRST_VALUE LAST_VALUE
    NTH_VALUE PERCENT_RANK CUME_DIST
    DATE TIME YEAR MONTH DAY DAYOFMONTH DAYOFWEEK DAYOFYEAR WEEK WEEKDAY
    WEEKOFYEAR YEARWEEK QUARTER HOUR MINUTE SECOND MICROSECOND MONTHNAME
    DAYNAME LAST_DAY MAKEDATE MAKETIME DATE_ADD DATE_SUB ADDDATE SUBDATE
    ADDTIME SUBTIME DATEDIFF TIMEDIFF TIMESTAMPDIFF TIMESTAMPADD DATE_FORMAT
    TIME_FORMAT STR_TO_DATE FROM_DAYS TO_DAYS TO_SECONDS FROM_UNIXTIME
    UNIX_TIMESTAMP SEC_TO_TIME TIME_TO_SEC PERIOD_ADD PERIOD_DIFF EXTRACT
    NOW CURDATE CURTIME CURRENT_DATE CURRENT_TIME CURRENT_TIMESTAMP
    LOCALTIME LOCALTIMESTAMP SYSDATE UTC_DATE UTC_TIME UTC_TIMESTAMP
    CONVERT_TZ GET_FORMAT TIMESTAMP
    CONCAT CONCAT_WS SUBSTRING SUBSTR MID SUBSTRING_INDEX LEFT RIGHT UPPER
    LOWER UCASE LCASE TRIM LTRIM RTRIM LENGTH CHAR_LENGTH CHARACTER_LENGTH
    OCTET_LENGTH BIT_LENGTH REPLACE REVERSE REPEAT SPACE LPAD RPAD LOCATE
    POSITION INSTR FIELD FIND_IN_SET ELT ASCII ORD CHAR HEX UNHEX INSERT
    FORMAT QUOTE SOUNDEX STRCMP REGEXP_REPLACE REGEXP_SUBSTR REGEXP_INSTR
    REGEXP_LIKE CONVERT CAST COLLATION CHARSET BIN OCT CONV MD5 SHA1 SHA2
    CRC32 UUID BINARY
    ROUND FLOOR CEIL CEILING ABS MOD POW POWER SQRT EXP LN LOG LOG2 LOG10
    SIGN TRUNCATE GREATEST LEAST RAND PI DEGREES RADIANS SIN COS TAN ASIN
    ACOS ATAN ATAN2 COT BIT_COUNT
    IF IFNULL NULLIF COALESCE ISNULL NVL NVL2 INTERVAL
    JSON_EXTRACT JSON_UNQUOTE JSON_VALUE JSON_CONTAINS JSON_CONTAINS_PATH
    JSON_LENGTH JSON_KEYS JSON_OBJECT JSON_ARRAY JSON_TYPE JSON_VALID
    JSON_SEARCH JSON_QUERY JSON_DEPTH JSON_TABLE
    INET_ATON INET_NTOA INET6_ATON INET6_NTOA
    POINT ST_ASTEXT ST_ASWKT ST_X ST_Y ST_LATITUDE ST_LONGITUDE ST_DISTANCE
    ST_DISTANCE_SPHERE ST_CONTAINS ST_WITHIN ST_INTERSECTS ST_GEOMFROMTEXT
    ST_POINTFROMTEXT ST_SRID ST_LENGTH ST_AREA
""".split())
# MariaDB's max_statement_time, MySQL's max_execution_time
TIMEOUT_ERRORS = {1969, 3024}
TOO_SLOW = "too slow: narrow the query"
NO_BOUNDED_CONNECTION = ("no connection to the database with a time limit "
                         "(none opened, or the database did not say what it "
                         "is)")
EMPTY = "\u2205"
# the order find_columns gives the evidence in, surest first
EVIDENCE_ORDER = ("exact", "token", "table", "described", "about", "similar")


# ------------------------------------------------------------ settings
# the ranges the settings page accepts (settings_store._AGENT_WHOLE), held
# to on the environment too: an engine setting outside them, or a number
# that is no number (inf, nan), keeps the default
BOUNDS = {"max_turns": (2, 30), "max_seconds": (60, 3600),
          "sql_seconds": (1, 60), "result_tokens": (400, 12000)}


def _whole_in(low, high):
    def read(raw):
        value = int(raw)
        return value if low <= value <= high else None
    return read


def _number_in(low, high):
    def read(raw):
        value = float(raw)
        return value if math.isfinite(value) and low <= value <= high else None
    return read


def _share(raw):
    value = float(raw)
    return value if math.isfinite(value) and 0.0 <= value < 1.0 else None


def strip_comments(text):
    """The SQL without its comments ("-- ...", "# ..." to the end of the
    line, "/* ... */", an optimizer hint "/*+ ... */"), quoted text left as
    it is: '...', "..." and `...`, a doubled quote or a backslash escaping
    one. ValueError on MySQL's "/*! ... */", which MySQL runs: taking it out
    would change what the query computes, so it is refused."""
    out, i, n = [], 0, len(text)
    while i < n:
        c = text[i]
        if c in "'\"`":
            j = i + 1
            while j < n:
                if text[j] == "\\" and c != "`":
                    j += 2
                    continue
                if text[j] == c:
                    if j + 1 < n and text[j + 1] == c:
                        j += 2
                        continue
                    break
                j += 1
            out.append(text[i:j + 1])
            i = j + 1
        elif text.startswith("--", i) and (i + 2 >= n or text[i + 2] in " \t\r\n") \
                or c == "#":
            j = text.find("\n", i)
            i = n if j < 0 else j
            out.append(" ")
        elif text.startswith("/*!", i):
            raise ValueError("MySQL version comments (/*! ... */) are not allowed")
        elif text.startswith("/*", i):
            j = text.find("*/", i + 2)
            i = n if j < 0 else j + 2
            out.append(" ")
        else:
            out.append(c)
            i += 1
    # spaces as they were: a quoted value is never touched
    return "".join(out).strip()


def _one_of(*allowed):
    def read(raw):
        value = raw.lower()
        return value if value in allowed else None
    return read


def _switch(raw):
    value = raw.lower()
    if value in ("on", "true", "1", "yes"):
        return True
    if value in ("off", "false", "0", "no"):
        return False
    return None


# (field, variable, reader): a reader returns None for a value it refuses,
# and the field keeps its default
_ENVIRONMENT = (
    ("judge_mode", "DATAGORA_JUDGE", _one_of("single", "agent")),
    ("max_turns", "DATAGORA_AGENT_MAX_TURNS", _whole_in(*BOUNDS["max_turns"])),
    ("max_seconds", "DATAGORA_AGENT_MAX_SECONDS",
     _number_in(*BOUNDS["max_seconds"])),
    ("think", "DATAGORA_AGENT_THINK", _one_of("all", "plan_conclude", "none")),
    ("sql_seconds", "DATAGORA_AGENT_SQL_SECONDS",
     _number_in(*BOUNDS["sql_seconds"])),
    ("result_tokens", "DATAGORA_AGENT_RESULT_TOKENS",
     _whole_in(*BOUNDS["result_tokens"])),
    ("choice_tolerance", "DATAGORA_AGENT_CHOICE_TOLERANCE", _share),
    ("same_result", "DATAGORA_AGENT_SAME_RESULT", _one_of("answer", "choice")),
    ("arbiter", "DATAGORA_AGENT_ARBITER", _one_of("off", "vote")),
    ("wording", "DATAGORA_AGENT_WORDING", _switch),
)


@dataclass
class Settings:
    """The judge's engine settings, as the settings page stores them and
    the environment carries them (contrats_verdict_agent.md, contract 3)."""
    judge_mode: str = "agent"
    max_turns: int = 8
    # 1200 since 27 October: on one GPU shared by four questions a call
    # takes two to four times longer, and at 600 the time cap cut the
    # agent before the verifier's second round
    max_seconds: float = 1200
    think: str = "all"
    sql_seconds: float = 5
    result_tokens: int = 3000
    choice_tolerance: float = 0.01
    same_result: str = "answer"
    arbiter: str = "off"
    compare_rows: int = 1000
    verify_rounds: int = 1
    # the closed question on the wording of a confirmed choice
    # (Verifier._selected_by_wording), asked in a fresh context
    wording: bool = True

    @classmethod
    def from_environment(cls, environ=None) -> "Settings":
        """Read like Clarifier.tuning: at the moment of use, an empty value
        counts as unset, and anything unreadable or out of range keeps the
        default rather than switching a bound off by accident."""
        env = os.environ if environ is None else environ
        values = {}
        for name, key, read in _ENVIRONMENT:
            raw = str(env.get(key) or "").strip()
            if not raw:
                continue
            try:
                value = read(raw)
            except (TypeError, ValueError):
                value = None
            if value is not None:
                values[name] = value
        return cls(**values)


# --------------------------------------------------------------- facts
@dataclass(frozen=True)
class Edge:
    """One join, read from one side: `via` is "a.x = b.y", composite keys
    joined by " AND ", a polymorphic link's condition after " WHEN "."""
    a: str
    b: str
    via: str
    source: str
    weight: float


@dataclass
class Fact:
    """What a tool established, kept in the agent's notebook (nb.facts) and
    shown in its trace. The verifier runs its own checks on the database
    and keeps their results for the question's later rounds (Verifier._call).

    kinds: table_exists, column_exists, values_seen, value_found,
    value_absent, join_path, count, compare, time. Keys are lower case:
    a table, "table.column", a value, pair_key(a, b), sql_key(sql) or
    readings_key(sql_a, sql_b)."""
    kind: str
    key: str
    value: dict
    step: int = -1


def sql_key(sql):
    """The SQL's identity: sha1 of its text, lower case, whitespace made
    single spaces, trailing semicolons dropped. Two readings written with
    different spacing are the same reading."""
    text = " ".join(str(sql or "").split()).lower().rstrip("; ").strip()
    return hashlib.sha1(text.encode("utf-8")).hexdigest()


def readings_key(sql_a, sql_b):
    """The key of a comparison between two SQLs, in either order."""
    return "|".join(sorted((sql_key(sql_a), sql_key(sql_b))))


def pair_key(a, b):
    """The key of a join between two tables, in either order."""
    return "|".join(sorted((str(a or "").lower(), str(b or "").lower())))


def _tokens(text):
    return focus.tokens(text)


def _cut(text, width):
    text = str(text)
    return text if len(text) <= width else text[:width - 1] + "\u2026"


def _show(value, width=VALUE_WIDTH):
    """A value as the agent reads it: text, cut to `width`."""
    if value is None:
        return None
    if isinstance(value, (bytes, bytearray)):
        return _cut(value.hex(), width)
    if isinstance(value, (datetime.date, datetime.time)):
        return value.isoformat()
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return value
    return _cut(value, width)


def _cell(value):
    """One value of a result, normalised for comparing two readings: a
    number to CELL_DECIMALS decimals, half up, a moment in ISO form and a
    time stamp of midnight as its date, NULL as one sign, bytes in hex.
    5, 5.0 and Decimal('5.000') are the same value; so are AVG over a
    DECIMAL, which MariaDB gives to four decimals (312.4567), and AVG over
    a DOUBLE (312.45666666666665); so are DATE(x) and a DATETIME at
    midnight."""
    if value is None:
        return EMPTY
    if isinstance(value, bool):
        return "1" if value else "0"
    if isinstance(value, (int, float, decimal.Decimal)):
        try:
            number = decimal.Decimal(str(value)).quantize(
                decimal.Decimal(1).scaleb(-CELL_DECIMALS),
                rounding=decimal.ROUND_HALF_UP)
        except (decimal.InvalidOperation, ValueError):
            return str(value)
        # -0.00001 and 0 are the same number
        return format(number if number else abs(number), "f")
    if isinstance(value, datetime.datetime):
        if (value.time() == datetime.time()) and value.tzinfo is None:
            return value.date().isoformat()
        return value.isoformat()
    if isinstance(value, (datetime.date, datetime.time)):
        return value.isoformat()
    if isinstance(value, datetime.timedelta):
        return str(value)
    if isinstance(value, (bytes, bytearray)):
        return value.hex()
    return str(value)


def _ordered(sql):
    """Whether a statement orders the rows it returns: an ORDER BY on the
    outermost SELECT or UNION, never one inside a subquery or a window."""
    return _order_key(sql) is not None


def _order_key(sql):
    """What a statement orders its rows by, as ((expression, descending),
    ...) with the table names left out, or None when it orders nothing.
    Two readings ordered by the same key list the same ranking: rows they
    list otherwise are ties, in any order the database likes (review of
    the fixes: ties and a column swap were taken for another ranking)."""
    try:
        import sqlglot
        from sqlglot import exp
        tree = sqlglot.parse_one(str(sql), read="mysql")
    except Exception:
        return None
    order = tree.args.get("order") if tree is not None else None
    if not order:
        return None
    key = []
    for o in order.expressions:
        expr = o.this if isinstance(o, exp.Ordered) else o
        expr = expr.copy()
        for column in expr.find_all(exp.Column):
            column.set("table", None)
        key.append((expr.sql(dialect="mysql").lower(), bool(o.args.get("desc"))))
    return tuple(key)


def _rows_hash(rows):
    """sha1 of the rows sorted, so the order a query returns them in does
    not count."""
    body = "\n".join(sorted("\x1f".join(r) for r in rows))
    return hashlib.sha1(body.encode("utf-8")).hexdigest()


def _base_type(dtype):
    return re.sub(r"\(.*", "", str(dtype or "")).strip().lower()


def _words_of(name, singular):
    """A name's words in order, each singular: valid_from -> [valid, from]."""
    spaced = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", str(name or ""))
    return [singular(w) for w in re.split(r"[^A-Za-z0-9]+", spaced) if w]


def _outer_aggregate(tree, select):
    """Whether `tree` holds an aggregate of `select` itself, not one inside
    a window (SUM(x) OVER ()) or inside a subquery of its own."""
    from sqlglot import exp
    for agg in tree.find_all(exp.AggFunc):
        if agg.find_ancestor(exp.Window, exp.Select) is select:
            return True
    return False


def count_statements(sql, columns_of=None):
    """The statements that count the rows `sql` returns, in the order to
    try them: COUNT(*) around it; the same with every column of its result
    named apart (_named_apart_sql); the same with its columns replaced by 1
    (_count_sql). One that fails is never the count, the next is tried
    (review of 26 October: a result with two columns of one name could not
    be counted, and Ask said "at least 50 rows")."""
    found = [f"SELECT COUNT(*) FROM ({sql}) AS _n"]
    for other in (_named_apart_sql(sql, columns_of), _count_sql(sql)):
        if other and other not in found:
            found.append(other)
    return found


def _named_apart_sql(sql, columns_of=None):
    """COUNT(*) of the query with every column of its result named apart.

    MariaDB refuses a derived table with two columns of one name (1060):
    SELECT p.name, c.name has two, and so has SELECT * over two tables that
    each hold an id. Each column keeps its name when no other has it and is
    named _c<n> otherwise; `*` and `t.*` are spelled out from the catalogue
    (columns_of(table) -> [(column, type)]). The rows are the query's very
    rows, DISTINCT, GROUP BY and UNION included, so their count is its
    count. None when it cannot be written: a star over what the catalogue
    does not hold (a CTE, a derived table)."""
    import sqlglot
    from sqlglot import exp
    if _HAS_DIV.search(str(sql or "")):
        return None
    try:
        tree = sqlglot.parse_one(sql, read="mysql")
    except Exception:
        return None
    if not isinstance(tree, (exp.Select, exp.SetOperation)):
        return None
    tree = tree.copy()

    def branch(select):
        # a SELECT of the result itself: under nothing but UNIONs
        node = select.parent
        while node is not None and node is not tree:
            if not isinstance(node, (exp.SetOperation, exp.Subquery, exp.Paren)):
                return False
            node = node.parent
        return node is tree
    selects = [tree] if isinstance(tree, exp.Select) else [
        s for s in tree.find_all(exp.Select) if branch(s)]
    for select in selects:
        sources = []
        # "from_" in sqlglot 30, "from" before it
        start = select.args.get("from_") or select.args.get("from")
        for node in ([start.this] if start is not None else []) + [
                j.this for j in select.args.get("joins") or []]:
            sources.append((node.alias_or_name, node.name if isinstance(node, exp.Table) else None))
        out, seen = [], set()
        # the names the result has already: a name made up is never one of
        # them (SELECT x, _c2, x gave two _c2)
        taken = {str(e.alias_or_name or "").lower() for e in select.expressions}
        for e in select.expressions:
            star = isinstance(e, exp.Star) or (isinstance(e, exp.Column)
                                               and isinstance(e.this, exp.Star))
            items = []
            if star:
                qual = (e.table or "").lower() if isinstance(e, exp.Column) else ""
                for alias, table in sources:
                    if qual and str(alias).lower() != qual:
                        continue
                    cols = (columns_of(table) if table and columns_of else None) or []
                    if not cols:
                        return None
                    items += [exp.column(c, table=alias) for c, _type in cols]
                if not items:
                    return None
            else:
                items = [e]
            for item in items:
                name = (item.alias if isinstance(item, exp.Alias)
                        else item.name if isinstance(item, exp.Column) else "")
                name = str(name or "").lower()
                if not name or name in seen:
                    n = len(out)
                    while f"_c{n}" in taken or f"_c{n}" in seen:
                        n += 1
                    name = f"_c{n}"
                    item = exp.alias_(item.unalias() if isinstance(item, exp.Alias) else item,
                                      name)
                seen.add(name)
                out.append(item)
        select.set("expressions", out)
    tree.set("order", None)
    try:
        body = tree.sql(dialect="mysql")
    except Exception:
        return None
    return f"SELECT COUNT(*) FROM ({body}) AS _n"


# sqlglot writes x DIV 2 as CAST(x / 2 AS SIGNED), which rounds where DIV
# truncates: a rewritten count would count other rows (review of the fixes)
_HAS_DIV = re.compile(r"\bDIV\b", re.IGNORECASE)


def _count_sql(sql):
    """COUNT(*) of a SELECT with its columns replaced by 1, keeping FROM,
    WHERE, GROUP BY, HAVING and LIMIT, or None when the columns decide how
    many rows there are: DISTINCT, an aggregate with no GROUP BY (one
    row), a GROUP BY or a HAVING that names a column of the result by its
    alias or its position, a UNION. The ORDER BY is dropped: it changes
    no count."""
    import sqlglot
    from sqlglot import exp
    if _HAS_DIV.search(str(sql or "")):
        return None
    try:
        tree = sqlglot.parse_one(sql, read="mysql")
    except Exception:
        return None
    if not isinstance(tree, exp.Select) or tree.args.get("distinct"):
        return None
    group = tree.args.get("group")
    if not group and any(_outer_aggregate(e, tree) for e in tree.expressions):
        return None
    aliases = {e.alias.lower() for e in tree.expressions if e.alias}
    if group:
        for g in group.expressions:
            if isinstance(g, exp.Literal) or (
                    isinstance(g, exp.Column) and not g.table
                    and g.name.lower() in aliases):
                return None
    having = tree.args.get("having")
    if having is not None:
        # a column of HAVING outside any aggregate is one of the result's
        for column in having.find_all(exp.Column):
            if column.find_ancestor(exp.AggFunc, exp.Select) is tree:
                return None
    light = tree.copy()
    light.set("expressions", [exp.alias_(exp.Literal.number(1), "_x")])
    light.set("order", None)
    try:
        body = light.sql(dialect="mysql")
    except Exception:
        return None
    return f"SELECT COUNT(*) FROM ({body}) AS _n"


def _has_time(kind, present, timed):
    """Whether a moment column holds a time of day: True, False, or None
    when it cannot be told. A TIME holds one by its type; a DATE or a YEAR
    holds none to look at, which is no evidence of midnight; a DATETIME or
    a TIMESTAMP holds one when a value read is not at midnight (`timed`,
    how many are not), False only when every value read is at midnight.
    No value read at all (present 0) tells nothing."""
    if present == 0:
        return None
    if kind == "time":
        return True
    if kind in ("datetime", "timestamp"):
        return None if timed is None else bool(timed)
    return None


def _profile_nulls(known):
    """(nulls, null_share, present) from a column's profile, each None when
    it cannot be told: the profile keeps the share of NULLs and the rows
    it read, or a count, or a percentage."""
    rows = known.get("rows")
    rows = int(rows) if isinstance(rows, (int, float)) and not isinstance(
        rows, bool) else None
    share = next((known[k] for k in ("null_share", "null_fraction")
                  if isinstance(known.get(k), (int, float))), None)
    if share is None and isinstance(known.get("null_pct"), (int, float)):
        share = known["null_pct"] / 100.0
    nulls = known.get("nulls")
    nulls = int(nulls) if isinstance(nulls, (int, float)) and not isinstance(
        nulls, bool) else None
    if nulls is None and share is not None and rows is not None:
        nulls = int(round(rows * share))
    if share is None and nulls is not None and rows:
        share = round(nulls / rows, 4)
    present = rows - nulls if rows is not None and nulls is not None else None
    return nulls, (None if share is None else float(share)), present


def _version_flavour(con):
    """"mariadb", "mysql" or "unknown", from SELECT VERSION() on `con`."""
    cur = None
    try:
        cur = con.cursor()
        cur.execute("SELECT VERSION()")
        row = cur.fetchone()
        version = str(row[0] if row else "").lower()
    except Exception:
        return "unknown"
    finally:
        if cur is not None:
            _quietly(cur.close)
    if "mariadb" in version:
        return "mariadb"
    return "mysql" if re.match(r"\d", version) else "unknown"


def _bounded_seconds(seconds):
    """A statement timeout that bounds: 0 means none to both servers, so
    nothing below a millisecond is ever sent."""
    try:
        seconds = float(seconds)
    except (TypeError, ValueError):
        seconds = 0.0
    return max(seconds, 0.001) if math.isfinite(seconds) else 0.001


def _session_time(flavour, seconds):
    """The SET that bounds every statement of a session to `seconds`, or
    lifts the bound (seconds None); None for an unknown flavour."""
    if flavour == "mariadb":
        return ("SET SESSION max_statement_time=DEFAULT" if seconds is None
                else f"SET SESSION max_statement_time="
                     f"{_bounded_seconds(seconds):g}")
    if flavour == "mysql":
        return ("SET SESSION max_execution_time=DEFAULT" if seconds is None
                else f"SET SESSION max_execution_time="
                     f"{max(1, round(_bounded_seconds(seconds) * 1000))}")
    return None


def _with_limit(sql, rows):
    """A guarded SELECT with LIMIT `rows` after it when it has no LIMIT of
    its own, or as it is; after a UNION the LIMIT applies to the whole of
    it. Appended to the text rather than written back by sqlglot, so the
    query that runs is the query that was guarded."""
    import sqlglot
    from sqlglot import exp
    try:
        tree = sqlglot.parse_one(sql, read="mysql")
    except Exception:
        return sql
    if not isinstance(tree, (exp.Select, exp.SetOperation)):
        return sql
    if tree.args.get("limit") is not None:
        return sql
    if isinstance(tree, exp.SetOperation):
        last = tree.expression
        if isinstance(last, exp.Select) and last.args.get("limit") is not None:
            return sql
    return f"{sql} LIMIT {int(rows)}"


def _quietly(call, *args):
    """A clean-up step that must not hide the result: a rollback or a
    close that fails is ignored."""
    try:
        call(*args)
    except Exception:
        pass


# -------------------------------------------------------------- results
@dataclass
class ToolResult:
    """What one tool call found.

    `data` is the whole result, kept in memory; `digest` one line for the
    agent's notebook; `facts` what the verifier may reuse; `rows` how many
    items the result holds; `complete` False when a bound cut it (more
    rows, columns not swept); `cursor` where a find_value sweep that
    stopped early goes on. `lines` is the text render() pages through."""
    tool: str
    ok: bool
    data: object
    digest: str
    facts: list = field(default_factory=list)
    error: str = ""
    rows: int = 0
    complete: bool = True
    cursor: int | None = None
    lines: list = field(default_factory=list, repr=False)

    def render(self, max_tokens: int, offset: int = 0) -> tuple[str, dict]:
        """(text, size): the header, then the lines from `offset` as long
        as they fit `max_tokens`. size = {"rows", "tokens", "truncated",
        "more"}, `more` the offset to ask for next, or None. A cap of 0 or
        less renders the header alone, which is how the agent asks only
        for a result's size."""
        if not self.ok:
            text = f"{self.tool} failed: {self.error or self.digest}"
            return text, {"rows": 0, "tokens": _tokens(text),
                          "truncated": False, "more": None}
        head = f"{self.tool}: {self.digest}"
        offset = max(0, int(offset or 0))
        lines = self.lines
        if max_tokens is None or max_tokens <= 0:
            more = offset if offset < len(lines) else None
            return head, {"rows": self.rows, "tokens": _tokens(head),
                          "truncated": more is not None, "more": more}
        room = max_tokens - _tokens(head) - 24
        shown, i, cut = [], offset, False
        while i < len(lines):
            cost = _tokens(lines[i]) + 1
            if cost > room:
                if not shown:
                    # one line larger than the whole room: its start, said
                    # to be cut, rather than nothing at all
                    chars = max(int(room * focus.OTHER_CHARS_PER_TOKEN), 80)
                    shown.append(_cut(lines[i], chars) + " [cut]")
                    i += 1
                    cut = True
                break
            shown.append(lines[i])
            room -= cost
            i += 1
        more = i if i < len(lines) else None
        if more is not None:
            shown.append(f"... {len(lines) - i} more lines not shown "
                         f"(more from {i})")
        text = "\n".join([head] + shown)
        return text, {"rows": self.rows, "tokens": _tokens(text),
                      "truncated": cut or more is not None, "more": more}


def _failed(tool, error, data=None):
    error = _cut(str(error or "failed"), ERROR_WIDTH)
    return ToolResult(tool, False, data if data is not None else {},
                      f"failed: {error}", error=error)


class _BadArguments(ValueError):
    pass


def _profile_text(spec):
    """One column's profile as a line: nulls, distinct values, range,
    most frequent values, format."""
    parts = []
    nulls = next((spec[k] for k in ("null_share", "null_fraction", "nulls",
                                    "null_pct") if k in spec), None)
    if isinstance(nulls, (int, float)) and not isinstance(nulls, bool):
        parts.append(f"{nulls:.0%} null" if nulls <= 1 else f"{nulls} null")
    distinct = next((spec[k] for k in ("distinct", "distincts", "n_distinct")
                     if k in spec), None)
    if distinct is not None:
        parts.append(f"{distinct} distinct")
    low, high = spec.get("min"), spec.get("max")
    if low is not None or high is not None:
        parts.append(f"from {_show(low, 30)} to {_show(high, 30)}")
    top = next((spec[k] for k in ("top", "top_values", "frequent")
                if spec.get(k)), None)
    if isinstance(top, (list, tuple)):
        shown = []
        for item in top[:5]:
            if isinstance(item, dict):
                item = item.get("value")
            elif isinstance(item, (list, tuple)) and item:
                item = item[0]
            shown.append(str(_show(item, 30)))
        parts.append("most frequent " + ", ".join(shown))
    fmt = spec.get("format")
    if isinstance(fmt, dict):
        parts.append("format " + ", ".join(f"{k} {v}" for k, v in fmt.items()))
    elif fmt:
        parts.append(f"format {_cut(fmt, 60)}")
    if "has_time" in spec:
        parts.append("with a time of day" if spec["has_time"] else "dates only")
    return "; ".join(parts)


def load_profile(path):
    """{table: {column: profile}}, lower case, from a column profile file
    (data/files/<Profile>.profile.json), or {} when there is none or it
    cannot be read. Either {"tables": {t: {"columns": {...}}}}, or
    {t: {"columns": {...}}}, or {t: {column: {...}}}."""
    if not path:
        return {}
    try:
        data = json.loads(pathlib.Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    if not isinstance(data, dict):
        return {}
    tables = data.get("tables") if isinstance(data.get("tables"), dict) else data
    out = {}
    for table, spec in tables.items():
        if not isinstance(spec, dict):
            continue
        cols = spec.get("columns") if isinstance(spec.get("columns"), dict) else spec
        found = {str(c).lower(): v for c, v in cols.items() if isinstance(v, dict)}
        if found:
            out[str(table).lower()] = found
    return out


# ----------------------------------------------------------- the schema
class SchemaView:
    """One reading of the schema, made once per job from the first slot's
    clarifier, and only read afterwards, by every slot's thread.

    blocks   {table: its full block}, as the single judge shows it
    short    {table: its short form}
    lower    {lower-case name: catalogue name}
    edges    {table: [Edge]}, both ways, cheapest first
    flavour  "mariadb", "mysql" or "unknown", from SELECT VERSION(); the
             one thing written after: an "unknown" is asked again by each
             ToolBox before it runs anything, and the answer kept here
             (the same answer whichever thread writes it)
    profile  the column profile, {} when there is none
    """

    def __init__(self, clar, profile_path: str | None = None):
        self.schema = str(clar.schema or "")
        self.blocks = dict(clar._table_blocks())
        try:
            self.short = dict(clar._short_blocks())
        except Exception:
            self.short = {}
        self.lower = {t.lower(): t for t in self.blocks}
        self._columns = {t: [(c, str(d or "").lower()) for c, d in cols]
                         for t, cols in clar.columns.items()}
        for t in self._columns:
            self.lower.setdefault(t.lower(), t)
        self._index = {t.lower(): {c.lower(): (c, d) for c, d in cols}
                       for t, cols in self._columns.items()}
        try:
            self.samples = dict(clar.samples)
        except Exception:
            self.samples = {}
        self.edges = self._read_edges(clar)
        self.flavour = self._read_flavour(clar)
        self.profile = load_profile(profile_path)

    # ---------------------------------------------------------- names
    def table(self, name) -> str | None:
        """The catalogue's spelling of a table, or None. Quotes and a
        prefix naming this schema are taken off."""
        text = str(name or "").strip().strip("`\"'[] ")
        if "." in text:
            prefix, _, text = text.rpartition(".")
            if prefix.strip("`\"' ").lower() != self.schema.lower():
                return None
            text = text.strip("`\"' ")
        return self.lower.get(text.lower())

    def closest(self, name, n=3) -> list[str]:
        """The catalogue's tables whose names are closest to `name`."""
        text = str(name or "").strip().strip("`\"'[] ").lower()
        text = text.rpartition(".")[2]
        found = difflib.get_close_matches(text, list(self.lower), n=n, cutoff=0.5)
        return [self.lower[f] for f in found]

    def columns_of(self, table) -> list[tuple[str, str]]:
        """[(column, type)] of a table, in catalogue order; [] unknown."""
        t = self.table(table)
        return list(self._columns.get(t, [])) if t else []

    def column(self, table, column) -> str | None:
        """The catalogue's spelling of a column, or None."""
        t = self.table(table)
        if t is None:
            return None
        found = self._index.get(t.lower(), {}).get(
            str(column or "").strip("`\"' ").lower())
        return found[0] if found else None

    def type_of(self, table, column) -> str:
        t = self.table(table)
        found = self._index.get((t or "").lower(), {}).get(str(column or "").lower())
        return _base_type(found[1]) if found else ""

    def has(self, table, column) -> bool:
        return self.column(table, column) is not None

    # ---------------------------------------------------------- joins
    def _read_edges(self, clar):
        found = {}

        def put(a, a_cols, b, b_cols, source, condition=None):
            a, b = self.table(a), self.table(b)
            if a is None or b is None:
                return
            left = [c.strip() for c in str(a_cols or "").split(",") if c.strip()]
            right = [c.strip() for c in str(b_cols or "").split(",") if c.strip()]
            if not left or len(left) != len(right):
                return
            left = [self.column(a, c) for c in left]
            right = [self.column(b, c) for c in right]
            if None in left or None in right:
                return
            side_a, side_b = (a, tuple(left)), (b, tuple(right))
            key = (min(side_a, side_b), max(side_a, side_b),
                   str(condition or ""))
            if key in found:
                return          # the same join, read from a surer source
            when = f" WHEN {condition}" if condition else ""
            found[key] = (
                Edge(a, b, " AND ".join(f"{a}.{x} = {b}.{y}"
                                        for x, y in zip(left, right)) + when,
                     source, WEIGHTS[source]),
                Edge(b, a, " AND ".join(f"{b}.{y} = {a}.{x}"
                                        for x, y in zip(left, right)) + when,
                     source, WEIGHTS[source]))

        try:
            clar.foreign_keys           # reads the catalogue's own keys
            declared = getattr(clar, "_foreign_keys", None) or {}
        except Exception:
            declared = {}
        for (table, column), (other, other_column) in sorted(
                declared.items(), key=lambda kv: (str(kv[0]), str(kv[1]))):
            put(table, column, other, other_column, "fk")
        try:
            graph = list(clar.graph_edges or [])
        except Exception:
            graph = []
        for edge in graph:
            if len(edge) < 4:
                continue
            condition = edge[4] if len(edge) > 4 and isinstance(edge[4], str) else None
            put(edge[0], edge[1], edge[2], edge[3], "graph", condition)
        try:
            written = dict(clar._documented("links") or {})
            # a column whose target depends on a type code: every target,
            # each with its condition (dictionary "polymorphic")
            for key, targets in (clar._documented("polymorphic") or {}).items():
                written[key] = list(targets)
        except Exception:
            written = {}
        for key, value in sorted(written.items(), key=lambda kv: str(kv[0])):
            for link in (value if isinstance(value, list) else [value]):
                if (not isinstance(key, tuple) or len(key) < 2
                        or not isinstance(link, (tuple, list)) or len(link) < 2):
                    continue
                about = link[2] if len(link) > 2 and isinstance(link[2], dict) else {}
                when = about.get("when")
                condition = None
                if isinstance(when, dict) and when.get("column"):
                    value_text = str(when.get("value", "")).replace("'", "''")
                    holder = self.table(key[0]) or key[0]
                    condition = f"{holder}.{when['column']} = '{value_text}'"
                put(key[0], key[1], link[0], link[1], "kb", condition)

        edges = {}
        for forward, backward in found.values():
            edges.setdefault(forward.a, []).append(forward)
            if forward.a != forward.b:
                edges.setdefault(backward.a, []).append(backward)
        for t in edges:
            edges[t].sort(key=lambda e: (e.weight, e.b, e.via))
        return edges

    @staticmethod
    def _read_flavour(clar):
        """The flavour, or "unknown" when SELECT VERSION() does not answer;
        each ToolBox asks again before it runs anything (ToolBox._flavour)."""
        try:
            con = clar.connect()
        except Exception:
            return "unknown"
        try:
            return _version_flavour(con)
        finally:
            _quietly(con.close)

    def _costs_to(self, target):
        """{table: cheapest cost to reach `target`}, Dijkstra, no bound
        on hops: the lower bound the path walk prunes with."""
        dist = {target: 0.0}
        heap = [(0.0, target)]
        while heap:
            d, t = heapq.heappop(heap)
            if d > dist.get(t, float("inf")):
                continue
            for e in self.edges.get(t, ()):
                nd = d + e.weight
                if nd < dist.get(e.b, float("inf")):
                    dist[e.b] = nd
                    heapq.heappush(heap, (nd, e.b))
        return dist

    def _hops_to(self, target, limit):
        hops = {target: 0}
        queue = deque([target])
        while queue:
            t = queue.popleft()
            if hops[t] >= limit:
                continue
            for e in self.edges.get(t, ()):
                if e.b not in hops:
                    hops[e.b] = hops[t] + 1
                    queue.append(e.b)
        return hops

    def _cheapest_route(self, a, b, max_hops):
        """(cost, tables, via, sources) of the cheapest simple path from a
        to b within max_hops joins, or None: Bellman-Ford bounded by the
        hops, a tie going to the fewest joins, then by name."""
        def rank(route):
            return (round(route[0], 9), len(route[1]), route[1], route[2])

        best = {a: (0.0, (a,), (), ())}
        for _ in range(max_hops):
            nxt = dict(best)
            for t, (d, tables, via, sources) in best.items():
                for e in self.edges.get(t, ()):
                    if e.b in tables:
                        continue
                    route = (d + e.weight, tables + (e.b,), via + (e.via,),
                             sources + (e.source,))
                    if e.b not in nxt or rank(route) < rank(nxt[e.b]):
                        nxt[e.b] = route
            best = nxt
        return best.get(b)

    def _cheapest(self, a, b, max_hops):
        """The cheapest cost from a to b within max_hops joins, or None."""
        route = self._cheapest_route(a, b, max_hops)
        return None if route is None else route[0]

    def paths(self, a, b, max_hops=MAX_HOPS, limit=MAX_PATHS,
              seen: set | None = None) -> list[dict]:
        """Up to `limit` simple join paths from a to b, within `max_hops`
        joins, none dearer than the cheapest by more than PATH_SLACK.

        [{"tables", "via", "sources", "unseen", "cost"}], cheapest first:
        `via` one join per hop, "a.x = b.y"; `sources` where each was
        read; `unseen` the tables of the path not in `seen` (the tables
        already described), which is what points the agent at a table
        between two others it was never shown. [] when there is none or a
        name is unknown.

        The cheapest path (_cheapest_route) is always the first; the others
        are walked best first, by their cost so far plus the cheapest cost
        left (_costs_to), so the bounds on the walk (PATH_EXPANSIONS,
        PATH_FOUND) can only drop the dearer ones."""
        a, b = self.table(a), self.table(b)
        if a is None or b is None:
            return []
        known = {str(s).lower() for s in (seen or ())}

        def shaped(tables, via, sources, cost):
            return {"tables": list(tables), "via": list(via),
                    "sources": list(sources),
                    "unseen": [t for t in tables if t.lower() not in known],
                    "cost": round(cost, 3)}

        if a == b:
            return [shaped([a], [], [], 0.0)]
        route = self._cheapest_route(a, b, max_hops)
        if route is None:
            return []
        best = route[0]
        bound = best * PATH_SLACK + 1e-9
        costs = self._costs_to(b)
        hops = self._hops_to(b, max_hops)
        found = {(route[1], route[2]): (best, route[1], route[2], route[3])}
        walked, pushed = 0, 0
        heap = [(costs.get(a, 0.0), 0.0, 0, (a,), (), ())]
        while heap and walked < PATH_EXPANSIONS and len(found) < PATH_FOUND:
            estimate, cost, _n, tables, via, sources = heapq.heappop(heap)
            if len(found) >= limit:
                # nothing left can be cheaper than the paths kept: the
                # estimate never overstates what a path will cost
                kept = sorted(c for c, _t, _v, _s in found.values())
                if estimate > kept[limit - 1] + 1e-9:
                    break
            t = tables[-1]
            if t == b:
                found.setdefault((tables, via), (cost, tables, via, sources))
                continue
            for e in self.edges.get(t, ()):
                walked += 1
                if e.b in tables:
                    continue
                c = cost + e.weight
                left = costs.get(e.b, float("inf"))
                if c + left > bound:
                    continue
                if len(tables) + hops.get(e.b, max_hops + 1) > max_hops:
                    continue
                pushed += 1
                heapq.heappush(heap, (c + left, c, pushed, tables + (e.b,),
                                      via + (e.via,), sources + (e.source,)))
        ordered = sorted(found.values(),
                         key=lambda p: (round(p[0], 9), len(p[1]), p[1], p[2]))
        return [shaped(tables, via, sources, cost)
                for cost, tables, via, sources in ordered[:limit]]

    def connected(self, tables, max_hops=6) -> tuple[bool, list[str]]:
        """(every table reached from the first within max_hops joins, the
        tables that are not, as they were given). An unknown name is not
        reached."""
        given = list(dict.fromkeys(str(t) for t in tables or () if t))
        if not given:
            return True, []
        names = [self.table(t) for t in given]
        start = next((n for n in names if n), None)
        if start is None:
            return False, given
        reach = set(self._hops_to(start, max_hops))
        missing = [g for g, n in zip(given, names) if n is None or n not in reach]
        return not missing, missing


# ------------------------------------------------------------- the tools
class ToolBox:
    """The tools of one slot: its clarifier, the job's SchemaView, and
    the tables this slot's agent has described so far (`seen`)."""

    def __init__(self, clar, view: SchemaView, settings: Settings | None = None,
                 seen: set | None = None):
        self.clar = clar
        self.view = view
        self.settings = settings or Settings()
        self.seen = seen if seen is not None else set()
        self.clock = time.monotonic
        # where each find_value sweep stopped, so one that is resumed knows
        # whether a lookup failed before it, and whether every column
        # before it was looked up (`whole`): a cursor that skipped some
        # never makes the sweep complete, however far it goes on
        self._sweeps = {}

    # ------------------------------------------------------- dispatch
    def run(self, tool: str, args: dict) -> ToolResult:
        """Run one tool on the agent's arguments. Never raises: an unknown
        tool, a missing or mistyped argument and a failure inside all come
        back as a ToolResult with ok False and the error to show."""
        name = str(tool or "").strip()
        try:
            if name not in TOOLS:
                return _failed(name or "unknown",
                               f"unknown tool {name!r}; the tools are "
                               + ", ".join(TOOLS))
            args = args if isinstance(args, dict) else {}
            return getattr(self, "_call_" + name)(args)
        except _BadArguments as e:
            return _failed(name, str(e))
        except Exception as e:
            return _failed(name, f"{type(e).__name__}: {e}")

    @staticmethod
    def _text(args, key, tool):
        value = args.get(key)
        if isinstance(value, (list, tuple)):
            value = " ".join(str(v) for v in value)
        value = str(value if value is not None else "").strip()
        if not value:
            raise _BadArguments(f"{tool} needs `{key}`")
        return value

    @staticmethod
    def _number(args, key, default):
        if args.get(key) in (None, ""):
            return default
        try:
            return int(args.get(key))
        except (TypeError, ValueError):
            raise _BadArguments(f"`{key}` must be a whole number")

    @staticmethod
    def _names(value):
        if value is None:
            return []
        if isinstance(value, str):
            value = re.split(r"[,\s]+", value)
        if not isinstance(value, (list, tuple, set)):
            raise _BadArguments("give table names as a list")
        return [str(v).strip() for v in value if str(v or "").strip()]

    def _call_search_tables(self, args):
        return self.search_tables(self._text(args, "phrase", "search_tables"),
                                  self._number(args, "n", SEARCH_TABLES),
                                  self._number(args, "cursor", 0))

    def _call_describe_tables(self, args):
        names = self._names(args.get("names") if args.get("names") is not None
                            else args.get("tables") or args.get("table"))
        if not names:
            raise _BadArguments("describe_tables needs `names`")
        return self.describe_tables(names)

    def _call_find_columns(self, args):
        return self.find_columns(self._text(args, "phrase", "find_columns"),
                                 self._number(args, "n", FIND_COLUMNS),
                                 self._names(args.get("tables")) or None)

    def _call_sample_values(self, args):
        return self.sample_values(self._text(args, "table", "sample_values"),
                                  self._text(args, "column", "sample_values"),
                                  self._number(args, "n", SAMPLE_VALUES))

    def _call_find_value(self, args):
        return self.find_value(self._text(args, "value", "find_value"),
                               self._names(args.get("tables")) or None,
                               self._number(args, "cursor", 0))

    def _call_join_path(self, args):
        return self.join_path(self._text(args, "a", "join_path"),
                              self._text(args, "b", "join_path"))

    def _call_time_columns(self, args):
        return self.time_columns(self._text(args, "table", "time_columns"))

    def _call_run_count(self, args):
        return self.run_count(self._text(args, "sql", "run_count"))

    def _call_compute(self, args):
        return self.compute(self._text(args, "expression", "compute"))

    def _call_clock(self, args):
        table = args.get("table")
        return self.read_clock(str(table).strip() if table else None)

    def _call_compare_readings(self, args):
        sqls = args.get("sqls")
        if not isinstance(sqls, (list, tuple)):
            raise _BadArguments("compare_readings needs `sqls`, a list of 2 "
                                "to 4 SQL queries")
        return self.compare_readings([str(s) for s in sqls])

    # --------------------------------------------------- the schema
    def _unknown(self, tool, name):
        close = self.view.closest(name)
        return _failed(tool, f"unknown table {name}"
                       + (f" (closest: {', '.join(close)})" if close else ""),
                       {"unknown": [{"name": name, "closest": close}]})

    def _scope(self, tables):
        """(the catalogue names of `tables`, or None for everywhere; the
        names not found)."""
        if not tables:
            return None, []
        scope, unknown = set(), []
        for name in tables:
            t = self.view.table(name)
            if t is None:
                unknown.append(name)
            else:
                scope.add(t)
        return (scope or None), unknown

    def search_tables(self, phrase, n=SEARCH_TABLES, cursor=0) -> ToolResult:
        """The tables a phrase points at, best first, each in short form:
        focus.rank, which scores the schema's words, the column index, the
        corpus and the joins, as the single judge's schema cut does."""
        n = min(max(int(n or SEARCH_TABLES), 1), SEARCH_TABLES_MAX)
        cursor = max(0, int(cursor or 0))
        ranked = focus.rank(self.clar, phrase, self.view.blocks)
        matched = [(t, s, w) for t, s, w in ranked if s > 0]
        page = matched[cursor:cursor + n]
        nxt = cursor + len(page) if cursor + len(page) < len(matched) else None
        items = [{"table": t, "score": round(s, 2), "why": list(w),
                  "short": self.view.short.get(t)
                  or self.view.blocks[t].split("\n", 1)[0]}
                 for t, s, w in page]
        total = len(self.view.blocks)
        data = {"tables": items, "tables_total": total,
                "matched": len(matched), "cursor": nxt}
        if not matched:
            data["closest"] = self.view.closest(phrase)
            digest = (f"no table matches {phrase!r} among {total}; try "
                      f"other words, or find_columns")
            if data["closest"]:
                digest += f" (names close to it: {', '.join(data['closest'])})"
        else:
            digest = (f"{len(matched)} of {total} tables match {phrase!r}: "
                      + ", ".join(f"{i['table']} {i['score']:.1f}"
                                  for i in items[:5])
                      + (f"; {len(matched) - cursor - len(page)} more from "
                         f"cursor {nxt}" if nxt is not None else ""))
        lines = [f"{i['table']}  score {i['score']:.2f} by "
                 f"{', '.join(i['why'])}\n{i['short']}" for i in items]
        facts = [Fact("table_exists", i["table"].lower(), {"table": i["table"]})
                 for i in items]
        return ToolResult("search_tables", True, data, _cut(digest, DIGEST_WIDTH),
                          facts, rows=len(items), complete=nxt is None,
                          lines=lines)

    def _profile_lines(self, table):
        spec = self.view.profile.get(table.lower()) or {}
        out = []
        for column, _dtype in self.view.columns_of(table):
            said = _profile_text(spec.get(column.lower()) or {})
            if said:
                out.append(f"  {column}: {said}")
        return out

    def describe_tables(self, names) -> ToolResult:
        """Up to DESCRIBE_MAX tables whole: every column with its type, its
        key, a few values and what it means, and the column profile when
        there is one. An unknown name comes back with the closest ones.
        Each table described is added to `seen`."""
        names = list(dict.fromkeys(self._names(names)))
        asked, skipped = names[:DESCRIBE_MAX], names[DESCRIBE_MAX:]
        tables, unknown, lines, facts = [], [], [], []
        for name in asked:
            t = self.view.table(name)
            if t is None:
                unknown.append({"name": name, "closest": self.view.closest(name)})
                continue
            if any(x["table"] == t for x in tables):
                continue
            profile = self._profile_lines(t)
            tables.append({"table": t, "block": self.view.blocks.get(t, ""),
                           "profile": profile, "seen_before": t in self.seen})
            lines.extend(self.view.blocks.get(t, f"TABLE {t}").split("\n"))
            if profile:
                lines.append("  -- profile of the columns:")
                lines.extend(profile)
            cols = self.view.columns_of(t)
            facts.append(Fact("table_exists", t.lower(),
                              {"table": t, "columns": len(cols)}))
            facts.extend(Fact("column_exists", f"{t}.{c}".lower(),
                              {"table": t, "column": c, "type": d})
                         for c, d in cols)
        for x in tables:
            self.seen.add(x["table"])
        for u in unknown:
            lines.append(f"unknown table {u['name']}"
                         + (f" (closest: {', '.join(u['closest'])})"
                            if u["closest"] else ""))
        if skipped:
            lines.append(f"not described, {DESCRIBE_MAX} at a time: "
                         + ", ".join(skipped))
        data = {"tables": tables, "unknown": unknown, "skipped": skipped}
        digest = ("described " + ", ".join(
            f"{x['table']} ({len(self.view.columns_of(x['table']))} columns"
            + (", seen before" if x["seen_before"] else "") + ")"
            for x in tables)) if tables else "nothing described"
        if unknown:
            digest += "; unknown: " + ", ".join(
                u["name"] + (f" (closest: {', '.join(u['closest'])})"
                             if u["closest"] else "") for u in unknown)
        if skipped:
            digest += f"; {len(skipped)} left for another call"
        digest = _cut(digest, DIGEST_WIDTH)
        if not tables:
            return ToolResult("describe_tables", False, data, digest,
                              error=_cut(digest, ERROR_WIDTH), lines=lines)
        return ToolResult("describe_tables", True, data, digest, facts,
                          rows=len(tables), complete=not skipped, lines=lines)

    def find_columns(self, phrase, n=FIND_COLUMNS, tables=None) -> ToolResult:
        """The columns a phrase points at and how: by their whole name, a
        word of it, their table's name, what they are documented to mean,
        what their table is for, or closeness in meaning (the column
        index). `direct` marks a column that answers the phrase on its own
        (Clarifier.answers_directly)."""
        n = min(max(int(n or FIND_COLUMNS), 1), FIND_COLUMNS_MAX)
        scope, unknown = self._scope(tables)
        if tables and scope is None:
            return self._unknown("find_columns", unknown[0])
        evidence = self.clar.column_evidence(phrase, semantic=True, tables=scope)
        try:
            direct = set(self.clar.answers_directly(phrase))
        except Exception:
            direct = set()
        # surest evidence first, and within one kind the columns that
        # answer the phrase on their own
        rank = {how: i for i, how in enumerate(EVIDENCE_ORDER)}
        ordered = [e for _i, e in sorted(
            enumerate(evidence),
            key=lambda x: (rank.get(x[1][2], len(rank)),
                           f"{x[1][0]}.{x[1][1]}" not in direct, x[0]))]
        items = []
        for table, column, how in ordered[:n]:
            labels = self.clar.enum_labels(table, column)
            if labels:
                example = [f"{code} ({label})" for code, label
                           in list(labels.items())[:5]]
            else:
                example = list((self.view.samples.get(
                    (table.lower(), column.lower())) or [])[:5])
            items.append({"table": table, "column": column,
                          "type": self.view.type_of(table, column), "how": how,
                          "meaning": self.clar.means(table, column),
                          "e_g": [str(_show(v, 40)) for v in example],
                          "direct": f"{table}.{column}" in direct})
        data = {"columns": items, "found": len(evidence), "unknown": unknown}
        lines = [f"{i['table']}.{i['column']}  {i['type']}  [{i['how']}"
                 + (", answers it directly" if i["direct"] else "") + "]"
                 + (f"  -- {_cut(i['meaning'], 120)}" if i["meaning"] else "")
                 + (f"  e.g. {', '.join(i['e_g'])}" if i["e_g"] else "")
                 for i in items]
        if items:
            digest = (f"{len(evidence)} columns for {phrase!r}: "
                      + ", ".join(f"{i['table']}.{i['column']} ({i['how']})"
                                  for i in items[:4])
                      + (f"; first {n} shown" if len(evidence) > n else ""))
        else:
            digest = (f"no column name or description holds the words of "
                      f"{phrase!r}" + (" in those tables" if scope else ""))
        facts = [Fact("column_exists", f"{i['table']}.{i['column']}".lower(),
                      {"table": i["table"], "column": i["column"],
                       "type": i["type"]}) for i in items]
        return ToolResult("find_columns", True, data, _cut(digest, DIGEST_WIDTH),
                          facts, rows=len(items), complete=len(evidence) <= n,
                          lines=lines)

    # --------------------------------------------------- the values
    def _flavour(self, con):
        """The database's flavour, read again on `con` when the view's
        first reading failed: one SELECT VERSION() that did not answer
        must not leave a whole job with no time limit. A reading that
        succeeds is kept on the view, the same answer whichever thread
        writes it."""
        if self.view.flavour in ("mariadb", "mysql"):
            return self.view.flavour
        found = _version_flavour(con)
        if found != "unknown":
            self.view.flavour = found
        return found

    def _set_time(self, con, seconds) -> bool:
        """Bound every statement on a connection, or lift the bound
        (seconds None). True when the server took it; False when the
        flavour is unknown or the server refused, and then nothing on
        that connection is bounded."""
        sql = _session_time(self._flavour(con), seconds)
        if sql is None:
            return False
        cur = None
        try:
            cur = con.cursor()
            cur.execute(sql)
            return True
        except Exception:
            return False
        finally:
            if cur is not None:
                _quietly(cur.close)

    @contextlib.contextmanager
    def _bounded(self, seconds):
        """A lent connection whose statements stop after `seconds`, or
        None when none opens or no time limit could be set on it: a
        lookup that could run for ever is not run."""
        con = self.clar._lent_connection()
        if con is not None and not self._set_time(con, seconds):
            self.clar._close(con)
            con = None
        try:
            yield con
        finally:
            if con is not None:
                self._set_time(con, None)
                self.clar._close(con)

    def compute(self, expression) -> ToolResult:
        """One expression on numbers and dates, worked out by the code
        (calc.py): the agent writes "add_months(today(), -3)" rather than
        counting months in its head. today() is the question's date."""
        today = getattr(self.clar, "today", None) or datetime.date.today()
        try:
            value = calc.evaluate(expression, today=today, now=getattr(self.clar, "now", None))
        except calc.Refused as e:
            return _failed("compute", str(e))
        said = calc.show(value)
        line = f"{_cut(str(expression), 120)} = {said}"
        return ToolResult("compute", True, {"expression": str(expression), "value": said},
                          line, rows=1, lines=[line])

    def read_clock(self, table=None) -> ToolResult:
        """The agent's clock tool (not self.clock, the timer the sweeps are
        bounded by: named alike, the tool hid it and every call failed with
        "time.monotonic() takes no arguments", 23 October). When it is: the asker's date and time (the question's context),
        the database server's clock and time zone, and for a table the
        latest moment each of its date columns holds, so the agent sees
        whether the data reaches the period the question counts from today."""
        today = getattr(self.clar, "today", None) or datetime.date.today()
        data = {"today": today.isoformat(),
                "asker": _cut(str(getattr(self.clar, "context", "") or ""), 300)}
        with self._bounded(self.settings.sql_seconds) as con:
            if con is not None:
                try:
                    cur = con.cursor()
                    cur.execute("SELECT NOW(), @@session.time_zone, @@system_time_zone")
                    row = cur.fetchone() or (None, None, None)
                    data.update(database_now=_show(row[0]), database_time_zone=row[1],
                                system_time_zone=row[2])
                except Exception as e:
                    data["database_error"] = _cut(str(e), ERROR_WIDTH)
        latest = []
        if table:
            t = self.view.table(table)
            if t is None:
                return self._unknown("clock", table)
            moment_types = tuple(getattr(self.clar, "MOMENTS", ()))
            moments = [(c, _base_type(d)) for c, d in self.view.columns_of(t)
                       if _base_type(d) in moment_types][:MOMENTS_MAX]
            read = self._moments_read(t, moments) if moments else {}
            latest = [{"column": c, "latest": _show((read.get(c) or (None, None))[1])}
                      for c, _k in moments]
            data.update(table=t, latest=latest)
        lines = [f"the asker's day: {data['today']}"]
        if data.get("database_now"):
            lines.append(f"the database's clock: {data['database_now']} "
                         f"(time zone {data.get('database_time_zone')}, "
                         f"system {data.get('system_time_zone')})")
        lines += [f"{data['table']}.{x['column']}: latest {x['latest']}" for x in latest]
        digest = "; ".join(lines[:3]) + (f"; +{len(lines) - 3} more" if len(lines) > 3 else "")
        return ToolResult("clock", True, data, digest, rows=len(lines), lines=lines)

    def sample_values(self, table, column, n=SAMPLE_VALUES) -> ToolResult:
        """Up to n distinct values a column really holds, each cut to
        VALUE_WIDTH characters; `complete` when there are no more. The
        dictionary's labels of its codes, and whether it is a key."""
        t = self.view.table(table)
        if t is None:
            return self._unknown("sample_values", table)
        c = self.view.column(t, column)
        if c is None:
            names = [x for x, _d in self.view.columns_of(t)]
            close = difflib.get_close_matches(str(column).lower(),
                                              [x.lower() for x in names], n=3)
            return _failed("sample_values",
                           f"{t} has no column {column}"
                           + (f" (closest: {', '.join(close)})" if close
                              else f" (its columns: {', '.join(names[:12])})"))
        n = min(max(int(n or SAMPLE_VALUES), 1), SAMPLE_VALUES_MAX)
        with self._bounded(self.settings.sql_seconds) as con:
            if con is None:
                # with none lent, the clarifier would open one of its own,
                # with no time limit
                return _failed("sample_values", NO_BOUNDED_CONNECTION)
            values, checked = self.clar._distinct_values_checked(
                t, c, limit=n + 1, con=con)
        if not checked:
            return _failed("sample_values",
                           f"could not read the values of {t}.{c}")
        complete = len(values) <= n
        shown = [_show(v) for v in values[:n]]
        labels = self.clar.enum_labels(t, c)
        data = {"table": t, "column": c, "values": shown, "complete": complete,
                "labels": labels, "is_key": bool(self.clar.is_a_key(t, c)),
                "type": self.view.type_of(t, c)}
        said = [f"{v} = {labels[str(v)]}" if str(v) in labels else str(v)
                for v in shown]
        lines = [", ".join(said[i:i + 10]) for i in range(0, len(said), 10)]
        if data["is_key"]:
            lines.append("(a key: its values identify rows, they say nothing "
                         "about them)")
        digest = (f"{t}.{c} ({data['type']}): {len(shown)} values"
                  + (", all of them" if complete else f", more than {n} exist")
                  + (": " + ", ".join(str(v) for v in said[:6]) if said else ""))
        facts = [Fact("values_seen", f"{t}.{c}".lower(),
                      {"table": t, "column": c, "values": shown,
                       "complete": complete})]
        return ToolResult("sample_values", True, data, _cut(digest, DIGEST_WIDTH),
                          facts, rows=len(shown), complete=complete, lines=lines)

    def _value_columns(self, value, scope):
        """The columns a value may be stored in, the likeliest first: text
        columns, and coded columns the dictionary labels. A column whose
        labels name the value comes first, then those whose sample values
        hold one of its words, then by where focus.vocabulary finds its
        words in the table."""
        words = self.clar._content_words(value)
        try:
            vocabulary = focus.vocabulary(self.clar)
        except Exception:
            vocabulary = {}
        found = []
        for table in sorted(self.view._columns):
            if scope is not None and table not in scope:
                continue
            here = vocabulary.get(table, {})
            near = sum(focus.WHERE.get(here[w], 0.0) for w in words if w in here)
            for column, dtype in self.view._columns[table]:
                labels = self.clar.enum_labels(table, column)
                text = any(k in dtype for k in ("char", "text", "enum"))
                if not (text or labels):
                    continue
                likely = near
                if labels and self.clar.codes_for(value, labels):
                    likely += 10.0
                held = self.view.samples.get((table.lower(), column.lower()))
                if held and words & self.clar._content_words(
                        " ".join(map(str, held))):
                    likely += 5.0
                found.append((-likely, len(found), table, column))
        found.sort()
        return [(t, c) for _p, _i, t, c in found]

    def find_value(self, value, tables=None, cursor=0) -> ToolResult:
        """Where a value is stored: a sweep of the text columns, likeliest
        first, each looked up by Clarifier._near_values_checked (LIKE on
        its longest word, then SOUNDEX held close to the spelling, and the
        dictionary's labels for a coded column), on one connection whose
        statements stop after LOOKUP_SECONDS.

        Bounded: SWEEP_COLUMNS columns and SWEEP_SECONDS a call, and it
        stops at SWEEP_HITS columns found; `cursor` goes on from where one
        stopped. `complete` means what check_value's `checked` means: the
        value was found, or every eligible column was looked up and none
        failed, which is the only state that proves an absence."""
        text = str(value or "").strip()
        if len(text) < VALUE_MIN_CHARS:
            return _failed("find_value",
                           f"{text!r} is shorter than {VALUE_MIN_CHARS} "
                           f"characters and would match too much to prove "
                           f"anything; give the value as it would be "
                           f"stored, or read a column with sample_values")
        scope, unknown = self._scope(tables)
        if tables and scope is None:
            return self._unknown("find_value", unknown[0])
        eligible = self._value_columns(text, scope)
        start = max(0, int(cursor or 0))
        key = (text.lower(), tuple(sorted(scope)) if scope else None)
        before = self._sweeps.get(key)
        resumed = (start > 0 and before is not None
                   and before["next"] == start and before.get("whole") is True)
        hits, looked, failed, stopped = [], 0, 0, None
        deadline = self.clock() + SWEEP_SECONDS
        i = start
        with self._bounded(LOOKUP_SECONDS) as con:
            if con is None:
                return _failed("find_value", NO_BOUNDED_CONNECTION)
            while i < len(eligible):
                if len(hits) >= SWEEP_HITS:
                    stopped = "hits"
                    break
                if looked >= SWEEP_COLUMNS:
                    stopped = "columns"
                    break
                if self.clock() > deadline:
                    stopped = "time"
                    break
                table, column = eligible[i]
                i += 1
                found, ok = self.clar._near_values_checked(table, column, text,
                                                           con=con)
                looked += 1
                if not ok:
                    failed += 1
                if found:
                    hits.append({"table": table, "column": column,
                                 "matches": [_show(v) for v in
                                             found[:MATCHES_SHOWN]]})
        failed_total = failed + (before["failed"] if resumed else 0)
        whole = start == 0 or resumed
        nxt = i if i < len(eligible) else None
        complete = bool(hits) or (nxt is None and whole and failed_total == 0)
        self._sweeps[key] = {"next": nxt if nxt is not None else len(eligible),
                             "failed": failed_total, "whole": whole}
        data = {"value": text, "hits": hits, "checked": looked,
                "eligible": len(eligible), "failed": failed,
                "complete": complete, "cursor": nxt, "unknown": unknown}
        where = " in those tables" if scope else ""
        if hits:
            digest = (f"{text!r} found in " + "; ".join(
                f"{h['table']}.{h['column']} ({', '.join(map(str, h['matches']))})"
                for h in hits))
        elif complete:
            digest = (f"{text!r} is in no column{where}: all "
                      f"{len(eligible)} text columns looked up")
        else:
            digest = f"{text!r} not found in the {looked} columns looked up{where}"
        tail = []
        if failed:
            tail.append(f"{failed} lookups failed")
        if nxt is not None:
            tail.append(f"{len(eligible) - nxt} columns left, cursor {nxt}"
                        + (" (time ran out)" if stopped == "time" else ""))
        if tail:
            digest += "; " + ", ".join(tail)
        lines = [f"{h['table']}.{h['column']} holds "
                 + ", ".join(map(str, h["matches"])) for h in hits]
        lines.append(f"looked up {looked} of {len(eligible)} text columns"
                     f"{where} from {start}"
                     + (f", {failed} failed" if failed else "")
                     + ("; the sweep is complete" if complete and not hits else "")
                     + (f"; cursor {nxt} goes on" if nxt is not None else ""))
        value_key = text.lower()
        facts = [Fact("value_found", value_key, dict(h)) for h in hits]
        if complete and not hits:
            facts.append(Fact("value_absent", value_key,
                              {"value": text, "eligible": len(eligible),
                               "scope": sorted(scope) if scope else None}))
        return ToolResult("find_value", True, data, _cut(digest, DIGEST_WIDTH),
                          facts, rows=len(hits), complete=complete, cursor=nxt,
                          lines=lines)

    # ---------------------------------------------------- the joins
    def join_path(self, a, b) -> ToolResult:
        """Up to MAX_PATHS ways to join two tables within MAX_HOPS joins,
        the cheapest first, each with its joins, where each was read, and
        the tables on it not described yet."""
        ta, tb = self.view.table(a), self.view.table(b)
        if ta is None:
            return self._unknown("join_path", a)
        if tb is None:
            return self._unknown("join_path", b)
        found = self.view.paths(ta, tb, MAX_HOPS, MAX_PATHS, seen=self.seen)
        data = {"found": bool(found), "paths": found, "hops_searched": MAX_HOPS}
        lines = []
        for n, p in enumerate(found, 1):
            lines.append(f"path {n}: {' -> '.join(p['tables'])}  "
                         f"({len(p['via'])} joins, by "
                         f"{', '.join(p['sources']) or '-'})")
            lines.extend(f"  {v}" for v in p["via"])
            if p["unseen"]:
                lines.append("  not described yet: " + ", ".join(p["unseen"]))
        if found:
            first = found[0]
            # the first is the cheapest by where its joins were read, which
            # is not always the one of fewest joins
            digest = (f"{ta} to {tb}: {len(found)} path(s), the cheapest "
                      f"{len(first['via'])} joins: " + " AND ".join(first["via"]))
            unseen = sorted({t for p in found for t in p["unseen"]
                             if t not in (ta, tb)})
            if unseen:
                digest += f"; through tables not described yet: {', '.join(unseen)}"
        else:
            digest = (f"no path between {ta} and {tb} within {MAX_HOPS} joins "
                      f"(declared keys, the knowledge base and the graph)")
            lines.append(digest)
        facts = [Fact("join_path", pair_key(ta, tb),
                      {"a": ta, "b": tb, "found": bool(found), "paths": found})]
        return ToolResult("join_path", True, data, _cut(digest, DIGEST_WIDTH),
                          facts, rows=len(found), lines=lines)

    # ----------------------------------------------------- the time
    def _moments_read(self, table, moments):
        """{column: (min, max, nulls, null_share, with a time of day,
        error)} for the moment columns, one bounded query over the whole
        table, its first TIME_ROWS rows only when that is too slow; a
        column the profile already describes is not
        asked again. `nulls` is a count of NULLs and `null_share` their
        share of the rows read, whichever source said it (the profile
        keeps a share and the rows it read, the query counts), None when
        unknown. The time of day is _has_time's: True, False or None."""
        out, asked = {}, []
        spec = self.view.profile.get(table.lower()) or {}
        for column, kind in moments:
            known = spec.get(column.lower()) or {}
            if "min" in known and "max" in known and "has_time" in known:
                nulls, share, present = _profile_nulls(known)
                said = known["has_time"]
                out[column] = (known["min"], known["max"], nulls, share,
                               _has_time(kind, present,
                                         None if said is None else bool(said)),
                               "")
            else:
                asked.append((column, kind))
        if not asked:
            return out
        parts = []
        for column, kind in asked:
            timed = (f"SUM(TIME(`{column}`) <> '00:00:00')"
                     if kind in ("datetime", "timestamp") else "NULL")
            parts.append(f"MIN(`{column}`), MAX(`{column}`), "
                         f"COUNT(*) - COUNT(`{column}`), COUNT(`{column}`), "
                         f"{timed}")
        inner = ", ".join(f"`{c}`" for c, _k in asked)
        # over the whole table first: the first TIME_ROWS rows of a bigger
        # one, in no order, gave a "latest" date from its earliest rows,
        # and the clock then said the data stopped early (review of 26
        # October). Too slow for the statement's time, those rows are read
        got = self.execute(f"SELECT {', '.join(parts)} FROM `{table}`", 1)
        if got["error"]:
            got = self.execute(f"SELECT {', '.join(parts)} FROM (SELECT {inner} "
                               f"FROM `{table}` LIMIT {TIME_ROWS}) AS s", 1)
        row = got["rows"][0] if got["rows"] else None
        for n, (column, kind) in enumerate(asked):
            if got["error"] or row is None or len(row) < 5 * n + 5:
                out[column] = (None, None, None, None, None,
                               got["error"] or "no row")
                continue
            low, high, nulls, present, timed = row[5 * n:5 * n + 5]
            nulls = None if nulls is None else int(nulls)
            present = None if present is None else int(present)
            rows = (nulls + present if nulls is not None and present is not None
                    else None)
            share = round(nulls / rows, 4) if rows else None
            out[column] = (low, high, nulls, share,
                           _has_time(kind, present, timed), "")
        return out

    def time_columns(self, table) -> ToolResult:
        """How a table keeps time: its date and time columns (up to
        MOMENTS_MAX) with their range, NULLs (`nulls` a count, `null_share`
        a share of the rows read) and whether they hold a time of day
        (`has_time`: True, False only for a DATETIME or a TIMESTAMP whose
        values read are all at midnight, None when it cannot be told: a
        DATE, a YEAR, or no value read); the pairs that open and close a
        period (valid_from and valid_to); the tables one join away that
        keep its history; the column that says which event a row records;
        and its links to itself (a parent row of the same table). The
        words read are wording.TIME_WORDS."""
        t = self.view.table(table)
        if t is None:
            return self._unknown("time_columns", table)
        singular = self.clar._singular
        marks = [singular(w) for w in wording.TIME_WORDS]
        mark_set = set(marks)
        moment_types = tuple(getattr(self.clar, "MOMENTS", ()))
        columns = self.view.columns_of(t)
        all_moments = [(c, _base_type(d)) for c, d in columns
                       if _base_type(d) in moment_types]
        moments = all_moments[:MOMENTS_MAX]
        read = self._moments_read(t, moments)
        found = []
        for column, kind in moments:
            low, high, nulls, share, timed, error = read.get(
                column, (None,) * 5 + ("",))
            entry = {"column": column, "type": kind, "min": _show(low),
                     "max": _show(high), "nulls": nulls, "null_share": share,
                     "has_time": timed}
            if error:
                entry["error"] = _cut(error, ERROR_WIDTH)
            found.append(entry)
        # a period: two moment columns named alike but for one word, an
        # opening word and a closing one; the one listed first opens it
        intervals = []
        named = [(c, _words_of(c, singular)) for c, _k in all_moments]
        for i, (c1, w1) in enumerate(named):
            for c2, w2 in named[i + 1:]:
                if len(w1) != len(w2):
                    continue
                apart = [k for k in range(len(w1)) if w1[k] != w2[k]]
                if len(apart) != 1:
                    continue
                x, y = w1[apart[0]], w2[apart[0]]
                if x in mark_set and y in mark_set:
                    pair = [c1, c2] if marks.index(x) < marks.index(y) else [c2, c1]
                    intervals.append(pair)
        own = set(_words_of(t, singular))
        history = sorted({e.b for e in self.view.edges.get(t, ())
                          if e.b != t
                          and set(_words_of(e.b, singular)) & mark_set})
        event_type = None
        forms = {singular(w) for w in getattr(self.clar, "FORM_WORDS", ())}
        for column, dtype in columns:
            words = set(_words_of(column, singular))
            if (words & forms and (own & mark_set or words & mark_set)
                    and _base_type(dtype) not in moment_types):
                event_type = column
                break
        parents = [e.via for e in self.view.edges.get(t, ()) if e.b == t]
        data = {"table": t, "moments": found, "intervals": intervals,
                "history_tables": history, "event_type": event_type,
                "parent_links": parents}
        lines = []
        for m in found:
            if m.get("error"):
                lines.append(f"{m['column']} ({m['type']}): not read, {m['error']}")
                continue
            if m["nulls"] is not None:
                said = f"{m['nulls']} NULL" + (
                    f" ({m['null_share']:.0%})" if m["null_share"] else "")
            elif m["null_share"] is not None:
                said = f"{m['null_share']:.0%} NULL"
            else:
                said = "NULLs not counted"
            if m["type"] not in ("datetime", "timestamp"):
                timed = ""
            elif m["has_time"] is None:
                timed = ", no value read to tell a time of day"
            elif m["has_time"]:
                timed = ", with a time of day"
            else:
                timed = ", midnight only: dates in effect"
            lines.append(f"{m['column']} ({m['type']}): from {m['min']} to "
                         f"{m['max']}, {said}{timed}")
        if len(all_moments) > MOMENTS_MAX:
            lines.append(f"{len(all_moments) - MOMENTS_MAX} more moment "
                         f"columns not read: "
                         + ", ".join(c for c, _k in all_moments[MOMENTS_MAX:]))
        for start, end in intervals:
            lines.append(f"a period: {start} opens it, {end} closes it")
        if history:
            lines.append("tables one join away keeping its history: "
                         + ", ".join(history))
        if event_type:
            lines.append(f"the kind of event a row records: {event_type}")
        for via in parents:
            lines.append(f"linked to itself: {via}")
        if not found:
            lines.append(f"{t} has no date or time column")
        bits = [f"{len(all_moments)} moment columns" if all_moments
                else "no date or time column"]
        bits += [f"{m['column']} {m['min']}..{m['max']}" for m in found[:3]
                 if not m.get("error")]
        bits += [f"period {a}..{b}" for a, b in intervals[:2]]
        if history:
            bits.append("history in " + ", ".join(history[:3]))
        if parents:
            bits.append("linked to itself")
        digest = _cut(f"{t}: " + "; ".join(bits), DIGEST_WIDTH)
        facts = [Fact("time", t.lower(), data)]
        return ToolResult("time_columns", True, data, digest, facts,
                          rows=len(found),
                          complete=len(all_moments) <= MOMENTS_MAX, lines=lines)

    # ------------------------------------------------------ the SQL
    def guard(self, sql) -> tuple[str | None, str]:
        """(the SQL to run, "") or (None, why it may not run).

        One statement, read by sqlglot's tokenizer and parser in the mysql
        dialect: no comment, no semicolon, no INTO; a SELECT, a WITH ending
        in one, or a UNION of them; no write, DDL, SET or lock anywhere in
        it, no server variable (@@) and no assignment (:=); none of the
        functions that sleep, wait, read files, take locks or move a
        sequence (BLOCKED_FUNCTIONS), no function named with a schema, and
        of the functions sqlglot does not know only ALLOWED_FUNCTIONS;
        every table one of this schema, or a CTE of the query."""
        import sqlglot
        from sqlglot import exp
        from sqlglot.tokens import TokenType

        if __package__:
            from .schema_graph import cte_names
        else:
            from schema_graph import cte_names

        text = str(sql or "").strip()
        while text.endswith(";"):
            text = text[:-1].rstrip()
        if not text:
            return None, "no SQL given"
        if len(text) > SQL_MAX_CHARS:
            return None, (f"the SQL is {len(text)} characters long; "
                          f"{SQL_MAX_CHARS} at most")
        try:
            tokens = sqlglot.tokenize(text, read="mysql")
        except Exception as e:
            return None, _cut(f"the SQL does not read: {e}", ERROR_WIDTH)
        if any(t.comments for t in tokens):
            # a comment is taken out, not refused: a reading whose SQL
            # explained itself sank a choice at the time cap (Warehouse
            # Q09). What runs is the text without it, checked as any other;
            # a MySQL /*! ... */, which MySQL runs, is refused.
            try:
                text = strip_comments(text)
            except ValueError as e:
                return None, str(e)
            # "SELECT 1; -- note": the semicolon trimmed before is back
            while text.endswith(";"):
                text = text[:-1].rstrip()
            try:
                tokens = sqlglot.tokenize(text, read="mysql")
            except Exception as e:
                return None, _cut(f"the SQL does not read: {e}", ERROR_WIDTH)
            if not text or any(t.comments for t in tokens):
                return None, "comments are not allowed"
        if any(t.token_type == TokenType.SEMICOLON for t in tokens):
            return None, "one statement only: no ';'"
        if any(t.token_type == TokenType.INTO for t in tokens):
            return None, "INTO is not allowed: the database is only read"
        try:
            trees = [t for t in sqlglot.parse(text, read="mysql") if t is not None]
        except Exception as e:
            return None, _cut(f"the SQL does not parse: {e}", ERROR_WIDTH)
        if len(trees) != 1:
            return None, "one statement only"
        tree = trees[0]
        if not isinstance(tree, (exp.Select, exp.SetOperation)):
            return None, (f"only a SELECT, a WITH or a UNION may run, not "
                          f"{type(tree).__name__.upper()}")
        blocked = tuple(getattr(exp, n) for n in BLOCKED_NODES if hasattr(exp, n))
        server_variable = getattr(exp, "SessionParameter", ())
        assignment = getattr(exp, "PropertyEQ", ())
        for node in tree.walk():
            if isinstance(node, blocked):
                return None, (f"{type(node).__name__.upper()} is not allowed: "
                              f"the database is only read")
            if server_variable and isinstance(node, server_variable):
                return None, ("a server variable (@@) is not allowed: only the "
                              "tables are read")
            if assignment and isinstance(node, assignment):
                return None, ("assigning a variable (:=) is not allowed: the "
                              "database is only read")
            if isinstance(node, exp.Dot) and isinstance(node.expression, exp.Func):
                return None, (f"a function named with a schema "
                              f"({_cut(node.sql(dialect='mysql'), 60)}) is not "
                              f"allowed: only the server's own functions")
            if isinstance(node, exp.Func):
                try:
                    name = (node.name if isinstance(node, exp.Anonymous)
                            else node.sql_name())
                except Exception:
                    name = ""
                name = str(name or "").upper()
                if name in BLOCKED_FUNCTIONS:
                    return None, f"{name}() is not allowed"
                if isinstance(node, exp.Anonymous) and name not in ALLOWED_FUNCTIONS:
                    return None, (f"{name or 'this function'}() is not one of "
                                  f"the functions a query may call here: "
                                  f"aggregates, windows, dates, text, numbers")
        blocks = {c.alias_or_name.lower() for c in tree.find_all(exp.CTE)}
        try:
            blocks |= {b.lower() for b in cte_names(text)}
        except Exception:
            pass
        schema = self.view.schema.lower()
        for node in tree.find_all(exp.Table):
            name = node.name
            if not name:
                continue
            db = str(node.db or "")
            if node.catalog or (db and db.lower() != schema):
                return None, (f"only the tables of {self.view.schema} may be "
                              f"read: {db + '.' if db else ''}{name} is not one")
            if not db and name.lower() in blocks:
                continue
            if self.view.table(name) is None:
                close = self.view.closest(name)
                return None, (f"unknown table {name}"
                              + (f" (closest: {', '.join(close)})" if close else ""))
        return text, ""

    def _timed(self, sql):
        if self.view.flavour == "mariadb":
            return (f"SET STATEMENT max_statement_time="
                    f"{_bounded_seconds(self.settings.sql_seconds):g} FOR {sql}")
        return sql

    def _sql_error(self, error):
        args = getattr(error, "args", ()) or ()
        code = args[0] if args else None
        message = str(args[1] if len(args) > 1 else error)
        if ((isinstance(code, int) and code in TIMEOUT_ERRORS)
                or "max_statement_time" in message.lower()
                or "maximum statement execution time" in message.lower()):
            return f"{TOO_SLOW} (it ran past {self.settings.sql_seconds:g} s)"
        prefix = (f"{code}: " if isinstance(code, int)
                  else f"{type(error).__name__}: ")
        return _cut(prefix + message, ERROR_WIDTH)

    def _explain(self, sql, con):
        """The join check of the plan, before running: a cartesian product
        comes back as an error. An EXPLAIN that fails is skipped."""
        try:
            if __package__:
                from .schema_graph import explain_check
            else:
                from schema_graph import explain_check
            verdict, why = explain_check(sql, con)
        except Exception:
            return ""
        if str(verdict).startswith("REJECT"):
            return _cut(f"{verdict}: {why}", ERROR_WIDTH)
        return ""

    def execute(self, sql, fetch) -> dict:
        """Run one guarded SQL, read only, and read at most `fetch` rows.

        {"columns", "rows", "total", "read", "ms", "error", "truncated"}:
        `total` is how many rows the query matches, counted by _count when
        more than `fetch` came back (None when no count could run), and
        `read` how many rows were read, at most fetch + 1: when `total` is
        None it is all that is known, a lower bound.
        A read-only transaction, the plan's join check first, a timeout of
        settings.sql_seconds on every statement of the session (MariaDB
        max_statement_time, MySQL max_execution_time, never below a
        millisecond, which would be none), the EXPLAIN and the counts
        included, and a rollback whatever happens. A database whose
        flavour is still unknown when asked again runs nothing: no time
        limit could be set. A query
        with no LIMIT of its own runs with LIMIT fetch + 1 after it
        (_with_limit): the driver's cursor reads the whole result before
        handing over the first row, and fetch + 1 rows are all it needs."""
        out = {"columns": [], "rows": [], "total": None, "read": 0, "ms": 0,
               "error": "", "truncated": False}
        clean, why = self.guard(sql)
        if clean is None:
            out["error"] = why
            return out
        fetch = max(1, int(fetch or 1))
        started = time.monotonic()
        try:
            con = self.clar.connect()
        except Exception as e:
            out["error"] = _cut(f"no connection to the database: {e}", ERROR_WIDTH)
            return out
        cur = None
        bound = None
        try:
            cur = con.cursor()
            bound = _session_time(self._flavour(con), self.settings.sql_seconds)
            if bound is None:
                out["error"] = ("not run: the database did not say what it is "
                                "(SELECT VERSION() failed), so no time limit "
                                "can be set on the query")
                return out
            # every statement from here on, the EXPLAIN and the counts
            # included, stops after sql_seconds
            cur.execute(bound)
            cur.execute("START TRANSACTION READ ONLY")
            run = _with_limit(clean, fetch + 1)
            rejected = self._explain(run, con)
            if rejected:
                out["error"] = rejected
                return out
            cur.execute(self._timed(run))
            rows = list(cur.fetchmany(fetch + 1) or [])
            out["columns"] = [d[0] for d in (cur.description or [])]
            out["read"] = total = len(rows)
            if total > fetch:
                out["truncated"] = True
                # the true total, or None when it is unknown; it must never
                # fall back to the number read, which `read` carries
                total = self._count(cur, clean)
            out["rows"] = [list(r) for r in rows[:fetch]]
            out["total"] = total
        except Exception as e:
            out["error"] = self._sql_error(e)
        finally:
            out["ms"] = int((time.monotonic() - started) * 1000)
            _quietly(con.rollback)
            if cur is not None:
                if bound is not None:
                    _quietly(cur.execute,
                             _session_time(self.view.flavour, None))
                _quietly(cur.close)
            _quietly(con.close)
        return out

    def _count(self, cur, clean):
        """How many rows a guarded SELECT returns, or None when the
        database could count it no way in its time. The statements of
        count_statements in turn: COUNT(*) around the query; when that
        fails other than by time (MariaDB refuses a derived table with two
        columns of one name, 1060, which any SELECT * over a join has), the
        same with its columns named apart, then with its columns replaced
        by 1. A rewritten statement runs only once the guard accepts it."""
        statements = count_statements(clean, self.view.columns_of)
        for sql in statements:
            if sql is not statements[0] and self.guard(sql)[0] is None:
                continue
            try:
                cur.execute(self._timed(sql))
                got = cur.fetchone()
                return int(got[0]) if got and got[0] is not None else None
            except Exception as e:
                if self._sql_error(e).startswith(TOO_SLOW):
                    return None
        return None

    def run_count(self, sql) -> ToolResult:
        """How many rows a SELECT returns, with its columns and its first
        COUNT_ROWS rows.

        `count` is None when the total could not be counted (the count ran
        out of time, or could not be written): `complete` is then False
        and `lower_bound` the rows actually read, so an unknown total is
        never read as none. When the count is known, `lower_bound` is it."""
        clean, why = self.guard(sql)
        if clean is None:
            return _failed("run_count", why)
        got = self.execute(clean, COUNT_ROWS)
        if got["error"]:
            return _failed("run_count", got["error"],
                           {"count": None, "columns": [], "rows": [],
                            "ms": got["ms"]})
        count = got["total"]
        rows = [[_show(v) for v in r] for r in got["rows"]]
        bound = count if count is not None else int(got.get("read") or 0)
        data = {"count": count, "complete": count is not None,
                "lower_bound": bound, "columns": got["columns"], "rows": rows,
                "ms": got["ms"]}
        said = (f"at least {bound} (the total could not be counted)"
                if count is None else str(count))
        digest = (f"{said} rows ({', '.join(got['columns'][:6])}) in "
                  f"{got['ms']} ms"
                  + (f"; first: {', '.join(map(str, rows[0]))}" if rows else ""))
        lines = [" | ".join(got["columns"])]
        lines += [" | ".join("NULL" if v is None else str(v) for v in r)
                  for r in rows]
        if count is not None and count > len(rows):
            lines.append(f"... {count - len(rows)} more rows not read")
        elif count is None:
            lines.append(f"... at least {bound - len(rows)} more rows; the "
                         f"total is unknown, not zero")
        facts = [Fact("count", sql_key(clean),
                      {"count": count, "complete": count is not None,
                       "lower_bound": bound, "columns": got["columns"]})]
        return ToolResult("run_count", True, data, _cut(digest, DIGEST_WIDTH),
                          facts, rows=bound, complete=count is not None,
                          lines=lines)

    def compare_readings(self, sqls) -> ToolResult:
        """Whether two to four readings of a question return the same rows.

        Each runs (up to settings.compare_rows rows); the rows are
        normalised (_cell: numbers to CELL_DECIMALS decimals, moments in
        ISO form, a midnight time stamp as its date, NULL as one sign,
        column names ignored) and compared as multisets, so the order of
        the rows does not count, nor that of the columns: readings of one
        width whose rows differ as listed are compared again with B's
        columns in A's order (_aligned), `reordered` saying how. Readings
        of different widths are compared on their first column, which the
        prompt asks to be the entity's key. Past compare_rows rows the
        counts are compared, and equal counts leave the pair
        `undetermined`. `i`, `a` and `b` are positions in `sqls`, from 0.
        Two readings that both order their rows (ORDER BY) answer in that
        order: the same rows ranked otherwise differ, `compared_on` then
        ending "in order" (review of 26 October: "the oldest products" by
        created_at and by updated_at were found the same, and Q10's choice
        was dropped).

        pairs: {a, b, same, only_a, only_b, share, compared_on,
        undetermined, [reordered]}, share = (only_a + only_b) / (|A| + |B|)."""
        if isinstance(sqls, str):
            sqls = [sqls]
        sqls = [str(s) for s in (sqls or [])]
        if not READINGS_MIN <= len(sqls) <= READINGS_MAX:
            return _failed("compare_readings",
                           f"compare {READINGS_MIN} to {READINGS_MAX} readings, "
                           f"not {len(sqls)}")
        cleans = []
        for i, s in enumerate(sqls):
            clean, why = self.guard(s)
            if clean is None:
                return _failed("compare_readings", f"reading {i}: {why}")
            cleans.append(clean)
        limit = max(1, int(self.settings.compare_rows))
        results, read = [], []
        for i, clean in enumerate(cleans):
            got = self.execute(clean, limit)
            if got["error"]:
                results.append({"i": i, "count": None, "hash": None,
                                "truncated": False, "error": got["error"]})
                read.append(None)
                continue
            rows = [tuple(_cell(v) for v in r) for r in got["rows"]]
            truncated = bool(got["truncated"])
            results.append({"i": i, "count": got["total"],
                            "hash": None if truncated else _rows_hash(rows),
                            "truncated": truncated,
                            "columns": got["columns"], "ms": got["ms"],
                            "ordered": _ordered(clean), "order_key": _order_key(clean)})
            read.append((rows, len(got["columns"])))
        pairs = [self._pair(i, j, results, read)
                 for i in range(len(cleans)) for j in range(i + 1, len(cleans))]
        failed = [r for r in results if r.get("error")]
        data = {"results": results, "pairs": pairs}
        lines = []
        for r in results:
            if r.get("error"):
                lines.append(f"reading {r['i']}: failed, {r['error']}")
            else:
                lines.append(f"reading {r['i']}: {r['count']} rows"
                             + (f" (more than {limit}: only the counts compare)"
                                if r["truncated"] else "")
                             + f", columns {', '.join(r['columns'])}")
        said = [self._said(p, results) for p in pairs]
        lines.extend(said)
        digest = _cut("; ".join(said), DIGEST_WIDTH)
        facts = [Fact("compare", readings_key(cleans[p["a"]], cleans[p["b"]]),
                      dict(p, keys=[sql_key(cleans[p["a"]]),
                                    sql_key(cleans[p["b"]])]))
                 for p in pairs]
        facts += [Fact("count", sql_key(clean),
                       {"count": r["count"], "hash": r["hash"],
                        "truncated": r["truncated"]})
                  for r, clean in zip(results, cleans) if not r.get("error")]
        if failed:
            return ToolResult("compare_readings", False, data, digest, facts,
                              error=_cut("; ".join(
                                  f"reading {r['i']}: {r['error']}"
                                  for r in failed), ERROR_WIDTH),
                              rows=len(results), complete=False, lines=lines)
        return ToolResult("compare_readings", True, data, digest, facts,
                          rows=len(results),
                          complete=not any(p["undetermined"] for p in pairs),
                          lines=lines)

    @staticmethod
    def _pair(i, j, results, read):
        pair = {"a": i, "b": j, "same": None, "only_a": None, "only_b": None,
                "share": None, "compared_on": "rows", "undetermined": False}
        if read[i] is None or read[j] is None:
            pair.update(compared_on="nothing: a reading failed", undetermined=True)
            return pair
        ra, rb = results[i], results[j]
        if ra["truncated"] or rb["truncated"]:
            pair["compared_on"] = "count"
            ca, cb = ra["count"], rb["count"]
            if ca is None or cb is None or ca == cb:
                pair["undetermined"] = True
            else:
                pair["same"] = False
                pair["share"] = round(abs(ca - cb) / max(ca + cb, 1), 6)
            return pair
        (rows_a, width_a), (rows_b, width_b) = read[i], read[j]
        if width_a != width_b:
            pair["compared_on"] = "first column"
            rows_a = [r[:1] for r in rows_a]
            rows_b = [r[:1] for r in rows_b]
        bag_a, bag_b = Counter(rows_a), Counter(rows_b)
        if bag_a != bag_b and width_a == width_b > 1:
            order = ToolBox._aligned(bag_a, bag_b, width_a,
                                     ra.get("columns") or [],
                                     rb.get("columns") or [])
            if order is not None:
                bag_b = Counter({tuple(r[k] for k in order): n
                                 for r, n in bag_b.items()})
                pair["reordered"] = list(order)
        only_a = sum((bag_a - bag_b).values())
        only_b = sum((bag_b - bag_a).values())
        pair.update(same=only_a == 0 and only_b == 0, only_a=only_a,
                    only_b=only_b,
                    share=round((only_a + only_b)
                                / max(len(rows_a) + len(rows_b), 1), 6))
        if pair["same"] and ra.get("ordered") and rb.get("ordered") \
                and ra.get("order_key") != rb.get("order_key"):
            # the same rows, each reading ranking them by its own key: the
            # places that differ, on the entity key (A's first column and the
            # column of B that holds it). Said, never decided here: whether
            # the order is the answer is the question's (Verifier); the rows
            # stay the same rows
            first = (pair.get("reordered") or [0])[0]
            seq_a = [r[0] for r in rows_a]
            seq_b = [r[first] if len(r) > first else r[0] for r in rows_b]
            moved = sum(1 for x, y in zip(seq_a, seq_b) if x != y)
            if moved:
                pair.update(order_moved=moved,
                            order_share=round(moved / max(len(seq_a), 1), 6))
        return pair

    @staticmethod
    def _aligned(bag_a, bag_b, width, columns_a, columns_b):
        """The order of B's columns (B's position for each of A's) under
        which the two readings hold the same rows, or None: the same
        rows listed in another column order are the same answer. Tried:
        the order the names give when both name the same columns, then
        each order matching every column of A to a column of B holding
        the same values, at most ALIGN_TRIES of them."""
        import itertools

        orders = []
        names_a = [str(c).lower() for c in columns_a]
        names_b = [str(c).lower() for c in columns_b]
        if (len(names_a) == len(names_b) == width
                and len(set(names_a)) == width
                and sorted(names_a) == sorted(names_b)):
            orders.append([names_b.index(n) for n in names_a])

        def column(bag, k):
            out = Counter()
            for r, n in bag.items():
                out[r[k]] += n
            return out

        ours = [column(bag_a, k) for k in range(width)]
        theirs = [column(bag_b, k) for k in range(width)]
        choices = [[k for k in range(width) if theirs[k] == ours[m]]
                   for m in range(width)]
        if all(choices):
            for n, order in enumerate(itertools.product(*choices)):
                if n >= ALIGN_TRIES:
                    break
                if len(set(order)) == width:
                    orders.append(list(order))
        identity = list(range(width))
        for order in orders:
            if order == identity:
                continue
            moved = Counter({tuple(r[k] for k in order): n
                             for r, n in bag_b.items()})
            if moved == bag_a:
                return order
        return None

    @staticmethod
    def _said(pair, results):
        a, b = pair["a"], pair["b"]
        head = f"readings {a} and {b}"
        if pair["undetermined"]:
            if pair["compared_on"] == "count":
                return (f"{head}: both {results[a]['count']} rows, too many to "
                        f"compare row by row: undetermined, compare an "
                        f"aggregate instead")
            return f"{head}: not compared, a reading failed"
        if pair["compared_on"] == "count":
            return (f"{head}: differ, {results[a]['count']} rows against "
                    f"{results[b]['count']}")
        on = " on their first column" if pair["compared_on"].startswith("first column") else ""
        if pair["same"] and pair.get("order_moved"):
            return (f"{head}: the same {results[a]['count']} rows{on}, ranked otherwise: "
                    f"{pair['order_moved']} places differ")
        if pair["same"]:
            return f"{head}: the same {results[a]['count']} rows{on}"
        total = pair["only_a"] + pair["only_b"]
        return (f"{head}: differ{on}, {pair['only_a']} rows only in {a}, "
                f"{pair['only_b']} only in {b} ({total} of "
                f"{(results[a]['count'] or 0) + (results[b]['count'] or 0)}, "
                f"{pair['share']:.1%})")

    # --------------------------------------------------- the verifier
    def absent_everywhere(self, what, columns=True) -> tuple[bool, bool, list]:
        """(absent, complete_sweep, hits) for a claim that the database
        does not hold `what`: no column the term points at by evidence that
        withholds a denial, and no row holding it. The evidence is
        column_evidence, every kind (a name, a description, `about`,
        closeness in meaning), weighed by Clarifier.withholds_denial: an
        echo of the kind only ("score" in nps_score, for "engagement
        score") forbids nothing, is kept in last_echoes, and the rows are
        swept. A number or a date is
        looked for in the columns of its type (_typed_lookups), anything
        else in the text columns (Clarifier.check_value), whether or not
        it reads as a literal: a lower-case word is stored as often as a
        name. Every sweep runs on a connection whose statements stop after
        LOOKUP_SECONDS, within SWEEP_COLUMNS lookups and SWEEP_SECONDS.

        complete_sweep is True only when a hit was found or the sweep ran
        to its end with no lookup failing; a sweep cut short, a failed
        lookup, no connection or a value too short to sweep never prove an
        absence."""
        text = str(what or "").strip()
        self.last_echoes = []
        if not text:
            return False, False, []
        # columns=False: the rows alone, once the column evidence was
        # weighed on the values (Verifier._weigh_on_values)
        hits = [{"table": t, "column": c, "how": how}
                for t, c, how in (self.clar.column_evidence(text, semantic=True)
                                  if columns else [])]
        if hits and not self._withholds(text):
            # the schema echoes the kind ("score": nps_score), never the
            # thing ("engagement"): the old judge's measured rule, so the
            # rows are still swept but the echo forbids nothing (E40)
            self.last_echoes, hits = hits, []
        if hits:
            return False, True, hits
        if len(text) < VALUE_MIN_CHARS:
            return True, False, []
        until = self.clock() + SWEEP_SECONDS
        with self._bounded(LOOKUP_SECONDS) as con:
            if con is None:
                return True, False, []
            typed = self._typed_lookups(text)
            if typed is not None:
                return self._typed_sweep(typed, con, until)
            where, checked = self.clar.check_value(
                text, con=con, max_columns=SWEEP_COLUMNS, until=until,
                clock=self.clock)
        if where:
            return False, True, [{"table": where[0], "column": where[1],
                                  "how": "value"}]
        return True, bool(checked), []

    def _withholds(self, text):
        """Whether the evidence for `text` forbids a denial, by
        Clarifier.withholds_denial; a clarifier without it, or a rule
        that fails, keeps every echo as evidence."""
        rule = getattr(self.clar, "withholds_denial", None)
        if rule is None:
            return True
        try:
            return bool(rule(text))
        except Exception:
            return True

    def _typed_lookups(self, text):
        """The lookups that would find a number or a date where a row keeps
        it, or None when `text` is neither: a number by equality in the
        numeric columns (within a hair of it in a float), a date by its
        day in the date and time columns, a time stamp by equality, a year
        (a whole number from 1000 to 9999) by its span as well; and each
        as written inside a text column (LIKE), where a legacy schema
        keeps them too. [(table, column, condition, params)]."""
        day = moment = number = year = None
        if _DAY.fullmatch(text):
            try:
                day = datetime.date.fromisoformat(text)
            except ValueError:
                return None
        elif _MOMENT.fullmatch(text):
            try:
                moment = datetime.datetime.fromisoformat(text.replace("T", " "))
            except ValueError:
                return None
        elif _NUMBER.fullmatch(text):
            number = decimal.Decimal(text)
            if number == number.to_integral_value() and 1000 <= number <= 9999:
                year = int(number)
        else:
            return None
        like = "%" + re.sub(r"([\\%_])", r"\\\1", text) + "%"
        plans = []
        for table in sorted(self.view._columns):
            for column, dtype in self.view._columns[table]:
                # "int unsigned", "decimal(12,2)": the type's first word
                base = (_base_type(dtype).split() or [""])[0]
                q = f"`{column}`"
                if number is not None and base in NUMBER_TYPES:
                    whole = number == number.to_integral_value()
                    if base in INEXACT_TYPES:
                        eps = abs(float(number)) * 1e-9 + 1e-9
                        plans.append((table, column, f"{q} BETWEEN %s AND %s",
                                      (float(number) - eps,
                                       float(number) + eps)))
                    elif base in WHOLE_TYPES:
                        if whole:
                            plans.append((table, column, f"{q} = %s",
                                          (int(number),)))
                    else:
                        plans.append((table, column, f"{q} = %s",
                                      (str(number),)))
                if base in DAY_TYPES:
                    span = None
                    if day is not None:
                        span = (day, day + datetime.timedelta(days=1))
                    elif year is not None:
                        span = (datetime.date(year, 1, 1),
                                datetime.date(year + 1, 1, 1))
                    if span:
                        plans.append((table, column, f"{q} >= %s AND {q} < %s",
                                      tuple(d.isoformat() for d in span)))
                    elif moment is not None and base != "date":
                        plans.append((table, column, f"{q} = %s",
                                      (moment.isoformat(sep=" "),)))
                    elif moment is not None and moment.time() == datetime.time():
                        # a DATE holds a time stamp of midnight
                        plans.append((table, column, f"{q} = %s",
                                      (moment.date().isoformat(),)))
                if any(k in dtype for k in ("char", "text", "enum")):
                    # lower case on both sides, whatever the collation
                    # (a _bin one tells "high" from "HIGH")
                    plans.append((table, column, f"LOWER({q}) LIKE %s", (like.lower(),)))
        return plans

    def _typed_sweep(self, plans, con, until):
        """(absent, complete, hits) from _typed_lookups' lookups, run on a
        bounded connection: it stops at the first row found, after
        SWEEP_COLUMNS lookups or at `until`, and is complete only when
        every lookup ran and none failed."""
        failed = 0
        for n, (table, column, condition, params) in enumerate(plans):
            if n >= SWEEP_COLUMNS or self.clock() > until:
                return True, False, []
            cur = None
            try:
                cur = con.cursor()
                cur.execute(f"SELECT `{column}` FROM `{table}` "
                            f"WHERE {condition} LIMIT 1", params)
                row = cur.fetchone()
            except Exception:
                failed += 1
                continue
            finally:
                if cur is not None:
                    _quietly(cur.close)
            if row:
                return False, True, [{"table": table, "column": column,
                                      "how": "value"}]
        return True, failed == 0, []
