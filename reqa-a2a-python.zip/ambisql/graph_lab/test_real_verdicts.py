"""real_verdicts: the real verdict of a question labelled in a question
file, for a saved run whose own file does not carry it. No server."""

import os

os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

import pathlib
import tempfile
import time
import unittest
from unittest.mock import patch

import real_verdicts as rv


def write(path, text):
    pathlib.Path(path).write_text(text, encoding="utf-8")


class RealVerdictTests(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.examples = pathlib.Path(self.tmp.name) / "examples"
        self.runs = pathlib.Path(self.tmp.name) / "runs"
        self.examples.mkdir()
        self.runs.mkdir()
        p = patch.object(rv, "EXAMPLES", self.examples)
        p.start()
        self.addCleanup(p.stop)
        rv._cache.clear()

    def test_a_question_is_found_whatever_its_spelling(self):
        self.assertEqual(rv.key("How many  Products, per category?"),
                         rv.key("how many products per category"))

    def test_the_column_by_its_name_now_or_before_and_clashes_label_nothing(self):
        write(self.examples / "questions_a.csv",
              "id,question,real_verdict,also_accepted\n"
              "Q1,How many books?,ANSWERABLE,\n"
              "Q2,Most popular book?,NEEDS_MORE,NEEDS A CHOICE\n"
              "Q3,Twice?,ANSWERABLE,\nQ3b,Twice,NEEDS MORE,\n")
        write(self.runs / "old.questions.csv", "id,question,expected\nE1,Old one?,NO DATA\n")
        write(self.runs / "plain.questions.csv", "id,question\nX,No verdict?\n")
        found = rv.known(self.runs)
        self.assertEqual(found[rv.key("How many books?")]["real_verdict"], "ANSWERABLE")
        self.assertEqual(found[rv.key("Most popular book?")]["real_verdict"], "NEEDS MORE")
        self.assertEqual(found[rv.key("Most popular book?")]["also_accepted"], "NEEDS A CHOICE")
        self.assertEqual(found[rv.key("Old one?")]["real_from"], "old.questions.csv")
        self.assertNotIn(rv.key("Twice?"), found)
        self.assertNotIn(rv.key("No verdict?"), found)

    def test_the_examples_answer_key_wins_and_a_change_is_read_again(self):
        write(self.examples / "questions_a.csv", "id,question,real_verdict\nQ1,Q one?,ANSWERABLE\n")
        old = self.runs / "x.questions.csv"
        write(old, "id,question,expected\nQ1,Q one?,NEEDS MORE\nQ2,Q two?,NO DATA\n")
        self.assertEqual(rv.known(self.runs)[rv.key("Q one?")]["real_verdict"], "ANSWERABLE")
        time.sleep(0.05)
        write(old, "id,question,expected\nQ2,Q two?,NOT COVERED\n")
        os.utime(old, (time.time() + 5, time.time() + 5))
        self.assertEqual(rv.known(self.runs)[rv.key("Q two?")]["real_verdict"], "NOT COVERED")

    def test_a_question_of_two_databases_takes_its_own_database_s_key(self):
        # review of 26 October: a generic question took another database's key
        write(self.examples / "questions_library.csv",
              "id,question,real_verdict\nQ1,How many items per category?,ANSWERABLE\n")
        write(self.examples / "questions_products.csv",
              "id,question,real_verdict\nP1,How many items per category?,NEEDS MORE\n")
        k = rv.key("How many items per category?")
        self.assertEqual(rv.known(self.runs, "Library")[k]["real_verdict"], "ANSWERABLE")
        self.assertEqual(rv.known(self.runs, "Warehouse")[k]["real_verdict"], "NEEDS MORE")
        self.assertNotIn(k, rv.known(self.runs, "Enterprise"))    # neither is its key
        self.assertNotIn(k, rv.known(self.runs))                  # they disagree

    def test_review_of_the_fixes_no_key_of_another_database_comes_through(self):
        # an old list naming no database disagreed, and the products key
        # came through for a Point run
        write(self.examples / "questions_products.csv",
              "id,question,real_verdict\nP1,How many items?,ANSWERABLE\n")
        write(self.runs / "old.questions.csv", "id,question,real_verdict\nX,How many items?,NEEDS MORE\n")
        k = rv.key("How many items?")
        self.assertEqual(rv.known(self.runs, "Point")[k]["real_verdict"], "NEEDS MORE")
        self.assertEqual(rv.known(self.runs, "Warehouse")[k]["real_verdict"], "ANSWERABLE")
        # and fill() reads its own labels as own() does: an answer is none
        verdicts = [{"question": "How many items?", "verdict": "ANSWERABLE",
                     "extra": {"expected": "1200"}}]
        self.assertEqual(rv.fill(verdicts, rv.known(self.runs, "Warehouse")), 1)

    def test_a_run_is_scored_against_its_real_verdicts(self):
        rows = [{"question": "a", "verdict": "ANSWERABLE", "real_verdict": "ANSWERABLE"},
                {"question": "b", "verdict": "NEEDS MORE", "real_verdict": "NEEDS_A_CHOICE",
                 "also_accepted": "NEEDS MORE"},
                {"question": "c", "verdict": "NOT COVERED", "real_verdict": "NO DATA"},
                {"question": "d", "verdict": "UNKNOWN", "real_verdict": "ANSWERABLE"},
                {"question": "e", "verdict": "ANSWERABLE", "real_verdict": ""}]
        got = rv.score(rows)
        self.assertEqual((got["right"], got["scored"], got["unknown"], got["unlabelled"]),
                         (2, 3, 1, 1))
        self.assertAlmostEqual(got["accuracy"], 2 / 3)

    def test_a_run_without_them_is_scored_on_the_question_files_or_not_at_all(self):
        found = {rv.key("Q one?"): {"real_verdict": "NEEDS MORE", "also_accepted": ""}}
        rows = [{"question": "Q one?", "verdict": "NEEDS MORE"},
                {"question": "other", "verdict": "ANSWERABLE"}]
        got = rv.score(rows, found)
        self.assertEqual((got["right"], got["scored"], got["unlabelled"]), (1, 1, 1))
        self.assertIsNone(rv.score(rows, {}))

    def test_a_run_with_its_own_real_verdicts_is_left_alone(self):
        found = {rv.key("q one"): {"real_verdict": "ANSWERABLE", "also_accepted": "",
                                   "real_from": "f.csv"}}
        own = [{"question": "q one", "extra": {"expected": "NEEDS MORE"}}]
        self.assertEqual(rv.fill(own, found), 0)
        self.assertEqual(own[0]["extra"], {"expected": "NEEDS MORE"})
        bare = [{"question": "Q one?", "extra": {}}, {"question": "other", "extra": {}}]
        self.assertEqual(rv.fill(bare, found), 1)
        self.assertEqual(bare[0]["extra"]["real_verdict"], "ANSWERABLE")
        self.assertEqual(bare[1]["extra"], {})



class ExpectedAnswerTests(unittest.TestCase):

    def test_an_expected_answer_is_no_label(self):
        # review of 26 October: a customer's expected-answer column showed 0 %
        import real_verdicts as rv
        rows = [{"question": "How many?", "expected": "42", "verdict": "ANSWERABLE"}]
        self.assertFalse(rv.own(rows))
        self.assertIsNone(rv.score(rows))
        rows.append({"question": "Cheap?", "expected": "needs more", "verdict": "NEEDS MORE"})
        self.assertEqual(rv.score(rows), {"right": 1, "scored": 1, "unknown": 0,
                                          "unlabelled": 1, "accuracy": 1.0})

if __name__ == "__main__":
    unittest.main()
