"""The developers' examples on the Ask page: the generator, the endpoint and
the page script. No database and no model: the examples are files in a
temporary data directory, and the configured databases are patched."""

import os

# the column index is on by default; a test never builds one in a real
# Qdrant, and the tests that need one give it directly
os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

import csv
import importlib.util
import io
import json
import pathlib
import shutil
import subprocess
import sys
import tempfile
import unittest
from contextlib import redirect_stderr, redirect_stdout

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(HERE))


def generator():
    spec = importlib.util.spec_from_file_location(
        "make_ask_examples", ROOT / "scripts" / "make_ask_examples.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


DATASET = [
    {"id": "Q01", "question": "How many products are there?", "expected": "ANSWERABLE",
     "also_accepted": [], "readings": [], "missing": ""},
    {"id": "Q09", "question": "Which supplier is the most reliable?", "expected": "NEEDS A CHOICE",
     "also_accepted": ["ANSWERABLE"],
     "readings": [{"reading": "Highest rating (suppliers.rating).", "sql": "SELECT 1"},
                  {"reading": "Shortest lead time.", "sql": "SELECT 2"}], "missing": ""},
    {"id": "Q12", "question": "Which products are cheap?", "expected": "NEEDS MORE",
     "also_accepted": ["NOT COVERED", "NO DATA"], "readings": [],
     "missing": "The price below which a product counts as cheap."},
]


class GeneratorTests(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = pathlib.Path(self.tmp.name)
        (self.base / "datasets").mkdir()
        (self.base / "datasets" / "Mini.jsonl").write_text(
            "\n".join(json.dumps(r) for r in DATASET) + "\n", encoding="utf-8")
        self.gen = generator()

    def run_it(self, *profiles):
        out = io.StringIO()
        with redirect_stdout(out), redirect_stderr(io.StringIO()):
            code = self.gen.main(["--data-dir", str(self.base / "data"),
                                  "--datasets", str(self.base / "datasets"),
                                  *(["--profiles", *profiles] if profiles else [])])
        return code, out.getvalue()

    def test_every_question_with_its_class_and_its_answer_key(self):
        code, said = self.run_it()
        self.assertEqual(code, 0)
        path = self.base / "data" / "dev" / "ask_examples" / "Mini.csv"
        with path.open(encoding="utf-8", newline="") as fh:
            rows = list(csv.DictReader(fh))
        self.assertEqual([r["id"] for r in rows], ["Q01", "Q09", "Q12"])
        self.assertEqual(list(rows[0]), ["id", "question", "real_verdict", "also_accepted", "expect"])
        self.assertEqual(rows[1]["real_verdict"], "NEEDS A CHOICE")
        self.assertEqual(rows[1]["expect"], "Highest rating (suppliers.rating). / Shortest lead time.")
        self.assertEqual(rows[2]["also_accepted"], "NOT COVERED|NO DATA")
        self.assertEqual(rows[2]["expect"], "The price below which a product counts as cheap.")
        self.assertIn("3 examples, written", said)

    def test_it_is_idempotent(self):
        self.run_it("Mini")
        path = self.base / "data" / "dev" / "ask_examples" / "Mini.csv"
        first = path.read_bytes()
        code, said = self.run_it("Mini")
        self.assertEqual((code, path.read_bytes()), (0, first))
        self.assertIn("unchanged", said)

    def test_an_unknown_profile_is_an_error_and_writes_nothing(self):
        code, _ = self.run_it("Nowhere")
        self.assertEqual(code, 1)
        self.assertFalse((self.base / "data" / "dev").exists())

    def test_the_real_datasets_convert(self):
        # every dataset the bench ships turns into examples, all classes kept
        for path in (ROOT / "docs" / "test_strategy" / "coverage_bench" / "datasets").glob("*.jsonl"):
            with self.subTest(dataset=path.stem):
                rows = self.gen.examples_of(path)
                self.assertTrue(rows)
                self.assertTrue(all(r["question"] and r["real_verdict"] for r in rows))


class EndpointTests(unittest.TestCase):

    def setUp(self):
        from unittest.mock import patch
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.data = pathlib.Path(self.tmp.name)
        env = patch.dict("os.environ", {"DATAGORA_DATA_DIR": self.tmp.name,
                                        "DATAGORA_COVERAGE_DIR": self.tmp.name})
        env.start()
        self.addCleanup(env.stop)
        sys.path.insert(0, str(HERE / "ui"))
        import app
        from fastapi.testclient import TestClient
        self.app = app
        names = patch.object(app.DbProfile, "names", classmethod(lambda cls, path=None:
                                                                 ["Library", "Warehouse"]))
        names.start()
        self.addCleanup(names.stop)
        self.client = TestClient(app.app)
        self.gen = generator()

    def write(self, profile, rows):
        examples = [{"id": r["id"], "question": r["question"], "real_verdict": r["expected"],
                     "also_accepted": "|".join(r["also_accepted"]),
                     "expect": self.gen.expect_of(r)} for r in rows]
        self.gen.write(examples, self.data / "dev" / "ask_examples" / f"{profile}.csv")

    def get(self, profile):
        return self.client.get("/api/ask/examples", params={"profile": profile})

    def test_a_database_with_a_file_offers_its_examples(self):
        self.write("Library", DATASET)
        got = self.get("Library")
        self.assertEqual(got.status_code, 200)
        body = got.json()
        self.assertTrue(body["available"])
        self.assertEqual([e["id"] for e in body["examples"]], ["Q01", "Q09", "Q12"])
        self.assertEqual(body["examples"][2], {
            "id": "Q12", "question": "Which products are cheap?", "real_verdict": "NEEDS MORE",
            "also_accepted": "NOT COVERED|NO DATA",
            "expect": "The price below which a product counts as cheap."})

    def test_no_file_is_no_examples_never_an_error(self):
        got = self.get("Warehouse")
        self.assertEqual(got.status_code, 200)
        self.assertEqual(got.json(), {"available": False, "examples": []})

    def test_a_name_the_settings_do_not_know_is_refused(self):
        self.write("Library", DATASET)
        for name in ("Nowhere", "../Library", "Library/../Library", "..", "library"):
            with self.subTest(name=name):
                self.assertEqual(self.get(name).status_code, 404)

    def test_a_regenerated_file_shows_at_once(self):
        self.write("Library", DATASET[:1])
        self.assertEqual(len(self.get("Library").json()["examples"]), 1)
        self.write("Library", DATASET)
        self.assertEqual(len(self.get("Library").json()["examples"]), 3)


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class PageTests(unittest.TestCase):

    def test_the_ask_page_script_parses(self):
        page = (HERE / "ui" / "index.html").read_text(encoding="utf-8")
        script = page.split("<script>")[-1].split("</script>")[0]
        check = f"new Function({json.dumps(script)}); process.stdout.write('ok')"
        done = subprocess.run(["node", "-e", check], capture_output=True, text=True, timeout=30)
        self.assertEqual((done.returncode, done.stdout), (0, "ok"), done.stderr)

    def test_the_examples_are_escaped_and_only_offered_with_a_file(self):
        page = (HERE / "ui" / "index.html").read_text(encoding="utf-8")
        self.assertIn('id="showex" class="ghost hide"', page)
        self.assertIn("/api/ask/examples?profile=", page)
        # the file's text is set as text, never as markup
        lister = page.split("function drawExampleList()")[1].split("\n}\n")[0]
        self.assertNotIn("innerHTML =", lister.replace('box.innerHTML = ""', ""))


if __name__ == "__main__":
    unittest.main()
