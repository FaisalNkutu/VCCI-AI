"""Logging, Langfuse tracing and prompt versions, all of them optional.

Three rules govern this file, and they are the reason it can be dropped
into somebody else's application without asking them to change anything.

**Nothing here is required.** Without the SDK, without credentials, or
with Langfuse down, every call becomes a no-op and the pipeline answers
exactly as before. Observability that can break the thing it observes is
worse than none.

**Nothing here is silent about itself.** When tracing is off, the logger
says so once, with the reason. A team that thinks it is tracing and is
not has the worst of both.

**Prompts live in Langfuse but ship with the code.** Each prompt is
fetched by label and falls back to the constant in the source, so a new
deployment works before anyone has opened Langfuse, and a prompt change
can be rolled out by moving a label rather than by redeploying. The
version actually used travels with the generation, otherwise versioning
buys nothing: you cannot compare what you cannot attribute.

Configuration, all from the environment:

    LANGFUSE_PUBLIC_KEY, LANGFUSE_SECRET_KEY, LANGFUSE_BASE_URL
    DATAGORA_LOG_LEVEL       DEBUG, INFO (default), WARNING, ERROR
    DATAGORA_TRACING         off to disable tracing while keeping logs
    DATAGORA_PROMPT_LABEL    which label to fetch, default "production"
"""

import contextvars
import logging
import os
import sys
import threading
import uuid
from pathlib import Path

# The id every log line and every span of one question share. A
# ContextVar rather than a global, so concurrent questions in one
# process never borrow each other's identity.
_TRACE_ID = contextvars.ContextVar("datagora_trace", default="-")

_ROOT = Path(__file__).resolve().parents[2]
_CONFIGURED = False
_CLIENT = "unset"
_WARNED = False


# ----------------------------------------------------------------- env

def load_env(path=None):
    """Read the repo .env into the environment without overwriting what
    is already set, so a container's real configuration always wins."""
    if str(os.environ.get("DATAGORA_DOTENV", "on")).lower() in (
            "off", "0", "false", "no") and path is None:
        return
    env_file = Path(path) if path else _ROOT / ".env"
    if not env_file.exists():
        return
    for line in env_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


# -------------------------------------------------------------- logger

class _TraceFilter(logging.Filter):
    """Stamps every record with the question it belongs to.

    Without this the logs and the traces are two accounts of the same
    event that cannot be put side by side: you read a stack trace in a
    container and have no way to find the Langfuse trace that explains
    it, or the reverse. The id is the same string in both places, so
    grepping it in the logs and pasting it in a Langfuse URL land on the
    same question."""

    def filter(self, record):
        record.trace = _TRACE_ID.get()
        return True


def current_trace_id():
    """The id of the question being answered, or "-" outside one."""
    return _TRACE_ID.get()


def trace_url():
    """A clickable link to the current trace, when tracing is on."""
    c = client()
    tid = _TRACE_ID.get()
    if c is None or tid == "-":
        return None
    try:
        return c.get_trace_url(trace_id=tid)
    except Exception:
        host = os.environ.get("LANGFUSE_BASE_URL", "").rstrip("/")
        return f"{host}/traces/{tid}" if host else None


def get_logger(name="datagora"):
    """The one logger. Level from DATAGORA_LOG_LEVEL, stderr, one line
    per event so it reads in a container log, each carrying the trace
    id of the question that produced it."""
    global _CONFIGURED
    if not _CONFIGURED:
        level = (os.environ.get("DATAGORA_LOG_LEVEL") or "INFO").upper()
        handler = logging.StreamHandler(sys.stderr)
        handler.addFilter(_TraceFilter())
        handler.setFormatter(logging.Formatter(
            "%(asctime)s %(levelname)-7s [%(trace).8s] %(name)s  %(message)s",
            datefmt="%H:%M:%S"))
        root = logging.getLogger("datagora")
        root.handlers[:] = [handler]
        root.setLevel(getattr(logging, level, logging.INFO))
        root.propagate = False
        _CONFIGURED = True
    return logging.getLogger(name if name.startswith("datagora")
                             else f"datagora.{name}")


# ------------------------------------------------------------ langfuse

def _unquoted(name):
    """A variable's value without the quotes a .env wraps it in.

    Docker Compose takes them off; `docker run --env-file` keeps them, and
    the keys then reached Langfuse as "pk-lf-..." with their quotes: every
    export answered 401 while the log said tracing was on."""
    value = str(os.environ.get(name) or "").strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
        value = value[1:-1].strip()
    return value


def _reachable_host(url):
    """The Langfuse address as this process reaches it.

    The .env says http://localhost:3001, which is right on the laptop and
    is the container itself inside one: every trace export failed, retried
    and was dropped. A loopback address goes through DATAGORA_HOST_GATEWAY,
    the rule model endpoints already follow; a real address is untouched."""
    gateway = os.environ.get("DATAGORA_HOST_GATEWAY")
    if not gateway or not url:
        return url
    for loop in ("localhost", "127.0.0.1", "[::1]", "0.0.0.0"):
        if f"//{loop}:" in url or url.rstrip("/").endswith(f"//{loop}"):
            return url.replace(f"//{loop}", f"//{gateway}", 1)
    return url


def client():
    """The Langfuse client, or None. Resolved once; the reason for None
    is logged once, never per call."""
    global _CLIENT, _WARNED
    if _CLIENT != "unset":
        return _CLIENT
    log = get_logger("trace")
    load_env()
    if os.environ.get("DATAGORA_TRACING", "").lower() in ("off", "0", "false"):
        _CLIENT = None
        log.info("tracing disabled by DATAGORA_TRACING")
        return None
    if not (_unquoted("LANGFUSE_PUBLIC_KEY") and _unquoted("LANGFUSE_SECRET_KEY")):
        _CLIENT = None
        if not _WARNED:
            log.info("tracing off: no LANGFUSE_PUBLIC_KEY / SECRET_KEY")
            _WARNED = True
        return None
    try:
        from langfuse import Langfuse
        host = _reachable_host(_unquoted("LANGFUSE_BASE_URL")
                               or _unquoted("LANGFUSE_HOST")
                               or "http://localhost:3001")
        # base_url, not host: the SDK takes base_url first, then the
        # LANGFUSE_BASE_URL variable as it stands, and only then host. Given
        # as host, the address corrected above lost to the raw variable:
        # localhost, which in a container is the container itself, or the
        # value with its quotes, and every trace was dropped while the log
        # named the corrected address
        _CLIENT = Langfuse(
            public_key=_unquoted("LANGFUSE_PUBLIC_KEY"),
            secret_key=_unquoted("LANGFUSE_SECRET_KEY"),
            base_url=host)
        log.info("tracing on: %s", host)
    except Exception as e:                         # SDK missing or refused
        _CLIENT = None
        log.info("tracing off: %s: %s", type(e).__name__, str(e)[:90])
    return _CLIENT


def reset():
    """Forget the client, so the next call builds one from the environment.

    The settings page can now change the Langfuse keys while the process
    runs. The client used to be resolved once for the life of the process,
    so new keys were ignored, and a deployment that turned tracing on from
    the page kept sending nothing without a word."""
    global _CLIENT, _WARNED
    try:
        if _CLIENT not in (None, "unset"):
            _CLIENT.flush()
    except Exception:
        pass
    _CLIENT = "unset"
    _WARNED = False


# --------------------------------------------------- coverage, per job
# A coverage run is a job, and a job is a Langfuse session: every question
# of one batch lands under the same session id, which is the job's own
# fingerprint, so a run can be opened as a whole and its cost read in one
# place. Every model call is a generation tagged with the endpoint that
# served it, gpu:<id>, so the same run can be split by GPU: how many
# requests each took, how long they waited, what each cost. And each is
# tagged with the prompt version it was sent, so two runs judged by two
# versions can be compared without anyone grepping.
#
# All of it is a no-op when tracing is off, and nothing here may slow or
# fail a question: a tracing error is logged and swallowed, never raised.

import contextlib as _contextlib


def _propagate(**attrs):
    try:
        from langfuse import propagate_attributes
        return propagate_attributes(**{k: v for k, v in attrs.items()
                                       if v not in (None, [], {})})
    except Exception:
        return _contextlib.nullcontext()


class _NoStep:
    """What step() yields when nothing is traced: update() does nothing."""

    def update(self, **_kw):
        return None


class _Step:
    def __init__(self, handle):
        self.handle = handle

    def update(self, output=None, **metadata):
        try:
            self.handle.update(output=output, metadata=metadata or None)
        except Exception as e:
            get_logger("trace").debug("step not updated: %s", e)


@_contextlib.contextmanager
def step(name, as_type="chain", input=None, **metadata):
    """One step of a question, nested under whatever is being traced.

    The type is what draws the graph: Langfuse shows a trace as a graph as
    soon as one of its observations is of a type other than span, event or
    generation (agent, chain, retriever, tool, guardrail, evaluator...),
    and a question traced as spans and generations only was a list, where
    it used to be read as a graph. A no-op when tracing is off; a tracing
    error is logged and never raised."""
    c = client()
    if c is None:
        yield _NoStep()
        return
    obs = handle = None
    try:
        obs = c.start_as_current_observation(
            name=name, as_type=as_type, input=input,
            metadata=metadata or None)
        handle = obs.__enter__()
    except Exception as e:
        get_logger("trace").debug("step %s not started: %s", name, e)
        obs = None
    try:
        yield _Step(handle) if handle is not None else _NoStep()
    finally:
        if obs is not None:
            try:
                obs.__exit__(None, None, None)
            except Exception:
                pass


@_contextlib.contextmanager
def question_span(*, job=None, position=None, question="", endpoint=None,
                  model=None, session=None, database=None, think=None):
    """One coverage question, as a trace under its run's session.

    The session is the run: the name of its saved file when there is one,
    so a Resume lands with the run it continues and two runs of the same
    questions never mix. It used to be the fingerprint of the question
    list, under which a run on Warehouse and one on Library sat together.
    `job`, the fingerprint, stays as a tag."""
    c = client()
    if c is None:
        yield None
        return
    tags = ["coverage"]
    if job:
        tags.append(f"job:{job}")
    if database:
        tags.append(f"db:{database}")
    if endpoint:
        tags.append(f"gpu:{endpoint}")
    if model:
        tags.append(f"model:{model}")
    if isinstance(think, bool):
        # thinking on or off, so two runs of the same questions compare
        tags.append(f"think:{'on' if think else 'off'}")
    meta = {"job": job, "run": session, "database": database,
            "position": position, "endpoint": endpoint, "model": model,
            "think": think}
    try:
        cm = _propagate(session_id=session or job, tags=tags,
                        metadata={k: str(v) for k, v in meta.items()
                                  if v is not None},
                        trace_name="coverage.question")
        cm.__enter__()
    except Exception as e:
        get_logger("trace").debug("question not traced: %s", e)
        yield None
        return
    span = None
    try:
        # a span, as it always was: Langfuse's aggregates count spans by
        # name, and a question typed otherwise left them. The graph comes
        # from the typed steps inside it (see step())
        span = c.start_as_current_observation(
            name="coverage.question", as_type="span",
            input={"question": question, "position": position})
        handle = span.__enter__()
    except Exception as e:
        get_logger("trace").debug("question span not started: %s", e)
        handle = span = None
    try:
        yield handle
    finally:
        try:
            if span is not None:
                span.__exit__(None, None, None)
        except Exception:
            pass
        try:
            cm.__exit__(None, None, None)
        except Exception:
            pass


# How much of a prompt a trace keeps. The model is always sent the whole
# prompt; the trace used to keep its first 8 000 characters, which on a
# large schema stopped in the middle of the tables, before the question,
# and read as the prompt itself having been cut. A long one now keeps its
# beginning and its end, where the question is, and says what it left out.
TRACE_HEAD = 60_000
TRACE_TAIL = 6_000


def _clipped(text):
    text = text or ""
    if len(text) <= TRACE_HEAD + TRACE_TAIL:
        return text
    left = len(text) - TRACE_HEAD - TRACE_TAIL
    return (text[:TRACE_HEAD]
            + f"\n\n[... {left} characters not kept in this trace; the model "
              f"was sent all {len(text)} ...]\n\n"
            + text[-TRACE_TAIL:])


@_contextlib.contextmanager
def generation(*, endpoint, model, url, system, user, num_ctx=None,
               prompt_version=None):
    """One model call, nested under the question being judged.

    Yields a callable to record the outcome with: the reply, the prompt
    tokens the server counted, and an error when there was one."""
    c = client()
    if c is None:
        yield lambda **_k: None
        return
    started = __import__("time").monotonic()
    meta = {"endpoint": endpoint, "url": url, "num_ctx": num_ctx,
            "prompt": prompt_version}
    obs = None
    try:
        obs = c.start_as_current_observation(
            name=f"llm.{prompt_version.split()[0]}" if prompt_version else "llm.chat",
            as_type="generation", model=model,
            input=[{"role": "system", "content": _clipped(system)},
                   {"role": "user", "content": _clipped(user)}],
            metadata={**{k: v for k, v in meta.items() if v is not None},
                      "system_chars": len(system or ""),
                      "user_chars": len(user or "")})
        handle = obs.__enter__()
    except Exception as e:
        get_logger("trace").debug("generation not started: %s", e)
        handle = obs = None

    def record(*, output=None, prompt_tokens=None, error=None, reply_tokens=None,
               server=None):
        if handle is None:
            return
        try:
            # `server`: where the server says its time went (llm.py), so a
            # slow or timed-out question shows whether it waited, read a
            # long prompt, or generated at length
            update = {"output": output if error is None else f"error: {error}",
                      "metadata": {"seconds": round(__import__("time").monotonic()
                                                    - started, 3),
                                   **({"server": server} if server else {}),
                                   **({"error": str(error)[:300]} if error else {})}}
            usage = {}
            if prompt_tokens is not None:
                usage["input"] = int(prompt_tokens)
            if reply_tokens is not None:
                usage["output"] = int(reply_tokens)
            if usage:
                update["usage_details"] = usage
            if error is not None:
                update["level"] = "ERROR"
            handle.update(**update)
        except Exception as e:
            get_logger("trace").debug("generation not updated: %s", e)

    try:
        yield record
    finally:
        try:
            if obs is not None:
                obs.__exit__(None, None, None)
        except Exception:
            pass


# how long a question is willing to wait for its trace to be sent. The
# answer is already computed by then, so anything spent here is spent
# after the work, on a subsystem that only watches the work.
FLUSH_SECONDS = float(os.environ.get("DATAGORA_FLUSH_TIMEOUT") or 3)


def flush(timeout=None):
    """Send what has been traced, and give up rather than hold the answer.

    This used to call the client's flush directly, in the request
    thread, with no limit. A Langfuse host that accepts the connection
    and then never replies made every question hang after its answer was
    already computed and sitting in memory: the page showed the last step
    spinning forever and nothing was reported anywhere. That is the same
    shape as the serialisation bug this project already shipped, one
    layer up, and it is worse because the failing subsystem is the one
    whose whole job is to observe without interfering.

    The send now happens on its own thread and is waited on for a few
    seconds. If it has not finished, the run carries on and says so. The
    thread is a daemon, so a send that never returns cannot hold the
    process open either."""
    c = client()
    if c is None:
        return True
    log = get_logger("trace")
    done = threading.Event()

    def send():
        try:
            c.flush()
        except Exception as e:
            log.debug("flush failed: %s", str(e)[:90])
        finally:
            done.set()

    threading.Thread(target=send, daemon=True).start()
    if done.wait(FLUSH_SECONDS if timeout is None else timeout):
        return True
    log.info("tracing: the trace did not finish sending in %.0fs; the "
             "answer is unaffected", FLUSH_SECONDS if timeout is None
             else timeout)
    return False


# -------------------------------------------------------------- spans

class Span:
    """A step of the journey. Becomes a no-op object when tracing is off,
    so callers never test for it."""

    def __init__(self, name, parent=None, *, as_type="span", prompt=None,
                 model=None, **attrs):
        """`as_type="generation"` with `prompt=` is what links a model call
        to the prompt version that produced it, natively rather than as a
        note in the metadata. That link is the whole payoff of versioning:
        Langfuse can then show a version's cost, latency and scores, and
        answer "did v3 do better than v2" without anyone grepping."""
        self.name = name
        self._span = None
        self._token = None
        self.log = get_logger("trace")
        c = client()
        if c is None:
            # tracing off, but a question still deserves an identity:
            # without one the log lines of concurrent questions are
            # interleaved with no way to tell them apart, which is the
            # problem the id solves whether or not Langfuse is listening
            if parent is None:
                self._token = _TRACE_ID.set(uuid.uuid4().hex)
            return
        extra = {}
        if as_type == "generation":
            if model:
                extra["model"] = model
            handle = getattr(prompt, "handle", None)
            if handle is not None:
                extra["prompt"] = handle
        try:
            # Langfuse v4 is built on OpenTelemetry and names this
            # start_observation; v3 called it start_span. Both are tried
            # so an upgrade on their side does not silently stop tracing,
            # which is exactly how a pipeline ends up believing it is
            # observed while sending nothing.
            if parent is not None and parent._span is not None:
                owner, kwargs = parent._span, {}
            else:
                owner, kwargs = c, {}
            if parent is None and hasattr(c, "start_as_current_observation"):
                # the root is made the current observation, so what is
                # traced inside without a parent handed to it, a model
                # call, the clarifier's steps, lands under this question
                # rather than in a trace of its own with no name
                self._current = c.start_as_current_observation(
                    name=name, as_type=as_type, input=attrs.get("input"),
                    **extra)
                self._span = self._current.__enter__()
            elif hasattr(owner, "start_observation"):
                self._span = owner.start_observation(
                    name=name, as_type=as_type, input=attrs.get("input"),
                    **extra, **kwargs)
            elif hasattr(owner, "start_span"):
                self._span = owner.start_span(
                    name=name, input=attrs.get("input"))
            else:
                self.log.debug("no span API on %s", type(owner).__name__)
            if parent is None and self._span is not None:
                real = getattr(self._span, "trace_id", None)
                if real:
                    self._token = _TRACE_ID.set(real)
        except Exception as e:
            self.log.debug("span %s not started: %s", name, e)

    def end(self, output=None, **meta):
        if self._token is not None:
            try:
                _TRACE_ID.reset(self._token)
            except ValueError:
                pass                       # ended in another context
            self._token = None
        # ended once: a step ended by hand inside its `with` is not ended
        # again on the way out, which OpenTelemetry warned about
        if self._span is None or getattr(self, "_ended", False):
            return
        try:
            if output is not None or meta:
                self._span.update(output=output, metadata=meta or None)
            current = getattr(self, "_current", None)
            if current is not None:
                current.__exit__(None, None, None)      # ends it, and the context
            else:
                self._span.end()
            self._ended = True
        except Exception as e:
            self.log.debug("span %s not ended: %s", self.name, e)

    def score(self, name, value, comment=None):
        """A number attached to this step: 0 or 1 for a gate, a count, a
        duration. Scores are what make a week of traces answerable."""
        if self._span is None:
            return
        try:
            self._span.score(name=name, value=value, comment=comment)
        except Exception as e:
            self.log.debug("score %s not recorded: %s", name, e)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.end(output=None if exc is None else f"{exc_type.__name__}: {exc}")
        return False


# ------------------------------------------------------------ prompts

class Prompt:
    """A prompt fetched from Langfuse, or the constant that ships with the
    code. `.text` is what goes to the model, `.version` is what the trace
    records, and `.source` says which of the two answered."""

    def __init__(self, name, text, version=None, source="code", handle=None):
        self.name = name
        self.text = text
        self.version = version
        self.source = source
        self.handle = handle

    def __str__(self):
        return self.text


def prompt(name, fallback, label=None):
    """Managed if Langfuse has it, the code's constant otherwise.

    The fallback is not a degraded mode, it is the guarantee that a fresh
    deployment works before anyone has opened Langfuse."""
    log = get_logger("prompt")
    c = client()
    if c is None:
        return Prompt(name, fallback)
    label = label or os.environ.get("DATAGORA_PROMPT_LABEL") or "production"
    try:
        p = c.get_prompt(name, label=label, cache_ttl_seconds=60)
        text = p.prompt if isinstance(p.prompt, str) else fallback
        return Prompt(name, text, getattr(p, "version", None), "langfuse", p)
    except Exception as e:
        log.debug("prompt %s not in langfuse (%s), using the code's copy",
                  name, type(e).__name__)
        return Prompt(name, fallback)


def register_prompt(name, text, labels=("production",)):
    """Push the code's copy to Langfuse so it becomes editable there.
    Idempotent in effect: Langfuse versions every push, and the label is
    moved to the new version."""
    c = client()
    if c is None:
        return None
    try:
        created = c.create_prompt(name=name, prompt=text,
                                  labels=list(labels))
        get_logger("prompt").info("registered %s v%s", name,
                                  getattr(created, "version", "?"))
        return created
    except Exception as e:
        get_logger("prompt").warning("could not register %s: %s: %s",
                                     name, type(e).__name__, str(e)[:90])
        return None


# --------------------------------------------------------------- CLI

def _cli():
    """Show the observability state, and push the code's prompts to
    Langfuse so they become editable there.

        python observability.py                 status
        python observability.py --register      publish the prompts
    """
    import argparse
    ap = argparse.ArgumentParser(description=_cli.__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--register", action="store_true")
    args = ap.parse_args()

    load_env()
    c = client()
    print(f"\n  logging        level {os.environ.get('DATAGORA_LOG_LEVEL', 'INFO')}")
    print(f"  tracing        {'on, ' + os.environ.get('LANGFUSE_BASE_URL', '?') if c else 'off'}")
    print(f"  prompt label   {os.environ.get('DATAGORA_PROMPT_LABEL', 'production')}")

    if __package__:
        from . import ambisql
        from . import pipeline as pl
    else:
        import ambisql
        import pipeline as pl
    owned = {
        "datagora-sql-generator": pl.SQL_SYSTEM,
        "datagora-answer": pl.ANSWER_SYSTEM,
        "datagora-anchors": pl.ANCHOR_SYSTEM,
        "datagora-ambiguity": ambisql.SYSTEM,
    }
    if args.register:
        for name, text in owned.items():
            register_prompt(name, text)
    print("\n  prompts:")
    for name, text in owned.items():
        p = prompt(name, text)
        where = (f"langfuse v{p.version}" if p.source == "langfuse"
                 else "the code's copy")
        print(f"    {name:26} {where}")
    if not args.register and c is not None:
        print("\n  publish them with:  python observability.py --register")
    flush()


if __name__ == "__main__":
    _cli()
