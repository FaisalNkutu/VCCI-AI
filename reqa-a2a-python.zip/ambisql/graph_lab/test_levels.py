"""Does each ambiguity level behave as TEST_QUESTIONS.md says it should?

test_ambisql.py gives the pair that matters for a product: how many real
ambiguities are caught, and how many clear questions are disturbed. This
one asks a narrower question: taken level by level, does the clarifier
reach the outcome the documentation promises?

The three groups are judged on different things, and conflating them
hides which half is weak:

    clear       ANSWER   nothing to settle, the question goes straight on
    level 1     CLARIFY  several readings, all of which the data can serve
    level 2     GUIDE    ambiguous, and the data cannot settle it

A level 1 question is also allowed to come back as GUIDE when only one
reading exists in that schema, which is the third case the paper does
not name. That is counted apart rather than as a failure, because it is
the correct answer to a question the taxonomy does not cover.

    python test_levels.py                       both databases
    python test_levels.py --profile datagora_lib
    python test_levels.py --endpoint local-small
"""

import os

# the column index is on by default; a test never builds one in a real
# Qdrant, and the tests that need one give it directly
os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")

import argparse
import sys
import time

from api import is_ambiguous
from db_profile import DbProfile
from llm import LLM

# Drawn from TEST_QUESTIONS.md. Kept short on purpose: every question
# costs one model call, and a suite nobody runs measures nothing.
SETS = {
    "datagora_lib": {
        "clear": [
            "how many books are in the catalogue",
            "number of loans per member",
            "books published before 2000",
            "books that have more than one author",
            "the longest book",
        ],
        "level1": [
            "how many loans are still open",
            "who are the oldest members",
            "which authors are the most famous",
            "list every genre and its parent genre",
        ],
        "level2": [
            "members taller than average",
            "books cheaper than 10",
            "books written by Shakespeare in 2020",
            "which members live in Paris",
        ],
    },
    "datagora_generic": {
        "clear": [
            "how many products are there in each category",
            "list the warehouses and their cities",
            "the top 5 warehouses by capacity",
            "products supplied by more than three suppliers",
            "average lead time in days per supplier",
        ],
        "level1": [
            "which supplier is the most reliable",
            "show me the oldest products",
            "products in Rotterdam",
            "categories and their parent category",
        ],
        "level2": [
            "products cheaper than a coffee",
            "stock after the merger",
            "the warranty duration of each product",
            "the blood type of our suppliers",
        ],
    },
}

# what each group should produce, and what is tolerated
EXPECTED = {
    "clear": ("ANSWER", ()),
    "level1": ("CLARIFY", ("GUIDE",)),      # GUIDE when one reading survives
    "level2": ("GUIDE", ()),
}


def run_group(profile, llm, group, questions, verbose):
    want, tolerated = EXPECTED[group]
    hits = allowed = 0
    rows = []
    for q in questions:
        t0 = time.time()
        try:
            a = is_ambiguous(q, db=profile, llm=llm)
            got = a.action
            detail = (f"level {a.level} {a.kind}" if a.ambiguous else "")
            if a.action == "ERROR":
                detail = a.reason[:60]
        except Exception as e:
            got, detail = "ERROR", f"{type(e).__name__}: {e}"[:60]
        ok = got == want
        near = (not ok) and got in tolerated
        hits += ok
        allowed += near
        mark = "ok  " if ok else ("~   " if near else "MISS")
        rows.append((mark, q, got, detail, time.time() - t0))
    if verbose:
        for mark, q, got, detail, secs in rows:
            print(f"    {mark} {q[:46]:46} -> {got:8} {detail:28} {secs:4.1f}s")
    return hits, allowed, len(questions)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--profile", default=None)
    ap.add_argument("--endpoint", default=None,
                    help="an entry of models.json, else the reasoner role")
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    llm = LLM.load(args.endpoint) if args.endpoint else LLM.role("reasoner")
    print(f"\n  model: {llm.name} -> {llm.model} at {llm.url}")
    if not llm.reachable():
        raise SystemExit(f"  {llm.url} is unreachable. Start it, or pick "
                         f"another with --endpoint.")

    names = [args.profile] if args.profile else list(SETS)
    totals = {g: [0, 0, 0] for g in EXPECTED}
    for name in names:
        if name not in SETS:
            raise SystemExit(f"no question set for {name!r}; "
                             f"known: {sorted(SETS)}")
        profile = DbProfile.load(name)
        print(f"\n  == {name} " + "=" * (58 - len(name)))
        for group in ("clear", "level1", "level2"):
            want = EXPECTED[group][0]
            print(f"\n  {group}, expecting {want}")
            hit, near, total = run_group(profile, llm, group,
                                         SETS[name][group], not args.quiet)
            extra = f", {near} tolerated" if near else ""
            print(f"    -> {hit}/{total}{extra}")
            totals[group][0] += hit
            totals[group][1] += near
            totals[group][2] += total

    print("\n  " + "=" * 62)
    failed = False
    for group in ("clear", "level1", "level2"):
        hit, near, total = totals[group]
        share = (hit + near) / total if total else 0
        print(f"  {group:8} {EXPECTED[group][0]:8} "
              f"{hit}/{total}" + (f"  (+{near} tolerated)" if near else "")
              + f"   {share:.0%} acceptable")
        # the clear group is the one that decides whether a product is
        # usable, so it is the one allowed to fail the run
        if group == "clear" and hit < total * 0.6:
            failed = True
    print()
    if failed:
        print("  too many clear questions were interrupted\n")
        sys.exit(1)


if __name__ == "__main__":
    main()
