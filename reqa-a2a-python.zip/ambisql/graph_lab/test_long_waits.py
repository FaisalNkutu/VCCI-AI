"""What a long wait does: a model reply that takes minutes, a stream with
nothing to say for a while, a prompt too long to keep whole in a trace.

No model, no database: the model call is answered by a stand-in for
urlopen, and the streams are read directly."""

import os

os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

import json
import pathlib
import queue
import sys
import threading
import time
import unittest
from unittest.mock import patch

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "ui"))

import llm  # noqa: E402
import observability  # noqa: E402
import settings_store  # noqa: E402

ENDPOINT = {"api": "ollama", "url": "http://gpu:11434", "model": "gemma4:31b"}


class _Reply:
    def __init__(self, data):
        self.data = data

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def read(self):
        return json.dumps(self.data).encode("utf-8")


class ReplyWaitTests(unittest.TestCase):
    def test_ten_minutes_unless_the_endpoint_says(self):
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("DATAGORA_LLM_TIMEOUT", None)
            self.assertEqual(llm.LLM("a", ENDPOINT).timeout, 600)
            self.assertEqual(llm.LLM("a", {**ENDPOINT, "timeout": 1200}).timeout, 1200)

    def test_the_environment_serves_an_endpoint_that_does_not_say(self):
        with patch.dict(os.environ, {"DATAGORA_LLM_TIMEOUT": "900"}):
            self.assertEqual(llm.LLM("a", ENDPOINT).timeout, 900)
            # the endpoint's own value still wins
            self.assertEqual(llm.LLM("a", {**ENDPOINT, "timeout": 300}).timeout, 300)

    def test_an_environment_endpoint_takes_its_own(self):
        env = {"DATAGORA_ENDPOINTS": "gpu_a",
               "DATAGORA_ENDPOINT_GPU_A_URL": "http://gpu:11434",
               "DATAGORA_ENDPOINT_GPU_A_MODEL": "gemma4:31b",
               "DATAGORA_ENDPOINT_GPU_A_TIMEOUT": "1500"}
        doc = llm.env_endpoints(env)
        self.assertEqual(llm.LLM("gpu_a", doc["endpoints"]["gpu_a"]).timeout, 1500)

    def test_the_chat_request_itself_uses_the_wait(self):
        waits = []
        # a model that cannot think, said by /api/show, whatever an earlier
        # test left of what the server said
        llm._THINKERS.clear()
        self.addCleanup(llm._THINKERS.clear)

        def urlopen(req, timeout=None):
            if getattr(req, "full_url", req).endswith("/api/chat"):
                waits.append(timeout)
            return _Reply({"message": {"content": "{}"}, "prompt_eval_count": 10,
                           "models": [], "capabilities": ["completion"]})

        with patch("urllib.request.urlopen", urlopen):
            llm.LLM("a", {**ENDPOINT, "timeout": 1200}).chat("s", "u")
        self.assertEqual(waits, [1200])

    def test_a_reply_too_slow_says_what_to_change(self):
        def urlopen(req, timeout=None):
            raise TimeoutError("timed out")

        # set not to think: with the server down, a model that may think is
        # waited for as one that does (THINK_TIMEOUT)
        model = llm.LLM("a", {**ENDPOINT, "timeout": 180, "think": False})
        with patch("urllib.request.urlopen", urlopen):
            self.assertIsNone(model.chat("s", "u"))
        self.assertIn("after 180 s", model.last_error)
        self.assertIn("settings page", model.last_error)

    def test_a_prompt_that_did_not_fit_says_how_big_it_was(self):
        def urlopen(req, timeout=None):
            if req.full_url.endswith("/api/ps"):
                return _Reply({"models": [{"name": "gemma4:31b", "context_length": 2048}]})
            return _Reply({"message": {"content": "{}"}, "prompt_eval_count": 2047})

        model = llm.LLM("a", {**ENDPOINT, "num_ctx": 2048})
        with patch("urllib.request.urlopen", urlopen):
            self.assertIsNone(model.chat("s" * 240, "u" * 24_000))
        self.assertIn("about 10100 tokens were sent", model.last_error)

    def test_the_settings_page_keeps_a_sane_wait(self):
        norm = settings_store._normalise_endpoint
        self.assertEqual(norm({**ENDPOINT})["timeout"], 600)
        self.assertEqual(norm({**ENDPOINT, "timeout": "1200"})["timeout"], 1200)
        self.assertEqual(norm({**ENDPOINT, "timeout": 5})["timeout"], 30)
        self.assertEqual(norm({**ENDPOINT, "timeout": "soon"})["timeout"], 600)
        doc = settings_store.models_document({"endpoints": [
            {**ENDPOINT, "id": "gpu", "timeout": 900}], "roles": {}})
        self.assertEqual(llm.LLM("gpu", doc["endpoints"]["gpu"]).timeout, 900)


class TraceTests(unittest.TestCase):
    def test_a_short_prompt_is_kept_whole(self):
        self.assertEqual(observability._clipped("Schema: t(a)\nQuestion: q"),
                         "Schema: t(a)\nQuestion: q")

    def test_a_long_prompt_keeps_its_question_and_says_what_it_left(self):
        text = "Schema of the database:\n" + "TABLE t\n" * 40_000 + "\nQuestion: how many?"
        kept = observability._clipped(text)
        self.assertLess(len(kept), len(text))
        self.assertTrue(kept.startswith("Schema of the database:"))
        self.assertTrue(kept.endswith("Question: how many?"))
        self.assertIn(f"the model was sent all {len(text)}", kept)


class QuotedEnvTests(unittest.TestCase):
    def test_the_quotes_an_env_file_kept_are_taken_off(self):
        # docker run --env-file keeps them; the keys then got a 401
        with patch.dict(os.environ, {"LANGFUSE_PUBLIC_KEY": '"pk-lf-x"',
                                     "LANGFUSE_HOST": "'http://localhost:3001'",
                                     "LANGFUSE_SECRET_KEY": "sk-lf-y"}):
            self.assertEqual(observability._unquoted("LANGFUSE_PUBLIC_KEY"), "pk-lf-x")
            self.assertEqual(observability._unquoted("LANGFUSE_HOST"), "http://localhost:3001")
            self.assertEqual(observability._unquoted("LANGFUSE_SECRET_KEY"), "sk-lf-y")
            self.assertEqual(observability._unquoted("NOT_SET_AT_ALL"), "")


class KeepAliveTests(unittest.TestCase):
    def setUp(self):
        import app
        self.app = app
        self.saved = app.KEEP_ALIVE
        app.KEEP_ALIVE = 0.05

    def tearDown(self):
        self.app.KEEP_ALIVE = self.saved

    def test_a_quiet_run_still_sends_something(self):
        live = self.app._Live("r1")
        got = []

        def later():
            time.sleep(0.2)
            live.put({"type": "verdict", "index": 0})
            live.put(None)

        threading.Thread(target=later, daemon=True).start()
        for chunk in live.follow():
            got.append(chunk)
        self.assertIn(": keep-alive\n\n", got)
        data = [c for c in got if c.startswith("data:")]
        self.assertEqual([json.loads(c[5:])["type"] for c in data], ["verdict"])
        # every chunk is one the pages read or skip: a data line or a comment
        self.assertTrue(all(c.startswith(("data:", ":")) and c.endswith("\n\n")
                            for c in got))

    def test_a_run_that_has_ended_is_read_without_waiting(self):
        live = self.app._Live("r2")
        live.put({"type": "start"})
        live.put({"type": "done"})
        live.put(None)
        got = list(live.follow())
        self.assertEqual([json.loads(c[5:])["type"] for c in got], ["start", "done"])

    def test_a_page_following_late_reads_only_the_thinking_still_in_flight(self):
        # review of 26 October: a page following a long run replayed every
        # thinking line of every question, and 2000 verdicts froze its tab
        live = self.app._Live("r3")
        live.put({"type": "start"})
        for n in range(3):
            live.put({"type": "thinking", "index": 0, "text": f"q0 line {n}"})
        live.put({"type": "thinking", "index": 1, "text": "q1 line"})
        live.put({"type": "verdict", "index": 0})
        live.put({"type": "thinking", "index": 1, "text": "q1 later"})
        live.put({"type": "done"})
        live.put(None)
        got = [json.loads(c[5:]) for c in live.follow()]
        self.assertEqual([(e["type"], e.get("text")) for e in got],
                         [("start", None), ("verdict", None), ("thinking", "q1 later"),
                          ("done", None)])
        self.assertEqual([e["type"] for e in live.events], ["start", "verdict", "done"])


if __name__ == "__main__":
    unittest.main()
