"""The words of a question that say how to compute or how the sentence runs,
never what to look up.

They matter to the guards: a word the schema must hold before a question is
called answerable, and a word that may point at a column, are the words
that carry meaning. "How many products are there per category" asks the
schema for products and categories; "how", "many", "are", "there" and "per"
ask it for nothing. A hand-written list of such words missed "average",
"many", "three" and "supplied" in the first measured run, and would always
miss the next one. So they are generated here from what makes them a class:

  function words  determiners, pronouns, prepositions, conjunctions,
                  auxiliaries, modals, negation and the adverbs of time,
                  degree and focus. These are closed classes: English does
                  not make new ones, so the lists below are the whole of
                  them as used in questions, not a sample.
  operations      what SQL can compute (the aggregate functions of MariaDB:
                  COUNT, SUM, AVG, MIN, MAX, STD, VARIANCE, GROUP_CONCAT...)
                  as English names it, each with every inflection generated
                  (count, counts, counted, counting).
  numbers         cardinals, ordinals and their compounds, generated:
                  "twenty-five", "third", "hundreds".
  requests        the verbs a request opens with: please list, show, give.

Some words compute and also name data: a rate, a rank, an order, a share,
a score, a round of a tournament. No rule tells them apart without the
schema, and a word taken for an operation is never looked for, which could
let a yes through; they stay ordinary words, checked against the schema
(AMBIGUOUS). A trade adds its own operations and logic words in its
vocabulary file, under "calculations" and "logic_words".
"""

import re

DETERMINERS = {
    "a", "an", "the", "this", "that", "these", "those", "my", "your", "his",
    "her", "its", "our", "their", "whose", "which", "what", "whatever",
    "whichever", "each", "every", "either", "neither", "both", "all", "any",
    "some", "no", "none", "several", "few", "fewer", "many", "much", "more",
    "most", "less", "least", "little", "enough", "such", "other", "another",
    "same", "own", "certain", "various"}
PRONOUNS = {
    "i", "me", "we", "us", "you", "he", "him", "she", "it", "they", "them",
    "myself", "yourself", "himself", "herself", "itself", "ourselves",
    "yourselves", "themselves", "who", "whom", "whoever", "someone",
    "somebody", "something", "anyone", "anybody", "anything", "everyone",
    "everybody", "everything", "nobody", "nothing", "ones"}
PREPOSITIONS = {
    "about", "above", "across", "after", "against", "along", "alongside",
    "amid", "among", "amongst", "around", "as", "at", "before", "behind",
    "below", "beneath", "beside", "besides", "between", "beyond", "by",
    "despite", "down", "during", "except", "excluding", "for", "from", "in",
    "including", "inside", "into", "like", "near", "of", "off", "on",
    "onto", "out", "outside", "over", "past", "per", "plus", "regarding",
    "since", "than", "through", "throughout", "till", "to", "toward",
    "towards", "under", "underneath", "unlike", "until", "up", "upon",
    "versus", "via", "vs", "with", "within", "without", "linked",
    "associated", "related", "belonging", "according"}
CONJUNCTIONS = {
    "and", "or", "nor", "but", "yet", "so", "because", "although",
    "though", "whereas", "while", "whilst", "whether", "if", "unless",
    "once", "when", "whenever", "where", "wherever", "why", "how",
    "however", "then", "therefore", "otherwise"}
AUXILIARIES = {
    "be", "am", "is", "are", "was", "were", "been", "being", "do", "does",
    "did", "done", "doing", "have", "has", "had", "having"}
MODALS = {"can", "could", "may", "might", "must", "shall", "should",
          "will", "would", "ought"}
ADVERBS = {
    # negation and frequency
    "not", "never", "ever", "always", "often", "sometimes", "usually",
    "rarely", "seldom",
    # time and aspect
    "already", "still", "yet", "again", "now", "currently", "then", "ago",
    # degree and focus
    "also", "too", "very", "only", "just", "even", "quite", "rather",
    "almost", "nearly", "exactly", "respectively", "together", "else",
    "instead", "here", "there", "anywhere", "everywhere", "somewhere",
    # comparison
    "greater", "higher", "lower", "larger", "smaller", "bigger", "longer",
    "shorter", "earlier", "later", "above", "below"}
REQUESTS = {
    "please", "list", "show", "give", "find", "display", "tell", "provide",
    "summarize", "summarise", "identify", "describe", "calculate", "compute",
    "determine", "retrieve", "fetch", "get", "want", "need", "know", "see",
    "include", "mention"}

FUNCTION_WORDS = (DETERMINERS | PRONOUNS | PREPOSITIONS | CONJUNCTIONS
                  | AUXILIARIES | MODALS | ADVERBS | REQUESTS)

# What SQL computes, as English says it, in the base form; every inflection
# is generated by forms() below
OPERATIONS = {
    "count", "number", "total", "sum", "average", "mean", "avg", "median",
    "maximum", "max", "minimum", "min", "deviation", "stddev", "std",
    "variance", "percentile", "quartile", "percent", "percentage",
    "proportion", "fraction", "distinct", "unique", "different", "aggregate",
    "cumulative", "overall", "combined", "altogether", "breakdown",
    "distribution", "difference", "decimal", "integer", "tally", "many",
    "much", "per",
    # "round" names a round of a tournament too; its participle only rounds
    "rounded", "rounding"}

# compute, and name data too: never taken for an operation
AMBIGUOUS = {
    "rate", "ratio", "rank", "ranking", "order", "share", "frequency",
    "time", "times", "change", "growth", "return", "mode", "group", "running",
    "score", "level", "amount", "round", "add", "value", "balance", "weight",
    "size", "volume", "length", "quarter", "second", "minute", "single",
    "double", "name"}

UNITS = ["zero", "one", "two", "three", "four", "five", "six", "seven",
         "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen",
         "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"]
TENS = ["twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty",
        "ninety"]
SCALES = ["hundred", "thousand", "million", "billion", "trillion"]
ORDINAL_IRREGULAR = {"one": "first", "two": "second", "three": "third",
                     "five": "fifth", "eight": "eighth", "nine": "ninth",
                     "twelve": "twelfth"}


def forms(base):
    """Every inflection of an English word, over-generated on purpose: a
    form that is not a word costs nothing, a missing one is a word the
    guards would look for in vain."""
    base = base.lower()
    out = {base, base + "s", base + "es", base + "ed", base + "ing"}
    if base.endswith("e"):
        out |= {base + "d", base[:-1] + "ing"}
    if base.endswith("y") and len(base) > 2 and base[-2] not in "aeiou":
        out |= {base[:-1] + "ies", base[:-1] + "ied"}
    if len(base) > 2 and base[-1] not in "aeiouwxy" and base[-2] in "aeiou":
        out |= {base + base[-1] + "ed", base + base[-1] + "ing"}
    return out


def number_words():
    """Cardinals, ordinals and the words that count, generated; compounds
    ("twenty-five") arrive split, each part a number word."""
    out = set(UNITS) | set(TENS) | set(SCALES)
    for word in UNITS[1:] + TENS + SCALES:
        if word in ORDINAL_IRREGULAR:
            out.add(ORDINAL_IRREGULAR[word])
        elif word.endswith("y"):
            out.add(word[:-1] + "ieth")
        elif word.endswith("t"):
            out.add(word + "h")
        else:
            out.add(word + "th")
    out |= {"dozen", "half", "twice", "thrice", "once", "couple", "pair"}
    return out


OPERATION_FORMS = {f for base in OPERATIONS for f in forms(base)}
NUMBER_WORDS = number_words()


def operation_words(extra_operations=(), extra_logic=(), normalise=str):
    """The whole set, with a trade's own operations (inflected) and logic
    words, each passed through `normalise`, the clarifier's one spelling
    of a word, so they compare with a question's words as it reads them."""
    ours = OPERATION_FORMS | NUMBER_WORDS | FUNCTION_WORDS
    theirs = {f for base in extra_operations for f in forms(base)} | set(extra_logic)
    # the ambiguous words are kept out of ours; a trade that lists one knows
    # its data, and its word is taken
    return ({normalise(w) for w in ours} - {normalise(w) for w in AMBIGUOUS}
            | {normalise(w) for w in theirs})


# Words that say how a schema keeps time, in its own names: a table that
# keeps what happened row by row, a column that says when a row changed,
# and the columns that open and close a period. A reader of one table
# (verdict_tools.time_columns) looks for them in the names around it, the
# way a person would: salary_history beside employees, valid_from beside
# valid_to. Every word that opens a period comes before every word that
# closes one, and that order is how a pair is read as from, then to. Names
# are compared word by word, singular: "events" is "event".
TIME_WORDS = (
    # a table that keeps what happened, one row per change
    "history", "log", "event", "audit", "journal", "trail", "snapshot",
    "version", "revision", "change", "transition", "movement",
    # a column that says when a row changed
    "changed_at", "updated_at", "modified_at", "recorded_at", "occurred_at",
    "logged_at", "as_of",
    # the columns that open a period...
    "valid_from", "effective_from", "from", "start", "begin", "opened",
    "since",
    # ...and those that close it
    "valid_to", "effective_to", "to", "end", "until", "finish", "closed",
    "expiry", "expire")

# A question asked at a point in time rather than over a period: "on 1 March
# 2025", "on March 1st", "on 01/03/2025", "at the end of June", "at year-end",
# "as of", "ever", "had when the order was placed", "au 31/12/2025". Only such
# a question needs the state kept at a date (a history); "in 2025" filters a
# period and reads that period's rows. The agent took "the scrap rate per
# machine in 2025" for one (E17, 20 October). The verifier skips its history
# check only when the question names a PERIOD and no point in time: a
# question naming neither is checked, the careful way (Verifier._check_time).
_MONTHS = ("january|february|march|april|may|june|july|august|september|october|"
           "november|december|jan|feb|mar|apr|jun|jul|aug|sept|sep|oct|nov|dec|"
           "janvier|f\u00e9vrier|fevrier|mars|avril|mai|juin|juillet|"
           "ao\u00fbt|aout|septembre|octobre|novembre|d\u00e9cembre|decembre")
_DAY = r"\d{1,2}(?:st|nd|rd|th|er)?"
_DATE = r"\d{1,2}/\d{1,2}/\d{2,4}|\d{4}-\d{2}-\d{2}"
POINT_IN_TIME = re.compile(
    r"\b(?:as of|as at|at (?:the )?(?:end|start|beginning|close) of|(?:at )?year[- ]end"
    r"|end of (?:the )?(?:" + _MONTHS + r"|month|quarter|year)"
    r"|on (?:the )?" + _DAY + r",? (?:of )?(?:" + _MONTHS + r")(?!\w)"
    r"|on (?:" + _MONTHS + r")\.? " + _DAY + r"(?!\w)"
    r"|(?:on|at|au|le|du) (?:" + _DATE + r")"
    r"|at the time|at that time|at any (?:time|point)|ever(?!\w)|back then|used to"
    r"|(?:had|held|have|has|was|were|is) (?:\w+ ){0,3}when"
    r"|(?:au|le) " + _DAY + r" (?:" + _MONTHS + r")(?!\w)"
    r"|\u00e0 la date|au moment|\u00e0 la fin d(?:e|u|')|au d\u00e9but d(?:e|u|')"
    r"|fin (?:de |d')(?:" + _MONTHS + r")|d\u00e9j\u00e0|jamais)", re.IGNORECASE)
PERIOD = re.compile(
    r"\b(?:in|during|for|throughout|over|within|across) (?:the )?(?:year )?"
    r"(?:\d{4}|(?:last|this|previous|past|next|current) \w+|q[1-4]|(?:first|second|last) "
    r"(?:half|quarter)|(?:" + _MONTHS + r")(?!\w))"
    r"|\b(?:last|this|previous|past|current) (?:fiscal )?(?:year|quarter|month|week)\b"
    r"|\bbetween\b|\bsince\b|\bfrom \d{4}\b|\bper (?:year|month|quarter|week)\b"
    r"|\ben \d{4}\b|\bpendant\b|\bdepuis\b|\bdurant\b|\bentre\b"
    r"|\bl'an(?:n\u00e9e)? derni(?:er|\u00e8re)\b|\bce mois\b", re.IGNORECASE)

# A question about what would have been ("what would our freight spend have
# been with the tariff increase the carriers announced"): what it supposes is
# the asker's to give, not a thing the database lacks. The agent called it
# absent and the run said NOT COVERED (E26, 20 October). Only the supposition
# is the asker's: "drone deliveries" in "what would our spend on drone
# deliveries have been with a 5% increase" is still looked for, and a polite
# "would" ("I would like the list...") supposes nothing (Verifier._check_absent).
COUNTERFACTUAL = re.compile(
    r"\bwould\b(?:\s+[\w'-]+){0,10}?\s+have\b|\bwhat if\b|\bhad we\b"
    r"|\bif (?:we|our|the|they|it)\b(?:\s+[\w'-]+){0,6}?\s+had\b"
    r"|\bsuppos(?:e|ing)\b|\bassuming\b|\baurai(?:t|ent)\b|\baurions\b"
    r"|\bsi (?:on|nous) avai(?:t|ons)\b|\ben supposant\b", re.IGNORECASE)
_SUPPOSED = re.compile(r"\b(?:with|if|had|assuming|supposing|suppose|given|avec|si|en supposant)"
                       r"\b\s+(.+)$", re.IGNORECASE)
_SUPPOSED_END = re.compile(r"[?]|,\s*(?:what|how|which|who|quel\w*|combien)\b", re.IGNORECASE)


def supposition(question):
    """What a what-if question supposes ("the tariff increase the carriers
    announced"), or "" for a question that supposes nothing."""
    text = str(question or "")
    if not COUNTERFACTUAL.search(text):
        return ""
    found = _SUPPOSED.search(text)
    if not found:
        return ""
    return _SUPPOSED_END.split(found.group(1))[0].strip()


# Words that put events in an order: "reopened after being resolved",
# "invoiced before shipped", "the first review after it", "its previous
# status", "rouverts". Without them a "newest" or "oldest" (first_last) is an
# order by one date, which a date column gives whether or not it holds a
# time of day: the verifier asked for timed events of "who are our newest
# suppliers" (Warehouse Q11, 20 October). A sequence is checked whatever its
# words say.
SEQUENCE = re.compile(
    r"\b(?:after|before|then|following|followed|preced\w*|prior to|previous\w*|next|later"
    r"|subsequent\w*|chang\w*|reopen\w*|re-open\w*|trigger\w*|led to|lead to|caus\w*|again"
    r"|apr\u00e8s|avant|puis|ensuite|rouvert\w*|pr\u00e9c\u00e9d\w*|suivant\w*)\b", re.IGNORECASE)

# What a question compares with: "cheaper than a coffee", "as old as the
# warehouse", "moins cher qu'un caf\u00e9". A reference the database does not
# hold is the asker's to give, as a threshold is (Warehouse Q15 was called
# NOT COVERED). Not a count ("more than one pet", "older than 30 and own a
# boat"), never past the comparison ("and own a boat"), never "other than"
# or "rather than". On the bench it meets one question expected NOT
# COVERED, "taller than average", whose missing thing is the height.
COMPARED_WITH = re.compile(
    r"\b(\w+er|more(?: \w+)?|less(?: \w+)?|fewer(?: \w+)?)\s+than\s+([^?.,;!]{1,60})"
    r"|\bas \w+ as\s+([^?.,;!]{1,60})"
    r"|\b(?:plus|moins)(?: \w+)? qu(?:e |')([^?.,;!]{1,60})", re.IGNORECASE)
_COMPARISON_END = re.compile(r"\b(?:and|or|who|which|that|with|but|where|whose"
                             r"|et|ou|qui|avec|dont)\b", re.IGNORECASE)
_A_COUNT = re.compile(r"(?:\d|(?:one|two|three|four|five|six|seven|eight|nine|ten|eleven"
                      r"|twelve|twenty|thirty|fifty|hundred|thousand|dozen|a few|a dozen"
                      r"|un|une|deux|trois|quatre|cinq|dix|cent)\b)", re.IGNORECASE)


# A distance from a place: "within 50 km of our office", "less than 10
# miles from the depot", "à moins de 5 km de notre siège". The place is the
# asker's to locate, as a threshold is (Point pt-h26, 23 October).
_UNIT = r"(?:km|kilomet(?:er|re)s?|kilom\u00e8tres?|mi|miles?|met(?:er|re)s?|m\u00e8tres?)"
_N = r"\d[\d.,]*\s*"
# "of" only after "within": "100 km of bike lanes" is a length, not a place;
# and "m" alone is millions as often as metres (review of 23 October)
DISTANCE_FROM = re.compile(
    r"\bwithin\s+" + _N + _UNIT + r"\s+(?:of|from|around)\s+([^?.,;!]{1,60})"
    r"|\b" + _N + _UNIT + r"\s+(?:away\s+)?from\s+([^?.,;!]{1,60})"
    r"|\b" + _N + _UNIT + r"\s+around\s+([^?.,;!]{1,60})"
    r"|\b(?:\u00e0 moins de|dans un rayon de)\s+" + _N + _UNIT
    + r"\s+(?:de|du|des|d')\s*([^?.,;!]{1,60})", re.IGNORECASE)


# A verb of the trade and the nouns its tables are named by: "how many
# products did we sell" swept "sell", met sales_orders nowhere, and was
# refused (Warehouse Q14, 23 October). Tried only when the verb is absent.
VERB_NOUNS = {
    "sell": ("sale", "sold"), "sold": ("sale",), "buy": ("purchase", "bought"),
    "bought": ("purchase",), "pay": ("payment", "paid"), "paid": ("payment",),
    "ship": ("shipment", "shipping"), "shipped": ("shipment",),
    "deliver": ("delivery",), "delivered": ("delivery",), "spend": ("expense",),
    "spent": ("expense",), "borrow": ("loan",), "borrowed": ("loan",),
    "lend": ("loan",), "lent": ("loan",), "rent": ("rental",), "rented": ("rental",),
    "hire": ("hiring", "hire_date"), "hired": ("hire_date", "hiring"),
    "book": ("booking", "reservation"), "booked": ("booking", "reservation"),
    "vendre": ("vente",), "vendu": ("vente",), "acheter": ("achat",), "achet\u00e9": ("achat",),
}


def noun_forms(term):
    """The term with its verb replaced by each noun the tables use, or []."""
    words = str(term or "").split()
    out = []
    for i, w in enumerate(words):
        for noun in VERB_NOUNS.get(w.lower(), ()):
            out.append(" ".join(words[:i] + [noun] + words[i + 1:]))
    return out


# A time word only the asker can bound: rows never say where "recently"
# begins (Library and Warehouse Q14, 23 October: a count of the last 30
# days took it for data and the NEEDS MORE was dropped).
VAGUE_TIME = re.compile(
    r"\b(?:(?<!most )(?<!least )recent|recently|lately|of late|soon|nowadays|these days"
    r"|upcoming|in the near future"
    r"|r\u00e9cemment|derni\u00e8rement|bient\u00f4t|ces temps-ci"
    # "commandes récentes", never "les plus récentes", which orders by age
    r"|(?<!plus )r\u00e9cent(?:e|s|es)?)\b", re.IGNORECASE)


def compared_with(question):
    """The references a question compares with, as written: never a count,
    never past the comparison. A place a distance is measured from is one."""
    out = []
    for m in COMPARED_WITH.finditer(str(question or "")):
        head = (m.group(1) or "").lower().split()
        if head and head[0] in ("other", "rather"):
            continue
        reference = _COMPARISON_END.split(next(g for g in m.groups()[1:] if g))[0].strip()
        if reference and not _A_COUNT.match(reference):
            out.append(reference)
    for m in DISTANCE_FROM.finditer(str(question or "")):
        reference = _COMPARISON_END.split(next(g for g in m.groups() if g))[0].strip()
        if reference and not _A_COUNT.match(reference):
            out.append(reference)
    return out

# Words that order things by age: "the oldest members", "our newest
# suppliers", "the latest orders". Each date a thing has (joined, created,
# born, first ordered) is a reading of them, and the agent saw only one
# (Warehouse Q10, Q11, Library Q09, 20 October): the code then lists the
# dates of the question's tables before the agent concludes
# (VerdictAgent._probe). Not "last year" nor "first quarter", which are
# periods.
_PERIOD_NOUN = r"(?: (?:half|quarter|year|month|week|day|time|semester))"
ORDERED_BY_AGE = re.compile(
    r"\b(?:oldest|newest|latest|earliest|youngest|most recent|least recent|longest[- ]standing"
    r"|first(?!" + _PERIOD_NOUN + r")|last(?!" + _PERIOD_NOUN + r")"
    r"|plus ancien\w*|plus r\u00e9cent\w*|plus jeunes?|premiers?(?!" + _PERIOD_NOUN + r")"
    r"|derni(?:er|\u00e8re)s?(?!" + _PERIOD_NOUN + r"))\b", re.IGNORECASE)
