"""Datagora's question-to-answer engine, as one import.

The whole point of this file is that a production application should not
have to know how the parts fit together. It needs a database, optionally
a graph, two models, and one method.

    from graph_lab import Datagora

    dg = Datagora(
        mysql=dict(host="db.internal", port=3306, database="sales",
                   user="readonly", password=os.environ["DB_PASSWORD"]),
        neo4j_uri="bolt://graph.internal:7687",      # optional
        neo4j_password=os.environ["NEO4J_PASSWORD"], # optional
        reasoner="server-gemma",                     # optional
        sql="jarvis-arctic",                         # optional
    )

    out = dg.ask("how many orders per city last month")
    if out.waiting:                     # the question was ambiguous
        out = dg.ask(out.question, choice=out.options[0].label)
    print(out.answer)

When a question needs a choice or more detail, `out.suggestions` holds
whole questions in the asker's words to put to them instead of the
readings (`reformulate=False`, or DATAGORA_REFORMULATE=off, turns it off):

    s = out.suggestions[0]
    out = (dg.ask(out.question, choice=s.choice, suggestion=s.question)
           if s.choice else dg.ask(s.question))

Credentials are passed in, never read from a file, so an application
that already has a secret manager keeps using it. Nothing here writes:
every statement runs inside a transaction that is rolled back.

**Neo4j is optional.** Without it the engine still clarifies, generates,
checks the dialect, runs EXPLAIN and executes read-only, and every run
reports that joins were not verified. With it, the joins are imposed
from the schema graph and audited before execution. Adopt the first,
add the second when you want the guarantee.
"""

import os
import threading

from .ambisql import Clarifier, Option, Outcome

# the steps as plain functions, for a pipeline that wants one of them
# rather than all of them
from .api import (
    Ambiguity,
    check_sql,
    imposed_joins,
    is_ambiguous,
    name_tables,
    run_sql,
    say,
    suggest_questions,
    write_sql,
)
from .coverage import (
    ANSWERABLE,
    NEEDS_CHOICE,
    NEEDS_MORE,
    NO_DATA,
    NOT_COVERED,
    UNKNOWN,
    BatchReport,
    assess_file,
    job_id,
    read_questions,
    read_questions_from_text,
    write_verdicts,
)
from .coverage import Verdict as CoverageVerdict
from .coverage import assess as assess_coverage
from .db_profile import DbProfile
from .dialect_lint import lint, repair_message, transpile
from .llm import LLM
from .pipeline import Pipeline, Run, _EmptyGraph
from .reformulate import Suggestion
from .schema_graph import (
    Graph,
    audit_joins,
    audit_literals,
    audit_traps,
    explain_check,
    judge_sql,
    parse_sql,
)

__version__ = "1.2.0"

__all__ = ["Datagora", "Pipeline", "Run", "Clarifier", "Outcome", "Option",
           "DbProfile", "LLM", "Graph", "audit_joins", "audit_literals",
           "audit_traps",
           "explain_check", "parse_sql", "lint", "repair_message",
           "transpile",
           # the functional surface
           "is_ambiguous", "name_tables", "imposed_joins", "write_sql",
           "check_sql", "run_sql", "say", "Ambiguity",
           "suggest_questions", "Suggestion",
           # resumable question coverage
           "assess_file", "assess_coverage", "BatchReport", "job_id",
           "CoverageVerdict", "read_questions", "read_questions_from_text",
           "write_verdicts", "ANSWERABLE", "NEEDS_CHOICE", "NEEDS_MORE",
           "NO_DATA", "NOT_COVERED", "UNKNOWN"]


class Answer:
    """What `ask` returns: an answer, or a question to put to the user."""

    def __init__(self, run):
        self._run = run
        self.answer = run.answer
        self.failed = run.failed
        self.sql = run.sql
        self.rows = run.rows
        self.columns = run.columns
        self.question = run.question
        self.technical_question = run.technical_question
        self.steps = run.steps
        c = run.clarification
        self.options = list(getattr(c, "options", []) or [])
        self.waiting = bool(self.options and not run.answer and not run.failed)
        self.clarification = None if c is None else getattr(c, "question", "")
        self.kind = "" if c is None else getattr(c, "kind", "")
        # when the question needs a choice or more detail: the question to
        # put to the asker in plain words, and whole questions they can
        # pick. Empty when the switch is off or nothing waits for them.
        self.clarifying = getattr(run, "clarifying", "") or ""
        self.suggestions = [s if isinstance(s, Suggestion) else Suggestion(**s)
                            for s in getattr(run, "suggestions", None) or []]

    def __repr__(self):
        n = len(self.suggestions)
        said = f"{n} suggestion" + ("" if n == 1 else "s")
        if self.waiting:
            return (f"<Answer waiting, {len(self.options)} options"
                    + (f", {said}>" if n else ">"))
        if n and not self.answer:
            return f"<Answer needs more, {said}>"
        return f"<Answer {self.answer[:60]!r}>" if self.answer \
            else f"<Answer failed: {self.failed[:60]}>"


def _picked(suggestion, question):
    """Whether `question` is this suggestion, as offered or with its
    [blank] filled in by the asker."""
    text = str(getattr(suggestion, "question", "") or "")
    asked = " ".join(str(question or "").split()).lower()
    if " ".join(text.split()).lower() == asked:
        return True
    if not getattr(suggestion, "blank", False) or "[" not in text or "]" not in text:
        return False
    left, right = text.split("[", 1)[0], text.split("]", 1)[1]
    left, right = " ".join(left.split()).lower(), " ".join(right.split()).lower()
    return bool(left or right) and asked.startswith(left) and asked.endswith(right) \
        and len(asked) > len(left) + len(right)


class Datagora:
    """One database, two models, one method."""

    def __init__(self, mysql, *, name=None, neo4j_uri=None,
                 neo4j_user="neo4j", neo4j_password=None, dialect="mysql",
                 reasoner=None, sql=None, descriptions=None, reformulate=None,
                 judge=None, context=None, qdrant_url=None, qdrant_collection=None,
                 embed_url=None, embed_model=None):
        # `name` is the namespace the graph is stored under, so it has to
        # be the same string here and when the graph was built. Defaulting
        # it to the database name makes that automatic: one graph per
        # database, and an application never has to think about it. Pass
        # it explicitly only to keep several graphs of one database apart.
        name = name or mysql["database"]
        self.profile = DbProfile(name=name, mysql=dict(mysql),
                                 dialect=dialect,
                                 neo4j_uri=neo4j_uri,
                                 neo4j_user=neo4j_user,
                                 # this client's own password: the
                                 # environment would hand a second client
                                 # the first one's (review of 26 October)
                                 neo4j_password=neo4j_password,
                                 descriptions=(descriptions
                                               or os.environ.get(
                                                   "DATAGORA_DESCRIPTIONS")))
        # the corpus of answered questions and the column index live in
        # Qdrant, searched with an embedding model: given here, a client has
        # them as the application does; left out, it works without them
        if qdrant_url:
            self.profile.qdrant_url = qdrant_url
        if qdrant_collection:
            self.profile.qdrant_collection = qdrant_collection
        if embed_url:
            self.profile.ollama_url = embed_url
        if embed_model:
            self.profile.embed_model = embed_model
        self._use_graph = bool(neo4j_uri)
        # `reformulate`: whether a question that needs a choice or more
        # detail comes back with questions to pick (Answer.suggestions).
        # None reads DATAGORA_REFORMULATE at each question, on by default.
        self.pipeline = Pipeline(
            self.profile,
            reasoner=_endpoint(reasoner),
            sql_llm=_endpoint(sql),
            reformulate=reformulate, judge=judge, context=context)
        if not self._use_graph:                  # do not even try to dial
            self.pipeline._graph = _NoGraph()
        # the last answer that stopped with suggestions: the question
        # picked from them is judged knowing what was decided (ask)
        self._last_stop = None

    # the last stop is each thread's own: two users of one client in a web
    # server took each other's stop, and a question was judged with another
    # person's note (review of 26 October)
    @property
    def _last_stop(self):
        local = self.__dict__.get("_last")
        return getattr(local, "stop", None) if local is not None else None

    @_last_stop.setter
    def _last_stop(self, value):
        self.__dict__.setdefault("_last", threading.local()).stop = value

    @property
    def reformulate(self):
        """Whether the next question may come back with suggestions.

        Set it to True or False to force it, or None to follow
        DATAGORA_REFORMULATE again; it takes effect on the next ask. Read,
        it says what will happen, whichever of the two decides."""
        return self.pipeline.reformulates

    @reformulate.setter
    def reformulate(self, value):
        self.pipeline.reformulate = None if value is None else bool(value)

    @property
    def judge(self):
        """Who decides whether a question is clear: "single", the one call
        and its checks, or "agent", the judge that explores the database
        (slower, minutes rather than seconds, and more often right). None
        follows DATAGORA_ASK_JUDGE, then the agent; set it to change the next
        question's judge."""
        return self.pipeline.judge_mode

    @judge.setter
    def judge(self, value):
        self.pipeline.judge = value

    @property
    def context(self):
        """Who asks and when, told to every model with the question
        (graph_lab.context): None, the machine's date, time, timezone and
        language at each question, plus DATAGORA_CONTEXT; a dict of facts
        over them ({"location": "Montreal", "currency": "CAD"}); a
        callable returning one; False for none."""
        return self.pipeline.context

    @context.setter
    def context(self, value):
        self.pipeline.context = value

    # -------------------------------------------------------------- use
    def ask(self, question, choice=None, suggestion=None, context=None, earlier=None):
        """An answer, or what to put to the user first.

        `choice` answers a clarification by an option's label. With it,
        `suggestion` is the question picked from Answer.suggestions for
        that option, which is answered as it is, without clarifying again.
        A suggestion without a choice (NEEDS MORE) is simply a new
        question: `ask(s.question)`. `context` is who asks and when for
        this question, over the client's (a user's own timezone and local
        time, say).

        `earlier` is the Answer this question follows. Left out, a question
        picked from the last answer's suggestions follows that answer by
        itself, and the judge is told what was decided there rather than
        starting again; False says it follows nothing. A choice comes back
        to the same question and needs no note."""
        last = getattr(self, "_last_stop", None)
        if earlier is None and last is not None and (
                (choice is not None and question == last.question)
                or (choice is None and any(_picked(s, question) for s in last.suggestions))):
            # a suggestion picked, as it is or with its [blank] filled in;
            # a choice on the question that stopped, judged with the note
            # its options were judged with (review of 26 October)
            earlier = last
        if isinstance(earlier, Answer):
            earlier = earlier._run
        answer = Answer(self.pipeline.ask(question, choice, suggestion=suggestion,
                                          context=context, earlier=earlier or None))
        # any stop, suggestions or not: a choice coming back to it is judged
        # with its note (review of the fixes: with reformulate off, a choice
        # was judged with none, and could be told "no longer offered")
        run = answer._run
        stopped = not answer.answer and not run.failed and (
            run.clarification is not None or bool(answer.suggestions))
        self._last_stop = answer if stopped else None
        return answer

    def check_sql(self, sql):
        """Judge a query you already have, without running it. Returns a
        list of (verdict, explanation); empty means nothing to report.

        Delegates to the one implementation in schema_graph. This used to
        keep its own shorter copy of the sequence and had quietly fallen
        two gates behind, so the same object called a query fine here and
        rejected it three times through ask()."""
        con = self.profile.connect_mysql()
        try:
            findings, _ran = judge_sql(
                sql,
                columns=self.pipeline.clarifier.columns,
                graph=self.pipeline.graph if self.pipeline.has_graph else None,
                con=con)
            return findings
        finally:
            con.close()

    def build_graph(self):
        """Read the schema and write its join graph. Run once per
        database, and again after a migration: it is idempotent and it
        preserves any weight or meaning a human curated."""
        from .build_graph import classify, read_schema, write_graph
        tables, fks, unique_sets, primary = read_schema(self.profile)
        edges, junctions = classify(fks, unique_sets, primary)
        stored, missing = write_graph(self.profile, tables, edges, junctions)
        self.pipeline._graph = None              # re-read on next use
        self._use_graph = True
        return {"tables": stored[0], "edges": stored[1],
                "edges_needing_a_meaning": missing}

    @property
    def has_graph(self):
        return self.pipeline.has_graph

    def health(self):
        ok_db = True
        try:
            self.profile.connect_mysql().close()
        except Exception:
            ok_db = False
        return {"database": ok_db,
                "graph": self.has_graph,
                "reasoner": self.pipeline.reasoner.reachable(),
                "sql": self.pipeline.sql_llm.reachable()}

    def close(self):
        self.pipeline.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


def _endpoint(model):
    """A configured endpoint's name loaded, an LLM (or any object with the
    same chat and json) used as it is, nothing left to the roles. An
    application that builds its own LLM had to register it under a name
    first, which is a file or a variable for one object it already held."""
    if not model:
        return None
    return LLM.load(model) if isinstance(model, str) else model


class _NoGraph(_EmptyGraph):
    """Chosen explicitly when no neo4j_uri was given, so the engine never
    waits on a connection nobody asked for: the pipeline's empty graph,
    never retried since no graph failed (review of 26 October: a copy of
    it, which could drift)."""
