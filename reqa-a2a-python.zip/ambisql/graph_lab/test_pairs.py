"""The question/SQL pairs: split, leak check, tags, hashing, file shape.

The scripts live in docs/test_strategy/coverage_bench (step 24). Nothing
here reads a database: the logic is tested on built cases, and the shipped
pair files are checked as files (every group placed, answer keys out of the
corpus, no evaluation question close to a corpus one).

    .venv/Scripts/python -m unittest test_pairs
"""

import json
import random
import sys
import unittest
from collections import Counter
from pathlib import Path

BENCH = Path(__file__).resolve().parents[2] / "docs" / "test_strategy" / "coverage_bench"
sys.path.insert(0, str(BENCH))

import pairs_common as pc  # noqa: E402
import split_pairs as sp  # noqa: E402
import verify_pairs as vp  # noqa: E402


def tags(**over):
    base = {"join_depth": 0, "temporal": False, "polymorphic": False,
            "anti_join": False, "window": False, "aggregate": False,
            "business_concept": False, "language": "en", "empty_ok": False}
    base.update(over)
    return base


def pair(pid, question, group=None, source="hand", verdict="ANSWERABLE",
         profile="Library", sql="SELECT 1", **tag_over):
    group = group or pid
    return {"id": pid, "profile": profile, "question": question, "sql": sql,
            "accepted_sql": [], "row_count": 1, "result_hash": "h" + group,
            "verdict": verdict, "group": group, "tags": tags(**tag_over),
            "source": source, "definition": None, "reviewed": True,
            "notes": "", "paraphrase_of": None if pid == group else group,
            "tables": [], "accepted_results": []}


WORDS = ("amber basil cedar delta ember fjord glade harbor indigo juniper "
         "kestrel lagoon meadow nectar orchid prairie quartz raven saffron "
         "tundra umber violet willow xenon yarrow zephyr").split()


def distinct_questions(n, seed=7):
    """n questions far apart from each other (random words and numbers)."""
    rng = random.Random(seed)
    out = set()
    while len(out) < n:
        words = [rng.choice(WORDS) for _ in range(4)]
        words += ["".join(rng.choice("bcdfghjklmnpqrstvwxz0123456789")
                          for _ in range(6)) for _ in range(3)]
        out.add(" ".join(words) + "?")
    return sorted(out)


class Normalise(unittest.TestCase):
    def test_case_accents_and_punctuation_go(self):
        self.assertEqual(pc.norm_question("Combien de clients, créés en 2025 ?"),
                         "combien de clients crees en 2025")

    def test_spaces_collapse(self):
        self.assertEqual(pc.norm_question("  Which   books?"), "which books")


class NearDuplicate(unittest.TestCase):
    def test_equal_after_normalisation(self):
        self.assertTrue(sp.near_duplicate("Which books?", "which BOOKS"))

    def test_one_word_changed_in_a_long_question(self):
        a = "Which customers in the DACH sales territory ordered pumps in 2025?"
        b = "Which customers in the DACH sales territory ordered pumps in 2024?"
        self.assertTrue(sp.near_duplicate(a, b))

    def test_different_questions(self):
        self.assertFalse(sp.near_duplicate("How many books are there?",
                                           "Which members joined in 2025?"))

    def test_threshold_is_respected(self):
        a, b = "abcdefghij", "abcdefghxy"          # ratio 0.8
        self.assertFalse(sp.near_duplicate(a, b, 0.9))
        self.assertTrue(sp.near_duplicate(a, b, 0.75))


class LeakCheck(unittest.TestCase):
    def test_flags_equal_and_near_questions(self):
        corpus = [("c1", "How many books are in the catalogue?"),
                  ("c2", "Which genres have no parent genre?")]
        evaluation = [("e1", "how many books are in the catalogue"),
                      ("e2", "Which genres have no parent genres?"),
                      ("e3", "Who borrowed the most books in 2024?")]
        flags = sp.leak_check(evaluation, corpus)
        self.assertEqual({(e, c) for e, c, _ in flags}, {("e1", "c1"), ("e2", "c2")})
        self.assertTrue(all(r >= 0.9 for _, _, r in flags))

    def test_clean_split_gives_no_flag(self):
        qs = distinct_questions(20)
        self.assertEqual(sp.leak_check([("e", q) for q in qs[:10]],
                                       [("c", q) for q in qs[10:]]), [])

    def test_accepts_pair_dicts(self):
        flags = sp.leak_check([pair("e1", "Which books are cheap?")],
                              [pair("c1", "which books are cheap")])
        self.assertEqual(flags[0][:2], ("e1", "c1"))


class Clusters(unittest.TestCase):
    def test_near_identical_groups_are_joined(self):
        pairs = [pair("g1", "Which campaigns have an end date before 2025?"),
                 pair("g2", "Which campaigns have an end date before 2026?"),
                 pair("g3", "How many loans did each member have?")]
        self.assertEqual(sp.clusters(pairs), [["g1", "g2"], ["g3"]])

    def test_a_paraphrase_can_join_two_groups(self):
        pairs = [pair("g1", "How many books are in the catalogue?"),
                 pair("g1.1", "Count the books held by the library.", group="g1"),
                 pair("g2", "Count the books held by the library!")]
        self.assertEqual(sp.clusters(pairs), [["g1", "g2"]])


class Assign(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pairs = cls.build()
        cls.split = sp.assign(cls.pairs)

    @staticmethod
    def build(n=200, keys=20):
        qs = distinct_questions(n + keys + 40)
        pairs = []
        for i in range(n):
            g = f"lib-h{i:03d}"
            pairs.append(pair(g, qs[i], join_depth=i % 4, temporal=i % 3 == 0,
                              window=i % 7 == 0))
            if i % 3 == 0:                          # a paraphrase
                pairs.append(pair(f"{g}.1", qs[n + keys + i % 40] + f" {i}",
                                  group=g, join_depth=i % 4,
                                  temporal=True, window=i % 7 == 0))
        for k in range(keys):
            pairs.append(pair(f"lib-Q{k:02d}", qs[n + k], source="answer_key"))
        return pairs

    def test_every_group_gets_one_side_and_paraphrases_follow(self):
        pairs, split = self.pairs, self.split
        self.assertEqual(set(split), {p["group"] for p in pairs})
        self.assertTrue(set(split.values()) <= set(sp.SIDES))

    def test_answer_keys_are_never_corpus(self):
        split = self.split
        keys = [g for g in split if "-Q" in g]
        self.assertEqual({split[g] for g in keys}, {"eval_tune"})

    def test_proportions_80_10_10_outside_the_answer_keys(self):
        split = self.split
        sides = Counter(s for g, s in split.items() if "-Q" not in g)
        total = sum(sides.values())
        self.assertAlmostEqual(sides["corpus"] / total, 0.8, delta=0.03)
        self.assertAlmostEqual(sides["eval_tune"] / total, 0.1, delta=0.03)
        self.assertAlmostEqual(sides["eval_locked"] / total, 0.1, delta=0.03)

    def test_deterministic_and_seeded(self):
        self.assertEqual(sp.assign(self.pairs), self.split)
        self.assertNotEqual(sp.assign(self.pairs, seed=2), self.split)

    def test_each_large_cell_reaches_the_evaluation(self):
        pairs, split = self.pairs, self.split
        cells = {}
        for p in pairs:
            if p["paraphrase_of"] is None and p["source"] != "answer_key":
                cells.setdefault(sp.cell_key(p), []).append(split[p["group"]])
        for cell, sides in cells.items():
            if len(sides) >= 10:
                self.assertTrue(set(sides) & set(sp.EVAL), cell)

    def test_the_split_of_built_pairs_has_no_leak(self):
        pairs, split = self.pairs, self.split
        ev = [p for p in pairs if split[p["group"]] in sp.EVAL]
        co = [p for p in pairs if split[p["group"]] == "corpus"]
        self.assertEqual(sp.leak_check(ev, co), [])


class ReadOnly(unittest.TestCase):
    def test_writes_are_refused(self):
        for sql in ("DELETE FROM books", "UPDATE books SET price = 1",
                    "INSERT INTO books VALUES (1)", "DROP TABLE books",
                    "SELECT 1; DROP TABLE books", "SET @a = 1",
                    "SELECT * FROM books INTO OUTFILE '/tmp/x'"):
            with self.assertRaises(ValueError, msg=sql):
                pc.check_read_only(sql)

    def test_reads_pass(self):
        for sql in ("SELECT 1", "WITH a AS (SELECT 1) SELECT * FROM a",
                    "SELECT REPLACE(title, 'a', 'b') FROM books",
                    "SELECT 'x; DROP TABLE y' AS text",
                    "-- comment\nSELECT title FROM books;"):
            pc.check_read_only(sql)


class Hash(unittest.TestCase):
    def test_row_order_does_not_matter(self):
        self.assertEqual(pc.result_hash([(1, "a"), (2, "b")]),
                         pc.result_hash([(2, "b"), (1, "a")]))

    def test_decimal_and_int_hash_alike(self):
        import decimal
        self.assertEqual(pc.result_hash([(decimal.Decimal("5.00"),)]),
                         pc.result_hash([(5,)]))

    def test_different_rows_differ(self):
        self.assertNotEqual(pc.result_hash([(1,)]), pc.result_hash([(2,)]))


class Tags(unittest.TestCase):
    def test_anti_join_by_left_join_or_not_exists(self):
        left = ("SELECT b.title FROM books b LEFT JOIN loans l "
                "ON l.book_id = b.book_id WHERE l.loan_id IS NULL")
        sub = ("SELECT title FROM books b WHERE NOT EXISTS "
               "(SELECT 1 FROM loans l WHERE l.book_id = b.book_id)")
        self.assertTrue(pc.infer_tags(left, "library")["anti_join"])
        self.assertTrue(pc.infer_tags(sub, "library")["anti_join"])
        self.assertFalse(pc.infer_tags("SELECT b.title FROM books b LEFT JOIN "
                                       "genres g ON g.genre_id = b.genre_id",
                                       "library")["anti_join"])

    def test_window_temporal_depth(self):
        sql = ("WITH r AS (SELECT member_id, RANK() OVER (ORDER BY borrowed_at) rk "
               "FROM loans WHERE borrowed_at >= '2025-01-01') "
               "SELECT m.full_name FROM r JOIN members m ON m.member_id = r.member_id")
        t = pc.infer_tags(sql, "library")
        self.assertTrue(t["window"] and t["temporal"])
        self.assertEqual(t["join_depth"], 1)              # loans, members; r is a CTE

    def test_tables_ignore_ctes_and_extract(self):
        sql = ("WITH x AS (SELECT * FROM loans) SELECT EXTRACT(YEAR FROM "
               "x.borrowed_at) FROM x JOIN books b ON b.book_id = x.book_id")
        self.assertEqual(pc.sql_tables(sql), ["loans", "books"])

    def test_polymorphic_markers_and_overrides(self):
        self.assertTrue(pc.infer_tags("SELECT COUNT(*) FROM copies WHERE "
                                      "kind_code = 'DGTLCP'", "library")["polymorphic"])
        t = pc.infer_tags("SELECT 1 FROM lots", "enterprise",
                          {"polymorphic": True}, "x = y", language="fr")
        self.assertTrue(t["polymorphic"] and t["business_concept"])
        self.assertEqual(t["language"], "fr")
        with self.assertRaises(ValueError):
            pc.infer_tags("SELECT 1", "library", {"colour": "blue"})


class Shape(unittest.TestCase):
    def test_a_valid_group_passes(self):
        pairs = [pair("lib-h1", "How many books?"),
                 pair("lib-h1.1", "Count the books.", group="lib-h1")]
        self.assertEqual(vp.check_shape(pairs, "Library"), [])

    def test_paraphrases_must_share_the_sql(self):
        para = pair("lib-h1.1", "Count the books.", group="lib-h1")
        para["sql"] = "SELECT 2"
        problems = vp.check_shape([pair("lib-h1", "How many books?"), para], "Library")
        self.assertTrue(any("disagree on sql" in p for p in problems))

    def test_missing_tag_and_empty_answer_are_caught(self):
        p = pair("lib-h1", "How many books?")
        del p["tags"]["window"]
        p["row_count"] = 0
        problems = vp.check_shape([p], "Library")
        self.assertTrue(any("tags" in m for m in problems))
        self.assertTrue(any("no row" in m for m in problems))


PAIRS_DIR = BENCH / "pairs"


@unittest.skipUnless((PAIRS_DIR / "split.json").exists(), "pairs not built")
class ShippedFiles(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pairs = {k: pc.load_pairs(k) for k in pc.PROFILES}
        cls.split = json.loads((PAIRS_DIR / "split.json").read_text(encoding="utf-8"))

    def test_files_are_well_formed(self):
        for key, pairs in self.pairs.items():
            self.assertTrue(pairs, key)
            self.assertEqual(vp.check_shape(pairs, pc.PROFILES[key]["profile"]), [], key)

    def test_every_group_is_placed_and_answer_keys_stay_out_of_the_corpus(self):
        for pairs in self.pairs.values():
            for p in pairs:
                self.assertIn(self.split[p["group"]], sp.SIDES)
                if p["source"] == "answer_key":
                    self.assertNotEqual(self.split[p["group"]], "corpus", p["id"])

    def test_no_evaluation_question_is_close_to_a_corpus_one(self):
        exports = {}
        for key in pc.PROFILES:
            path = PAIRS_DIR / f"{key}.corpus_sample_queries.json"
            exports[key] = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(sp.run_leak_checks(self.pairs, self.split, exports), [])

    def test_sample_queries_come_from_the_corpus_only(self):
        for key in pc.PROFILES:
            path = PAIRS_DIR / f"{key}.corpus_sample_queries.json"
            for entries in json.loads(path.read_text(encoding="utf-8")).values():
                for q in entries:
                    self.assertEqual(set(q) >= {"question", "sql", "level", "kind"}, True)
                    group = q["pair_id"].split(".")[0]
                    self.assertEqual(self.split[group], "corpus", q["pair_id"])


if __name__ == "__main__":
    unittest.main()
