"""Ask judged by the agent: the switch, the judge built once and copied for
each question, the verdict kept for the asker's choice, the agent's settings
for one person waiting, the settings key and the client. No model, no
database."""

import os

os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

import unittest
from types import SimpleNamespace
from unittest.mock import patch

import pipeline
import settings_store
from ambisql import Option, Outcome


class Judge:
    """Stands for a judge, built as VerdictAgent is: over a clarifier, with a
    schema view and settings, so Pipeline._clarify copies it for each
    question as it copies the agent. The copies share what the clarifier
    holds (the outcome, the calls, the judges made); each keeps its own
    trace and the tables it showed."""

    def __init__(self, clar, view=None, settings=None, system=None):
        self.clar, self._view, self._settings, self._system = clar, view, settings, system
        self.last_trace = self.last_shown = None
        clar.judges.append(self)

    outcome = property(lambda self: self.clar.outcome,
                       lambda self, value: setattr(self.clar, "outcome", value))
    calls = property(lambda self: self.clar.calls)

    def clarify(self, question):
        self.calls.append(question)
        if self.clar.meet is not None:
            self.clar.meet.wait(10)            # two questions in flight at once
        self.last_trace = {"question": question, "judge": id(self)}
        self.last_shown = [f"tables of {question}"]
        return self.outcome


def judge_of(outcome, system=None):
    """A judge as the pipeline builds one, over a clarifier of its own."""
    clar = SimpleNamespace(outcome=outcome, calls=[], judges=[], meet=None)
    return Judge(clar, view=SimpleNamespace(read="once"), settings=pipeline.ask_settings({}),
                 system=system)


CHOICE = Outcome(action="CLARIFY", phrase="active", kind="AmbiSchema", reason="r",
                 question='By "active", which do you mean?',
                 options=[Option(label="by status", means="status ACTIVE"),
                          Option(label="by date", means="no termination date")])


def pipe(judge=None, single=None, agent=None):
    p = pipeline.Pipeline.__new__(pipeline.Pipeline)
    p.judge, p.reformulate = judge, False
    p.clarifier = single or judge_of(Outcome(action="ANSWER", reason="clear"))
    p._agent, p._verdicts = agent, {}
    p.profile = SimpleNamespace(name="Shop")
    return p


class JudgeChoiceTests(unittest.TestCase):

    def test_the_pipeline_choice_then_the_environment_then_the_agent(self):
        # the agent by default since 1.2.0 (27 October: 23 of 29 right
        # against 19 for the single call)
        with patch.dict("os.environ", {"DATAGORA_ASK_JUDGE": "single"}):
            self.assertEqual(pipe().judge_mode, "single")
            self.assertEqual(pipe(judge="agent").judge_mode, "agent")
        with patch.dict("os.environ", {"DATAGORA_ASK_JUDGE": "both"}):
            self.assertEqual(pipe().judge_mode, "agent")
        with patch.dict("os.environ", {}, clear=False):
            os.environ.pop("DATAGORA_ASK_JUDGE", None)
            self.assertEqual(pipe().judge_mode, "agent")

    def test_the_single_judge_is_the_clarifier_as_before(self):
        single, agent = judge_of(CHOICE), judge_of(CHOICE)
        p = pipe(judge="single", single=single, agent=agent)
        p._clarify("q?")
        self.assertEqual((len(single.calls), len(agent.calls)), (1, 0))

    def test_the_agent_verdict_is_kept_for_the_askers_choice(self):
        single, agent = judge_of(CHOICE), judge_of(CHOICE)
        p = pipe(judge="agent", single=single, agent=agent)
        first = p._clarify("How many active employees?")
        again = p._clarify("how many  active employees?", again=True)
        self.assertIs(first, again)
        self.assertEqual((len(single.calls), len(agent.calls)), (0, 1))
        p._clarify("How many active employees?")          # a new question is judged anew
        self.assertEqual(len(agent.calls), 2)

    def test_two_askers_of_one_question_each_choose_among_their_own(self):
        # review of 26 October: the second verdict replaced the first, and
        # the first asker's reading was "no longer offered"
        other = Outcome(action="CLARIFY", phrase="active", kind="AmbiSchema", reason="r",
                        question='By "active", which do you mean?',
                        options=[Option(label="by login", means="logged in this month"),
                                 Option(label="by date", means="no termination date")])
        agent = judge_of(CHOICE)
        p = pipe(judge="agent", agent=agent)
        first = p._clarify("How many active employees?")
        agent.outcome = other
        second = p._clarify("How many active employees?")
        self.assertIs(p._clarify("How many active employees?", again=True, choice="by status"),
                      first)
        self.assertIs(p._clarify("How many active employees?", again=True, choice="by login"),
                      second)
        # offered by both: the latest; offered by none: the latest, which says so
        self.assertIs(p._clarify("How many active employees?", again=True, choice="by date"),
                      second)
        self.assertIs(p._clarify("How many active employees?", again=True, choice="gone"),
                      second)
        self.assertEqual(len(agent.calls), 2)

    def test_the_kept_verdicts_are_bounded(self):
        agent = judge_of(CHOICE)
        p = pipe(judge="agent", agent=agent)
        for _ in range(pipeline.KEPT_PER_QUESTION + 3):
            p._clarify("q?")
        self.assertEqual(len(p._verdicts["q?"]), pipeline.KEPT_PER_QUESTION)
        for n in range(pipeline.KEPT_VERDICTS + 5):
            p._clarify(f"q{n}?")
        self.assertEqual(len(p._verdicts), pipeline.KEPT_VERDICTS)
        self.assertNotIn("q?", p._verdicts)

    def test_an_answer_is_remembered_only_with_its_joins_verified(self):
        # review of 26 October: without a graph the checks pass any join
        def remembering(graph=True):
            p = pipe()
            kept = []
            p._recall = SimpleNamespace(remember=lambda q, t, s: kept.append((q, t, s)) or "id-1")
            p._graph = SimpleNamespace(edges={("a", "b"): "a.x = b.y"} if graph else {})
            return p, kept

        def run(rows=([3],)):
            return pipeline.Run(question="q?", profile="Shop", rows=list(rows))
        with patch.dict("os.environ", {"DATAGORA_REMEMBER": "on"}):
            p, kept = remembering()
            answered = run()
            p._remember(answered, "q?", ["t"], "SELECT 1", "model")
            self.assertEqual((kept, answered.remembered), ([("q?", ["t"], "SELECT 1")], "id-1"))
            for p, kept, r, source in ((*remembering(graph=False), run(), "model"),
                                       (*remembering(), run(), "corpus"),
                                       (*remembering(), run(rows=()), "model")):
                p._remember(r, "q?", ["t"], "SELECT 1", source)
                self.assertEqual((kept, r.remembered), ([], ""), source)
            p, kept = remembering()
            p._here().remember = False
            p._remember(run(), "q?", ["t"], "SELECT 1", "model")
            self.assertEqual(kept, [])

    def test_an_error_is_never_kept(self):
        agent = judge_of(Outcome(action="ERROR", reason="timed out"))
        p = pipe(judge="agent", agent=agent)
        p._clarify("q?")
        p._clarify("q?", again=True)
        self.assertEqual(len(agent.calls), 2)

    def test_ask_stops_on_the_agents_choice(self):
        agent = judge_of(CHOICE)
        p = pipe(judge="agent", agent=agent)
        run = pipeline.Run(question="q?", profile="Shop")
        p._ask(run, "q?", None, trace=None)
        self.assertIs(run.clarification, CHOICE)
        self.assertEqual(agent.calls, ["q?"])
        self.assertEqual(run.steps[-1].detail, "CLARIFY: waiting for the user")


class JudgeCopyTests(unittest.TestCase):
    """Review of 26 October: the double had no schema view, so the copy made
    for each question and the verdict_agent property never ran."""

    def test_each_question_gets_its_own_judge_sharing_the_schema_view(self):
        base = judge_of(CHOICE, system="AGENT PROMPT")
        p = pipe(judge="agent", agent=base)
        p._clarify("How many active employees?")
        first = p.last_trace()
        p._clarify("Which products are cheap?")
        made = base.clar.judges[1:]                  # the first is the shared one
        self.assertEqual(len(made), 2)
        self.assertNotIn(base, made)
        self.assertIsNot(made[0], made[1])
        for copy in made:
            self.assertIs(copy.clar, base.clar)
            self.assertIs(copy._view, base._view)
            self.assertIs(copy._settings, base._settings)
            self.assertEqual(copy._system, "AGENT PROMPT")
        # the shared one judges nothing; each trace is its own question's
        self.assertIsNone(base.last_trace)
        self.assertEqual(first, made[0].last_trace)
        self.assertEqual(p.last_trace(), made[1].last_trace)
        self.assertEqual(p.last_trace()["question"], "Which products are cheap?")
        self.assertEqual(p._judged_tables(), ["tables of Which products are cheap?"])

    def test_two_questions_at_once_each_read_their_own_judge(self):
        import threading
        base = judge_of(CHOICE)
        base.clar.meet = threading.Barrier(2)
        p = pipe(judge="agent", agent=base)
        seen = {}

        def ask(question):
            p._clarify(question)
            seen[question] = (p.last_trace()["question"], p._judged_tables())
        threads = [threading.Thread(target=ask, args=(q,)) for q in ("first?", "second?")]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        self.assertEqual(seen, {"first?": ("first?", ["tables of first?"]),
                                "second?": ("second?", ["tables of second?"])})
        self.assertEqual(len({id(j) for j in base.clar.judges[1:]}), 2)

    def test_a_stand_in_without_a_schema_view_is_asked_itself(self):
        asked = []
        plain = SimpleNamespace(clarify=lambda q: asked.append(q) or CHOICE)
        p = pipe(judge="agent", agent=plain)
        self.assertIs(p._clarify("q?"), CHOICE)
        self.assertEqual(asked, ["q?"])

    def test_the_agent_is_built_once_over_the_pipeline_s_clarifier(self):
        import pathlib
        import tempfile
        import verdict_agent
        import verdict_tools
        views = []

        class View:
            def __init__(self, clar, profile_path=None):
                views.append((clar, profile_path))

        p = pipe(judge="agent")
        with tempfile.TemporaryDirectory() as d:
            profile = pathlib.Path(d) / "files" / "Shop.profile.json"
            profile.parent.mkdir()
            profile.write_text("{}", encoding="utf-8")
            with patch.object(verdict_tools, "SchemaView", View), \
                    patch.dict("os.environ", {"DATAGORA_DATA_DIR": d}):
                agent = p.verdict_agent
                self.assertIs(p.verdict_agent, agent)
                settings = pipeline.ask_settings()
        self.assertIsInstance(agent, verdict_agent.VerdictAgent)
        self.assertIs(agent.clar, p.clarifier)
        # the schema read once, with the database's column profile
        self.assertEqual(views, [(p.clarifier, str(profile))])
        self.assertIsInstance(agent._view, View)
        self.assertEqual(agent._settings, settings)
        self.assertEqual(agent._settings.max_turns, pipeline.ASK_AGENT["max_turns"])

    def test_the_real_agent_is_copied_for_each_question_and_its_trace_read(self):
        import verdict_agent
        made = []

        class Agent(verdict_agent.VerdictAgent):
            def __init__(self, *a, **kw):
                super().__init__(*a, **kw)
                made.append(self)

        class NoModel:
            # what the agent reads of a clarifier, and no model: the
            # question ends in an ERROR with its trace, and nothing is called
            columns, context, earlier = {}, "", ""

            @property
            def llm(self):
                raise RuntimeError("no model in a test")

        base = Agent(NoModel(), view=SimpleNamespace(), settings=pipeline.ask_settings({}))
        p = pipe(judge="agent", agent=base)
        out = p._clarify("How many active employees?")
        self.assertEqual(out.action, "ERROR")
        self.assertIn("no model in a test", out.reason)
        self.assertEqual(len(made), 2)
        copy = made[1]
        self.assertIs(copy.clar, base.clar)
        self.assertIs(copy._view, base._view)
        self.assertIs(copy._settings, base._settings)
        self.assertIsNone(base.last_trace)
        self.assertIs(p.last_trace(), copy.last_trace)
        self.assertEqual((p.last_trace()["mode"], p.last_trace()["stopped_by"]), ("agent", "error"))
        self.assertEqual(p._verdicts, {})           # an error is never kept


class ChoiceComesBackTests(unittest.TestCase):
    """Review of 23 October: a choice that comes back to readings that are
    no longer the same was answered with the first one."""

    def run_with(self, outcome, choice="by login"):
        p = pipe(judge="single", single=judge_of(outcome))
        p.clarifier.rewrite = lambda q, out, opt: f"REWRITTEN as {opt.label}"
        p.anchors = lambda q: ([], "")          # stop once the question is settled
        run = pipeline.Run(question="q?", profile="Shop")
        p._ask(run, "q?", choice, trace=None)
        return run

    def test_a_reading_no_longer_offered_is_never_answered_in_its_name(self):
        run = self.run_with(CHOICE, choice="by login")
        self.assertIs(run.clarification, CHOICE)
        self.assertEqual(run.technical_question, "")
        self.assertIn("no longer offered", run.steps[-1].detail)

    def test_an_error_on_the_way_back_fails_the_run(self):
        run = self.run_with(Outcome(action="ERROR", reason="timed out"))
        self.assertEqual(run.failed, "timed out")

    def test_the_reading_still_offered_is_answered(self):
        run = self.run_with(CHOICE, choice="by date")
        self.assertEqual(run.technical_question, "REWRITTEN as by date")


class AskSettingsTests(unittest.TestCase):

    def test_fewer_turns_a_shorter_limit_thinking_to_plan_and_conclude(self):
        s = pipeline.ask_settings({})
        self.assertEqual((s.max_turns, s.max_seconds, s.think), (5, 180.0, "plan_conclude"))

    def test_each_moved_by_its_variable_within_bounds(self):
        s = pipeline.ask_settings({"DATAGORA_ASK_AGENT_MAX_TURNS": "7",
                                   "DATAGORA_ASK_AGENT_MAX_SECONDS": "240",
                                   "DATAGORA_ASK_AGENT_THINK": "none"})
        self.assertEqual((s.max_turns, s.max_seconds, s.think), (7, 240.0, "none"))
        s = pipeline.ask_settings({"DATAGORA_ASK_AGENT_MAX_TURNS": "999",
                                   "DATAGORA_ASK_AGENT_MAX_SECONDS": "ten",
                                   "DATAGORA_ASK_AGENT_THINK": "sometimes"})
        self.assertEqual((s.max_turns, s.max_seconds, s.think), (5, 180.0, "plan_conclude"))

    def test_the_coverage_judges_other_settings_are_kept(self):
        s = pipeline.ask_settings({"DATAGORA_AGENT_CHOICE_TOLERANCE": "0.05"})
        self.assertEqual(s.choice_tolerance, 0.05)


class SettingsKeyTests(unittest.TestCase):

    def test_the_key_its_variable_and_its_values(self):
        self.assertEqual(settings_store.DEFAULTS["engine"]["ask_judge"], "")
        self.assertIn((("engine", "ask_judge"), "DATAGORA_ASK_JUDGE"), settings_store._ENV_MAP)
        settings_store._check_agent({"ask_judge": "agent"})
        with self.assertRaises(ValueError):
            settings_store._check_agent({"ask_judge": "both"})


class ClientTests(unittest.TestCase):

    def test_the_client_says_and_changes_the_judge(self):
        # in package mode, as an application imports it
        import pathlib
        import subprocess
        import sys
        code = "\n".join([
            "import os",
            "os.environ.pop('DATAGORA_ASK_JUDGE', None)",
            "from graph_lab import Datagora",
            "from graph_lab.pipeline import Pipeline",
            "d = Datagora.__new__(Datagora)",
            "d.pipeline = Pipeline.__new__(Pipeline)",
            "d.pipeline.judge = None",
            "assert d.judge == 'agent', d.judge",
            "d.judge = 'single'",
            "assert d.judge == 'single' and d.pipeline.judge == 'single'",
            "print('ok')"])
        src = pathlib.Path(__file__).resolve().parents[1]
        env = dict(os.environ, DATAGORA_TRACING="off", DATAGORA_DOTENV="off",
                   DATAGORA_COLUMN_INDEX="off")
        done = subprocess.run([sys.executable, "-c", code], cwd=src, env=env,
                              capture_output=True, text=True, timeout=120)
        self.assertEqual(done.returncode, 0, done.stderr[-800:])
        self.assertIn("ok", done.stdout)


class AnswerSentenceTests(unittest.TestCase):

    def test_markdown_escapes_are_dropped_from_the_answer(self):
        p = pipeline.Pipeline.__new__(pipeline.Pipeline)
        p.reasoner = SimpleNamespace(chat=lambda system, user:
                                     r"The first two are: product\_id=121 and *bold\* \[x\].")
        p._answer_prompt = SimpleNamespace(text="SYSTEM")
        said = p.say("q?", ["product_id"], [[121], [340]])
        self.assertEqual(said, "The first two are: product_id=121 and *bold* [x].")

    def test_a_count_that_failed_is_never_the_fetch_ceiling(self):
        # review of 26 October: total None was said as len(rows), "50 rows
        # match" for 446, and the server showed 50 as the count
        sent = []
        p = pipeline.Pipeline.__new__(pipeline.Pipeline)
        p.reasoner = SimpleNamespace(chat=lambda system, user: sent.append(user) or "Many.")
        p._answer_prompt = SimpleNamespace(text="SYSTEM")
        rows = [[i] for i in range(pipeline.MAX_ROWS)]
        p.say("q?", ["product_id"], rows, None)
        self.assertIn(f"At least {pipeline.MAX_ROWS} rows match (the total could not be counted)",
                      sent[-1])
        p.say("q?", ["product_id"], rows, 446)
        self.assertIn("446 rows match", sent[-1])
        # and the page is sent no count rather than the ceiling
        import pathlib
        import sys
        sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent / "ui"))
        import app
        run = pipeline.Run(question="q?", profile="p", answer="Many.", rows=rows, columns=["id"])
        run.total_rows = None
        self.assertIsNone(app._payload(run)["row_count"])
        run.total_rows = 446
        self.assertEqual(app._payload(run)["row_count"], 446)
        short = pipeline.Run(question="q?", profile="p", answer="Two.", rows=[[1], [2]], columns=["id"])
        self.assertEqual(app._payload(short)["row_count"], 2)

    def test_a_count_that_failed_reaches_the_answer_as_unknown(self):
        # review of 26 October (Ask 20): say() was tested alone, never handed
        # the count by the run that failed to make it
        said = []
        p = pipe(judge="single")
        p.clarifier.columns = {"t": [("name", "varchar")]}
        p.profile = SimpleNamespace(name="Shop", connect_mysql=lambda: SimpleNamespace(
            close=lambda: None))
        p.sql_llm = SimpleNamespace(model="sql", chat=lambda system, user: "SELECT name FROM t")
        p.reasoner = SimpleNamespace(model="reasoner")
        p._sql_prompt = p._answer_prompt = SimpleNamespace(text="SYSTEM", version=1, source="t")
        p.anchors = lambda q: (["t"], "model")
        p.subschema = lambda tables: list(tables)
        p.imposed_joins = lambda sub: []
        p.examples_for = lambda q: []
        p.check = lambda sql, con: (None, ["dialect"])
        rows = [[i] for i in range(pipeline.MAX_ROWS)]
        p.execute = lambda sql, con: (["name"], rows, None)
        p.say = lambda q, columns, got, total=None: said.append((len(got), total)) or "Many."
        p._remember = lambda *a: None
        run = pipeline.Run(question="q?", profile="Shop")
        p._ask(run, "q?", None, trace=None)
        self.assertEqual(said, [(pipeline.MAX_ROWS, None)])
        self.assertIsNone(run.total_rows)
        execute = next(s for s in run.steps if s.name == "execute")
        self.assertIn(f"at least {pipeline.MAX_ROWS} rows, the total could not be counted",
                      execute.detail)

    def test_the_count_past_the_ceiling_is_always_made(self):
        # review of 26 October: COUNT(*) around two columns named name failed
        # (1060), and the answer said "at least 50"
        class Cursor:
            def __init__(self, rowcount, db=None):
                self.rowcount, self.db, self.sent, self.got = rowcount, db, [], None

            def execute(self, sql):
                self.sent.append(sql)
                got = self.db(sql)
                if isinstance(got, Exception):
                    raise got
                self.got = got

            def fetchone(self):
                return self.got

        p = pipeline.Pipeline.__new__(pipeline.Pipeline)
        p.clarifier = SimpleNamespace(columns={"products": [("product_id", "int"), ("name", "varchar")],
                                               "categories": [("category_id", "int"), ("name", "varchar")]})
        sql = "SELECT p.name, c.name FROM products p JOIN categories c ON 1 = 1"
        # the driver read every row: its own count, and no second query
        cur = Cursor(446)
        self.assertEqual(p._count(cur, sql), 446)
        self.assertEqual(cur.sent, [])
        # a driver that does not say: the names apart count it
        cur = Cursor(-1, lambda s: (446,) if "AS _c1" in s
                     else RuntimeError("1060 Duplicate column name 'name'"))
        self.assertEqual(p._count(cur, sql), 446)
        self.assertEqual(len(cur.sent), 2)

    def test_review_of_the_fixes_what_a_clarifier_showed_is_its_thread_s(self):
        import threading
        import ambisql
        clar = ambisql.Clarifier.for_connection(lambda: None, "s")
        clar.last_shown = ["mine"]
        seen = []
        t = threading.Thread(target=lambda: (seen.append(clar.last_shown),
                                             setattr(clar, "last_shown", ["theirs"])))
        t.start()
        t.join()
        self.assertEqual((seen, clar.last_shown), ([None], ["mine"]))

    def test_review_of_the_fixes_a_sentence_of_context_stays_under_the_question_s(self):
        p = pipeline.Pipeline.__new__(pipeline.Pipeline)
        p.context = "Our fiscal year starts in April"
        got = p._context_of({"date": "2026-10-26"})
        self.assertEqual((got.get("about"), got.get("date")),
                         ("Our fiscal year starts in April", "2026-10-26"))

    def test_the_sql_prompt_asks_for_names_not_keys(self):
        import prompts
        self.assertIn("never a key alone", prompts.SQL_SYSTEM)
        self.assertEqual(prompts.VERSIONS["sql"]["version"], 2)


class RememberTests(unittest.TestCase):

    def test_a_test_instance_writes_nothing_into_the_corpus(self):
        self.assertTrue(pipeline.remembers({}))
        self.assertFalse(pipeline.remembers({"DATAGORA_REMEMBER": "off"}))
        self.assertTrue(pipeline.remembers({"DATAGORA_REMEMBER": "on"}))


class JudgeTraceTests(unittest.TestCase):

    def test_the_question_s_own_judge_is_read_and_said_as_a_step(self):
        # 23 October: Ask built one judge per question and the trace was
        # still read on the shared one, which judged nothing
        p = pipe(judge="agent", agent=judge_of(CHOICE))
        p._here().trace = {"stopped_by": "concluded", "seconds": 42.0,
                           # a tool, the side question on the readings and
                           # two turns: two turns (review of 26 October)
                           "turns": [{"kind": "turn", "tool": None},
                                     {"kind": "tool", "tool": "describe_tables"},
                                     {"kind": "wording", "tool": None},
                                     {"kind": "turn", "tool": None}],
                           "conclusion": {"verdict": "CHOICE", "reason": "two readings"},
                           "verifier": [{"check": "choice", "status": "compared"}],
                           "coercions": []}
        said = p.judge_said()
        self.assertIn("agent: concluded after 2 turns, 42.0 s; declared CHOICE", said)
        self.assertIn("tools: describe_tables", said)
        self.assertIn("checks: choice:compared", said)
        self.assertEqual(pipe(judge="single").judge_said(), "")


if __name__ == "__main__":
    unittest.main()
