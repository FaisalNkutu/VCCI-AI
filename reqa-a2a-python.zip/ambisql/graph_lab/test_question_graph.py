"""The schema as a graph, and what one judged question used of it.

question_graph.schema_graph on a clarifier whose catalogue, dictionary and
Neo4j edges are given (no database, no Neo4j); question_graph.highlight on
traces shaped like the agent's and the single judge's; the Neo4j Browser
link; and the app: the schema graph read once per database, the highlight
of each verdict in a saved run and in a run going on.

    .venv/Scripts/python src/graph_lab/test_question_graph.py
"""

import os

os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

import pathlib
import sys
import tempfile
import unittest
import urllib.parse
from unittest.mock import Mock, patch

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "ui"))

import dictionary  # noqa: E402
import question_graph as qg  # noqa: E402
from ambisql import Clarifier  # noqa: E402
from coverage import Ledger, Verdict, write_manifest  # noqa: E402

COLUMNS = {
    "departments": [("department_id", "int"), ("name", "varchar")],
    "employees": [("employee_id", "int"), ("department_id", "int"),
                  ("manager_id", "int"), ("status_code", "varchar"),
                  ("termination_date", "date")],
    "badges": [("badge_id", "int"), ("employee_id", "int")],
    "stock_counts": [("count_id", "int"), ("product_id", "int"), ("warehouse_id", "int")],
    "inventory": [("product_id", "int"), ("warehouse_id", "int"), ("on_hand", "int")],
    "attachments": [("attachment_id", "int"), ("object_type", "varchar"), ("object_id", "int")],
    "tickets": [("ticket_id", "int"), ("closed_at", "datetime")],
}
DECLARED = {
    ("employees", "department_id"): ("departments", "department_id"),
    ("employees", "manager_id"): ("employees", "employee_id"),
}


def meanings():
    found = dictionary.empty()
    found["primary"] = {"departments": ("department_id",), "employees": ("employee_id",),
                        "inventory": ("product_id", "warehouse_id")}
    # a badge belongs to at most one employee, an employee has zero or one
    # badge: written once, from the employee's side
    found["links"] = {("badges", "employee_id"): (
        "employees", "employee_id",
        {"role": "parent_of", "cardinality": "Zero Or One", "name": "employee_badge"})}
    found["polymorphic"] = {("attachments", "object_id"): [(
        "tickets", "ticket_id",
        {"role": "child_of", "cardinality": "Zero or One",
         "when": {"column": "object_type", "value": "TICKET"}})]}
    return found


def clarifier():
    def refused():
        raise ConnectionError("no database in a test")

    clar = Clarifier.for_connection(refused, "theirs", llm=lambda system, user: {})
    clar._columns = COLUMNS
    clar._views = {}
    clar._keys = {(t, c) for t, cols in COLUMNS.items() for c, _d in cols if c.endswith("_id")}
    clar._foreign_keys = dict(DECLARED)
    clar._samples = {}
    clar._meanings = meanings()
    # the graph repeats a declared key, holds a composite join of its own and
    # the polymorphic link with its condition
    clar._graph_edges = [
        ("employees", "department_id", "departments", "department_id"),
        ("stock_counts", "product_id,warehouse_id", "inventory", "product_id,warehouse_id"),
        ("attachments", "object_id", "tickets", "ticket_id", "attachments.object_type = 'TICKET'"),
    ]
    clar._index_checked = clar._corpus_checked = clar._reranker_checked = True
    return clar


class SchemaGraphTests(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.graph = qg.schema_graph(clarifier())
        cls.links = {(x["source"], x["target"], x["condition"]): x for x in cls.graph["links"]}

    def test_every_table_with_its_columns_and_keys(self):
        tables = {t["name"]: t["columns"] for t in self.graph["tables"]}
        self.assertEqual(sorted(tables), sorted(COLUMNS))
        employees = {c["name"]: c for c in tables["employees"]}
        self.assertEqual(employees["employee_id"], {"name": "employee_id", "type": "int",
                                                    "pk": True, "fk": None})
        self.assertEqual(employees["department_id"]["fk"], "departments.department_id")
        self.assertFalse(employees["department_id"]["pk"])
        inventory = {c["name"]: c for c in tables["inventory"]}
        self.assertTrue(inventory["product_id"]["pk"] and inventory["warehouse_id"]["pk"])

    def test_a_foreign_key_is_many_to_one_and_read_once(self):
        link = self.links[("employees", "departments", "")]
        self.assertEqual((link["source_card"], link["target_card"], link["kind"]), ("*", "1", "fk"))
        self.assertEqual(link["via"], "employees.department_id = departments.department_id")
        self.assertEqual(sum(1 for x in self.graph["links"]
                             if (x["source"], x["target"]) == ("employees", "departments")), 1)

    def test_a_self_reference_is_kept(self):
        link = self.links[("employees", "employees", "")]
        self.assertEqual(link["via"], "employees.manager_id = employees.employee_id")

    def test_the_dictionary_cardinality_gives_the_multiplicity(self):
        badge = self.links[("badges", "employees", "")]
        self.assertEqual((badge["source_card"], badge["target_card"], badge["kind"]),
                         ("0..1", "1", "kb"))

    def test_a_polymorphic_link_keeps_its_condition_once(self):
        found = [x for x in self.graph["links"] if x["source"] == "attachments"]
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0]["condition"], "attachments.object_type = 'TICKET'")
        self.assertEqual((found[0]["source_card"], found[0]["target_card"]), ("*", "0..1"))

    def test_a_composite_join_is_one_link(self):
        link = self.links[("stock_counts", "inventory", "")]
        self.assertEqual(link["via"], "stock_counts.product_id = inventory.product_id"
                                      " AND stock_counts.warehouse_id = inventory.warehouse_id")

    def test_multiplicity_spellings(self):
        self.assertEqual([qg.multiplicity(x) for x in
                          ("Exactly One", "Zero Or More", "zero_or_one", "One or More", "lots")],
                         ["1", "*", "0..1", "1..*", ""])


AGENT = {
    "mode": "agent", "verdict": "NEEDS A CHOICE", "index": 2,
    "question": "How many active employees work in each department?",
    "choices": ["employees.status_code", "employees.termination_date"],
    "turns": [{"tool": "describe_tables", "args": {"names": ["employees", "departments"]}}],
    "conclusion": {
        "tables": ["employees", "departments"],
        "columns": [{"table": "employees", "column": "status_code", "role": "filter"},
                    {"table": "departments", "column": "name", "role": "group"}],
        "joins": ["employees.department_id = departments.department_id", "work_orders.wo (self)"],
        "issues": [{"type": "choice", "readings": [
            {"label": "by status code", "means": "status_code = 'ACTIVE'",
             "table": "employees", "column": "status_code",
             "sql": "SELECT d.name, count(*) FROM departments d JOIN employees e "
                    "ON d.department_id = e.department_id WHERE e.status_code = 'ACTIVE' GROUP BY d.name"},
            {"label": "by termination date", "means": "no termination date",
             "table": "employees", "column": "termination_date",
             "sql": "SELECT count(*) FROM employees WHERE termination_date IS NULL"},
        ]}]},
}

SINGLE = {
    "mode": "single", "verdict": "ANSWERABLE", "index": 0,
    "question": "How many active employees work in each department?",
    "reply": {"reason": "Filter employees.status_code for 'ACTIVE' and group by "
                        "departments.name; COUNT(x.y) is a function, 3.5 a number.",
              "ambiguous": False, "candidates": []},
    "tables_shown": ["employees", "departments", "absences"],
    "action": "ANSWER",
}

SINGLE_CHOICE = {
    "mode": "single", "verdict": "NEEDS A CHOICE", "index": 1,
    "question": "Top products by quantity ordered",
    "choices": ["sales_order_lines.quantity", "purchase_order_lines.quantity"],
    "reply": {"reason": "quantity ordered is ambiguous", "candidates": [
        {"table": "sales_order_lines", "column": "quantity", "means": "customer orders"},
        {"table": "purchase_order_lines", "column": "quantity", "means": "supplier orders",
         "via": "purchase_order_lines.po_id = purchase_orders.po_id"}]},
    "tables_shown": ["sales_order_lines", "purchase_order_lines"],
}


class HighlightTests(unittest.TestCase):

    def test_the_agent_conclusion_and_its_readings(self):
        found = qg.highlight(AGENT)
        self.assertEqual(found["tables"], ["employees", "departments"])
        self.assertEqual(found["columns"], ["employees.status_code", "departments.name",
                                            "employees.department_id", "departments.department_id"])
        first, second = found["readings"]
        self.assertEqual((first["label"], first["means"]), ("by status code", "status_code = 'ACTIVE'"))
        self.assertEqual(first["tables"], ["employees", "departments"])
        self.assertEqual(first["columns"], ["employees.status_code", "departments.department_id",
                                            "employees.department_id"])
        self.assertEqual((second["tables"], second["columns"]),
                         (["employees"], ["employees.termination_date"]))

    def test_the_single_judge_names_tables_in_its_reason(self):
        found = qg.highlight(SINGLE)
        self.assertEqual(found, {"tables": ["employees", "departments"],
                                 "columns": ["employees.status_code", "departments.name"],
                                 "readings": []})

    def test_a_single_choice_reads_each_candidate(self):
        found = qg.highlight(SINGLE_CHOICE)
        self.assertEqual(found["tables"], [])
        self.assertEqual([(r["label"], r["tables"], r["columns"]) for r in found["readings"]], [
            ("sales_order_lines.quantity", ["sales_order_lines"], ["sales_order_lines.quantity"]),
            ("purchase_order_lines.quantity", ["purchase_order_lines", "purchase_orders"],
             ["purchase_order_lines.quantity", "purchase_order_lines.po_id",
              "purchase_orders.po_id"])])

    def test_a_choice_whose_trace_kept_only_labels(self):
        trace = dict(SINGLE_CHOICE, reply={"reason": ""})
        found = qg.highlight(trace)
        self.assertEqual([r["tables"] for r in found["readings"]],
                         [["sales_order_lines"], ["purchase_order_lines"]])

    def test_other_verdicts_and_empty_traces_draw_nothing(self):
        for verdict in ("NOT COVERED", "NO DATA", "UNKNOWN"):
            self.assertIsNone(qg.highlight(dict(AGENT, verdict=verdict)), verdict)
        self.assertIsNone(qg.highlight(None))
        self.assertIsNone(qg.highlight({"mode": "single", "reply": None, "tables_shown": None},
                                       "ANSWERABLE"))

    def test_a_verdict_in_flight_passes_its_verdict(self):
        trace = {k: v for k, v in AGENT.items() if k not in ("verdict", "choices")}
        self.assertIsNone(qg.highlight(trace))
        self.assertEqual(qg.highlight(trace, "NEEDS MORE", [])["tables"], ["employees", "departments"])

    def test_the_trace_line_of_a_row(self):
        lines = [{"index": 0, "question": "a", "verdict": "UNKNOWN"},
                 {"index": 1, "question": "b", "verdict": "ANSWERABLE"},
                 {"index": 0, "question": "a", "verdict": "ANSWERABLE"},
                 {"index": 3, "question": "a  ", "verdict": "NO DATA"}]
        # the retry wins over the UNKNOWN it replaced
        self.assertEqual(qg.trace_of(lines, 0, "a"), lines[2])
        # a row whose place moved is found by its text
        self.assertEqual(qg.trace_of(lines, 7, "b"), lines[1])
        self.assertIsNone(qg.trace_of(lines, 1, "c"))


class Neo4jLinkTests(unittest.TestCase):

    def test_the_query_is_encoded_in_the_address(self):
        url = qg.neo4j_url("http://localhost:7474/browser/", "datagora_ent",
                           ["employees", "o'brien", "employees"])
        base, _, arg = url.partition("?cmd=edit&arg=")
        self.assertEqual(base, "http://localhost:7474/browser/")
        self.assertNotIn(" ", arg)
        self.assertEqual(urllib.parse.unquote(arg),
                         "MATCH (t:Table) WHERE t.db = 'datagora_ent' AND t.name IN "
                         "['employees', 'o\\'brien']\n"
                         "OPTIONAL MATCH (t)-[r:JOINS_ON]-(n:Table {db: 'datagora_ent'})\n"
                         "RETURN t, r, n")

    def test_without_a_graph_name_the_tables_are_matched_by_name(self):
        url = qg.neo4j_url("http://neo/browser/?dbms=x", "*", ["books"])
        self.assertTrue(url.startswith("http://neo/browser/?dbms=x&cmd=edit&arg="))
        self.assertNotIn("t.db", urllib.parse.unquote(url))

    def test_no_server_nor_user_in_the_address(self):
        # a connection named in the address is a transient one, asked for a
        # login on every click: the page reuses one logged-in tab instead
        url = qg.neo4j_url("http://localhost:7474/browser/", "datagora_ent", ["employees"])
        self.assertNotIn("dbms=", url)
        self.assertNotIn("connectURL=", url)
        self.assertIn("?cmd=edit&arg=", url)

    def test_the_query_the_page_copies(self):
        query = qg.neo4j_query("datagora_ent", ["employees", "departments"])
        self.assertIn("t.name IN ['employees', 'departments']", query)
        self.assertIsNone(qg.neo4j_query("db", []))

    def test_the_address_is_configured_or_switched_off(self):
        self.assertEqual(qg.browser_base({}), "http://localhost:7474/browser/")
        self.assertEqual(qg.browser_base({"DATAGORA_NEO4J_BROWSER_URL": "http://n:7474/browser/"}),
                         "http://n:7474/browser/")
        self.assertIsNone(qg.browser_base({"DATAGORA_NEO4J_BROWSER_URL": "OFF"}))
        self.assertIsNone(qg.neo4j_url(None, "db", ["books"]))
        self.assertIsNone(qg.neo4j_url("http://n/", "db", []))


class _App(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        env = patch.dict("os.environ", {"DATAGORA_COVERAGE_DIR": self.tmp.name,
                                        "DATAGORA_DATA_DIR": self.tmp.name})
        env.start()
        self.addCleanup(env.stop)
        import app
        from fastapi.testclient import TestClient
        self.app = app
        self.client = TestClient(app.app)
        app._schema_graphs.clear()
        self.addCleanup(app._schema_graphs.clear)


class SchemaGraphEndpointTests(_App):

    def test_read_once_per_database_until_the_settings_change(self):
        reads = []

        def read(profile):
            reads.append(profile.name)
            return {"tables": [{"name": "books", "columns": []}], "links": []}

        profile = Mock()
        profile.name = "Library"
        with patch.object(self.app, "read_schema_graph", side_effect=read), \
                patch.object(self.app.DbProfile, "load", return_value=profile):
            first = self.client.get("/api/coverage/schema-graph", params={"profile": "Library"})
            again = self.client.get("/api/coverage/schema-graph", params={"profile": "Library"})
            self.assertEqual(reads, ["Library"])
            self.app._settings_changed()
            self.client.get("/api/coverage/schema-graph", params={"profile": "Library"})
        self.assertEqual(first.status_code, 200)
        self.assertEqual(first.json(), again.json())
        self.assertEqual(first.json()["profile"], "Library")
        self.assertEqual(reads, ["Library", "Library"])

    def test_the_page_scripts_are_served(self):
        for script, name in (("/schema_graph.js", "showGraph"), ("/accuracy.js", "realVerdict")):
            r = self.client.get(script)
            self.assertEqual(r.status_code, 200, script)
            self.assertIn(name, r.text)
            self.assertTrue(r.headers["content-type"].startswith("text/javascript"))

    def test_an_unknown_or_unreadable_database_is_said(self):
        with patch.object(self.app.DbProfile, "load", side_effect=SystemExit("unknown database 'x'")):
            r = self.client.get("/api/coverage/schema-graph", params={"profile": "x"})
        self.assertEqual(r.status_code, 404)
        with patch.object(self.app.DbProfile, "load", return_value=Mock()), \
                patch.object(self.app, "read_schema_graph", side_effect=ConnectionError("refused")):
            r = self.client.get("/api/coverage/schema-graph", params={"profile": "y"})
        self.assertEqual(r.status_code, 503)
        self.assertIn("ConnectionError: refused", r.json()["detail"])
        self.assertEqual(self.app._schema_graphs, {})


class RunHighlightTests(_App):
    """A saved run says what each question used, from its trace."""

    def write_run(self):
        path = pathlib.Path(self.tmp.name) / "ent.csv"
        ledger = Ledger(path, ["id"])
        rows = [("E01", SINGLE), ("E02", SINGLE_CHOICE), ("E03", AGENT),
                ("E04", dict(AGENT, verdict="NOT COVERED"))]
        for n, (qid, trace) in enumerate(rows):
            # the question text is the row's own, so each row has its line
            ledger.add(Verdict(question=f"{trace['question']} {qid}", verdict=trace["verdict"],
                               choices=trace.get("choices") or [], extra={"id": qid},
                               trace={k: v for k, v in trace.items()
                                      if k not in ("verdict", "choices", "index", "question")}),
                       index=n)
        ledger.close()
        write_manifest(path, "job", None, len(rows), profile="Enterprise")
        return path

    def test_each_verdict_carries_its_highlight(self):
        self.write_run()
        with patch.object(self.app, "graph_key_of", return_value="datagora_ent"):
            verdicts = self.client.get("/api/coverage/run/ent").json()["verdicts"]
        single, choice, agent, missing = (v["highlight"] for v in verdicts)
        self.assertEqual(single["tables"], ["employees", "departments"])
        self.assertEqual(len(choice["readings"]), 2)
        self.assertEqual(agent["readings"][0]["label"], "by status code")
        self.assertIsNone(missing)
        query = urllib.parse.unquote(agent["neo4j_url"].partition("&arg=")[2])
        self.assertEqual(query, agent["neo4j_query"])
        self.assertIn("t.db = 'datagora_ent' AND t.name IN ['employees', 'departments']", query)

    def test_the_link_is_switched_off(self):
        self.write_run()
        with patch.dict("os.environ", {"DATAGORA_NEO4J_BROWSER_URL": "off"}):
            verdicts = self.client.get("/api/coverage/run/ent").json()["verdicts"]
        self.assertIsNone(verdicts[0]["highlight"]["neo4j_url"])
        self.assertEqual(verdicts[0]["highlight"]["tables"], ["employees", "departments"])

    def test_a_run_without_a_trace_has_no_highlight(self):
        path = self.write_run()
        (pathlib.Path(str(path) + ".trace.jsonl")).unlink()
        verdicts = self.client.get("/api/coverage/run/ent").json()["verdicts"]
        self.assertEqual([v["highlight"] for v in verdicts], [None] * 4)


class LiveHighlightTests(_App):
    """A verdict streamed as it is decided says what it used, from the
    clarifier's trace, before any file is read."""

    def test_the_verdict_event_carries_the_highlight(self):
        import coverage
        self.addCleanup(self.app._RUNS.clear)
        started = []

        def thread(target=None, **_kw):
            started.append(target)
            return Mock()

        def assess(questions, *, on_each=None, **_kw):
            trace = {k: v for k, v in AGENT.items() if k not in ("verdict", "choices")}
            on_each(Verdict(question=questions[0]["question"], verdict="NEEDS A CHOICE",
                            choices=AGENT["choices"], trace=trace, position=0))

        profile = Mock(graph_key="datagora_ent")
        with patch.object(self.app.threading, "Thread", side_effect=thread), \
                patch.object(self.app.threading, "Timer"), \
                patch.object(self.app.DbProfile, "load", return_value=profile), \
                patch.object(coverage, "assess", side_effect=assess):
            self.app.coverage(self.app.Coverage(profile="Enterprise", csv="question\nactive staff\n"))
            started[0]()
        live = next(iter(self.app._RUNS.values()))
        event = next(e for e in live.events if e["type"] == "verdict")
        self.assertEqual(event["highlight"]["tables"], ["employees", "departments"])
        self.assertIn("datagora_ent", urllib.parse.unquote(event["highlight"]["neo4j_url"]))


class FallbackTests(unittest.TestCase):
    """A question whose trace names no table: what the judge's words, its
    options or the question name, said to be guessed."""

    @classmethod
    def setUpClass(cls):
        cls.graph = qg.schema_graph(clarifier())

    def test_the_tables_the_judge_names_in_its_reason(self):
        got = qg.fallback(self.graph, "q?", "The employees table holds status_code and "
                          "its department.", verdict="ANSWERABLE")
        self.assertEqual(got["guessed"], "reason")
        self.assertEqual(got["tables"], ["employees"])
        self.assertIn("employees.status_code", got["columns"])

    def test_the_options_of_a_choice(self):
        got = qg.fallback(self.graph, "q?", "Which do you mean?",
                          ["employees.status_code", "employees.termination_date"],
                          "NEEDS A CHOICE")
        self.assertEqual(got["guessed"], "choice")
        self.assertEqual([r["columns"] for r in got["readings"]],
                         [["employees.status_code"], ["employees.termination_date"]])

    def test_else_the_tables_the_question_names_in_full_first(self):
        got = qg.fallback(self.graph, "How many employees work in each department?",
                          "Yes, this can be answered as asked.", verdict="ANSWERABLE")
        self.assertEqual(got["guessed"], "question")
        self.assertEqual(sorted(got["tables"]), ["departments", "employees"])
        self.assertIn("employees.department_id", got["columns"])
        got = qg.fallback(self.graph, "Which stock was counted last?", "", verdict="NEEDS MORE")
        self.assertEqual(got["tables"], ["stock_counts"])

    def test_nothing_to_show_or_nothing_found(self):
        self.assertIsNone(qg.fallback(self.graph, "How many employees?", "",
                                      verdict="NOT COVERED"))
        self.assertIsNone(qg.fallback(self.graph, "What is the weather like?", "",
                                      verdict="ANSWERABLE"))
        self.assertIsNone(qg.fallback(None, "How many employees?", "", verdict="ANSWERABLE"))


class OldRunTests(_App):
    """A run saved before traces: a guessed graph and its real verdicts."""

    def test_a_run_without_a_trace_is_drawn_from_what_it_says(self):
        path = RunHighlightTests.write_run(self)
        pathlib.Path(str(path) + ".trace.jsonl").unlink()
        graph = qg.schema_graph(clarifier())
        with patch.object(self.app, "schema_graph_or_none", return_value=graph):
            verdicts = self.client.get("/api/coverage/run/ent").json()["verdicts"]
        single, choice, agent, refused = (v["highlight"] for v in verdicts)
        # without its trace the judge's reason is gone: the question's words
        self.assertEqual(single["guessed"], "question")
        self.assertIn("employees", single["tables"])
        self.assertIn(agent["guessed"], ("reason", "choice", "question"))
        # options on tables this schema does not hold, a question naming none
        self.assertIsNone(choice)
        self.assertIsNone(refused)                         # NOT COVERED draws nothing

    def test_the_real_verdict_is_found_for_a_run_without_one(self):
        path = pathlib.Path(self.tmp.name) / "wh.csv"
        ledger = Ledger(path, ["id"])
        ledger.add(Verdict(question="How many products are there in each category?",
                           verdict="ANSWERABLE", extra={"id": "Q01"}), index=0)
        ledger.add(Verdict(question="A question no file labels", verdict="NEEDS MORE",
                           extra={"id": "Q99"}), index=1)
        ledger.close()
        write_manifest(path, "job", None, 2, profile="Warehouse")
        verdicts = self.client.get("/api/coverage/run/wh").json()["verdicts"]
        self.assertEqual(verdicts[0]["extra"]["real_verdict"], "ANSWERABLE")
        self.assertEqual(verdicts[0]["extra"]["real_from"], "questions_products.csv")
        self.assertNotIn("real_verdict", verdicts[1]["extra"])
        # and the History page's numbers say how many are right
        summary = self.client.get("/api/coverage/summary/wh").json()
        self.assertEqual((summary["accuracy"]["right"], summary["accuracy"]["scored"],
                          summary["accuracy"]["unlabelled"]), (1, 1, 1))


if __name__ == "__main__":
    unittest.main()
