"""Are the answers right, not just well formed?

Every other test here asks whether the machinery behaves: the gates
reject, the levels are reached, the schema is portable. None of them
asks the only question a user has, which is whether the number that
comes back is the number the database holds.

So each case carries a reference query, written by hand against the
schema, and the pipeline's result is compared to what that query
returns. The comparison is on VALUES, not on SQL text: a question has
many correct formulations and exactly one correct answer.

    keys      the reference returns one column of key values. The run
              must produce the same set of them, and the same number of
              rows. Column names and order are the model's business.
    scalar    the reference returns one number. The run must produce it.
    count     only the number of rows has to match, for questions whose
              payload is a list nobody can predict the shape of.

A case can also expect no query at all: `outcome="CLARIFY"` or
`"GUIDE"`. Getting an answer where the data cannot support one is a
failure even when the answer looks fine.

    python test_answers.py                     both databases
    python test_answers.py --profile datagora_lib
    python test_answers.py --only "top 5"      one case, while iterating
"""

import os

# the column index is on by default; a test never builds one in a real
# Qdrant, and the tests that need one give it directly
os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")

import argparse
import sys
import time

from db_profile import DbProfile
from llm import LLM
from pipeline import MAX_ROWS, Pipeline

# (question, choice, check, reference sql or expected outcome)
CASES = {
    "datagora_lib": [
        ("how many books are in the catalogue", None, "scalar",
         "SELECT COUNT(*) FROM books"),
        ("how many books per genre", None, "keys",
         "SELECT g.name FROM genres g JOIN books b ON b.genre_id = g.genre_id "
         "GROUP BY g.name"),
        ("number of loans per member", None, "count",
         "SELECT m.member_id FROM members m JOIN loans l "
         "ON l.member_id = m.member_id GROUP BY m.member_id"),
        ("the longest book", None, "keys",
         "SELECT title FROM books ORDER BY pages DESC LIMIT 1"),
        ("books that have never been borrowed", None, "keys",
         "SELECT b.title FROM books b WHERE NOT EXISTS "
         "(SELECT 1 FROM loans l WHERE l.book_id = b.book_id)"),
        ("books that have more than one author", None, "count",
         "SELECT book_id FROM book_authors GROUP BY book_id HAVING COUNT(*) > 1"),
        ("list the members and their email addresses", None, "count",
         "SELECT member_id FROM members"),
        ("genres with no book at all", None, "keys",
         "SELECT g.name FROM genres g WHERE NOT EXISTS "
         "(SELECT 1 FROM books b WHERE b.genre_id = g.genre_id)"),
        ("members who never borrowed anything", None, "keys",
         "SELECT m.full_name FROM members m WHERE NOT EXISTS "
         "(SELECT 1 FROM loans l WHERE l.member_id = m.member_id)"),
        # the traps: the reference is the correct reading, and the whole
        # point is that a wrong join gives a larger, plausible number
        ("total pages of the books that have at least one author", None,
         "scalar",
         "SELECT SUM(b.pages) FROM books b WHERE EXISTS "
         "(SELECT 1 FROM book_authors ba WHERE ba.book_id = b.book_id)"),
        ("which members live in Paris", None, "GUIDE", None),
        ("members taller than average", None, "GUIDE", None),
        ("how many loans are still open", None, "CLARIFY", None),
    ],
    "datagora_generic": [
        ("how many products are there in each category", "1", "count",
         "SELECT c.category_id FROM categories c JOIN products p "
         "ON p.category_id = c.category_id GROUP BY c.category_id"),
        ("list the warehouses and their cities", None, "count",
         "SELECT warehouse_id FROM warehouses"),
        ("the top 5 warehouses by capacity", None, "keys",
         "SELECT name FROM warehouses ORDER BY capacity_units DESC LIMIT 5"),
        ("how many suppliers are there", None, "scalar",
         "SELECT COUNT(*) FROM suppliers"),
        ("products whose quantity is below their reorder level", None, "count",
         "SELECT product_id FROM inventory "
         "WHERE quantity_on_hand < reorder_level"),
        ("products supplied by more than three suppliers", None, "count",
         "SELECT product_id FROM product_suppliers GROUP BY product_id "
         "HAVING COUNT(*) > 3"),
        ("warehouses that store nothing", None, "keys",
         "SELECT w.name FROM warehouses w WHERE NOT EXISTS "
         "(SELECT 1 FROM inventory i WHERE i.warehouse_id = w.warehouse_id)"),
        # the fan trap: capacity belongs to the warehouse, not to the
        # stock line, so a join to inventory before summing inflates it
        # per city, so grouped. The fan trap is that joining inventory
        # before summing repeats a warehouse once per stock line: the
        # totals below are the ones a correct query must reproduce.
        ("total storage capacity per city", None, "keys",
         "SELECT CONCAT(w.city, ' ', SUM(w.capacity_units)) FROM warehouses w "
         "GROUP BY w.city"),
        ("total stock of the products that have at least one supplier", None,
         "scalar",
         "SELECT SUM(i.quantity_on_hand) FROM inventory i WHERE EXISTS "
         "(SELECT 1 FROM product_suppliers ps "
         "  WHERE ps.product_id = i.product_id)"),
        ("products cheaper than a coffee", None, "GUIDE", None),
        ("which supplier is the most reliable", None, "CLARIFY", None),
    ],
}


def reference(profile, sql):
    con = profile.connect_mysql()
    try:
        cur = con.cursor()
        cur.execute(sql)
        return [list(r) for r in cur.fetchall()]
    finally:
        con.close()


def flat(rows):
    """Every cell of a result, as comparable text. Column choice and
    column order are the model's business; the values are not."""
    out = set()
    for row in rows:
        for v in row:
            if v is None:
                continue
            if isinstance(v, float) and v == int(v):
                v = int(v)
            out.add(str(v).strip())
    return out


def judge(case, run):
    """(ok, detail). Everything here is a comparison against the
    reference, never against how the query was written."""
    _question, _choice, check, _ref_sql = case
    c = run.clarification
    action = getattr(c, "action", "") if c else ""

    if check in ("CLARIFY", "GUIDE"):
        if action == check:
            return True, f"{check} as expected"
        return False, (f"expected {check}, got "
                       + (action or (f"an answer over {len(run.rows)} rows")
                          if run.answer else (run.failed or "nothing"))[:70])

    if run.failed:
        return False, "failed: " + " ".join(run.failed.split())[:70]
    if action in ("CLARIFY", "GUIDE") and not run.answer:
        return False, f"asked instead of answering ({action})"
    return None, ""                      # the caller compares to reference


def compare(check, got_rows, want_rows, ceiling=None):
    """The run is capped at MAX_ROWS, so a reference returning more than
    that cannot be matched row for row. Above the cap the test flips to
    the question that still means something: is every value returned one
    the reference also holds, and did the run stop at the cap rather than
    somewhere arbitrary. That still catches an invented row and a wrong
    filter; it cannot catch a missing row, and says so."""
    if ceiling and len(want_rows) > ceiling:
        want, got = flat(want_rows), flat(got_rows)
        invented = got - want
        if check != "count" and invented:
            return False, (f"{len(invented)} value(s) not in the reference, "
                           f"e.g. {sorted(invented)[:2]}")
        if len(got_rows) != ceiling:
            return False, (f"reference has {len(want_rows)} rows, the cap is "
                           f"{ceiling}, the run returned {len(got_rows)}")
        return True, f"capped at {ceiling}, no invented value"
    return _compare(check, got_rows, want_rows)


def _compare(check, got_rows, want_rows):
    if check == "scalar":
        want = flat(want_rows)
        got = flat(got_rows)
        if not want:
            return False, "the reference returned nothing"
        missing = want - got
        if missing:
            return False, (f"expected {sorted(want)[:3]}, "
                           f"got {sorted(got)[:5]}")
        return True, f"value {min(want)} present"
    if check == "count":
        if len(got_rows) == len(want_rows):
            return True, f"{len(got_rows)} rows"
        return False, f"expected {len(want_rows)} rows, got {len(got_rows)}"
    # keys
    want = flat(want_rows)
    got = flat(got_rows)
    missing = want - got
    if missing:
        return False, (f"{len(missing)} of {len(want)} key values absent, "
                       f"e.g. {sorted(missing)[:2]}")
    if len(got_rows) != len(want_rows):
        return False, (f"all key values present but {len(got_rows)} rows "
                       f"against {len(want_rows)}")
    return True, f"{len(want)} key values, {len(got_rows)} rows"


def main():
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--profile", default=None)
    ap.add_argument("--only", default=None, help="substring of a question")
    ap.add_argument("--endpoint", default=None)
    args = ap.parse_args()

    llm = LLM.load(args.endpoint) if args.endpoint else LLM.role("reasoner")
    print(f"\n  reasoner: {llm.name} -> {llm.model}")
    if not llm.reachable():
        raise SystemExit(f"  {llm.url} is unreachable.")

    names = [args.profile] if args.profile else list(CASES)
    passed = failed = 0
    failures = []
    for name in names:
        profile = DbProfile.load(name)
        pipe = Pipeline(profile,
                        reasoner=LLM.load(args.endpoint) if args.endpoint
                        else None,
                        sql_llm=LLM.load(args.endpoint) if args.endpoint
                        else None)
        print(f"\n  == {name} " + "=" * (56 - len(name)))
        try:
            for case in CASES[name]:
                question, choice, check, ref_sql = case
                if args.only and args.only.lower() not in question.lower():
                    continue
                t0 = time.time()
                try:
                    run = pipe.ask(question, choice)
                except Exception as e:
                    ok, detail = False, f"{type(e).__name__}: {e}"[:70]
                else:
                    ok, detail = judge(case, run)
                    if ok is None:
                        ok, detail = compare(
                            check, run.rows,
                            reference(profile, ref_sql),
                            ceiling=MAX_ROWS)
                secs = time.time() - t0
                passed += bool(ok)
                failed += not ok
                if not ok:
                    failures.append((name, question, detail))
                print(f"    {'ok  ' if ok else 'FAIL'} {question[:44]:44} "
                      f"{detail[:44]:44} {secs:4.0f}s")
        finally:
            pipe.close()

    print("\n  " + "=" * 62)
    print(f"  {passed} correct, {failed} wrong, {passed + failed} cases")
    if failures:
        print("\n  what went wrong:")
        for name, question, detail in failures:
            print(f"    {name:18} {question[:40]:40} {detail}")
    print()
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
