"""The words a question uses to compute or to connect, generated rather than
listed: every inflection of an operation, numbers in every form, the closed
classes whole, and the words that are also data kept out."""

import os

os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

import pathlib
import sys
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))

import wording  # noqa: E402
from ambisql import Clarifier  # noqa: E402


class WordingTests(unittest.TestCase):
    def setUp(self):
        self.clar = Clarifier(connect=lambda: None, schema="x")
        self.clar._vocabulary = {k: set() for k in Clarifier.VOCABULARIES}
        self.ops = self.clar.operation_words()

    def words(self, sentence):
        return self.clar._content_words(sentence) - self.ops

    def test_every_inflection_of_an_operation(self):
        for word in ("counted", "counting", "totals", "totalled", "totaling",
                     "summed", "averaged", "averaging", "aggregated", "tallied"):
            self.assertIn(self.clar._singular(word), self.ops, word)

    def test_numbers_in_every_form(self):
        self.assertEqual(self.words("more than twenty-five suppliers"), {"supplier"})
        self.assertEqual(self.words("the third and the hundredth order"), {"order"})
        self.assertEqual(self.words("hundreds of dozens of items"), {"item"})

    def test_what_is_left_is_what_the_schema_must_hold(self):
        self.assertEqual(self.words("How many products are there in each category?"),
                         {"product", "category"})
        # "time" is also data, and here it is: the lead time
        self.assertEqual(self.words("What is the average lead time in days per supplier?"),
                         {"lead", "time", "day", "supplier"})
        self.assertEqual(self.words("Please provide the warehouses that can be "
                                    "linked to suppliers, rounded to two decimals"),
                         {"warehouse", "supplier"})

    def test_a_word_that_is_also_data_is_still_looked_for(self):
        for word in ("rate", "rank", "order", "share", "score", "return", "round",
                     "amount", "weight", "name"):
            self.assertNotIn(word, self.ops, word)

    def test_a_trade_s_own_word_is_taken_even_an_ambiguous_one(self):
        self.clar._vocabulary = {k: set() for k in Clarifier.VOCABULARIES}
        self.clar._vocabulary["calculations"] = {"turnover", "rate"}
        ops = self.clar.operation_words()
        self.assertIn("turnover", ops)
        self.assertIn(self.clar._singular("turnovers"), ops)
        self.assertIn("rate", ops)

    def test_the_closed_classes_hold_no_noun_a_schema_would_name(self):
        nouns = {"product", "supplier", "customer", "order", "date", "price",
                 "city", "country", "status", "type", "name", "amount"}
        self.assertFalse(nouns & wording.FUNCTION_WORDS)
        self.assertFalse(nouns & wording.OPERATION_FORMS)


if __name__ == "__main__":
    unittest.main()
