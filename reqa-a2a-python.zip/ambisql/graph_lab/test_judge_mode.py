"""Which judge a coverage run uses, and what keeps two judges apart.

No database and no model: the clarifiers are stand-ins and the agent's
schema view is replaced, since only the wiring is under test here."""

import os
import tempfile

os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"
os.environ["DATAGORA_DATA_DIR"] = tempfile.mkdtemp(prefix="datagora-tests-")

import json
import pathlib
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

import ambisql
import coverage
import settings_store as store


class JudgeModeTests(unittest.TestCase):

    def test_the_agent_unless_asked(self):
        with patch.dict("os.environ", {}, clear=False):
            os.environ.pop("DATAGORA_JUDGE", None)
            self.assertEqual(coverage.judge_mode(), "agent")
            self.assertEqual(coverage.judge_mode("single"), "single")
            self.assertEqual(coverage.judge_mode("nonsense"), "agent")
        with patch.dict("os.environ", {"DATAGORA_JUDGE": "single"}):
            self.assertEqual(coverage.judge_mode(), "single")
            # the run's own choice wins over the environment
            self.assertEqual(coverage.judge_mode("agent"), "agent")

    def test_stand_ins_are_never_wrapped(self):
        clars = [Mock(), Mock()]
        self.assertIs(coverage._as_judges(clars, "agent"), clars)

    def test_real_clarifiers_become_agents_sharing_one_view(self):
        made = []

        class View:
            def __init__(self, clar, profile_path=None):
                made.append(clar)

        # the two names on the real module: a module stand-in broke the
        # agent's own import of verdict_tools when this file ran alone
        import verdict_tools
        settings = SimpleNamespace(from_environment=lambda: SimpleNamespace(think="all"))
        clars = [ambisql.Clarifier.for_connection(lambda: None, "s", llm=object())
                 for _ in range(3)]
        with patch.object(verdict_tools, "SchemaView", View), \
                patch.object(verdict_tools, "Settings", settings):
            judges = coverage._as_judges(clars, "agent")
        self.assertEqual(len(made), 1)              # the schema is read once
        self.assertTrue(all(type(j).__name__ == "VerdictAgent" for j in judges))
        self.assertEqual(len({id(j._view) for j in judges}), 1)
        self.assertEqual([j.clar for j in judges], clars)

    def test_single_leaves_the_clarifiers_as_they_are(self):
        clars = [ambisql.Clarifier.for_connection(lambda: None, "s", llm=object())]
        self.assertIs(coverage._as_judges(clars, "single"), clars)

    def test_the_agent_trace_is_kept_whole(self):
        clar = SimpleNamespace(last_trace={"mode": "agent", "turns": [1, 2]},
                               last_reply=None, last_shown=None)
        self.assertEqual(coverage._trace_of(clar, None)["turns"], [1, 2])
        single = SimpleNamespace(last_reply={"a": 1}, last_shown=["t"])
        self.assertEqual(coverage._trace_of(single, None)["mode"], "single")

    def test_a_stop_reaches_the_agent(self):
        seen = {}

        class Judge:
            cancel_event = None
            _llm = None

            def clarify(self, question):
                seen["event"] = self.cancel_event
                return ambisql.Outcome(action="ANSWER")

        judge = Judge()
        ev = __import__("threading").Event()
        with patch.object(coverage, "_slots", return_value=[judge]):
            coverage.assess(["q?"], connect=lambda: None, schema="s", cancel=ev)
        self.assertIs(seen["event"], ev)


class JudgedWithTests(unittest.TestCase):

    def setUp(self):
        self.dir = pathlib.Path(tempfile.mkdtemp(prefix="judged-"))
        self.out = self.dir / "run.csv"
        self.out.write_text("question,verdict\n", encoding="utf-8")
        coverage.manifest_path(self.out).write_text(json.dumps({"job": "j"}), encoding="utf-8")

    def test_a_file_no_run_judged_has_no_judge(self):
        self.assertIsNone(coverage.judged_with(self.out))

    def test_a_run_from_before_the_agent_was_single(self):
        coverage.record_run(self.out, {"id": "a", "judged": 3})
        self.assertEqual(coverage.judged_with(self.out), "single")

    def test_the_last_run_that_judged_says_it(self):
        coverage.record_run(self.out, {"id": "a", "judged": 3, "judge": "agent"})
        coverage.record_run(self.out, {"id": "b", "judged": 0, "judge": "single"})
        self.assertEqual(coverage.judged_with(self.out), "agent")

    def test_a_run_recorded_before_its_first_verdict_decided_nothing(self):
        coverage.record_run(self.out, {"id": "a", "judged": 0, "judge": "agent"})
        self.assertIsNone(coverage.judged_with(self.out))

    def test_a_run_cut_before_its_count_was_written_still_decides(self):
        # killed between the verdict written and its count recorded: the
        # entry still says 0, and the file holds the agent's verdict
        coverage.record_run(self.out, {"id": "a", "judged": 0, "judge": "agent"})
        with open(self.out, "a", encoding="utf-8") as fh:
            fh.write("first,ANSWERABLE\n")
        self.assertEqual(coverage.judged_with(self.out), "agent")

    def test_an_unknown_left_in_the_file_is_no_verdict(self):
        # a resume drops it and judges the question again
        coverage.record_run(self.out, {"id": "a", "judged": 0, "judge": "agent"})
        with open(self.out, "a", encoding="utf-8") as fh:
            fh.write("first,UNKNOWN\n")
        self.assertIsNone(coverage.judged_with(self.out))


def _outcome():
    return SimpleNamespace(action="ANSWER", reason="", question="", checked=False,
                           kind="AmbiValue", options=[])


class FileGuardTests(unittest.TestCase):
    """assess_file refuses to resume a file with the other judge, however
    the run before it ended. The clarifier is a stand-in, so the agent is
    never built: only what the manifest records is under test."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = pathlib.Path(self.tmp.name)
        self.out = self.root / "verdicts.csv"
        self.questions = self.write("q.csv", "id,question\n1,first\n2,second\n3,third\n")

    def write(self, name, body):
        path = self.root / name
        path.write_text(body, encoding="utf-8")
        return path

    def run_file(self, questions, replies=None, **kw):
        clarifier = Mock()
        if replies is None:
            clarifier.clarify.return_value = _outcome()
        else:
            clarifier.clarify.side_effect = replies
        with patch.object(coverage, "Clarifier", return_value=clarifier):
            report = coverage.assess_file(questions, self.out, profile=object(), **kw)
        return report, clarifier.clarify.call_count

    def runs(self, output=None):
        return coverage.read_manifest(output or self.out)["runs"]

    def test_a_resume_with_the_other_judge_is_refused(self):
        self.run_file(self.questions, judge="agent")
        with self.assertRaisesRegex(ValueError, "judged by the agent judge"):
            self.run_file(self.questions, judge="single")
        # the same judge resumes, with nothing left to do
        report, asked = self.run_file(self.questions, judge="agent")
        self.assertEqual((asked, report.already_done), (0, 3))

    def test_the_run_and_its_judge_are_recorded_before_the_first_question(self):
        seen = []

        def reply(_question):
            seen.append(self.runs()[-1])
            return _outcome()

        self.run_file(self.questions, replies=reply, judge="agent")
        self.assertEqual((seen[0]["judge"], seen[0]["judged"]), ("agent", 0))
        self.assertIn("agent_version", seen[0])
        # brought up to date as each verdict lands, under one entry
        self.assertEqual([s["judged"] for s in seen], [0, 1, 2])
        self.assertEqual(len(self.runs()), 1)
        self.assertEqual(self.runs()[0]["judged"], 3)
        self.assertEqual(self.runs()[0]["id"], seen[0]["id"])

    def test_a_run_stopped_after_one_verdict_still_blocks_the_other_judge(self):
        report, _asked = self.run_file(
            self.questions, replies=[_outcome(), KeyboardInterrupt()], judge="agent")
        self.assertEqual((report.stopped, report.processed), ("stopped by hand", 1))
        self.assertEqual((self.runs()[-1]["judge"], self.runs()[-1]["judged"]), ("agent", 1))
        with self.assertRaisesRegex(ValueError, "judged by the agent judge"):
            self.run_file(self.questions, judge="single")

    def test_a_run_whose_count_was_never_written_still_blocks(self):
        # every update after the first record fails: the entry says 0, the
        # file holds the agent's verdicts, and the guard reads the file
        real = coverage.record_run
        calls = []

        def flaky(output, run):
            calls.append(run)
            if len(calls) > 1:
                raise OSError("disk full")
            return real(output, run)

        with patch.object(coverage, "record_run", side_effect=flaky):
            report, _asked = self.run_file(self.questions, judge="agent")
        self.assertIsNone(report.stopped)
        self.assertEqual(self.runs()[-1]["judged"], 0)
        with self.assertRaisesRegex(ValueError, "judged by the agent judge"):
            self.run_file(self.questions, judge="single")

    def test_a_new_version_carries_only_the_verdicts_of_its_own_judge(self):
        self.run_file(self.questions, judge="agent")
        edited = self.write("q.csv", "id,question\n1,first\n2,second\n3,third\n4,fourth\n")
        report, asked = self.run_file(edited, judge="single")
        self.assertNotEqual(report.output, str(self.out))
        self.assertEqual((asked, report.already_done), (4, 0))
        self.assertNotIn("carrying", report.note)
        self.assertEqual(coverage.judged_with(report.output), "single")

    def test_among_versions_of_both_judges_the_same_judge_is_carried(self):
        self.run_file(self.questions, judge="agent")                 # 3 by the agent
        self.run_file(self.write(
            "q.csv", "id,question\n1,first\n2,second\n3,third\n4,fourth\n"),
            judge="single")                                            # 4 by single, newer
        report, asked = self.run_file(self.write(
            "q.csv", "id,question\n1,first\n2,second\n3,third\n4,fourth\n5,fifth\n"),
            judge="agent")
        # the agent's three, not the newer single four
        self.assertIn("carrying 3 verdicts", report.note)
        self.assertEqual((asked, report.already_done), (2, 3))
        self.assertEqual(coverage.judged_with(report.output), "agent")

    def test_a_crash_before_any_verdict_leaves_the_file_to_either_judge(self):
        report, _asked = self.run_file(self.questions, replies=KeyboardInterrupt(),
                                       judge="agent")
        self.assertEqual((report.stopped, report.processed), ("stopped by hand", 0))
        self.assertEqual(self.runs()[-1]["judge"], "agent")
        report, asked = self.run_file(self.questions, judge="single")
        self.assertEqual((asked, report.processed), (3, 3))


class SettingsTests(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        env = patch.dict("os.environ", {"DATAGORA_DATA_DIR": self.tmp.name})
        env.start()
        self.addCleanup(env.stop)
        # what the store set in the environment, per test: a variable it
        # never set is left alone, which is what one test checks
        for name, value in (("_SET_HERE", set()), ("_BEFORE", {})):
            p = patch.object(store, name, value)
            p.start()
            self.addCleanup(p.stop)

    def test_the_judge_settings_are_there_and_empty(self):
        engine = store.load()["engine"]
        for key in ("judge_mode", "agent_max_turns", "agent_think", "agent_same_result",
                    "agent_arbiter", "agent_choice_tolerance"):
            self.assertEqual(engine[key], "")

    def test_a_judge_chosen_on_the_page_reaches_the_engine(self):
        doc = store.load()
        doc["databases"] = [{"name": "w"}]
        doc["engine"]["judge_mode"] = "agent"
        doc["engine"]["agent_max_turns"] = 6
        store.apply_to_environment(doc)
        self.assertEqual(os.environ.get("DATAGORA_JUDGE"), "agent")
        self.assertEqual(os.environ.get("DATAGORA_AGENT_MAX_TURNS"), "6")

    def test_an_empty_judge_leaves_the_server_value(self):
        with patch.dict("os.environ", {"DATAGORA_JUDGE": "agent"}):
            doc = store.load()
            doc["databases"] = [{"name": "w"}]
            store.apply_to_environment(doc)
            self.assertEqual(os.environ.get("DATAGORA_JUDGE"), "agent")

    def test_a_save_without_the_judge_keeps_it(self):
        store.update("engine", {"judge_mode": "agent", "agent_think": "none"})
        store.update("engine", {"ask_values": False})
        engine = store.load()["engine"]
        self.assertEqual(engine["judge_mode"], "agent")
        self.assertEqual(engine["agent_think"], "none")
        self.assertFalse(engine["ask_values"])

    def test_a_setting_the_agent_cannot_use_is_refused(self):
        for bad in ({"judge_mode": "both"}, {"agent_think": "sometimes"},
                    {"agent_max_turns": 1}, {"agent_choice_tolerance": "x"}):
            with self.assertRaises(ValueError):
                store.update("engine", bad)

    def test_a_number_the_agent_would_not_read_is_refused(self):
        # verdict_tools.Settings reads these with int() and a share below 1,
        # and keeps its default in silence for anything else
        for bad in ({"agent_max_turns": 2.5}, {"agent_max_turns": "2.5"},
                    {"agent_result_tokens": 1e3}, {"agent_result_tokens": "1e3"},
                    {"agent_max_turns": 6.0}, {"agent_max_seconds": 600.5},
                    {"agent_sql_seconds": True}, {"agent_max_turns": "+6"},
                    {"agent_choice_tolerance": 1}, {"agent_choice_tolerance": "1.0"},
                    {"agent_choice_tolerance": True}, {"agent_choice_tolerance": -0.1},
                    {"agent_choice_tolerance": "nan"}):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                store.update("engine", bad)

    # (store key, Settings field, the values the store is asked to take)
    CANDIDATES = (
        ("agent_max_turns", "max_turns",
         (2, 6, 30, "6", " 12 ", "06", 1, 31, 2.5, 6.0, "2.5", "1e1", "+6", True, "six")),
        ("agent_max_seconds", "max_seconds",
         (60, 900, 3600, "900", 59, 3601, 600.5, 900.0, "900.0", "1e3", "inf", True)),
        ("agent_sql_seconds", "sql_seconds",
         (1, 9, 60, "9", 0, 61, 2.5, "2.5", True, False)),
        ("agent_result_tokens", "result_tokens",
         (400, 4000, 12000, "4000", 399, 12001, 1e3, "1e3", 4000.0, True)),
        ("agent_choice_tolerance", "choice_tolerance",
         (0, 0.0, 0.02, 0.5, 0.999, "0.02", " 0.25 ", "1e-2", 1, 1.0, "1", -0.1,
          "nan", "inf", True, False, "x")),
        ("judge_mode", "judge_mode", ("agent", "single", "Agent", "both")),
        ("agent_think", "think", ("none", "plan_conclude", "all", "NONE", "some")),
        ("agent_same_result", "same_result", ("choice", "answer", "rows")),
        ("agent_arbiter", "arbiter", ("vote", "off", "on")),
    )

    def test_every_value_the_store_takes_is_the_value_the_agent_uses(self):
        tools = __import__("verdict_tools")
        defaults = tools.Settings()
        for key, field, values in self.CANDIDATES:
            for value in values:
                try:
                    store._check_agent({key: value})
                except ValueError:
                    continue
                with self.subTest(key=key, value=value), \
                        patch.dict("os.environ", {}), \
                        patch.object(store, "_SET_HERE", set()), \
                        patch.object(store, "_BEFORE", {}):
                    store.apply_to_environment({"engine": {key: value}})
                    used = getattr(tools.Settings.from_environment(), field)
                    if isinstance(getattr(defaults, field), str):
                        self.assertEqual(used, value)
                    else:
                        self.assertEqual(used, float(value))

    def test_the_agreement_is_not_empty(self):
        # every key takes at least one value, and refuses at least one
        for key, _field, values in self.CANDIDATES:
            taken = []
            for value in values:
                try:
                    store._check_agent({key: value})
                    taken.append(value)
                except ValueError:
                    pass
            with self.subTest(key=key):
                self.assertTrue(taken)
                self.assertLess(len(taken), len(values))

    def test_the_judge_applies_on_a_deployment_configured_by_its_env(self):
        # no endpoint and no database on the page: the engine's other values
        # are left to their defaults, the judge chosen there still applies
        with patch.dict("os.environ", {"DATAGORA_SCHEMA_SAMPLES": "7"}):
            doc = store.load()
            self.assertFalse(doc.get("endpoints") or doc.get("databases"))
            doc["engine"].update(judge_mode="agent", agent_max_turns="6",
                                 agent_choice_tolerance="0.02", schema_samples=3)
            store.apply_to_environment(doc)
            self.assertEqual(os.environ.get("DATAGORA_JUDGE"), "agent")
            self.assertEqual(os.environ.get("DATAGORA_AGENT_MAX_TURNS"), "6")
            self.assertEqual(os.environ.get("DATAGORA_AGENT_CHOICE_TOLERANCE"), "0.02")
            self.assertEqual(os.environ.get("DATAGORA_SCHEMA_SAMPLES"), "7")
            # emptied on the page, the .env's value comes back
            doc["engine"]["judge_mode"] = ""
            store.apply_to_environment(doc)
            self.assertIsNone(os.environ.get("DATAGORA_JUDGE"))

    def test_an_empty_judge_leaves_the_env_value_without_databases_too(self):
        with patch.dict("os.environ", {"DATAGORA_JUDGE": "agent"}):
            store.apply_to_environment(store.load())
            self.assertEqual(os.environ.get("DATAGORA_JUDGE"), "agent")


if __name__ == "__main__":
    unittest.main()
