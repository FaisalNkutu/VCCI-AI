"""Bash-runnable evaluation of the clarifier, on two unrelated schemas.

It measures the two things that matter and that pull in opposite
directions. **Detection**: when a question really is ambiguous, does the
clarifier say so, and are the options it offers real. **False
clarification**: when a question is perfectly clear, does it keep quiet.
A clarifier judged on detection alone always wins by asking about
everything, which is the behaviour that makes a product unusable, so
neither number means anything without the other.

Every case is labelled by hand with what it should do. The questions
differ per database because the schemas do; the code and the scoring do
not, which is the same portability property the join audit has.

    .venv/Scripts/python src/graph_lab/test_ambisql.py
    .venv/Scripts/python src/graph_lab/test_ambisql.py --endpoint server-gemma
"""

import os

# the column index is on by default; a test never builds one in a real
# Qdrant, and the tests that need one give it directly
os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")

import argparse
import time

from ambisql import Clarifier
from db_profile import DbProfile
from llm import LLM

# expect: "CLARIFY or GUIDE" for a genuinely ambiguous question,
#         "ANSWER" for one a competent analyst would just answer.
CASES = {
    "datagora_generic": [
        ("how many products do we have?", "ANSWER"),
        ("list the warehouses and their cities", "ANSWER"),
        ("total quantity on hand per warehouse", "ANSWER"),
        ("show me the oldest products", "AMBIGUOUS"),
        ("which products are the best?", "AMBIGUOUS"),
        ("products stored in city 0001", "ANSWER"),
    ],
    "datagora_lib": [
        ("how many books are in the catalogue?", "ANSWER"),
        ("list the members and their email addresses", "ANSWER"),
        ("number of loans per member", "ANSWER"),
        ("who are the oldest members?", "AMBIGUOUS"),
        ("what are the most popular books?", "AMBIGUOUS"),
        ("books published before 2000", "ANSWER"),
    ],
}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--endpoint", default=None,
                    help=f"model endpoint; known: {LLM.names()}")
    ap.add_argument("--profile", default=None, help="one profile only")
    args = ap.parse_args()

    llm = LLM.load(args.endpoint)
    if not llm.reachable():
        raise SystemExit(
            f"endpoint {llm.name} ({llm.url}) is unreachable. "
            f"Known endpoints: {LLM.names()}; switch with --endpoint or by "
            f"changing `default` in models.json.")
    print(f"model: {llm.name} -> {llm.model}\n")

    names = [args.profile] if args.profile else list(CASES)
    detected = missed = quiet = false_alarm = errors = 0
    grounded_options = 0
    t0 = time.time()

    for name in names:
        clar = Clarifier(DbProfile.load(name), llm)
        print(f"{'='*72}\n{name}\n{'='*72}")
        for question, expected in CASES[name]:
            out = clar.clarify(question)
            act = out.action
            if act == "ERROR":
                errors += 1
                verdict = "ERROR"
            elif expected == "AMBIGUOUS":
                ok = act in ("CLARIFY", "GUIDE")
                detected += ok
                missed += not ok
                verdict = "caught" if ok else "MISSED"
                grounded_options += len(out.options)
            else:
                ok = act == "ANSWER"
                quiet += ok
                false_alarm += not ok
                verdict = "quiet" if ok else "FALSE ALARM"
            print(f"  {verdict:12} {act:8} {question}")
            if out.options:
                print(f"               options: "
                      f"{', '.join(o.label for o in out.options)}")
        print()

    total_amb = detected + missed
    total_clear = quiet + false_alarm
    print(f"{'='*72}")
    print(f"  ambiguous questions caught   {detected}/{total_amb}")
    print(f"  clear questions left alone   {quiet}/{total_clear}"
          f"   (false alarms: {false_alarm})")
    if detected:
        print(f"  grounded options per catch   "
              f"{grounded_options / detected:.1f}")
    if errors:
        print(f"  model errors                 {errors}")
    print(f"  {time.time() - t0:.0f}s on {llm.model}")
    print("\n  Read both lines together. A clarifier that catches "
          "everything\n  by asking about everything is worse than none.")


if __name__ == "__main__":
    main()
