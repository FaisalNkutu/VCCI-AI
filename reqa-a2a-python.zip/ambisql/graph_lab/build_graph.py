"""G1: build the join graph of a database into Neo4j, from information_schema.

Nothing here knows a table name. Point it at a profile and it reads the
schema, so the same command serves our sandbox and a customer's
production database.

What it reads mechanically, never guesses:
  nodes        every BASE TABLE of the schema
  edges        every declared foreign key, oriented child -> parent
  cardinality  the parent side of a foreign key is unique by definition;
               the child side is unique only if a UNIQUE index covers
               exactly the foreign key columns. Unique on both sides is
               1:1, otherwise N:1, and the child is the finer side.
  junction     a table whose PRIMARY KEY is made only of foreign key
               columns, with at least two foreign keys. The two tables
               it sits between are then an effective N:M, which is what
               the fan and chasm rules read.

What it reads from the data dictionary, when the profile names one:
  edges        every relationship the knowledge base documents and the
               catalogue does not declare: references a constraint cannot
               express, such as one whose target table depends on a code,
               and ones the database simply never enforced, often with
               column names that do not match. Stored as documented, not
               declared, so a
               reader of the graph can tell an enforced constraint from a
               written one, and pruned when the dictionary drops them.

What it deliberately leaves to a human:
  meaning      one sentence per edge. A builder cannot invent what a
               relation means, and the judge and the repair messages
               quote it. Created empty and reported.
  weight       the tie-break between paths of equal length. Created at 1
               and never overwritten, so curation survives a rebuild.

Idempotent by construction: nodes and edges are MERGE'd, mechanical
properties are refreshed on every run, curated properties are only set
on creation, and anything no longer in the schema is removed. Rebuilding
after a migration is safe and does not erase human work.

    .venv/Scripts/python src/graph_lab/build_graph.py --profile datagora_lib
    .venv/Scripts/python src/graph_lab/build_graph.py --all --report
"""

import argparse
from collections import defaultdict

if __package__:
    from . import dictionary
    from .db_profile import DbProfile
else:
    import dictionary
    from db_profile import DbProfile


# ----------------------------------------------------------- reading SQL

def read_schema(profile):
    """Tables, foreign keys and uniqueness, straight from the catalogue."""
    con = profile.connect_mysql()
    cur = con.cursor()
    schema = profile.schema

    cur.execute("""SELECT table_name FROM information_schema.tables
                   WHERE table_schema=%s AND table_type='BASE TABLE'
                   ORDER BY table_name""", (schema,))
    tables = [r[0] for r in cur.fetchall()]

    # foreign keys, grouped by constraint so composite keys stay together
    cur.execute("""SELECT constraint_name, table_name, column_name,
                          referenced_table_name, referenced_column_name
                   FROM information_schema.key_column_usage
                   WHERE table_schema=%s AND referenced_table_name IS NOT NULL
                   ORDER BY table_name, constraint_name, ordinal_position""",
                (schema,))
    grouped = defaultdict(lambda: {"cols": [], "ref_cols": []})
    for name, table, col, ref_table, ref_col in cur.fetchall():
        key = (table, name)
        grouped[key]["table"] = table
        grouped[key]["ref_table"] = ref_table
        grouped[key]["cols"].append(col)
        grouped[key]["ref_cols"].append(ref_col)

    # unique indexes, as column sets, to read cardinality mechanically
    cur.execute("""SELECT table_name, index_name, column_name, seq_in_index
                   FROM information_schema.statistics
                   WHERE table_schema=%s AND non_unique=0
                   ORDER BY table_name, index_name, seq_in_index""", (schema,))
    idx = defaultdict(list)
    for table, index, col, _seq in cur.fetchall():
        idx[(table, index)].append(col)
    unique_sets = defaultdict(set)
    for (table, _index), cols in idx.items():
        unique_sets[table].add(tuple(cols))

    primary = {t: tuple(c) for (t, i), c in idx.items() if i == "PRIMARY"}
    con.close()
    return tables, list(grouped.values()), unique_sets, primary


def classify(fks, unique_sets, primary):
    """Cardinality per foreign key, and which tables are junctions."""
    fk_cols_by_table = defaultdict(set)
    fk_count = defaultdict(int)
    for fk in fks:
        fk_cols_by_table[fk["table"]].update(fk["cols"])
        fk_count[fk["table"]] += 1

    junctions = {
        t for t, pk in primary.items()
        if fk_count[t] >= 2 and set(pk) and set(pk) <= fk_cols_by_table[t]}

    edges = []
    for fk in fks:
        child_unique = tuple(fk["cols"]) in unique_sets.get(fk["table"], set())
        edges.append({
            "left": fk["table"], "right": fk["ref_table"],
            "left_col": ",".join(fk["cols"]),
            "right_col": ",".join(fk["ref_cols"]),
            "cardinality": "1:1" if child_unique else "N:1",
            "composite": len(fk["cols"]) > 1,
            "self_ref": fk["table"] == fk["ref_table"],
        })
    return edges, junctions


def documented(profile, tables, edges, primary):
    """Edges the dictionary documents that the catalogue does not declare.

    Only between tables the catalogue has, since a knowledge base can
    outlive a table. One to one when the referencing column is its table's
    whole primary key, which is the shape of a table that continues
    another's rows; many to one otherwise."""
    kb = dictionary.load(getattr(profile, "descriptions", None))
    links = kb["links"]
    by_name = {t.lower(): t for t in tables}
    declared = {(e["left"].lower(), e["left_col"].lower(),
                 e["right"].lower(), e["right_col"].lower()) for e in edges}
    found = []
    for (child, col), (parent, pcol, about) in sorted(links.items()):
        left, right = by_name.get(child), by_name.get(parent)
        if not left or not right or (child, col, parent, pcol) in declared:
            continue
        pk = tuple(c.lower() for c in primary.get(left, ()))
        found.append({
            "left": left, "right": right, "left_col": col, "right_col": pcol,
            "cardinality": "1:1" if pk == (col,) else "N:1",
            "composite": False, "self_ref": left == right,
            "relationship": about.get("name") or "", "condition": None})
    # a column whose target depends on a type code: one edge per target,
    # each holding the condition it is valid under
    for (child, col), targets in sorted(kb.get("polymorphic", {}).items()):
        left = by_name.get(child)
        for parent, pcol, about in targets:
            right = by_name.get(parent)
            if not left or not right:
                continue
            when = about.get("when") or {}
            condition = (f"{left}.{when['column']} = '{str(when.get('value', ''))}'"
                         if when.get("column") else None)
            found.append({
                "left": left, "right": right, "left_col": col, "right_col": pcol,
                "cardinality": "N:1", "composite": False, "self_ref": left == right,
                "relationship": about.get("name") or "", "condition": condition})
    return found


# ------------------------------------------------------------- writing

WRITE_NODES = """
UNWIND $tables AS t
MERGE (n:Table {db: $db, name: t.name})
SET n.junction = t.junction, n.declared = true
"""

WRITE_EDGES = """
UNWIND $edges AS e
MATCH (a:Table {db: $db, name: e.left})
MATCH (b:Table {db: $db, name: e.right})
MERGE (a)-[r:JOINS_ON {left_col: e.left_col, right_col: e.right_col}]->(b)
ON CREATE SET r.weight = 1, r.meaning = null
SET r.cardinality = e.cardinality,
    r.composite   = e.composite,
    r.self_ref    = e.self_ref,
    r.declared    = true,
    r.inferred    = false
"""

PRUNE_EDGES = """
MATCH (a:Table {db: $db})-[r:JOINS_ON]->(b:Table {db: $db})
WHERE r.declared = true
  AND NOT [a.name, r.left_col, b.name, r.right_col] IN $keep
DELETE r
"""

WRITE_DOCUMENTED = """
UNWIND $edges AS e
MATCH (a:Table {db: $db, name: e.left})
MATCH (b:Table {db: $db, name: e.right})
MERGE (a)-[r:JOINS_ON {left_col: e.left_col, right_col: e.right_col}]->(b)
ON CREATE SET r.weight = 1, r.meaning = null
SET r.cardinality  = e.cardinality,
    r.composite    = e.composite,
    r.self_ref     = e.self_ref,
    r.declared     = false,
    r.documented   = true,
    r.relationship = e.relationship,
    r.condition    = e.condition,
    r.inferred     = false
"""

PRUNE_DOCUMENTED = """
MATCH (a:Table {db: $db})-[r:JOINS_ON]->(b:Table {db: $db})
WHERE r.documented = true AND coalesce(r.declared, false) = false
  AND NOT [a.name, r.left_col, b.name, r.right_col] IN $keep
DELETE r
"""

PRUNE_NODES = """
MATCH (n:Table {db: $db})
WHERE NOT n.name IN $keep
DETACH DELETE n
"""


def write_graph(profile, tables, edges, junctions, written=()):
    if profile.graph_key == "*":
        # a graph read whole has no name to write under, and writing into
        # it would mix this database's nodes with whatever else it holds
        raise SystemExit(f"{profile.name} reads the whole Neo4j graph (\"*\"): "
                         f"give it a graph name of its own to build one")
    drv = profile.connect_neo4j()
    payload_tables = [{"name": t, "junction": t in junctions} for t in tables]
    keep_edges = [[e["left"], e["left_col"], e["right"], e["right_col"]]
                  for e in edges]
    keep_written = [[e["left"], e["left_col"], e["right"], e["right_col"]]
                    for e in written]
    with drv.session() as s:
        s.run(WRITE_NODES, db=profile.graph_key, tables=payload_tables)
        if edges:
            s.run(WRITE_EDGES, db=profile.graph_key, edges=edges)
        s.run(PRUNE_EDGES, db=profile.graph_key, keep=keep_edges)
        if written:
            s.run(WRITE_DOCUMENTED, db=profile.graph_key, edges=list(written))
        s.run(PRUNE_DOCUMENTED, db=profile.graph_key, keep=keep_written)
        s.run(PRUNE_NODES, db=profile.graph_key, keep=tables)
        counts = s.run(
            """MATCH (n:Table {db: $db})
               OPTIONAL MATCH (n)-[r:JOINS_ON]->(:Table {db: $db})
               RETURN count(DISTINCT n) AS nodes, count(r) AS edges""",
            db=profile.graph_key).single()
        stored = (counts["nodes"], counts["edges"])
        missing = s.run(
            """MATCH (:Table {db: $db})-[r:JOINS_ON]->(:Table {db: $db})
               WHERE r.meaning IS NULL RETURN count(r) AS n""",
            db=profile.graph_key).single()["n"]
    drv.close()
    return stored, missing


# -------------------------------------------------------------- report

def report(profile, tables, edges, junctions, stored, missing, written=()):
    print(f"\n=== {profile.name} ({profile.schema}) ===")
    print(f"  {len(tables)} tables, {len(edges) - len(written)} declared "
          f"edges, {len(written)} documented in the dictionary "
          f"-> stored in Neo4j: {stored[0]} nodes, {stored[1]} edges")
    for e in edges:
        flags = []
        if e["composite"]:
            flags.append("composite")
        if e["self_ref"]:
            flags.append("self-reference")
        tail = ("  [" + ", ".join(flags) + "]") if flags else ""
        if e.get("relationship") is not None:
            flags.append(f"documented: {e['relationship'] or 'unnamed'}")
            tail = "  [" + ", ".join(flags) + "]"
        print(f"    {e['left']}.{e['left_col']} -> "
              f"{e['right']}.{e['right_col']}  {e['cardinality']}{tail}")
    if junctions:
        print(f"  junction tables: {', '.join(sorted(junctions))}")

    fan_in = defaultdict(set)
    for e in edges:
        if e["cardinality"] == "N:1" and not e["self_ref"]:
            fan_in[e["right"]].add(e["left"])
    hubs = {t: kids for t, kids in fan_in.items() if len(kids) > 1}
    for t, kids in sorted(hubs.items()):
        print(f"  trap-prone hub: {t} has {len(kids)} N branches "
              f"({', '.join(sorted(kids))})")
    if missing:
        print(f"  NEEDS CURATION: {missing} edges have no meaning sentence; "
              f"weights are all at their default of 1")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--profile", help="profile name from profiles.json")
    ap.add_argument("--all", action="store_true", help="build every profile")
    ap.add_argument("--report", action="store_true", help="print the graph")
    args = ap.parse_args()

    names = DbProfile.names() if args.all else [args.profile]
    if not names or names == [None]:
        raise SystemExit("give --profile NAME or --all; "
                         f"known: {DbProfile.names()}")

    for name in names:
        profile = DbProfile.load(name)
        tables, fks, unique_sets, primary = read_schema(profile)
        edges, junctions = classify(fks, unique_sets, primary)
        written = documented(profile, tables, edges, primary)
        stored, missing = write_graph(profile, tables, edges, junctions,
                                      written)
        if args.report or args.all:
            report(profile, tables, edges + written, junctions, stored,
                   missing, written)
        else:
            print(f"{name}: {stored[0]} nodes, {stored[1]} edges")


if __name__ == "__main__":
    main()
