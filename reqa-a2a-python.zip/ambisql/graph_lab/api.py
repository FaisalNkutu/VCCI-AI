"""The pipeline's steps as plain functions, each usable on its own.

`Datagora.ask()` runs the whole journey, which is what an application
wants. This module is for the other case: a team that already has a
pipeline and wants one of our steps inside it, at the place they choose,
without adopting the rest.

    from graph_lab.api import is_ambiguous, check_sql, write_sql

    a = is_ambiguous("which supplier is the most reliable", db="sales")
    if a.ambiguous:
        print(a.level, a.kind, a.question, [o.label for o in a.options])

    for verdict, why in check_sql(their_sql, db="sales"):
        print(verdict, why)

    # whole questions in the asker's words, for a choice or a NEEDS MORE
    a = is_ambiguous("which products are cheap", db="sales", reformulate=True)
    for s in a.suggestions:
        print(s.question, s.choice)

Every function is stateless and takes where things live as arguments, so
two calls can hit two databases and two models without any shared setup:

    db      a profile name, a DbProfile, or a dict of MySQL credentials
    llm     an endpoint name, an LLM, or dict(api=, url=, model=)
    prompt  the system prompt to use instead of ours, when you have one

Nothing here writes to the database, and nothing here raises for an
unreachable model: a step that could not run says so in its result,
because a caller integrating one piece needs to tell "no ambiguity" from
"I could not tell".
"""

from pydantic import BaseModel, ConfigDict, Field

if __package__:
    from .ambisql import Clarifier, Option, Outcome, _Callable
    from .db_profile import DbProfile
    from .llm import LLM
    from .prompts import ANCHOR_SYSTEM, ANSWER_SYSTEM, SQL_SYSTEM
    from .reformulate import Suggestion, needs, suggest
    from .schema_graph import Graph, judge_sql
else:
    from ambisql import Clarifier, Option, Outcome, _Callable
    from db_profile import DbProfile
    from llm import LLM
    from prompts import ANCHOR_SYSTEM, ANSWER_SYSTEM, SQL_SYSTEM
    from reformulate import Suggestion, needs, suggest
    from schema_graph import Graph, judge_sql

__all__ = ["is_ambiguous", "name_tables", "imposed_joins", "write_sql",
           "check_sql", "run_sql", "say", "Ambiguity", "suggest_questions",
           "Suggestion"]

# AmbiSQL splits its taxonomy in two. Level 1 is settled by looking at the
# database: a word matching several columns, a value matching several
# rows, a reading the schema does not hold. Level 2 comes from the model
# reading the question and cannot be checked against anything, which is
# why we ground on level 1 and treat level 2 as a hint.
LEVEL_1 = {"AmbiSchema", "AmbiValue", "AmbiView"}


class Ambiguity(BaseModel):
    """What `is_ambiguous` gives back.

    `ambiguous` is the answer to the question asked. `level` is 1 when
    the database itself shows the ambiguity, 2 when only the model sees
    it, and 0 when there is none. `usable` is False when the model could
    not be reached, which is not the same as a clear question."""
    model_config = ConfigDict(extra="forbid")

    ambiguous: bool
    level: int = 0
    kind: str = ""
    reason: str = ""
    question: str = ""
    options: list[Option] = Field(default_factory=list)
    action: str = "ANSWER"
    usable: bool = True
    # the words that left the question open, and the two facts that tell
    # NOT COVERED and NO DATA from NEEDS MORE (coverage.classify): what
    # suggest_questions needs to work from this object alone
    phrase: str = ""
    empty: bool = False
    checked: bool = False
    # whole questions in the asker's words, when is_ambiguous was asked
    # for them (reformulate=True) and the question needs a choice or more
    suggestions: list[Suggestion] = Field(default_factory=list)

    def __bool__(self):
        return self.ambiguous


# --------------------------------------------------------------- wiring

def _db(db):
    """A profile from whatever the caller had at hand."""
    if isinstance(db, DbProfile):
        return db
    if isinstance(db, str):
        return DbProfile.load(db)
    if isinstance(db, dict):
        # credentials straight from the caller's secret manager, with no
        # profiles.json anywhere in the picture
        cfg = dict(db)
        name = cfg.pop("name", None) or cfg.get("database", "db")
        return DbProfile(name=name, mysql=cfg)
    raise TypeError("db must be a profile name, a DbProfile or a dict "
                    "of MySQL credentials")


def _llm(llm, role):
    """The model to call, defaulting to the one configured for the role."""
    if llm is None:
        return LLM.role(role)
    if isinstance(llm, LLM):
        return llm
    if isinstance(llm, str):
        return LLM.load(llm)
    if isinstance(llm, dict):
        cfg = dict(llm)
        return LLM(cfg.pop("name", "inline"),
                   {"api": cfg.get("api", "openai"), "url": cfg["url"],
                    "model": cfg["model"]})
    if callable(llm):
        # your own client, a function taking (system, user) and returning
        # text or a dict, as INTEGRATION.md promises: it raised a TypeError,
        # and suggest_questions fell back to its templates in silence
        # (review of 26 October)
        return llm if hasattr(llm, "json") else _Callable(
            llm, getattr(llm, "__name__", "callable"))
    raise TypeError("llm must be an endpoint name, an LLM, a dict with url, "
                    "model and api, or a function taking (system, user)")


def _graph(db, graph):
    """The join graph, or None when the caller does not want one."""
    if graph in (False, None):
        return None
    if isinstance(graph, Graph):
        return graph
    try:
        return Graph.from_profile(_db(db))
    except Exception:
        return None


# ------------------------------------------------------------ the steps

def is_ambiguous(question, *, db, llm=None, prompt=None, reformulate=False):
    """Does this question have more than one reading in this schema?

        a = is_ambiguous("the most reliable supplier", db="sales")
        a.level     1, because two columns of suppliers could mean it
        a.question  the question to put to a human
        a.options   what they would be choosing between

    The reading is checked against the live schema before it is reported,
    so a column the model invented is dropped rather than shown.

    `reformulate=True` also fills `a.suggestions` when the question needs
    a choice or more detail: whole questions in the asker's words, one
    more model call. Off by default here, because a caller of one step
    asked for one step."""
    profile = _db(db)
    clarifier = Clarifier(profile, _llm(llm, "reasoner"), system=prompt)
    out = clarifier.clarify(question)
    if out.action == "ERROR":
        return Ambiguity(ambiguous=False, reason=out.reason, action="ERROR",
                         usable=False)
    if out.action == "ANSWER":
        return Ambiguity(ambiguous=False, action="ANSWER")
    return Ambiguity(ambiguous=True, level=1 if out.kind in LEVEL_1 else 2,
                     kind=out.kind, reason=out.reason, question=out.question,
                     options=list(out.options), action=out.action,
                     phrase=out.phrase, empty=bool(getattr(out, "empty", False)),
                     checked=bool(out.checked),
                     suggestions=(suggest(clarifier, question, out)
                                  if reformulate else []))


def _as_outcome(ambiguity):
    """The clarifier's Outcome behind an Ambiguity, or the Outcome itself."""
    if isinstance(ambiguity, Outcome):
        return ambiguity
    return Outcome(action=getattr(ambiguity, "action", "") or "",
                   phrase=getattr(ambiguity, "phrase", "") or "",
                   kind=getattr(ambiguity, "kind", "") or "",
                   reason=getattr(ambiguity, "reason", "") or "",
                   question=getattr(ambiguity, "question", "") or "",
                   options=list(getattr(ambiguity, "options", None) or []),
                   empty=bool(getattr(ambiguity, "empty", False)),
                   checked=bool(getattr(ambiguity, "checked", False)))


def suggest_questions(question, ambiguity, *, db, llm=None, prompt=None):
    """Whole questions the asker can pick instead of the one they asked.

        a = is_ambiguous("which products are cheap", db="sales")
        for s in suggest_questions("which products are cheap", a, db="sales"):
            s.question   "Which products cost less than 10?"
            s.choice     the option label it settles a choice with, or None
            s.note       one plain sentence, or ""

    `ambiguity` is what is_ambiguous returned, or the clarifier's Outcome.
    One per reading for a choice, two to four for a NEEDS MORE, none for
    anything else. A model that cannot be reached, or none configured,
    gives the templates built from the readings rather than an error.
    `prompt` replaces REFORMULATE_SYSTEM."""
    outcome = _as_outcome(ambiguity)
    if not needs(outcome):
        return []
    try:
        model = _llm(llm, "reasoner")
    except (Exception, SystemExit):
        model = None
    clarifier = Clarifier(_db(db), model)
    if model is None:
        # the templates alone: a clarifier left without a model would try
        # to load the configured one on first use
        clarifier._llm = _NoModel()
    return suggest(clarifier, question, outcome, system=prompt)


class _NoModel:
    """Stands in for a model that could not be loaded: nothing to call."""

    name = model = "none"

    def json(self, *_a, **_kw):
        return None


def name_tables(question, *, db, llm=None, prompt=None):
    """The tables a question is about, confirmed against the catalogue.

    Names the model invents are dropped, so the list only ever holds
    tables that exist."""
    profile = _db(db)
    model = _llm(llm, "reasoner")
    clarifier = Clarifier(profile, model)
    raw = clarifier.json_with_schema(
        question, prompt or ANCHOR_SYSTEM, model,
        lambda schema: f"Schema:\n{schema}\n\nQuestion: {question}")
    real = {t.lower(): t for t in clarifier.columns}
    return list(dict.fromkeys(
        real[t.lower()] for t in (raw or {}).get("tables", [])
        if isinstance(t, str) and t.lower() in real))


def imposed_joins(tables, *, db, graph=True):
    """Every join the schema allows between these tables, and no other.

    Useful on its own: hand it to whatever writes your SQL today and it
    has nothing left to invent."""
    g = _graph(db, graph)
    if g is None:
        return []
    wanted = {t.lower() for t in tables}
    conditions = getattr(g, "conditions", None) or {}
    return [{"left": f, "left_col": lc, "right": t, "right_col": rc,
             "cardinality": card, "meaning": meaning,
             "condition": conditions.get((f, lc, t, rc))}
            for f, lc, t, rc, _w, _inf, card, meaning in g.edges
            if f.lower() in wanted and t.lower() in wanted]


def write_sql(question, *, db, tables=None, llm=None, prompt=None,
              correction=None):
    """One MariaDB SELECT for this question.

    The joins are imposed from the schema, so the model is choosing what
    to select, never what to join. `correction` is a verdict from a
    previous attempt, which is how the retry loop is built."""
    # imported here, not at module level: write_sql is the one
    # function that needs the engine, and importing it up top made
    # `from graph_lab.api import is_ambiguous` pull in the retry loop,
    # the schema graph, the corpus and the tracing
    if __package__:
        from .pipeline import Pipeline, strip_sql
    else:
        from pipeline import Pipeline, strip_sql
    profile = _db(db)
    pipe = Pipeline(profile, reasoner=_llm(llm, "reasoner"),
                    sql_llm=_llm(llm, "sql"))
    try:
        names = tables or name_tables(question, db=profile, llm=llm)
        if not names:
            return ""
        sub = pipe.subschema(names)
        user = pipe.prompt_for_sql(question, sub, pipe.imposed_joins(sub),
                                   correction)
        return strip_sql(pipe.sql_llm.chat(prompt or SQL_SYSTEM, user))
    finally:
        pipe.close()


def check_sql(sql, *, db, graph=True):
    """Judge SQL without running it.

    Returns [(verdict, explanation)], empty when there is nothing to
    report. Verdicts starting with REJECT are the ones that matter. This
    is the function to reach for first: it measures the queries your
    current pipeline already produces, and changes nothing.

    The gate sequence itself lives in schema_graph.judge_sql, so this and
    the pipeline's own check cannot fall out of step."""
    profile = _db(db)
    con = profile.connect_mysql()
    try:
        findings, _ran = judge_sql(sql,
                                   columns=Clarifier(profile).columns,
                                   graph=_graph(profile, graph),
                                   con=con)
        return findings
    finally:
        con.close()


def run_sql(sql, *, db, limit=50):
    """Execute read-only and roll back. Returns (columns, rows)."""
    profile = _db(db)
    con = profile.connect_mysql()
    try:
        cur = con.cursor()
        con.begin()
        try:
            cur.execute(sql)
            return ([d[0] for d in (cur.description or [])],
                    [list(r) for r in cur.fetchmany(limit)])
        finally:
            con.rollback()
            cur.close()
    finally:
        con.close()


def say(question, columns, rows, *, llm=None, prompt=None):
    """Result rows as a sentence for someone who does not read SQL."""
    model = _llm(llm, "reasoner")
    if not rows:
        return "Nothing matches that question."
    shown = 5
    preview = [", ".join(f"{c}={v}" for c, v in zip(columns, r))
               for r in rows[:shown]]
    more = (f"\n...and {len(rows) - shown} more rows, which are displayed "
            f"to the user separately." if len(rows) > shown else "")
    text = model.chat(
        prompt or ANSWER_SYSTEM,
        f"Question: {question}\n\n"
        f"[context, not an answer: the result has {len(rows)} rows "
        f"and {len(columns)} columns]\n"
        f"First rows:\n" + "\n".join(preview) + more)
    return (text or "").strip()
