"""AmbiSQL for Datagora: ask one grounded question instead of guessing.

The shape follows the SIGMOD 2026 paper (arXiv 2508.15276): detect the
ambiguous phrase, classify it, ask a multiple-choice question, rewrite
the question with the answer, then hand the rewritten question to the
generator. It sits IN FRONT of the pipeline, so the SQL generator, the
imposed joins and the audit are untouched.

Two decisions that are ours rather than the paper's.

**The model is the reasoner, not the SQL specialist.** Three of the four
steps are natural-language work: writing a question a human will read,
naming what the options mean, rewriting a sentence. Arctic-Text2SQL-R1
was reinforcement-trained on one reward, the execution correctness of
SQL, and its output contract ends in a ```sql fence. Asking it to phrase
a question fights everything it was optimised for. Gemma does this half;
Arctic keeps the SQL.

**Options are grounded, never imagined.** The model proposes candidate
columns and values; every one is then checked against information_schema
and against the real column contents, and whatever does not exist is
dropped. A clarification that offers a column the database does not have
is worse than no clarification at all, so this check is not optional. It
is also what makes the component portable: the options come from
whatever database it is pointed at.

    .venv/Scripts/python src/graph_lab/ambisql.py --profile datagora_lib \
        --question "who are the oldest members?"
"""

import argparse
import difflib
import json
import os
import pathlib
import re
import threading
import time

from pydantic import BaseModel, ConfigDict, Field

if __package__:
    from . import dictionary, wording
    from .db_profile import DbProfile
    from .llm import LLM
else:
    import dictionary
    import wording
    from db_profile import DbProfile
    from llm import LLM


class _Untraced:
    def update(self, **_kw):
        return None


def _step(name, as_type="chain", **kw):
    """A step of the question in its Langfuse trace, when tracing is there;
    nothing otherwise, and never an error."""
    import contextlib
    try:
        if __package__:
            from .observability import step
        else:
            from observability import step
        return step(name, as_type=as_type, **kw)
    except Exception:
        return contextlib.nullcontext(_Untraced())

# The seven types of the paper. The first three can be grounded in the
# database, so they earn real options; the last four are reported with
# their reason but no option list, because nothing in the schema settles
# them.
GROUNDED = {"AmbiSchema", "AmbiValue", "AmbiView"}
TYPES = {
    "AmbiSchema": "several columns could answer the phrase",
    "AmbiValue": "the literal does not match the stored form",
    "AmbiView": "the operation is unclear: count, total, rank or list",
    "AmbiSource": "the fact may come from the data or from the world",
    "AmbiContext": "a required piece of context is missing",
    "AmbiFallacy": "the question assumes something that is not true",
    "AmbiRef": "a time or place reference is fuzzy",
}
# the reference implementation names this type AmbiView; earlier drafts
# here and in the deck called it AmbiIntent, and models trained on either
# vocabulary will answer with either, so the old name is accepted
ALIASES = {"AmbiIntent": "AmbiView", "AmbiOperation": "AmbiView"}

# AmbiView is grounded differently from the other two: its options are
# SQL operations, not schema elements, so there is no catalogue to check
# them against. A closed vocabulary plays that part, which is what keeps
# a model from offering an operation MariaDB does not have.
OPERATIONS = {
    "count": "count how many rows there are",
    "sum": "add up the values",
    "average": "take the average of the values",
    "maximum": "keep the largest value",
    "minimum": "keep the smallest value",
    "rank": "order them and keep the top ones",
    "list": "list them one by one, without totalling",
    "group": "break the total down by category",
}

# The prompts live in prompts.py, each with its version; these names
# stay for anything that imported them from here.
if __package__:
    from .prompts import DECIDE_SYSTEM
    from .prompts import DETECT_SYSTEM as SYSTEM
else:
    from prompts import DECIDE_SYSTEM
    from prompts import DETECT_SYSTEM as SYSTEM


class Option(BaseModel):
    """One reading of an ambiguous phrase, grounded in the schema.

    `table` and `column` are what makes the option checkable: an option
    naming neither is an opinion, and this component exists to refuse
    those."""

    model_config = ConfigDict(extra="forbid")

    label: str
    means: str
    table: str | None = None
    column: str | None = None
    value: str | None = None
    # the join that reaches `table` from the table the question started
    # in, as "books.genre_id = genres.genre_id", when the reading lives one
    # table away. Read from the catalogue's foreign keys, never from the
    # model, so the SQL stage is handed a join that exists.
    via: str | None = None


class Outcome(BaseModel):
    """One of the four outcomes of the answer policy, never a silent guess.

    ANSWER   nothing to settle, the question goes to the generator
    CLARIFY  several readings exist in this schema, the user picks one
    GUIDE    the reading the user probably meant is not in this schema;
             say what the data does hold and offer it, labelled
    ERROR    the model was unreachable or unusable. Not an answer, and
             kept distinct on purpose: a pipeline that reports "no
             ambiguity" when its model timed out is lying to itself.
    """
    model_config = ConfigDict(extra="forbid")

    action: str
    phrase: str = ""
    kind: str = ""
    reason: str = ""
    question: str = ""
    options: list[Option] = Field(default_factory=list)
    # what the asker must give, in a few words, when the judge knows it
    # ("the 2027 budget exchange rates"): the agent's verifier sets it, and
    # Ask's reformulation names it in the question with a blank
    missing: str = ""
    # who can fill a NEEDS MORE: "asker", a value they hold (a threshold, a
    # period, the size of an announced increase), or "data", something the
    # records do not keep (the time of each expense), which nobody can type
    # in and the database must record; "" when the judge does not say
    gap: str = ""
    # True when the columns that answer the question are there and the
    # filter simply matches no row. That is an EMPTY RESULT, which is an
    # answer, and it is not the same claim as "this database cannot
    # express it". Measured on the demo library: "which books were
    # written by Shakespeare in 2020" was reported as not covered, while
    # authors.name and books.published_on both sit in the schema and
    # answer it in one query. What is missing is a row.
    #
    # The distinction earns its own verdict because a benchmark needs it:
    # a question whose correct answer is the empty set cannot be scored
    # the same way as one the schema cannot reach, and a test set has to
    # be able to exclude the first kind deliberately.
    empty: bool = False
    # True only when a GUIDE rests on something verified against the
    # data: the schema was swept and holds nothing of the kind. False
    # when it rests on the model's classification alone. A report that
    # tells a team "your database cannot do this" needs to know which
    # of the two it is looking at.
    checked: bool = False

    def render(self):
        if self.action == "ANSWER":
            return "unambiguous, straight to the generator"
        if self.action == "ERROR":
            return f"ERROR: {self.reason}"
        lines = [self.question]
        for i, o in enumerate(self.options, 1):
            lines.append(f"  [{i}] {o.label}   ({o.means})"
                         + (f"   through {o.via}" if o.via else ""))
        return "\n".join(lines)


class _Callable:
    """Any function turned into the small interface this file needs.

    A team integrating the clarifier already has a model client, often
    inside LangChain or LangGraph. Requiring them to adopt our LLM class
    and our models.json to use one function is the wrong trade, so a
    plain callable taking (system, user) and returning text or a dict is
    accepted everywhere an LLM is."""

    def __init__(self, fn, name="callable"):
        self.fn = fn
        self.name = name
        self.model = name
        self.url = ""
        self.last_error = ""

    def reachable(self):
        return True

    def chat(self, system, user, **_):
        out = self.fn(system, user)
        return out if isinstance(out, str) else json.dumps(out)

    def json(self, system, user, **_):
        out = self.fn(system, user)
        if isinstance(out, dict):
            return out
        # the same parser our own client uses. A real model fences its
        # JSON or puts a sentence in front of it, so a stricter rule here
        # would have made every question UNKNOWN for a team whose model
        # behaves exactly like ours
        if __package__:
            from .llm import first_json_object
        else:
            from llm import first_json_object
        parsed = first_json_object(out)
        if parsed is None:
            self.last_error = "the callable did not return JSON"
        return parsed


class Clarifier:
    """Ambiguity detection, grounded in one database.

    Nothing here needs the rest of this package. It reads
    information_schema and real column values through a connection you
    give it, and asks one model whatever you give it:

        clar = Clarifier.for_connection(
            connect=lambda: pool.getconn(),   # any DB-API connection
            schema="sales",
            llm=my_model)                     # or a plain function

        out = clar.clarify("which supplier is the most reliable")
        out.action     ANSWER, CLARIFY, GUIDE or ERROR
        out.options    real columns, confirmed against the catalogue

    `llm` may be an LLM, anything exposing json(system, user), or a
    function taking (system, user). No profiles.json, no models.json, no
    Neo4j and no Qdrant are involved at any point."""

    # Who asks and when (context.describe), what was decided before
    # (context.earlier_note), the question's date and time (context.today,
    # context.moment): read before the question by both judges. A run sets
    # them on the clarifier for every thread (coverage); a question sets
    # them for its own thread only (for_question), so two people asking at
    # once on one pipeline never read each other's (review of 23 October).
    def for_question(self, **said):
        local = self.__dict__.setdefault("_question", threading.local())
        for key, value in said.items():
            setattr(local, key, value)

    def _asked(self, name, default):
        local = self.__dict__.get("_question")
        if local is not None and hasattr(local, name):
            return getattr(local, name)
        return self.__dict__.get("_" + name, default)

    context = property(lambda self: self._asked("context", ""),
                       lambda self, v: self.__dict__.__setitem__("_context", v))
    earlier = property(lambda self: self._asked("earlier", ""),
                       lambda self, v: self.__dict__.__setitem__("_earlier", v))
    today = property(lambda self: self._asked("today", None),
                     lambda self, v: self.__dict__.__setitem__("_today", v))
    now = property(lambda self: self._asked("now", None),
                   lambda self, v: self.__dict__.__setitem__("_now", v))

    # what this thread's last question showed and was answered: set while
    # the prompt is built, before the model call, a question asked meanwhile
    # on another thread overwrote them, and recorded its tables as this
    # one's (review of the fixes); the reformulation reads last_reply too
    def _mine(self, name):
        local = self.__dict__.get("_last")
        return getattr(local, name, None) if local is not None else None

    def _set_mine(self, name, value):
        setattr(self.__dict__.setdefault("_last", threading.local()), name, value)

    last_shown = property(lambda self: self._mine("last_shown"),
                          lambda self, v: self._set_mine("last_shown", v))
    last_focus = property(lambda self: self._mine("last_focus"),
                          lambda self, v: self._set_mine("last_focus", v))
    last_reply = property(lambda self: self._mine("last_reply"),
                          lambda self, v: self._set_mine("last_reply", v))

    def __init__(self, profile=None, llm=None, system=None, *,
                 connect=None, schema=None, index=None):
        if profile is None and connect is None:
            raise ValueError("give either a DbProfile or connect= and schema=")
        self.profile = profile
        self._connect = connect
        self._schema = schema
        # an optional search over what columns MEAN: anything exposing
        # similar(phrase) -> [(table, column, score)]. Given, it is used;
        # not given, a profile with Qdrant builds one unless
        # DATAGORA_COLUMN_INDEX is off. It only ever withholds a denial.
        self._index = index
        self._index_checked = index is not None
        self._similar = {}
        self._continues = {}
        if llm is not None and callable(llm) and not hasattr(llm, "json"):
            llm = _Callable(llm, getattr(llm, "__name__", "callable"))
        self._llm = llm
        # a caller integrating this one step may have its own wording, or
        # a prompt it manages and versions elsewhere. Overriding it must
        # change what is sent, so the prompt is read from here rather
        # than from the constant at the point of the call.
        self.system = system or SYSTEM
        self._columns = None
        self._views = None
        self._keys = None
        self._vocabulary = None
        self._foreign_keys = None
        self._samples = None
        self._meanings = None
        self._graph_edges = None
        self._corpus = None
        self._corpus_checked = False
        # how the last schema sent was cut, or None when it went whole
        self.last_focus = None
        # the correction to the estimated cost of the schema, learned from
        # the token counts the model server returns (see json_with_schema)
        self._token_scale = 1.0

    @classmethod
    def for_connection(cls, connect, schema, llm=None, system=None):
        """The clarifier on a database this package knows nothing about.

        `connect` is called whenever a connection is needed and its
        result is closed afterwards, so a pool, a context manager factory
        or a plain connect function all work."""
        return cls(None, llm, system, connect=connect, schema=schema)

    @property
    def llm(self):
        """Loaded when it is first needed, never at construction.

        Half of what this class does is read the catalogue, and that
        needs no model at all. Loading one eagerly meant check_sql, which
        only wants the column types, died with SystemExit on a machine
        with no models.json: a validation harness in someone else's CI
        exited nonzero and reported a crash where the real answer was
        that no model was required."""
        if self._llm is None:
            # the reasoner role, not the bare default: this class does
            # the reasoner's work, and resolving the default meant
            # DATAGORA_LLM_REASONER was quietly ignored, so a run asked
            # to use one model used another and said nothing
            try:
                self._llm = LLM.role("reasoner")
            except SystemExit:
                self._llm = LLM.load()
        return self._llm

    # ------------------------------------------------------ the database
    def connect(self):
        return self._connect() if self._connect else self.profile.connect_mysql()

    @property
    def schema(self):
        return self._schema if self._schema else self.profile.schema

    # ------------------------------------------------------- the schema
    @property
    def columns(self):
        """{table: [(column, type)]}, read once from the catalogue."""
        if self._columns is None:
            con = self.connect()
            cur = con.cursor()
            cur.execute(
                """SELECT table_name, column_name, data_type
                   FROM information_schema.columns
                   WHERE table_schema=%s ORDER BY table_name, ordinal_position""",
                (self.schema,))
            cols = {}
            for t, c, d in cur.fetchall():
                cols.setdefault(t, []).append((c, d))
            con.close()
            self._columns = cols
        return self._columns

    @property
    def keys(self):
        """{(table, column)} that identify a row rather than describe it.

        Primary keys and foreign keys, read from the catalogue. They are
        excluded from anything that reasons about a column's VALUES,
        because a key's values are a counting artefact: `books.genre_id`
        holding twelve numbers says the library has twelve genres, not
        that the column records a state. On a small table every key looks
        like a closed vocabulary, which is exactly the kind of thing that
        behaves differently on a customer's data than on a demo.

        near_values refuses numeric columns for the same reason, and a
        boolean flag like `is_active` must stay, so the test is on being a
        key and not on being a number."""
        if self._keys is None:
            found = set()
            try:
                con = self.connect()
                cur = con.cursor()
                cur.execute(
                    """SELECT table_name, column_name
                       FROM information_schema.key_column_usage
                       WHERE table_schema=%s
                         AND (constraint_name='PRIMARY'
                              OR referenced_table_name IS NOT NULL)""",
                    (self.schema,))
                for t, c in cur.fetchall():
                    found.add(((t or "").lower(), (c or "").lower()))
                cur.close()
                con.close()
            except Exception:
                # a catalogue this cannot read leaves the set empty, which
                # only means no column is excluded. Failing to load it must
                # not take the schema down.
                pass
            self._keys = found
        return self._keys

    def is_a_key(self, table, column):
        """A key by the catalogue or by the dictionary. A schema declares
        the constraints it can, and some it cannot: a reference whose target
        depends on a code, or one the database never enforced. For those the
        dictionary is the only place that says the column identifies a
        row."""
        pair = ((table or "").lower(), (column or "").lower())
        return (pair in self.keys
                or pair in self._documented("keys")
                or pair in self._documented("links"))

    @property
    def views(self):
        """Table names that are views, read once from the catalogue.

        A view and the table it is built from hold the same column, so
        offering both as a choice is not an ambiguity, it is the same
        answer written twice. "Which products are below their reorder
        level" came back asking whether to use inventory.quantity_on_hand
        or inventory_reorder_report.quantity_on_hand, which are the same
        number."""
        if self._views is None:
            try:
                con = self.connect()
                cur = con.cursor()
                cur.execute(
                    "SELECT table_name, view_definition "
                    "FROM information_schema.views WHERE table_schema=%s",
                    (self.schema,))
                found = {}
                for name, definition in cur.fetchall():
                    text = (definition or "").lower()
                    # which tables it is actually built from, rather than
                    # which tables happen to share a column name. Matching
                    # on the bare column collapsed two unrelated readings
                    # whenever both were called created_at.
                    found[name.lower()] = {
                        other.lower() for other in self.columns
                        if other.lower() != name.lower()
                        # MariaDB writes every name back in backticks,
                        # so this is exact: without them "inventory" also
                        # matches inside "inventory_movements"
                        and f"`{other.lower()}`" in text}
                self._views = found
                con.close()
            except Exception:
                # not knowing is not the same as there being none, and a
                # catalogue that refuses the question must not silently
                # turn every view into a table
                self._views = {}
        return self._views
    @property
    def meanings(self):
        """An optional data dictionary: what tables and columns MEAN.

        A schema says what a column is called and never what it holds, and
        `fee`, `sku` and `qty` say almost nothing. A deployment can supply
        descriptions and everything here reads them; absent, every rule
        behaves exactly as it did before."""
        if self._meanings is None:
            named = (getattr(self.profile, "descriptions", None)
                     if self.profile is not None
                     else os.environ.get("DATAGORA_DESCRIPTIONS"))
            # either shape, the short one or a knowledge base; see
            # dictionary.py. Unreadable gives an empty one, never an error.
            self._meanings = dictionary.load(named)
        return self._meanings

    # ------------------------------------------- what the dictionary adds
    def _documented(self, part):
        return self.meanings.get(part) or ({} if part != "keys" else set())

    def enum_labels(self, table, column):
        """{code: label} for a column the dictionary declares closed:
        CARTPT means CARTESIAN-POINT. {} when it declares nothing."""
        return self._documented("enums").get(
            ((table or "").lower(), (column or "").lower())) or {}

    # How many joined rows are read to see which codes a child's rows
    # carry. A child holds one code or several; a thousand rows say which
    # without scanning a production table end to end.
    CODE_SAMPLE = 1000

    def continues_in(self, table, column, con=None):
        """{code: (table, join)}: which table a code's rows continue in.

        abs_point.cat_code = GEOGPT means the point's coordinates are in
        geo_point, joined on abs_point_id = geo_point_id. Nothing written
        says so: the dictionary names geo_point as a child of abs_point, and
        the data is asked which codes the parent rows that have a geo_point
        row carry. One code, and no other child claiming it, is a link; two
        codes, no rows, or a query that failed is none. It used to be
        guessed from the names, "geo" shortening "geographic", which was
        right on the example and nothing more than a guess.

        Read once per clarifier. `con`, when given, is a caller's open
        connection: the schema text asks this of every coded column."""
        key = ((table or "").lower(), (column or "").lower())
        if key not in self._continues:
            self._continues[key] = self._children_by_code(table, column, con)
        return self._continues[key]

    def _children_by_code(self, table, column, con=None):
        if len(self.enum_labels(table, column)) < 2:
            return {}
        kids = self._documented("children").get((table or "").lower()) or {}
        claimed = {}
        for child, (child_col, parent_col, join) in kids.items():
            child = self._catalogue_table(child)
            if not (self.has(child, child_col) and self.has(table, parent_col)):
                continue
            codes = self._codes_joined(table, column, parent_col,
                                       child, child_col, con)
            if codes is not None and len(codes) == 1:
                claimed.setdefault(str(codes[0]), []).append((child, join))
        return {code: found[0] for code, found in claimed.items()
                if len(found) == 1}

    def _codes_joined(self, table, column, parent_col, child, child_col,
                      con=None):
        """The distinct codes among parent rows that have a child row, read
        from a bounded sample, or None when the query could not run."""
        lent = con is not None
        cur = None
        try:
            con = con if lent else self.connect()
            cur = con.cursor()
            cur.execute(
                f"SELECT DISTINCT x.code FROM (SELECT p.`{column}` AS code "
                f"FROM `{table}` p JOIN `{child}` c "
                f"ON p.`{parent_col}` = c.`{child_col}` "
                f"WHERE p.`{column}` IS NOT NULL LIMIT %s) x LIMIT 3",
                (self.CODE_SAMPLE,))
            return [r[0] for r in cur.fetchall()]
        except Exception:
            return None
        finally:
            for thing in (cur, None if lent else con):
                if thing is not None:
                    try:
                        thing.close()
                    except Exception:
                        pass

    def codes_for(self, value, labels):
        """The codes whose label names `value`, as a person would say it.

        "geographic points" is GEOGPT; "GEOGPT" is GEOGPT. A word that fits
        every code selects nothing, so "points" is no code at all."""
        wanted = str(value or "").strip().lower()
        words = self._content_words(value)
        hits = [code for code, label in labels.items()
                if wanted == code.lower()
                or (words and words <= (self._content_words(label)
                                        | {code.lower()}))]
        return [] if len(hits) == len(labels) > 1 else hits

    def _said(self, table, column):
        """What a column is documented to mean, its codes' labels included,
        as text for the word matching below."""
        labels = self.enum_labels(table, column)
        return " ".join([self.means(table, column)] + list(labels.values()))

    # A concept can live in the VALUES of a column without living in any
    # column name. No product is called "gluten", and no LIKE will ever
    # find one, yet a model shown a list of product names can tell bread
    # from rice. So when a literal search has failed, the values
    # themselves are put to the model. This is the only place the
    # component trusts a judgement rather than a match, which is why it
    # asks about real rows and never about the question alone.
    SAMPLE_VALUES = 30

    DECIDE_SYSTEM = DECIDE_SYSTEM

    def distinct_values(self, table, column, limit=None):
        """Values really present, for a person or a model to look at."""
        values, _checked = self._distinct_values_checked(
            table, column, limit=limit)
        return values

    def _distinct_values_checked(self, table, column, limit=None, con=None):
        """Return ``(values, checked)`` without disguising a DB failure.

        An empty result and a failed query both used to become ``[]``.  That
        is harmless for suggestions, but unsafe when the caller may turn the
        empty list into NOT COVERED.  The boolean keeps those two facts
        separate while the public ``distinct_values`` API stays unchanged.

        `con`, when given, is an open connection lent by a caller looping
        over many columns, and is left open.
        """
        if not self.has(table, column):
            return [], False
        lent = con is not None
        cur = None
        try:
            con = con if lent else self.connect()
            cur = con.cursor()
            cur.execute(
                f"SELECT DISTINCT `{column}` FROM `{table}` "
                f"WHERE `{column}` IS NOT NULL LIMIT %s",
                (int(limit or self.tuning("DATAGORA_SAMPLE_VALUES",
                                          self.SAMPLE_VALUES)),))
            return [r[0] for r in cur.fetchall()], True
        except Exception:
            return [], False
        finally:
            if cur is not None:
                try:
                    cur.close()
                except Exception:
                    pass
            if con is not None and not lent:
                try:
                    con.close()
                except Exception:
                    pass

    def _lent_connection(self):
        """One connection for a loop of lookups, or None when none opens.

        Every lookup used to open its own. Measured by the realistic fake's
        profile, the schema text of the demo library opened 39 connections
        for its sample values, about three seconds on Windows where each
        one loads the certificate store; a value sweep over a 700-table
        schema opened 1780. The loop borrows this one and closes it once."""
        try:
            return self.connect()
        except Exception:
            return None

    @staticmethod
    def _close(con):
        if con is not None:
            try:
                con.close()
            except Exception:
                pass

    # how few distinct values a column may hold and still be a closed
    # vocabulary rather than free text. Deliberately small: a status, a
    # kind, a state, a grade. A column of names or descriptions never
    # fits under it. A default, not a constant: DATAGORA_ENUMERATION
    # moves it for a schema that spells its states differently.
    ENUMERATION = 12

    # the types a database uses to record WHEN something happened, which
    # is also how it records whether it has happened at all
    MOMENTS = ("date", "datetime", "timestamp", "time", "year")

    def tuning(self, key, default):
        """A number a deployment may change, read where it is used.

        Read at the moment of use and not at import, so a container and a
        test get the same answer from the same variable, and so nothing
        here is a constant a customer would have to edit the source to
        move. An empty value counts as unset: compose passes a variable it
        cannot resolve as an empty string, and taking that for an answer
        would set the ceiling to nothing at all. Anything unreadable, or
        zero, or negative, falls back to the default rather than
        disabling a check by accident.
        """
        raw = str(os.environ.get(key) or "").strip()
        if not raw:
            return default
        try:
            value = int(raw)
        except ValueError:
            return default
        return value if value > 0 else default

    def records_a_state(self, table, column):
        """Does this column record a state, rather than name a thing?

        Two shapes, and a database has only these two for the purpose:

        A small closed vocabulary. Asked one past the ceiling, so a short
        answer is itself the proof: a column that returns three rows when
        thirteen were allowed holds three values and nothing else. That is
        `loans.status` holding borrowed, returned, late.

        A moment. A date is how a table says whether a thing has happened
        yet, by holding NULL until it does, and when it happened, by
        ordering. That is `loans.returned_at`.

        This exists because the value step was allowed to withdraw a menu
        on the model's word and withdrew two correct ones. Measured on
        gemma3:4b, "how many loans are still open" was offered
        loans.status and loans.returned_at, which are exactly the two
        columns that answer it, and the model said no. A 4b model asked a
        semantic question will sometimes be wrong, and the cost of being
        wrong here is a client told their data cannot answer something it
        answers in one query.

        So its word is overruled on the two shapes that are not a matter
        of opinion. Whether `status` holds three values and whether
        `returned_at` is a date are facts in the catalogue, re-checkable
        in one query, which is the standard this component holds itself
        to everywhere else.
        """
        # a key identifies a row, it does not describe one, and on a small
        # table its values pass for a closed vocabulary by accident
        if self.is_a_key(table, column):
            return False
        if self.column_type(table, column) in self.MOMENTS:
            return True
        # a vocabulary the dictionary declares is closed by definition,
        # and saying so costs no query
        if self.enum_labels(table, column):
            return True
        # a number is an amount, however few of them there are. Measured on
        # the enterprise database: sales_order_lines.quantity holds 1, 2, 3,
        # 5, 10, 20 and 50, passed for a closed vocabulary, and a menu built
        # on it was kept as if quantities were states. A flag, stored as a
        # bit or a tinyint (is_planned, is_quality_related), is the one
        # number that is a state.
        kind = self.column_type(table, column)
        if (any(k in kind for k in self.NUMERIC)
                and not kind.startswith(("bit", "tinyint", "bool"))):
            return False
        ceiling = self.tuning("DATAGORA_ENUMERATION", self.ENUMERATION)
        values = self.distinct_values(table, column, limit=ceiling + 1)
        return 0 < len(values) <= ceiling

    def decide_on_values(self, phrase, candidates, question="", llm=None, **kw):
        """Can this concept be read off these columns' real values?

        Returns (verdict, table, column, why) with verdict one of "yes",
        "no" or "unknown". "unknown" whenever anything at all went wrong,
        because not knowing must never be reported as an absence.

        The model names ONE column, the one whose values decide the
        concept, and never a join. A candidate that is a key is replaced by
        the column it stands for before the model sees anything, so a
        genre asked about through books.genre_id is shown as the names in
        genres.name, marked with the join that reaches them. How to get
        from the question's table to that column is the catalogue's
        answer, in its foreign keys; a model asked to describe a join path
        describes one, whether or not it exists.

        `llm` and `kw` (timeout, num_predict) let a caller bound the call:
        the verdict agent asks it without thinking and within its time.
        """
        if str(os.environ.get("DATAGORA_ASK_VALUES", "on")).lower() in (
                "off", "0", "false", "no"):
            return ("unknown", None, None, "")
        shown = []
        offered = {}
        for candidate in self.through_keys(candidates):
            table = candidate.get("table")
            column = candidate.get("column")
            if not self.has(table, column):
                continue
            key = ((table or "").lower(), (column or "").lower())
            offered[key] = (table, column)
            values, checked = self._distinct_values_checked(table, column)
            if not checked:
                return ("unknown", None, None,
                        f"could not read values from {table}.{column}")
            if not values:
                continue
            said = self.means(table, column)
            reached = candidate.get("via")
            labels = self.enum_labels(table, column)
            shown.append(
                f"- {table}.{column}"
                + (f" ({said})" if said else "")
                + (f" [reached through {reached}]" if reached else "")
                + ": " + ", ".join(
                    str(v)[:40] + (f" = {labels[str(v)]}"
                                   if str(v) in labels else "")
                    for v in values))
        if not shown:
            return ("unknown", None, None, "no values to look at")
        asked = [f"Concept: {phrase}"]
        if question:
            asked.append(f"Question as asked: {question}")
        asked.append("Candidate columns and the distinct values they hold:")
        asked.extend(shown)
        try:
            user = chr(10).join(asked)
            model = llm if llm is not None else self.llm
            if self._accepts_schema():
                reply = model.json(self.DECIDE_SYSTEM, user,
                                   schema=self.decide_schema(offered), **kw)
            else:
                reply = model.json(self.DECIDE_SYSTEM, user, **kw)
        except Exception:
            return ("unknown", None, None, "the model could not be reached")
        if not isinstance(reply, dict) or "decidable" not in reply:
            return ("unknown", None, None, "the model gave no decision")
        table = reply.get("table")
        column = reply.get("column")
        why = str(reply.get("why") or "").strip()
        if reply.get("decidable"):
            # Validate against what was offered, not merely against the
            # schema.  It is otherwise possible for the model to select a
            # real but unseen column.  The lookup also canonicalises casing,
            # so Products.Product_Name cannot manufacture a new option next
            # to products.product_name.
            chosen = offered.get(((table or "").lower(),
                                  (column or "").lower()))
            if chosen is None:
                return ("unknown", None, None,
                        why or "the model selected a column it was not shown")
            return ("yes", chosen[0], chosen[1], why)
        return ("no", None, None, why)

    def decide_schema(self, offered):
        """The shape of a value decision, limited to the columns offered.

        `why` first, for the reason the detection reply puts `reason`
        first: a constrained decoder writes keys in schema order, so the
        model says what it saw before it rules. The table and the column
        can only be ones it was shown, or empty when it rules no."""
        tables = sorted({t for t, _c in offered.values()})
        columns = sorted({c for _t, c in offered.values()})
        return {"type": "object",
                "properties": {
                    "why": {"type": "string"},
                    "decidable": {"type": "boolean"},
                    "table": {"type": "string", "enum": tables + [""]},
                    "column": {"type": "string", "enum": columns + [""]}},
                "required": ["why", "decidable", "table", "column"]}

    def means(self, table, column=None):
        """What the dictionary says, or an empty string."""
        if column is None:
            return self.meanings["tables"].get((table or "").lower(), "")
        return self.meanings["columns"].get(
            f"{(table or '').lower()}.{(column or '').lower()}", "")

    # How many real values each column shows the model. Not a question of
    # model size: AmbiSQL, which runs on GPT-5 and Claude, shows three. It
    # is a token budget, three values times every column of the schema in
    # every prompt, which is nothing on fifty columns and ten thousand
    # tokens on five hundred. DATAGORA_SCHEMA_SAMPLES moves it; 0 sends no
    # values at all, which is the setting for a schema holding personal
    # data and a model endpoint outside the building.
    SCHEMA_SAMPLES = 5
    SAMPLE_WIDTH = 40

    @property
    def foreign_keys(self):
        """{(table, column): (referenced_table, referenced_column)}.

        Shown to the model because a join is otherwise invisible to it: a
        column named book_id says nothing about which table it leads to,
        and a concept that lives one table away could never be proposed.
        Read once, from the catalogue; unreadable leaves it empty."""
        if self._foreign_keys is None:
            found = {}
            try:
                con = self.connect()
                cur = con.cursor()
                try:
                    cur.execute(
                        """SELECT table_name, column_name,
                                  referenced_table_name, referenced_column_name
                           FROM information_schema.key_column_usage
                           WHERE table_schema=%s
                             AND referenced_table_name IS NOT NULL""",
                        (self.schema,))
                    for t, c, rt, rc in cur.fetchall():
                        found[((t or "").lower(), (c or "").lower())] = (rt, rc)
                finally:
                    cur.close()
                    con.close()
            except Exception:
                found = {}
            self._foreign_keys = found
        documented = {
            pair: (rt, rc)
            for pair, (rt, rc, _about) in self._documented("links").items()
            if self.has(*pair) and self.has(rt, rc)}
        if not documented:
            return self._foreign_keys
        # the catalogue wins where both speak: a declared constraint is
        # enforced, a documented one is only written down
        return {**documented, **self._foreign_keys}

    @property
    def samples(self):
        """{(table, column): [value, ...]}, a few real values per column.

        This is what tells a model that genres.genre_id holds 1, 2, 3 and
        genres.name holds Fantasy, Poetry, History, which no identifier
        says on its own. Proposing `genre_id` for a question about genres
        was the measured symptom of sending names alone. Read once per
        clarifier, never per question."""
        if self._samples is None:
            # 0 is a real answer here, "send no values", which tuning()
            # would otherwise read as invalid and replace with the default
            raw = str(os.environ.get("DATAGORA_SCHEMA_SAMPLES") or "").strip()
            limit = 0 if raw == "0" else self.tuning(
                "DATAGORA_SCHEMA_SAMPLES", self.SCHEMA_SAMPLES)
            found = {}
            if limit:
                con = self._lent_connection()
                try:
                    for table, cols in self.columns.items():
                        for column, _type in cols:
                            values, _ok = self._distinct_values_checked(
                                table, column, limit=limit, con=con)
                            if values:
                                found[(table.lower(), column.lower())] = [
                                    str(v)[:self.SAMPLE_WIDTH]
                                    for v in values]
                finally:
                    self._close(con)
            self._samples = found
        return self._samples

    def schema_text(self, tables=None):
        """The catalogue as the model sees it: one line per column.

        Every table, in name order, or only `tables`, in the order given.
        Which tables to send when the whole does not fit the model's
        window is schema_for's business; see focus.py."""
        blocks = self._table_blocks()
        names = sorted(blocks) if tables is None else [
            t for t in tables if t in blocks]
        return chr(10).join(blocks[t] for t in names)

    def _table_blocks(self):
        """{table: its lines}, the catalogue as the model sees it.

        Each line carries what an analyst would look at before choosing a
        column: its type, whether it is a key and where a foreign key
        leads, a few values it really holds, and what it is documented to
        mean. AmbiSQL renders a column the same way, as name, primary key,
        type, description and sample values, and it is the part of their
        design that transfers whatever the model: it is evidence in the
        prompt, not length.

        Descriptions belong here because that is where they pay: the model
        picks its candidate columns from this text, and a column it
        understands is a column it stops guessing about."""
        keys, fks, samples = self.keys, self.foreign_keys, self.samples
        # which code's rows continue in which table, asked of the data for
        # every coded column before the text is written, on one connection
        pending = [(t, c) for (t, c) in self._documented("enums")
                   if (t, c) not in self._continues
                   and self._documented("children").get(t)]
        if pending:
            con = self._lent_connection()
            try:
                for t, c in pending:
                    self.continues_in(t, c, con)
            finally:
                self._close(con)
        linked = self._graph_links()
        poly = self.polymorphic_links()
        blocks = {}
        for table, cols in sorted(self.columns.items()):
            note = self.means(table)
            lines = [f"TABLE {table}" + (f"  -- {note}" if note else "")]
            width = max((len(c) for c, _ in cols), default=0)
            for column, dtype in cols:
                key = (table.lower(), column.lower())
                parts = [f"  {column.ljust(width)}  {str(dtype or '').lower()}"]
                if key in poly:
                    parts.append("; ".join(f"-> {rt}.{rc} when {cond}" if cond
                                           else f"-> {rt}.{rc}"
                                           for rt, rc, cond in poly[key]))
                elif key in fks:
                    rt, rc = fks[key]
                    parts.append(f"-> {rt}.{rc}")
                elif key in linked:
                    rt, rc = linked[key]
                    parts.append(f"-> {rt}.{rc}")
                elif key in keys:
                    parts.append("PRIMARY KEY")
                labels = self.enum_labels(table, column)
                if labels:
                    # the dictionary's codes rather than a sample: all of
                    # them, each with what it means, and none of it data
                    parts.append("e.g. " + ", ".join(
                        f"{code} ({label})"
                        for code, label in list(labels.items())[:12]))
                elif key in samples:
                    parts.append("e.g. " + ", ".join(samples[key]))
                said = self.means(table, column)
                going = self.continues_in(table, column)
                if going:
                    said = " ".join(p for p in (said, ", ".join(
                        f"{code} rows continue in {sub}"
                        for code, (sub, _join) in going.items()) + ".") if p)
                if said:
                    parts.append(f"-- {said}")
                lines.append("  ".join(parts))
            blocks[table] = chr(10).join(lines)
        return blocks

    def _graph_links(self):
        """{(table, column): (other table, other column)}, the joins the
        Neo4j graph holds and the catalogue does not declare, shown the
        way a foreign key is: a reference whose target depends on a code
        is often only written down there."""
        # an edge with a fifth element, the condition of a polymorphic link,
        # is no foreign key: polymorphic_links shows it with its condition
        return {(e[0].lower(), e[1].lower()): (e[2], e[3])
                for e in self.graph_edges
                if len(e) >= 4 and not (len(e) > 4 and e[4])
                and "," not in str(e[1]) and "," not in str(e[3])}

    def polymorphic_links(self):
        """{(table, column): [(other table, other column, condition)]}, the
        columns whose target depends on a type code: object_id leads to
        sales_orders when object_type is ORDER, to support_tickets when it
        is TICKET. From the dictionary's Polymorphic relationships and the
        graph's edges that hold a condition; the condition is written
        without its table ("object_type = 'ORDER'")."""
        out = {}

        def add(table, column, other, other_column, condition):
            if not (self.has(table, column) and self.has(other, other_column)):
                return
            key = (str(table).lower(), str(column).lower())
            targets = out.setdefault(key, [])
            if all((t, c) != (other, other_column) for t, c, _w in targets):
                targets.append((other, other_column, condition))

        for (table, column), targets in (self._documented("polymorphic") or {}).items():
            for other, other_column, about in targets:
                when = (about or {}).get("when") or {}
                condition = (f"{when['column']} = '{when.get('value', '')}'"
                             if when.get("column") else "")
                add(table, column, other, other_column, condition)
        for e in self.graph_edges:
            if len(e) > 4 and e[4]:
                condition = str(e[4])
                prefix = f"{e[0]}."
                if condition.lower().startswith(prefix.lower()):
                    condition = condition[len(prefix):]
                add(e[0], e[1], e[2], e[3], condition)
        return out

    def _short_blocks(self):
        """{table: two lines}, the short form of a table in a cut schema:
        its name and what it means, then its column names, each foreign key
        with where it leads. About a quarter of the full block (89 tokens
        a table against 345 on the 156-table Enterprise base), so a table
        that joins the ones a question names can be shown when there is no
        room for it whole; see focus.choose."""
        fks, linked = self.foreign_keys, self._graph_links()
        poly = self.polymorphic_links()
        blocks = {}
        for table, cols in sorted(self.columns.items()):
            note = self.means(table)
            names = []
            for column, _dtype in cols:
                key = (table.lower(), column.lower())
                target = fks.get(key) or linked.get(key)
                if key in poly:
                    names.append(f"{column}->" + "|".join(f"{t}.{c}" for t, c, _w in poly[key]))
                else:
                    names.append(f"{column}->{target[0]}.{target[1]}" if target
                                 else column)
            blocks[table] = (f"TABLE {table}" + (f"  -- {note}" if note else "")
                             + chr(10) + "  columns: " + ", ".join(names))
        return blocks

    # ------------------------------------------- a schema that does not fit
    # Room kept in the window for the reply: the JSON verdict and its
    # reason. The rest of the arithmetic is in schema_room.
    REPLY_ROOM = 1024
    # and, for a model that thinks first, room for its thinking, which
    # Ollama keeps in the same window: a 15K-token schema in a 16K window
    # left it a few hundred tokens to reason in. Less than the cap on the
    # reply (llm.MAX_THINKING_TOKENS, 8192, thinking and answer together)
    # on purpose: gemma4:31b thought 1 200 characters at the median and
    # 4 772 at the most on the 251-table Warehouse questions, about 1 500
    # tokens, and this room, the reply's and the tenth kept back make about
    # 6 000. Keeping the whole cap free would take 2 800 tokens from the
    # schema, and on the Enterprise questions the cut that shows every
    # table a question needs went from 35 of 37 to 29. A reply that runs
    # to the cap is a model that looped, and fails anyway.
    THINK_ROOM = 4096
    # characters a token in the prose of a system prompt and a question,
    # measured with Gemma's tokenizer (the detection prompt: 4 167
    # characters, 1 116 tokens); the schema's own rate is in focus.py
    PROSE_CHARS_PER_TOKEN = 3.5

    def schema_room(self, question, system=None, llm=None):
        """The tokens the schema may take in the model's window, or None
        when there is no limit to keep to: a model object that does not
        say its window (a caller's own callable), or DATAGORA_FOCUS=off."""
        if str(os.environ.get("DATAGORA_FOCUS") or "").strip().lower() in (
                "off", "0", "false", "no"):
            return None
        model = llm if llm is not None else self.llm
        window = getattr(model, "num_ctx", None)
        if not isinstance(window, int) or window <= 0:
            return None
        system = self.system if system is None else system
        used = (len(system or "") + len(question or "") + 200) / self.PROSE_CHARS_PER_TOKEN
        # the counts are estimates, so a tenth is kept back
        thinks = getattr(model, "thinks", None)
        reserve = self.REPLY_ROOM + (self.THINK_ROOM if callable(thinks) and thinks() is True else 0)
        room = int((window - reserve - used) * 0.9)
        cap = self.tuning("DATAGORA_FOCUS_MAX_TOKENS", 0)
        if cap:
            room = min(room, int(cap))
        return max(room, 0)

    def schema_for(self, question, system=None, llm=None):
        """(the schema to send with this question, the tables in it).

        The whole schema, and None for the tables, when it fits the
        model's window and has no more than focus.FROM_TABLES tables:
        nothing changes for a database of ordinary size. Otherwise the
        tables related to the question, most related first, as many as fit,
        the first focus.FULL_TABLES whole and the others in short form
        (_short_blocks), and the list of them; see focus.py for how they
        are chosen.
        `system` and `llm` are the prompt and the model the schema is sent
        with, when they are not this clarifier's own."""
        if __package__:
            from . import focus
        else:
            import focus
        blocks = self._table_blocks()
        room = self.schema_room(question, system, llm)
        if not focus.wanted(self, blocks, room):
            self.last_focus = self.last_shown = None
            return chr(10).join(blocks[t] for t in sorted(blocks)), None
        short = self._short_blocks()
        kept, report = focus.choose(self, question, blocks, room, self._token_scale,
                                    short=short)
        self.last_focus, self.last_shown = report, list(kept)
        focus.log.info(
            "focus: %d tables, about %d tokens, in a room of %d: kept %d, "
            "%d in short form (about %d tokens), %d of them at %.0f%% of the "
            "best score or more, by %s%s", report["tables"],
            report["tokens_whole"], room, report["kept"], len(report["short"]),
            report["tokens_kept"], report["relevant"], 100 * report["share"],
            report["by"],
            f"; related but left out for room: {report['relevant_left_out']}"
            if report["relevant_left_out"] else "")
        in_short = set(report["short"])
        text = chr(10).join(short[t] if t in in_short else blocks[t] for t in kept)
        tail = focus.note(len(blocks) - len(kept), len(in_short))
        return (text + (chr(10) + tail if tail else "")), kept

    def json_with_schema(self, question, system, llm, user_of, reply_schema=False):
        """A model's JSON reply to a prompt that carries the schema.

        The schema is the one schema_for gives for this model's window, and
        `user_of(schema)` writes the user message around it. The estimate
        of what the schema costs is corrected from the count the server
        returns, so the next prompt is cut to the real size; and when the
        server still read the whole window and dropped the rest, the
        question is asked once more with a smaller cut rather than lost.
        `reply_schema` restricts the reply to the tables shown."""
        scale = self._token_scale
        for attempt in (1, 2):
            # which tables the model is shown, as a step of the trace
            with _step("schema", as_type="retriever",
                       input={"question": question,
                              "tables": len(self.columns)}) as traced:
                schema, shown = self.schema_for(question, system, llm)
                report = self.last_focus or {}
                traced.update(output=(
                    {"sent": "the whole schema", "tables": len(self.columns)}
                    if shown is None else
                    {"sent": f"{len(shown)} of {len(self.columns)} tables",
                     "tables": shown[:60], "found_by": report.get("by"),
                     "tokens": report.get("tokens_kept"),
                     "room": report.get("room")}))
            user = user_of(schema)
            if reply_schema:
                reply = llm.json(system, user, schema=self.reply_schema(shown))
            else:
                reply = llm.json(system, user)
            error = str(getattr(llm, "last_error", "") or "")
            if reply is not None or "did not fit" not in error or attempt == 2:
                break
            self._token_scale = min(3.0, self._token_scale * 1.3)
        if attempt == 2:
            # the smaller cut served this question only. Kept, the 1.3 stayed
            # on the GPU for the rest of the job after one long question, and
            # every later question was shown fewer tables. What the reply
            # really cost is learned just below, when it can be (no thinking).
            self._token_scale = scale
        self._learn_tokens(llm, system, user, schema)
        return reply

    @staticmethod
    def _thought(llm):
        """Whether the model's last reply came with thinking."""
        server = getattr(llm, "last_server", None)
        return bool(isinstance(server, dict) and server.get("thinking_chars"))

    def _learn_tokens(self, llm, system, user, schema):
        """Correct the schema's estimated cost from what the server counted,
        a twentieth over it to be safe. A prompt the server cut says nothing
        about its size and teaches nothing; nor does a reply with thinking,
        whose count on Ollama took the thinking in: learned from it, the
        scale climbed to 1.6 over a run on gemma4:31b, where without
        thinking the estimate came to 0.97 to 0.99 of the count. The schema
        then looked 1.6 times its size, a question late in a run was shown
        9 to 14 tables where an early one had 17, and the verdicts changed
        with the order of the questions."""
        if __package__:
            from . import focus
        else:
            import focus
        counted = getattr(llm, "last_prompt_tokens", None)
        if (not isinstance(counted, int) or counted <= 0
                or getattr(llm, "last_error", "") or self._thought(llm)):
            return
        estimated = focus.tokens(schema)
        if estimated < 1000:
            return             # too small to say anything about the rate
        prose = (len(system or "") + len(user or "") - len(schema or "")) \
            / self.PROSE_CHARS_PER_TOKEN
        self._token_scale = min(3.0, max(0.6, (counted - prose) / estimated * 1.05))

    @property
    def graph_edges(self):
        """[(table, column, other table, other column)], the joins of the
        database's Neo4j graph, child first; [] without one. Read once,
        never fatal: a graph that cannot be reached leaves the schema as
        the catalogue and the dictionary describe it."""
        if self._graph_edges is None:
            found = []
            if (self.profile is not None
                    and getattr(self.profile, "neo4j_uri", None)):
                driver = None
                try:
                    if __package__:
                        from .schema_graph import Graph
                    else:
                        from schema_graph import Graph
                    driver = self.profile.connect_neo4j(timeout=5)
                    graph = Graph.from_profile(self.profile, driver)
                    conditions = getattr(graph, "conditions", None) or {}
                    # a fifth field, the type code a polymorphic edge holds
                    # under, only when there is one
                    found = [(f, lc, t, rc) + ((conditions[(f, lc, t, rc)],)
                                               if conditions.get((f, lc, t, rc)) else ())
                             for f, lc, t, rc, *_rest in graph.edges
                             if f and t and lc and rc]
                except Exception:
                    found = []
                finally:
                    if driver is not None:
                        try:
                            driver.close()
                        except Exception:
                            pass
            self._graph_edges = found
        return self._graph_edges

    def table_links(self):
        """{table: {tables one join away}}, in lower case, both ways: the
        declared foreign keys, the dictionary's links and the Neo4j graph."""
        links = {}

        def tie(a, b):
            a, b = str(a or "").lower(), str(b or "").lower()
            if a and b and a != b:
                links.setdefault(a, set()).add(b)
                links.setdefault(b, set()).add(a)

        for (table, _column), (other, _other_column) in self.foreign_keys.items():
            tie(table, other)
        for edge in self.graph_edges:
            table, other = edge[0], edge[2]
            tie(table, other)
        for (table, _column), targets in self.polymorphic_links().items():
            for other, _other_column, _condition in targets:
                tie(table, other)
        return links

    @property
    def reranker(self):
        """The reranker the settings page chose (rerank.py), or None, which
        leaves every vector order as it is. Read once, never fatal."""
        if not getattr(self, "_reranker_checked", False):
            self._reranker_checked = True
            try:
                if __package__:
                    from .rerank import Reranker
                else:
                    from rerank import Reranker
                self._reranker = Reranker.configured()
            except Exception:
                self._reranker = None
        return getattr(self, "_reranker", None)

    @property
    def corpus(self):
        """The database's corpus of answered questions (Qdrant), or None."""
        if not self._corpus_checked:
            self._corpus_checked = True
            if (self.profile is not None
                    and getattr(self.profile, "qdrant_url", None)):
                try:
                    if __package__:
                        from .recall import Recall
                    else:
                        from recall import Recall
                    found = Recall.from_profile(self.profile)
                    self._corpus = (found if found.available() and found.exists()
                                    else None)
                    # unreached, not absent: kept, and taken once it answers
                    self._corpus_waiting = None if found.available() else found
                except Exception:
                    self._corpus = None
        elif self._corpus is None and getattr(self, "_corpus_waiting", None) is not None:
            # Qdrant down at the first question left the corpus off for the
            # life of the clarifier (review of 26 October). The recall tries
            # it again after a while; until then this costs nothing
            waiting = self._corpus_waiting
            if waiting.available():
                self._corpus_waiting = None
                try:
                    self._corpus = waiting if waiting.exists() else None
                except Exception:
                    self._corpus = None
        return self._corpus

    def has(self, table, column):
        table = (table or "").lower()
        for t, cols in self.columns.items():
            if t.lower() == table:
                return any(c.lower() == (column or "").lower() for c, _ in cols)
        return False

    def resembles_column(self, phrase):
        """Columns whose name echoes the words of the phrase.

        This guards the worst thing the component can say. Telling a user
        "this database has no equivalent" when the column is sitting
        there is more damaging than asking nothing, and a model that
        mis-classified a phrase will produce exactly that. So before any
        such claim is made, the schema is searched for it. Measured on
        the library schema, this is what stops "email addresses" being
        declared absent while members.email exists."""
        # punctuation comes off BEFORE the length test, and the floor is
        # three characters rather than four. Applied to the raw token, the
        # old order made "fee" invisible while "fee?" was visible, and no
        # column named sku, fee, qty, vat or tax could ever be found. A
        # denial then went out about a column sitting in the schema.
        #
        # Stopwords are dropped because the floor now admits words like
        # "the", and "the" is a substring of "theme": a false echo here
        # does not merely withhold a denial, it declares the question
        # answerable on the strength of a column that has nothing to do
        # with it.
        # RECALL. Any evidence at all counts, because this is used to
        # withhold a denial and being wrong in this direction costs a
        # question that asks for more rather than a false "cannot".
        return [f"{t}.{c}" for t, c, _how in self.column_evidence(phrase)]

    # Words that name the FORM a value takes rather than a concept of its
    # own. "email addresses" is answered by members.email, and "address"
    # there adds nothing the column name does not already say. Kept tiny
    # on purpose, and used only by the precise check below, where an extra
    # word left uncovered is exactly what should stop an ANSWER. A trade
    # extends it through the vocabulary file, key `generic_words`.
    GENERIC_WORDS = {"address", "number", "value", "code", "identifier",
                     "label", "record", "entry", "detail", "info",
                     "information", "list", "field", "data"}

    # Words that name the form of a classification, left out only before a
    # denial is considered: "blood type" was kept from one by movement_type.
    # Not added to GENERIC_WORDS, which also decides an ANSWER: there,
    # "supplier type" would pass on the suppliers table alone.
    FORM_WORDS = {"type", "kind"}

    # Words that mark the column a table NAMES its rows with, tried in this
    # order: genres.name, books.title. Used for one thing only, picking the
    # column a key stands for. A schema that names its rows otherwise (nom,
    # libelle, designation) adds its words through the vocabulary file, key
    # `label_words`; they are tried after these, and a table holding none
    # of them falls back to its first text column.
    LABEL_WORDS = ("name", "title", "label")

    # What each kind of evidence is allowed to do. Every kind withholds a
    # denial, which is the cheap direction to be wrong in. Only these point
    # at the column itself, by its name or by what it is documented to
    # hold, and so only these may be offered to a reader as the column
    # meant, or count towards declaring a question answerable. The other two
    # point at a neighbourhood: a table whose description mentions the
    # word, a column whose meaning is close.
    SUGGESTS = ("exact", "token", "table", "described")

    @staticmethod
    def _singular(word):
        """One spelling per word, applied identically on both sides.

        Not a lemmatiser and not trying to be: it only has to put a phrase
        word and an identifier token into the same form, and it does the
        same thing to both, so "status" becoming "statu" on each side still
        matches."""
        w = word.lower()
        if len(w) > 4 and w.endswith("ies"):
            return w[:-3] + "y"
        if len(w) > 4 and w.endswith("sses"):
            return w[:-2]
        if len(w) > 3 and w.endswith(("xes", "zes", "ches", "shes")):
            return w[:-2]
        if len(w) > 3 and w.endswith("s") and not w.endswith("ss"):
            return w[:-1]
        return w

    @classmethod
    def _identifier_tokens(cls, name):
        """genre_id -> {genre, id}; quantityOnHand -> {quantity, on, hand}.

        The old test was a substring search on the raw identifier, so
        "genre" found genre_id, "the" found theme, and "id" could have
        found almost anything. An identifier is words joined together, and
        it is compared as words."""
        spaced = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", str(name or ""))
        return {cls._singular(t) for t in re.split(r"[^A-Za-z0-9]+", spaced)
                if t}

    def _content_words(self, phrase):
        """The words of a phrase that carry meaning, in one spelling.

        Split the way an identifier is split, on anything that is not a
        letter or a digit. Split on spaces, "member's" stayed one word that
        no column could ever match, and "city/region" was neither city nor
        region."""
        stop = self.words_for("stopwords", self.STOPWORDS)
        out = set()
        for w in re.split(r"[^0-9a-zà-öø-ÿ]+", str(phrase or "").lower()):
            if len(w) >= 3 and w not in stop:
                out.add(self._singular(w))
        return out

    def _catalogue_table(self, name):
        """The catalogue's own spelling of a table name, or the name."""
        low = (name or "").lower()
        return next((t for t in self.columns if t.lower() == low), name)

    def _label_columns(self, table):
        """The columns that name the rows of a table, rather than key them.

        What "genre" means when it matches the TABLE genres: the reader
        wants genres.name, and genre_id is the one column that could never
        answer it. Text columns that are not keys, in catalogue order."""
        cols = next((c for t, c in self.columns.items()
                     if t.lower() == (table or "").lower()), [])
        return [c for c, dtype in cols
                if not self.is_a_key(table, c)
                and any(k in str(dtype).lower()
                        for k in ("char", "text", "enum"))]

    def label_column(self, table):
        """The one column that names the rows of a table, or None.

        genres gives name, books gives title. The label words are tried in
        order across every text column before the next word is, so a table
        holding both `title` and `subtitle_note` still gives title; with
        none of them, the first text column that is not a key."""
        labels = self._label_columns(table)
        if not labels:
            return None
        extra = sorted(self.vocabulary.get("label_words", set())
                       - set(self.LABEL_WORDS))
        for word in list(self.LABEL_WORDS) + extra:
            wanted = self._singular(word)
            for col in labels:
                if wanted in self._identifier_tokens(col):
                    return col
        return labels[0]

    def through_keys(self, candidates):
        """The candidates, with every key replaced by the column it stands for.

        A key identifies a row, and a question never asks for one. "genre"
        proposed as books.genre_id means the name of the genre that number
        points at, genres.name, which is one join away. The join is read
        from the catalogue's foreign keys and carried as `via`, so what the
        SQL stage is handed is a path that exists rather than one a model
        described.

        A foreign key leads to the label column of the table it references.
        A primary key that references nothing stands for its own table's
        label column. A key whose table names nothing in text is kept as it
        was: dropping the candidate would lose the reading, which is worse
        than an awkward option.

        One hop, deliberately. A concept two joins away is rare in a
        question, and a longer path chosen by rule is a guess about which
        route the asker meant."""
        out, seen = [], set()
        for c in candidates or []:
            if not isinstance(c, dict):
                continue
            item = dict(c)
            table, column = c.get("table"), c.get("column")
            if table and column and not self.has(table, column):
                moved = self._one_join_away(table, column)
                if moved:
                    table = moved[0]
                    item["table"], item["via"] = moved
            if self.has(table, column) and self.is_a_key(table, column):
                fk = self.foreign_keys.get(((table or "").lower(),
                                            (column or "").lower()))
                target = self._catalogue_table(fk[0] if fk else table)
                label = self.label_column(target)
                if label:
                    item["table"], item["column"] = target, label
                    if fk:
                        item["via"] = f"{table}.{column} = {fk[0]}.{fk[1]}"
            pair = ((item.get("table") or "").lower(),
                    (item.get("column") or "").lower())
            if pair in seen:
                continue
            seen.add(pair)
            out.append(item)
        return out

    def _one_join_away(self, table, column):
        """(table, join) for a column the model put on the wrong table, when
        exactly one table joined to it holds a column of that name.

        Measured on the shipments tables: "which road shipments are still in
        transit" was proposed as road_shpmnt.state_code, while state_code is
        on shpmnt, the parent road_shpmnt continues. The candidate was
        thrown away as not existing, nothing else could hold the phrase, and
        the question was reported NOT COVERED. The column exists one join
        away, which is a fact of the catalogue, so it is used there and the
        join is carried. Two tables holding it is a guess, and is left."""
        low = (table or "").lower()
        found = []
        for (t, c), (rt, rc) in self.foreign_keys.items():
            if t == low:
                other, join = rt, f"{table}.{c} = {rt}.{rc}"
            elif (rt or "").lower() == low:
                other, join = t, f"{t}.{c} = {table}.{rc}"
            else:
                continue
            if self.has(other, column):
                found.append((self._catalogue_table(other), join))
        names = {t.lower() for t, _j in found}
        return found[0] if len(names) == 1 else None

    @property
    def index(self):
        """The optional column index, or None. Never fatal.

        Built for a profile that names a Qdrant, unless
        DATAGORA_COLUMN_INDEX is off. On by default since it was measured:
        at its bar no unrelated phrase passed and 7 of 13 synonyms did, and
        its only effect is to withhold a denial. It costs an embedding call
        per phrase checked and a collection per schema."""
        if not self._index_checked:
            self._index_checked = True
            if __package__:
                from .recall import column_index_on
            else:
                from recall import column_index_on
            wanted = column_index_on()
            if (wanted and self.profile is not None
                    and getattr(self.profile, "qdrant_url", None)):
                try:
                    if __package__:
                        from .recall import ColumnIndex
                    else:
                        from recall import ColumnIndex
                    found = ColumnIndex.from_profile(self.profile)
                    self._index = found if found.ready(self) else None
                    # unreached, not absent: kept, and readied once it answers
                    self._index_waiting = None if found.available() else found
                except Exception:
                    self._index = None
        elif self._index is None and getattr(self, "_index_waiting", None) is not None:
            # as the corpus: Qdrant down at the first question left the
            # index off until a restart (review of 26 October)
            waiting = self._index_waiting
            if waiting.available():
                self._index_waiting = None
                try:
                    self._index = waiting if waiting.ready(self) else None
                except Exception:
                    self._index = None
        return self._index

    def similar_columns(self, phrase):
        """[(table, column, score)] close in meaning to the phrase, or [].

        Asked once per phrase and remembered, since the same phrase is
        looked up by several guards in one question."""
        key = str(phrase or "").strip().lower()
        if not key or self.index is None:
            return []
        if key not in self._similar:
            try:
                hits = self.index.similar(phrase)
            except Exception:
                hits = []
            self._similar[key] = [(t, c, s) for t, c, s in hits
                                  if self.has(t, c)
                                  and not self.is_a_key(t, c)]
        return self._similar[key]

    def question_tables(self, question, proposed=()):
        """The tables a question is about, and those one join away: the
        tables its words name, or, when none is named ("vessels" for
        sea_shpmnt), the ones the model proposed.

        None, the whole catalogue in view, on a database of no more than
        focus.FROM_TABLES tables, where every column is about the trade
        the questions are asked in, and when nothing is named or proposed.
        On one of hundreds, a word of the question finds columns in trades
        it has nothing to do with, and those are no evidence for it."""
        if __package__:
            from .focus import FROM_TABLES
        else:
            from focus import FROM_TABLES
        if len(self.columns) <= FROM_TABLES:
            return None
        words = self._content_words(question)
        named = {t for t in self.columns
                 if self._singular(t) in words
                 or (len(self._identifier_tokens(t)) > 1
                     and self._identifier_tokens(t) <= words)}
        proposed = {t for t in proposed if t in self.columns}
        links = self.table_links()
        # the model's own tables stay in view when they join the ones the
        # question names, within three joins: a word naming another table
        # ("per department") used to replace them, and the column the model
        # rightly chose (salary_history) was then judged absent. A table of
        # another trade, joined to nothing named, is still no evidence.
        base = set(named)
        if named and proposed:
            near, frontier = {t.lower() for t in named}, {t.lower() for t in named}
            for _hop in range(3):
                frontier = {u for t in frontier for u in links.get(t, ())} - near
                near |= frontier
            base |= {t for t in proposed if t.lower() in near}
        base = base or proposed
        if not base:
            return None
        scope = set(base)
        for table in base:
            scope |= {self._catalogue_table(u) for u in links.get(table.lower(), ())}
        return scope

    def column_evidence(self, phrase, semantic=True, tables=None):
        """Every column the phrase points at, and HOW it points at it.

        Returns [(table, column, how)], where `how` is one of:

          exact      a word IS the column's whole name: "fee" and fee
          token      a word is one part of the name: "quantity" and
                     quantity_on_hand
          table      a word names the table, so its label columns stand
                     in: "genre" and genres.name, "order items" and
                     order_items
          described  a word appears in what the column is documented to
                     mean
          about      a word appears in what the TABLE is documented to
                     hold, so its label columns stand in
          similar    the phrase is close in meaning to what the column
                     holds, by the optional column index; no shared word
                     at all is needed

        The callers need different amounts of this, which is the whole
        reason it is returned rather than collapsed into yes or no. A
        denial is withheld on any of it. A column is offered to a reader
        only on the kinds in SUGGESTS, and a question is declared
        answerable only on those and on complete coverage, in
        answers_directly below.

        `tables`, when given, is where to look; anywhere otherwise.

        Keys are left out of the name matches. A key's name is a counting
        artefact: books.book_id matching "book" said nothing about books.
        """
        # a word that only computes points at nothing: "total weight" was
        # not to be offered total_cost
        words = self._content_words(phrase) - self.operation_words()
        if not words:
            return []
        found, seen = [], set()

        def add(table, column, how):
            if (table, column) not in seen:
                seen.add((table, column))
                found.append((table, column, how))

        for table, cols in self.columns.items():
            if tables is not None and table not in tables:
                continue
            for col, _dtype in cols:
                if self.is_a_key(table, col):
                    continue
                tokens = self._identifier_tokens(col)
                whole = self._singular(col)
                if whole in words:
                    add(table, col, "exact")
                elif tokens & words and len(tokens) > 1:
                    add(table, col, "token")
            # a table is named by its whole name or, when that name is
            # several words, by all of them: "order items" is order_items,
            # "items" alone is not.
            parts = self._identifier_tokens(table)
            if (self._singular(table) in words
                    or (len(parts) > 1 and parts <= words)):
                for col in self._label_columns(table):
                    add(table, col, "table")
            # what it MEANS, when somebody wrote it down. `fee` is
            # invisible to a question about charges, and no amount of
            # matching on identifiers will ever fix that.
            for col, _dtype in cols:
                # a key's description is as empty as its name: "Geographic
                # point identifier" made geo_point_id the answer to a
                # question about geographic points
                if self.is_a_key(table, col):
                    continue
                said = self._said(table, col)
                if said.strip() and self._content_words(said) & words:
                    add(table, col, "described")
            # what the table is for, and the other names a team calls it
            said = " ".join([self.means(table)] + sorted(
                self._documented("aliases").get(table.lower()) or []))
            if said.strip() and self._content_words(said) & words:
                for col in self._label_columns(table):
                    add(table, col, "about")
        if semantic:
            for table, col, _score in self.similar_columns(phrase):
                if tables is None or table in tables:
                    add(table, col, "similar")
        return found

    def _entity_words(self, words, tables=None):
        """The words of a phrase that name a table: "copies" in "braille
        copies", "order items" in "cancelled order items". Any table of the
        catalogue, or only `tables` when given."""
        found = set()
        for table in (self.columns if tables is None else tables):
            parts = self._identifier_tokens(table)
            single = self._singular(table)
            if single in words:
                found.add(single)
            if len(parts) > 1 and parts <= words:
                found |= parts
        return found

    # Words that say how to compute or how the sentence runs, never what to
    # look up: an average is taken of a column, it is not one. Measured on
    # the 251-table database: "how many products" and "average lead time"
    # were sent back asking which column holds "many" and "average". They
    # were a list written by hand, which would always miss the next word;
    # they are generated now, see wording.py: the closed classes of English
    # whole, what SQL computes with every inflection, numbers written out.
    # The names stay for whatever read them from here.
    CALCULATION_WORDS = wording.OPERATION_FORMS
    LOGIC_WORDS = wording.FUNCTION_WORDS
    NUMBER_WORDS = wording.NUMBER_WORDS

    def operation_words(self):
        """Words that say how to compute or how the sentence runs, never
        what to look up (wording.py), with a trade's own from its
        vocabulary file, in this clarifier's spelling of a word.

        Taken out wherever a phrase is held against the schema, so the
        rule is one and the same everywhere: such a word neither needs a
        column (unaccounted_words, answers_directly), nor points at one
        (column_evidence, which offers the choices), nor counts as an echo
        that forbids a denial (withholds_denial), nor brings a table into
        the schema sent (focus.py). Built once per clarifier."""
        vocabulary = self.vocabulary
        if getattr(self, "_operation_words_of", None) is not vocabulary:
            self._operation_words = wording.operation_words(
                vocabulary.get("calculations", ()),
                vocabulary.get("logic_words", ()),
                normalise=self._singular)
            self._operation_words_of = vocabulary
        return self._operation_words

    @staticmethod
    def _stem(word):
        """A rougher form than _singular, only to tell one word in two of
        its forms: "supplied", "supplier" and "suppliers" come to one."""
        w = word.lower()
        for _ in range(3):
            for end in ("ying", "ied", "ier", "ies", "ing", "ed", "er", "es",
                        "s", "y"):
                if w.endswith(end) and len(w) - len(end) >= 4:
                    w = w[:-len(end)]
                    break
            else:
                break
        return w

    def unaccounted_words(self, phrase, tables=None):
        """What a phrase says beyond the table it names.

        The words that rank, quantify, judge or only name a value's form are
        left out too: they are operations or thresholds, not things a column
        has to hold. "braille copies" leaves "braille", "unpaid fines"
        leaves both words, "oldest members" leaves nothing.

        `tables`, when given, are the only tables a word may name: the ones
        the model proposed. On a database of hundreds, some table is named
        by almost any word, and "lead" in "average lead time" was taken for
        the CRM's `leads` and left out unchecked."""
        words = self._content_words(phrase)
        if not words:
            return set()
        drop = (self._entity_words(words, tables)
                | self.operation_words()
                | {self._singular(g) for g in self.words_for(
                    "generic_words", self.GENERIC_WORDS)}
                | {self._singular(w) for w in self.words_for(
                    "phrasings", self.PHRASINGS)}
                | {self._singular(w) for w in self.words_for(
                    "not_a_value", self.NOT_A_VALUE)})
        # a word in another form of a table it names is that table:
        # "supplied" in "products supplied by suppliers"
        kin = {self._stem(tok)
               for t in (tables if tables is not None else ())
               for tok in self._identifier_tokens(t)}
        kin |= {self._stem(w) for w in self._entity_words(words, tables)}
        # a number is compared, never held in a column's name: "in 2020",
        # "more than three"
        return {w for w in words - drop
                if not w.isdigit() and self._stem(w) not in kin
                and not self.is_a_superlative(w) and not self.is_a_judgement(w)}

    def _covers(self, table, column, words):
        """Whether a column's own name or meaning accounts for any of these
        words, as opposed to its table's."""
        own = (self._identifier_tokens(column)
               | self._content_words(self._said(table, column)))
        return bool(own & words)

    def answers_directly(self, phrase):
        """Columns that answer the phrase on their own, or [].

        PRECISION. Used to declare a flagged question answerable anyway,
        which is the one direction this component must not be wrong in
        lightly: it tells a team yes. So it needs more than a shared word.

        Every word of the phrase that carries meaning must be accounted
        for by the matched column, by its table, by what it is documented
        to mean, or be one of the few words that only name a value's form.
        "email addresses" passes on members.email. "theme park" does not
        pass on questions.theme, because nothing accounts for "park", and
        a question about theme parks is not a question about themes.

        Closeness in meaning never qualifies, however close. It is how a
        search finds the neighbourhood of a word, and a neighbourhood is
        not an answer.
        """
        # an average is taken of a column; "average rating per country" is
        # answered by rating and country, not by a column for "average"
        words = self._content_words(phrase) - self.operation_words()
        if not words:
            return []
        generic = self.words_for("generic_words", self.GENERIC_WORDS)
        # "highest elevation" is an ORDER BY on a measure the phrase names.
        # The ranking word is the operation and needs no column; what it
        # ranks must then be named by the measure itself, by its own name
        # or description, never by its table: "best supplier" ranks
        # suppliers by something nobody said, and is not answered by
        # suppliers.rating just because rating lives in suppliers.
        ranking = {w for w in words if self.is_a_superlative(w)}
        measured = words - ranking
        hits = []
        for table, column, how in self.column_evidence(phrase,
                                                       semantic=False):
            if how not in self.SUGGESTS:
                continue
            if ranking and measured and self._orderable(table, column):
                own = (self._identifier_tokens(column)
                       | self._content_words(self._said(table, column))
                       | {self._singular(g) for g in generic})
                if measured <= own:
                    hits.append(f"{table}.{column}")
                    continue
            # every kind of evidence may qualify; what makes this precise is
            # the coverage test below, not the kind. Refusing a match on part
            # of a name left "per country" unanswered while
            # suppliers.country_code sat in the schema, and it was never what
            # stopped "theme park": "park" being unaccounted for is.
            covered = (self._identifier_tokens(column)
                       | self._identifier_tokens(table)
                       | {self._singular(table)}
                       | self._content_words(self._said(table, column))
                       | {self._singular(g) for g in generic})
            if words <= covered:
                hits.append(f"{table}.{column}")
        return hits

    # evidence that a word is the name of a column or of a table
    NAMED = ("exact", "token", "table")

    def withholds_denial(self, phrase):
        """Whether the schema echoes the phrase enough to forbid a denial.

        The echo of resembles_column, on the words that carry meaning: a
        word that only names a value's form (type, kind, code, number) is
        left out first. Measured on a warehouse schema, "blood type" was
        never denied because "type" echoes movement_type, though "blood"
        echoes nothing and the data held none. Anything else is as before,
        on purpose: a stricter rule (every word echoed) also dropped
        "storage space", which capacity_units answers, and a false denial
        is the error this guard exists to prevent."""
        generic = {self._singular(g) for g in self.words_for(
            "generic_words", self.GENERIC_WORDS) | self.FORM_WORDS}
        words = self._content_words(phrase)
        # nor does a word that only computes: "count" echoing
        # container_count says nothing about what is being counted
        meaningful = [w for w in re.split(r"[^0-9a-zà-öø-ÿ]+", str(phrase or "").lower())
                      if w and self._singular(w) in
                      words - generic - self.operation_words()]
        # The phrase names a kind of column the schema has, by its last
        # word, and says which one with a word nothing in the schema
        # answers to: no name, no description, no neighbour in meaning.
        # Measured on the enterprise database: "employee engagement score"
        # was kept from a denial because "score" echoes nps_score and
        # csat_score, while "engagement" echoes nothing; the scores held
        # are other scores. The echo is of the kind, never of the thing.
        # Only on the head word's NAME: "gluten free" (free met in a
        # description) and "storage space" (the head echoing nothing) stay
        # withheld, as measured below.
        if len(meaningful) >= 2:
            head = meaningful[-1]
            named = any(how in ("exact", "token")
                        for _t, _c, how in self.column_evidence(head, semantic=False))
            if named and any(not self.column_evidence(w) for w in meaningful[:-1]):
                return False
        if not meaningful or len(meaningful) == len(words):
            return bool(self.resembles_column(phrase))
        if any(how == "similar" for _t, _c, how in self.column_evidence(phrase)):
            return True
        return bool(self.resembles_column(" ".join(meaningful)))

    def per_row_is_per_entity(self, candidates):
        """The column naming the entity, when each of its values occurs once.

        "Which vessels carried more than 10 containers?" reads two ways, per
        shipment or in total per vessel, and the two are one answer when no
        vessel made two shipments: the data then decides, as it does
        elsewhere, rather than a question to the asker. Measured on the
        warehouse data: 35 sea shipments, 35 vessels."""
        tables: dict = {}
        for c in candidates or []:
            t, col = c.get("table"), c.get("column")
            if t and col and self.has(t, col):
                tables.setdefault(t, set()).add(col)
        for table, cols in tables.items():
            measures = [c for c in cols if not self.is_a_key(table, c)
                        and any(k in self.column_type(table, c) for k in self.NUMERIC)]
            if not measures:
                continue
            # only a text column the model itself proposed: a label column
            # picked here would be the wrong entity for "total per category"
            names = [c for c in cols if c not in measures and not self.is_a_key(table, c)
                     and not any(k in self.column_type(table, c) for k in self.NUMERIC)]
            for col in names:
                if not self.has(table, col):
                    continue
                con = cur = None
                try:
                    con = self.connect()
                    cur = con.cursor()
                    cur.execute(f"SELECT COUNT(*) = COUNT(DISTINCT `{col}`) AND COUNT(*) > 0 "
                                f"FROM `{table}`")
                    row = cur.fetchone()
                    if row and int(row[0] or 0) == 1:
                        return f"{table}.{col}"
                except Exception:
                    continue
                finally:
                    for closing in (cur, con):
                        try:
                            if closing is not None:
                                closing.close()
                        except Exception:
                            pass
        return None

    NUMERIC = ("int", "decimal", "float", "double", "numeric", "real")

    def _orderable(self, table, column):
        """A number or a moment: something a ranking word can sort by."""
        kind = self.column_type(table, column)
        return kind in self.MOMENTS or any(k in kind for k in self.NUMERIC)

    def quantities(self, candidates):
        """The proposed columns that hold an amount one can add up: a
        number that is not a key. "container_count" is one; a member_id,
        however numeric, counts nothing."""
        return [f"{c.get('table')}.{c.get('column')}"
                for c in candidates or [] if isinstance(c, dict)
                and self.has(c.get("table"), c.get("column"))
                and not self.is_a_key(c.get("table"), c.get("column"))
                and any(k in self.column_type(c.get("table"), c.get("column"))
                        for k in self.NUMERIC)]

    def column_type(self, table, column):
        for t, cols in self.columns.items():
            if t.lower() == (table or "").lower():
                for c, d in cols:
                    if c.lower() == (column or "").lower():
                        return d.lower()
        return ""

    def near_values(self, table, column, value, limit=4):
        """Values really present in that column that resemble the literal.
        This is what turns 'New York City' into the choice between the
        forms the database actually stores.

        Numeric columns are refused outright. A model that mistakes a
        vague phrase for a literal and points at an id column would
        otherwise turn the primary keys it happens to find into
        multiple-choice options, which is how "how many products do we
        have?" once came back offering 197, 170 and 317."""
        found, _checked = self._near_values_checked(
            table, column, value, limit=limit)
        return found

    def _near_values_checked(self, table, column, value, limit=4, con=None):
        """Return ``(matches, checked)`` for one literal lookup. `con`, when
        given, is a caller's open connection and is left open."""
        if not self.has(table, column) or not value:
            return [], False
        labels = self.enum_labels(table, column)
        if labels:
            # "geographic points" is stored as GEOGPT, which no LIKE on the
            # words will find; the dictionary says so directly
            coded = self.codes_for(value, labels)
            if coded:
                return coded[:limit], True
        if any(k in self.column_type(table, column) for k in
               ("int", "decimal", "float", "double", "numeric", "bit")):
            return [], True
        lent = con is not None
        cur = None
        found = []
        try:
            con = con if lent else self.connect()
            cur = con.cursor()
            # the longest word that carries meaning, not the first word:
            # "still in transit" was looked up as %still%, and "written by
            # Shakespeare" as %written%. A value of one word is unchanged.
            # As written, not singularised: "companies" must still find
            # "companies", which "company" would not.
            stop = self.words_for("stopwords", self.STOPWORDS)
            words = [w.strip(".,;:?!\"'()") for w in str(value).split()]
            meaningful = [w for w in words
                          if len(w) >= 3 and w.lower() not in stop]
            head = (max(meaningful, key=len) if meaningful
                    else words[0])[:12]
            # in lower case on both sides: under a _bin collation a LIKE
            # tells "high" from "HIGH", and a value stored in capitals was
            # never found (review of 26 October)
            cur.execute(
                f"SELECT DISTINCT `{column}` FROM `{table}` "
                f"WHERE LOWER(`{column}`) LIKE %s AND `{column}` IS NOT NULL "
                f"LIMIT %s", (f"%{head.lower()}%", limit))
            found = [r[0] for r in cur.fetchall()]
            if not found:
                cur.execute(
                    f"SELECT DISTINCT `{column}` FROM `{table}` "
                    f"WHERE SOUNDEX(`{column}`) = SOUNDEX(%s) "
                    f"AND `{column}` IS NOT NULL LIMIT %s", (value, limit))
                # SOUNDEX is deliberately broad.  MariaDB can give the
                # same code to an unrelated multi-word label: in the demo
                # data, "coffee" matched several names ending in "Drill".
                # Those are not grounded alternatives, even though the
                # database returned them.  Keep the phonetic fallback for
                # ordinary misspellings, but require the spelling to be
                # recognisably close as well.
                phonetic = [r[0] for r in cur.fetchall()]
                wanted = re.sub(r"[^a-z0-9]+", " ",
                                str(value).lower()).strip()

                def close_enough(candidate):
                    actual = re.sub(r"[^a-z0-9]+", " ",
                                    str(candidate).lower()).strip()
                    if not wanted or not actual:
                        return False
                    comparisons = [actual] + actual.split()
                    return max(difflib.SequenceMatcher(
                        None, wanted, part).ratio()
                               for part in comparisons) >= 0.74

                found = [candidate for candidate in phonetic
                         if close_enough(candidate)]
        except Exception:
            return [], False
        finally:
            if cur is not None:
                try:
                    cur.close()
                except Exception:
                    pass
            if con is not None and not lent:
                try:
                    con.close()
                except Exception:
                    pass
        return found, True

    # ------------------------------------------------------- the passes
    KINDS = ("AmbiSchema", "AmbiValue", "AmbiView", "AmbiSource",
             "AmbiContext", "AmbiFallacy", "AmbiRef")

    def reply_schema(self, tables=None):
        """The exact shape a detection reply must have, enforced by decoding.

        Two choices in here do more than any sentence in the prompt.
        `reason` comes first, and a constrained decoder writes keys in the
        order the schema gives, so the model states its reason before it
        commits to an answer. And `table` is restricted to the tables that
        exist, so a table that is not in the catalogue cannot be produced
        at all rather than being produced and discarded. Columns are
        restricted to names that exist somewhere; which table they belong
        to is still checked afterwards, by has().

        `tables`, when the schema sent was cut to some of them, restricts
        both lists to what the model was shown."""
        shown = {t.lower() for t in tables} if tables is not None else None
        chosen = {t: cols for t, cols in self.columns.items()
                  if shown is None or t.lower() in shown}
        tables = sorted(chosen)
        columns = sorted({c for cols in chosen.values() for c, _ in cols})
        pair = {"type": "object",
                "properties": {
                    "table": {"type": "string", "enum": tables or [""]},
                    "column": {"type": "string", "enum": columns or [""]},
                    "means": {"type": "string"}},
                "required": ["table", "column", "means"]}
        return {"type": "object",
                "properties": {
                    "reason": {"type": "string"},
                    "ambiguous": {"type": "boolean"},
                    "phrase": {"type": "string"},
                    "kind": {"type": "string", "enum": list(self.KINDS) + [""]},
                    "candidates": {"type": "array", "items": pair,
                                   "maxItems": 4},
                    "operations": {"type": "array", "items": {
                        "type": "string", "enum": sorted(OPERATIONS)}},
                    "value": {"type": "string"}},
                "required": ["reason", "ambiguous", "phrase", "kind",
                             "candidates", "operations", "value"]}

    def detect(self, question):
        # whole when it fits the model's window, else the tables most
        # related to the question; see schema_for and focus.py
        def user_of(schema):
            said = "".join(f"{s}\n" for s in (self.context, self.earlier) if s)
            return f"Schema of the database:\n{schema}\n\n{said}Question: {question}"

        # the schema is passed only to a model object that takes one. A
        # caller's own callable, which the library accepts, is asked the
        # plain way and still gets the prompt's description of the shape.
        # Decided from the signature rather than by catching TypeError,
        # which would also catch a genuine error inside the call and send
        # the question to the model a second time without saying so.
        if self._accepts_schema():
            return self.json_with_schema(question, self.system, self.llm,
                                         user_of, reply_schema=True)
        return self.llm.json(self.system, user_of(self.schema_for(question)[0]))

    def _accepts_schema(self):
        import inspect
        try:
            params = inspect.signature(self.llm.json).parameters
        except (TypeError, ValueError, AttributeError):
            return False
        return ("schema" in params
                or any(p.kind is inspect.Parameter.VAR_KEYWORD
                       for p in params.values()))


    # words a question starts with, or uses structurally, which are
    # capitalised without naming anything
    STOPWORDS = {"the", "a", "an", "which", "what", "who", "how", "list",
                 "show", "give", "all", "in", "of", "and", "or", "per",
                 "for", "from", "by", "with", "me", "our", "their"}

    # a capitalised word is only a filter value when something in the
    # sentence says it is being filtered on. Without this, "show the Top
    # 10 members" offered up "Top" and "list the books by J.R.R.
    # Tolkien" offered "J.R.R", and each of those became a statement
    # that the database holds no such thing.
    # "by" is here for "the books written by Shakespeare", "products
    # supplied by Acme": with no "is" or "were" nearby, nothing else in
    # those sentences marks the name as the value being filtered on.
    FILTER_WORDS = {"in", "from", "of", "named", "called", "at", "for",
                    "living", "live", "lives", "based", "located", "is",
                    "are", "was", "were", "like", "by"}

    # A denial has to rest on something checked, and sweeping the data
    # for one of these proves nothing: they are how a question is
    # phrased, not something a column could hold. "nothing" and
    # "newest" were being reported as values this database does not
    # hold, which reads as a gap in the data and is a gap in nobody.
    NOT_A_VALUE = {"nothing", "none", "any", "all", "some", "each", "every",
                   "newest", "oldest", "latest", "biggest", "smallest",
                   "best", "worst", "most", "least", "first", "last",
                   "city", "name", "date", "time", "year", "month", "day",
                   "total", "number", "count", "amount", "type", "kind"}

    # Words that make a phrase a judgement rather than a thing a database
    # could store. A schema holds a capacity, never "nearly full"; a
    # price, never "cheap". Sweeping the data for one of these finds
    # nothing whatever the schema contains, so a denial resting on that
    # sweep says "your database cannot answer this" about a question that
    # only needs a threshold from the person who asked. That is the most
    # damaging thing this component can say, and it was saying it about
    # warehouses whose capacity is right there in the table.
    #
    # Tested per word, not against the whole phrase: the model returns
    # "what constitutes 'cheap'" and "expensive in what sense?" as often
    # as it returns the bare adjective, and an equality test lets every
    # one of those through.
    JUDGEMENTS = {
        # money and size
        "cheap", "cheaper", "cheapest", "expensive", "pricey", "affordable",
        "costly", "big", "bigger", "biggest", "small", "smaller", "large",
        "larger", "huge", "tiny", "heavy",
        # fullness and level
        "full", "empty", "high", "higher", "highest", "low", "lower",
        "lowest", "enough", "sufficient", "insufficient", "limited",
        # speed and volume
        "fast", "faster", "slow", "slower", "quick", "busy", "quiet",
        "popular", "unpopular", "frequent", "rare", "common",
        # quality
        "good", "bad", "better", "worse", "poor", "strong", "weak",
        "reliable", "unreliable", "healthy", "important", "significant",
        "relevant", "typical", "unusual", "normal", "reasonable",
        "acceptable", "critical", "major", "minor",
        # time, when it is vague rather than named
        "recent", "recently", "soon", "lately", "upcoming",
        # deliberately NOT here: "new", "old", "long", "short", "light",
        # "young", "current". Every one of them is an ordinary word in a
        # name, and "New York", "Old Town Depot" and "Light Industrial
        # Ltd" were being read as opinions. The superlatives above carry
        # the meaning that mattered.
        # hedges that turn anything into a threshold
        "nearly", "almost", "approximately", "roughly",
        "several", "few",
        # superlatives that need a criterion before they mean anything:
        # best by what, oldest by which date
        "best", "worst", "newest", "oldest", "latest",
        "smallest", "longest", "shortest",
        # deliberately NOT here: "average", "top", "bottom", "many",
        # "count", "sum". Those are precise operations, not judgements.
        # "the average lead time per supplier" and "the top 5 warehouses
        # by capacity" are exact requests, and treating them as vague
        # turned two plain aggregates into "tell me more".
        #
        # States a business calls by an adjective. Added after measuring
        # what the list missed: on a shipments schema holding due_date and
        # delivered_at, "which shipments are overdue?" came back NOT
        # COVERED, "Nothing here can express it". Every word here names a
        # degree that needs a threshold from the asker, which is the case
        # this set exists for, and none of them names a thing a schema
        # would have to store. DATAGORA_VOCABULARY adds a trade's own.
        "overdue", "delayed", "stale", "urgent", "dormant", "idle",
        "sluggish", "understocked", "overstocked", "underused",
        "profitable", "unprofitable", "problematic", "seasonal",
        "at-risk", "risky", "safe", "efficient", "inefficient",
        "productive", "unproductive", "understaffed", "overstaffed",
        # Deliberately NOT added, and each for a reason a measurement
        # found. `late` is a value loans.status really holds, so the data
        # can answer it and calling it vague would hide that. `unpaid`
        # belongs to "unpaid fines", which a library with no fines table
        # genuinely cannot answer, and that correct NOT COVERED is one of
        # the measured cases. `active` and `current` sit in column names
        # (`is_active`) often enough that resembles_column already
        # protects them, and adding them here would turn a real choice
        # into "tell me more".
    }

    # Quantifiers and superlatives: how a *fragment* is worded, never
    # something a column holds. These are in NOT_A_VALUE too, but that set
    # is compared against the whole phrase, and the model returns "nothing
    # at all", "total value" and "longest in what sense?" rather than the
    # bare word. Each of those three was answered with "your database
    # cannot express it" while books.pages, products.price and
    # inventory.quantity_on_hand sat in the schema.
    #
    # Kept apart from JUDGEMENTS because these are only ever tested
    # against the phrase, never against the question. "The warranty
    # duration of each product" is not vague, and reading "each" as a
    # judgement turned a correct NOT COVERED into "tell me more".
    PHRASINGS = {
        "nothing", "none", "any", "all", "some", "each", "every",
        "most", "least", "first", "last",
        "total", "number", "count", "amount", "sum",
    }

    @staticmethod
    def _words(phrase):
        return {w.strip(".,;:?!\"'()[]").lower() for w in str(phrase).split()}

    # The word lists in this class are defaults, not the vocabulary. A
    # deployment adds its own trade's words through a JSON file named by
    # DATAGORA_VOCABULARY or by `vocabulary` in its profile, with any of
    # the keys judgements, phrasings, not_a_value, filter_words,
    # stopwords, generic_words, label_words.
    #
    # This exists because the lists are what withhold the worst claim the
    # component makes, and they were written by hand in one language.
    # Measured on a shipments schema holding due_date and delivered_at,
    # "which shipments are overdue?" came back NOT COVERED, "Nothing here
    # can express it", because `overdue` is not among the 81 words. So did
    # late, delayed, stale and urgent. Every one of those is answerable
    # with a threshold from the asker, which is the definition of the case
    # the list is meant to catch.
    #
    # Additive on purpose. A word a deployment adds can only move a
    # verdict from NOT COVERED to NEEDS MORE, never the other way, so a
    # customer file cannot weaken the guard or silence a denial the data
    # earned. Replacing the defaults is deliberately not offered.
    VOCABULARIES = ("judgements", "phrasings", "not_a_value",
                    "filter_words", "stopwords", "generic_words",
                    "label_words", "calculations", "logic_words")

    @property
    def vocabulary(self):
        """The trade's own words, added to ours. Read once, never fatal."""
        if self._vocabulary is None:
            extra = {key: set() for key in self.VOCABULARIES}
            named = (getattr(self.profile, "vocabulary", None)
                     if self.profile is not None
                     else os.environ.get("DATAGORA_VOCABULARY"))
            named = named or os.environ.get("DATAGORA_VOCABULARY")
            if named:
                try:
                    data = json.loads(
                        pathlib.Path(named).read_text(encoding="utf-8"))
                    for key in self.VOCABULARIES:
                        extra[key] = {str(w).strip().lower()
                                      for w in (data.get(key) or [])
                                      if str(w).strip()}
                except Exception:
                    # an unreadable vocabulary leaves the defaults in
                    # place. It must not take the database down, and it
                    # must not silently become an empty one either, which
                    # is why the defaults are merged rather than replaced.
                    pass
            self._vocabulary = extra
        return self._vocabulary

    def words_for(self, kind, default):
        return default | self.vocabulary.get(kind, set())

    SUPERLATIVE_WORDS = {"most", "least", "best", "worst", "top", "bottom"}

    def is_a_superlative(self, phrase):
        """True when the phrase ranks rather than judges: cheapest, most.

        A ranking is exact once a count is attached, and even without one
        it names an order rather than a threshold, so it is never the case
        for asking the user what "cheap" means."""
        # "-est" on a word of six letters or more: cheapest, newest,
        # busiest. It also fits "interest" or "request", which is harmless
        # here, because this only ever decides whether to trust the model
        # about a word the judgement list already flagged, and that list
        # holds no such word.
        return any(w in self.SUPERLATIVE_WORDS
                   or (len(w) >= 6 and w.endswith("est"))
                   for w in self._words(phrase))

    def is_a_phrasing(self, phrase):
        """True when the fragment is a quantifier rather than a thing."""
        return bool(self._words(phrase)
                    & self.words_for("phrasings", self.PHRASINGS))

    def is_a_judgement(self, phrase):
        """True when the phrase asks for an opinion, not for a value.

        Used to decide whether a GUIDE may claim the database cannot
        express something. A judgement never can be claimed against,
        because the missing part is a threshold the asker holds, not a
        column the schema lacks."""
        return bool(self._words(phrase)
                    & self.words_for("judgements", self.JUDGEMENTS))

    @staticmethod
    def asks_for_count(question):
        """Whether the wording already chooses a counting operation.

        This is structural rather than tied to a schema or example.  A
        model offering count versus sum after the asker said ``how many``
        manufactures an ambiguity that is not present in the wording.
        """
        return bool(re.search(r"\b(?:how\s+many|number\s+of)\b",
                              str(question), flags=re.IGNORECASE))

    # months and days, in full and short, which a question names as times
    CALENDAR_WORDS = frozenset(
        "january february march april may june july august september october "
        "november december jan feb mar apr jun jul aug sep sept oct nov dec "
        "monday tuesday wednesday thursday friday saturday sunday".split())

    def named_value(self, question, raw):
        """The value a question filters on, when it clearly names one.

        The model's own `value` first, because it saw the sentence. Then
        a capitalised word that directly follows a word marking a filter:
        live *in* Paris, books *of* the genre Mystery. A bare capitalised
        word is not enough, because the claim built on it is that the
        database holds nothing like it, and that claim is expensive to
        get wrong."""
        value = str(raw.get("value") or "").strip()
        if value and not value.replace(".", "", 1).isdigit():
            return value
        words = (question or "").split()
        for i, w in enumerate(words):
            if i == 0:
                continue
            bare = w.strip(".,;:?!\"'")
            if not (len(bare) > 2 and bare[0].isupper()
                    and bare.lower() not in self.words_for(
                        "stopwords", self.STOPWORDS)):
                continue
            # a time ("in October", "in FY2025", "in Q3") or an acronym
            # ("the OTIF rate") is not a value to look for: no column holds
            # "October", and the claim built on not finding it was a NOT
            # COVERED on a question the dates answer. The model's own
            # value, above, still names one when it means it.
            if (bare.lower() in self.CALENDAR_WORDS or any(c.isdigit() for c in bare)
                    or (bare.isupper() and bare.isalpha())):
                continue
            before = [words[j].strip(".,;:?!\"'").lower()
                      for j in range(max(0, i - 3), i)]
            if any(b in self.words_for("filter_words",
                                       self.FILTER_WORDS)
                   for b in before):
                return bare
        return ""

    def unheld_filter_words(self, question, tables=None):
        """The words a question filters on that nothing here holds.

        A word right after a filter word ("by rail", "in France", "of
        Mystery"), past any word that only computes or connects, is what
        the question filters on. It is held when a column is named or
        described by it, when it labels a code, or when a row holds it as a
        value; `tables`, when given, is where to look. Measured on Jarvis:
        "how many shipments went by rail?" came back clear once, with no
        phrase named, and nothing checked it, while no table holds rail.
        A lookup that could not run proves nothing, so the word counts as
        held. Verbs ("went", "carried") are never in that place."""
        ops = self.operation_words()
        stop = self.words_for("stopwords", self.STOPWORDS)
        markers = self.VALUE_MARKERS | self.words_for("filter_words", set())
        # a word in another form of a table in view is that table:
        # "supplied" for suppliers
        kin = {self._stem(tok) for t in (tables or self.columns)
               for tok in self._identifier_tokens(t)}
        tokens = [t.strip(".,;:?!\"'()").lower() for t in str(question or "").split()]
        unheld = []
        for i, token in enumerate(tokens):
            word = self._singular(token)
            if (len(word) < 3 or word.isdigit() or word in ops or token in stop
                    or token in markers or self._stem(word) in kin
                    or self.is_a_superlative(word) or self.is_a_judgement(word)):
                continue
            j = i - 1
            while j >= 0 and tokens[j] not in markers and (
                    self._singular(tokens[j]) in ops or tokens[j] in stop):
                j -= 1
            if j < 0 or tokens[j] not in markers:
                continue
            if self.column_evidence(word, semantic=False, tables=tables):
                continue
            # the value as written: Paris is looked for, not "pari"
            where, checked = self.check_value(token, tables=tables)
            # and then in the form a code is written in. "at the monthly
            # average rate" was flagged on the enterprise database because
            # the rate type is stored as MONTH_AVG, which holds "month" and
            # no LIKE on "monthly" finds. An adjective of a period or a
            # place is that word (ADJECTIVE_ROOTS), held when a value has
            # it as one of its words: MONTH_AVG holds month, MONDAY no day.
            if where is None and checked:
                root = self.ADJECTIVE_ROOTS.get(token)
                if root:
                    if self.column_evidence(root, semantic=False, tables=tables):
                        continue
                    where, checked = self.check_value(root, tables=tables,
                                                      as_a_word=True)
            if where is None and checked:
                unheld.append(token)
        return unheld

    # The words that introduce a value being filtered on: "by rail", "in
    # France", "named Eiffel". Not "is", "are", "of" or "for", which the
    # FILTER_WORDS below hold for another purpose: after them comes a
    # description or a relation ("are supplied", "value of the stock"),
    # and measured over the test questions they flagged those wrongly.
    VALUE_MARKERS = {"by", "in", "from", "at", "named", "called", "like",
                     "living", "live", "lives", "based", "located", "via"}

    # An adjective of a period or a place, and the word a code holds for
    # it: MONTH_AVG for "monthly". Listed rather than cut by a rule: cutting
    # -al, -ly or -ic made "rental" rent, "electric" electr and "public"
    # publ, which CURRENT, ELECTRONICS and PUBLISHED hold, and a value the
    # data lacks counted as held.
    ADJECTIVE_ROOTS = {"monthly": "month", "weekly": "week", "daily": "day",
                       "yearly": "year", "quarterly": "quarter", "annual": "year",
                       "regional": "region", "seasonal": "season",
                       "national": "nation"}

    def _has_word(self, stored, word):
        """Whether `word` is one of the words of a stored value, in either
        number: "month" in MONTH_AVG or MONTHS, not "rent" in CURRENT."""
        words = [w for w in re.split(r"[^a-z0-9]+", str(stored).lower()) if w]
        return word in words or word in {self._singular(w) for w in words}

    def check_value(self, value, tables=None, as_a_word=False, con=None,
                    max_columns=None, until=None, clock=None):
        """Return ``(location, checked)`` for a schema-wide value sweep.

        ``checked`` is true only when every eligible column was queried
        successfully.  A single failed lookup prevents a claim of absence;
        a positive match remains usable because its presence is proven by
        the row that was read.

        ``as_a_word`` counts a value only when ``value`` is one of its
        words, or a code the dictionary labels with it, rather than any
        value a LIKE or a SOUNDEX on it finds.

        ``con``, when given, is a caller's open connection, bounded by the
        caller's statement timeout, and is left open. ``max_columns`` and
        ``until`` (a reading of ``clock``, time.monotonic by default) bound
        the sweep: past either it stops, and ``checked`` is False, since
        the columns never looked up prove nothing.
        """
        if not value:
            return None, False
        checked = True
        clock = clock or time.monotonic
        looked = 0
        lent = con is not None
        if not lent:
            con = self._lent_connection()
        if con is None:
            return None, False
        try:
            for table, cols in (self.columns or {}).items():
                if tables and table not in tables:
                    continue
                for column, ctype in cols:
                    if not any(k in str(ctype).lower()
                               for k in ("char", "text", "enum")):
                        continue
                    if ((max_columns is not None and looked >= max_columns)
                            or (until is not None and clock() > until)):
                        return None, False
                    looked += 1
                    found, this_checked = self._near_values_checked(
                        table, column, value, con=con)
                    checked = checked and this_checked
                    if found and as_a_word:
                        labels = self.enum_labels(table, column)
                        if not (labels and self.codes_for(value, labels)):
                            found = [f for f in found if self._has_word(f, value)]
                    if found:
                        return (table, column), True
        finally:
            if not lent:
                self._close(con)
        return None, checked

    def holds_value(self, value, tables=None):
        """Where this value actually appears, if it appears at all.

        The guard that uses this needs to tell "no column holds it" from
        "the columns I happened to check do not hold it". Those are not
        the same claim, and only one of them is safe to put in front of a
        user. Returns (table, column) or None; None also when nothing
        could be checked, which the caller must treat as not knowing."""
        return self.check_value(value, tables=tables)[0]

    # ------------------------------------------------- an empty result
    def text_holders(self, candidates):
        """The candidates that could hold a literal: real text columns.

        Keys are followed first, so books.author_id proposed for
        "Shakespeare" is looked up as authors.name, the column that would
        actually hold the name."""
        return [c for c in self.through_keys(candidates)
                if self.has(c.get("table"), c.get("column"))
                and any(k in self.column_type(c.get("table"), c.get("column"))
                        for k in ("char", "text", "enum"))]

    def a_literal(self, value):
        """True when `value` names a thing a row could hold.

        Not a number or a date, which are compared rather than looked up;
        not a quantifier; not one of the schema's own words, which is the
        question naming a column rather than a row. A lower-case judgement
        or ranking word ("cheap", "latest") is a threshold, not a literal.
        A capitalised one is a name, whatever the word list says: "New
        York" is a place, even though "new" is a judgement."""
        v = str(value or "").strip()
        if len(v) < 2 or re.fullmatch(r"[\d\s.,:/%+-]+", v):
            return False
        if v.lower() in self.words_for("not_a_value", self.NOT_A_VALUE):
            return False
        if not v[:1].isupper() and (self.is_a_judgement(v)
                                    or self.is_a_phrasing(v)
                                    or self.is_a_superlative(v)):
            return False
        return not self.column_evidence(v, semantic=False)

    def looks_like_codes(self, table, column):
        """True when a column holds short codes rather than words.

        DE, FR, US; CARTPT, GEOGPT. The one kind of column where a value
        can be present under a spelling no LIKE or SOUNDEX will ever
        connect to the question's words."""
        values = self.distinct_values(table, column)
        return bool(values) and all(
            len(str(v)) <= 6 and not re.search(r"\s", str(v)) for v in values)

    def spelt_otherwise(self, value, holders, question=""):
        """Why the holders express `value` under another spelling, or "".

        The last look before calling a result empty, and only on columns of
        codes. A LIKE and a SOUNDEX find "Shakespear" but never "DE" for
        Germany, and a country code column holding DE answers a question
        about Germany, so there the values are put to the model. On a column
        of names or titles the lookup is the authority: a model shown thirty
        author names and asked about Shakespeare is being asked whether a
        name COULD be there, which is not the question. Only a "yes" changes
        anything, and it can only turn an empty result into an answer."""
        coded = [c for c in holders
                 if self.looks_like_codes(c.get("table"), c.get("column"))]
        if not coded:
            return ""
        verdict, table, column, why = self.decide_on_values(
            value, coded, question)
        if verdict == "yes" and table:
            return (f"\"{value}\" is held under another spelling in "
                    f"{table}.{column}" + (f": {why}" if why else ""))
        return ""

    def empty_result(self, value, holders, kind="AmbiValue", reason=""):
        """The NO DATA outcome: a column could hold it, and no row does.

        Unless every column that could hold it is a vocabulary the
        dictionary declares closed. abs_point.cat_code holds CARTPT and
        GEOGPT and nothing else, so "polar points" is not a row that
        happens to be missing: it is a kind this database cannot record,
        which is NOT COVERED. Two sources agree before that is said, the
        dictionary's list and the lookup that found nothing in the data."""
        declared = [c for c in holders
                    if self.enum_labels(c.get("table"), c.get("column"))]
        if declared and len(declared) == len(holders):
            c = declared[0]
            listed = ", ".join(
                f"{code} ({label})" for code, label
                in self.enum_labels(c["table"], c["column"]).items())
            return Outcome(
                action="GUIDE", phrase=value, kind=kind, reason=reason,
                options=[], checked=True,
                question=(f"{c['table']}.{c['column']} can only hold "
                          f"{listed}, and none of them is \"{value}\": this "
                          f"database has no such kind. {reason}").strip())
        where = ", ".join(f"{c['table']}.{c['column']}" for c in holders[:3])
        return Outcome(
            action="GUIDE", phrase=value, kind=kind, reason=reason,
            options=[], empty=True,
            question=(f"This database can ask the question, and no row "
                      f"answers it: {where} could hold \"{value}\" and none "
                      f"does. The result is empty. {reason}").strip())

    def no_row_matches(self, raw, question=""):
        """NO DATA for a question the model found clear, or None.

        The model reports the literal it saw in `value` and the column that
        would hold it. The literal is looked up there, then everywhere,
        then its spelling is questioned; only when all three come back
        empty, and every lookup actually ran, is the result called empty.
        Anything unread, anything found, and it stays an answer."""
        # the model's own `value` first; a clear question often comes back
        # without one, and then the literal is the capitalised word after a
        # filter word, "written by Shakespeare"
        value = self.named_value(question, raw)
        if not self.a_literal(value):
            return None
        holders = self.text_holders(raw.get("candidates"))
        if not holders:
            return None
        for c in holders:
            found, checked = self._near_values_checked(
                c["table"], c["column"], value)
            if found or not checked:
                return None
        # the proposed column may simply be the wrong one: "Tolkien"
        # proposed against books.title lives in authors.name, and that is a
        # model's slip, not an empty result
        elsewhere, checked = self.check_value(value)
        if elsewhere is not None or not checked:
            return None
        if self.spelt_otherwise(value, holders, question):
            return None
        return self.empty_result(value, holders,
                                 reason=(raw.get("reason") or "").strip())

    def ground(self, raw, unreachable=False, question=""):
        """Keep only what the database confirms, and say which of the four
        outcomes that leaves.

        The interesting case is an ambiguity whose readings are not all in
        this schema. "The oldest members" is genuinely ambiguous between
        age and membership date, but a schema with no birth date can only
        offer one of the two. Answering it silently would hide that; so
        would calling the question unambiguous. It is a GUIDE: name what
        the data holds and offer it, labelled."""
        if unreachable:
            return Outcome(action="ERROR", reason=(getattr(self.llm, "last_error", "")
                                            or "the model endpoint did not "
                                               "answer"))
        if raw is None:
            # the client knows whether the host refused the call or
            # replied with something unusable. Reporting the second when
            # it was the first sends whoever reads this to the wrong
            # place: a wrong model name looks exactly like a bad reply.
            return Outcome(action="ERROR",
                           reason=(getattr(self.llm, "last_error", "")
                                   or "the model reply could not be read "
                                      "as JSON"))
        if not raw.get("ambiguous"):
            # The model named the word it hesitated over and then called the
            # question clear. Measured: "which books are cheap?" came back
            # ambiguous=false with phrase "cheap", and was reported
            # ANSWERABLE, because this return used to happen before any
            # judgement check could run. A bare judgement needs a threshold
            # from the asker whatever the model concluded.
            #
            # Superlatives are left to the model. "the 5 cheapest books" is
            # an exact ORDER BY and a LIMIT, and treating it as vague would
            # turn a precise request into "tell me more".
            named = (raw.get("phrase") or "").strip()
            if (named and self.is_a_judgement(named)
                    and not self.is_a_superlative(named)):
                return Outcome(
                    action="GUIDE", phrase=named, kind="AmbiContext",
                    reason=(raw.get("reason") or "").strip(),
                    options=[],
                    question=(f"\"{named}\" needs a threshold: what counts "
                              f"as {named} here?"))
            # Clear is not the same as non-empty. Measured on the demo
            # library: "which books were written by Shakespeare in 2020"
            # came back clear, and correctly so, and was reported
            # ANSWERABLE while no author of that name exists. The model
            # names the literal it saw; the data says whether any row
            # holds it.
            empty = self.no_row_matches(raw, question)
            if empty:
                return empty
            # The model hesitated over a phrase and called the question
            # clear anyway. When what that phrase says beyond the table it
            # names is nowhere in the schema, no name, no description, no
            # alias, the model's "clear" is its own reading and nothing
            # else. Measured with the library's knowledge base: "which
            # members have unpaid fines" came back clear on loans.status,
            # and "which authors are still alive" clear on born_year. Both
            # were reported answerable. The answer is withheld, never
            # turned into a denial: the reader is asked which column holds
            # it.
            # the tables the model proposed are the ones the phrase may name
            proposed = {self._catalogue_table(c.get("table"))
                        for c in raw.get("candidates") or []
                        if isinstance(c, dict) and c.get("table")}
            proposed = {t for t in proposed if t in self.columns}
            unheard = self.unaccounted_words(named, tables=proposed or None)
            # a literal is a row, and whether one holds it was just asked
            # of the data: its words are never missing from the schema
            literal = self.named_value(question, raw)
            if literal:
                unheard -= self._content_words(literal)
            # names and descriptions only: closeness in meaning may withhold
            # a denial, and must never be what lets a yes through. And only
            # in the tables the question is about: on a database of
            # hundreds, "warranty duration" passed on the duration_minutes
            # of other trades, while nothing about products names a
            # warranty.
            scope = self.question_tables(question, proposed)
            if unheard and not self.column_evidence(" ".join(sorted(unheard)),
                                                    semantic=False, tables=scope):
                return Outcome(
                    action="GUIDE", phrase=named,
                    kind=raw.get("kind") or "AmbiSchema",
                    reason=(raw.get("reason") or "").strip(), options=[],
                    question=(f"Nothing in this schema is named or described "
                              f"as \"{' '.join(sorted(unheard))}\", which "
                              f"\"{named}\" needs. Which column holds it?"))
            # what the question filters on must be held somewhere, even
            # when the model named no phrase: "went by rail" came back clear
            # the literal the value step already judged, codes included
            # ("Germany" held as DE), is not judged again here
            judged = {w.lower() for w in str(literal or "").split()}
            unheld = [w for w in self.unheld_filter_words(question, tables=scope)
                      if w not in judged]
            if unheld:
                return Outcome(
                    action="GUIDE", phrase=named or " ".join(unheld),
                    kind=raw.get("kind") or "AmbiValue",
                    reason=(raw.get("reason") or "").strip(), options=[],
                    question=(f"Nothing in this database is named, described "
                              f"or recorded as \"{' '.join(unheld)}\". Which "
                              f"column holds it?"))
            return Outcome(action="ANSWER")
        kind = raw.get("kind") or "AmbiSchema"
        kind = ALIASES.get(kind, kind)
        if kind not in TYPES:
            kind = "AmbiSchema"
        phrase = (raw.get("phrase") or "").strip()
        reason = (raw.get("reason") or TYPES[kind]).strip()

        # A key proposed as the meaning of a word is replaced by the column
        # it stands for, before anything looks at the candidates: every
        # later step, the value lookups included, is then about genres.name
        # rather than about a number. When two readings turn out to be one,
        # the id and the name it points at, there was nothing to choose.
        given = [c for c in (raw.get("candidates") or [])
                 if isinstance(c, dict)]
        through = self.through_keys(given)

        def real_pairs(cands):
            return {((c.get("table") or "").lower(),
                     (c.get("column") or "").lower())
                    for c in cands if self.has(c.get("table"), c.get("column"))}

        folded = len(real_pairs(through)) < len(real_pairs(given))
        # Whether every reading the model proposed is a column of this
        # database. When one is not (a birth date the schema lacks), the
        # one that survives is the database's reading and not the asker's,
        # and saying so is the point; when all are, a choice that comes
        # down to one has nothing left to ask. See the single option below.
        every_reading_held = len(given) >= 2 and all(
            self.has(c.get("table"), c.get("column")) for c in through)
        # A column outside the tables the question is about is no reading
        # of it. On a database of hundreds, "warranty duration of each
        # product" was offered the duration_minutes of other trades as a
        # choice, none of them anything to do with products.
        scope = self.question_tables(
            question, {self._catalogue_table(c.get("table")) for c in through})
        if scope is not None:
            through = [c for c in through
                       if self._catalogue_table(c.get("table")) in scope]
        raw = {**raw, "candidates": through}

        if kind not in GROUNDED:
            # the classification is the model's opinion, the candidates are
            # checkable facts. A small model often mislabels a plain
            # column choice as AmbiContext while still naming the right
            # columns, so when real columns survive the check they are
            # used and the label is corrected rather than obeyed.
            real = [c for c in (raw.get("candidates") or [])
                    if self.has(c.get("table"), c.get("column"))]
            # The label says the asker must supply something; the schema may
            # say otherwise. Measured: "how many suppliers are there per
            # country?" came back AmbiContext with no candidate at all, and
            # was reported NEEDS MORE while suppliers.country_code answers it
            # with a GROUP BY. When the schema holds exactly what the phrase
            # names, and the phrase is no judgement, the schema is right.
            if (not self.is_a_judgement(phrase)
                    and not self.is_a_judgement(question)):
                direct = self.answers_directly(phrase)
                if direct:
                    return Outcome(
                        action="ANSWER", phrase=phrase, kind=kind,
                        reason=(f"the model asked for context on \"{phrase}\" "
                                f"but the schema answers it directly "
                                f"({', '.join(direct[:3])})"))
            # a real candidate that records a state is where "still open",
            # "late" and "recently" live, and it forbids a denial exactly as
            # it does in the value step. Measured: allowing AmbiContext to
            # reach a denial turned "how many loans are still open?" into
            # NOT COVERED while the model itself had proposed loans.status,
            # which holds borrowed, returned and late. It is offered
            # instead, and the reader picks it or says more.
            stateful = [c for c in real
                        if self.records_a_state(c["table"], c["column"])]
            if len(real) < 2 and stateful:
                options = [Option(label=f"{c['table']}.{c['column']}",
                                  means=c.get("means") or "the state it records",
                                  table=c["table"], column=c["column"],
                                  via=c.get("via"))
                           for c in stateful]
                return Outcome(
                    action="GUIDE", phrase=phrase, kind=kind, reason=reason,
                    options=options,
                    question=(f"\"{phrase}\" may be read off "
                              f"{options[0].label}. Use that?"))
            if len(real) >= 2:
                kind = "AmbiSchema"
            else:
                # The model saying "this database holds no such thing" is
                # evidence, not proof, so it is checked rather than
                # obeyed: the schema is searched for the words and the
                # data for the value. When both come back empty the two
                # agree, and a coverage report may say so. Downgrading it
                # to "tell me more" threw away a correct answer, which is
                # what a larger reasoner kept getting right and we kept
                # discarding.
                holder, sweep_checked = self.check_value(phrase)
                # AmbiFallacy only, and this was tried the other way and
                # measured. AmbiContext means a threshold or a degree the
                # asker holds, which by definition is never a gap in the
                # data. Letting it reach a denial fixed "audiobooks" and
                # broke "how many loans are still open?", which came back
                # NOT COVERED on a table whose status column holds borrowed,
                # returned and late. A missed denial costs a question that
                # asks for more; a false one tells a team their database
                # cannot do something it does in one query. The fix for the
                # missed ones is in the prompt, which now tells the model
                # that a question assuming something the schema does not
                # hold is AmbiFallacy.
                absent = (kind == "AmbiFallacy"
                          # a ranking word orders by something the asker has
                          # not named; sweeping the data for "busiest" proves
                          # nothing. "tallest" loses a correct denial to
                          # this, and that is the side to be wrong on.
                          and not self.is_a_superlative(phrase)
                          and not self.withholds_denial(phrase)
                          and not self.is_a_judgement(phrase)
                          and not self.is_a_judgement(question)
                          and not self.is_a_phrasing(phrase)
                          and holder is None and sweep_checked)
                return Outcome(
                    action="GUIDE", phrase=phrase, kind=kind, reason=reason,
                    checked=absent,
                    question=(f"\"{phrase}\" has no equivalent in this "
                              f"database. {reason}" if absent
                              else f"About \"{phrase}\": {reason}"),
                    options=[])

        # A judgement is short of a threshold the asker holds, and no menu
        # can supply one. Offering four product names for "cheaper than a
        # coffee", or list/minimum/rank for "cheap", is the component
        # answering a question nobody asked. Only the two kinds that build
        # options out of data or operations are stopped here: a judgement
        # can still be a genuine choice between columns, which is what
        # "the most reliable supplier" is.
        # AmbiView only, and on the phrase alone. AmbiValue was here too
        # and the word list read "New York" as a judgement, because "new"
        # is in it: a literal is data, so it is decided against the
        # database by near_values below, never against a vocabulary. The
        # question was tested too, which cost any sentence containing
        # "low" or "old" its grounding. That test now survives only where
        # it is safe: suppressing a denial, further down.
        if kind == "AmbiView" and self.is_a_judgement(phrase):
            return Outcome(
                action="GUIDE", phrase=phrase, kind=kind, reason=reason,
                options=[],
                question=(f"\"{phrase}\" needs to be said more precisely. "
                          f"{reason}"))

        options = []
        if kind == "AmbiView":
            proposed = {str(o).strip().lower() for o in (raw.get("operations") or [])}
            # "How many" and "number of" choose a count. Keeping a
            # model-proposed count/sum menu made a clear request look
            # ambiguous and blocked the SQL stage unnecessarily: "how many
            # members" counts members. Except where what is counted is held
            # as a quantity: "how many containers did each vessel carry"
            # adds up container_count, and counting the shipments answers
            # something else. When the model proposed a sum and a column it
            # named holds such a number, the choice is the asker's.
            if self.asks_for_count(question) and not (
                    "sum" in proposed and self.quantities(raw.get("candidates"))):
                return Outcome(
                    action="ANSWER", phrase=phrase, kind=kind,
                    reason="the question explicitly asks for a count")
            # a total or an average against each row as it is: the same
            # thing when every entity occurs once
            if proposed and proposed <= {"sum", "average"}:
                entity = self.per_row_is_per_entity(raw.get("candidates") or [])
                if entity:
                    return Outcome(
                        action="ANSWER", phrase=phrase, kind=kind,
                        reason=(f"each value of {entity} occurs once, so per row "
                                f"and in total give the same answer"))
            # the options are operations, so the closed vocabulary plays
            # the part information_schema plays for the other two types
            for op in (raw.get("operations") or []):
                key = str(op).strip().lower()
                if key in OPERATIONS:
                    options.append(Option(label=key, means=OPERATIONS[key]))
            if not options:
                blob = " ".join([phrase, reason] +
                                [str(c.get("means", ""))
                                 for c in (raw.get("candidates") or [])]).lower()
                for op, plain in OPERATIONS.items():
                    if op in blob:
                        options.append(Option(label=op, means=plain))
        elif kind == "AmbiValue":
            value = raw.get("value") or phrase
            closed, looked = [], True
            for c in (raw.get("candidates") or []):
                found, checked = self._near_values_checked(
                    c.get("table"), c.get("column"), value)
                looked = looked and checked
                labels = self.enum_labels(c.get("table"), c.get("column"))
                if labels and not found:
                    closed.append(c)
                for real in found:
                    named = labels.get(str(real))
                    options.append(Option(
                        label=str(real), means=(f"{named}, " if named else "")
                        + f"as stored in {c['table']}.{c['column']}",
                        table=c.get("table"), column=c.get("column"),
                        value=str(real), via=c.get("via")))
            if not options and closed and looked:
                # the value was looked for in a vocabulary the dictionary
                # declares closed, matched none of its codes, and is in no
                # other column either: "polar points" where cat_code holds
                # CARTPT and GEOGPT. Decided here, because a later step
                # would see "points" echo a column and offer it instead.
                elsewhere, swept = self.check_value(value)
                if elsewhere is None and swept:
                    return self.empty_result(value, closed, kind, reason)
        else:
            for c in (raw.get("candidates") or []):
                if self.has(c.get("table"), c.get("column")):
                    options.append(Option(
                        label=f"{c['table']}.{c['column']}",
                        means=c.get("means") or "", table=c.get("table"),
                        column=c.get("column"), via=c.get("via")))
            # The columns exist, which is all the check above proves. When
            # the question also names a value, the data can say more: if
            # no proposed column holds anything like it, the reading is
            # not in this schema and a menu of columns is the wrong
            # answer. "which members live in Paris" offered full_name and
            # email, both real, neither answering, because members has no
            # city. The same test leaves "products in Rotterdam" alone,
            # since warehouses.city does hold Rotterdam.
            named = self.named_value(question, raw)
            if named and options and not any(
                    self.near_values(o.table, o.column, named)
                    for o in options):
                # The proposed columns do not hold it. That alone is not
                # enough to tell the user their database has nothing like
                # it: the model may simply have proposed the wrong
                # columns, and two date columns can never hold a name
                # whatever the data says. So the whole schema is swept
                # before the claim is made, and when the value is found
                # elsewhere the options are wrong but the database is
                # not, which is a CLARIFY and not a denial.
                found, sweep_checked = self.check_value(named)
                # a word that echoes a column name is not a missing
                # value, it is the question naming the thing it wants.
                # "per warehouse city" was denied for not holding
                # "city" while warehouses.city sat right there.
                echoes = self.resembles_column(named)
                sayable = (not echoes
                           and named.lower() not in self.words_for(
                               "not_a_value", self.NOT_A_VALUE)
                           and not self.is_a_judgement(named)
                           and not self.is_a_phrasing(named))
                if found is None and sayable:
                    # No column holds the literal. Before denying, the
                    # values themselves are put to the model, because a
                    # concept can live in them without living in any name:
                    # nothing is called "gluten" and a LIKE will never
                    # find one, yet a model shown the product names can
                    # tell bread from rice. The columns come first and the
                    # model second, so it is deciding about real rows.
                    verdict, table, column, why = self.decide_on_values(
                        named, raw.get("candidates"), question)
                    if verdict == "yes" and table:
                        return Outcome(
                            action="ANSWER", phrase=phrase or named,
                            kind=kind, reason=why or reason)
                    elif verdict == "no" and sweep_checked:
                        return Outcome(
                            action="GUIDE", phrase=phrase or named,
                            kind=kind, reason=why or reason,
                            question=(f"\"{named}\" cannot be read off any "
                                      f"column of this database. "
                                      f"{why or reason}"),
                            options=[], checked=True)
                    elif verdict == "unknown" and sweep_checked:
                        # the model could not be reached, or would not
                        # decide. The sweep above already earned this
                        # denial on its own, so it stands: the call was an
                        # opportunity to overturn it, not its evidence.
                        return Outcome(
                            action="GUIDE", phrase=phrase or named,
                            kind=kind, reason=reason,
                            question=(f"No column of this database holds "
                                      f"\"{named}\". {reason}"),
                            options=[], checked=True)
                    elif verdict in ("no", "unknown"):
                        # A failed lookup is not an empty database.  The
                        # distinction is carried by check_value(), so a
                        # connection error can never become NOT COVERED.
                        return Outcome(
                            action="GUIDE", phrase=phrase or named,
                            kind=kind, reason=why or reason, options=[],
                            question=(f"The database could not verify "
                                      f"whether it holds \"{named}\". "
                                      f"{why or reason}"))
                if found is not None:
                    table, column = found
                    options.insert(0, Option(
                        label=f"{table}.{column}",
                        means=f"the column that actually holds \"{named}\"",
                        table=table, column=column))
                # found nothing but the word echoes a column or is a way
                # of phrasing a question: nothing was proved, so nothing
                # is claimed and the options already gathered stand
            elif (not named and len(options) >= 2
                    and not self.resembles_column(phrase)
                    and self.holds_value(phrase) is None):
                # Two real columns were proposed, the phrase is in none of
                # their names and in none of the data. That is the shape
                # that answered a question about gluten with "choose
                # between products.product_name and categories.name": the
                # columns exist, so the rule called it an ambiguity.
                #
                # Existing is not answering. Nothing is CALLED gluten, so
                # no match can settle it, and the only thing that can is a
                # look at the values. The model sees them and says whether
                # bread can be told from rice. It is asked here and not
                # earlier because the columns must be identified first,
                # which is what makes the question about real rows.
                verdict, table, column, why = self.decide_on_values(
                    phrase, raw.get("candidates"), question)
                if verdict == "no":
                    # A "no" withdraws the menu; it does NOT authorise a
                    # denial. Measured on gemma3:4b it denied "how many
                    # loans are still open" on a table whose status column
                    # holds borrowed/returned/late, and "borrowed
                    # recently" on a column full of dates. Both are
                    # answerable, and NOT COVERED is the one verdict a
                    # client repeats to their management.
                    #
                    # So the model's judgement is treated as what it is:
                    # evidence about plausibility, not proof of absence.
                    # It is trusted to stop us offering product_name as an
                    # answer about gluten, and not trusted to say the data
                    # cannot answer. Only our own sweep earns that, above.
                    #
                    # And it is overruled outright on the columns a
                    # database uses to record a state: a closed vocabulary
                    # or a moment. Those are where "still open", "late"
                    # and "recently" actually live, they are readable from
                    # the catalogue, and no opinion is needed to see them.
                    # A menu built on one of them stands whatever the
                    # model thinks of it.
                    stateful = [o for o in options
                                if o.table and o.column
                                and self.records_a_state(o.table, o.column)]
                    if not stateful:
                        return Outcome(
                            action="GUIDE", phrase=phrase, kind=kind,
                            reason=why or reason, options=[],
                            question=(f"\"{phrase}\" cannot be read off the "
                                      f"columns proposed for it. "
                                      f"{why or reason}"))
                    # the menu stands, and the doubt is carried with it
                    # rather than acted on, so a reader sees what the
                    # model saw and keeps the columns that answer them
                    # Narrow only while a choice survives. Assigning
                    # `stateful` unconditionally left a single option when
                    # exactly one candidate recorded a state, and one
                    # option falls into the single-option GUIDE below,
                    # which reads as NEEDS MORE. Measured: two candidates
                    # on `loans`, status holding borrowed/returned/late and
                    # borrower_name holding 400 names, gave NEEDS A CHOICE
                    # with the step off and NEEDS MORE with it on. The step
                    # is not allowed to cost a verdict, so below two the
                    # menu stands exactly as it was.
                    if len(stateful) >= 2:
                        options = stateful
                    if why:
                        reason = (f"{reason} Reading the values, the model "
                                  f"was unsure: {why}").strip()
                if verdict == "yes" and table:
                    chosen = [o for o in options
                              if ((o.table or "").lower(),
                                  (o.column or "").lower()) ==
                                 (table.lower(), column.lower())]
                    if chosen and self.is_a_judgement(phrase) and                             not self.is_a_superlative(phrase):
                        # the values settle WHICH column, and a judgement
                        # still lacks its threshold. Measured: "which members
                        # borrowed something recently" was offered
                        # borrowed_at and returned_at, the model picked
                        # borrowed_at, and the question was reported
                        # answerable with nobody having said how recent.
                        return Outcome(
                            action="GUIDE", phrase=phrase, kind=kind,
                            reason=why or reason, options=chosen,
                            question=(f"\"{phrase}\" is read off "
                                      f"{chosen[0].label}, and needs a "
                                      f"threshold: what counts as {phrase} "
                                      f"here?"))
                    # Values settle a concept read off text, "gluten free"
                    # off product names. They cannot settle which of two
                    # numbers or two dates was meant: list_price and
                    # standard_cost are both prices, and a model shown
                    # both picks one and calls it decided. Measured on the
                    # enterprise database: "which products are the most
                    # expensive?" came back answerable on list_price while
                    # the cost reading is as good. The menu stands.
                    kinds = [self.column_type(o.table, o.column)
                             for o in options if o.table and o.column
                             and not self.is_a_key(o.table, o.column)]
                    numbers = sum(1 for k in kinds
                                  if any(n in k for n in self.NUMERIC))
                    moments = sum(1 for k in kinds if k in self.MOMENTS)
                    if numbers >= 2 or moments >= 2:
                        chosen = []
                    if chosen:
                        # The optional value pass has resolved the choice
                        # against real rows.  Falling through with one
                        # option turned NEEDS A CHOICE into NEEDS MORE,
                        # which made additional evidence degrade coverage.
                        return Outcome(
                            action="ANSWER", phrase=phrase, kind=kind,
                            reason=why or reason)

        seen, unique = set(), []
        for o in options:
            key = (o.label, o.table, o.column)
            if key not in seen:
                seen.add(key)
                unique.append(o)
        # a view offering the same column as a real table is the same
        # answer twice, so the table wins and the choice disappears
        # a view option is dropped only when a real table in this very
        # choice offers the same column AND the view is built from that
        # table. The previous rule matched on the column name alone, so
        # any two readings that happened to share a name collapsed.
        by_table = {(o.table or "").lower(): o.column for o in unique
                    if o.table and (o.table or "").lower() not in self.views}
        kept = [o for o in unique
                if not (o.table
                        and (o.table or "").lower() in self.views
                        and any(o.column == column
                                and source in self.views[(o.table or "").lower()]
                                for source, column in by_table.items()))]
        collapsed = len(kept) < len(unique) or folded
        unique = kept
        if len(unique) == 1 and collapsed:
            # the readings collapsed because a view and its table are the
            # same column, or a key and the name it points at are the same
            # thing, so nothing was ever ambiguous and there is nothing to
            # ask. Falling through to the single-option branch
            # said "this database only holds one of them", which invites a
            # choice between a thing and itself.
            return Outcome(action="ANSWER", phrase=phrase, kind=kind,
                           reason=reason)

        if (len(unique) >= 2 and self.is_a_judgement(phrase)
                and not self.is_a_superlative(phrase)):
            # a choice AND a threshold: picking borrowed_at over
            # returned_at still leaves "recently" undefined, so the columns
            # are offered and the verdict is the one that asks for more
            return Outcome(
                action="GUIDE", phrase=phrase, kind=kind, reason=reason,
                options=unique,
                question=(f"\"{phrase}\" needs a threshold, and can be read "
                          f"off {' or '.join(o.label for o in unique[:3])}: "
                          f"which, and what counts as {phrase} here?"))
        if len(unique) >= 2:
            return Outcome(
                action="CLARIFY", phrase=phrase, kind=kind, reason=reason,
                options=unique,
                question=f"By \"{phrase}\", which do you mean?")
        if (len(unique) == 1 and every_reading_held
                and kind not in ("AmbiValue", "AmbiView")
                and not self.is_a_judgement(phrase)):
            # Two or more readings were proposed, every one of them a column
            # of this database, and they came down to one: the same column
            # twice, or the others in tables the question is not about.
            # Measured on the enterprise database: "approved absence days
            # per department" was proposed as departments.name reached
            # through the employee and departments.name reached through the
            # position history, one column, and was reported NEEDS MORE as
            # if the database lacked a reading. It holds the one there is,
            # so the question is answered with it and the reading is said.
            # A reading the schema lacks keeps the GUIDE below, which is
            # the "oldest members" with no birth date: answering it on the
            # membership date alone would hide that.
            o = unique[0]
            return Outcome(
                action="ANSWER", phrase=phrase, kind=kind,
                reason=(f"\"{phrase}\" is read off {o.label}"
                        + (f" ({o.means})" if o.means else "")
                        + f", the one reading left of those proposed. {reason}"
                        ).strip(),
                options=unique)
        if len(unique) == 1:
            o = unique[0]
            return Outcome(
                action="GUIDE", phrase=phrase, kind=kind, reason=reason,
                options=unique,
                question=(f"\"{phrase}\" can be read in more than one way, "
                          f"and this database only holds one of them: "
                          f"{o.label} ({o.means}). Use that?"))
        # nothing grounded. Before saying the database cannot express the
        # phrase, look for it: a model that mis-classified would otherwise
        # deny a column that exists.
        # Declared answerable only on complete evidence. The old test was
        # any shared substring, so "theme park" came back ANSWERABLE on the
        # strength of questions.theme, and a team was told yes about a
        # question the data has nothing to do with.
        direct = self.answers_directly(phrase)
        if direct:
            return Outcome(action="ANSWER", phrase=phrase, kind=kind,
                           reason=(f"the model flagged \"{phrase}\" but the "
                                   f"schema answers it directly "
                                   f"({', '.join(direct[:3])})"))
        # A partial echo earns a suggestion, not a verdict in either
        # direction. It is too weak to say yes and far too strong to let
        # the denial below say no: the phrase names something this schema
        # has, only not completely.
        # in the tables the question is about, on a large database (see
        # question_tables): "warranty duration" was offered the
        # duration_minutes of vehicles, tyres and certifications
        evidence = self.column_evidence(phrase, tables=scope)
        echoes = [e for e in evidence if e[2] in self.SUGGESTS]
        # Columns found through the table the phrase names say nothing
        # about what the phrase adds to it. Measured: "braille copies" was
        # offered copies.kind_code, acquired_on, shelf_code and cond_code,
        # every one of them found through "copies", none of them about
        # braille, and was reported as a choice, which reads as answerable.
        # When no echo accounts for any of the added words, it is a request
        # for more instead, and still never a denial.
        specific = self.unaccounted_words(phrase)
        if echoes and specific and not any(
                self._covers(t, c, specific) for t, c, _how in echoes):
            return Outcome(
                action="GUIDE", phrase=phrase, kind=kind, reason=reason,
                options=[],
                question=(f"This schema holds {', '.join(sorted({t for t, _c, _h in echoes})[:3])}, "
                          f"but nothing in it is named or described as "
                          f"\"{' '.join(sorted(specific))}\". {reason}").strip())
        if echoes:
            options = [Option(label=f"{t}.{c}",
                              means=f"the column \"{phrase}\" points at "
                                    f"({how})",
                              table=t, column=c)
                       for t, c, how in echoes[:4]]
            return Outcome(
                action="CLARIFY" if len(options) >= 2 else "GUIDE",
                phrase=phrase, kind=kind, reason=reason, options=options,
                question=(f"By \"{phrase}\", which do you mean?"
                          if len(options) >= 2 else
                          f"\"{phrase}\" may mean {options[0].label}. "
                          f"Use that?"))
        # Evidence of a neighbourhood only: a table whose description uses
        # the word, a column close in meaning. Enough to stop a denial, not
        # enough to offer a choice, so the columns are shown as leads and
        # the verdict stays "tell me more". A lead the reader confirms
        # becomes a question that names the column, and that one is judged
        # on its own words.
        near = [e for e in evidence if e[2] not in self.SUGGESTS]
        if near:
            leads = [Option(label=f"{t}.{c}",
                            means=("close in meaning" if how == "similar"
                                   else "its table is described that way"),
                            table=t, column=c)
                     for t, c, how in near[:4]]
            return Outcome(
                action="GUIDE", phrase=phrase, kind=kind, reason=reason,
                options=leads,
                question=(f"\"{phrase}\" is not named anywhere in this "
                          f"schema, but it may be held by "
                          f"{', '.join(o.label for o in leads)}. Say which, "
                          f"or say it another way."))
        # `resembles_column` above protects against denying a column that
        # exists. The same protection is owed to a value that exists: the
        # phrase may be a name sitting in a column nobody proposed, and
        # "nothing here can express it" would then be false. Checked
        # against the data before it is said.
        if (phrase.strip().lower() in self.words_for(
                "not_a_value", self.NOT_A_VALUE)
                or self.is_a_judgement(phrase)
                or self.is_a_phrasing(phrase)
                # the comparison usually sits in the question, not in the
                # fragment: "cheaper than a coffee" comes back as the
                # phrase "a coffee". Only ever used to withhold a denial,
                # which is the safe direction to be wrong in.
                or self.is_a_judgement(question)):
            # nothing was checked, so nothing is claimed: the outcome
            # stays a GUIDE but without `checked`, which is what tells a
            # coverage report to say "tell me more" rather than "your
            # database cannot do this"
            return Outcome(action="GUIDE", phrase=phrase, kind=kind, reason=reason,
                           options=[],
                           question=(f"\"{phrase}\" needs to be said more "
                                     f"precisely. {reason}"))
        holder, sweep_checked = self.check_value(phrase)
        if holder:
            table, column = holder
            return Outcome(
                action="CLARIFY", phrase=phrase, kind="AmbiSchema", reason=reason,
                question=f"By \"{phrase}\", which do you mean?",
                options=[Option(label=f"{table}.{column}",
                                means=f"the column that holds \"{phrase}\"",
                                table=table, column=column)])
        if sweep_checked:
            # Say what was checked, and only that. The sentence used to read
            # "Nothing here can express it", which is a claim about the
            # SCHEMA, while the sweep above looked at VALUES. Measured on
            # the demo library: "which books were written by Shakespeare in
            # 2020" came back "\"Shakespeare\" has no equivalent in this
            # database. Nothing here can express it." The database holds
            # authors.name and books.published_on and answers that question
            # in one query; what it does not hold is a row for Shakespeare,
            # which is an empty result and a perfectly good answer.
            #
            # The two are told apart by whether a column that could hold
            # such a value exists at all. The model proposed candidates;
            # any of them that is a real text column is a column of the
            # right kind for a literal, so the question is reachable and
            # what is missing is a row. With none, nothing in this schema
            # could ever hold it and the denial is about the schema.
            #
            # "Shakespeare" against authors.name is the first: the column
            # is there, no row matches, the answer is the empty set.
            # "Paris" against members, which has no place column at all,
            # is the second.
            #
            # Both rest on one query a reader can repeat, which is the
            # standard this component holds itself to.
            reachable = self.text_holders(raw.get("candidates"))
            if reachable:
                spelt = self.spelt_otherwise(phrase, reachable, question)
                if spelt:
                    return Outcome(action="ANSWER", phrase=phrase,
                                   kind=kind, reason=spelt)
                return self.empty_result(phrase, reachable, kind, reason)
            return Outcome(
                action="GUIDE", phrase=phrase, kind=kind, reason=reason,
                options=[], checked=True,
                question=(f"No value in this database matches "
                          f"\"{phrase}\": every text column was searched "
                          f"and none holds it, and no column of this "
                          f"schema could. {reason}"))
        return Outcome(
            action="GUIDE", phrase=phrase, kind=kind, reason=reason,
            options=[],
            question=(f"The database could not verify whether \"{phrase}\" "
                      f"has an equivalent. {reason}"))

    def clarify(self, question):
        # what a run keeps beside its verdicts (coverage.py): the reply as
        # the model wrote it and the tables it was shown; the outcome says
        # the rest. Reset first, so a question that fails never reports the
        # one before it.
        self.last_reply = self.last_shown = None
        raw = self.detect(question)
        self.last_reply = raw
        # the guards, as one step of the question's trace: what the model
        # said in, what the checks made of it out
        said = {k: raw.get(k) for k in ("ambiguous", "phrase", "kind", "reason")} \
            if isinstance(raw, dict) else None
        if said is not None:
            said["candidates"] = [f"{c.get('table')}.{c.get('column')}"
                                  for c in (raw.get("candidates") or [])[:6]
                                  if isinstance(c, dict)]
        with _step("guards", as_type="guardrail", input=said) as traced:
            outcome = self.ground(raw, unreachable=not self.llm.reachable()
                                  if raw is None else False,
                                  question=question)
            traced.update(output={"action": outcome.action, "kind": outcome.kind,
                                  "asks": outcome.question,
                                  "options": [o.label for o in outcome.options]})
        return outcome

    def rewrite(self, question, clarification, option):
        """The question restated with the choice made explicit. Falls back
        to appending the choice, so a model that is unavailable or
        unhelpful never blocks the pipeline."""
        fallback = (f"{question} (by \"{clarification.phrase}\" I mean "
                    f"{option.label})")
        text = self.llm.chat(
            "You rewrite a question so it is unambiguous. Reply with the "
            "rewritten question only, one sentence, no preamble, no SQL.",
            f"Question: {question}\nThe phrase \"{clarification.phrase}\" "
            f"means: {option.label}, that is, {option.means}\n"
            f"Rewrite the question.")
        if not text:
            return fallback
        text = text.strip().strip('"').split("\n")[0].strip()
        return text if 5 < len(text) < 400 else fallback


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--profile", default="datagora_generic")
    ap.add_argument("--endpoint", default=None,
                    help=f"model endpoint; known: {LLM.names()}")
    ap.add_argument("--question", required=True)
    args = ap.parse_args()

    llm = LLM.load(args.endpoint)
    if not llm.reachable():
        raise SystemExit(f"endpoint {llm.name} ({llm.url}) is unreachable")
    print(f"model: {llm.name} -> {llm.model}")

    clar = Clarifier(DbProfile.load(args.profile), llm)
    c = clar.clarify(args.question)
    print(f"\n-> {c.action}" + (f"   [{c.kind}] {c.reason}" if c.kind else ""))
    print(c.render())
    if c.options:
        print("\nif the user picks [1], the question becomes:")
        print(f"  {clar.rewrite(args.question, c, c.options[0])}")


if __name__ == "__main__":
    main()
