"""Which tables the model is shown when the schema is too large.

A schema of a few dozen tables is sent whole, as it always was. One of
several hundred cannot be: at 35 to 55 tokens a column (Gemma's tokenizer,
a column with its type, five values and its description), a 16K window
holds three to four hundred columns, and a production database of 250
tables holds several times that. The model server reads what fits and
drops the rest, the question with it, and the verdict is UNKNOWN.

Nor should it be, even where it fits. Measured on a 251-table database
(Warehouse and 238 tables of other trades), with the window filled to the
brim with the best-scored tables, 45 of them: the model was misled by what
had nothing to do with the question. "Lead time" found the CRM's `leads`,
"warranty duration" a `duration_minutes` of another trade, and two
questions with no answer in the data were declared answerable.

So every table is scored on how much it has to do with the question, and
what is left out is what scores far below the best: under MIN_SHARE of the
best table's score. Over the 25 questions measured, the least of the tables
a question needed scored 0.38 of the best, so MIN_SHARE sits well under it,
on the side of showing a table too many. At least MIN_TABLES are shown,
and never more than the window holds. Each signal has a low bar, because a
table left out that mattered costs more than a table shown that did not:

  words    a word of the question is in a table's name, a column's name,
           what the dictionary says a table or column means, a table's
           aliases, or the values a column holds and its codes' labels.
           Each word counts by how rare it is in the schema: "city", in
           sixty tables, says little; "warehouse", in three, says a lot.
  meaning  the column index (Qdrant) finds columns close in meaning to the
           question; a column counts by how far it stands above the others
           returned, so only the ones that stand out earn anything
  corpus   an earlier question close to this one (Qdrant, a bar set below
           the one used to name tables) was answered with these tables
  links    a table one join away from a table scored above: by a declared
           foreign key, by the dictionary, or by the Neo4j graph. The table
           between two others, which no word of the question names.

The tables nothing pointed at are shown only to make up MIN_TABLES, the
nearest by joins first. Nothing here decides a verdict: the guards that
withhold a NOT COVERED still read the whole catalogue.

The cut applies to a schema that does not fit the window, and to one of
more than FROM_TABLES tables even when it fits; a smaller one goes whole.

What is kept is not all shown alike. The FULL_TABLES best-scored tables
are shown whole, every column with its type, values and description; the
others in short form, their name and meaning and one line of column names
with the foreign keys' targets, about a quarter of the cost. Shown whole
in score order, 17 tables filled the room on the 156-table Enterprise
base, where 19 to 106 passed the share, and the table between two others
(shipment_lines, purchase_order_lines) was the one left out: every table
a question needed was shown for 30 of 37 questions. Eight whole and the
rest short, 35 of 37, for fewer tokens (7 600 against 8 600 a question).
"""

import math
import os
from collections import deque

if __package__:
    from .observability import get_logger
else:
    from observability import get_logger

log = get_logger("focus")

# where a word is found, and what that is worth before its rarity: the
# table's own name says the most, a value the least
WHERE = {"table": 3.0, "column": 2.0, "described": 1.5, "value": 1.0}
# the meaning signal: points for a column standing this many deviations
# above the others returned, MEANING at most
MEANING = 3.0
MEANING_Z = 3.0
MEANING_FROM_Z = 0.5
MEANING_LIMIT = 128
# with a reranker (rerank.py): the columns it reads, the closest by vector
# first; one it scores RERANK_FROM or more earns its table up to RERANKED
# more, on top of what the vector gave. It adds and never takes away, so
# a table the column index found is never lost to it.
RERANK_POOL = 40
RERANK_FROM = 0.5
RERANKED = 3.0
CORPUS = 3.0
# how far below the corpus's own bar a neighbour still points at tables:
# naming tables needs a close question, keeping one in view does not
CORPUS_BELOW = 0.15
CORPUS_NEIGHBOURS = 8
# a table one join away from a scored one gets this share of its score
LINK_SHARE = 0.5
# a table scoring under this share of the best is left out; the tables a
# question needed scored 0.38 of the best at the least (see above).
# DATAGORA_FOCUS_MIN_SHARE moves it, 0 keeps every table pointed at.
MIN_SHARE = 0.15
# never fewer tables than this, when the schema has them
MIN_TABLES = 12
# a schema of more tables than this is cut even when it fits the window
FROM_TABLES = 50
# the best-scored tables shown whole when the schema is cut; the others
# kept are shown in short form (see the module's docstring)
FULL_TABLES = 8
# tokens kept for the lines that say some tables are short and others not
# shown
NOTE_ROOM = 120
# Gemma's tokenizer reads every digit as a token of its own, so a schema of
# dates and amounts costs far more than its length says. The rest of a
# schema came to 2.7 to 3.2 characters a token, measured on prompts Ollama
# counted: 13 707 characters with 1 051 digits made 5 043 tokens, 34 511
# with 5 033 digits made 15 832. The lower figure is taken.
OTHER_CHARS_PER_TOKEN = 2.7


def min_share():
    """MIN_SHARE, or DATAGORA_FOCUS_MIN_SHARE when it reads as a number
    from 0 to 1; read at every question, so a change applies at once."""
    try:
        value = float(str(os.environ.get("DATAGORA_FOCUS_MIN_SHARE") or "").strip())
    except ValueError:
        return MIN_SHARE
    return value if 0.0 <= value <= 1.0 else MIN_SHARE


def wanted(clar, blocks, room):
    """Whether this schema is cut: it does not fit, or it has more than
    FROM_TABLES tables. `room` None means no window to keep to."""
    if room is None:
        return False
    whole = sum(tokens(b, clar._token_scale) + 1 for b in blocks.values())
    return whole > room or len(blocks) > FROM_TABLES


def tokens(text, scale=1.0):
    """The tokens a schema text costs, estimated as llm.estimate_tokens
    counts them (digits, the rest of ASCII, accented letters and other
    scripts each at their own rate); `scale` is the correction a clarifier
    learned from the counts its model server returned."""
    # one estimate for the whole engine, imported at the call: once llm is
    # loaded this is a dictionary lookup, and focus loads without it
    if __package__:
        from .llm import estimate_tokens
    else:
        from llm import estimate_tokens
    return int(estimate_tokens(text or "") * scale) + 1


def vocabulary(clar):
    """{table: {word: where}}, every word that can point at a table, with
    the strongest place it was found. Built once per clarifier."""
    cached = getattr(clar, "_focus_vocabulary", None)
    if cached is not None:
        return cached
    rank = {k: i for i, k in enumerate(("value", "described", "column", "table"))}
    found = {}

    def put(table, words, where):
        seen = found.setdefault(table, {})
        for w in words:
            if rank[where] > rank.get(seen.get(w), -1):
                seen[w] = where

    samples = getattr(clar, "samples", None) or {}
    for table, cols in clar.columns.items():
        put(table, clar._identifier_tokens(table) | {clar._singular(table)}, "table")
        put(table, clar._content_words(" ".join(
            [clar.means(table)]
            + sorted(clar._documented("aliases").get(table.lower()) or []))),
            "described")
        for column, _dtype in cols:
            if not clar.is_a_key(table, column):
                put(table, clar._identifier_tokens(column), "column")
            put(table, clar._content_words(clar._said(table, column)), "described")
            values = samples.get((table.lower(), column.lower()))
            if values:
                put(table, clar._content_words(" ".join(map(str, values))), "value")
    clar._focus_vocabulary = found
    return found


def _reranked(clar, index, question):
    """{table: points} from the closest RERANK_POOL columns as the
    reranker reads them against the question, or {} without a reranker or
    when it could not say."""
    reranker = getattr(clar, "reranker", None)
    # a cross-encoder only: what an embedding model as reranker does to the
    # columns of a schema has not been measured, where the column index is
    # already one embedding's reading of them
    if reranker is None or getattr(getattr(reranker, "model", None), "api", "") != "local":
        return {}
    if __package__:
        from .rerank import rerank
    else:
        from rerank import rerank
    found = index.candidates(question, limit=RERANK_POOL)
    if not found:
        return {}
    ranked = rerank(question, found, text=lambda c: c[3] or f"{c[0]}.{c[1]}",
                    reranker=reranker)
    if not ranked or ranked[0][1] is None:
        return {}
    best = {}
    for (table, _column, _vector, _text), score in ranked:
        if table and score >= RERANK_FROM:
            best[table] = max(best.get(table, 0.0), RERANKED * score)
    return best


def rank(clar, text, blocks):
    """[(table, score, why)], every table of `blocks`, most related to
    `text` first.

    The tables a signal pointed at come first, best score first, then by
    name; then the others, nearest by joins to those first, then by name,
    with a score of 0 and no signal. `why` lists the signals that pointed
    at a table, in the order they were read. Each signal that cannot be had
    (no index, no corpus, no graph) is skipped, never fatal. choose() cuts
    a schema on this order; a tool that searches the tables reads it as
    is."""
    lower = {t.lower(): t for t in blocks}
    score = {t: 0.0 for t in blocks}
    why = {t: [] for t in blocks}

    def add(signal, table, points):
        t = lower.get(str(table or "").lower())
        if t is not None and points > 0:
            score[t] += points
            if signal not in why[t]:
                why[t].append(signal)

    try:
        # the words that only compute or connect bring no table in: an
        # average_score column has nothing to do with "average lead time"
        words = clar._content_words(text) - clar.operation_words()
        vocab = vocabulary(clar)
        n = max(len(blocks), 1)
        for w in words:
            holders = [t for t in blocks if w in vocab.get(t, {})]
            if not holders:
                continue
            rarity = math.log((n + 1) / len(holders))
            for t in holders:
                add("words", t, WHERE[vocab[t][w]] * rarity)
    except Exception as e:
        log.info("focus: words not read: %s", str(e)[:90])

    try:
        index = clar.index
        if index is not None:
            best = {}
            for table, _column, _score, z in index.standing(text,
                                                            limit=MEANING_LIMIT):
                if table and z >= MEANING_FROM_Z:
                    best[table] = max(best.get(table, 0.0),
                                      min(MEANING, MEANING * z / MEANING_Z))
            for table, points in best.items():
                add("meaning", table, points)
            for table, points in _reranked(clar, index, text).items():
                add("reranked", table, points)
    except Exception as e:
        log.info("focus: meaning not read: %s", str(e)[:90])

    try:
        corpus = clar.corpus
        if corpus is not None:
            if __package__:
                from .recall import corpus_min_score
            else:
                from recall import corpus_min_score
            bar = corpus_min_score(corpus.embed_model) - CORPUS_BELOW
            best = {}
            for similarity, payload in corpus.neighbours(text, CORPUS_NEIGHBOURS):
                if similarity >= bar:
                    for table in payload.get("tables") or []:
                        best[table] = max(best.get(table, 0.0), CORPUS * similarity)
            for table, points in best.items():
                add("corpus", table, points)
    except Exception as e:
        log.info("focus: corpus not read: %s", str(e)[:90])

    links = {}
    try:
        links = clar.table_links()
    except Exception as e:
        log.info("focus: links not read: %s", str(e)[:90])
    own = dict(score)
    for t, s in sorted(((t, s) for t, s in own.items() if s > 0),
                       key=lambda x: -x[1]):
        for other in links.get(t.lower(), ()):
            u = lower.get(other)
            if u is not None and score[u] < LINK_SHARE * s:
                score[u] = LINK_SHARE * s
                if "links" not in why[u]:
                    why[u].append("links")

    pointed = sorted((t for t in blocks if score[t] > 0),
                     key=lambda t: (-score[t], t))
    # the rest, nearest by joins to what was pointed at, then by name
    hops = {t: 0 for t in pointed}
    queue = deque(pointed)
    while queue:
        t = queue.popleft()
        for other in links.get(t.lower(), ()):
            u = lower.get(other)
            if u is not None and u not in hops:
                hops[u] = hops[t] + 1
                queue.append(u)
    rest = sorted((t for t in blocks if score[t] <= 0),
                  key=lambda t: (hops.get(t, 10 ** 6), t))
    return [(t, score[t], why[t]) for t in pointed + rest]


def choose(clar, question, blocks, room, scale=1.0, short=None):
    """(tables to show, most related first; a report of the choice).

    `blocks` is {table: its lines as schema_text writes them}, `room` the
    tokens the schema may take, `scale` the clarifier's correction to the
    estimate, `short` {table: its short form}, or None to show every table
    whole. The report's "short" lists the tables to show in short form.
    The tables are ranked by rank(), and each signal that cannot be had
    (no index, no corpus, no graph) is skipped, never fatal."""
    ranked = rank(clar, question, blocks)
    score = {t: s for t, s, _why in ranked}
    why = {t: w for t, _s, w in ranked}
    pointed = [t for t, s, _why in ranked if s > 0]
    rest = [t for t, s, _why in ranked if s <= 0]

    # what scores far below the best is left out; the rest of the ranking
    # only makes up the minimum
    share = min_share()
    best = score[pointed[0]] if pointed else 0.0
    relevant = [t for t in pointed if score[t] >= share * best]
    others = [t for t in pointed + rest if t not in set(relevant)]
    wanted = relevant + others[:max(0, MIN_TABLES - len(relevant))]

    # the best FULL_TABLES whole, the rest short; a table that does not fit
    # whole may still fit short, and a smaller one further down may fit
    # when this one does not
    short = short or {}
    kept, in_short, used = [], [], 0
    limit = max(room - NOTE_ROOM, 0)
    for t in wanted:
        forms = ([blocks[t]] if len(kept) - len(in_short) < FULL_TABLES else []) \
            + ([short[t]] if t in short else [])
        for text in forms or [blocks[t]]:
            cost = tokens(text, scale) + 1
            if used + cost <= limit:
                kept.append(t)
                used += cost
                if text is not blocks[t]:
                    in_short.append(t)
                break

    taken = set(kept)
    by = {}
    for t in kept:
        for signal in (why[t] or ["nearby"]):
            by[signal] = by.get(signal, 0) + 1
    report = {"tables": len(blocks), "kept": len(kept), "short": in_short,
              "pointed": len(pointed), "relevant": len(relevant),
              "share": share,
              "relevant_left_out": [t for t in relevant if t not in taken][:20],
              "tokens_whole": sum(tokens(b, scale) + 1 for b in blocks.values()),
              "tokens_kept": used, "room": room, "by": by,
              "scores": {t: round(score[t], 2) for t in pointed[:30]},
              "all_scores": {t: round(score[t], 3) for t in pointed}}
    return kept, report


def note(left_out, short=0):
    """The lines that end a cut schema, so the model knows it is one: that
    a table in short form is as real as one shown whole, and that a table
    or a join not shown is not one the database lacks. Without them the
    judge read a cut schema as the whole and said data was missing when
    only the table between two others had been left out."""
    lines = []
    if short:
        lines.append(
            f"-- {short} of the tables above are shown in short form, their "
            f"column names only: they are real tables of this database, "
            f"their columns hold data like the others, and they join by "
            f"the columns marked ->.")
    if left_out:
        lines.append(
            f"-- {left_out} more tables of this database are not shown: "
            f"less related to this question than the ones above. A table "
            f"or a join that is not shown may still exist; do not say one "
            f"is missing only because it is not here.")
    return chr(10).join(lines)
