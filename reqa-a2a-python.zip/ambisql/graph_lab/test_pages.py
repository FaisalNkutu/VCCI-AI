"""The pages put what the database returns into HTML only escaped. No
server, no browser: a reading of the page sources. And common.js, the
helpers three of them share, served by the app and parsed by node when it
is installed."""

import pathlib
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE = pathlib.Path(__file__).resolve().parent
UI = HERE / "ui"


class AskPageTests(unittest.TestCase):

    def setUp(self):
        self.page = (UI / "index.html").read_text(encoding="utf-8")

    def test_the_answer_tables_escape_every_value_and_column(self):
        # review of 23 October: a value holding <img onerror=...> ran in the
        # asker's browser, the rows and column names went in as HTML
        self.assertNotRegex(self.page, r'"<td>"\s*\+\s*\(v === null \? "" : v\)')
        self.assertNotRegex(self.page, r'"<th>"\s*\+\s*c\s*\+')
        self.assertNotRegex(self.page, r"\$\{v === null \? \"\" : v\}")
        self.assertNotRegex(self.page, r">\$\{c\}</th>")
        self.assertEqual(len(re.findall(r"esc\(v\)", self.page)), 2)
        self.assertEqual(len(re.findall(r"esc\(c\)", self.page)), 2)

    def test_the_steps_and_their_details_are_escaped(self):
        self.assertIn("esc(s.name)", self.page)
        self.assertIn("esc(labelFor(e.name))", self.page)

    def test_one_question_at_a_time_on_the_database_it_was_asked_on(self):
        # review of 26 October: two Enters sent two streams, and Ask again
        # from History asked on the first database when its own was gone
        body = self.page[self.page.index("async function ask("):]
        self.assertLess(body.index('if($("go").disabled) return;'), body.index("const question"))
        self.assertIn("This question was asked on ${wanted}", self.page)
        # the chips are named by database, not by profile
        self.assertIn("EXAMPLES[DB_OF[name]]", self.page)

    def test_the_health_check_never_overlaps_or_runs_hidden(self):
        # pollHealth is in common.js, shared with the coverage page
        common = (UI / "common.js").read_text(encoding="utf-8")
        self.assertNotIn("setInterval(drawHealth", self.page)
        self.assertIn("setInterval(pollHealth", self.page)
        self.assertIn("if(healthBusy || document.hidden) return;", common)

    def test_a_screen_reader_hears_the_answer_and_links_are_web_addresses(self):
        self.assertRegex(self.page, r'id="answer"[^>]*aria-live="polite"')
        self.assertRegex(self.page, r'id="progress"[^>]*role="status"')
        self.assertIn(r"/^https?:\/\//i.test(d.trace_url)", self.page)


class CoveragePageTests(unittest.TestCase):

    def setUp(self):
        self.page = (UI / "coverage.html").read_text(encoding="utf-8")

    def test_a_followed_run_is_drawn_once_a_frame_and_saved_once_a_second(self):
        # review of 26 October: 2000 replayed verdicts froze the tab
        keep = self.page[self.page.index("function keep(v){"):]
        keep = keep[:keep.index("}")]
        self.assertIn("drawSoon()", keep)
        self.assertNotIn("drawRows()", keep)
        verdict = self.page[self.page.index('else if(e.type === "verdict"){'):]
        verdict = verdict[:verdict.index("else if(", 1)]
        self.assertIn("saveSoon(profile, csv", verdict)
        self.assertNotIn("saveRun(", verdict)
        self.assertNotIn("setInterval(drawHealth", self.page)

    def test_follow_it_live_lets_go_of_the_run_on_screen(self):
        follow = self.page[self.page.index("async function followOther(x){"):]
        follow = follow[:follow.index("const known")]
        self.assertIn("await detach();", follow)


class HistoryPageTests(unittest.TestCase):

    def setUp(self):
        self.page = (UI / "history.html").read_text(encoding="utf-8")

    def test_everything_kept_of_the_judge_is_shown(self):
        # review of 26 October: missing, gap, the tables and the note were
        # kept and never shown
        for said in ("J.missing", 'J.gap === "data"', "a.judged_tables", "a.earlier"):
            self.assertIn(said, self.page)

    def test_the_runs_tab_follows_the_runs_going_on_and_the_count_is_honest(self):
        live = self.page[self.page.index("async function loadLive(){"):]
        self.assertIn("loadRuns();", live[:live.index("$(\"livecard\")")])
        self.assertIn("total > asks.length", self.page)

    def test_values_go_into_the_tables_escaped(self):
        self.assertIn("<td>${esc(x)}</td>", self.page)
        self.assertIn('<th scope="col">${esc(c)}</th>', self.page)
        self.assertNotRegex(self.page, r"<td>\$\{(?!esc\()")


    def test_review_of_the_fixes_a_hidden_history_asks_nothing(self):
        live = self.page[self.page.index("async function loadLive(){"):]
        self.assertTrue(live.split("\n")[2].strip().startswith("if(document.hidden) return;"))
        self.assertIn("else if(stale.length) fillMixes(", live)


# What common.js holds for the Ask, coverage and history pages, each of
# which used to keep a copy (review of 26 October, Serveur 15). None may
# declare one again: a page's own `const esc` next to the shared one stops
# its whole script before it runs.
SHARED = ("$", "esc", "fileUrl", "duration", "configBanner", "drawHealth",
          "healthBusy", "pollHealth", "showLive", "hideLive")
SHARING = ("index.html", "coverage.html", "history.html")


def declares(name):
    name = re.escape(name)
    return re.compile(rf"^\s*(?:(?:async\s+)?function\s+{name}\s*\(|(?:const|let|var)\s+{name}\s*=)",
                      re.MULTILINE)


def inline_scripts(page):
    return re.findall(r"<script>(.*?)</script>", page, re.DOTALL)


class CommonScriptTests(unittest.TestCase):

    def test_it_is_served_as_a_script(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        env = patch.dict("os.environ", {"DATAGORA_TRACING": "off", "DATAGORA_DOTENV": "off",
                                        "DATAGORA_COLUMN_INDEX": "off",
                                        "DATAGORA_COVERAGE_DIR": tmp.name,
                                        "DATAGORA_DATA_DIR": tmp.name})
        env.start()
        self.addCleanup(env.stop)
        for path in (str(HERE), str(UI)):
            if path not in sys.path:
                sys.path.insert(0, path)
        import app
        from fastapi.testclient import TestClient
        r = TestClient(app.app).get("/common.js")
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.headers["content-type"].startswith("text/javascript"))
        for name in SHARED:
            self.assertRegex(r.text, declares(name))

    def test_each_page_loads_it_before_its_own_script(self):
        for name in SHARING:
            page = (UI / name).read_text(encoding="utf-8")
            tag = '<script src="/common.js"></script>'
            self.assertEqual(page.count(tag), 1, name)
            self.assertLess(page.index(tag), page.index("<script>"), name)

    def test_no_page_keeps_a_copy(self):
        for name in SHARING:
            scripts = inline_scripts((UI / name).read_text(encoding="utf-8"))
            self.assertTrue(scripts, name)
            for helper in SHARED:
                for script in scripts:
                    self.assertNotRegex(script, declares(helper), f"{name} declares {helper}")

    @unittest.skipUnless(shutil.which("node"), "node is not installed")
    def test_the_scripts_parse_and_declare_nothing_twice(self):
        # each parses on its own (node --check), then common.js and the
        # page's script run one after the other in one global scope, as the
        # browser runs them. Without a DOM the page stops at its first use
        # of one; a name declared twice stops it before anything runs, with
        # the only SyntaxError a script that parses can raise there.
        common = UI / "common.js"
        run = ("const vm = require('vm'), fs = require('fs');"
               "const [common, ...page] = process.argv.slice(1);"
               "const scope = vm.createContext({});"
               "new vm.Script(fs.readFileSync(common, 'utf8')).runInContext(scope);"
               "for(const file of page){"
               "  try{ new vm.Script(fs.readFileSync(file, 'utf8')).runInContext(scope); }"
               "  catch(e){ if(e.name === 'SyntaxError'){ process.stdout.write(e.message); process.exit(1); } }"
               "}"
               "process.stdout.write('ok');")
        with tempfile.TemporaryDirectory() as tmp:
            done = subprocess.run(["node", "--check", str(common)], capture_output=True,
                                  text=True, timeout=30)
            self.assertEqual(done.returncode, 0, done.stderr)
            for name in SHARING:
                files = []
                for i, script in enumerate(inline_scripts((UI / name).read_text(encoding="utf-8"))):
                    files.append(pathlib.Path(tmp) / f"{pathlib.Path(name).stem}_{i}.js")
                    files[-1].write_text(script, encoding="utf-8")
                    done = subprocess.run(["node", "--check", str(files[-1])], capture_output=True,
                                          text=True, timeout=30)
                    self.assertEqual(done.returncode, 0, f"{name}: {done.stderr}")
                done = subprocess.run(["node", "-e", run, str(common), *map(str, files)],
                                      capture_output=True, text=True, timeout=30)
                self.assertEqual((done.returncode, done.stdout), (0, "ok"), f"{name}: {done.stderr}")


class PackageTests(unittest.TestCase):

    def test_every_file_the_server_serves_is_packaged(self):
        # review of 26 October: the wheel had the pages but not the four
        # scripts they load, and an installed UI failed on every page
        import fnmatch
        app = (UI / "app.py").read_text(encoding="utf-8")
        served = set(re.findall(r'FileResponse\(HERE / "([^"]+)"', app))
        self.assertIn("theme.js", served)
        project = (UI.parents[2] / "pyproject.toml").read_text(encoding="utf-8")
        data = project[project.index("[tool.setuptools.package-data]"):]
        data = data[:data.index("\n]") + 2]
        patterns = re.findall(r'"([^"]+)"', data)
        for name in served:
            self.assertTrue(any(fnmatch.fnmatch(f"ui/{name}", p) for p in patterns), name)


if __name__ == "__main__":
    unittest.main()
