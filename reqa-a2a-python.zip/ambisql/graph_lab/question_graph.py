"""The schema of a database as a graph, and what one judged question used of it.

The coverage page draws, under a question the judge found ANSWERABLE,
NEEDS A CHOICE or NEEDS MORE, the tables the judge used, the joins between
them and their neighbours one join away. Two pieces, kept apart so each is
made once:

    schema_graph(clar)  every table with its columns (type, primary key,
                        foreign key) and every link with its multiplicity
                        at each end, UML style. Read once per database by
                        the app and fetched once per database by the page.
    highlight(trace)    what one question used: its tables, its columns
                        and, for a choice, each reading's tables and
                        columns. Small, read from the run's trace, sent
                        with each verdict.
    fallback(graph, q)  the same for a question whose trace names no
                        table, from the judge's words, its options or the
                        question's own words, and said to be guessed.

The page draws the highlighted tables and their neighbours from the graph
it holds, so a question costs no schema read at all.

What a question used comes from the trace Ledger.keep_trace writes:

    the agent judge   its conclusion's tables, columns and joins, and the
                      readings of each issue (table, column, SQL)
    the single judge  the tables and columns its reason names among those
                      it was shown, the candidates of its reply (a reading
                      each for a choice), and the join an option goes
                      through (`via`) when the trace keeps one

Names are passed as the trace spells them; the page matches them to the
graph without regard to case and leaves out a name the schema does not
hold, which is how a column read off a SQL expression costs nothing when
it is not one.
"""

import json
import os
import re
import urllib.parse

DRAWN = ("ANSWERABLE", "NEEDS A CHOICE", "NEEDS MORE")
CHOICE = "NEEDS A CHOICE"
# the Neo4j Browser, as the person at the page reaches it
BROWSER = "http://localhost:7474/browser/"

_QUOTES = str.maketrans("", "", "`\"[]")
# "a.x = b.y", a schema prefix allowed on either side
_NAME = r"[A-Za-z_]\w*"
_ATOM = re.compile(rf"(?<![\w.])(?:{_NAME}\.)?({_NAME})\.({_NAME})\s*=\s*"
                   rf"(?:{_NAME}\.)?({_NAME})\.({_NAME})(?![\w.])")
# table.column, and not a function call
_DOTTED = re.compile(rf"(?<![\w.])({_NAME})\.({_NAME})(?![\w.(])")
_FROM = re.compile(r"\b(?:FROM|JOIN)\s+([\w.]+)(?:\s+(?:AS\s+)?(\w+))?", re.I)
_NOT_ALIAS = {"on", "where", "join", "left", "right", "inner", "outer", "full",
              "cross", "natural", "group", "order", "limit", "having", "union",
              "using", "straight_join", "window", "lateral", "for"}
# UML multiplicity of a relationship's cardinality, as the knowledge bases
# spell it ("Exactly One", "Zero Or More", "Zero or One")
_CARDS = {"exactly one": "1", "one": "1", "zero or one": "0..1",
          "zero or more": "*", "many": "*", "one or more": "1..*"}


# ------------------------------------------------------------ the graph
def multiplicity(text):
    """"0..1" for "Zero or One", "*" for "Zero Or More"; "" when unknown."""
    return _CARDS.get(" ".join(str(text or "").lower().replace("_", " ").split()), "")


def _columns_of(spec):
    return [c.strip() for c in str(spec or "").split(",") if c.strip()]


def _primary_keys(clar):
    """{(table, column)}, lower case: the catalogue's primary keys, one
    query, and the dictionary's. `keys` alone mixes them with the foreign
    keys, and a child table's key is often both."""
    found = set()
    try:
        con = clar.connect()
        try:
            cur = con.cursor()
            cur.execute(
                """SELECT table_name, column_name
                   FROM information_schema.key_column_usage
                   WHERE table_schema=%s AND constraint_name='PRIMARY'""",
                (clar.schema,))
            found = {(str(t or "").lower(), str(c or "").lower())
                     for t, c in cur.fetchall()}
            cur.close()
        finally:
            con.close()
    except Exception:
        found = set()
    try:
        for table, cols in (clar._documented("primary") or {}).items():
            found.update((str(table).lower(), str(c).lower()) for c in cols)
    except Exception:
        pass
    return found


def schema_graph(clar):
    """{"tables": [{name, columns: [{name, type, pk, fk}]}], "links": [...]}.

    A link is {source, target, via, condition, source_card, target_card,
    kind}: `source` holds the reference and `target` is the table it
    references, `via` the join ("a.x = b.y", composite keys joined by
    " AND "), `condition` the type code a polymorphic link holds under.
    The referencing end is "*" and the referenced end "1", unless the
    dictionary's relationship gives a cardinality ("Zero or One" is 0..1).

    Read from the clarifier the judge uses, so the graph is the schema the
    verdicts were reached on: the catalogue's columns and foreign keys, the
    dictionary's links and polymorphic links, and the Neo4j graph's joins,
    a link read from two of them kept once, from the surer (the order
    SchemaView reads them in). Its sample values are never read: a picture
    needs none, and they are most of the cost of reading a schema."""
    columns = {t: list(cols) for t, cols in (clar.columns or {}).items()}
    tables = {t.lower(): t for t in columns}
    names = {t.lower(): {str(c).lower(): c for c, _d in cols} for t, cols in columns.items()}
    primary = _primary_keys(clar)
    try:
        documented = dict(clar._documented("links") or {})
    except Exception:
        documented = {}
    try:
        polymorphic = dict(clar._documented("polymorphic") or {})
    except Exception:
        polymorphic = {}

    links, seen = [], set()

    def add(child, child_cols, parent, parent_cols, kind, condition="", about=None):
        a, b = tables.get(str(child or "").lower()), tables.get(str(parent or "").lower())
        left, right = _columns_of(child_cols), _columns_of(parent_cols)
        if a is None or b is None or not left or len(left) != len(right):
            return
        left = [names[a.lower()].get(c.lower()) for c in left]
        right = [names[b.lower()].get(c.lower()) for c in right]
        if None in left or None in right:
            return
        key = (a.lower(), tuple(c.lower() for c in left), b.lower(),
               tuple(c.lower() for c in right), str(condition or "").lower())
        if key in seen:
            return            # the same join, read from a surer source
        seen.add(key)
        about = about or {}
        far = multiplicity(about.get("cardinality"))
        # a parent_of relationship says how many children; a child_of one
        # how many parents
        many, one = ((far or "*", "1") if about.get("role") == "parent_of"
                     else ("*", far or "1"))
        links.append({"source": a, "target": b,
                      "via": " AND ".join(f"{a}.{x} = {b}.{y}" for x, y in zip(left, right)),
                      "condition": str(condition or ""),
                      "source_card": many, "target_card": one, "kind": kind})

    def about_of(table, column, other=None, other_column=None):
        """The dictionary's relationship behind a link, for its cardinality:
        a polymorphic one when the target is named, a plain one otherwise."""
        key = (str(table).lower(), str(column).lower())
        if other is None:
            found = documented.get(key)
            return found[2] if found and len(found) > 2 and isinstance(found[2], dict) else None
        for target in polymorphic.get(key) or []:
            if (str(target[0]).lower(), str(target[1]).lower()) == (
                    str(other).lower(), str(other_column).lower()):
                return target[2] if len(target) > 2 and isinstance(target[2], dict) else None
        return None

    try:
        clar.foreign_keys            # reads the catalogue's own keys
        declared = getattr(clar, "_foreign_keys", None) or {}
    except Exception:
        declared = {}
    for (table, column), (other, other_column) in sorted(declared.items()):
        add(table, column, other, other_column, "fk", about=about_of(table, column))
    try:
        graph = list(clar.graph_edges or [])
    except Exception:
        graph = []
    for edge in graph:
        if len(edge) < 4:
            continue
        condition = edge[4] if len(edge) > 4 and isinstance(edge[4], str) else ""
        first = (_columns_of(edge[1]) or [""])[0]
        other = (_columns_of(edge[3]) or [""])[0]
        add(edge[0], edge[1], edge[2], edge[3], "graph", condition,
            about_of(edge[0], first, edge[2], other) if condition
            else about_of(edge[0], first))
    for (table, column), (other, other_column, *rest) in sorted(
            documented.items(), key=lambda kv: str(kv[0])):
        add(table, column, other, other_column, "kb",
            about=rest[0] if rest and isinstance(rest[0], dict) else None)
    for (table, column), targets in sorted(polymorphic.items(), key=lambda kv: str(kv[0])):
        for other, other_column, *rest in targets:
            about = rest[0] if rest and isinstance(rest[0], dict) else {}
            when = about.get("when") if isinstance(about.get("when"), dict) else {}
            holder = tables.get(str(table).lower(), table)
            value = str(when.get("value", "")).replace("'", "''")
            # spelled as SchemaView spells it, so the graph's copy of the
            # same link is recognised as the same
            condition = f"{holder}.{when['column']} = '{value}'" if when.get("column") else ""
            add(table, column, other, other_column, "kb", condition, about)

    refs = {}
    for link in links:
        for atom in _ATOM.findall(link["via"]):
            refs.setdefault((atom[0].lower(), atom[1].lower()), []).append(f"{atom[2]}.{atom[3]}")
    out_tables = []
    for table in sorted(columns, key=str.lower):
        cols = []
        for column, dtype in columns[table]:
            pair = (table.lower(), str(column).lower())
            cols.append({"name": column, "type": str(dtype or "").lower(),
                         "pk": pair in primary,
                         "fk": " | ".join(dict.fromkeys(refs.get(pair, []))) or None})
        out_tables.append({"name": table, "columns": cols})
    return {"tables": out_tables, "links": links}


# ------------------------------------------------- what a question used
def _atoms(text):
    """[(table, column, table, column)] of every "a.x = b.y" in the text."""
    return _ATOM.findall(str(text or "").translate(_QUOTES))


def _sql_names(sql):
    """{name or alias, lower case: table} of a query's FROM and JOIN clauses."""
    found = {}
    for m in _FROM.finditer(str(sql or "").translate(_QUOTES)):
        table = m.group(1).rpartition(".")[2]
        found.setdefault(table.lower(), table)
        alias = m.group(2)
        if alias and alias.lower() not in _NOT_ALIAS:
            found.setdefault(alias.lower(), table)
    return found


class _Picked:
    """Tables and columns, each kept once whatever its case, in order."""

    def __init__(self):
        self.tables, self.columns = {}, {}

    def table(self, name):
        name = str(name or "").strip().translate(_QUOTES)
        if re.fullmatch(_NAME, name):
            self.tables.setdefault(name.lower(), name)

    def column(self, table, column):
        table = str(table or "").strip().translate(_QUOTES)
        column = str(column or "").strip().translate(_QUOTES)
        if re.fullmatch(_NAME, table) and re.fullmatch(_NAME, column):
            self.table(table)
            self.columns.setdefault(f"{table}.{column}".lower(), f"{table}.{column}")

    def join(self, text, aliases=None):
        aliases = aliases or {}
        for a, x, b, y in _atoms(text):
            self.column(aliases.get(a.lower(), a), x)
            self.column(aliases.get(b.lower(), b), y)

    def lists(self):
        return list(self.tables.values()), list(self.columns.values())


def _reading(label, means, table, column, sql=None, via=None):
    """One reading of a choice: its tables and columns, from its table and
    column, the query that reads it and the join it goes through."""
    picked = _Picked()
    picked.table(table)
    text = str(column or "")
    if re.fullmatch(r"\s*\w+\s*", text):
        picked.column(table, text)
    else:
        # "actual_end > planned_end", "goods_receipts.receipt_date > ...":
        # every name it holds, qualified or of the reading's table
        for t, c in _DOTTED.findall(text):
            picked.column(t, c)
        bare = _DOTTED.sub(" ", text)
        for word in re.findall(r"[A-Za-z_]\w*", bare):
            picked.column(table, word)
    aliases = _sql_names(sql)
    for name in aliases.values():
        picked.table(name)
    picked.join(sql, aliases)
    picked.join(via)
    tables, columns = picked.lists()
    return {"label": str(label or column or table or ""), "means": str(means or ""),
            "tables": tables, "columns": columns}


def _agent(trace, picked):
    conclusion = trace.get("conclusion") if isinstance(trace.get("conclusion"), dict) else {}
    for table in conclusion.get("tables") or []:
        picked.table(table)
    for col in conclusion.get("columns") or []:
        if isinstance(col, dict):
            picked.column(col.get("table"), col.get("column"))
    for join in conclusion.get("joins") or []:
        picked.join(join)
    readings = []
    for issue in conclusion.get("issues") or []:
        for r in (issue.get("readings") or []) if isinstance(issue, dict) else []:
            if isinstance(r, dict):
                readings.append(_reading(r.get("label"), r.get("means"), r.get("table"),
                                         r.get("column"), r.get("sql"), r.get("via")))
    return readings


def _single(trace, picked, verdict, choices):
    reply = trace.get("reply") if isinstance(trace.get("reply"), dict) else {}
    shown = {str(t).lower(): str(t) for t in trace.get("tables_shown") or [] if t}
    # the tables its reason names, among those it was shown: a word that
    # names a table, or table.column
    said = " ".join(str(x) for x in (reply.get("reason"), trace.get("reason")) if x)
    for t, c in _DOTTED.findall(said.translate(_QUOTES)):
        if t.lower() in shown:
            picked.column(shown[t.lower()], c)
    for word in re.findall(r"\w+", _DOTTED.sub(" ", said)):
        if word.lower() in shown:
            picked.table(shown[word.lower()])
    options = [o for o in (trace.get("options") or reply.get("candidates") or [])
               if isinstance(o, dict)]
    readings = []
    if verdict == CHOICE:
        for n, o in enumerate(options):
            label = (choices[n] if n < len(choices) and choices[n] else o.get("label")
                     or ".".join(str(x) for x in (o.get("table"), o.get("column")) if x))
            readings.append(_reading(label, o.get("means"), o.get("table"),
                                     o.get("column"), via=o.get("via")))
        if not options:
            # a trace that kept only the labels: "table.column" is a reading
            for label in choices:
                m = re.fullmatch(r"\s*(\w+)\.(\w+)\s*", str(label or ""))
                if m:
                    readings.append(_reading(label, "", m.group(1), m.group(2)))
    else:
        for o in options:
            picked.table(o.get("table"))
            picked.column(o.get("table"), o.get("column"))
            picked.join(o.get("via"))
    return readings


def highlight(trace, verdict=None, choices=None):
    """{"tables", "columns", "readings"}: what one judged question used of
    the schema, for the page to highlight on the schema graph. None for a
    verdict with no path to show (NOT COVERED, NO DATA, UNKNOWN) and for a
    trace that names no table (a clarifier of another make keeps none).

    `verdict` and `choices` default to the trace's own, which the run's
    trace file holds; a verdict in flight passes them, its trace being the
    clarifier's alone. Tables and columns are names as the trace spells
    them, columns "table.column"; each reading has a label, what it means,
    and its own tables and columns."""
    if not isinstance(trace, dict):
        return None
    verdict = verdict or trace.get("verdict")
    if verdict not in DRAWN:
        return None
    choices = [str(c) for c in (choices if choices is not None else trace.get("choices") or [])]
    picked = _Picked()
    if trace.get("mode") == "agent" or isinstance(trace.get("conclusion"), dict):
        readings = _agent(trace, picked)
    else:
        readings = _single(trace, picked, verdict, choices)
    tables, columns = picked.lists()
    readings = [r for r in readings if r["tables"]]
    if not tables and not readings:
        return None
    return {"tables": tables, "columns": columns, "readings": readings}



# ------------------------------------------------------- without a record
# words that name no table nor column on their own
_PLAIN = frozenset("""a an the of in on at to for by with from and or not no is are was
were be been has have had do does did what which who whom whose how when where why many
much most least more less top total number count sum average per each every all any some
our their its this that these those than then there here it they we you your list show
give find tell""".split())
# column words too common to say which column a question means
_COMMON = frozenset({"id", "name", "code", "date", "type", "status", "description", "at"})
GUESS_TABLES = 4


def fallback(graph, question, said="", choices=(), verdict=None):
    """What a judged question used, when its trace says nothing of its
    tables: a run saved before traces were written, or a single judge that
    did not keep the tables it was shown. {"tables", "columns", "readings",
    "guessed"}, or None for a verdict with no path to show or nothing found.

    In order: the tables the judge's own words name ("The warehouses table
    contains both the name and city...", `said`), guessed "reason"; the
    options of a choice ("table.column"), guessed "choice"; else the tables
    the question's words name, a table named in full first, guessed
    "question". The page says which: none of them is a record of what the
    judge read."""
    if verdict not in DRAWN or not isinstance(graph, dict):
        return None
    from ambisql import Clarifier
    singular = Clarifier._singular
    tables = {str(t.get("name")).lower(): t for t in graph.get("tables") or []
              if isinstance(t, dict) and t.get("name")}

    def tokens(name):
        return [singular(w) for w in re.split(r"[^0-9A-Za-z]+", str(name or "")) if w]

    picked, readings = _Picked(), []
    if verdict == CHOICE:
        for label in choices or []:
            m = re.fullmatch(r"\s*(\w+)\.(\w+)\s*", str(label or ""))
            if m and m.group(1).lower() in tables:
                readings.append(_reading(label, "", tables[m.group(1).lower()]["name"],
                                         m.group(2)))
    text = str(said or "").translate(_QUOTES)
    words = {w.lower() for w in re.findall(r"\w+", text)}
    for t, c in _DOTTED.findall(text):
        if t.lower() in tables:
            picked.column(tables[t.lower()]["name"], c)
    for word in re.findall(r"\w+", _DOTTED.sub(" ", text)):
        if word.lower() in tables:
            picked.table(tables[word.lower()]["name"])
    named, _cols = picked.lists()
    for name in named:
        # the columns of a named table that the same words name
        for c in tables[name.lower()].get("columns") or []:
            if str(c.get("name") or "").lower() in words:
                picked.column(name, c["name"])
    source = "reason" if named else "choice" if readings else None
    if source is None:
        asked = {singular(w) for w in re.findall(r"[A-Za-z]+", str(question or ""))
                 if len(w) >= 3 and w.lower() not in _PLAIN}
        scored = []
        for t in tables.values():
            name = tokens(t["name"])
            hit = [w for w in name if w in asked]
            if not hit:
                continue
            cols = [c["name"] for c in t.get("columns") or [] if c.get("name")
                    and any(w in asked for w in tokens(c["name"]) if w not in _COMMON)]
            full = len(hit) == len(name)
            scored.append((not full, -(3 * len(hit) + len(cols)), t["name"], cols))
        scored.sort()
        full = [s for s in scored if not s[0]]
        keep = full[:GUESS_TABLES] if len(full) >= 2 else scored[:min(3, GUESS_TABLES)]
        for _part, _score, name, cols in keep:
            picked.table(name)
            for c in cols:
                picked.column(name, c)
        source = "question" if keep else None
    found, columns = picked.lists()
    readings = [r for r in readings if r["tables"]]
    if not found and not readings:
        return None
    return {"tables": found, "columns": columns, "readings": readings, "guessed": source}


def read_trace(path):
    """The lines of a run's trace file (coverage.trace_path), [] when it has
    none. A line that does not parse, the last one of a run killed while
    writing it, is left out."""
    lines = []
    try:
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                try:
                    found = json.loads(line)
                except ValueError:
                    continue
                if isinstance(found, dict):
                    lines.append(found)
    except OSError:
        return []
    return lines


def trace_of(lines, index, question):
    """The trace line of the question at `index`: the last one written for
    it, since a resumed run judges an UNKNOWN again and the retry is the
    verdict. Matched on its place and its text, and on its text alone when
    the place moved: a saved file is put back in the order of its questions
    only when its run ends, and a row's place is not always its index."""
    text = " ".join(str(question or "").split())
    same = [x for x in lines if " ".join(str(x.get("question") or "").split()) == text]
    placed = [x for x in same if x.get("index") == index]
    found = placed or same
    return found[-1] if found else None


# ------------------------------------------------- the Neo4j Browser link
def browser_base(environ=None):
    """The Neo4j Browser's address for the person at the page, from
    DATAGORA_NEO4J_BROWSER_URL (localhost:7474 when unset), or None when it
    is "off": a deployment whose graph nobody may browse shows no link."""
    environ = os.environ if environ is None else environ
    value = str(environ.get("DATAGORA_NEO4J_BROWSER_URL") or "").strip()
    if value.lower() == "off":
        return None
    return value or BROWSER


def _cypher_text(value):
    return "'" + str(value).replace("\\", "\\\\").replace("'", "\\'") + "'"


def neo4j_query(graph_key, tables):
    """The Cypher query that shows these tables and every table one join
    away: the Table nodes build_graph.py writes, by name and by the `db`
    they are filed under, and their JOINS_ON relationships. None without a
    table. A graph_key of "*" or None matches the tables by name alone, as
    Graph.from_profile reads a server that files its nodes under no name."""
    names = list(dict.fromkeys(str(t) for t in tables or () if t))
    if not names:
        return None
    listed = ", ".join(_cypher_text(t) for t in names)
    if graph_key and graph_key != "*":
        db = _cypher_text(graph_key)
        query = (f"MATCH (t:Table) WHERE t.db = {db} AND t.name IN [{listed}]\n"
                 f"OPTIONAL MATCH (t)-[r:JOINS_ON]-(n:Table {{db: {db}}})\n"
                 "RETURN t, r, n")
    else:
        query = (f"MATCH (t:Table) WHERE t.name IN [{listed}]\n"
                 "OPTIONAL MATCH (t)-[r:JOINS_ON]-(n:Table)\n"
                 "RETURN t, r, n")
    return query


def neo4j_url(base, graph_key, tables):
    """The Neo4j Browser for these tables, None without a base or a table.

    No server and no user in the address: the Browser of Neo4j 5.26 opens a
    connection named there as a transient one, never kept, and asked for a
    login on every click. The page opens every link in one named tab, where
    the person logs in once. The query rides along as cmd=edit&arg=, which
    the classic Browser puts in its editor; the 5.26 one ignores it, and
    the page copies the query (neo4j_query) when the link is clicked."""
    query = neo4j_query(graph_key, tables)
    if not base or not query:
        return None
    return (f"{base}{'&' if '?' in base else '?'}cmd=edit&arg="
            + urllib.parse.quote(query, safe=""))
