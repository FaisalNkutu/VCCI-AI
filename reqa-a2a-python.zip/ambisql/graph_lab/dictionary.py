"""A data dictionary, in either of the two shapes a deployment hands over.

The short shape, written by hand:

    {"tables":  {"loans": "one row per book lent"},
     "columns": {"loans.fee": "late fee in euros"}}

The knowledge-base shape, one entry per table, which is what a modelling
team exports: a label and a purpose, per-column descriptions and types, the
closed vocabulary of each ENUM column with a label per code, the primary
key, the relationships with their join, aliases, and sample questions with
their SQL. `data/sample/KB_full_sample_1_table.json` is one such entry.

Both become one structure:

    tables     {table: text}
    columns    {"table.column": text}
    enums      {(table, column): {code: label}}
    keys       {(table, column)}                      primary key columns
    primary    {table: (column, ...)}                 each table's whole key
    links      {(table, column): (ref_table, ref_column, relationship)}
    children   {table: {child_table: (child_column, column, join)}}
    aliases    {table: {word, ...}}
    examples   [{"question", "sql", "table"}]

Every key is lower case, since that is how the catalogue is compared.

Nothing here reads a database and nothing here is trusted to say no. A
dictionary is something a team wrote: it can be stale, and it can name a
table that no longer exists. So it only ever adds evidence, names a join
or labels a code, and every use of it checks the table against the
catalogue first.

What a knowledge base does not say is which table a code's rows continue
in. `abs_point.cat_code` holds CARTPT and GEOGPT, and `abs_point` is the
parent of `crts_point` and `geo_point`, one row at most each; nothing
written anywhere says that CARTPT rows are the ones in crts_point. That is
not guessed here. `children` lists the tables that continue another's rows,
which the relationships do state, and the clarifier asks the data which
code the rows of each child carry.
"""

import json
import logging
import pathlib
import threading

_LOG = logging.getLogger("datagora.dictionary")


def empty():
    return {"tables": {}, "columns": {}, "enums": {}, "keys": set(),
            "primary": {}, "links": {}, "children": {}, "aliases": {},
            "examples": [], "polymorphic": {}}


# One parse per file and per version of it, for the whole process. A
# production knowledge base runs to megabytes, and it used to be read by
# every clarifier, every parallel slot and the graph builder in turn. The
# key holds the file's size and modification time, so an edited file is
# read again on next use and an unchanged one never is. What is kept is
# only what the parse extracts, a fraction of the file: provenance,
# retrieval hints and validation notes are dropped on the way in.
_CACHE: dict = {}
_LOCK = threading.Lock()


def load(path):
    """The dictionary at `path`, or an empty one when it cannot be read.

    An unreadable dictionary must not take the database down with it: it
    is an aid, not a source of truth. The result is shared between every
    caller in the process and must be treated as read only."""
    if not path:
        return empty()
    where = pathlib.Path(path)
    if not where.is_absolute() and not where.exists():
        # a relative path is also looked for in the package and in the
        # repository, whoever passed it: a page, a .env, or a DbProfile
        # built in code. Left to the working folder alone, a knowledge base
        # named as examples/kb_points.json was silently not read.
        here = pathlib.Path(__file__).resolve().parent
        for base in (here, here.parent.parent):
            if (base / where).exists():
                where = base / where
                break
    try:
        where = where.resolve()
        stat = where.stat()
    except OSError:
        return empty()
    key = (str(where), stat.st_size, stat.st_mtime_ns)
    with _LOCK:
        if key in _CACHE:
            return _CACHE[key]
        try:
            data = json.loads(where.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return empty()
        parsed = parse(data)
        # the previous version of the same file is dropped, not kept
        for old in [k for k in _CACHE if k[0] == key[0]]:
            del _CACHE[old]
        _CACHE[key] = parsed
        return parsed


def parse(data):
    if not isinstance(data, dict):
        return empty()
    if isinstance(data.get("tables"), dict) or isinstance(
            data.get("columns"), dict):
        out = empty()
        out["tables"] = {str(k).lower(): str(v) for k, v
                         in (data.get("tables") or {}).items()}
        out["columns"] = {str(k).lower(): str(v) for k, v
                          in (data.get("columns") or {}).items()}
        return out
    entries = {str(k).lower(): v for k, v in data.items()
               if isinstance(v, dict) and isinstance(v.get("columns"), dict)}
    return _knowledge_base(entries)


# ------------------------------------------------------- knowledge base
def _text(entry):
    label = str(entry.get("label") or "").strip()
    about = str(entry.get("description")
                or (entry.get("semantic") or {}).get("purpose") or "").strip()
    return ". ".join(p for p in (label, about) if p)


def _knowledge_base(entries):
    out = empty()
    for table, entry in entries.items():
        said = _text(entry)
        if said:
            out["tables"][table] = said
        for column, spec in (entry.get("columns") or {}).items():
            column = str(column).lower()
            spec = spec if isinstance(spec, dict) else {}
            if spec.get("description"):
                out["columns"][f"{table}.{column}"] = str(spec["description"])
            allowed = spec.get("allowed_values")
            if isinstance(allowed, dict) and allowed:
                out["enums"][(table, column)] = {
                    str(code): str((v or {}).get("label") or code)
                    if isinstance(v, dict) else str(v or code)
                    for code, v in allowed.items()}
        primary = entry.get("primary_key")
        whole = tuple(str(c).lower() for c in (
            [primary] if isinstance(primary, str) else list(primary or [])))
        if whole:
            out["primary"][table] = whole
        for column in whole:
            out["keys"].add((table, column))
        for rel in entry.get("relationships") or []:
            _link(out, table, rel)
        words = set()
        for source in ((entry.get("semantic") or {}).get("aliases") or [],
                       entry.get("keywords") or []):
            words.update(str(w).strip().lower() for w in source if w)
        words.discard(table)
        if words:
            out["aliases"][table] = words
        for q in entry.get("sample_queries") or []:
            if isinstance(q, dict) and q.get("question") and q.get("sql"):
                out["examples"].append({"question": str(q["question"]),
                                        "sql": str(q["sql"]), "table": table})
    out["children"] = _children(out)
    return out


def _link(out, table, rel):
    """One relationship, stored on the column that holds the reference.

    `child_of` is read as written: this table's column points at the
    other. `parent_of` is the same edge seen from the other end, and is
    stored on the child's column, so a knowledge base that describes each
    edge once, from either side, still gives every join."""
    if not isinstance(rel, dict):
        return
    own = str(rel.get("own_column") or "").lower()
    other = str(rel.get("related_table") or "").lower()
    theirs = str(rel.get("related_column") or "").lower()
    if not (own and other and theirs) or "," in own or "," in theirs:
        return
    role = str(rel.get("role") or "").lower()
    about = {"name": str(rel.get("name") or ""), "role": role,
             "cardinality": str(rel.get("cardinality") or ""),
             "type": str(rel.get("type") or ""),
             "join": str(rel.get("join_on") or f"{table}.{own} = {other}.{theirs}")}
    when = rel.get("when")
    if about["type"].lower() == "polymorphic" or isinstance(when, dict):
        # one column, several targets, the type code saying which: not a
        # foreign key, so kept apart from `links`, every target with its
        # condition ({"column": "object_type", "value": "ORDER"})
        if not (isinstance(when, dict) and str(when.get("column") or "").strip()):
            # with no condition, each target would be joined to every row
            # of the column, the rows of the other targets included
            _LOG.warning("polymorphic relationship %s of %s.%s to %s.%s "
                         "skipped: it has no `when` saying which rows it "
                         "holds for", about["name"] or "-", table, own,
                         other, theirs)
            return
        about["when"] = dict(when)
        child, col, parent, pcol = ((other, theirs, table, own) if role == "parent_of"
                                    else (table, own, other, theirs))
        targets = out["polymorphic"].setdefault((child, col), [])
        if all((t, c) != (parent, pcol) for t, c, _a in targets):
            targets.append((parent, pcol, about))
        return
    if role == "parent_of":
        out["links"].setdefault((other, theirs), (table, own, about))
    else:
        out["links"].setdefault((table, own), (other, theirs, about))


def _children(out):
    """{parent: {child: (child_column, parent_column, join)}}.

    A child is a table that continues some of its parent's rows, one row
    at most per parent row, joined key on key. That is stated by the
    relationships and read from them: a `parent_of` whose cardinality is
    zero or one, or an identifying `child_of` whose two ends are each
    their table's whole primary key. A `child_of` that says "exactly one"
    is only how many parents a row has, and a book having exactly one genre
    does not make books a kind of genre. Nor is a junction a child: its key
    holds the reference and something else, book_authors keying on a book
    and an author, which is several rows per book, not one."""
    found = {}
    for (child, col), (parent, pcol, about) in out["links"].items():
        if child == parent:
            continue
        card = about.get("cardinality", "").lower()
        whole_key = (out["primary"].get(child) == (col,)
                     and out["primary"].get(parent) == (pcol,))
        if about.get("role") == "parent_of":
            one_row = "one" in card and "many" not in card
        else:
            one_row = (about.get("type", "").lower() == "identifying"
                       and whole_key)
        if one_row:
            found.setdefault(parent, {})[child] = (col, pcol, about["join"])
    return found
