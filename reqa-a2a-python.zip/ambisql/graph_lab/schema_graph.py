"""The reusable half of the join lab: the graph reader and the audits.

Extracted from test_no_llm.py so the same code serves a test, a bench
and production. Nothing here names a table: the graph is read from
Neo4j, the tables of a query are parsed out of its SQL, and the verdicts
come from cardinalities. That is what lets the identical audit run on
our sandbox and on a customer's schema.

A Graph is scoped to one database through `match`, the node properties
that select its namespace: {"db": "datagora_lib"} for a graph built by
build_graph.py, {"demo": True} for the hand-made demonstration graph.
Several databases therefore share one Neo4j instance without colliding.
"""


# ------------------------------------------------------------ SQL parsing

def _analyse(sql):
    """Everything the audits need, read once, scope by scope.

    Returns (tables, joins, aggregates, blocks). A block is a CTE or a
    derived table: a step the query defined for itself, which the graph
    has nothing to say about.

    Built on sqlglot's scope walker rather than on our own. The upstream
    AST primer says of `find_all(exp.Table)` that it is "NOT a good way
    to find all tables in the query", because it collects CTEs as if
    they were tables, and our hand-written `nearest_select` and CTE_RE
    existed to patch exactly that by hand. They patched it badly, and
    four cases proved it: a CTE declared with a column list was not
    recognised as a block, nor was `WITH RECURSIVE`; a string literal
    containing the words "WITH fake AS (" invented a block that did not
    exist; a derived table in a FROM was judged as a real table and
    rejected for having no edge; and an equality inside a subquery
    leaked into the WHERE of a comma join, producing a join pair nobody
    wrote. `Scope.sources` distinguishes a table from a nested query by
    construction, and `find_all_in_scope` stops at the scope boundary."""
    import sqlglot
    from sqlglot import exp
    from sqlglot.optimizer.scope import find_all_in_scope, traverse_scope

    try:
        tree = sqlglot.parse_one(sql, read="mysql")
    except Exception:
        return [], [], [], set()        # the dialect lint reports bad SQL

    tables, joins, aggs, blocks = set(), [], [], set()

    for scope in traverse_scope(tree):
        src = {}
        for name, source in scope.sources.items():
            if isinstance(source, exp.Table):
                src[name.lower()] = source.name.lower()
                tables.add(source.name.lower())
            else:                       # a CTE, a derived table, a union
                src[name.lower()] = None
                blocks.add(name.lower())

        def owner(column, src=src):
            key = (column.table or "").lower()
            return src.get(key) or key or None

        def pairs(condition, src=src):
            """Every `a.x = b.y` in a condition, however it is wrapped.
            ANDed equalities are a composite key, so all are returned."""
            out = []
            for eq in find_all_in_scope(condition, exp.EQ):
                left, right = eq.this, eq.expression
                if isinstance(left, exp.Column) and isinstance(right,
                                                               exp.Column):
                    out.append((owner(left), left.name.lower(),
                                owner(right), right.name.lower()))
            return out

        conditionless = False
        for join in scope.expression.args.get("joins") or []:
            if join.args.get("on") is not None:
                joins += pairs(join.args["on"])
            elif join.args.get("using"):
                for using in join.args["using"]:
                    name = (using.name or str(using)).lower()
                    right = (join.this.alias_or_name or "").lower()
                    right = src.get(right, right)
                    others = [v for v in src.values() if v and v != right]
                    if right and others:
                        joins.append((others[0], name, right, name))
            else:
                conditionless = True    # a comma join or a CROSS JOIN

        where = scope.expression.args.get("where")
        if conditionless and where is not None:
            joins += pairs(where.this)

        for agg in find_all_in_scope(scope.expression, exp.AggFunc):
            cols = list(agg.find_all(exp.Column))
            owners = {owner(c) for c in cols if owner(c)}
            label = cols[0].name.lower() if cols else "*"
            aggs.append((agg.sql_name().upper(), owners, label))

    seen, unique = set(), []
    for j in joins:
        if j not in seen and j[0] and j[2]:
            seen.add(j)
            unique.append(j)
    return sorted(tables), unique, aggs, blocks


def parse_sql(sql):
    """Tables, join pairs, and aggregates with the tables they read."""
    tables, joins, aggs, _blocks = _analyse(sql)
    return tables, joins, aggs


def cte_names(sql):
    """The blocks a query defines for itself, CTEs and derived tables.

    They matter to the audit because a block is not a table: the graph
    has no edge to `step1` and never will, so a join onto one must be
    left alone rather than rejected. Without this the auditor refuses
    exactly the shape the generator is asked to write, one CTE per hop,
    which is the worst kind of contradiction to ship."""
    return _analyse(sql)[3]


# ------------------------------------------------------------- the graph

def _get(record, key):
    """A field of a Neo4j record, or None when the query did not return it
    (a stand-in record in a test, an older server)."""
    try:
        return record[key]
    except (KeyError, IndexError, TypeError):
        return None


class Graph:
    """The join graph of one database, read once from Neo4j."""

    def __init__(self, driver, match=None):
        self.drv = driver
        self.match = match or {}
        where = " AND ".join(f"a.{k} = ${k}" for k in self.match) or "true"
        where2 = " AND ".join(f"b.{k} = ${k}" for k in self.match) or "true"
        query = (f"MATCH (a:Table)-[r:JOINS_ON]->(b:Table) "
                 f"WHERE {where} AND {where2} "
                 f"RETURN a.name AS f, r.left_col AS lc, b.name AS t, "
                 f"r.right_col AS rc, r.weight AS w, r.inferred AS inf, "
                 f"r.cardinality AS card, r.meaning AS meaning, "
                 f"r.condition AS cond")
        with driver.session() as s:
            records = list(s.run(query, **self.match))
        self.edges = [(x["f"], x["lc"], x["t"], x["rc"],
                       x["w"] if x["w"] is not None else 1,
                       bool(x["inf"]), x["card"], x["meaning"])
                      for x in records]
        # the type code a polymorphic edge holds under, keyed by the edge:
        # "attachments.object_type = 'ORDER'". Apart from `edges`, whose
        # eight fields every reader unpacks.
        self.conditions = {(x["f"], x["lc"], x["t"], x["rc"]): x["cond"]
                           for x in records if _get(x, "cond")}

    @classmethod
    def from_profile(cls, profile, driver=None):
        # the graph chosen for the database, or the one filed under the
        # database itself, never the name it is shown by: a database called
        # "Library" on the settings page is datagora_lib, and keyed on the
        # shown name, renaming it on the page lost every join. "*" reads the
        # whole graph, for a server that files its nodes under no name.
        key = profile.graph_key
        return cls(driver or profile.connect_neo4j(), {} if key == "*" else {"db": key})

    # a join column pair may be composite, stored comma separated
    @staticmethod
    def _cols(spec):
        return tuple(sorted(c.strip() for c in str(spec).split(",")))

    def edge_between(self, ta, ca, tb, cb):
        for f, lc, t, rc, w, inf, card, meaning in self.edges:
            pair = (f, self._cols(lc), t, self._cols(rc))
            want = (ta, self._cols(ca), tb, self._cols(cb))
            want_rev = (tb, self._cols(cb), ta, self._cols(ca))
            if pair in (want, want_rev):
                return {"weight": w, "inferred": inf, "cardinality": card,
                        "meaning": meaning}
        return None

    def tables_linked(self, ta, tb):
        return any((f == ta and t == tb) or (f == tb and t == ta)
                   for f, _, t, _, _, _, _, _ in self.edges)

    def force_union_subschema(self, anchors):
        """Union of the shortest paths between every pair of anchors."""
        tables = set(anchors)
        where = " AND ".join(f"x.{k} = ${k} AND y.{k} = ${k}"
                             for k in self.match) or "true"
        query = (f"MATCH (x:Table {{name: $a}}), (y:Table {{name: $b}}) "
                 f"WHERE {where} "
                 f"MATCH p = allShortestPaths((x)-[:JOINS_ON*]-(y)) "
                 f"RETURN [n IN nodes(p) | n.name] AS path, "
                 f"reduce(w=0, r IN relationships(p) | "
                 f"w + coalesce(r.weight, 1)) AS cost "
                 f"ORDER BY cost, path LIMIT 1")
        with self.drv.session() as s:
            for i, a in enumerate(anchors):
                for b in anchors[i + 1:]:
                    for rec in s.run(query, a=a, b=b, **self.match):
                        tables.update(rec["path"])
        return sorted(tables)

    def fine_side(self, table, within):
        """Tables of `within` strictly finer than `table`, that is, those
        reaching it through a fine-to-coarse edge."""
        return {f for f, _, t, _, _, _, _, _ in self.edges
                if t == table and f in within and f != table}


# -------------------------------------------------------------- audits

def audit_joins(sql, graph):
    """Every join pair must be an edge of the graph, on the right keys.

    Joins onto a block the query defined itself are skipped: a CTE is a
    step, not a table, and the graph has nothing to say about it. What
    the block joined internally was already judged when its own body was
    parsed, so nothing escapes the audit by hiding in a WITH."""
    _tables, joins, _aggs, blocks = _analyse(sql)

    # Column pairs are grouped by the couple of tables they join, because
    # a composite foreign key is written as several ANDed equalities and
    # stored in the graph as one edge over several columns. Judging each
    # pair on its own called the correct half of a composite key a wrong
    # key, and no rewrite could satisfy that: every form of the only
    # correct query was refused.
    grouped = {}
    for ta, ca, tb, cb in joins:
        key = (ta, tb) if ta <= tb else (tb, ta)
        left, right = (ca, cb) if ta <= tb else (cb, ca)
        grouped.setdefault(key, [[], []])
        grouped[key][0].append(left)
        grouped[key][1].append(right)

    verdicts = []
    for (ta, tb), (cols_a, cols_b) in grouped.items():
        ca, cb = ",".join(sorted(cols_a)), ",".join(sorted(cols_b))
        if ta in blocks or tb in blocks:
            verdicts.append(("OK", f"{ta}.{ca} = {tb}.{cb} (step of the "
                                   f"query, not a table)"))
            continue
        e = graph.edge_between(ta, ca, tb, cb)
        if e:
            verdicts.append(("OK", f"{ta}.{ca} = {tb}.{cb}"
                             + (" (inferred)" if e["inferred"] else "")))
        elif graph.tables_linked(ta, tb):
            verdicts.append(("REJECT wrong-keys",
                             f"{ta}.{ca} = {tb}.{cb}: tables are linked "
                             f"but not on these columns"))
        else:
            verdicts.append(("REJECT no-edge",
                             f"{ta}.{ca} = {tb}.{cb}: no JOINS_ON edge"))
    return verdicts


NUMERIC_TYPES = ("int", "decimal", "numeric", "float", "double", "real",
                 "bigint", "smallint", "tinyint", "mediumint", "bit")


def _numeric(ctype):
    """Whether a column type is a number, by its base name: a spatial
    POINT is none, though "int" is in its name (review of 26 October)."""
    import re
    base = re.split(r"[\s(]", str(ctype or "").strip().lower(), maxsplit=1)[0]
    return base in NUMERIC_TYPES or base in ("integer", "dec", "fixed")


def _is_number(text):
    try:
        float(str(text).strip())
        return True
    except (TypeError, ValueError):
        return False


def audit_literals(sql, columns):
    """A numeric column compared to a word, which MariaDB answers silently.

    `WHERE inventory.warehouse_id = 'WH-ROT-01'` does not fail and does
    not warn. warehouse_id is an integer, so MariaDB coerces the string
    to 0, matches nothing, and the pipeline reports that nothing in the
    data matches the question. That is the worst outcome this project has:
    a confident, wrong, unflagged answer, produced by a query every other
    gate accepts because its joins are sound and its plan is fine.

    It happens when a model applies a filter to the wrong column, here the
    warehouse's code onto the warehouse's id without joining warehouses at
    all. `columns` is {table: [(name, type)]}, the catalogue the clarifier
    already reads."""
    import sqlglot
    from sqlglot import exp

    types = {}
    for table, cols in (columns or {}).items():
        for name, ctype in cols:
            types.setdefault(name.lower(), set()).add(
                (table.lower(), str(ctype).lower()))

    try:
        tree = sqlglot.parse_one(sql, read="mysql")
    except Exception:
        return []                       # the dialect lint reports bad SQL

    # names the query gives itself: a CTE's columns, an alias, a derived
    # table. `CASE ... END AS level ... WHERE level = 'high'` was rejected
    # for a tinyint level elsewhere in the schema (review of 26 October)
    own = {a.alias.lower() for a in tree.find_all(exp.Alias) if a.alias}
    derived = {s.alias.lower() for s in tree.find_all(exp.Subquery) if s.alias}
    for cte in tree.find_all(exp.CTE):
        derived.add(cte.alias_or_name.lower())
        alias = cte.args.get("alias")
        own |= {c.name.lower() for c in getattr(alias, "columns", None) or []}
    # each name a table goes by, with every table it names (an alias reused
    # in a subquery names two): a real column is typed by those tables
    tables = {}
    for t in tree.find_all(exp.Table):
        if t.name:
            tables.setdefault((t.alias_or_name or "").lower(), set()).add(t.name.lower())
    in_query = set().union(*tables.values()) if tables else set()

    verdicts = []
    comparisons = (exp.EQ, exp.NEQ, exp.GT, exp.GTE, exp.LT, exp.LTE)
    for node in tree.find_all(*comparisons):
        left, right = node.this, node.expression
        for col, lit in ((left, right), (right, left)):
            if not isinstance(col, exp.Column) or not isinstance(
                    lit, exp.Literal):
                continue
            if not lit.is_string or _is_number(lit.this):
                continue
            name, qual = col.name.lower(), (col.table or "").lower()
            if qual in derived:
                continue
            known = types.get(name) or set()
            if qual in tables:
                # qualified by a real table: that table's type alone
                known = {(t, ctype) for t, ctype in known if t in tables[qual]}
            elif not qual:
                # unqualified: MariaDB's WHERE reads the tables' columns, not
                # the aliases. A name the query gives itself is skipped only
                # when no table of the query holds it (review of the fixes:
                # "s.label AS status ... WHERE status = 'shipped'" on a
                # tinyint orders.status passed)
                mine = {(t, ctype) for t, ctype in known if t in in_query}
                if not mine and name in own:
                    continue
                known = mine or known
            if not known:
                continue
            # every table holding a column of this name agrees it is
            # numeric: no alias resolution needed to be sure
            if all(_numeric(ctype) for _table, ctype in known):
                verdicts.append((
                    "REJECT literal-type",
                    f"{col.sql(dialect='mysql')} is a numeric column, "
                    f"compared to the text '{lit.this}'. MariaDB reads that "
                    f"text as 0 and silently matches nothing. The filter "
                    f"probably belongs on a different column, reached "
                    f"through a join that is missing."))
    return verdicts


def judge_sql(sql, *, columns=None, graph=None, con=None, stop_early=False):
    """Every gate, in one place, in the one order they belong in.

    There used to be three copies of this sequence: Pipeline.check for
    the retry loop, api.check_sql for a caller with its own pipeline, and
    Datagora.check_sql behind the facade. They drifted, as copies do. The
    facade's copy was two gates short, so the same object answered "this
    query is fine" through one method and rejected it three times through
    another. One implementation, three callers.

    Returns [(verdict, explanation)], empty when there is nothing to say.
    A gate whose input is missing is skipped rather than guessed at, and
    `ran` reports which ones actually executed, because "no problem
    found" and "not checked" are different claims.

    The order is deliberate. Dialect first, since a statement that means
    two things cannot be reasoned about further. Literals second, because
    a filter on the wrong column produces sound joins and a clean plan,
    so no later gate would ever see it. Then the joins, then the traps
    they enable, then EXPLAIN, which is the only one that talks to the
    server."""
    if __package__:
        from .dialect_lint import lint
    else:
        from dialect_lint import lint

    out, ran = [], []

    def rejected():
        # only a rejection stops the gates early: a dialect WARN in `out`
        # returned at the next gate, skipping the literals, the joins and
        # EXPLAIN (review of 26 October)
        return stop_early and any(v.startswith("REJECT") for v, _ in out)

    ran.append("dialect")
    out += [(v, why) for v, why in lint(sql)[0] if v != "OK"]
    if rejected():
        return out, ran

    if columns:
        ran.append("literals")
        out += audit_literals(sql, columns)
        if rejected():
            return out, ran

    if graph is not None and getattr(graph, "edges", None):
        ran.append("joins")
        out += [(v, why) for v, why in audit_joins(sql, graph) if v != "OK"]
        if rejected():
            return out, ran
        ran.append("traps")
        verdict, why = audit_traps(sql, graph)
        if verdict != "OK":
            out.append((verdict, why))
            if rejected():
                return out, ran

    if con is not None:
        ran.append("EXPLAIN")
        try:
            verdict, why = explain_check(sql, con)
            if verdict != "OK":
                out.append((verdict, why))
        except Exception as e:
            out.append(("REJECT unplannable",
                        f"MariaDB refused to plan it: {str(e)[:160]}"))
    return out, ran


def audit_traps(sql, graph):
    """Fan and chasm, from cardinalities alone, before any execution.

    Blocks are excluded from the granularity reasoning for the same
    reason: their grain is whatever their own GROUP BY made it, which
    the table graph cannot know. A query that pre-aggregates inside a
    block is the fix for these traps, so counting the block as a table
    would flag the cure as the disease."""
    tables, _joins, aggs, blocks = _analyse(sql)
    tables = [t for t in tables if t not in blocks]
    additive = [(f, o, c) for f, o, c in aggs if f in ("SUM", "AVG", "COUNT")]
    if not additive or len(tables) < 2:
        return ("OK", "no additive aggregate over a join")
    finest = [t for t in tables if not graph.fine_side(t, tables)]
    if len(finest) > 1:
        return ("REJECT chasm/fan",
                f"two fine branches {finest} converge; pre-aggregate each "
                f"on the shared key before joining")
    leaf = finest[0] if finest else None
    for func, owners, col in additive:
        # an aggregate reads a set of tables, not one. SUM(price * qty)
        # is evaluated at the grain of the stock line, so it is safe as
        # soon as the finest table is among them; reading only the first
        # column made it look like SUM(price) and rejected a correct
        # query. Nothing is claimed about an aggregate over no column,
        # such as COUNT(*), which cannot be inflated by a repeated value.
        others = {o for o in owners if o not in blocks}
        if others and leaf and leaf not in others and col != "*":
            named = min(others)
            return ("REJECT fan",
                    f"{func}({named}.{col}) sits above the finest table "
                    f"{leaf}; its rows are repeated by the join")
    return ("OK", "aggregates at the finest granularity")


# a table reached by one of these is looked up, and the plan names the
# column it is reached by. Anything else, with no ref, is read in full
# for every row already joined.
SCAN_TYPES = {"ALL", "index", "range"}


def _conjuncts(condition):
    """The parts of a condition joined by AND, brackets taken off."""
    from sqlglot import exp
    while isinstance(condition, exp.Paren):
        condition = condition.this
    if isinstance(condition, exp.And):
        return _conjuncts(condition.this) + _conjuncts(condition.expression)
    return [condition]


def join_links(sql):
    """(links, blocks, loose) of a query, or None when it does not parse.

    `links` holds a frozenset of two names, lower case, for every two
    sources of one scope that one part of an ON or a WHERE (split on AND)
    names together: a.x = b.y, but also a.d BETWEEN b.start AND b.stop or
    a.x < b.y, which a plan reads with no ref. Each source is named by its
    alias and by its table, as EXPLAIN may print either. USING links its
    table to every other source of the scope. `blocks` are the CTEs and
    derived tables, which EXPLAIN prints as <derived2>. `loose` is True
    when a part names two columns or more and one of them has no table
    before it: what it links cannot be told without the catalogue."""
    import sqlglot
    from sqlglot import exp
    from sqlglot.optimizer.scope import find_all_in_scope, traverse_scope

    try:
        tree = sqlglot.parse_one(sql, read="mysql")
        scopes = list(traverse_scope(tree))
    except Exception:
        return None
    links, blocks, loose = set(), set(), False

    def names(alias, src):
        found = {alias}
        if src.get(alias):
            found.add(src[alias])
        return found

    def link(first, second, src):
        for x in names(first, src):
            for y in names(second, src):
                if x != y:
                    links.add(frozenset((x, y)))

    for scope in scopes:
        src = {}
        for name, source in scope.sources.items():
            if isinstance(source, exp.Table):
                src[name.lower()] = source.name.lower()
            else:
                src[name.lower()] = None
                blocks.add(name.lower())
        conditions = []
        for join in scope.expression.args.get("joins") or []:
            if join.args.get("on") is not None:
                conditions.append(join.args["on"])
            elif join.args.get("using"):
                right = (join.this.alias_or_name or "").lower()
                for other in src:
                    if other != right:
                        link(right, other, src)
        where = scope.expression.args.get("where")
        if where is not None:
            conditions.append(where.this)
        for condition in conditions:
            for part in _conjuncts(condition):
                columns = list(find_all_in_scope(part, exp.Column))
                if len(columns) < 2:
                    continue
                if any(not c.table for c in columns):
                    loose = True
                owners = sorted({c.table.lower() for c in columns if c.table})
                for i, first in enumerate(owners):
                    for second in owners[i + 1:]:
                        link(first, second, src)
    return links, blocks, loose


def explain_check(sql, con):
    """A cartesian product is visible in EXPLAIN before running.

    Grouped by the plan's `id`, because that is what a cartesian product
    actually is: two tables multiplied inside one join unit. Rows with
    different ids are separate blocks, a CTE materialised as <derived2>
    or a subquery, run once each and never multiplied together. Counting
    all the rows instead rejected a correct single-table query the moment
    it used WITH, which is the shape we ask the generator for: the
    generator wrote it, we refused it twice, and the third attempt was
    worse than the first.

    A later table read with no ref is not proof on its own: a join on
    columns no index covers is read through the join buffer, and a join
    on a range (a.d BETWEEN b.start AND b.stop) is "Range checked for
    each record", both with no ref. It is refused only when no part of
    the query's conditions names it with a table read before it
    (join_links); when that cannot be told, a plan that applies a
    condition at the join ("Using where" with the join buffer) is let
    through."""
    with con.cursor() as cur:
        cur.execute("EXPLAIN " + sql)
        rows = cur.fetchall()
        cols = [d[0] for d in cur.description]
    plan = [{str(k).lower(): v for k, v in zip(cols, r)} for r in rows]
    found = join_links(sql)
    links, blocks, loose = found if found is not None else (set(), set(), True)
    units = {}
    for r in plan:
        units.setdefault(r["id"], []).append(r)
    for unit in units.values():
        # the first table drives the join and is always ref-less. Every
        # table after it should be reached through a reference to one
        # already joined: `ref` names that column and `type` is a lookup.
        # A scan with no ref is the table being paired with every row so
        # far, which is the multiplication we refuse to run. `key` is not
        # the signal: a COUNT(*) cross join reads a covering index, so it
        # has a key and no join condition at all.
        before = set()
        for n, r in enumerate(unit):
            table = str(r.get("table") or "")
            name = table.lower()
            earlier = set(before)
            if any(t.startswith("<") for t in earlier):
                earlier |= blocks
            before.add(name)
            if n == 0 or table.startswith("<"):   # <derived2>, <union1>:
                continue                   # materialised, not unjoined
            if not (r.get("ref") is None and r.get("type") in SCAN_TYPES):
                continue
            extra = str(r.get("extra") or "").lower()
            if "range checked for each record" in extra:
                continue                   # a range read off a row before
            if any(frozenset((name, e)) in links for e in earlier):
                continue                   # joined, on columns with no index
            if loose and "using where" in extra and "join buffer" in extra:
                continue
            return ("REJECT cartesian",
                    f"{table} is joined to nothing: the plan pairs it "
                    f"with every row already read")
    return ("OK", f"{len(plan)} rows in the plan, {len(units)} block(s)")
