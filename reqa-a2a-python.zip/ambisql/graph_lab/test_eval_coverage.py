"""The DeepEval harness of the coverage bench, offline (plan 8.6).

The deterministic metrics on hand-made cases, the statistics, the loading
and validation of the four evaluation sets, the leak check, the scoring of
a recorded run with its trace, and the judge wrapper on a scripted model.
No database, no model, and no DeepEval needed: the tests that need
DeepEval itself are skipped when it is not importable, and pass in
.venv-eval where it is.

    .venv/Scripts/python src/graph_lab/test_eval_coverage.py
"""

import csv
import io
import json
import os
import shutil
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from types import SimpleNamespace

os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

HERE = Path(__file__).resolve().parent
BENCH = HERE.parents[1] / "docs" / "test_strategy" / "coverage_bench"
FIXTURES = BENCH / "fixtures"
import sys  # noqa: E402

if str(BENCH) not in sys.path:
    sys.path.append(str(BENCH))

import build_datasets  # noqa: E402
import compare_runs  # noqa: E402
import eval_ask  # noqa: E402
import eval_coverage  # noqa: E402
import goldens  # noqa: E402
import judge_llm  # noqa: E402
import leak  # noqa: E402
import live  # noqa: E402
import metrics  # noqa: E402
import report  # noqa: E402
import stats  # noqa: E402


def fixture_lines(name):
    with open(FIXTURES / name, encoding="utf-8") as fh:
        return [json.loads(line) for line in fh if line.strip()]


def last_line(name, qid):
    return [line for line in fixture_lines(name) if line.get("id") == qid][-1]


class StatisticsTests(unittest.TestCase):
    def test_one_home_for_the_statistics(self):
        self.assertIs(compare_runs.wilson, stats.wilson)
        self.assertIs(compare_runs.mcnemar_exact, stats.mcnemar_exact)
        self.assertIs(compare_runs.SAMPLE_NOTE, stats.SAMPLE_NOTE)

    def test_percentile_and_mean(self):
        self.assertIsNone(stats.percentile([], 50))
        self.assertEqual(stats.percentile([7], 95), 7.0)
        self.assertEqual(stats.percentile([1, 2, 3, 4], 50), 2.5)
        self.assertAlmostEqual(stats.percentile(range(1, 11), 95), 9.55)
        self.assertEqual(stats.percentile([3, 1, None, 2], 0), 1.0)
        self.assertIsNone(stats.mean([None]))
        self.assertEqual(stats.mean([1, None, 2]), 1.5)


class VerdictAndChoicesTests(unittest.TestCase):
    def test_verdict_match(self):
        self.assertEqual(metrics.verdict_match("ANSWERABLE", [], "answerable"), 1.0)
        self.assertEqual(metrics.verdict_match("ANSWERABLE", ["NEEDS A CHOICE"],
                                               "NEEDS A CHOICE"), 1.0)
        self.assertEqual(metrics.verdict_match("NEEDS MORE", "", "NEEDS A CHOICE"), 0.0)
        self.assertEqual(metrics.verdict_match("NOT COVERED", [], ""), 0.0)
        # no key: left out of the score, never counted wrong
        self.assertIsNone(metrics.verdict_match("", [], "ANSWERABLE"))

    def test_choices_cover_the_readings(self):
        readings = [{"reading": "net", "columns": ["invoices.net_amount"]},
                    {"reading": "gross", "columns": ["invoices.gross_amount"]},
                    {"reading": "orders", "columns": ["sales_orders.net_amount"]}]
        score, detail = metrics.choices_match(
            readings, ["invoices.net_amount", "purchase_order_lines.quantity", "`gross_amount`"])
        self.assertAlmostEqual(score, 2 / 3)
        self.assertEqual(detail["covered"], ["net", "gross"])
        self.assertEqual(detail["uncovered"], ["orders"])
        # the invented choice of E16
        self.assertEqual(detail["extra"], ["purchase_order_lines.quantity"])

    def test_choices_without_readings_or_options(self):
        self.assertIsNone(metrics.choices_match([], ["a.b"])[0])
        self.assertIsNone(metrics.choices_match([{"reading": "x", "columns": []}], ["a.b"])[0])
        self.assertEqual(metrics.choices_match([{"columns": ["a.b"]}], [])[0], 0.0)

    def test_tools_match(self):
        self.assertIsNone(metrics.tools_match([], ["x"]))
        self.assertEqual(metrics.tools_match(["join_path", "describe_tables"],
                                             ["describe_tables", "search_tables"]), 0.5)


class ContextTests(unittest.TestCase):
    def test_recall(self):
        self.assertEqual(metrics.context_recall(["a", "B"], ["b", "c"]), 0.5)
        self.assertIsNone(metrics.context_recall([], ["a"]))
        self.assertEqual(metrics.context_recall(["a"], []), 0.0)

    def test_precision_weighted_by_order(self):
        self.assertEqual(metrics.context_precision(["a", "b", "c"], {"a", "b"}), 1.0)
        # the needed tables read last: (1/2 + 2/3) / 2
        self.assertAlmostEqual(metrics.context_precision(["c", "a", "b"], {"a", "b"}),
                               (1 / 2 + 2 / 3) / 2)
        self.assertEqual(metrics.context_precision(["x", "y"], {"a"}), 0.0)
        self.assertIsNone(metrics.context_precision([], {"a"}))
        self.assertIsNone(metrics.context_precision(["a"], set()))
        # a table read twice counts once, at its first rank
        self.assertEqual(metrics.context_precision(["a", "a", "x"], {"a"}), 1.0)

    def test_plain_precision_for_a_whole_schema(self):
        self.assertEqual(metrics.plain_precision(["a", "b", "c", "d"], {"a"}), 0.25)

    def test_agent_tables_in_the_order_reached(self):
        line = last_line("trace_agent.jsonl", "E27")
        reach = metrics.tables_from_trace(line, ["goods_receipts", "goods_receipt_lines",
                                                 "purchase_order_lines", "suppliers"])
        self.assertEqual(reach["ordered"][:4], ["suppliers", "nonconformances", "work_orders",
                                                "material_shortages"])
        self.assertEqual(reach["how"]["goods_receipts"], ["counted"])
        self.assertIn("described", reach["how"]["purchase_order_lines"])
        self.assertFalse(reach["whole_schema"])

    def test_single_tables_shown_or_the_whole_schema(self):
        line = last_line("trace_single.jsonl", "E01")
        self.assertEqual(metrics.tables_from_trace(line)["ordered"],
                         ["customers", "customer_segments", "customer_credit_limits",
                          "sales_territories"])
        whole = metrics.tables_from_trace({"reply": {"ambiguous": False}, "tables_shown": None},
                                          ["b", "a"])
        self.assertEqual((whole["ordered"], whole["whole_schema"]), (["a", "b"], True))

    def test_a_failed_join_path_reaches_nothing(self):
        line = {"mode": "agent", "turns": [
            {"tool": "join_path", "args": {"a": "x", "b": "y"},
             "digest": "no path between x and y within 5 hops"}]}
        self.assertEqual(metrics.tables_from_trace(line, ["x", "y"])["ordered"], [])


class FaithfulnessTests(unittest.TestCase):
    TABLES = ["support_tickets", "invoices"]
    COLUMNS = ["status_code", "closed_at", "net_amount"]

    def test_claims_leave_out_what_the_question_says(self):
        found = metrics.claims("In 2025, 12 tickets in support_tickets were 'open' and "
                               "RESOLVED; see support_tickets.closed_at.",
                               self.TABLES, self.COLUMNS, "How many tickets were open in 2025?")
        self.assertEqual(found, [("number", "12"), ("column", "support_tickets.closed_at"),
                                 ("table", "support_tickets"), ("value", "RESOLVED")])

    def test_supported_and_unsupported(self):
        facts = ["support_tickets(closed_at, status_code, ticket_id)",
                 "sample_values: NEW, OPEN, RESOLVED; 1,234.46 on average"]
        score, detail = metrics.faithfulness(
            "1,234.5 tickets on average are RESOLVED, and 77 are CLOSED in support_tickets.",
            facts, self.TABLES, self.COLUMNS, "How many tickets?")
        self.assertEqual(detail["claims"], 5)
        self.assertEqual(sorted(detail["unsupported"]), ["number:77", "value:CLOSED"])
        self.assertAlmostEqual(score, 3 / 5)

    def test_rows_are_facts(self):
        score, _ = metrics.faithfulness("Lyon holds 8 warehouses.", [], [], [],
                                        "Where are the warehouses?",
                                        rows=[["Lyon", 8], {"city": "Hamburg", "n": 3}])
        self.assertEqual(score, 1.0)

    def test_nothing_to_check(self):
        self.assertEqual(metrics.faithfulness("Yes, this can be answered as asked.",
                                              ["x"], self.TABLES), (None, {"claims": 0,
                                                                          "unsupported": []}))


class MetricClassesTests(unittest.TestCase):
    def test_score_case_without_a_model(self):
        case = metrics.make_case(
            input="Which suppliers are based in Germany?",
            actual_output="ANSWERABLE. Yes, this can be answered as asked.",
            expected_output="ANSWERABLE",
            retrieval_context=["suppliers(country_code, name)"],
            tools_called=[("describe_tables", {"names": ["suppliers"]})],
            expected_tools=["describe_tables"],
            metadata={"verdict": "ANSWERABLE", "also_accepted": [], "readings": [],
                      "needed_tables": ["suppliers"], "acceptable_tables": ["countries"],
                      "reached": ["suppliers", "countries"], "known_tables": ["suppliers"]})
        scores = metrics.score_case(case)
        self.assertEqual(scores["VerdictMatch"]["score"], 1.0)
        self.assertIsNone(scores["ChoicesMatch"]["score"])
        self.assertEqual(scores["ContextRecall"]["score"], 1.0)
        self.assertEqual(scores["ContextPrecision"]["score"], 1.0)
        self.assertEqual(scores["ToolsMatch"]["score"], 1.0)
        self.assertEqual(set(scores), {m.name for m in metrics.DETERMINISTIC})

    def test_no_trace_is_not_applicable(self):
        metric = metrics.ContextRecall()
        metric.measure(SimpleNamespace(metadata={"needed_tables": ["a"], "reached": None}))
        self.assertIsNone(metric.score)
        self.assertTrue(metric.is_successful())
        self.assertEqual(metric.reason, "not applicable (no trace)")

    def test_a_judged_metric_that_fails_does_not_stop_the_run(self):
        class Broken:
            def measure(self, case, **kwargs):
                raise RuntimeError("the judge did not answer")
        scores = metrics.score_case(metrics.make_case(input="q", actual_output="a",
                                                      expected_output=None), [Broken()])
        self.assertIsNone(scores["Broken"]["score"])
        self.assertIn("did not answer", scores["Broken"]["error"])


class Scripted:
    """A model that answers each DeepEval schema with a fixed reply."""

    name, model, last_error = "scripted", "fake", ""

    def __init__(self):
        self.think_calls = []

    def thinking(self, on):
        self.think_calls.append(on)
        return self

    def chat(self, system, user, **kw):
        return "plain reply"

    def json(self, system, user, schema=None, **kw):
        props = (schema or {}).get("properties", {})
        for key, value in (("truths", ["12 tickets are OPEN"]), ("claims", ["12 are open"]),
                           ("statements", ["12 tickets are open"]),
                           ("verdicts", [{"verdict": "yes"}]), ("reason", "fine"),
                           ("label", "yes")):
            if key in props:
                return {key: value}
        return None


class JudgeTests(unittest.TestCase):
    def test_core_turns_thinking_off_and_validates_the_schema(self):
        from pydantic import BaseModel

        class Label(BaseModel):
            label: str

        model = Scripted()
        core = judge_llm.JudgeCore(model)
        self.assertEqual(model.think_calls, [False])
        self.assertEqual(core.generate("say"), "plain reply")
        self.assertEqual(core.generate("say", Label), Label(label="yes"))
        self.assertEqual(core.name(), "scripted (fake)")

    def test_a_silent_model_raises_with_its_reason(self):
        from pydantic import BaseModel

        class Other(BaseModel):
            nothing: int

        model = Scripted()
        model.last_error = "timed out"
        model.chat = lambda system, user, **kw: None
        core = judge_llm.JudgeCore(model)
        with self.assertRaisesRegex(RuntimeError, "timed out"):
            core.generate("say")
        # a TypeError, which DeepEval reads as "ask again without a schema"
        with self.assertRaises(TypeError):
            core.generate("say", Other)

    def test_endpoint_from_env_needs_the_variable(self):
        with self.assertRaises(SystemExit):
            judge_llm.endpoint_from_env({})

    def test_endpoint_from_env_takes_a_url(self):
        model = judge_llm.endpoint_from_env({judge_llm.ENV: "http://judge.invalid:11436",
                                             judge_llm.ENV_MODEL: "some-model"})
        self.assertEqual((model.url, model.model, model.think),
                         ("http://judge.invalid:11436", "some-model", False))

    @unittest.skipUnless(judge_llm.HAVE_DEEPEVAL, "deepeval is not installed (.venv-eval has it)")
    def test_deepeval_wrapper_and_judged_metrics(self):
        judge = judge_llm.DatagoraJudge(Scripted())
        self.assertEqual(judge.get_model_name(), "scripted (fake)")
        case = metrics.make_case(input="How many tickets are open?",
                                 actual_output="12 tickets are open.",
                                 expected_output="ANSWERABLE",
                                 retrieval_context=["12 tickets are OPEN"],
                                 metadata={"verdict": "ANSWERABLE"})
        scores = metrics.score_case(case, metrics.judged_metrics(judge))
        self.assertEqual(scores["FaithfulnessMetric"], {"score": 1.0, "detail": None,
                                                         "error": None})
        self.assertEqual(scores["AnswerRelevancyMetric"]["score"], 1.0)

    @unittest.skipUnless(judge_llm.HAVE_DEEPEVAL, "deepeval is not installed (.venv-eval has it)")
    def test_deterministic_metrics_are_deepeval_metrics(self):
        from deepeval.metrics import BaseMetric
        from deepeval.test_case import LLMTestCase
        for cls in metrics.DETERMINISTIC:
            self.assertTrue(issubclass(cls, BaseMetric), cls)
        case = metrics.make_case(input="q", actual_output="a", expected_output="ANSWERABLE",
                                 metadata={"verdict": "ANSWERABLE"})
        self.assertIsInstance(case, LLMTestCase)
        self.assertEqual(metrics.score_case(case)["VerdictMatch"]["score"], 1.0)


class DatasetTests(unittest.TestCase):
    def test_the_four_sets_load_and_validate(self):
        expected = {"Library": (23, 18), "Warehouse": (25, 20), "Enterprise": (40, 40),
                    "Point": (10, 10)}
        for profile in goldens.PROFILES:
            with self.subTest(profile=profile):
                rows = goldens.read_dataset(profile)
                kb = goldens.load_kb(profile)
                self.assertEqual(goldens.validate(rows, kb), [])
                self.assertGreaterEqual(len(rows), expected[profile][0])
                keyed = [r for r in rows if r["expected"]]
                self.assertGreaterEqual(len(keyed), expected[profile][1])
                tables = set(goldens.kb_columns(kb))
                for row in rows:
                    self.assertTrue(set(goldens.REQUIRED) <= set(row), row["id"])
                    self.assertIn(row["expected"], goldens.VERDICTS + ("",))
                    self.assertTrue(set(row["needed_tables"]) <= tables, row["id"])
                    self.assertIn(row["split"], goldens.SPLITS)

    def test_the_key_as_the_repository_keeps_it(self):
        ent = {r["id"]: r for r in goldens.read_dataset("Enterprise")}
        self.assertEqual(ent["E06"]["also_accepted"], ["NEEDS A CHOICE"])
        self.assertEqual(ent["E37"]["also_accepted"], ["ANSWERABLE"])
        self.assertEqual(ent["E36"]["readings"][0]["columns"], ["invoices.net_amount"])
        self.assertEqual(ent["E08"]["acceptable_tables"], ["countries"])
        self.assertTrue(ent["E34"]["missing"].startswith("The 2027 budget"))
        wh = {r["id"]: r for r in goldens.read_dataset("Warehouse")}
        self.assertEqual(wh["Q09"]["expected"], "NEEDS A CHOICE")
        # the README leaves Q21 without a verdict: the step 24 audit gives it
        self.assertEqual(wh["Q21"]["expected"], "ANSWERABLE")
        self.assertIn("step 24 audit", wh["Q21"]["note"])
        self.assertTrue(wh["Q21"]["sql"])
        # settled by the audit of step 22, against the README
        self.assertEqual((wh["Q14"]["expected"], wh["Q14"]["also_accepted"]), ("NEEDS MORE", []))
        # a paraphrase takes the key of its question
        self.assertEqual((wh["wh-Q01.1"]["expected"], wh["wh-Q01.1"]["note"]),
                         ("ANSWERABLE", "paraphrase of Q01"))
        pt = {r["id"]: r for r in goldens.read_dataset("Point")}
        self.assertEqual((pt["P09"]["expected"], pt["P09"]["also_accepted"]),
                         ("NO DATA", ["ANSWERABLE"]))
        self.assertEqual(pt["P01"]["needed_tables"], ["abs_point"])

    def test_validate_reports_what_is_wrong(self):
        kb = {"books": {"columns": {"title": {}}}}
        row = {f: "" for f in goldens.REQUIRED}
        row.update(id="X1", question="q", expected="MAYBE", also_accepted=["NOPE"],
                   needed_tables=["loans"], readings=[{"columns": ["books.isbn"]}],
                   split="corpus")
        problems = goldens.validate([row, dict(row)], kb)
        text = "\n".join(problems)
        for part in ("'MAYBE' is not a verdict", "'NOPE' is not a verdict", "'loans'",
                     "'books.isbn'", "id used twice"):
            self.assertIn(part, text)

    def test_readme_key_with_ranges(self):
        text = ("### questions_library.csv, 3 questions\n\n| | Q | Intended | x |\n|---|---|---|---|\n"
                "| Q01-Q03, Q05 | aggregates | ANSWERABLE | ok |\n| Q04 | longest | NEEDS MORE | ok |\n"
                "### other\n| Q09 | x | NOT COVERED | y |\n")
        self.assertEqual(build_datasets.readme_key(text, "questions_library.csv"),
                         {"Q01": "ANSWERABLE", "Q02": "ANSWERABLE", "Q03": "ANSWERABLE",
                          "Q05": "ANSWERABLE", "Q04": "NEEDS MORE"})

    def test_reading_columns(self):
        kb = {"sales_orders": {"columns": {c: {} for c in (
                  "order_id", "delivery_date", "promised_date", "ship_date", "requested_date")}},
              "journal_lines": {"columns": {c: {} for c in (
                  "entry_id", "credit_amount", "debit_amount")}},
              "journal_entries": {"columns": {c: {} for c in ("entry_id", "entry_date")}}}
        readings = [
            {"reading": "Delivered late (sales_orders.delivery_date > promised_date).",
             "sql": "SELECT order_id FROM sales_orders WHERE delivery_date > promised_date"},
            {"reading": "Ledger revenue.",
             "sql": "SELECT SUM(jl.credit_amount - jl.debit_amount) FROM journal_lines jl "
                    "JOIN journal_entries je ON je.entry_id = jl.entry_id "
                    "WHERE YEAR(je.entry_date) = 2025"}]
        self.assertEqual(goldens.reading_columns(readings, kb), [
            ["sales_orders.delivery_date", "sales_orders.promised_date"],
            ["journal_entries.entry_date", "journal_lines.credit_amount",
             "journal_lines.debit_amount"]])

    def test_acceptable_tables(self):
        kb = {"a": {"columns": {"id": {}}, "relationships": [{"related_table": "bridge"}]},
              "bridge": {"columns": {"id": {}}, "relationships": [{"related_table": "b"}]},
              "b": {"columns": {"id": {}}}, "hub": {"columns": {"id": {}}}}
        # no SQL: the table that joins two needed tables which do not join alone
        self.assertEqual(goldens.acceptable_tables(["a", "b"], [], kb), ["bridge"])
        # a SQL: what it reads beyond the needed tables, and what the key allows
        self.assertEqual(goldens.acceptable_tables(
            ["a"], ["SELECT * FROM a JOIN hub ON 1=1"], kb, ["b"]), ["b", "hub"])


class PairsAndLeakTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="eval-pairs-"))
        self.addCleanup(shutil.rmtree, self.tmp, True)
        pairs = [
            {"id": "L-1", "profile": "Library", "question": "How many loans are there?",
             "sql": "SELECT COUNT(*) FROM loans", "verdict": "ANSWERABLE", "group": "g1",
             "tags": {"language": "en"}, "source": "hand"},
            {"id": "L-2", "profile": "Library", "question": "Count the loans.",
             "sql": "SELECT COUNT(*) FROM loans", "verdict": "ANSWERABLE", "group": "g1"},
            {"id": "L-3", "profile": "Library", "question": "Which members borrowed books?",
             "sql": "SELECT m.full_name FROM members m JOIN loans l ON l.member_id = m.member_id",
             "group": "g2", "row_count": 4},
        ]
        with open(self.tmp / "library.jsonl", "w", encoding="utf-8") as fh:
            fh.writelines(json.dumps(p) + "\n" for p in pairs)
        (self.tmp / "split.json").write_text(json.dumps(
            {"Library": {"corpus": ["g1"], "eval_locked": ["g2"]}}), encoding="utf-8")

    def test_split_shapes(self):
        pair = {"id": "x1", "group": "g"}
        self.assertEqual(goldens.split_of(pair, {"eval_tune": ["g"]}), "eval_tune")
        self.assertEqual(goldens.split_of(pair, {"ids": {"x1": "locked"}}), "eval_locked")
        self.assertEqual(goldens.split_of(pair, {"groups": {"g": "corpus"}}), "corpus")
        self.assertEqual(goldens.split_of({"id": "y", "split": "eval_tune"}, {}), "eval_tune")
        # not placed: the corpus side, never scored
        self.assertEqual(goldens.split_of({"id": "z"}, {}), "corpus")

    def test_only_the_eval_side_enters_the_set(self):
        kb = goldens.load_kb("Library")
        specs = build_datasets.merge_pairs("Library", [], kb, self.tmp)
        rows = [build_datasets.row("Library", kb, **s) for s in specs]
        self.assertEqual([r["id"] for r in rows], ["L-3"])
        self.assertEqual(rows[0]["split"], "eval_locked")
        self.assertEqual(rows[0]["needed_tables"], ["loans", "members"])
        self.assertEqual(rows[0]["expected"], "ANSWERABLE")
        self.assertEqual(goldens.validate(rows, kb), [])

    def test_a_pair_completes_its_key_question(self):
        kb = goldens.load_kb("Library")
        key = [{"id": "Q9", "question": "Which members borrowed books?", "source": "csv",
                "expected": "", "note": "no verdict in the README"}]
        specs = build_datasets.merge_pairs("Library", key, kb, self.tmp)
        self.assertEqual(len(specs), 1)
        done = build_datasets.row("Library", kb, **specs[0])
        self.assertEqual((done["expected"], done["split"], done["row_count"], done["group"]),
                         ("ANSWERABLE", "eval_locked", 4, "g2"))
        self.assertTrue(done["sql"].startswith("SELECT m.full_name"))
        self.assertIn("step 24 audit (L-3)", done["note"])

    def test_leak_by_text_similarity_and_by_group(self):
        corpus = leak.corpus("Library", {}, self.tmp)
        self.assertEqual([c["question"] for c in corpus],
                         ["How many loans are there?", "Count the loans."])
        same = leak.find_leaks([{"id": "E1", "question": "How many loans are there ?"}], corpus)
        self.assertEqual(same[0]["why"], "same text")
        close = leak.find_leaks([{"id": "E2", "question": "How many loans are there now?"}],
                                corpus)
        self.assertTrue(close and close[0]["ratio"] >= 0.9)
        grouped = leak.find_leaks([{"id": "E3", "question": "Loans in total?", "group": "g1"}],
                                  corpus)
        self.assertIn("group g1", grouped[0]["why"])
        self.assertEqual(leak.find_leaks([{"id": "E4", "question": "Who wrote Hamlet?"}],
                                         corpus), [])

    def test_refuse_to_score_a_leaking_set(self):
        with self.assertRaises(SystemExit) as caught:
            leak.refuse_if_leaking([{"id": "E1", "question": "Count the loans."}], "Library",
                                   {}, self.tmp)
        self.assertIn("refusing to score Library", str(caught.exception))
        self.assertEqual(leak.refuse_if_leaking([{"id": "E2", "question": "Who wrote it?"}],
                                                "Library", {}, self.tmp), 2)

    def test_the_committed_sets_do_not_leak_into_the_example_kbs(self):
        for profile in goldens.PROFILES:
            with self.subTest(profile=profile):
                rows = goldens.read_dataset(profile)
                self.assertEqual(leak.find_leaks(rows, leak.corpus(profile)), [])


class EvalCoverageTests(unittest.TestCase):
    """A recorded agent run (the trace fixture) scored end to end."""

    IDS = "E01,E16,E27,E34"

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="eval-coverage-"))
        self.addCleanup(shutil.rmtree, self.tmp, True)
        rows = {r["id"]: r for r in goldens.read_dataset("Enterprise")}
        verdicts = {"E01": ("ANSWERABLE", ""), "E16": ("ANSWERABLE", ""),
                    "E27": ("ANSWERABLE", ""),
                    "E34": ("NEEDS MORE", "I would need to know: the BUDGET rates for 2027; "
                                           "exchange_rates ends on 2026-06-30 and 37 orders wait.")}
        self.run = self.tmp / "run.csv"
        with open(self.run, "w", encoding="utf-8-sig", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=["id", "question", "verdict", "kind",
                                                    "answer_to_give", "choices"])
            writer.writeheader()
            for qid, (verdict, sentence) in verdicts.items():
                writer.writerow({"id": qid, "question": rows[qid]["question"],
                                 "verdict": verdict, "kind": "",
                                 "answer_to_give": sentence or "Yes, this can be answered as asked.",
                                 "choices": ""})
        shutil.copy(FIXTURES / "trace_agent.jsonl", str(self.run) + ".trace.jsonl")

    def main(self, *extra):
        out = self.tmp / "out"
        with redirect_stdout(io.StringIO()) as printed:
            code = eval_coverage.main(["Enterprise", "--mode", "agent", "--from-run",
                                       str(self.run), "--ids", self.IDS, "--out", str(out),
                                       *extra])
        reports = sorted(out.glob("Enterprise_agent_*.json"))
        return code, json.loads(reports[-1].read_text(encoding="utf-8")), \
            sorted(out.glob("Enterprise_agent_*.md"))[-1].read_text(encoding="utf-8"), \
            printed.getvalue()

    def test_three_tables_from_a_recorded_run(self):
        compare = self.tmp / "before.json"
        compare.write_text(json.dumps({"verdicts": {"E01": "ANSWERABLE", "E16": "NEEDS A CHOICE",
                                                    "E27": "NEEDS MORE", "E34": "NEEDS MORE"}}),
                           encoding="utf-8")
        code, rep, md, printed = self.main("--compare", str(compare))
        self.assertEqual(code, 0)
        rows = {r["id"]: r for r in rep["per_question"]}
        self.assertEqual(rep["summary"]["right"], 4)
        self.assertEqual(rows["E01"]["context_recall"], 1.0)
        self.assertAlmostEqual(rows["E16"]["context_recall"], 2 / 3)
        self.assertEqual(rows["E16"]["context_precision"], 1.0)
        self.assertEqual(rows["E16"]["tables"], "2/3")
        self.assertEqual(rows["E16"]["missing_tables"], ["products"])
        self.assertIsNotNone(rows["E27"]["turns"])
        self.assertIn("describe_tables", rows["E27"]["tools"])
        # exchange_rates, 2026-06-30 and 37 are in the digests; BUDGET and 2027
        # come from the question and are not claims
        self.assertEqual(rows["E34"]["faithfulness"], 1.0)
        self.assertEqual(rep["comparison"]["fixed"], ["E16", "E27"])
        self.assertEqual(rep["comparison"]["mcnemar"]["p"], 0.5)
        self.assertIn(stats.SAMPLE_NOTE, md)
        self.assertIn("## Par question", md)
        self.assertIn("| E16 |", md)
        self.assertNotIn(chr(0x2014), md)
        self.assertIn("4/4", printed)

    def test_a_broken_question_fails_the_run(self):
        compare = self.tmp / "before.csv"
        with open(compare, "w", encoding="utf-8-sig", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=["id", "question", "verdict"])
            writer.writeheader()
            writer.writerow({"id": "E34", "question": "x", "verdict": "NEEDS MORE"})
        (self.run.parent / "run2.csv").write_text(
            self.run.read_text(encoding="utf-8-sig").replace("NEEDS MORE", "ANSWERABLE"),
            encoding="utf-8-sig")
        self.run = self.run.parent / "run2.csv"
        code, rep, _, printed = self.main("--compare", str(compare))
        self.assertEqual(code, 1)
        self.assertEqual(rep["comparison"]["broke"], ["E34"])
        self.assertIn("REGRESSION", printed)

    def test_a_run_judged_by_the_other_judge_is_refused(self):
        Path(str(self.run) + ".job.json").write_text(json.dumps(
            {"runs": [{"judged": 4, "judge": "single"}]}), encoding="utf-8")
        with self.assertRaisesRegex(SystemExit, "judged by the single judge"):
            self.main()

    def test_a_recorded_run_cannot_be_ablated(self):
        with redirect_stdout(io.StringIO()), self.assertRaises(SystemExit):
            from contextlib import redirect_stderr
            with redirect_stderr(io.StringIO()):
                eval_coverage.parse(["Enterprise", "--mode", "single", "--from-run", "x.csv",
                                     "--ablate", "kb"])


class EvalAskTests(unittest.TestCase):
    def test_read_only_guard(self):
        self.assertTrue(eval_ask.is_read_only("SELECT 1"))
        self.assertTrue(eval_ask.is_read_only("WITH a AS (SELECT 1 AS x) SELECT x FROM a"))
        self.assertTrue(eval_ask.is_read_only("SELECT 1 UNION SELECT 2"))
        for sql in ("DELETE FROM t", "SELECT 1; DROP TABLE t", "UPDATE t SET a = 1",
                    "INSERT INTO t SELECT 1", ""):
            self.assertFalse(eval_ask.is_read_only(sql), sql)

    def test_tables_shown_and_history(self):
        entry = {"steps": [{"name": "anchors", "ok": True,
                            "detail": "customers, customer_segments   (from the corpus)"},
                           {"name": "sub-schema", "ok": True,
                            "detail": "customers > customer_segments > countries   (1 imposed joins)"}]}
        self.assertEqual(eval_ask.shown_tables(entry),
                         (["customers", "customer_segments"],
                          ["customers", "customer_segments", "countries"]))
        tmp = Path(tempfile.mkdtemp(prefix="eval-ask-"))
        self.addCleanup(shutil.rmtree, tmp, True)
        path = tmp / "h.jsonl"
        path.write_text("\n".join(json.dumps(e) for e in (
            {"profile": "Enterprise", "question": "Q one", "answer": "old"},
            {"profile": "Enterprise", "question": "q  ONE", "answer": "new"},
            {"profile": "Library", "question": "Q two"},
            {"profile": "Enterprise", "question": "Q three", "choice": "a.b"})) + "\n",
            encoding="utf-8")
        history = eval_ask.read_history(path, "Enterprise")
        self.assertEqual(list(history), ["q one"])
        self.assertEqual(history["q one"]["answer"], "new")

    def test_scoring_without_a_database(self):
        rows = [r for r in goldens.read_dataset("Enterprise") if r["id"] in ("E01", "E02")]
        history = {
            "how many customers are there in each customer segment?": {
                "question": rows[0]["question"], "sql": rows[0]["sql"], "seconds": 4.0,
                "answer": "Industrial has 120 customers.", "columns": ["segment", "n"],
                "rows": [["Industrial", 120]], "row_count": 6,
                "steps": [{"name": "sub-schema", "ok": True,
                           "detail": "customers > customer_segments   (1 imposed joins)"}]}}
        per = eval_ask.evaluate(rows, history, goldens.load_kb("Enterprise"), None)
        e01, e02 = per
        self.assertIsNone(e01["execution"])
        self.assertIn("row counts 6 against 6", e01["why"])
        self.assertEqual((e01["context_recall"], e01["context_precision"]), (1.0, 1.0))
        self.assertEqual(e01["faithfulness"], 1.0)
        self.assertEqual(e02["why"], "not in the history")
        summary = eval_ask.summarize("Enterprise", per)
        self.assertEqual((summary["execution_scored"], summary["answered"]), (0, 1))
        self.assertEqual(eval_ask.as_verdicts([{"id": "E1", "execution": True},
                                               {"id": "E2", "execution": None}]),
                         {"E1": "RIGHT"})


class LiveTests(unittest.TestCase):
    def test_ablations_act_on_the_profile_object(self):
        from db_profile import DbProfile
        p = DbProfile(name="x", mysql={"host": "h", "database": "d"},
                      neo4j_uri="bolt://n:7687", qdrant_url="http://q:6333",
                      descriptions="kb.json")
        live.apply_ablations(p, ["corpus", "kb", "graph"])
        self.assertEqual((p.qdrant_url, p.descriptions, p.neo4j_uri), (None, None, None))
        self.assertEqual(live.ablation_environment(["kb", "cut", "think"], oracle=True), {
            "DATAGORA_COLUMN_INDEX": "off", "DATAGORA_FOCUS": "off",
            "DATAGORA_AGENT_THINK": "none", "DATAGORA_ORACLE_TABLES": "on"})
        self.assertEqual(live.suffix(["kb", "graph"], True), "_no-kb_no-graph_oracle")

    def test_an_evaluation_never_writes_the_corpus_or_the_index(self):
        import recall
        remember, build = recall.Recall.remember, recall.ColumnIndex.build
        try:
            live.guard_writes()
            self.assertIsNone(recall.Recall.remember(object(), "q", ["t"], "SELECT 1"))
            self.assertEqual(recall.ColumnIndex.build(SimpleNamespace(collection="c"), None), 0)
        finally:
            recall.Recall.remember, recall.ColumnIndex.build = remember, build

    def test_preflight_stops_on_a_database_that_does_not_answer(self):
        class Down:
            name = "x"

            def connect_mysql(self):
                raise OSError("connection refused")

        with self.assertRaisesRegex(SystemExit, "unreachable.*connection refused"):
            live.preflight(Down(), [])

        class Up:
            name = "x"

            def connect_mysql(self):
                return SimpleNamespace(close=lambda: None)

        silent = SimpleNamespace(name="m", url="http://m", reachable=lambda: False)
        with self.assertRaisesRegex(SystemExit, "no model endpoint answers"):
            live.preflight(Up(), [silent])

    def test_report_tables_in_markdown(self):
        lines = report.md_table([{"a": 0.5, "b": None, "c": True, "d": ["x", "y"]}],
                                [("a", "A"), ("b", "B"), ("c", "C"), ("d", "D")])
        self.assertEqual(lines[-1], "| 0,50 | - | oui | x y |")


if __name__ == "__main__":
    unittest.main()
