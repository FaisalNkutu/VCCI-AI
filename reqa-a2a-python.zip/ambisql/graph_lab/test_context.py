"""Who asks and when: the context each question carries to the models.
No model, no database."""

import os

os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

import datetime
import json
import tempfile
import unittest
from types import SimpleNamespace

import context
import pipeline
import verdict_notebook

NOW = datetime.datetime(2026, 10, 23, 12, 31, tzinfo=datetime.timezone(datetime.timedelta(hours=-4)))


class ContextTests(unittest.TestCase):

    def test_the_machine_gives_the_date_the_time_and_the_offset(self):
        ctx = context.machine_context(NOW, {})
        self.assertEqual((ctx["date"], ctx["time"], ctx["weekday"], ctx["utc_offset"]),
                         ("2026-10-23", "12:31", "Friday", "UTC-04:00"))
        self.assertIn("server", ctx)

    def test_the_weekday_follows_the_date_given_and_no_key_crashes(self):
        # review of 23 October: the browser's date with the server's weekday
        late = datetime.datetime(2026, 10, 24, 1, 0, tzinfo=datetime.timezone.utc)
        ctx = context.resolve({"date": "2026-10-23", "now": "x", "environ": "y"}, late, {})
        self.assertEqual(ctx["weekday"], "Friday")
        self.assertIn("Asked on Friday 23 October 2026", context.describe(ctx))
        self.assertEqual(context.moment({"date": "2026-10-23", "time": "09:15"}),
                         datetime.datetime(2026, 10, 23, 9, 15))

    def test_a_date_pinned_in_the_environment_brings_its_own_weekday(self):
        # review of 26 October: "Asked on Monday 1 March 2025", a Saturday
        ctx = context.machine_context(NOW, {"DATAGORA_CONTEXT": '{"date": "2025-03-01"}'})
        self.assertEqual(ctx["weekday"], "Saturday")
        ctx = context.resolve({"date": "2025-03-01", "weekday": "Monday"}, NOW, {})
        self.assertEqual(ctx["weekday"], "Saturday")

    def test_a_coverage_run_is_told_the_day_never_the_minute(self):
        # decided on 26 October: a measure sends the same prompt all day
        import ambisql
        import coverage
        slots = coverage._slots(None, lambda: None, "s", object(), judge="single",
                                context={"date": "2026-10-26", "time": "14:32"})
        said = slots[0].context
        self.assertIn("Monday 26 October 2026", said)
        self.assertNotIn("14:32", said)

    def test_the_sentence_names_the_day_and_last_year(self):
        said = context.describe(context.machine_context(NOW, {}, location="Montreal"))
        self.assertIn("Asked on Friday 23 October 2026 at 12:31, UTC-04:00", said)
        self.assertIn("This year is 2026, last year was 2025", said)
        self.assertIn("Location: Montreal.", said)
        self.assertEqual(context.describe({}), "")

    def test_static_facts_come_from_the_environment_as_json_or_a_file(self):
        self.assertEqual(context.static_context({"DATAGORA_CONTEXT": '{"currency": "CAD"}'}),
                         {"currency": "CAD"})
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "ctx.json")
            with open(p, "w", encoding="utf-8") as fh:
                json.dump({"location": "Paris"}, fh)
            self.assertEqual(context.static_context({"DATAGORA_CONTEXT": p}), {"location": "Paris"})
        self.assertEqual(context.static_context({"DATAGORA_CONTEXT": "{not json"}), {})

    def test_a_dict_goes_over_the_machine_false_is_none_a_callable_is_called(self):
        ctx = context.resolve({"date": "2025-01-02", "timezone": "Europe/Paris"}, NOW, {})
        self.assertEqual((ctx["date"], ctx["timezone"], ctx["time"]),
                         ("2025-01-02", "Europe/Paris", "12:31"))
        self.assertEqual(context.resolve(False, NOW, {}), {})
        self.assertEqual(context.resolve(lambda: {"role": "buyer"}, NOW, {})["role"], "buyer")
        self.assertEqual(context.today({"date": "2025-01-02"}), datetime.date(2025, 1, 2))


class WhereItGoesTests(unittest.TestCase):

    def pipe(self, ctx=None):
        p = pipeline.Pipeline.__new__(pipeline.Pipeline)
        p.context = ctx
        p.clarifier = SimpleNamespace(columns={"orders": [("order_id", "int")]}, context="")
        return p

    def test_the_sql_prompt_carries_the_context(self):
        p = self.pipe()
        p.clarifier.context = "Asked on Friday 23 October 2026."
        text = p.prompt_for_sql("What was our revenue last year?", ["orders"], [])
        self.assertIn("Asked on Friday 23 October 2026.", text)
        self.assertLess(text.index("Asked on"), text.index("Question:"))

    def test_the_agent_reads_it_before_its_reading(self):
        nb = verdict_notebook.Notebook("What was our revenue last year?")
        nb.context = "Asked on Friday 23 October 2026."
        head = verdict_notebook.Budget._head(nb)
        self.assertEqual(head[:5], ["QUESTION", "What was our revenue last year?", "",
                                    "WHO ASKS AND WHEN", "Asked on Friday 23 October 2026."])

    def test_two_questions_at_once_never_read_each_other_s(self):
        # review of 23 October: per-question state on a shared clarifier
        import threading
        import ambisql
        c = ambisql.Clarifier.__new__(ambisql.Clarifier)
        self.assertEqual((c.context, c.earlier, c.today), ("", "", None))
        c.context = "the run's"                    # coverage: every thread
        seen = {}

        def ask():
            c.for_question(context="theirs", earlier="note")
            seen["there"] = (c.context, c.earlier)
        t = threading.Thread(target=ask)
        t.start()
        t.join()
        self.assertEqual(seen["there"], ("theirs", "note"))
        self.assertEqual((c.context, c.earlier), ("the run's", ""))


class ClientTests(unittest.TestCase):

    def test_the_client_takes_a_context_in_package_mode(self):
        import pathlib
        import subprocess
        import sys
        code = "\n".join([
            "from graph_lab import Datagora",
            "from graph_lab.pipeline import Pipeline",
            "d = Datagora.__new__(Datagora)",
            "d.pipeline = Pipeline.__new__(Pipeline)",
            "d.pipeline.context = None",
            "d.context = {'location': 'Montreal'}",
            "assert d.pipeline.context == {'location': 'Montreal'}",
            "from graph_lab.context import describe, resolve",
            "assert 'Location: Montreal.' in describe(resolve(d.context))",
            "print('ok')"])
        src = pathlib.Path(__file__).resolve().parents[1]
        env = dict(os.environ, DATAGORA_TRACING="off", DATAGORA_DOTENV="off",
                   DATAGORA_COLUMN_INDEX="off")
        done = subprocess.run([sys.executable, "-c", code], cwd=src, env=env,
                              capture_output=True, text=True, timeout=120)
        self.assertEqual(done.returncode, 0, done.stderr[-800:])

    def test_the_client_takes_qdrant_and_its_embedding_model(self):
        # review of 27 October: a client could be given Neo4j and not Qdrant
        import pathlib
        import subprocess
        import sys
        code = "\n".join([
            "from graph_lab import Datagora",
            "class Model:",
            "    model = 'm'",
            "    def chat(self, system, user, **kw): return ''",
            "    def json(self, system, user, **kw): return {}",
            "db = dict(host='h', port=3306, database='shop', user='u', password='p')",
            "d = Datagora(db, reasoner=Model(), sql=Model(), qdrant_url='http://q:6333',",
            "             qdrant_collection='shop_corpus', embed_url='http://e:11434',",
            "             embed_model='nomic-embed-text')",
            "p = d.profile",
            "got = (p.qdrant_url, p.qdrant_collection, p.ollama_url, p.embed_model)",
            "assert got == ('http://q:6333', 'shop_corpus', 'http://e:11434', 'nomic-embed-text'), got",
            "assert Datagora(db, reasoner=Model(), sql=Model()).profile.qdrant_url is None",
            "print('ok')"])
        src = pathlib.Path(__file__).resolve().parents[1]
        env = {k: v for k, v in os.environ.items()
               if k not in ("QDRANT_URL", "DATAGORA_QDRANT_URL", "EMBED_MODEL")}
        env.update(DATAGORA_TRACING="off", DATAGORA_DOTENV="off", DATAGORA_COLUMN_INDEX="off")
        done = subprocess.run([sys.executable, "-c", code], cwd=src, env=env,
                              capture_output=True, text=True, timeout=120)
        self.assertEqual(done.returncode, 0, done.stderr[-800:])

    def test_the_page_context_is_kept_short(self):
        import pathlib
        import sys
        from unittest.mock import patch
        here = pathlib.Path(__file__).resolve().parent
        sys.path.insert(0, str(here / "ui"))
        with tempfile.TemporaryDirectory() as d, patch.dict(
                "os.environ", {"DATAGORA_COVERAGE_DIR": d, "DATAGORA_DATA_DIR": d}):
            import app
            kept = app._asker_context({"date": "2026-10-23", "timezone": "x" * 200,
                                       "bad key!": "v", "nested": {"a": 1}})
        self.assertEqual(kept, {"date": "2026-10-23", "timezone": "x" * 80})
        self.assertIsNone(app._asker_context("nope"))


class EarlierTests(unittest.TestCase):
    """What was decided before goes with the follow-up, short."""

    def test_the_note_says_what_was_asked_offered_and_picked(self):
        note = context.earlier_note(
            "How many products did we sell recently?", "NEEDS MORE", "which period recently covers",
            ["How many products did we sell in the last 30 days?",
             "How many products did we sell in the last 90 days?"],
            "How many products did we sell in the last 30 days?", ["order_lines", "orders"])
        for part in ('first asked: "How many products did we sell recently?"',
                     "judged NEEDS MORE: which period recently covers",
                     'They picked: "How many products did we sell in the last 30 days?"',
                     "Tables found then: order_lines, orders",
                     "What the asker settled is settled"):
            self.assertIn(part, note)
        self.assertEqual(context.earlier_note(""), "")
        long = context.earlier_note("q" * 5000, "NEEDS MORE", "w" * 5000, ["o" * 5000] * 9)
        self.assertLessEqual(len(long), context.EARLIER_CHARS)
        # review of 23 October: the cut took the pick and the rule
        full = context.earlier_note("q" * 140, "NEEDS MORE", "w" * 140, ["o" * 140] * 4,
                                    "p" * 140, ["t" * 30] * 8)
        self.assertLessEqual(len(full), context.EARLIER_CHARS)
        self.assertIn("They picked:", full)
        self.assertTrue(full.endswith("do not ask again what they answered."))

    def test_a_chain_of_stops_keeps_where_it_began_and_no_double_full_stop(self):
        note = context.earlier_note("Which products sold in the last 30 days?", "NEEDS MORE",
                                    "which period.", ["Which products sold in May?"],
                                    "Which products sold in May?",
                                    before="The asker first asked: \"Which products sold recently?\".")
        self.assertIn("Before that: The asker first asked", note)
        self.assertNotIn("..", note)

    def test_the_pipeline_tells_the_judge_for_one_question_only(self):
        from ambisql import Option, Outcome
        first = pipeline.Run(question="Which products are cheap?", profile="Shop")
        first.clarification = Outcome(action="GUIDE", phrase="cheap", kind="AmbiContext",
                                      reason="r", missing="the price below which")
        first.suggestions = [{"question": "Which products have a price under 20?"}]
        first.judged_tables = ["products"]
        note = pipeline.earlier_of(first, "Which products have a price under 20?")
        self.assertIn("judged NEEDS MORE: the price below which", note)
        self.assertIn("Tables found then: products", note)

    def test_the_agent_reads_it_after_who_asks(self):
        nb = verdict_notebook.Notebook("Which products have a price under 20?")
        nb.context, nb.earlier = "Asked on Friday.", "The asker first asked: \"cheap?\"."
        head = verdict_notebook.Budget._head(nb)
        self.assertEqual(head[3:8], ["WHO ASKS AND WHEN", "Asked on Friday.", "",
                                     "EARLIER IN THIS CONVERSATION",
                                     "The asker first asked: \"cheap?\"."])

    def test_the_client_links_a_picked_suggestion_by_itself(self):
        # in package mode, as an application imports it
        import pathlib
        import subprocess
        import sys
        code = "\n".join([
            "import graph_lab",
            "from graph_lab import pipeline as gp",
            "seen = []",
            "class Pipe:",
            "    def ask(self, question, choice=None, suggestion=None, context=None, earlier=None):",
            "        seen.append(earlier)",
            "        run = gp.Run(question=question, profile='Shop')",
            "        if question == 'Which products are cheap?':",
            "            run.suggestions = [{'question': 'Which products have a price under 20?'}]",
            "        else:",
            "            run.answer = '12 products'",
            "        return run",
            "d = graph_lab.Datagora.__new__(graph_lab.Datagora)",
            "d.pipeline, d._last_stop = Pipe(), None",
            "first = d.ask('Which products are cheap?')",
            "d.ask(first.suggestions[0].question)",
            "d.ask('Something else entirely?')",
            "assert seen[0] is None and seen[1] is first._run and seen[2] is None, seen",
            "print('ok')"])
        src = pathlib.Path(__file__).resolve().parents[1]
        env = dict(os.environ, DATAGORA_TRACING="off", DATAGORA_DOTENV="off",
                   DATAGORA_COLUMN_INDEX="off")
        done = subprocess.run([sys.executable, "-c", code], cwd=src, env=env,
                              capture_output=True, text=True, timeout=120)
        self.assertEqual(done.returncode, 0, done.stderr[-800:])

    def test_the_client_links_a_choice_on_a_follow_up_to_the_stop_it_answers(self):
        # review of 26 October (Ask 20): a question picked after a stop that
        # stops in turn on a choice; the choice comes back to that stop, and
        # the question after the answer follows nothing
        import pathlib
        import subprocess
        import sys
        code = "\n".join([
            "import graph_lab",
            "from graph_lab import pipeline as gp",
            "from graph_lab.ambisql import Option, Outcome",
            "seen = []",
            "PRICE = Outcome(action='CLARIFY', phrase='price', question='Which price?',",
            "                options=[Option(label='products.price', means='what customers pay')])",
            "class Pipe:",
            "    def ask(self, question, choice=None, suggestion=None, context=None, earlier=None):",
            "        seen.append(earlier)",
            "        run = gp.Run(question=question, profile='Shop')",
            "        if question == 'Which products are cheap?':",
            "            run.suggestions = [{'question': 'Which products have a price under 20?'}]",
            "        elif choice is None:",
            "            run.clarification = PRICE",
            "        else:",
            "            run.answer = '12 products'",
            "        return run",
            "d = graph_lab.Datagora.__new__(graph_lab.Datagora)",
            "d.pipeline, d._last_stop = Pipe(), None",
            "first = d.ask('Which products are cheap?')",
            "second = d.ask(first.suggestions[0].question)",
            "third = d.ask(first.suggestions[0].question, choice='products.price')",
            "d.ask('Something else entirely?')",
            "assert seen[1] is first._run and seen[2] is second._run and seen[3] is None, seen",
            "assert third.answer == '12 products'",
            "print('ok')"])
        src = pathlib.Path(__file__).resolve().parents[1]
        env = dict(os.environ, DATAGORA_TRACING="off", DATAGORA_DOTENV="off",
                   DATAGORA_COLUMN_INDEX="off")
        done = subprocess.run([sys.executable, "-c", code], cwd=src, env=env,
                              capture_output=True, text=True, timeout=120)
        self.assertEqual(done.returncode, 0, done.stderr[-800:])

    def test_one_thread_never_follows_another_s_stop(self):
        # review of 26 October: one client in a web server, two users
        import pathlib
        import subprocess
        import sys
        code = "\n".join([
            "import threading",
            "import graph_lab",
            "from graph_lab import pipeline as gp",
            "seen = []",
            "class Pipe:",
            "    def ask(self, question, choice=None, suggestion=None, context=None, earlier=None):",
            "        seen.append(earlier)",
            "        run = gp.Run(question=question, profile='Shop')",
            "        if question == 'Which products are cheap?':",
            "            run.suggestions = [{'question': 'Which products have a price under 20?'}]",
            "        else:",
            "            run.answer = '12 products'",
            "        return run",
            "d = graph_lab.Datagora.__new__(graph_lab.Datagora)",
            "d.pipeline = Pipe()",
            "first = d.ask('Which products are cheap?')",
            "other = threading.Thread(target=lambda: d.ask(first.suggestions[0].question))",
            "other.start()",
            "other.join()",
            "d.ask(first.suggestions[0].question)",
            "assert seen[1] is None and seen[2] is first._run, seen",
            "print('ok')"])
        src = pathlib.Path(__file__).resolve().parents[1]
        env = dict(os.environ, DATAGORA_TRACING="off", DATAGORA_DOTENV="off",
                   DATAGORA_COLUMN_INDEX="off")
        done = subprocess.run([sys.executable, "-c", code], cwd=src, env=env,
                              capture_output=True, text=True, timeout=120)
        self.assertEqual(done.returncode, 0, done.stderr[-800:])


if __name__ == "__main__":
    unittest.main()
