"""The gate that keeps the component reusable, run on every profile.

Portability is not a property you have, it is one you keep losing. One
hurried fix that reads a table by name and the component silently stops
working on any other schema, which is discovered at a customer's site.
So it is enforced here rather than asserted in a document.

Three checks, and the second is the one that really bites.

1. **No schema name in the logic.** Every table of every configured
   database is searched for in the modules that run in production. Test
   fixtures may name tables; the engine may not.

2. **Queries built from the graph, not written by hand.** For each
   database the test reads an edge out of Neo4j and assembles a join
   from it, then assembles a broken one by swapping the key. Both are
   generated from whatever schema is there, so a passing run means the
   audit worked on a schema this file never mentions. Hand-written
   cases could never prove that.

3. **The whole chain runs on every profile**: connect, read the
   catalogue, read the graph, audit, and clarify.

    .venv/Scripts/python src/graph_lab/test_reusable.py
"""

import os

# the column index is on by default; a test never builds one in a real
# Qdrant, and the tests that need one give it directly
os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")

import sys
from pathlib import Path

from db_profile import DbProfile
from schema_graph import Graph, audit_joins

HERE = Path(__file__).parent
# what ships and must stay schema-agnostic; test_* files hold fixtures
ENGINE = ["db_profile.py", "llm.py", "schema_graph.py", "build_graph.py",
          "ambisql.py", "ui/app.py", "verdict_tools.py", "verdict_agent.py", "verdict_notebook.py", "verdict_verifier.py"]


def check_no_hardcoded_names(profiles):
    """Fails if a production module names a table of any known database."""
    names = set()
    for p in profiles:
        con = p.connect_mysql()
        cur = con.cursor()
        cur.execute("""SELECT table_name FROM information_schema.tables
                       WHERE table_schema=%s AND table_type='BASE TABLE'""",
                    (p.schema,))
        names.update(r[0].lower() for r in cur.fetchall())
        con.close()
    # a couple of table names are ordinary English and would false-positive
    names -= {"members", "books", "products", "loans", "authors", "genres"}

    offences = []
    for rel in ENGINE:
        path = HERE / rel
        if not path.exists():
            continue
        in_doc = False
        for n, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            # prose may mention a schema for illustration; only code is judged
            fences = line.count('"""') + line.count("'''")
            if in_doc:
                if fences:
                    in_doc = False
                continue
            if fences == 1:
                in_doc = True
                continue
            low = line.lower()
            if low.lstrip().startswith("#") or fences:
                continue
            for name in names:
                if name in low:
                    offences.append(f"{rel}:{n} names {name!r}")
    return offences


def generated_cases(graph):
    """A valid join and a broken one, assembled from this graph's own
    edges, so the test never writes a table name itself."""
    real = [e for e in graph.edges if e[0] != e[2] and "," not in str(e[1])]
    if len(real) < 2:
        return []
    a_tab, a_lc, a_rt, a_rc = real[0][0], real[0][1], real[0][2], real[0][3]
    b_tab, b_lc, b_rt, b_rc = real[1][0], real[1][1], real[1][2], real[1][3]
    return [
        ("valid join from the graph", "OK",
         f"SELECT * FROM {a_tab} JOIN {a_rt} "
         f"ON {a_tab}.{a_lc} = {a_rt}.{a_rc}"),
        ("keys swapped for a table that is linked", "REJECT",
         f"SELECT * FROM {a_tab} JOIN {a_rt} "
         f"ON {a_tab}.{a_rc}_nope = {a_rt}.{a_lc}_nope"),
        ("two tables with no edge between them", "REJECT",
         f"SELECT * FROM {a_tab} JOIN {b_tab} "
         f"ON {a_tab}.{a_lc} = {b_tab}.{b_lc}")
        if not graph.tables_linked(a_tab, b_tab) else
        ("second valid join from the graph", "OK",
         f"SELECT * FROM {b_tab} JOIN {b_rt} "
         f"ON {b_tab}.{b_lc} = {b_rt}.{b_rc}"),
    ]


def main():
    names = DbProfile.names()
    profiles = [DbProfile.load(n) for n in names]
    print(f"profiles under test: {', '.join(names)}\n")

    failures = []

    print("1. no schema name in the engine")
    offences = check_no_hardcoded_names(profiles)
    if offences:
        failures.append("hardcoded table names")
        for o in offences[:10]:
            print(f"   FAIL {o}")
    else:
        print(f"   PASS  {len(ENGINE)} modules clean")

    print("\n2 and 3. the chain, on every profile, with generated queries")
    for p in profiles:
        try:
            con = p.connect_mysql()
            cur = con.cursor()
            cur.execute("""SELECT COUNT(*) FROM information_schema.columns
                           WHERE table_schema=%s""", (p.schema,))
            ncols = cur.fetchone()[0]
            con.close()

            drv = p.connect_neo4j()
            graph = Graph.from_profile(p, drv)
            cases = generated_cases(graph)
            if not graph.edges:
                failures.append(f"{p.name}: empty graph, run build_graph.py")
                print(f"   FAIL {p.name}: no graph. "
                      f"Run build_graph.py --profile {p.name}")
                drv.close()
                continue

            ok = True
            for label, expect, sql in cases:
                verdicts = audit_joins(sql, graph)
                got = "OK" if all(v[0] == "OK" for v in verdicts) else "REJECT"
                if got != expect:
                    ok = False
                    print(f"   FAIL {p.name}: {label}, "
                          f"expected {expect} got {got}")
            if ok:
                print(f"   PASS  {p.name}: {ncols} columns, "
                      f"{len(graph.edges)} edges, "
                      f"{len(cases)} generated queries judged correctly")
            else:
                failures.append(p.name)
            drv.close()
        except Exception as e:
            failures.append(f"{p.name}: {type(e).__name__}")
            print(f"   FAIL {p.name}: {type(e).__name__}: {str(e)[:110]}")

    print()
    if failures:
        print(f"REUSABILITY BROKEN: {', '.join(str(f) for f in failures)}")
        sys.exit(1)
    print("REUSABLE: the engine names no table, and every configured "
          "database\npasses with queries generated from its own schema.")


if __name__ == "__main__":
    main()
