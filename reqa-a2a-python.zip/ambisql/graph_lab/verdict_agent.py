"""The coverage judge as an agent that reads, plans, explores and concludes.

The single-call judge (Clarifier.detect) followed by word rules
(Clarifier.ground) decided on isolated words and never checked its claims
against the database. This judge works the way a person would on an
unfamiliar schema: it reads the question into a structured reading, makes
a plan, looks at the tables, values and joins it needs with bounded
read-only tools (verdict_tools.ToolBox), and concludes. The code then
checks every fact the conclusion rests on before it becomes a verdict
(verdict_verifier.Verifier).

  facts are settled by the database, never by the model: a table or a
  column exists, a value is stored, two tables join, two readings give
  different results, something is absent from the whole database;

  meaning is settled by the model, with the facts in front of it: which
  reading the wording selects, whether a threshold is the asker's to set.

The code explores for the agent before the agent explores for itself:
the tables one key away from the first ones the search found, then, once
the agent has written its reading, each value it names, each table it
expects and the joins between them. Models prefer to answer and try again
over looking first; the probes make the looking happen.

Every turn is one JSON reply; the user message is rebuilt each turn from
a notebook and made to fit the window (verdict_notebook). Drop-in for
Clarifier.clarify(question) -> Outcome: coverage.classify and
coverage._judge_core do not change.
"""

from __future__ import annotations

import copy
import inspect
import re
import threading
import time

if __package__:
    from .ambisql import TYPES, Outcome, _step
    from .verdict_notebook import (CONCLUDE_ROOM, MIN_RESULT_TOKENS, MIN_THINKING_ROOM,
                                   REPLY_ROOM, SHRINK_ON_OVERFLOW, THINK_ROOM, Budget,
                                   CodeResult, Notebook, Step, clip, short_args)
    from . import wording
    from .verdict_tools import strip_comments
    from .verdict_verifier import (COMPATIBLE_KINDS, ISSUES, KIND_OF_ISSUE, SEVERITY,
                                   VERDICTS, Checked, Verifier, matching_rows)
else:
    from ambisql import TYPES, Outcome, _step
    from verdict_notebook import (CONCLUDE_ROOM, MIN_RESULT_TOKENS, MIN_THINKING_ROOM,
                                  REPLY_ROOM, SHRINK_ON_OVERFLOW, THINK_ROOM, Budget,
                                  CodeResult, Notebook, Step, clip, short_args)
    import wording
    from verdict_tools import strip_comments
    from verdict_verifier import (COMPATIBLE_KINDS, ISSUES, KIND_OF_ISSUE, SEVERITY,
                                  VERDICTS, Checked, Verifier, matching_rows)

__all__ = ["VerdictAgent", "VotingAgent", "AgentCancelled", "AGENT_TOOLS", "TURN_SCHEMA",
           "FIRST_TURN_SCHEMA", "CONCLUSION_SCHEMA", "Notebook", "Step", "Budget",
           "Verifier", "Checked", "CodeResult", "KIND_OF_ISSUE", "SEVERITY", "ISSUES",
           "VERDICTS", "COMPATIBLE_KINDS", "THINK_ROOM", "REPLY_ROOM", "CONCLUDE_ROOM",
           "MIN_RESULT_TOKENS", "MIN_THINKING_ROOM", "matching_rows"]


# ------------------------------------------------------------- constants

# the tools the model may call; "more" pages through a result already
# read and runs no query. Kept here as well as in verdict_tools so the
# reply schema can be built without importing the tools.
AGENT_TOOLS = ("search_tables", "describe_tables", "find_columns",
               "sample_values", "find_value", "join_path", "time_columns",
               "run_count", "compare_readings", "compute", "clock", "more")

# which phases may think, per engine setting `agent_think`; formatting and
# probing never do (nothing to reason about)
THINKING_PHASES = {
    "all": {"planning", "exploring", "concluding", "reasking"},
    "plan_conclude": {"planning", "concluding", "reasking"},
    "none": set(),
}

MAX_PROBES = 8
MIN_CALL_SECONDS = 60       # the least an exploring call is given before it times out
WORDING_SECONDS = 60        # the most the closed question on a choice's wording may take
MAX_WORDING_CALLS = 2       # and how many times a question may ask it
MAX_WEIGH_CALLS = 2         # the values question (Verifier.weigh), as many
MAX_RANK_CALLS = 2          # the ranking question (Verifier.rank), as many
WEIGH_TOKENS = 600          # its reply: a column, yes or no, one sentence
WORDING_TOKENS = 400        # its reply: a yes or no, a letter and one sentence
WORDING_SCHEMA = {"type": "object",
                  "properties": {"choose": {"type": "boolean"},
                                 "reading": {"type": "string"},
                                 "why": {"type": "string"}},
                  "required": ["choose", "reading", "why"]}
RANK_SCHEMA = {"type": "object",
               "properties": {"is": {"type": "string", "enum": ["ranking", "thing"]},
                              "why": {"type": "string"}},
               "required": ["is", "why"]}
CONCLUDE_FLOOR = 180        # the least the conclusion is given: it always comes


# ----------------------------------------------------------- the schemas

READING = {
    "type": "object",
    "properties": {
        "measure": {"type": "string"},
        "entities": {"type": "array", "items": {"type": "string"}, "maxItems": 6},
        "filters": {"type": "array", "items": {"type": "string"}, "maxItems": 6},
        "values": {"type": "array", "items": {"type": "string"}, "maxItems": 6},
        "tables": {"type": "array", "items": {"type": "string"}, "maxItems": 6},
        "period": {"type": "string"},
        "comparisons": {"type": "array", "items": {"type": "string"}, "maxItems": 4},
        "time": {"type": "string", "enum": ["none", "current_state", "as_of",
                                            "sequence", "duration", "first_last"]},
        "time_relations": {"type": "array", "items": {"type": "string"}, "maxItems": 4},
    },
    "required": ["measure", "entities", "filters", "values", "tables", "period",
                 "comparisons", "time", "time_relations"],
}

READING_ITEM = {
    "type": "object",
    "properties": {"label": {"type": "string"}, "means": {"type": "string"},
                   "table": {"type": "string"}, "column": {"type": "string"},
                   "sql": {"type": "string"}},
    "required": ["label", "means", "table", "column", "sql"],
}

ISSUE = {
    "type": "object",
    "properties": {
        "type": {"type": "string", "enum": list(ISSUES)},
        "phrase": {"type": "string"},
        "kind": {"type": "string", "enum": sorted(TYPES)},
        "what": {"type": "string"},
        "readings": {"type": "array", "items": READING_ITEM, "maxItems": 4},
        "check_sql": {"type": "string"},
        "evidence": {"type": "array", "items": {"type": "integer"}, "maxItems": 6},
    },
    "required": ["type", "phrase", "kind", "what", "readings", "check_sql"],
}

CONCLUSION = {
    "type": "object",
    "properties": {
        "reason": {"type": "string"},
        "verdict": {"type": "string", "enum": list(VERDICTS)},
        "tables": {"type": "array", "items": {"type": "string"}, "maxItems": 10},
        "columns": {"type": "array", "maxItems": 12, "items": {
            "type": "object",
            "properties": {"table": {"type": "string"}, "column": {"type": "string"},
                           "role": {"type": "string", "enum": [
                               "measure", "filter", "group", "order", "time",
                               "label", "join"]}},
            "required": ["table", "column", "role"]}},
        "joins": {"type": "array", "items": {"type": "string"}, "maxItems": 8},
        "issues": {"type": "array", "items": ISSUE, "maxItems": 4},
    },
    "required": ["reason", "verdict", "tables", "columns", "joins", "issues"],
}

ARGS = {
    "type": "object",
    "properties": {
        "phrase": {"type": "string"},
        "names": {"type": "array", "items": {"type": "string"}, "maxItems": 4},
        "table": {"type": "string"}, "column": {"type": "string"},
        "value": {"type": "string"},
        "tables": {"type": "array", "items": {"type": "string"}, "maxItems": 6},
        "a": {"type": "string"}, "b": {"type": "string"},
        "sql": {"type": "string"},
        "sqls": {"type": "array", "items": {"type": "string"}, "minItems": 2, "maxItems": 4},
        "n": {"type": "integer"}, "step": {"type": "integer"},
        "cursor": {"type": "integer"},
        "mode": {"type": "string", "enum": ["full", "size"]},
        "expression": {"type": "string"},
    },
}

# what the agent does not know yet, and how it will find it out: the data,
# a computation, the clock, or, last, the asker
# what a reading's period says when it names none
NO_PERIOD = frozenset({"", "none", "n/a", "na", "null", "-", "all", "all time", "any",
                       "ever", "always"})

UNKNOWNS = {"type": "array", "maxItems": 4, "items": {
    "type": "object",
    "properties": {"what": {"type": "string"},
                   "how": {"type": "string",
                           "enum": ["data", "readings", "compute", "clock", "asker"]}},
    "required": ["what", "how"]}}


def _turn_schema(first):
    props = {
        "thought_summary": {"type": "string"},
        "notes": {"type": "array", "maxItems": 6, "items": {
            "type": "object",
            "properties": {"step": {"type": "integer"}, "summary": {"type": "string"}},
            "required": ["step", "summary"]}},
    }
    if first:
        props["reading"] = READING
    props.update({
        "plan": {"type": "array", "maxItems": 8, "items": {
            "type": "object",
            "properties": {"do": {"type": "string"},
                           "status": {"type": "string", "enum": ["todo", "done", "dropped"]}},
            "required": ["do", "status"]}},
        "unknowns": UNKNOWNS,
        "action": {"type": "string", "enum": ["call", "conclude"]},
        "call": {"type": "object",
                 "properties": {"tool": {"type": "string", "enum": list(AGENT_TOOLS)},
                                "args": ARGS},
                 "required": ["tool", "args"]},
        "conclusion": CONCLUSION,
    })
    required = ["thought_summary", "notes"] + (["reading"] if first else []) + ["plan", "action"]
    return {"type": "object", "properties": props, "required": required}


TURN_SCHEMA = _turn_schema(first=False)
FIRST_TURN_SCHEMA = _turn_schema(first=True)
CONCLUSION_SCHEMA = {"type": "object", "properties": {"conclusion": CONCLUSION},
                     "required": ["conclusion"]}


def _accepts(fn, name):
    """Whether a callable takes a keyword argument `name` (or **kw)."""
    try:
        params = inspect.signature(fn).parameters
    except (TypeError, ValueError):
        return False
    return name in params or any(p.kind is p.VAR_KEYWORD for p in params.values())


def _passes(model, name):
    """Whether `name` given to model.json reaches the call it makes: json
    must take it, and so must _chat when the model has one."""
    return _accepts(model.json, name) and (
        not hasattr(model, "_chat") or _accepts(model._chat, name))


# a verdict's weight when the vote is tied: the one that asks more of the
# asker wins, as the verifier's severity does for issues
VOTE_SEVERITY = {"NOT COVERED": 4, "NEEDS MORE": 3, "NO DATA": 2,
                 "NEEDS A CHOICE": 1, "ANSWERABLE": 0, "UNKNOWN": -1}
VOTED = ("NEEDS A CHOICE", "NEEDS MORE")


class AgentCancelled(RuntimeError):
    """The job was stopped while this question was being judged."""
    # read by the verifier, which keeps a failing check from sinking a
    # question but must never keep a stopped job going
    stops_the_job = True


class _Malformed(Exception):
    pass


class _OutOfTime(Exception):
    """An exploring call ran out of the question's time: conclude now."""


# ------------------------------------------------------------------ agent

class VerdictAgent:
    """Replaces Clarifier.clarify(question) -> Outcome, nothing around it
    changes. One per slot; the SchemaView is shared by every slot of a
    job, the ToolBox is made fresh for every question."""

    def __init__(self, clar, view=None, settings=None, system=None,
                 clock=time.monotonic, toolbox=None):
        self.clar = clar
        self._view = view
        self._settings = settings
        self._system = system
        self.clock = clock
        self._toolbox_factory = toolbox
        self.last_trace = None
        self.last_reply = None
        self.last_shown = None
        self.cancel_event: threading.Event | None = None
        self._deadline = None
        self._longest = 0.0         # the longest model call of this question, seconds
        self._trace_now = None
        self._wordings = 0          # closed questions on wording asked for this question
        self._weighings = 0         # values questions asked for this question

    # what coverage reads off a clarifier
    @property
    def _llm(self):
        return getattr(self.clar, "_llm", None)

    @property
    def llm(self):
        return self.clar.llm

    @property
    def profile(self):
        return getattr(self.clar, "profile", None)

    @property
    def settings(self):
        if self._settings is None:
            if __package__:
                from .verdict_tools import Settings
            else:
                from verdict_tools import Settings
            self._settings = Settings.from_environment()
        return self._settings

    @property
    def view(self):
        if self._view is None:
            if __package__:
                from .verdict_tools import SchemaView
            else:
                from verdict_tools import SchemaView
            self._view = SchemaView(self.clar)
        return self._view

    @property
    def system(self):
        if self._system is None:
            if __package__:
                from . import prompts
            else:
                import prompts
            text = getattr(prompts, "AGENT_SYSTEM", None)
            if not text:
                raise RuntimeError("prompts.AGENT_SYSTEM is missing: the agent has no prompt")
            self._system = text
        return self._system

    def _tools(self):
        if self._toolbox_factory is not None:
            return self._toolbox_factory(self.clar, self.view, self.settings)
        if __package__:
            from .verdict_tools import ToolBox
        else:
            from verdict_tools import ToolBox
        return ToolBox(self.clar, self.view, self.settings, seen=set())

    # --------------------------------------------------------- the loop
    def clarify(self, question):
        """One question judged. Never raises but to stop a job: a failure
        anywhere is an ERROR outcome (UNKNOWN, judged again on resume) with
        its trace."""
        self.last_trace = self.last_reply = self.last_shown = None
        started = self.clock()
        nb = Notebook(question)
        nb.context = str(getattr(self.clar, "context", "") or "")
        nb.earlier = str(getattr(self.clar, "earlier", "") or "")
        trace = {"mode": "agent", "prompt": self._prompt_version(), "turns": [],
                 "verifier": [], "coercions": [], "feedback_rounds": 0}
        stopped_by, outcome = "concluded", None
        self._longest = 0.0
        self._trace_now = trace
        self._wordings = 0
        self._weighings = 0
        self._rankings = 0
        try:
            s = self.settings
            self._deadline = started + float(getattr(s, "max_seconds", 1200) or 1200)
            tools = self._tools()
            # a settings object that does not mention the checks leaves
            # them off: the closed questions asked of a model in a fresh
            # context, on a choice's wording and on a column's values
            closed = bool(getattr(s, "wording", False))
            verifier = Verifier(self.view, tools, s,
                                meaning=self._wording if closed else None,
                                weigh=self._weigh if closed else None,
                                rank=self._rank if closed else None,
                                left=self._left)
            budget = Budget(self.llm, self.system, s)
            trace["settings"] = {k: getattr(s, k, None) for k in (
                "max_turns", "max_seconds", "think", "result_tokens",
                "choice_tolerance", "same_result", "verify_rounds", "wording")}
            trace["budget"] = {"window": budget.window, "system": budget.system,
                               "rooms": {"explore_think": budget.room(True),
                                         "explore": budget.room(False),
                                         "conclude_think": budget.room(True, True)}}
            outcome, stopped_by = self._run(question, nb, tools, verifier, budget, trace)
        except AgentCancelled:
            stopped_by = "cancel"
            raise
        except _Malformed as e:
            stopped_by, outcome = "error", Outcome(action="ERROR", reason=str(e))
        except Exception as e:      # a judge that fails is an UNKNOWN, never a crash
            stopped_by = "error"
            outcome = Outcome(action="ERROR", reason=f"{type(e).__name__}: {e}"[:200])
        finally:
            trace.update(reading=nb.reading, plan=nb.plan, stopped_by=stopped_by,
                         seconds=round(self.clock() - started, 3),
                         tables_seen=nb.described())
            if outcome is not None:
                trace["outcome"] = {"action": outcome.action, "kind": outcome.kind,
                                    "phrase": outcome.phrase,
                                    "options": [o.label for o in outcome.options],
                                    "checked": outcome.checked, "empty": outcome.empty,
                                    "reason": outcome.reason if outcome.action == "ERROR" else None}
            self.last_trace = trace
            self.last_shown = nb.described()
        return outcome

    def _left(self):
        return (self._deadline or 0) - self.clock()

    def _margin(self):
        """The time kept for the conclusion: what the slowest call of this
        question took, half again, and never less than a fixed margin. Three
        questions sharing a GPU make every call slower, and a reserve fixed
        in advance left the conclusion without time to come."""
        total = float(getattr(self.settings, "max_seconds", 1200) or 1200)
        fixed = 90 if total > 180 else total * 0.3
        return min(total * 0.5, max(fixed, 1.5 * self._longest))

    def _run(self, question, nb, tools, verifier, budget, trace):
        s = self.settings
        max_turns = max(2, int(getattr(s, "max_turns", 8) or 8))
        rounds_allowed = int(getattr(s, "verify_rounds", 1) or 0)

        # step 0, by the code: where the question points, and the tables one
        # key away from the first five, so a bridge table is never lost
        self._call_tool(nb, tools, "search_tables", {"phrase": question, "n": 12},
                        "probing", trace)
        self._neighbours(nb)

        turn, rounds, extra_turns = 1, 0, 0
        try:
            reply = self._turn(nb, "planning", FIRST_TURN_SCHEMA, budget, turn, max_turns, trace)
        except _OutOfTime:
            return self._conclude_now(nb, verifier, budget, turn + 1, max_turns, trace,
                                      why="time_cap")
        nb.apply_reply(reply)
        self._probe(nb, tools, trace)
        if reply.get("action") == "call" and isinstance(reply.get("call"), dict):
            self._do_call(nb, tools, reply["call"], trace)
        while True:
            self._check_cancel()
            turn += 1
            limit = max_turns + extra_turns
            if turn >= limit or self._left() < self._margin():
                return self._conclude_now(nb, verifier, budget, turn, limit, trace)
            phase = "reasking" if nb.feedback else "exploring"
            try:
                reply = self._turn(nb, phase, TURN_SCHEMA, budget, turn, limit, trace)
            except _OutOfTime:
                return self._conclude_now(nb, verifier, budget, turn, limit, trace,
                                          why="time_cap")
            nb.apply_reply(reply)
            if reply.get("action") == "call":
                self._do_call(nb, tools, reply.get("call") or {}, trace)
                continue
            conclusion = reply.get("conclusion")
            if not self._valid_conclusion(conclusion):
                fixed = self._turn(nb, "formatting", CONCLUSION_SCHEMA, budget, turn, limit,
                                   trace, concluding=True)
                conclusion = fixed.get("conclusion")
                if not self._valid_conclusion(conclusion):
                    raise _Malformed("the conclusion could not be read")
            checked = self._check(verifier, conclusion, nb, rounds >= rounds_allowed, trace)
            if checked.outcome is not None:
                return checked.outcome, "concluded"
            rounds += 1
            trace["feedback_rounds"] = rounds
            nb.feedback = list(checked.feedback)
            nb.forget_conclusion()
            extra_turns = 2

    def _conclude_now(self, nb, verifier, budget, turn, limit, trace, why=None):
        """The conclusion, from what was found, at the turn or time cap. It
        thinks only when the time left holds two calls as slow as the
        slowest so far, and it is given the time it needs."""
        why = why or ("time_cap" if self._left() < self._margin() else "turn_cap")
        hurry = self._left() < 2 * max(self._longest, 1.0)
        reply = self._turn(nb, "concluding", CONCLUSION_SCHEMA, budget, turn, limit,
                           trace, concluding=True, hurry=hurry)
        conclusion = reply.get("conclusion")
        if not self._valid_conclusion(conclusion):
            return verifier.no_conclusion(), why
        checked = self._check(verifier, conclusion, nb, True, trace)
        return checked.outcome or verifier.no_conclusion(), why

    def _check(self, verifier, conclusion, nb, final, trace):
        self._say("checking", f"verdict {conclusion.get('verdict')}")
        with _step("verify", as_type="guardrail",
                   input={"verdict": conclusion.get("verdict"), "final": final}) as traced:
            checked = verifier.check(conclusion, nb, final)
            try:
                traced.update(output={"feedback": checked.feedback,
                                      "action": getattr(checked.outcome, "action", None)})
            except Exception:
                pass
        trace["verifier"] += checked.checks
        trace["coercions"] += checked.coercions
        trace["conclusion"] = conclusion
        trace["declared_verdict"] = conclusion.get("verdict")
        self.last_reply = conclusion
        return checked

    def _wording(self, question, phrase, readings):
        """(index, why) when the question's words select one of the
        readings, None when the asker must choose or the check could not
        tell.

        Asked once the facts showed the readings give different results,
        in a fresh context: the model sees the question, the readings and
        that their results differ, never the agent's notes nor its verdict
        (a model that reviews its own draft repeats its mistakes, CoVe).
        No thinking: a closed question. Replayed on the 25 choices of the
        runs of 19 October, it agreed with the answer key on 22 and kept
        the five real choices.

        It is asked even at the time cap, where half the questions of those
        runs ended and where invented choices were left: a fixed timeout
        of WORDING_SECONDS, at most MAX_WORDING_CALLS times a question, so
        the overrun is bounded as the conclusion's own floor is. A reply
        that cannot be read keeps the choice."""
        if __package__:
            from . import prompts
        else:
            import prompts
        self._check_cancel()
        if self._wordings >= MAX_WORDING_CALLS:
            return None
        self._wordings += 1
        model, _thinks = self._model_for("checking", None, force_off=True)
        lines = [f"QUESTION: {question}", f"CLAIMED AMBIGUITY: \"{phrase}\""]
        said = str(getattr(self.clar, "context", "") or "")
        if said:
            lines.insert(1, f"ASKED: {said}")
        letters = "ABCD"
        for k, r in enumerate(readings[:len(letters)]):
            # the SQL as it runs, without the agent's comments in it
            try:
                sql = " ".join(strip_comments(str(r.get("sql") or "")).split())[:400]
            except ValueError:
                sql = ""
            rows = r.get("_count")
            lines.append(f"READING {letters[k]}: {r.get('label')}: {r.get('means') or ''}. "
                         f"Reads {r.get('table')}.{r.get('column')}. SQL: {sql}"
                         + (f" ({rows} rows)" if rows is not None else ""))
        lines.append("The readings give different results on the data.")
        kw = {"schema": WORDING_SCHEMA}
        if _passes(model, "num_predict"):
            kw["num_predict"] = WORDING_TOKENS
        if _passes(model, "timeout"):
            kw["timeout"] = WORDING_SECONDS
        self._say("checking", f"the wording of \"{phrase}\"")
        t0 = self.clock()
        with _step("agent.wording", as_type="guardrail", input={"phrase": phrase}) as traced:
            try:
                reply = model.json(prompts.AGENT_WORDING, "\n".join(lines), **kw)
            except Exception:
                reply = None
            try:
                traced.update(output=reply if isinstance(reply, dict) else None)
            except Exception:
                pass
        if self._trace_now is not None:
            self._trace_now["turns"].append({
                "kind": "wording", "phase": "wording", "think": False, "tool": None,
                "reply": reply if isinstance(reply, dict) else None,
                "seconds": round(self.clock() - t0, 3),
                "error": (getattr(model, "last_error", "") or None) if reply is None else None})
        if not isinstance(reply, dict) or reply.get("choose") is not False:
            return None
        # "B", "B)" or "Reading B"; anything else names no reading
        found = re.search(r"\b([A-D])\b", str(reply.get("reading") or "").upper())
        if not found or letters.index(found.group(1)) >= len(readings):
            return None
        return letters.index(found.group(1)), " ".join(str(reply.get("why") or "").split())

    def _rank(self, question, phrase, thing):
        """"ranking" when the phrase ranks or qualifies the things the
        database holds by a measure the question leaves open ("popular
        books"), "thing" when it names something that would have to be
        stored, None when the check could not tell.

        Asked of a model in a fresh context, with the question and the
        phrase alone, never the agent's notes nor its verdict; no thinking,
        within WORDING_SECONDS, at most MAX_RANK_CALLS times a question.
        Only for what the age words and the form of a ranking do not
        settle (review of 26 October, rule 3)."""
        if __package__:
            from . import prompts
        else:
            import prompts
        self._check_cancel()
        if getattr(self, "_rankings", 0) >= MAX_RANK_CALLS:
            return None
        self._rankings = getattr(self, "_rankings", 0) + 1
        model, _thinks = self._model_for("checking", None, force_off=True)
        lines = [f"QUESTION: {question}", f"PHRASE: \"{phrase}\"",
                 f"WHAT IT IS ABOUT: {thing}, which the database holds"]
        kw = {"schema": RANK_SCHEMA}
        if _passes(model, "num_predict"):
            kw["num_predict"] = WORDING_TOKENS
        if _passes(model, "timeout"):
            kw["timeout"] = WORDING_SECONDS
        self._say("checking", f"what \"{phrase}\" asks for")
        t0 = self.clock()
        with _step("agent.ranking", as_type="guardrail", input={"phrase": phrase}) as traced:
            try:
                reply = model.json(prompts.AGENT_RANKING, "\n".join(lines), **kw)
            except Exception:
                reply = None
            try:
                traced.update(output=reply if isinstance(reply, dict) else None)
            except Exception:
                pass
        if self._trace_now is not None:
            self._trace_now["turns"].append({
                "kind": "ranking", "phase": "ranking", "think": False, "tool": None,
                "reply": reply if isinstance(reply, dict) else None,
                "seconds": round(self.clock() - t0, 3),
                "error": (getattr(model, "last_error", "") or None) if reply is None else None})
        said = str(reply.get("is") or "").strip().lower() if isinstance(reply, dict) else ""
        return said if said in ("ranking", "thing") else None

    def _weigh(self, term, columns, question):
        """(verdict, why): can `term` be read off these columns' real
        values, "yes", "no" or "unknown". The old judge's measured question
        (Clarifier.decide_on_values), asked without thinking, within
        WORDING_SECONDS, at most MAX_WEIGH_CALLS times a question."""
        decide = getattr(self.clar, "decide_on_values", None)
        if decide is None:
            return "unknown", ""
        self._check_cancel()
        if self._weighings >= MAX_WEIGH_CALLS:
            return "unknown", ""
        self._weighings += 1
        model, _thinks = self._model_for("checking", None, force_off=True)
        kw = {}
        if _passes(model, "timeout"):
            kw["timeout"] = WORDING_SECONDS
        if _passes(model, "num_predict"):
            kw["num_predict"] = WEIGH_TOKENS
        self._say("checking", f"the values for \"{term}\"")
        t0 = self.clock()
        try:
            verdict, _t, _c, why = decide(term, columns, question, llm=model, **kw)
        except Exception as e:
            verdict, why = "unknown", f"{type(e).__name__}: {e}"[:160]
        if self._trace_now is not None:
            self._trace_now["turns"].append({
                "kind": "values", "phase": "values", "think": False, "tool": None,
                "reply": {"verdict": verdict, "why": why},
                "seconds": round(self.clock() - t0, 3), "error": None})
        return verdict, why

    @staticmethod
    def _valid_conclusion(c):
        return isinstance(c, dict) and c.get("verdict") in VERDICTS \
            and isinstance(c.get("issues", []), list)

    # ------------------------------------------------------ the probes
    def _neighbours(self, nb):
        """The tables one key away from the five first tables the search
        pointed at, in short form, when the search did not show them."""
        first = nb.steps[-1] if nb.steps else None
        data = getattr(getattr(first, "result", None), "data", None)
        rows = data.get("tables") if isinstance(data, dict) else data
        shown = [r.get("table") for r in rows or [] if isinstance(r, dict) and r.get("table")]
        near = []
        for t in shown[:5]:
            for e in (getattr(self.view, "edges", {}) or {}).get(t, []):
                if e.b not in shown and e.b not in near:
                    near.append(e.b)
        if not near:
            return
        short = getattr(self.view, "short", {}) or {}
        text = "\n".join(short.get(t, f"TABLE {t}") for t in near[:12])
        nb.record(Step(n=nb.next_n(), phase="probing", tool="neighbours",
                       args={"of": ", ".join(shown[:5])},
                       result=CodeResult(tool="neighbours", text=text, rows=len(near[:12]),
                                         digest=f"{len(near)} tables one key away: "
                                                + ", ".join(near[:12]))))

    def _probe(self, nb, tools, trace):
        """What the code looks up for the agent, after its reading and
        before it explores: each value named (is it stored, where, what
        else is stored there), each table it named and has not seen, the
        joins between them, and, when the question orders things by age
        ("oldest", "newest"), the dates of its first two tables. Bounded to the reading, not the whole
        database: exploring everything costs more than it finds. Stops
        when the question's time runs short."""
        r = nb.reading or {}
        done = 0
        tables, unknown = [], []
        for name in (r.get("tables") or [])[:6]:
            real = self.view.table(str(name))
            if real and real not in tables:
                tables.append(real)
            elif not real:
                unknown.append(str(name))
        if unknown:
            lines = []
            for name in unknown:
                try:
                    near = self.view.closest(name, 3)
                except Exception:
                    near = []
                lines.append(f"no table {name}" + (f"; closest: {', '.join(near)}" if near else ""))
            nb.record(Step(n=nb.next_n(), phase="probing", tool="names",
                           args={"tables": unknown},
                           result=CodeResult(tool="names", text="\n".join(lines),
                                             digest="; ".join(lines))))

        def room_left():
            return done < MAX_PROBES and self._left() > self._margin()

        for value in (r.get("values") or [])[:4]:
            if not room_left():
                break
            value = str(value or "").strip()
            if len(value) < 3:
                continue
            step = self._call_tool(nb, tools, "find_value",
                                   {"value": value, "tables": tables or None}, "probing", trace)
            done += 1
            hits = (getattr(step.result, "data", None) or {}).get("hits") \
                if getattr(step.result, "ok", False) else None
            if hits and room_left():
                h = hits[0]
                self._call_tool(nb, tools, "sample_values",
                                {"table": h.get("table"), "column": h.get("column"), "n": 20},
                                "probing", trace)
                done += 1
        unseen = [t for t in tables if t not in set(nb.described())][:4]
        if unseen and room_left():
            self._call_tool(nb, tools, "describe_tables", {"names": unseen}, "probing", trace)
            done += 1
        for b in tables[1:4]:
            if not room_left():
                break
            self._call_tool(nb, tools, "join_path", {"a": tables[0], "b": b}, "probing", trace)
            done += 1
        # "the oldest members": every date a thing has is a reading of its
        # age, and the agent saw one; the dates of the question's tables,
        # their ranges and gaps, are laid out before it concludes
        said = " ".join([str(nb.question or "")]
                        + [str(c) for c in r.get("comparisons") or []])
        if wording.ORDERED_BY_AGE.search(said):
            read = {str((s.args or {}).get("table") or "").lower()
                    for s in nb.steps if s.tool == "time_columns"}
            for t in tables[:2]:
                if not room_left():
                    break
                if t.lower() in read:
                    continue
                self._call_tool(nb, tools, "time_columns", {"table": t}, "probing", trace)
                done += 1
        # "the most reliable suppliers", "the busiest warehouses": every
        # column that could measure the comparison is a reading of it. Under
        # v6 the first one that fitted was taken and Warehouse Q09's choice
        # lost (review of 26 October); looked for on the question's tables
        # and those one key away, as the age words look at the dates
        near = list(tables)
        for t in tables[:2]:
            for e in (getattr(self.view, "edges", None) or {}).get(t, ()):
                if getattr(e, "b", None) and e.b not in near:
                    near.append(e.b)
        for comp in (r.get("comparisons") or [])[:2]:
            comp = str(comp or "").strip()
            if (not comp or re.search(r"\d", comp) or wording.ORDERED_BY_AGE.search(comp)
                    or wording.VAGUE_TIME.search(comp)):
                continue
            if not room_left():
                break
            self._call_tool(nb, tools, "find_columns",
                            {"phrase": comp, "tables": near[:6] or None}, "probing", trace)
            done += 1
        # a question in time ("last year", "recently", "on 1 March"): today,
        # the database's clock and how far its first table reaches, before
        # the agent counts a period from today
        question = str(nb.question or "")
        # "N/A" or "all time" is no period, and "between" alone ("the gap
        # between orders") is no time (review of 26 October)
        period = str(r.get("period") or "none").strip().lower()
        timed = (str(r.get("time") or "none") != "none"
                 or period not in NO_PERIOD
                 or any(m.group(0).strip().lower() not in ("between", "entre")
                        for m in wording.PERIOD.finditer(question))
                 or wording.VAGUE_TIME.search(question))
        if timed and room_left() and not any(s.tool == "clock" for s in nb.steps):
            self._call_tool(nb, tools, "clock", {"table": tables[0]} if tables else {},
                            "probing", trace)
            done += 1

    # ------------------------------------------------------- the tools
    def _do_call(self, nb, tools, call, trace):
        tool = str(call.get("tool") or "")
        args = call.get("args") if isinstance(call.get("args"), dict) else {}
        if tool == "more":
            return self._more(nb, tools, args, trace)
        return self._call_tool(nb, tools, tool, args, "exploring", trace)

    def _call_tool(self, nb, tools, tool, args, phase, trace):
        self._check_cancel()
        args = {k: v for k, v in (args or {}).items() if v not in (None, "", [])}
        size_only = args.get("mode") == "size"
        sent = {k: v for k, v in args.items() if k != "mode"}
        self._say(f"tool:{tool}", short_args(sent))
        t0 = self.clock()
        with _step(f"tool.{tool}", as_type="tool", input=sent) as traced:
            try:
                result = tools.run(tool, sent)
            except Exception as e:          # the toolbox must not raise; if it does, it is a step
                result = CodeResult(tool=tool, text="", ok=False,
                                    error=f"{type(e).__name__}: {e}", digest="error")
            try:
                traced.update(output={"ok": getattr(result, "ok", None),
                                      "digest": getattr(result, "digest", None)})
            except Exception:
                pass
        step = nb.record(Step(n=nb.next_n(), phase=phase, tool=tool, args=args,
                              result=result, seconds=round(self.clock() - t0, 3),
                              size_only=size_only))
        self._trace_step(trace, step)
        return step

    def _more(self, nb, tools, args, trace):
        """The next page of a result already read, with no new query; a
        value sweep that stopped early resumes where it stopped."""
        try:
            n = int(args.get("step"))
            src = nb.steps[n]
            cursor = max(0, int(args.get("cursor") or 0))
        except (TypeError, ValueError, IndexError):
            step = nb.record(Step(
                n=nb.next_n(), phase="exploring", tool="more", args=args,
                result=CodeResult(tool="more", text="", ok=False, digest="error",
                                  error="more needs the number of a step already read "
                                        "and a cursor it gave")))
            self._trace_step(trace, step)
            return step
        res = src.result
        if src.tool == "find_value" and getattr(res, "cursor", None) is not None:
            return self._call_tool(nb, tools, "find_value",
                                   dict(src.args, cursor=res.cursor), "exploring", trace)
        step = nb.record(Step(n=nb.next_n(), phase="exploring", tool="more",
                              args={"step": n, "cursor": cursor}, result=res, offset=cursor))
        self._trace_step(trace, step)
        return step

    @staticmethod
    def _trace_step(trace, step):
        trace["turns"].append({"kind": "tool", "n": step.n, "phase": step.phase,
                               "tool": step.tool,
                               "args": step.args, "digest": Budget.digest(step),
                               "seconds": step.seconds,
                               "error": getattr(step.result, "error", "") or None})

    # ------------------------------------------------------- one turn
    def _turn(self, nb, phase, schema, budget, turn, max_turns, trace, concluding=False,
              hurry=False):
        """One model reply for this phase, usable or an exception.

        An overflow is asked again with less to read and no thinking, never
        with a longer prompt. An unusable reply is asked again once, with
        what was wrong with it. An exploring call that runs out of time
        raises _OutOfTime, which leads to the conclusion; a conclusion that
        runs out of time is asked once more without thinking."""
        self._check_cancel()
        model, thinks = self._model_for(phase, budget, concluding, force_off=hurry)
        user, shown = budget.fit(nb, turn, max_turns, self._left(), thinks, concluding)
        error = None
        for _attempt in (1, 2):
            prompt = user if error is None else f"YOUR LAST REPLY COULD NOT BE USED: {error}\n\n{user}"
            reply, meta = self._ask(model, prompt, schema, budget, thinks, phase, trace)
            if meta.get("overflow"):
                model, thinks = self._model_for(phase, budget, concluding, force_off=True)
                user, shown = budget.fit(nb, turn, max_turns, self._left(), False, concluding,
                                         shrink=SHRINK_ON_OVERFLOW)
                reply, meta = self._ask(model, user, schema, budget, False, phase, trace)
                if meta.get("overflow"):
                    raise _Malformed(str(getattr(model, "last_error", "") or
                                         "the prompt did not fit the window"))
            if reply is None:
                err = str(getattr(model, "last_error", "") or "")
                if "timed out" in err.lower():
                    if not concluding:
                        raise _OutOfTime(err)
                    if thinks:
                        model, thinks = self._model_for(phase, budget, concluding,
                                                        force_off=True)
                        error = None
                        continue
                    raise _Malformed(err)
                try:
                    reachable = model.reachable()
                except Exception:
                    reachable = True
                if not reachable:
                    raise _Malformed(err or "the model server cannot be reached")
                error = err or "no JSON object came back"
                continue
            problem = self._problem(reply, schema)
            if problem is None:
                budget.learn(model, user, thinks)
                for s in shown:
                    s.shown = True
                return reply
            error = problem
        raise _Malformed(f"the model's reply could not be used twice: {error}")

    def _ask(self, model, user, schema, budget, thinks, phase, trace):
        t0 = self.clock()
        kw = {"schema": schema}
        prompt_tokens = budget.estimate(user)
        if _passes(model, "num_predict"):
            kw["num_predict"] = budget.num_predict(prompt_tokens, thinks)
        if _passes(model, "timeout"):
            # the question's time bounds every exploring call, its reserve
            # kept for the conclusion; the conclusion is given what it needs
            if phase in ("concluding", "formatting"):
                # twice the slowest call, never more than twice the floor:
                # past the question's time a slow GPU stretched it without
                # bound (review of 26 October)
                kw["timeout"] = int(max(CONCLUDE_FLOOR,
                                        min(2 * self._longest, 2 * CONCLUDE_FLOOR),
                                        self._left()))
            else:
                kw["timeout"] = int(max(MIN_CALL_SECONDS, self._left() - self._margin()))
        with _step("agent.turn", as_type="agent", input={"phase": phase}) as traced:
            reply = model.json(self.system, user, **kw)
            try:
                traced.update(output={"action": reply.get("action")
                                      if isinstance(reply, dict) else None})
            except Exception:
                pass
        took = self.clock() - t0
        if reply is not None:
            self._longest = max(self._longest, took)
        server = dict(getattr(model, "last_server", None) or {})
        meta = {"overflow": bool(server.get("overflow"))}
        said = reply if isinstance(reply, dict) else {}
        # each entry says what it is: a turn of the loop, a tool, or one
        # of the two short questions on the side (wording, values), which
        # were counted as turns, and a question was said over the cap
        # (review of 26 October)
        trace["turns"].append({
            "kind": "turn", "phase": phase, "think": thinks, "tool": None,
            # what the turn decided and what it said it did not know: the
            # prompt asks for the unknowns each turn, and nothing recorded
            # them (review of 26 October), so a v6 against v7 comparison
            # could not see where a choice was lost
            "action": said.get("action"),
            "unknowns": said.get("unknowns") if isinstance(said.get("unknowns"), list) else None,
            "prompt_tokens": getattr(model, "last_prompt_tokens", None) or prompt_tokens,
            "reply_tokens": server.get("reply_tokens"),
            "thinking_chars": server.get("thinking_chars"),
            "done_reason": server.get("done_reason"),
            "overflow": meta["overflow"],
            "seconds": round(self.clock() - t0, 3),
            "error": (getattr(model, "last_error", "") or None) if reply is None else None})
        return (reply if isinstance(reply, dict) else None), meta

    @staticmethod
    def _problem(reply, schema):
        """Why a reply cannot be used, or None."""
        if schema is CONCLUSION_SCHEMA:
            return None if isinstance(reply.get("conclusion"), dict) else "no conclusion object"
        if schema is FIRST_TURN_SCHEMA and not isinstance(reply.get("reading"), dict):
            return "the reading is missing"
        action = reply.get("action")
        if action not in ("call", "conclude"):
            return "action must be call or conclude"
        if action == "call":
            call = reply.get("call")
            if not isinstance(call, dict) or call.get("tool") not in AGENT_TOOLS:
                return f"the call must name one of the tools: {', '.join(AGENT_TOOLS)}"
            if call.get("args") is not None and not isinstance(call.get("args"), dict):
                return "the call's args must be an object"
        return None

    def _model_for(self, phase, budget, concluding=False, force_off=False):
        """The model for a phase: thinking only when the endpoint or the
        job lets it, the setting allows it for this phase, and the window
        leaves room for something besides the thinking. The per-phase
        setting can only take thinking away, never force it on a model the
        job switched off."""
        base = self.llm
        allowed = THINKING_PHASES.get(str(getattr(self.settings, "think", "all")),
                                      THINKING_PHASES["all"])
        try:
            can = bool(base.thinks())
        except Exception:
            can = False
        thinks = (can and phase in allowed and not force_off
                  and budget.can_think(concluding))
        # always a copy: the slot's own model keeps its own progress line,
        # so labels never stack up from one turn to the next
        if can and not thinks and hasattr(base, "thinking"):
            model = base.thinking(False)
        else:
            model = copy.copy(base)
        progress = getattr(base, "on_progress", None)
        if progress is not None:
            model.on_progress = lambda ph, said, _p=progress, _l=phase: _p(f"{_l} · {ph}", said)
        return model, thinks

    def _say(self, label, text):
        progress = getattr(self.llm, "on_progress", None)
        if progress is not None:
            try:
                progress(label, text)
            except Exception:
                pass

    def _check_cancel(self):
        ev = self.cancel_event
        if ev is not None and ev.is_set():
            raise AgentCancelled("the job was stopped")

    @staticmethod
    def _prompt_version():
        try:
            if __package__:
                from .prompts import version_of
            else:
                from prompts import version_of
            return version_of("agent")
        except Exception:
            return None


class VotingAgent(VerdictAgent):
    """The agent, with a vote when its first pass asks something of the
    asker (engine setting agent_arbiter = vote).

    A debate between a model and itself gains what a vote gains, and two
    runs of one agent share their blind spots; so the second and third
    passes are told a different strategy (values first, joins first), not
    a different temperature. The verdict is the majority; a tie goes to the
    verdict that asks more of the asker. The other answers stay cheap: an
    ANSWERABLE, a NOT COVERED or a NO DATA on the first pass is final."""

    def clarify(self, question):
        if __package__:
            from . import prompts
            from .coverage import classify
        else:
            import prompts
            from coverage import classify
        first = super().clarify(question)
        first_trace = self.last_trace
        verdict = classify(first)[0] if first is not None else "UNKNOWN"
        if verdict not in VOTED:
            return first
        base = self.system
        passes = [("default", first, first_trace, verdict)]
        try:
            for name, text in (("values", prompts.AGENT_STRATEGY_VALUES),
                               ("joins", prompts.AGENT_STRATEGY_JOINS)):
                self._system = base + "\n\n" + text
                out = super().clarify(question)
                passes.append((name, out, self.last_trace,
                               classify(out)[0] if out is not None else "UNKNOWN"))
        finally:
            self._system = base
        counts = {}
        for _n, _o, _t, v in passes:
            if v != "UNKNOWN":
                counts[v] = counts.get(v, 0) + 1
        if not counts:
            winner = verdict
        else:
            top = max(counts.values())
            winner = max((v for v, c in counts.items() if c == top),
                         key=lambda v: VOTE_SEVERITY.get(v, 0))
        chosen = next(p for p in passes if p[3] == winner)
        self.last_trace = dict(chosen[2] or {}, vote={
            "passes": [{"strategy": n, "verdict": v} for n, _o, _t, v in passes],
            "winner": winner, "from": chosen[0],
            "traces": [t for _n, _o, t, _v in passes]})
        return chosen[1]
