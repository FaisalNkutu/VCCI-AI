"""The pipeline as LangGraph nodes (langgraph_nodes): each node on a
pipeline whose model calls are stubbed, run through the pipeline's own
first step (Pipeline.prepare and Pipeline.judge_stage), so the nodes and
Datagora.ask cannot judge a question differently: the stop on a choice and
on any GUIDE, a choice coming back to readings no longer offered, the
context and the note on what was decided, the suggestions, every return of
every documented edge, the check, execute and answer nodes, the corpus
grown as Ask grows it, and the import in package mode. No model, no
database, no LangGraph."""

import os

os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

import pathlib
import subprocess
import sys
import unittest
from types import SimpleNamespace
from unittest.mock import patch

import ambisql
import langgraph_nodes as ln
import pipeline
import reformulate
from ambisql import Option, Outcome

CHOICE = Outcome(action="CLARIFY", phrase="active", kind="AmbiSchema", reason="r",
                 question='By "active", which do you mean?',
                 options=[Option(label="by status", means="status ACTIVE"),
                          Option(label="by date", means="no termination date")])
MORE = Outcome(action="GUIDE", phrase="cheap", kind="AmbiContext",
               reason="the price under which a product is cheap", question="What is cheap?")
ABSENT = Outcome(action="GUIDE", phrase="patents", kind="AmbiFallacy", checked=True,
                 reason="r", question="Nothing holds patents.")
CLEAR = Outcome(action="ANSWER", reason="clear")
SUGGESTED = [reformulate.Suggestion(question="Which products cost less than 10?")]


class Clar(ambisql.Clarifier):
    """A clarifier with no database: the per-question state it is told,
    a rewrite that says which option it took."""

    def __init__(self):
        self.last_shown = []
        self.seen = []

    def rewrite(self, question, out, option):
        return f"{question} [{option.label}]"


class Pipe(pipeline.Pipeline):
    """The real pipeline's steps, its model calls and the database stubbed."""

    def __init__(self, out, reformulates=True, context=None):
        self.out, self.calls = out, []
        self.judge, self.reformulate, self.context = "single", reformulates, context
        self.clarifier = Clar()
        self._agent, self._verdicts = None, {}
        # no graph: the answer node then remembers nothing, whatever
        # DATAGORA_REMEMBER says (the suite failed with it on)
        self._graph, self._driver = pipeline._EmptyGraph(), None
        self.profile = SimpleNamespace(name="Shop")
        self._sql_prompt = SimpleNamespace(text="SQL SYSTEM", version=1, source="test")
        self.sql_llm = SimpleNamespace(chat=self.chat)
        self.sent = []

    def _clarify(self, question, again=False, choice=None):
        self.calls.append((question, again))
        self.clarifier.seen.append((self.clarifier.context, self.clarifier.earlier))
        return self.out

    def chat(self, system, user):
        self.sent.append((system, user))
        return "SELECT 1"

    def anchors(self, question):
        return ["products"], "model"

    def subschema(self, tables):
        return list(tables)

    def imposed_joins(self, sub):
        return []

    def examples_for(self, question):
        return [{"question": "How many products?", "sql": "SELECT COUNT(*) FROM products",
                 "source": "pairs", "score": 0.9}]

    def prompt_for_sql(self, question, tables, joins, correction=None, examples=()):
        return f"{self.clarifier.context}|{question}|{len(examples)} examples"

    def check(self, sql, con):
        return ("the join audit rejected it", ["dialect"]) if "bad" in sql \
            else (None, ["dialect", "EXPLAIN"])

    def execute(self, sql, con):
        return ["n"], [[3]], 3

    def say(self, question, columns, rows, total=None):
        self.said = (question, total)
        return "Three."


def nodes(out, **kw):
    pipe = Pipe(out, **kw)
    con = SimpleNamespace(close=lambda: None)
    dg = SimpleNamespace(pipeline=pipe, profile=SimpleNamespace(connect_mysql=lambda: con))
    return ln.nodes_for(dg), pipe


class ClarifyNodeTests(unittest.TestCase):

    def run_clarify(self, out, state=None, **kw):
        n, pipe = nodes(out, **kw)
        with patch.object(pipeline, "suggest", return_value=SUGGESTED), \
                patch.object(pipeline, "headline", return_value="What does cheap mean for you?"):
            got = n["clarify"](dict({"question": "Which products are cheap?"}, **(state or {})))
        return got, pipe

    def test_a_needs_more_stops_with_its_suggestions(self):
        got, _ = self.run_clarify(MORE)
        self.assertEqual(got["technical_question"], "")
        self.assertEqual(ln.should_clarify(got), "ask_user")
        self.assertEqual(got["suggestions"][0]["question"], "Which products cost less than 10?")
        self.assertEqual(got["clarifying"], "What does cheap mean for you?")

    def test_the_switch_off_gives_none_and_a_refusal_never_any(self):
        got, _ = self.run_clarify(MORE, reformulates=False)
        self.assertEqual((got["suggestions"], ln.should_clarify(got)), ([], "ask_user"))
        got, _ = self.run_clarify(ABSENT)
        self.assertEqual((got["suggestions"], ln.should_clarify(got)), ([], "ask_user"))

    def test_a_choice_stops_and_the_picked_suggestion_answers_it(self):
        got, _ = self.run_clarify(CHOICE)
        self.assertEqual(ln.should_clarify(got), "ask_user")
        got, pipe = self.run_clarify(CHOICE, {"choice": "by status",
                                              "suggestion": "How many employees with an active status?"})
        self.assertEqual(got["technical_question"], "How many employees with an active status?")
        self.assertEqual(pipe.calls, [])                    # no second clarify
        self.assertEqual(ln.should_clarify(got), "continue")

    def test_a_choice_without_suggestion_reads_the_kept_verdict_and_rewrites(self):
        got, pipe = self.run_clarify(CHOICE, {"choice": "by date"})
        self.assertEqual(pipe.calls, [("Which products are cheap?", True)])
        self.assertEqual(got["technical_question"], "Which products are cheap? [by date]")

    def test_a_reading_no_longer_offered_is_never_answered_in_its_name(self):
        # review of 26 October: the node answered the first option
        got, _ = self.run_clarify(CHOICE, {"choice": "by login"})
        self.assertEqual(got["technical_question"], "")
        self.assertEqual(ln.should_clarify(got), "ask_user")

    def test_a_choice_coming_back_to_a_guide_stops(self):
        # review of 26 October: the node went on to generate
        got, _ = self.run_clarify(MORE, {"choice": "by status"})
        self.assertEqual(ln.should_clarify(got), "ask_user")

    def test_an_error_gives_up(self):
        got, _ = self.run_clarify(Outcome(action="ERROR", reason="timed out"))
        self.assertEqual((got["error"], ln.should_clarify(got)), ("timed out", "give_up"))

    def test_a_clear_question_carries_on(self):
        got, _ = self.run_clarify(CLEAR)
        self.assertEqual(ln.should_clarify(got), "continue")
        self.assertEqual(got["technical_question"], "Which products are cheap?")

    def test_the_judge_is_told_who_asks_and_what_was_decided(self):
        # review of 26 October: the nodes never told the clarifier, which
        # kept another question's context on the thread
        got, pipe = self.run_clarify(CLEAR, {"context": {"date": "2025-01-02"},
                                             "earlier": "The asker first asked: 'cheap?'."},
                                     context={"location": "Montreal"})
        context, earlier = pipe.clarifier.seen[-1]
        self.assertIn("2 January 2025", context)
        self.assertIn("Location: Montreal", context)     # the client's, under the question's
        self.assertEqual(earlier, "The asker first asked: 'cheap?'.")
        self.assertEqual(got["context"]["date"], "2025-01-02")
        # the next question on the thread starts clean
        got, pipe2 = self.run_clarify(CLEAR)
        self.assertEqual(pipe2.clarifier.seen[-1][1], "")

    def test_the_note_comes_back_and_a_choice_is_judged_with_it(self):
        # review of 26 October (Ask 20): the note out of the node was never read
        note = "The asker first asked: 'cheap?'."
        got, _ = self.run_clarify(CHOICE, {"earlier": note})
        self.assertEqual((got["earlier"], ln.should_clarify(got)), (note, "ask_user"))
        back, pipe = self.run_clarify(CHOICE, {"choice": "by date", "earlier": got["earlier"]})
        self.assertEqual(pipe.clarifier.seen[-1][1], note)
        self.assertEqual(back["earlier"], note)
        self.assertEqual(back["technical_question"], "Which products are cheap? [by date]")


class LaterNodesTests(unittest.TestCase):

    def test_anchors_give_up_with_no_table_and_carry_the_examples(self):
        n, pipe = nodes(CLEAR)
        got = n["anchors"]({"question": "q?", "technical_question": "q?"})
        self.assertEqual((got["tables"], got["anchor_source"], len(got["examples"])),
                         (["products"], "model", 1))
        self.assertEqual(ln.after_anchors(got), "continue")
        self.assertEqual(ln.after_anchors({"error": "no table"}), "give_up")

    def test_generate_uses_the_pipeline_s_prompt_examples_and_context(self):
        n, pipe = nodes(CLEAR)
        n["generate"]({"question": "q?", "technical_question": "q?", "tables": ["products"],
                       "examples": [{"question": "x", "sql": "y"}],
                       "context": {"date": "2025-01-02"}})
        system, user = pipe.sent[-1]
        self.assertEqual(system, "SQL SYSTEM")
        self.assertIn("2 January 2025", user)
        self.assertIn("1 examples", user)

    def test_check_reads_the_correction_of_the_pair(self):
        n, _ = nodes(CLEAR)
        self.assertEqual(n["check"]({"sql": "SELECT 1"}), {"verdict": ""})
        self.assertEqual(n["check"]({"sql": "bad"}), {"verdict": "the join audit rejected it"})
        self.assertEqual(ln.after_check({"verdict": ""}), "run")

    def test_execute_keeps_the_true_count_and_answer_says_it(self):
        n, pipe = nodes(CLEAR)
        got = n["execute"]({"sql": "SELECT 1"})
        self.assertEqual(got, {"columns": ["n"], "rows": [[3]], "total_rows": 3, "verdict": ""})
        self.assertEqual(ln.after_execute(got), "answer")
        n["answer"]({"question": "q?", "technical_question": "precise q?", **got})
        self.assertEqual(pipe.said, ("precise q?", 3))

    def test_a_refusal_at_execution_is_retried_and_a_silent_answer_is_an_error(self):
        self.assertEqual(ln.after_execute({"verdict": "MariaDB refused it", "attempts": 1}),
                         "retry")
        n, pipe = nodes(CLEAR)

        def silent(*a, **kw):
            raise RuntimeError("the reasoner returned nothing")
        pipe.say = silent
        got = n["answer"]({"question": "q?", "rows": [[1]], "columns": ["n"]})
        self.assertIn("the answer step failed", got["error"])

    def test_answer_remembers_only_rows_a_model_named_over_verified_joins(self):
        # as Pipeline._remember (review of 26 October): never an empty
        # result, never what the corpus gave, never joins no graph verified
        def answered(graph=True, **state):
            n, pipe = nodes(CLEAR)
            kept = []
            pipe._recall = SimpleNamespace(remember=lambda q, t, s: kept.append((q, t, s)))
            with patch.object(pipeline.Pipeline, "has_graph", graph), \
                    patch.dict("os.environ", {"DATAGORA_REMEMBER": "on"}):
                n["answer"](dict({"question": "q?", "technical_question": "precise q?",
                                  "tables": ["products"], "sql": "SELECT 1",
                                  "anchor_source": "model", "columns": ["n"], "rows": [[3]]},
                                 **state))
            return kept
        self.assertEqual(answered(), [("precise q?", ["products"], "SELECT 1")])
        for graph, state in ((False, {}), (True, {"anchor_source": "corpus"}), (True, {"rows": []})):
            with self.subTest(graph=graph, state=state):
                self.assertEqual(answered(graph, **state), [])

    def test_every_return_of_every_edge_is_wired_as_documented(self):
        # review of 26 October (Ask 20): some returns were never routed in a
        # test, and the wiring an application copies was never read
        import re
        returns = {
            "should_clarify": {ln.should_clarify(s) for s in (
                {"error": "down"}, {"technical_question": ""}, {"technical_question": "q?"})},
            "after_anchors": {ln.after_anchors(s) for s in ({"error": "no table"}, {})},
            "after_check": {ln.after_check(s) for s in (
                {"verdict": ""}, {"verdict": "rejected", "attempts": 1},
                {"verdict": "rejected", "attempts": pipeline.MAX_ATTEMPTS})},
            "after_execute": {ln.after_execute(s) for s in (
                {"verdict": ""}, {"verdict": "MariaDB refused it", "attempts": 1},
                {"verdict": "MariaDB refused it", "attempts": pipeline.MAX_ATTEMPTS})}}
        self.assertEqual(returns, {"should_clarify": {"ask_user", "continue", "give_up"},
                                   "after_anchors": {"continue", "give_up"},
                                   "after_check": {"run", "retry", "give_up"},
                                   "after_execute": {"answer", "retry", "give_up"}})
        guide = (pathlib.Path(__file__).resolve().parent / "INTEGRATION.md").read_text(
            encoding="utf-8")
        for where, text in (("langgraph_nodes", ln.__doc__), ("INTEGRATION.md", guide)):
            wired = {edge: set(re.findall(r'"(\w+)":', keys)) for edge, keys in re.findall(
                r'add_conditional_edges\("\w+",\s*(\w+),\s*\{([^}]*)\}', text)}
            with self.subTest(where=where):
                self.assertEqual(wired, returns)


class PackageModeTests(unittest.TestCase):

    def test_the_nodes_import_as_an_application_imports_them(self):
        code = "\n".join(["from graph_lab.langgraph_nodes import (nodes_for, should_clarify,",
                          "    after_anchors, after_check, after_execute)",
                          "print('ok')"])
        src = pathlib.Path(__file__).resolve().parents[1]
        env = dict(os.environ, DATAGORA_TRACING="off", DATAGORA_DOTENV="off")
        done = subprocess.run([sys.executable, "-c", code], cwd=src, env=env,
                              capture_output=True, text=True, timeout=120)
        self.assertEqual(done.returncode, 0, done.stderr[-800:])


if __name__ == "__main__":
    unittest.main()
