"""The unattended queue of the 8092 test instance
(docs/test_strategy/coverage_bench/queue_8092.py), offline: engine
settings per run, written into the test copy only, and a restart only
when they change. No Docker, no server."""

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

BENCH = Path(__file__).resolve().parents[2] / "docs" / "test_strategy" / "coverage_bench"
if str(BENCH) not in sys.path:
    sys.path.append(str(BENCH))

import queue_8092 as q  # noqa: E402


class EngineSettingsTests(unittest.TestCase):

    def test_settings_after_the_questions_file(self):
        self.assertEqual(q.engine_settings("agent_think=plan_conclude, agent_max_seconds=600"),
                         {"agent_think": "plan_conclude", "agent_max_seconds": "600"})
        self.assertEqual(q.engine_settings(""), {})
        self.assertEqual(q.engine_settings("agent_arbiter="), {"agent_arbiter": ""})
        with self.assertRaises(SystemExit):
            q.engine_settings("=x")

    def settings_file(self, d, engine):
        path = Path(d) / "datagora.json"
        path.write_text(json.dumps({"engine": engine, "endpoints": [1]}), encoding="utf-8")
        return path

    def test_new_settings_are_written_and_the_test_container_restarted(self):
        with tempfile.TemporaryDirectory() as d:
            path = self.settings_file(d, {"enumeration": 12})
            with patch.object(q.subprocess, "run") as run, \
                    patch.object(q, "live", return_value=[]):
                self.assertTrue(q.apply_engine("http://x", {"agent_think": "plan_conclude"},
                                               settings=path))
            data = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(data["engine"], {"enumeration": 12, "agent_think": "plan_conclude"})
            self.assertEqual(data["endpoints"], [1])
            self.assertEqual(run.call_args[0][0], ["docker", "restart", "datagora-ui-test"])
            self.assertTrue((Path(d) / "datagora.json.before_queue").exists())

    def test_settings_already_there_restart_nothing(self):
        with tempfile.TemporaryDirectory() as d:
            path = self.settings_file(d, {"agent_think": "plan_conclude"})
            with patch.object(q.subprocess, "run") as run:
                self.assertFalse(q.apply_engine("http://x", {"agent_think": "plan_conclude"},
                                                settings=path))
            run.assert_not_called()

    def test_thinking_goes_on_the_job_and_the_rest_on_the_engine(self):
        job, engine = q.job_options({"think": "off", "agent_think": "plan_conclude"})
        self.assertEqual(job, {"think": False})
        self.assertEqual(engine, {"agent_think": "plan_conclude"})
        self.assertEqual(q.job_options({"think": ""}), ({}, {}))
        with self.assertRaises(SystemExit):
            q.job_options({"think": "maybe"})

    def test_a_resumed_run_is_not_fresh(self):
        self.assertEqual(q.job_options({"resume": "on", "think": "on"}),
                         ({"fresh": False, "think": True}, {}))
        self.assertEqual(q.job_options({"resume": "off"}), ({"fresh": True}, {}))

    def test_engine_settings_are_refused_for_the_production_instance(self):
        with self.assertRaises(SystemExit):
            q.check_engine_target("http://127.0.0.1:8080", {"agent_think": "none"})
        q.check_engine_target("http://127.0.0.1:8080", {})
        q.check_engine_target("http://127.0.0.1:8092", {"agent_think": "none"})

    def test_the_production_settings_are_never_the_target(self):
        self.assertEqual(q.SETTINGS.parent.name, "data_8092")
        self.assertEqual(q.CONTAINER, "datagora-ui-test")

    def test_the_test_instance_is_known_by_host_and_port(self):
        # review of 26 October: ":8092" as a substring let ":80920" through
        self.assertTrue(q.is_test_instance("http://127.0.0.1:8092"))
        self.assertTrue(q.is_test_instance("http://localhost:8092/"))
        for base in ("http://127.0.0.1:80920", "http://10.0.0.5:8092", "http://127.0.0.1:8080"):
            self.assertFalse(q.is_test_instance(base), base)
            with self.assertRaises(SystemExit):
                q.check_engine_target(base, {"agent_think": "none"})

    def test_a_windows_path_keeps_its_drive(self):
        self.assertEqual(q.parse_spec("a=agent:Library:C:/runs/q.csv:think=on"),
                         ("a", "agent", "Library", "C:/runs/q.csv", "think=on"))
        self.assertEqual(q.parse_spec("a=single:Library:q.csv"),
                         ("a", "single", "Library", "q.csv", ""))

    def test_an_instance_that_never_answers_stops_the_queue(self):
        # it looped for ever on the 8092 instance once it was gone
        with patch.object(q, "live", side_effect=OSError("refused")), \
                patch.object(q.time, "sleep"):
            with self.assertRaises(SystemExit) as e:
                q.wait_idle("http://127.0.0.1:8092", every=0)
        self.assertIn("no Datagora instance answers", str(e.exception))

    def test_rebuild_is_refused_for_any_other_instance(self):
        with self.assertRaises(SystemExit) as e:
            q.main(["--rebuild", "a=agent:Library:q.csv"])
        self.assertIn("8092 test instance only", str(e.exception))


if __name__ == "__main__":
    unittest.main()
