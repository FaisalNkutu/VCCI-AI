"""Questions the asker can pick, instead of a menu of columns.

No database and no model: a scripted model answers from a script and
records what it was sent, and a stub clarifier holds a small catalogue and
the values of a few columns. What is checked is what the page will show:
one question per reading for a choice, values read from the data for a
NEEDS MORE, nothing for NOT COVERED and NO DATA, and a template wherever
the model's text names a column or brings a number nobody gave."""

import os

# the column index is on by default; a test never builds one in a real
# Qdrant, and the tests that need one give it directly
os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

import datetime
import pathlib
import re
import sys
import unittest
from unittest.mock import patch

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import prompts
import reformulate as rf
from ambisql import Clarifier, Option, Outcome

TODAY = datetime.date(2026, 10, 20)


class Scripted:
    """A model that answers from a script and records every call.

    `reply` is a dict, or a function of the user message; `fail` makes the
    call raise as an unreachable host does. `thinking` records what it was
    asked and returns the same object, so the calls stay readable."""

    model = "scripted"

    def __init__(self, reply=None, fail=False):
        self.reply = reply
        self.fail = fail
        self.calls = []
        self.thought = None

    def thinking(self, on):
        self.thought = on
        return self

    def reachable(self):
        return not self.fail

    def json(self, system, user, schema=None, num_predict=None, timeout=None):
        self.calls.append({"system": system, "user": user, "schema": schema,
                           "num_predict": num_predict, "timeout": timeout})
        if self.fail:
            raise ConnectionError("the host did not answer")
        return self.reply(user) if callable(self.reply) else self.reply

    def chat(self, system, user, **_):
        self.calls.append({"system": system, "user": user, "chat": True})
        return "a sentence"


class FakeCursor:
    def __init__(self, con):
        self.con = con
        self.row = None

    def execute(self, sql, params=None):
        self.con.executed.append(sql)
        m = re.search(r"FROM `(\w+)`", sql)
        c = re.search(r"\(`(\w+)`\)", sql)
        key = (m.group(1), c.group(1)) if m and c else None
        if key not in self.con.rows:
            raise RuntimeError("no such column")
        self.row = self.con.rows[key]

    def fetchone(self):
        return self.row

    def close(self):
        pass


class FakeConnection:
    def __init__(self, rows):
        self.rows = rows
        self.executed = []

    def cursor(self):
        return FakeCursor(self)

    def close(self):
        pass


class Stub:
    """The little of a Clarifier that suggestions read, and what the
    pipeline tells it for one question: who asks and when, and what was
    decided before, through the Clarifier's own for_question, for this
    thread only. clarify() records what it was told."""

    for_question = Clarifier.for_question
    _asked = Clarifier._asked
    context, earlier = Clarifier.context, Clarifier.earlier
    today, now = Clarifier.today, Clarifier.now

    columns = {
        "employees": [("employee_id", "int"), ("status_code", "varchar"),
                      ("termination_date", "date"), ("department_id", "int"),
                      ("name", "varchar")],
        "departments": [("department_id", "int"), ("name", "varchar")],
        "products": [("product_id", "int"), ("price", "decimal"),
                     ("name", "varchar"), ("qty", "int")],
        "sales": [("sale_id", "int"), ("sold_at", "datetime"),
                  ("product_id", "int")],
    }
    PRICES = [1.2, 3.5, 4, 8, 9.9, 12, 19, 24, 30, 55, 80, 120, 2300]

    def __init__(self, llm=None, outcome=None, aggregates=None):
        self.llm = llm
        self.outcome = outcome
        self.last_reply = None
        self.clarified = 0
        self.rewritten = 0
        self.con = FakeConnection(aggregates or {})
        self.values = {("products", "price"): list(self.PRICES)}
        self.told = []

    def _distinct_values_checked(self, table, column, limit=None):
        return list(self.values.get((table, column), [])), True

    def connect(self):
        return self.con

    def clarify(self, question):
        self.clarified += 1
        self.told.append({"question": question, "context": self.context,
                          "earlier": self.earlier, "today": self.today})
        return self.outcome

    def rewrite(self, question, clarification, option):
        self.rewritten += 1
        return f"REWRITTEN: {question} as {option.label}"


def active_employees():
    return Outcome(
        action="CLARIFY", phrase="active employees", kind="AmbiSchema",
        question='By "active employees", which do you mean?',
        options=[Option(label="employees.status_code",
                        means="employees with status_code = 'ACTIVE'",
                        table="employees", column="status_code"),
                 Option(label="employees.termination_date",
                        means="employees with termination_date IS NULL",
                        table="employees", column="termination_date")])


def cheap():
    return Outcome(action="GUIDE", phrase="cheap", kind="AmbiContext",
                   reason="The term 'cheap' needs a threshold on products.price.",
                   question='"cheap" needs a threshold: what counts as cheap here?')


def recently():
    return Outcome(action="GUIDE", phrase="recently", kind="AmbiContext",
                   reason="A relative period, read off sales.sold_at.",
                   question='"recently" needs a threshold')


ASKED_ACTIVE = "How many active employees work in each department?"
PLAIN_ACTIVE = {"suggestions": [
    {"id": "1", "question": "How many employees with an active status work in each department?",
     "note": "Counts employees whose recorded status is active."},
    {"id": "2", "question": "How many employees who have not left the company work in each department?",
     "note": "Counts everyone with no leaving date."}]}


def proposals(user):
    """The PROPOSAL lines of a message, as {id: what it proposes}."""
    return dict(re.findall(r"^PROPOSAL (\d+): (.+)$", user, re.M))


def cost_less_than(user):
    """A model that words each proposal as an everyday question, naming
    the measure as the prompt asks."""
    return {"suggestions": [
        {"id": i, "question": f"Which products have a price under {said.split()[-1]}?", "note": ""}
        for i, said in proposals(user).items()]}


class ChoiceTests(unittest.TestCase):

    def test_a_choice_gives_one_question_per_option_with_its_label(self):
        model = Scripted(PLAIN_ACTIVE)
        out = rf.suggest(Stub(model), ASKED_ACTIVE, active_employees())
        self.assertEqual([s.choice for s in out],
                         ["employees.status_code", "employees.termination_date"])
        self.assertEqual(out[0].question, PLAIN_ACTIVE["suggestions"][0]["question"])
        self.assertEqual(out[1].note, "Counts everyone with no leaving date.")
        self.assertFalse(any(s.blank for s in out))
        # the readings went to the model in words, never as columns
        user = model.calls[0]["user"]
        self.assertIn("READING 1:", user)
        self.assertIn("READING 2:", user)
        self.assertNotIn("status_code", user)

    def test_the_model_is_asked_once_without_thinking_and_bounded(self):
        model = Scripted(PLAIN_ACTIVE)
        rf.suggest(Stub(model), ASKED_ACTIVE, active_employees())
        self.assertEqual(len(model.calls), 1)
        call = model.calls[0]
        self.assertIs(model.thought, False)
        self.assertIs(call["system"], prompts.REFORMULATE_SYSTEM)
        self.assertEqual(call["num_predict"], rf.REPLY_TOKENS)
        self.assertEqual(call["timeout"], rf.SECONDS)
        ids = call["schema"]["properties"]["suggestions"]["items"]["properties"]["id"]["enum"]
        self.assertEqual(ids, ["1", "2"])

    def test_a_question_naming_a_column_is_replaced_by_its_template(self):
        leaky = {"suggestions": [
            {"id": "1", "question": "How many employees with status_code ACTIVE work in each department?",
             "note": ""},
            PLAIN_ACTIVE["suggestions"][1]]}
        out = rf.suggest(Stub(Scripted(leaky)), ASKED_ACTIVE, active_employees())
        # the first falls back to the template built from its meaning, the
        # second, which is plain, stays as the model wrote it
        self.assertNotIn("_", out[0].question)
        self.assertIn("status code is active", out[0].question)
        self.assertEqual(out[0].choice, "employees.status_code")
        self.assertEqual(out[1].question, PLAIN_ACTIVE["suggestions"][1]["question"])
        for s in out:
            self.assertEqual(rf.offending(s.question, Stub(), ASKED_ACTIVE), "")

    def test_a_question_far_longer_than_the_one_asked_is_refused(self):
        # live, E34: two readings pasted into one suggestion of 188
        # characters, for a question of 117
        long = {"suggestions": [
            {"id": "1", "question": "How many employees with an active status, read off the status "
                                    "code that records whether they are active today, work in each "
                                    "department of the company?", "note": ""},
            PLAIN_ACTIVE["suggestions"][1]]}
        out = rf.suggest(Stub(Scripted(long)), ASKED_ACTIVE, active_employees())
        self.assertIn("taking \"active employees\" to mean", out[0].question)
        self.assertEqual(out[1].question, PLAIN_ACTIVE["suggestions"][1]["question"])

    def test_the_question_given_back_or_a_pasted_label_is_refused(self):
        # live, E60: the original question given back for one reading; E65:
        # "claimed on day claimed (the claim date)"
        back = {"suggestions": [
            {"id": "1", "question": ASKED_ACTIVE, "note": ""},
            {"id": "2", "question": "How many employees (the termination date) work in each department?",
             "note": ""}]}
        out = rf.suggest(Stub(Scripted(back)), ASKED_ACTIVE, active_employees())
        self.assertTrue(all("taking" in s.question for s in out), [s.question for s in out])

    def test_a_number_the_asker_gave_is_never_dropped(self):
        # live, E66: "in January 2026" replaced by a reading of "change"
        q = "How many active employees work in each department in 2026?"
        drops = {"suggestions": [
            {"id": "1", "question": "How many employees with an active status work in each department?",
             "note": ""},
            {"id": "2", "question": "How many employees who have not left work in each department in 2026?",
             "note": ""}]}
        out = rf.suggest(Stub(Scripted(drops)), q, active_employees())
        self.assertIn("taking", out[0].question)
        self.assertIn("2026", out[0].question)
        self.assertEqual(out[1].question, drops["suggestions"][1]["question"])

    def test_an_option_found_by_its_name_is_said_by_what_it_holds(self):
        # live, E60: four readings each "the column '...' points at (token)"
        echoes = Outcome(action="CLARIFY", phrase="end of their trip", kind="AmbiSchema",
                         question='By "end of their trip", which do you mean?',
                         options=[Option(label="employees.termination_date",
                                         means='the column "end of their trip" points at (token)',
                                         table="employees", column="termination_date"),
                                  Option(label="sales.sold_at",
                                         means='the column "end of their trip" points at (token)',
                                         table="sales", column="sold_at")])
        clar = Stub(None)
        clar.means = lambda t, c: "Date the employee left." if c == "termination_date" else ""
        out = rf.suggest(clar, "How long after the end of their trip?", echoes)
        self.assertEqual([s.question for s in out], [
            'How long after the end of their trip, taking "end of their trip" to mean date the employee left?',
            'How long after the end of their trip, taking "end of their trip" to mean the sold at of sales?'])

    def test_two_options_given_the_same_question_keep_it_once(self):
        same = {"suggestions": [dict(PLAIN_ACTIVE["suggestions"][0], id="1"),
                                dict(PLAIN_ACTIVE["suggestions"][0], id="2")]}
        out = rf.suggest(Stub(Scripted(same)), ASKED_ACTIVE, active_employees())
        self.assertNotEqual(out[0].question, out[1].question)

    def test_a_failing_model_gives_the_templates(self):
        for model in (Scripted(fail=True), Scripted(None), Scripted("not json"), None):
            with self.subTest(model=model):
                out = rf.suggest(Stub(model), ASKED_ACTIVE, active_employees())
                self.assertEqual(len(out), 2)
                self.assertTrue(all(s.question.endswith("?") for s in out))
                self.assertIn("termination date is empty", out[1].question)

    def test_an_unconfigured_model_gives_the_templates(self):
        # a missing models.json says so with SystemExit, three frames down
        class NoModel(Stub):
            @property
            def llm(self):
                raise SystemExit("no models.json")

            @llm.setter
            def llm(self, value):
                pass

        out = rf.suggest(NoModel(), ASKED_ACTIVE, active_employees())
        self.assertEqual(len(out), 2)

    def test_the_headline_is_in_the_asker_s_words(self):
        self.assertEqual(rf.headline(ASKED_ACTIVE, active_employees(), Stub()),
                         'By "active employees", which do you mean?')

    def test_readings_of_stored_values_each_give_a_question_that_reads_well(self):
        # review of 26 October (Ask 20): the value templates were tested one
        # by one, never through suggest(). There the template naming the
        # stored value is refused as a code and said in words, which wrote
        # it in lower case: "how many active employees, with the status
        # code active?"
        values = Outcome(action="CLARIFY", phrase="active", kind="AmbiValue",
                         question='By "active", which do you mean?',
                         options=[Option(label="employees.status_code = ACTIVE", means="",
                                         value="ACTIVE", table="employees", column="status_code"),
                                  Option(label="employees.status_code = ACTIVE_PENDING", means="",
                                         value="ACTIVE_PENDING", table="employees",
                                         column="status_code")])
        q = "How many active employees?"
        for model in (None, Scripted(fail=True)):
            with self.subTest(model=model):
                out = rf.suggest(Stub(model), q, values)
                self.assertEqual([s.question for s in out],
                                 ["How many active employees, with the status code active?",
                                  "How many active pending employees?"])
                self.assertEqual([s.choice for s in out], [o.label for o in values.options])
                for s in out:
                    self.assertEqual(rf.offending(s.question, Stub(), q), "")


def values_only(*a, **kw):
    """The proposals with a value, the editable question set aside: it
    comes first since 23 October, and these tests are about the values."""
    return [s for s in rf.suggest(*a, **kw) if not s.blank]


class NeedsMoreTests(unittest.TestCase):

    def stub(self, model=None, **kw):
        clar = Stub(model, **kw)
        clar.last_reply = {"phrase": "cheap",
                           "candidates": [{"table": "products", "column": "price"}]}
        return clar

    def test_a_threshold_is_proposed_from_the_column_s_values(self):
        model = Scripted(cost_less_than)
        out = values_only(self.stub(model), "Which products are cheap?", cheap())
        # the quartiles of the prices, rounded: 8 -> 7.5, 19 -> 20, 55 -> 50
        self.assertEqual(proposals(model.calls[0]["user"]),
                         {"1": "below 7.5", "2": "below 20", "3": "below 50"})
        self.assertEqual([s.question for s in out],
                         ["Which products have a price under 7.5?",
                          "Which products have a price under 20?",
                          "Which products have a price under 50?"])
        self.assertTrue(all(s.choice is None for s in out))
        self.assertIn("from 1.2 to 2300", out[0].note)
        self.assertLessEqual(len(out), rf.MAX_MORE)

    def test_the_range_comes_from_a_bounded_query_when_the_database_answers(self):
        clar = self.stub(aggregates={("products", "price"): (0.5, 9999)})
        out = rf.suggest(clar, "Which products are cheap?", cheap())
        self.assertIn("from 0.5 to 9999", out[0].note)
        self.assertTrue(all("max_statement_time" in sql or "MAX_EXECUTION_TIME" in sql
                            for sql in clar.con.executed))

    def test_what_the_records_do_not_keep_is_said_and_never_left_to_fill(self):
        # E65, 23 October: "[time of expense]" was offered to type in
        out = Outcome(action="GUIDE", phrase="spent in the evening, after 6 pm",
                      kind="AmbiContext", reason="r", missing="time of expense", gap="data")
        q = "How many of the expenses claimed in 2025 were spent in the evening, after 6 pm?"
        got = rf.suggest(Stub(None), q, out)
        self.assertEqual([s.question for s in got], ["How many of the expenses claimed in 2025?"])
        self.assertFalse(any(s.blank for s in got))
        said = rf.headline(q, out, Stub(None))
        self.assertIn("The data does not record the time of expense", said)
        self.assertIn("would have to be added to the database", said)
        # a value the asker holds keeps its blank
        asked = out.model_copy(update={"gap": "asker", "missing": "the tariff increase"})
        self.assertTrue(any(s.blank for s in rf.suggest(Stub(None), q, asked)))

    def test_the_blank_keeps_the_preposition_of_the_open_words(self):
        # E26, 23 October: "have been [the tariff increase percentage]"
        out = Outcome(action="GUIDE", phrase="with the tariff increase the carriers announced",
                      kind="AmbiSource", reason="r", missing="the tariff increase percentage")
        q = ("What would our 2025 freight spend per carrier have been with the tariff "
             "increase the carriers announced?")
        got = rf.suggest(Stub(None), q, out)
        self.assertEqual(got[-1].question, "What would our 2025 freight spend per carrier have "
                                           "been with [the tariff increase percentage]?")

    def test_a_point_in_time_not_kept_proposes_the_current_value(self):
        # E42, 23 October: only a blank was offered
        out = Outcome(action="GUIDE", phrase="on 1 March 2025", kind="AmbiContext",
                      reason="only the current priority is stored",
                      missing="the priority on 1 March 2025")
        q = "What was the priority of support ticket T40623 on 1 March 2025?"
        got = rf.suggest(Stub(None), q, out)
        self.assertEqual([s.question for s in got],
                         ["What is the current priority of support ticket T40623?"])
        self.assertFalse(got[0].blank)
        self.assertEqual(rf.headline(q, out, Stub(None)),
                         "The data keeps only the current value, not the one on 1 March 2025.")

    def test_the_blank_names_what_the_judge_says_is_missing(self):
        # E34, 23 October
        out = Outcome(action="GUIDE", phrase="budget exchange rate finance has set for 2027",
                      kind="AmbiSource", reason="r",
                      missing="the 2027 budget exchange rates")
        q = ("How much will the purchase orders still open cost us in euros at the budget "
             "exchange rate finance has set for 2027?")
        got = rf.suggest(Stub(None), q, out)
        self.assertEqual(got[-1].question,
                         "How much will the purchase orders still open cost us in euros at the "
                         "[2027 budget exchange rates]?")
        self.assertTrue(got[-1].blank)
        self.assertEqual(rf.headline(q, out, Stub(None)),
                         "To answer, I need the 2027 budget exchange rates.")
        bare = out.model_copy(update={"missing": "office coordinates"})
        self.assertEqual(rf.headline(q, bare, Stub(None)),
                         "To answer, I need the office coordinates.")

    def test_without_a_model_the_templates_replace_the_vague_word(self):
        out = rf.suggest(self.stub(None), "Which products are cheap?", cheap())
        # the question to edit first, then the data's values below it
        self.assertEqual(out[0].question, "Which products have a price below [value]?")
        self.assertTrue(out[0].blank)
        self.assertIn("from 1.2 to 2300", out[0].note)
        self.assertEqual(out[1].question, "Which products have a price below 7.5?")
        self.assertTrue(all("cheap" not in s.question for s in out))

    def test_a_number_the_model_invents_is_refused(self):
        def invents(user):
            return {"suggestions": [{"id": i, "question": "Which products have a price under 3?",
                                     "note": ""} for i in proposals(user)]}

        out = values_only(self.stub(Scripted(invents)), "Which products are cheap?", cheap())
        self.assertEqual(out[0].question, "Which products have a price below 7.5?")

    def test_a_value_question_must_name_what_it_compares(self):
        # live, gemma3:4b: "Which books cost less than 100?" was judged NEEDS
        # MORE again (nothing is called "cost"), "Which books have a price
        # below 100?" answerable. Without the measure's name, the template.
        def cost(user):
            return {"suggestions": [
                {"id": i, "question": f"Which products cost less than {said.split()[-1]}?", "note": ""}
                for i, said in proposals(user).items()]}

        out = values_only(self.stub(Scripted(cost)), "Which products are cheap?", cheap())
        self.assertEqual(out[0].question, "Which products have a price below 7.5?")

    def test_the_whole_question_is_never_shown_as_the_open_words(self):
        # live: the phrase came back as the whole question, and the judge
        # quoted the word that mattered ("cost")
        whole = Outcome(action="GUIDE", phrase="Which books cost less than 100?", kind="AmbiSchema",
                        question='Nothing in this schema is named or described as "cost", which '
                                 '"Which books cost less than 100?" needs. Which column holds it?')
        q = "Which books cost less than 100?"
        self.assertEqual(rf.headline(q, whole, Stub()),
                         'To answer, I need to know more about what "cost" means.')
        out = rf.suggest(Stub(None), q, whole)
        self.assertNotIn('"Which books', out[0].question)
        # and the quoted word wins over a phrase that only contains it
        part = whole.model_copy(update={"phrase": "cost less than 100"})
        self.assertEqual(rf.headline(q, part, Stub()),
                         'To answer, I need to know more about what "cost" means.')

    def test_the_model_s_candidates_are_offered_when_the_outcome_has_none(self):
        # live: "How many loans are still open?" came back NEEDS MORE with no
        # option and loans.returned_at among the candidates; a blank alone
        # was offered
        still_open = Outcome(action="GUIDE", phrase="open loans", kind="AmbiSchema",
                             question='Nothing in this schema is named or described as "open", '
                                      'which "open loans" needs. Which column holds it?')
        clar = Stub(Scripted({"suggestions": [
            {"id": "1", "question": "How many loans have not been returned yet?", "note": ""}]}))
        clar.columns = dict(Stub.columns, loans=[("loan_id", "int"), ("returned_at", "datetime"),
                                                 ("member_id", "int")])
        clar.last_reply = {"phrase": "open loans", "candidates": [
            {"table": "loans", "column": "returned_at", "means": "when the loan was returned"},
            {"table": "loans", "column": "member_id", "means": "who borrowed"}]}
        out = rf.suggest(clar, "How many loans are still open?", still_open)
        self.assertEqual([s.question for s in out], ["How many loans have not been returned yet?"])
        self.assertIn("PROPOSAL 1: when the loan was returned (the returned at)",
                      clar.llm.calls[0]["user"])
        # the dictionary's meaning goes to the model before the model's own:
        # live, "when a loan is currently active" gave a question judged
        # NEEDS MORE again
        clar.means = lambda t, c: ("Date the book came back, empty while it is out."
                                   if c == "returned_at" else "")
        clar.llm.calls.clear()
        rf.suggest(clar, "How many loans are still open?", still_open)
        self.assertIn("empty while it is out", clar.llm.calls[0]["user"])
        self.assertNotIn("when the loan was returned", clar.llm.calls[0]["user"])
        # a candidate kept for another phrase is not used
        clar.last_reply = dict(clar.last_reply, phrase="something else")
        self.assertTrue(rf.suggest(clar, "How many loans are still open?", still_open)[0].blank)

    def test_the_asker_s_spelling_and_no_definition_of_an_identifier(self):
        # live, E43: the judge quoted "so100667" for SO100667, and the
        # template read 'taking "so100667" to mean when'
        order = Outcome(action="GUIDE", phrase="status did sales order SO100667 have",
                        kind="AmbiSchema",
                        question='Nothing in this schema is named or described as "so100667", '
                                 'which "status did sales order SO100667 have" needs.')
        clar = Stub(None)
        clar.columns = dict(Stub.columns, sales_order_status_history=[
            ("history_id", "int"), ("status_code", "varchar"), ("changed_at", "datetime")])
        clar.last_reply = {"phrase": order.phrase, "candidates": [
            {"table": "sales_order_status_history", "column": "status_code", "means": "status"},
            {"table": "sales_order_status_history", "column": "changed_at", "means": "when"}]}
        q = "What status did sales order SO100667 have on 1 June 2024?"
        self.assertEqual(rf.headline(q, order, clar),
                         'To answer, I need to know more about what "SO100667" means.')
        out = rf.suggest(clar, q, order)
        self.assertEqual([s.question for s in out], [
            "What status did sales order SO100667 have on 1 June 2024, going by the status code?",
            "What status did sales order SO100667 have on 1 June 2024, going by the changed at?"])

    def test_only_the_candidates_about_the_open_words_are_offered(self):
        # live, E46: segment_id for "Gold customers", offered beside the order
        # date and the status the model had proposed for other filters
        gold = Outcome(action="GUIDE", phrase="orders from Gold customers", kind="AmbiSchema",
                       question='Nothing in this database is named, described or recorded as '
                                '"gold". Which column holds it?')
        clar = Stub(None)
        clar.columns = dict(Stub.columns, customers=[("customer_id", "int"), ("segment_code", "varchar")],
                            sales_orders=[("order_id", "int"), ("order_date", "date"),
                                          ("status_code", "varchar")])
        clar.last_reply = {"phrase": gold.phrase, "candidates": [
            {"table": "customers", "column": "segment_code", "means": "Gold customer"},
            {"table": "sales_orders", "column": "order_date", "means": "filter for 2025 orders"},
            {"table": "sales_orders", "column": "status_code", "means": "exclude cancelled orders"}]}
        q = "What was the net amount of orders from Gold customers in 2025?"
        out = rf.suggest(clar, q, gold)
        self.assertEqual(len(out), 1)
        self.assertIn("segment code", out[0].question)

    def test_a_suggestion_asked_again_brings_no_vague_word(self):
        # live, Library Q08: "How many loans have an empty date the book came
        # back?" was judged NEEDS MORE again, on "empty"
        still_open = Outcome(action="GUIDE", phrase="open loans", kind="AmbiSchema",
                             question='Nothing in this schema is named or described as "open".')
        clar = Stub(Scripted({"suggestions": [
            {"id": "1", "question": "How many loans have an empty return date?", "note": ""}]}))
        clar.columns = dict(Stub.columns, loans=[("loan_id", "int"), ("returned_at", "datetime")])
        clar.means = lambda t, c: "Date the book came back, empty while it is out."
        clar.last_reply = {"phrase": "open loans", "candidates": [
            {"table": "loans", "column": "returned_at", "means": "when it came back"}]}
        out = values_only(clar, "How many loans are still open?", still_open)
        self.assertEqual(out[0].question, "How many loans are still open, going by the returned at?")
        # nor may a threshold question keep the word it settles
        keeps = {"suggestions": [{"id": i, "question": "Which cheap products have a price under 20?",
                                  "note": ""} for i in ("1", "2", "3")]}
        clar = self.stub(Scripted(keeps))
        self.assertEqual(values_only(clar, "Which products are cheap?", cheap())[0].question,
                         "Which products have a price below 7.5?")

    def test_an_outside_value_is_replaced_and_dropped(self):
        coffee = Outcome(action="GUIDE", phrase="a coffee", kind="AmbiContext",
                         reason="The schema has products.price, not the price of a coffee.",
                         question='"a coffee" needs to be said more precisely.')
        question = "Which products are cheaper than a coffee?"
        out = values_only(Stub(None), question, coffee)
        self.assertEqual(out[0].question, "Which products have a price below 7.5?")
        self.assertTrue(all("coffee" not in s.question for s in out))
        self.assertEqual(rf.headline(question, coffee, Stub()),
                         'To answer, I need a value for "a coffee": the data does not hold one.')

    def test_the_measure_is_found_in_the_named_table_when_no_column_was_named(self):
        # live, Warehouse Q15: no column anywhere in the outcome, the
        # model's candidates about "a coffee"; a blank alone was offered
        coffee = Outcome(action="GUIDE", phrase="a coffee", kind="AmbiContext",
                         question='"a coffee" needs to be said more precisely.')
        out = values_only(Stub(None), "Which products are cheaper than a coffee?", coffee)
        self.assertEqual(out[0].question, "Which products have a price below 7.5?")
        # nothing is guessed in a table the question does not name
        out = rf.suggest(Stub(None), "Which gadgets are cheaper than a coffee?", coffee)
        self.assertTrue(out[0].blank)
        self.assertEqual(out[0].question, "Which gadgets are cheaper than [amount]?")

    def test_a_note_about_the_data_comes_from_the_data_not_the_model(self):
        # live, Warehouse Q15: the model noted 100 was "the lowest price in
        # the data", on prices from 1.10 to 499.80
        def claims(user):
            return {"suggestions": [
                {"id": i, "question": f"Which products have a price under {said.split()[-1]}?",
                 "note": "Compares the price to the lowest price in the data."}
                for i, said in proposals(user).items()]}

        out = values_only(self.stub(Scripted(claims)), "Which products are cheap?", cheap())
        self.assertEqual(out[0].question, "Which products have a price under 7.5?")
        self.assertEqual([s.note for s in out],
                         ["In the data, the price goes from 1.2 to 2300.", "", ""])

    def test_a_value_at_the_edge_of_the_data_is_never_proposed(self):
        # live, Warehouse Q13: "above 500" on a column whose largest value
        # is 500, which matches nothing
        clar = Stub(None)
        clar.columns = dict(Stub.columns, warehouses=[("warehouse_id", "int"), ("fill_level", "int")])
        clar.values[("warehouses", "fill_level")] = [0, 50, 100, 200, 300, 400, 450, 480, 500]
        full = Outcome(action="GUIDE", phrase="nearly full", kind="AmbiContext",
                       reason="A threshold on warehouses.fill_level.", question='"nearly full" needs a threshold')
        out = values_only(clar, "Which warehouses are nearly full?", full)
        values = [float(re.findall(r"above ([\d.]+)", s.question)[0]) for s in out]
        self.assertTrue(values)
        self.assertTrue(all(0 < v < 500 for v in values), values)

    def test_a_relative_period_is_anchored_on_the_data_and_on_today(self):
        clar = Stub(None, aggregates={("sales", "sold_at"): (datetime.datetime(2026, 6, 30, 17, 5),)})
        out = rf.suggest(clar, "How many products did we sell recently?", recently(), today=TODAY)
        questions = [s.question for s in out]
        # the data stops in June, so the period it can answer comes first
        self.assertEqual(questions[0], "How many products did we sell in the 30 days up to 30 June 2026?")
        self.assertIn("How many products did we sell in the last 30 days?", questions)
        self.assertIn("30 June 2026", out[0].note)
        self.assertIn("20 October 2026", out[1].note)

    def test_nothing_concrete_gives_a_blank_rather_than_a_value(self):
        unknown = Outcome(action="GUIDE", phrase="unpaid fines", kind="AmbiSchema",
                          question="Nothing in this schema is named unpaid fines.")
        model = Scripted(cost_less_than)
        out = rf.suggest(Stub(model), "Which members have unpaid fines?", unknown)
        self.assertEqual(len(out), 1)
        self.assertTrue(out[0].blank)
        self.assertIn("[", out[0].question)
        self.assertEqual(model.calls, [])          # nothing to word, nothing asked

    def test_not_covered_no_data_and_answers_get_nothing(self):
        model = Scripted(cost_less_than)
        for outcome in (Outcome(action="GUIDE", phrase="gluten", checked=True, question="no"),
                        Outcome(action="GUIDE", phrase="Shakespeare", empty=True, question="none"),
                        Outcome(action="ANSWER"),
                        Outcome(action="ERROR", reason="down"),
                        Outcome(action="CLARIFY", phrase="x")):
            with self.subTest(outcome=outcome.action):
                self.assertEqual(rf.suggest(Stub(model), "Which products are gluten free?", outcome), [])
                self.assertEqual(rf.headline("Which products?", outcome, Stub()), "")
        self.assertEqual(model.calls, [])

    def test_a_period_only_when_the_open_words_are_about_time(self):
        # live, E36: judged on "revenue", the question also saying "last
        # year"; it was offered periods for "revenue"
        revenue = Outcome(action="GUIDE", phrase="revenue last year", kind="AmbiSchema",
                          question='Nothing in this schema is named or described as "revenue", '
                                   'which "revenue last year" needs. Which column holds it?')
        q = "What was our revenue last year?"
        self.assertEqual(rf.gap(Stub(), q, revenue), "other")
        self.assertEqual(rf.headline(q, revenue, Stub()),
                         'To answer, I need to know more about what "revenue" means.')
        # judged on the time words, it is a period, and they are replaced
        last_year = Outcome(action="GUIDE", phrase="last year", kind="AmbiContext",
                            question='"last year" needs a threshold')
        out = rf.suggest(Stub(None), q, last_year, today=TODAY)
        self.assertEqual(rf.gap(Stub(), q, last_year), "period")
        self.assertEqual(out[0].question, "What was our revenue in 2025?")

    def test_a_gap_in_the_data_comes_before_the_comparison_and_the_period(self):
        # review of 26 October: "later than the close of business" with no
        # time of day recorded was offered a blank the data can never fill
        no_time = Outcome(action="GUIDE", phrase="later than the close of business",
                          kind="AmbiContext", gap="data",
                          missing="the time of day of each sale")
        self.assertEqual(rf.gap(Stub(), "Which products sold later than the close of business?",
                                no_time), "data")
        self.assertEqual(rf.gap(Stub(), "Which products sold recently, after hours?",
                                Outcome(action="GUIDE", phrase="after hours", kind="AmbiContext",
                                        gap="data", missing="the time of day")), "data")

    def test_a_gap_in_the_data_on_a_comparison_offers_the_question_without_it(self):
        # review of 26 October (Ask 20): the gap was classified, never offered.
        # The judge quoting "close of business" without its article left
        # "later than the", and "Which products sold later than?" was offered
        q = "Which products sold later than the close of business?"
        for phrase in ("later than the close of business", "the close of business",
                       "close of business"):
            with self.subTest(phrase=phrase):
                out = Outcome(action="GUIDE", phrase=phrase, kind="AmbiContext", gap="data",
                              missing="the time of day of each sale")
                got = rf.suggest(Stub(None), q, out)
                self.assertEqual([s.question for s in got], ["Which products sold?"])
                self.assertFalse(any(s.blank for s in got))
                self.assertIn("The data does not record the time of day of each sale",
                              rf.headline(q, out, Stub(None)))
        # a comparison on the asker's own number stays: only the gap goes
        six = Outcome(action="GUIDE", phrase="after 6 pm", kind="AmbiContext", gap="data",
                      missing="the time of day")
        got = rf.suggest(Stub(None), "Which products sold more than 500 units after 6 pm?", six)
        self.assertEqual([s.question for s in got], ["Which products sold more than 500 units?"])

    def test_a_missing_value_with_a_number_is_no_period(self):
        # review of 26 October: "the 2027 budget figures" was offered periods
        budget = Outcome(action="GUIDE", phrase="", kind="AmbiContext", gap="asker",
                         missing="the 2027 budget figures")
        self.assertNotEqual(rf.gap(Stub(), "What is the budget for next year?", budget), "period")

    def test_review_of_the_fixes_suggestions_name_their_column_and_end_well(self):
        # the caller gives no label: the column says which value is meant
        said = rf._choice_template("How many active employees?", "active",
                                   Option(label="employees.status_code", means="ACTIVE",
                                          value="ACTIVE", table="employees",
                                          column="status_code"), "active")
        self.assertEqual(said, "How many active employees, with the status code ACTIVE?")
        # a dangling comparison is never left behind
        self.assertEqual(rf._without("Which products sold later than the close of business?",
                                     "the close of business"), "Which products sold?")

    def test_a_template_never_gives_the_question_back(self):
        # review of 26 October: ACTIVE read as "active" gave the question
        # itself, which picked, went to the SQL as ambiguous as it came
        q = "How many active employees?"
        for value in ("ACTIVE", "Active"):
            said = rf._choice_template(q, "active", Option(label="employees.status",
                                                           means=value, value=value),
                                       "active", "status")
            self.assertNotEqual(said.lower(), q.lower())
            self.assertIn(value, said)
        # and a comparison keeps its sentence
        self.assertEqual(rf._with_value("Which products cost more than my rent?",
                                        "more than my rent", "price", "above", 20),
                         "Which products cost more than 20, by price?")

    def test_the_headline_says_what_is_missing(self):
        self.assertEqual(rf.headline("Which products are cheap?", cheap(), Stub()),
                         'To answer, I need to know what "cheap" means for you.')
        self.assertEqual(rf.headline("How many products did we sell recently?", recently(), Stub()),
                         'To answer, I need to know which period "recently" covers for you.')


class AskReviewTests(unittest.TestCase):
    """The independent review of the Ask journey, 23 October: each test is
    the scenario that failed, as the asker would have read it."""

    def test_as_of_takes_the_whole_date_and_proposes_the_current_value(self):
        out = Outcome(action="GUIDE", phrase="as of 1 March 2025", kind="AmbiContext",
                      reason="r", missing="the past values", gap="data")
        q = "What was each supplier's rating as of 1 March 2025?"
        self.assertEqual([s.question for s in rf.suggest(Stub(None), q, out)],
                         ["What is each supplier's rating now?"])
        self.assertIn("not the one as of 1 March 2025", rf.headline(q, out, Stub(None)))

    def test_a_time_issue_with_no_phrase_still_proposes_the_current_value(self):
        out = Outcome(action="GUIDE", phrase="", kind="AmbiRef", reason="r",
                      missing="the past values (only the current one is kept)", gap="data")
        q = "What was the priority of support ticket T40623 on 1 March 2025?"
        self.assertEqual([s.question for s in rf.suggest(Stub(None), q, out)],
                         ["What is the current priority of support ticket T40623?"])

    def test_the_headline_never_shows_a_column_and_reads_as_a_sentence(self):
        q = "How many expenses were filed after 6 pm?"
        leak = Outcome(action="GUIDE", phrase="after 6 pm", kind="AmbiContext", reason="r",
                       missing="the time of day: only the day is recorded for expense_lines.expense_date",
                       gap="data")
        said = rf.headline(q, leak, Stub(None))
        self.assertNotIn("expense_lines", said)
        self.assertIn("The data does not record what this asks", said)
        clause = Outcome(action="GUIDE", phrase="2027", kind="AmbiSource", reason="r",
                         missing="what the 2027 rates are")
        self.assertEqual(rf.headline("Cost at the 2027 rates?", clause, Stub(None)),
                         "To answer, I need to know what the 2027 rates are.")
        caps = clause.model_copy(update={"missing": "The budget for 2027"})
        self.assertEqual(rf.headline("Cost at the 2027 rates?", caps, Stub(None)),
                         "To answer, I need the budget for 2027.")

    def test_a_period_never_doubles_its_preposition(self):
        for q in ("Which products sold best in the last year?",
                  "How many sales were made in the past week?"):
            for s in rf.suggest(Stub(None), q, recently().model_copy(update={"phrase": ""})):
                self.assertNotRegex(s.question, r"\bin the in\b|\bin in\b", q)

    def test_this_year_and_this_month_are_the_ones_going_on(self):
        today = datetime.date(2026, 10, 23)
        out = recently().model_copy(update={"phrase": "this year"})
        texts = [s.question for s in rf.suggest(Stub(None), "How many sales this year?", out,
                                                today=today)]
        self.assertTrue(any("2026" in t for t in texts), texts)
        self.assertFalse(any("2025" in t for t in texts), texts)
        out = recently().model_copy(update={"phrase": "this month"})
        texts = [s.question for s in rf.suggest(Stub(None), "How many sales this month?", out,
                                                today=today)]
        self.assertTrue(any("October 2026" in t for t in texts), texts)

    def test_the_blank_is_the_threshold_not_the_asker_s_number(self):
        out = rf.suggest(Stub(None), "Which of the 3 products are cheap?", cheap())
        blank = next(s for s in out if s.blank)
        self.assertIn("3 products", blank.question)
        self.assertIn("[value]", blank.question)

    def test_cost_less_than_a_coffee_is_a_comparison(self):
        self.assertTrue(rf._THAN.search("Which products cost less than a coffee?"))
        self.assertFalse(rf._THAN.search("Which customers have more than one pet?"))

    def test_without_never_leaves_a_broken_question(self):
        self.assertIsNone(rf._without("At what time of day are most sales made?",
                                      "what time of day"))
        self.assertIsNone(rf._without("Which customers have more than 500 loyalty points?",
                                      "loyalty points"))
        self.assertEqual(rf._without("How many sales are made in each store in the evening?",
                                     "in the evening"),
                         "How many sales are made in each store?")
        # E34 live, 23 October: "...cost us in euros at the?"
        self.assertEqual(rf._without(
            "How much will the purchase orders still open cost us in euros at the budget "
            "exchange rate finance has set for 2027?",
            "budget exchange rate finance has set for 2027"),
            "How much will the purchase orders still open cost us in euros?")

    def test_a_stored_code_is_never_the_meaning_shown(self):
        opt = Option(label="customers.tier = GLD_PLUS", means="", table="customers",
                     column="tier", value="GLD_PLUS")
        self.assertEqual(rf._plain_option(Stub(None), opt, Stub.columns), "gld plus")

    def test_two_readings_worded_alike_never_give_the_same_button(self):
        out = Outcome(action="CLARIFY", phrase="active employees", kind="AmbiSchema",
                      question="q", options=[
                          Option(label="employees.status_code", means="status ACTIVE",
                                 table="employees", column="status_code"),
                          Option(label="contracts.status_code", means="status ACTIVE",
                                 table="employees", column="status_code")])
        texts = [s.question for s in rf.suggest(Stub(None), ASKED_ACTIVE, out)]
        self.assertEqual(len(texts), len(set(t.lower() for t in texts)), texts)


class PlainTests(unittest.TestCase):

    def test_underscores_codes_symbols_and_sql_are_refused(self):
        stub = Stub()
        for text in ("How many employees with status_code set?",
                     "How many employees where status = 'ACTIVE'?",
                     "Which employees.name are active?",
                     "SELECT the employees WHERE they are active?",
                     "How many employees have status \"ACTIVE\"?",
                     "Which products have the highest qty?"):
            with self.subTest(text=text):
                self.assertNotEqual(rf.offending(text, stub, "How many active employees?"), "")

    def test_a_code_is_refused_even_without_quotes(self):
        # live, E34: "in the SPOT exchange rate", a stored value
        stub = Stub()
        self.assertEqual(rf.offending("How much at the SPOT exchange rate?", stub,
                                      "How much at the budget rate?"), "SPOT")
        # an acronym the asker typed is theirs
        self.assertEqual(rf.offending("How much in EUR per carrier?", stub,
                                      "How much in EUR per carrier last year?"), "")

    def test_everyday_words_that_are_also_names_are_allowed(self):
        stub = Stub()
        for text in ("How many employees with an active status work in each department?",
                     "Which products have a price below 10?",
                     "Where do our employees work?"):
            with self.subTest(text=text):
                self.assertEqual(rf.offending(text, stub, "How many active employees?"), "")
        # an abbreviation the asker typed is theirs
        self.assertEqual(rf.offending("Total qty per product?", stub, "total qty per product"), "")


class SwitchAndPromptTests(unittest.TestCase):

    def test_the_prompt_is_registered_with_its_fingerprint(self):
        entry = prompts.VERSIONS["reformulate"]
        self.assertEqual(entry["text"], "REFORMULATE_SYSTEM")
        self.assertEqual(prompts.fingerprint(prompts.REFORMULATE_SYSTEM), entry["sha"])
        self.assertEqual(prompts.name_of(prompts.REFORMULATE_SYSTEM), "reformulate v2")
        self.assertNotIn("unregistered", prompts.version_of("reformulate"))

    def test_the_switch_reads_the_environment_only_when_not_forced(self):
        with patch.dict("os.environ", {rf.ENV: ""}):
            self.assertTrue(rf.enabled())              # on by default
        for off in ("off", "0", "false", "False", "no"):
            with self.subTest(off=off), patch.dict("os.environ", {rf.ENV: off}):
                self.assertFalse(rf.enabled())
                self.assertTrue(rf.enabled(True))
        with patch.dict("os.environ", {rf.ENV: "on"}):
            self.assertTrue(rf.enabled())
            self.assertFalse(rf.enabled(False))


# ------------------------------------------------------------ the pipeline

class FakeProfile:
    name = "stub"
    schema = "stub"

    def connect_neo4j(self):
        raise RuntimeError("no graph here")

    def connect_mysql(self):
        raise AssertionError("the database is not reached in these tests")


def pipeline_with(outcome, model=None, reformulate=True):
    """A pipeline whose clarifier is the stub, stopped before the anchors:
    the single judge, which the stub stands for (the agent is the default
    since 1.2.0)."""
    import pipeline
    model = model or Scripted(PLAIN_ACTIVE)
    pipe = pipeline.Pipeline(FakeProfile(), reasoner=model, sql_llm=Scripted(),
                             reformulate=reformulate, judge="single")
    pipe.clarifier = Stub(model, outcome)
    pipe.anchors = lambda question: ([], "model")
    return pipe


class PipelineTests(unittest.TestCase):

    def test_a_choice_stops_with_a_question_for_each_option(self):
        pipe = pipeline_with(active_employees())
        run = pipe.ask(ASKED_ACTIVE)
        self.assertEqual(run.clarifying, 'By "active employees", which do you mean?')
        self.assertEqual([s["choice"] for s in run.suggestions],
                         ["employees.status_code", "employees.termination_date"])
        self.assertEqual(run.suggestions[0]["question"],
                         PLAIN_ACTIVE["suggestions"][0]["question"])
        self.assertIn("suggest", [s.name for s in run.steps])
        self.assertEqual(run.answer, "")

    def test_a_picked_suggestion_is_answered_without_clarifying_again(self):
        pipe = pipeline_with(active_employees())
        picked = PLAIN_ACTIVE["suggestions"][1]["question"]
        run = pipe.ask(ASKED_ACTIVE, choice="employees.termination_date",
                       suggestion=picked)
        self.assertEqual(pipe.clarifier.clarified, 0)
        self.assertEqual(pipe.clarifier.rewritten, 0)
        self.assertEqual(run.technical_question, picked)
        self.assertIsNone(run.clarification)
        self.assertEqual(run.suggestions, [])

    def test_a_choice_without_a_suggestion_is_rewritten_as_before(self):
        pipe = pipeline_with(active_employees())
        run = pipe.ask(ASKED_ACTIVE, choice="employees.status_code")
        self.assertEqual(pipe.clarifier.clarified, 1)
        self.assertEqual(pipe.clarifier.rewritten, 1)
        self.assertTrue(run.technical_question.startswith("REWRITTEN:"))

    def test_needs_more_stops_with_suggestions_and_not_covered_without(self):
        pipe = pipeline_with(cheap(), model=Scripted(cost_less_than))
        pipe.clarifier.last_reply = {"phrase": "cheap",
                                     "candidates": [{"table": "products", "column": "price"}]}
        run = pipe.ask("Which products are cheap?")
        # the question to edit first, then three values from the data
        self.assertEqual(len(run.suggestions), 4)
        self.assertTrue(run.suggestions[0]["blank"])
        self.assertTrue(all(s["choice"] is None for s in run.suggestions))
        self.assertEqual(run.clarifying, 'To answer, I need to know what "cheap" means for you.')

        absent = Outcome(action="GUIDE", phrase="gluten", checked=True,
                         question='"gluten" has no equivalent in this database.')
        model = Scripted(cost_less_than)
        run = pipeline_with(absent, model=model).ask("Which products are gluten free?")
        self.assertEqual((run.suggestions, run.clarifying), ([], ""))
        self.assertEqual(model.calls, [])

    def test_a_needs_more_suggestion_is_asked_as_a_new_question(self):
        # picked, it comes back as the question itself, without a choice,
        # and is clarified like any other; still vague, it gets new ones
        pipe = pipeline_with(cheap(), model=Scripted(cost_less_than))
        run = pipe.ask("Which products cost less than 20?",
                       suggestion="Which products cost less than 20?")
        self.assertEqual(pipe.clarifier.clarified, 1)
        self.assertEqual(run.question, "Which products cost less than 20?")

    def test_the_switch_off_makes_no_model_call_and_no_suggestion(self):
        model = Scripted(PLAIN_ACTIVE)
        run = pipeline_with(active_employees(), model, reformulate=False).ask(ASKED_ACTIVE)
        self.assertEqual((run.suggestions, run.clarifying), ([], ""))
        self.assertEqual(model.calls, [])
        self.assertNotIn("suggest", [s.name for s in run.steps])

    def test_the_environment_decides_when_the_argument_is_none(self):
        for value, made in (("off", False), ("on", True), ("", True)):
            with self.subTest(value=value), patch.dict("os.environ", {rf.ENV: value}):
                model = Scripted(PLAIN_ACTIVE)
                pipe = pipeline_with(active_employees(), model, reformulate=None)
                self.assertEqual(bool(pipe.ask(ASKED_ACTIVE).suggestions), made)
                self.assertEqual(len(model.calls), 1 if made else 0)
        # forced, the environment is not read
        with patch.dict("os.environ", {rf.ENV: "off"}):
            self.assertTrue(pipeline_with(active_employees(), reformulate=True)
                            .ask(ASKED_ACTIVE).suggestions)

    def test_a_failing_suggestion_never_costs_the_clarification(self):
        pipe = pipeline_with(active_employees())
        with patch("pipeline.suggest", side_effect=RuntimeError("boom")):
            run = pipe.ask(ASKED_ACTIVE)
        self.assertEqual(run.suggestions, [])
        self.assertEqual(run.clarification.action, "CLARIFY")

    def test_the_clarifier_is_told_for_this_question_only(self):
        # review of 26 October (Ask 20): the stub had no for_question, so
        # only the fallback that sets attributes for every thread ran
        import threading
        pipe = pipeline_with(active_employees())
        pipe.context = {"location": "Montreal"}                    # the client's
        pipe.ask(ASKED_ACTIVE, context={"date": "2025-01-02"})
        told = pipe.clarifier.told[-1]
        # the question's own date over the client's facts
        self.assertIn("2 January 2025", told["context"])
        self.assertIn("Location: Montreal", told["context"])
        self.assertEqual((told["earlier"], told["today"]), ("", datetime.date(2025, 1, 2)))
        # on this thread: nothing set for every thread, nothing seen on another
        self.assertFalse({"context", "earlier", "today", "_context", "_earlier"}
                         & set(vars(pipe.clarifier)))
        seen = []
        other = threading.Thread(target=lambda: seen.append(
            (pipe.clarifier.context, pipe.clarifier.earlier, pipe.clarifier.today)))
        other.start()
        other.join()
        self.assertEqual(seen, [("", "", None)])

    def test_a_question_s_own_date_over_the_client_s_dates_its_suggestions(self):
        pipe = pipeline_with(recently(), model=Scripted(None))
        pipe.context = {"location": "Montreal", "date": "2026-10-20"}
        run = pipe.ask("How many products did we sell recently?", context={"date": "2025-01-02"})
        self.assertEqual((run.context["date"], run.context["location"]), ("2025-01-02", "Montreal"))
        self.assertTrue(run.suggestions)
        self.assertTrue(all("2 January 2025" in s["note"] for s in run.suggestions),
                        run.suggestions)

    def test_a_choice_on_a_follow_up_is_judged_with_the_note_its_options_were(self):
        # review of 26 October (Ask 20): no test followed a question picked
        # after a stop that stopped again, on a choice
        pipe = pipeline_with(cheap(), model=Scripted(cost_less_than))
        pipe.clarifier.last_reply = {"phrase": "cheap",
                                     "candidates": [{"table": "products", "column": "price"}]}
        first = pipe.ask("Which products are cheap?")
        picked = first.suggestions[2]["question"]               # a value read from the data
        pipe.clarifier.outcome = Outcome(
            action="CLARIFY", phrase="price", kind="AmbiSchema",
            question='By "price", which do you mean?',
            options=[Option(label="products.price", means="what the customer pays",
                            table="products", column="price"),
                     Option(label="products.cost", means="what the shop pays",
                            table="products", column="cost")])
        second = pipe.ask(picked, earlier=first)
        note = pipe.clarifier.told[-1]["earlier"]
        self.assertIn('first asked: "Which products are cheap?"', note)
        self.assertIn(f'They picked: "{picked}"', note)
        self.assertEqual(second.earlier, note)
        self.assertEqual([s["choice"] for s in second.suggestions],
                         ["products.price", "products.cost"])
        # the choice comes back to that question, judged with that very note
        # rather than one about its own stop
        third = pipe.ask(picked, choice="products.price", earlier=second)
        self.assertEqual(pipe.clarifier.told[-1]["earlier"], note)
        self.assertEqual(third.earlier, note)
        self.assertEqual(third.technical_question, f"REWRITTEN: {picked} as products.price")
        # the other reading picked by its question: answered as it is, with
        # the same note and no judge called again
        judged = pipe.clarifier.clarified
        other = second.suggestions[1]["question"]
        fourth = pipe.ask(picked, choice="products.cost", suggestion=other, earlier=second)
        self.assertEqual((fourth.earlier, fourth.technical_question), (note, other))
        self.assertEqual(pipe.clarifier.clarified, judged)


# ------------------------------------------------------------ the payload

class PayloadTests(unittest.TestCase):

    def setUp(self):
        import tempfile
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        env = patch.dict("os.environ", {"DATAGORA_COVERAGE_DIR": self.tmp.name,
                                        "DATAGORA_DATA_DIR": self.tmp.name})
        env.start()
        self.addCleanup(env.stop)
        sys.path.insert(0, str(HERE / "ui"))
        import app
        self.app = app

    def test_the_payload_carries_the_suggestions_and_the_details(self):
        run = pipeline_with(active_employees()).ask(ASKED_ACTIVE)
        c = self.app._payload(run)["clarification"]
        self.assertEqual(c["needs"], "choice")
        self.assertEqual(c["verdict"], "NEEDS A CHOICE")
        self.assertEqual(c["clarifying"], 'By "active employees", which do you mean?')
        self.assertEqual(c["suggestions"][0], {
            "question": PLAIN_ACTIVE["suggestions"][0]["question"],
            "choice": "employees.status_code",
            "note": PLAIN_ACTIVE["suggestions"][0]["note"], "blank": False})
        # where each reading lives, for the page's details toggle
        self.assertEqual((c["options"][0]["table"], c["options"][0]["column"]),
                         ("employees", "status_code"))

    def test_both_endpoints_pass_the_pick_on_and_the_history_keeps_it(self):
        from fastapi.testclient import TestClient
        asked = []
        picked = PLAIN_ACTIVE["suggestions"][0]["question"]

        class Pipe:
            def ask(self, question, choice=None, on_step=None, suggestion=None,
                    context=None, earlier=None, remember=True):
                asked.append((question, choice, suggestion))
                return pipeline_with(active_employees()).ask(question, choice,
                                                             suggestion=suggestion)

        client = TestClient(self.app.app)
        with patch.object(self.app, "pipe", lambda name: Pipe()):
            first = client.post("/api/ask", json={"profile": "p", "question": ASKED_ACTIVE}).json()
            self.assertEqual(len(first["clarification"]["suggestions"]), 2)
            client.post("/api/ask", json={"profile": "p", "question": ASKED_ACTIVE,
                                          "choice": "employees.status_code",
                                          "suggestion": picked})
            client.post("/api/ask/stream", json={"profile": "p", "question": "Which cost less than 20?",
                                                 "suggestion": "Which cost less than 20?",
                                                 "original": "Which are cheap?"}).text
        self.assertEqual(asked[1], (ASKED_ACTIVE, "employees.status_code", picked))
        self.assertEqual(asked[2][2], "Which cost less than 20?")
        items = client.get("/api/history/ask").json()["items"]
        newest, middle, oldest = items
        self.assertEqual(len(oldest["suggestions"]), 2)
        self.assertEqual(middle["suggestion"], picked)
        self.assertEqual(middle["technical_question"], picked)
        self.assertEqual(newest["original"], "Which are cheap?")


# ---------------------------------------------- the functional API, flat

class ApiTests(unittest.TestCase):

    def call(self, outcome, model, **kw):
        import api
        with patch.object(api, "Clarifier", lambda profile, llm=None, system=None: Stub(llm, outcome)), \
                patch.object(api, "_llm", lambda llm, role: llm):
            return api.is_ambiguous(ASKED_ACTIVE, db={"database": "stub"}, llm=model, **kw)

    def test_is_ambiguous_fills_suggestions_only_when_asked(self):
        model = Scripted(PLAIN_ACTIVE)
        a = self.call(active_employees(), model)
        self.assertEqual((a.suggestions, model.calls), ([], []))
        self.assertEqual(a.phrase, "active employees")
        a = self.call(active_employees(), model, reformulate=True)
        self.assertEqual([s.choice for s in a.suggestions],
                         ["employees.status_code", "employees.termination_date"])

    def test_suggest_questions_works_from_what_is_ambiguous_returned(self):
        import api
        a = self.call(active_employees(), Scripted(PLAIN_ACTIVE))
        with patch.object(api, "Clarifier", lambda profile, llm=None, system=None: Stub(llm)), \
                patch.object(api, "_llm", lambda llm, role: llm):
            out = api.suggest_questions(ASKED_ACTIVE, a, db={"database": "stub"},
                                        llm=Scripted(PLAIN_ACTIVE))
            self.assertEqual(out[0].question, PLAIN_ACTIVE["suggestions"][0]["question"])
            # an unreachable model: the templates, and no exception
            out = api.suggest_questions(ASKED_ACTIVE, a, db={"database": "stub"},
                                        llm=Scripted(fail=True))
            self.assertEqual(len(out), 2)
            # an Outcome is taken as well; NOT COVERED gets nothing
            absent = Outcome(action="GUIDE", phrase="gluten", checked=True)
            self.assertEqual(api.suggest_questions("gluten?", absent, db={"database": "stub"},
                                                   llm=Scripted(PLAIN_ACTIVE)), [])

    def test_no_configured_model_gives_the_templates(self):
        import api

        def unconfigured(llm, role):
            raise SystemExit("no models.json")

        with patch.object(api, "Clarifier", lambda profile, llm=None, system=None: Stub(llm)), \
                patch.object(api, "_llm", unconfigured):
            # the real Clarifier keeps the stand-in model it is handed
            out = api.suggest_questions(ASKED_ACTIVE, active_employees(), db={"database": "stub"})
        self.assertEqual(len(out), 2)

    def test_a_function_is_a_model(self):
        # review of 26 October: INTEGRATION.md promises an llm taking
        # (system, user); _llm raised a TypeError on one
        import api
        import json as _json

        def my_client(system, user):
            return _json.dumps({"suggestions": []})
        model = api._llm(my_client, "reasoner")
        self.assertEqual(model.json("s", "u"), {"suggestions": []})
        self.assertEqual(model.chat("s", "u"), '{"suggestions": []}')
        with self.assertRaises(TypeError):
            api._llm(42, "reasoner")


# ------------------------------------------------------- the settings key

class SettingTests(unittest.TestCase):

    def setUp(self):
        import tempfile
        import settings_store as store
        self.store = store
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        env = patch.dict("os.environ", {"DATAGORA_DATA_DIR": self.tmp.name, rf.ENV: ""})
        env.start()
        self.addCleanup(env.stop)
        store._SET_HERE.clear()
        store._BEFORE.clear()

    def test_the_page_switches_it_and_a_partial_save_keeps_it(self):
        store = self.store
        self.assertTrue(store.load()["engine"]["reformulate"])     # on by default
        self.assertTrue(rf.enabled())
        store.update("databases", [{"name": "w", "database": "w"}])
        store.update("engine", {**store.load()["engine"], "reformulate": False})
        self.assertFalse(rf.enabled())
        # a page that sends only some engine keys keeps the others
        store.update("engine", {"ask_values": False})
        self.assertFalse(store.load()["engine"]["reformulate"])
        self.assertFalse(rf.enabled())
        store.update("engine", {"reformulate": True})
        self.assertTrue(rf.enabled())

    def test_the_settings_page_has_the_switch(self):
        page = (HERE / "ui" / "settings.html").read_text(encoding="utf-8")
        self.assertIn('id="eng-reform"', page)
        self.assertIn('reformulate: $("#eng-reform").checked', page)
        self.assertIn('e.reformulate !== false', page)


# --------------------------------------------- the package, as installed

PACKAGE_CHECK = r'''
import os, sys
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"
os.environ["DATAGORA_COLUMN_INDEX"] = "off"
os.environ.pop("DATAGORA_REFORMULATE", None)

import graph_lab
from graph_lab import Ambiguity, Datagora, Suggestion, suggest_questions
from graph_lab import api
from graph_lab.ambisql import Option, Outcome
from graph_lab.api import is_ambiguous
from graph_lab.api import suggest_questions as api_suggest
assert suggest_questions is api_suggest
assert "suggest_questions" in graph_lab.__all__ and "suggest_questions" in api.__all__

class Scripted:
    model = name = "scripted"
    def __init__(self, reply=None, fail=False):
        self.reply, self.fail, self.calls = reply, fail, []
    def thinking(self, on):
        return self
    def reachable(self):
        return True
    def json(self, system, user, schema=None, num_predict=None, timeout=None):
        self.calls.append(user)
        if self.fail:
            raise ConnectionError("down")
        return self.reply
    def chat(self, system, user, **kw):
        return ""

class Stub:
    columns = {"employees": [("employee_id", "int"), ("status_code", "varchar"),
                             ("termination_date", "date")]}
    def __init__(self, llm, outcome):
        self.llm, self.outcome, self.clarified, self.last_reply = llm, outcome, 0, None
    def clarify(self, question):
        self.clarified += 1
        return self.outcome
    def rewrite(self, question, clarification, option):
        return "REWRITTEN"
    def _distinct_values_checked(self, table, column, limit=None):
        return [], True
    def connect(self):
        raise RuntimeError("no database")

OUT = Outcome(action="CLARIFY", phrase="active employees", kind="AmbiSchema",
              question="By active employees, which do you mean?",
              options=[Option(label="employees.status_code", means="employees with status_code = 'ACTIVE'",
                              table="employees", column="status_code"),
                       Option(label="employees.termination_date",
                              means="employees with termination_date IS NULL",
                              table="employees", column="termination_date")])
REPLY = {"suggestions": [
    {"id": "1", "question": "How many employees with an active status work in each department?", "note": ""},
    {"id": "2", "question": "How many employees who have not left the company work in each department?", "note": ""}]}
Q = "How many active employees work in each department?"

model = Scripted(REPLY)
dg = Datagora(mysql=dict(host="127.0.0.1", port=1, database="stub", user="u", password="p"),
              reasoner=model, sql=Scripted(), reformulate=False, judge="single")
stub = dg.pipeline.clarifier = Stub(model, OUT)
dg.pipeline.anchors = lambda question: ([], "model")

out = dg.ask(Q)
assert out.waiting and out.suggestions == [] and model.calls == [], (out, model.calls)
assert dg.reformulate is False
print("OFF no suggestion, no model call")

dg.reformulate = True
out = dg.ask(Q)
assert [s.choice for s in out.suggestions] == ["employees.status_code", "employees.termination_date"]
assert all(isinstance(s, Suggestion) for s in out.suggestions)
assert out.suggestions[0].question == REPLY["suggestions"][0]["question"]
assert out.clarifying == 'By "active employees", which do you mean?', out.clarifying
assert "2 suggestions" in repr(out), repr(out)
print("ON", repr(out))

picked = out.suggestions[1]
before = stub.clarified
done = dg.ask(Q, choice=picked.choice, suggestion=picked.question)
assert stub.clarified == before and done.technical_question == picked.question
print("PICKED answered without clarifying again")

dg.reformulate = None
os.environ["DATAGORA_REFORMULATE"] = "off"
calls = len(model.calls)
assert dg.reformulate is False and dg.ask(Q).suggestions == [] and len(model.calls) == calls
os.environ["DATAGORA_REFORMULATE"] = "on"
assert dg.reformulate is True and len(dg.ask(Q).suggestions) == 2
print("ENV read when the argument is None")

more = Outcome(action="GUIDE", phrase="unpaid fines", kind="AmbiSchema", question="Which column holds it?")
stub.outcome = more
out = dg.ask("Which members have unpaid fines?")
assert out.suggestions and out.suggestions[0].blank and "needs more, 1 suggestion>" in repr(out), repr(out)
print("NEEDS MORE", repr(out))

api.Clarifier = lambda profile, llm=None, system=None: Stub(llm, OUT)
api._llm = lambda llm, role: llm
model = Scripted(REPLY)
a = is_ambiguous(Q, db={"database": "stub"}, llm=model)
assert isinstance(a, Ambiguity) and a.suggestions == [] and model.calls == []
a = is_ambiguous(Q, db={"database": "stub"}, llm=model, reformulate=True)
assert len(a.suggestions) == 2
assert len(suggest_questions(Q, a, db={"database": "stub"}, llm=model)) == 2
assert len(suggest_questions(Q, a, db={"database": "stub"}, llm=Scripted(fail=True))) == 2
print("API off, on, and an unreachable model")

flat = [m for m in ("ambisql", "pipeline", "reformulate", "api", "prompts") if m in sys.modules]
assert not flat, flat
print("PACKAGE OK")
'''


class PackageTests(unittest.TestCase):
    """The package imports its modules relatively, the tests flat: a module
    or an import that works here can break once installed. So this runs
    the client and the functional API as an application would, from src/,
    in a fresh interpreter, with nothing of this directory on its path."""

    def test_the_package_suggests_with_the_switch_on_and_stays_silent_off(self):
        import subprocess
        env = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}
        proc = subprocess.run([sys.executable, "-c", PACKAGE_CHECK], cwd=str(HERE.parent),
                              capture_output=True, text=True, timeout=300, env=env,
                              check=False)
        self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        self.assertIn("PACKAGE OK", proc.stdout)

    def test_the_module_ships_with_the_package(self):
        # the wheel takes every module of src/graph_lab (packages.find), so
        # the module only has to sit there; its prompt lives in prompts.py
        project = (HERE.parents[1] / "pyproject.toml").read_text(encoding="utf-8")
        self.assertIn('include = ["graph_lab*"]', project)
        self.assertTrue((HERE / "reformulate.py").is_file())
        self.assertTrue((HERE / "__init__.py").is_file())


if __name__ == "__main__":
    unittest.main()
