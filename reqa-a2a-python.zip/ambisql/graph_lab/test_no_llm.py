"""No-LLM validation of the join checklist: everything here runs without a
generative model. Embeddings (nomic-embed-text) power Qdrant retrieval;
Neo4j computes paths; the audits are pure functions.

Theories under test (see docs/architecture/join_correctness_checklist.md):
  T1  Qdrant neighbors alone can anchor a new question (layer 1)
  T2  allShortestPaths + weight tie-break yields the expected sub-schema
  T3  the static join audit accepts valid SQL and rejects seeded faults
  T4  fan and chasm traps are detectable without executing anything
  T5  EXPLAIN exposes a cartesian product before execution

Run from the repo root:
    .venv/Scripts/python src/graph_lab/test_no_llm.py
"""

import os

# the column index is on by default; a test never builds one in a real
# Qdrant, and the tests that need one give it directly
os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")

import json
import urllib.request
from pathlib import Path

import pymysql
from neo4j import GraphDatabase
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, PointStruct, VectorParams

# the audit logic lives in schema_graph so the test, the bench and
# production share one copy; this file keeps only what is specific to
# validating the hand-made demonstration graph
from schema_graph import Graph, audit_joins, audit_traps, explain_check, parse_sql

HERE = Path(__file__).parent
OLLAMA = "http://127.0.0.1:11434"
EMBED_MODEL = "nomic-embed-text"
COLLECTION = "graph_lab_corpus"


def env_password():
    for line in (HERE.parent.parent / ".env").read_text().splitlines():
        if line.startswith("NEO4J_PASSWORD="):
            return line.split("=", 1)[1].strip()
    raise SystemExit("NEO4J_PASSWORD not found in .env")


def embed(texts):
    body = json.dumps({"model": EMBED_MODEL, "input": texts}).encode()
    req = urllib.request.Request(f"{OLLAMA}/api/embed", data=body,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.loads(r.read())["embeddings"]


def main():
    data = json.loads((HERE / "corpus_demo.json").read_text("utf-8"))
    con = pymysql.connect(host="127.0.0.1", port=3306, user="psm_reader",
                          password="psm_reader", database="datagora_generic")
    drv = GraphDatabase.driver("bolt://127.0.0.1:7687",
                               auth=("neo4j", env_password()))
    graph = Graph(drv, {"demo": True})
    print(f"graph: {len(graph.edges)} edges loaded from Neo4j")

    # ---- certify the corpus by execution, extract tables by parsing
    corpus = data["corpus"]
    for c in corpus:
        with con.cursor() as cur:
            cur.execute(c["sql"])
            rows = cur.fetchall()
        assert rows, f"{c['id']} returned nothing"
        c["tables"], _, _ = parse_sql(c["sql"])
    print(f"corpus: {len(corpus)} question/SQL pairs certified by execution")

    # ---- index in Qdrant
    qc = QdrantClient(url="http://127.0.0.1:6333")
    if qc.collection_exists(COLLECTION):
        qc.delete_collection(COLLECTION)
    vecs = embed([c["question"] for c in corpus])
    qc.create_collection(COLLECTION, vectors_config=VectorParams(
        size=len(vecs[0]), distance=Distance.COSINE))
    qc.upsert(COLLECTION, [PointStruct(id=i, vector=v,
              payload={"question": c["question"], "sql": c["sql"],
                       "tables": c["tables"]})
              for i, (c, v) in enumerate(zip(corpus, vecs))])
    print(f"qdrant: {len(corpus)} questions indexed ({EMBED_MODEL})\n")

    # ---- T1 + T2: anchors from neighbors, then force-union sub-schema
    print("== T1/T2: anchors from Qdrant neighbors, no generative model ==")
    t1_ok = t2_ok = 0
    for t in data["held_out"]:
        qv = embed([t["question"]])[0]
        hits = qc.query_points(COLLECTION, query=qv, limit=2).points
        proposed = sorted({t for h in hits for t in h.payload["tables"]})
        expected = sorted(t["expected_tables"])
        sub = graph.force_union_subschema(proposed)
        rec = len(set(expected) & set(proposed)) / len(expected)
        cover = set(expected) <= set(sub)
        t1_ok += rec == 1.0
        t2_ok += cover
        print(f"  {t['id']}: neighbors {[h.payload['question'][:38] for h in hits]}")
        print(f"      proposed {proposed}")
        print(f"      recall {rec:.0%}, sub-schema covers expected: {cover}")
    print(f"  -> T1 anchors full-recall: {t1_ok}/5, "
          f"T2 sub-schema coverage: {t2_ok}/5\n")

    # ---- T3: join audit
    print("== T3: static join audit ==")
    goods = [corpus[2]["sql"], corpus[9]["sql"], corpus[10]["sql"]]
    bads = [
        ("invented edge", "SELECT * FROM products p JOIN warehouses w "
         "ON p.category_id = w.warehouse_id"),
        ("wrong keys", "SELECT * FROM inventory i JOIN warehouses w "
         "ON i.product_id = w.warehouse_id"),
    ]
    for sql in goods:
        vs = audit_joins(sql, graph)
        ok = all(v[0] == "OK" for v in vs)
        print(f"  valid SQL   -> {'PASS' if ok else 'FAIL'} "
              f"({len(vs)} joins checked)")
    for name, sql in bads:
        vs = audit_joins(sql, graph)
        rej = [v for v in vs if v[0] != "OK"]
        print(f"  {name:<13} -> {'REJECTED: ' + rej[0][1] if rej else 'MISSED'}")
    print()

    # ---- T4: traps
    print("== T4: fan and chasm, statically ==")
    fan_wrong = ("SELECT c.name, SUM(i.quantity_on_hand) FROM categories c "
                 "JOIN products p ON p.category_id = c.category_id "
                 "JOIN inventory i ON i.product_id = p.product_id "
                 "JOIN product_suppliers ps ON ps.product_id = p.product_id "
                 "GROUP BY c.name")
    fan_right = corpus[1]["sql"]
    price_fan = ("SELECT w.name, SUM(p.price) FROM warehouses w "
                 "JOIN inventory i ON i.warehouse_id = w.warehouse_id "
                 "JOIN products p ON i.product_id = p.product_id "
                 "GROUP BY w.name")
    for label, sql in [("doc's wrong (extra N:M hop)", fan_wrong),
                       ("clean aggregate", fan_right),
                       ("SUM over a coarser table", price_fan)]:
        v = audit_traps(sql, graph)
        print(f"  {label:<28} -> {v[0]}: {v[1][:80]}")
    print()

    # ---- T5: EXPLAIN
    print("== T5: EXPLAIN dry-run ==")
    cart = "SELECT * FROM products, warehouses"
    good = corpus[1]["sql"]
    for label, sql in [("cartesian", cart), ("proper join", good)]:
        v = explain_check(sql, con)
        print(f"  {label:<12} -> {v[0]}: {v[1]}")

    con.close()
    drv.close()


if __name__ == "__main__":
    main()
