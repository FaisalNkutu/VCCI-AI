"""The agent judge: its loop, its budget and its verifier, with a scripted
model, a stand-in schema and stand-in tools. No model server, no database.

The scenarios at the end are the questions the single-call judge got
wrong on the enterprise test database (E16, E17, E34, E27/E33, E35) and on
the product questions (Q09), replayed as the agent would explore them."""

import os
import tempfile

os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"
os.environ["DATAGORA_DATA_DIR"] = tempfile.mkdtemp(prefix="datagora-tests-")

import copy
import difflib
import threading
import unittest
from collections import deque
from dataclasses import dataclass, field
from types import SimpleNamespace

import coverage
import verdict_agent as va


# ------------------------------------------------------------ stand-ins

@dataclass
class Result:
    tool: str
    ok: bool = True
    data: object = None
    digest: str = ""
    facts: list = field(default_factory=list)
    error: str = ""
    rows: int = 0
    complete: bool = True
    cursor: int | None = None
    text: str = ""

    def render(self, max_tokens, offset=0):
        body = (self.text or self.digest)[offset:]
        cap = max(1, int(max_tokens * 2.7))
        shown = body[:cap]
        more = offset + cap if len(body) > cap else None
        return shown, {"rows": self.rows, "tokens": len(shown) // 3,
                       "truncated": more is not None, "more": more}


@dataclass(frozen=True)
class Edge:
    a: str
    b: str
    via: str
    source: str = "fk"
    weight: float = 1.0


class View:
    """A schema: tables with columns, joins, and short forms."""

    def __init__(self, tables, joins=()):
        self.tables = {t: list(cols) for t, cols in tables.items()}
        self.lower = {t.lower(): t for t in self.tables}
        self.edges = {t: [] for t in self.tables}
        for a, b, via in joins:
            self.edges[a].append(Edge(a, b, via))
            self.edges[b].append(Edge(b, a, via))
        self.short = {t: f"TABLE {t}  columns: {', '.join(c)}" for t, c in self.tables.items()}
        self.blocks = dict(self.short)

    def table(self, name):
        return self.lower.get(str(name or "").lower())

    def columns_of(self, table):
        return [(c, "varchar(40)") for c in self.tables.get(self.table(table), [])]

    def closest(self, name, n=3):
        return difflib.get_close_matches(str(name).lower(), list(self.lower), n=n)

    def has(self, table, column):
        t = self.table(table)
        return bool(t) and str(column or "").lower() in [c.lower() for c in self.tables[t]]

    def _bfs(self, a):
        prev, todo = {a: None}, deque([a])
        while todo:
            t = todo.popleft()
            for e in self.edges.get(t, []):
                if e.b not in prev:
                    prev[e.b] = (t, e.via)
                    todo.append(e.b)
        return prev

    def connected(self, tables, max_hops=6):
        tables = [self.table(t) or t for t in tables]
        reach = self._bfs(tables[0])
        cut = [t for t in tables[1:] if t not in reach]
        return not cut, cut

    def paths(self, a, b, max_hops=5, limit=3, seen=None):
        prev = self._bfs(a)
        if b not in prev:
            return []
        via, tabs, t = [], [b], b
        while prev[t] is not None:
            t, v = prev[t]
            via.insert(0, v)
            tabs.insert(0, t)
        return [{"tables": tabs, "via": via, "sources": ["fk"] * len(via),
                 "unseen": [x for x in tabs if seen is None or x not in seen]}]


class Tools:
    """Tools that answer from tables of canned results.

    compare: {frozenset of sql keys: pairs data} or a callable(sqls)
    counts: {substring of sql: count}
    values: {value: [(table, column, [matches])]}
    absent: {what: (absent, complete, hits)}"""

    def __init__(self, view, compare=None, counts=None, values=None, absent=None,
                 search=None, time=None):
        self.view = view
        self.time = time
        self.compare = compare or (lambda sqls: None)
        self.counts = counts or {}
        self.values = values or {}
        self.absent = absent or {}
        self.search = search
        self.calls = []

    def run(self, tool, args):
        self.calls.append((tool, dict(args)))
        if tool == "search_tables":
            tables = self.search or list(self.view.tables)[:3]
            return Result(tool, data={"tables": [{"table": t, "score": 1.0} for t in tables]},
                          digest=f"{len(tables)} tables: {', '.join(tables)}",
                          text="\n".join(self.view.short[t] for t in tables), rows=len(tables))
        if tool == "describe_tables":
            names = [self.view.table(n) for n in args.get("names") or []]
            names = [n for n in names if n]
            return Result(tool, data={"tables": [{"table": n} for n in names]},
                          digest=f"{len(names)} tables described",
                          text="\n".join(self.view.blocks[n] for n in names), rows=len(names))
        if tool == "join_path":
            paths = self.view.paths(self.view.table(args.get("a")), self.view.table(args.get("b")))
            return Result(tool, data={"paths": paths},
                          digest=(" -> ".join(paths[0]["tables"]) if paths else "no path"))
        if tool == "find_value":
            return self.find_value(args.get("value"), args.get("tables"))
        if tool == "sample_values":
            return Result(tool, data={"values": ["A", "B"]}, digest="2 values")
        if tool == "run_count":
            return self.run_count(args.get("sql"))
        if tool == "compare_readings":
            return self.compare_readings(args.get("sqls"))
        if tool == "clock":
            # as ToolBox.clock: today, and the latest date of the table asked
            # (review of 26 October: the double had no clock, and the probe
            # was never exercised at the agent's level)
            data = {"today": "2026-10-26", "table": args.get("table"),
                    "latest": [{"column": "order_date", "latest": "2026-09-30"}]}
            return Result(tool, data=data, digest="today 2026-10-26")
        if tool == "time_columns" and self.time is not None:
            data = self.time.get(self.view.table(args.get("table")))
            if data is None:
                return Result(tool, ok=False, error="no such table", digest="error")
            return Result(tool, data=data, digest="time columns")
        return Result(tool, ok=False, error=f"unknown tool {tool}", digest="error")

    def find_value(self, value, tables=None):
        self.calls.append(("find_value", {"value": value}))
        hits = [{"table": t, "column": c, "matches": m}
                for t, c, m in self.values.get(str(value).lower(), [])]
        return Result("find_value", data={"hits": hits},
                      digest=f"{len(hits)} hits for {value}")

    def run_count(self, sql):
        """Like ToolBox.run_count: `count` is how many rows the SELECT
        returns, so a COUNT(*) returns one row that holds the number."""
        self.calls.append(("run_count", {"sql": sql}))
        for frag, n in self.counts.items():
            if frag in str(sql):
                if n is None:       # the database could not count it
                    return Result("run_count", data={"count": None, "columns": ["id"],
                                                     "rows": []}, digest="unknown")
                if str(sql).lstrip().upper().startswith("SELECT COUNT("):
                    return Result("run_count", data={"count": 1, "columns": ["COUNT(*)"],
                                                     "rows": [[str(n)]]}, digest="1 row")
                return Result("run_count", data={"count": n, "columns": ["id"],
                                                 "rows": [[i] for i in range(min(n, 5))]},
                              digest=f"{n} rows")
        return Result("run_count", ok=False, error="no canned count", digest="error")

    def compare_readings(self, sqls):
        self.calls.append(("compare_readings", {"sqls": list(sqls)}))
        data = self.compare(list(sqls))
        if data is None:
            return Result("compare_readings", ok=False, error="no canned comparison")
        return Result("compare_readings", data=data, digest="compared")

    def absent_everywhere(self, what, columns=True):
        self.calls.append(("absent_everywhere", {"what": what}))
        return self.absent.get(str(what).lower(), (False, False, []))


def pairs(counts, same=(), share=None, undetermined=()):
    """A compare_readings payload for len(counts) readings."""
    n = len(counts)
    out = {"results": [{"i": i, "count": c, "hash": f"h{i}"} for i, c in enumerate(counts)],
           "pairs": []}
    for a in range(n):
        for b in range(a + 1, n):
            s = (a, b) in same
            sh = 0.0 if s else (share if share is not None else 0.5)
            diff = 0 if s else max(1, int(sh * (counts[a] + counts[b])))
            out["pairs"].append({"a": a, "b": b, "same": s, "only_a": diff, "only_b": 0,
                                 "share": sh, "undetermined": (a, b) in undetermined})
    return out


class Model:
    """A model that replies from a script. Each reply is a dict, None, or a
    callable(user, schema) returning one; `sent` keeps what it was sent."""

    def __init__(self, replies, can_think=True, num_ctx=16384, overflow_on=(),
                 overflow_always=False, raises=None):
        self.replies = list(replies)
        self.sent = []
        self.can_think = can_think
        self.think = None
        self.num_ctx = num_ctx
        self.name = "scripted"
        self.model = "scripted"
        self.on_progress = None
        self.last_error = ""
        self.last_server = {}
        self.last_prompt_tokens = 0
        self.overflow_on = set(overflow_on)
        self.overflow_always = overflow_always
        self.raises = raises

    def thinks(self):
        return self.can_think and self.think is not False

    def thinking(self, on):
        other = copy.copy(self)
        other.think = bool(on)
        return other

    def loaded_window(self):
        return None

    def reachable(self):
        return True

    def json(self, system, user, schema=None, **kw):
        n = len(self.sent)
        self.sent.append({"system": system, "user": user, "schema": schema, "kw": kw,
                          "think": self.thinks()})
        if self.raises is not None:
            raise self.raises
        self.last_server = {"overflow": n in self.overflow_on
                            and (self.thinks() or self.overflow_always)}
        if self.last_server["overflow"]:
            self.last_error = "the reply did not fit"
            return None
        if not self.replies:
            self.last_error = "script exhausted"
            return None
        r = self.replies.pop(0)
        if callable(r):
            r = r(user, schema)
        self.last_error = "" if r is not None else "no JSON"
        return copy.deepcopy(r)


def settings(**kw):
    # wording off by default here, said rather than left out: production has
    # it on, and the tests that need it ask for it (WordingTests)
    base = dict(judge_mode="agent", max_turns=8, max_seconds=600, think="all",
                sql_seconds=5, result_tokens=3000, choice_tolerance=0.01,
                same_result="answer", arbiter="off", compare_rows=1000, verify_rounds=1,
                wording=False)
    base.update(kw)
    return SimpleNamespace(**base)


def agent(model, view, tools, **kw):
    clar = SimpleNamespace(llm=model, _llm=model, profile=None)
    return va.VerdictAgent(clar, view=view, settings=settings(**kw), system="SYSTEM",
                           toolbox=lambda c, v, s: tools)


def reading(tables=(), values=(), time="none"):
    return {"measure": "", "entities": [], "filters": [], "values": list(values),
            "tables": list(tables), "period": "", "comparisons": [], "time": time,
            "time_relations": []}


def plan_turn(tables=(), values=(), action="conclude", call=None, conclusion=None):
    r = {"thought_summary": "t", "notes": [], "reading": reading(tables, values),
         "plan": [{"do": "look", "status": "todo"}], "action": action}
    if call:
        r["call"] = call
    if conclusion:
        r["conclusion"] = conclusion
    return r


def call(tool, **args):
    return {"thought_summary": "t", "notes": [], "plan": [{"do": "look", "status": "todo"}],
            "action": "call", "call": {"tool": tool, "args": args}}


def conclude(verdict="ANSWER", tables=(), issues=(), reason="r", columns=()):
    return {"thought_summary": "t", "notes": [], "plan": [{"do": "look", "status": "done"}],
            "action": "conclude",
            "conclusion": conclusion(verdict, tables, issues, reason, columns)}


def conclusion(verdict="ANSWER", tables=(), issues=(), reason="r", columns=()):
    return {"reason": reason, "verdict": verdict, "tables": list(tables),
            "columns": list(columns), "joins": [], "issues": list(issues)}


def issue(type_, phrase="p", what="", readings=(), check_sql="", kind=None):
    return {"type": type_, "phrase": phrase, "kind": kind or va.KIND_OF_ISSUE[type_],
            "what": what, "readings": list(readings), "check_sql": check_sql, "evidence": []}


def by_label(label, why):
    """A wording check that names the reading called `label`, wherever it
    sits in the list, as a check without a bias for a place would."""
    return lambda question, phrase, readings: (
        [r.get("label") for r in readings].index(label), why)


def rd(label, table, column, sql, means=""):
    return {"label": label, "means": means or label, "table": table, "column": column, "sql": sql}


SHOP = View({"orders": ["order_id", "customer_id", "order_date", "promised_date",
                        "net_amount", "gross_amount", "status"],
             "customers": ["customer_id", "name", "country"],
             "order_lines": ["line_id", "order_id", "product_id", "quantity"],
             "products": ["product_id", "name", "list_price"],
             "suppliers": ["supplier_id", "name", "rating"],
             "receipts": ["receipt_id", "supplier_id", "received", "promised"]},
            joins=[("orders", "customers", "orders.customer_id = customers.customer_id"),
                   ("order_lines", "orders", "order_lines.order_id = orders.order_id"),
                   ("order_lines", "products", "order_lines.product_id = products.product_id"),
                   ("receipts", "suppliers", "receipts.supplier_id = suppliers.supplier_id")])


def verdict(outcome):
    return coverage.classify(outcome)[0]


# ------------------------------------------------------------------ loop

class LoopTests(unittest.TestCase):

    def test_a_plain_question_is_answered(self):
        model = Model([plan_turn(tables=["orders"]),
                       conclude("ANSWER", tables=["orders"])])
        tools = Tools(SHOP)
        a = agent(model, SHOP, tools)
        out = a.clarify("How many orders are there?")
        self.assertEqual(verdict(out), coverage.ANSWERABLE)
        # the code searched first and described the table the reading named
        self.assertEqual(tools.calls[0][0], "search_tables")
        self.assertIn(("describe_tables", {"names": ["orders"]}), tools.calls)
        self.assertEqual(a.last_trace["mode"], "agent")
        self.assertEqual(a.last_trace["stopped_by"], "concluded")

    def test_a_question_in_time_probes_the_clock_and_the_sweeps_still_run(self):
        # review of 26 October: the clock probe was untested at this level,
        # which is how the 23 October clock that hid the sweeps' timer shipped
        reading_time = dict(reading(["orders"]), period="last year")
        first = dict(plan_turn(tables=["orders"]), reading=reading_time)
        model = Model([first, conclude("NOT_COVERED", ["orders"], [issue(
            "absent_from_database", "patents", what="patents")])])
        tools = Tools(SHOP, absent={"patents": (True, True, [])})
        out = agent(model, SHOP, tools).clarify("Which patents did we file last year?")
        names = [c[0] for c in tools.calls]
        self.assertIn("clock", names)
        self.assertIn("absent_everywhere", names)        # the sweep ran after it
        self.assertEqual(verdict(out), coverage.NOT_COVERED)

    def test_the_first_turn_is_asked_for_a_reading(self):
        model = Model([plan_turn(), conclude()])
        agent(model, SHOP, Tools(SHOP)).clarify("q?")
        self.assertIs(model.sent[0]["schema"], va.FIRST_TURN_SCHEMA)
        self.assertIs(model.sent[1]["schema"], va.TURN_SCHEMA)

    def test_values_named_are_looked_up_by_the_code(self):
        model = Model([plan_turn(tables=["customers"], values=["Germany"]),
                       conclude("ANSWER", tables=["customers"])])
        tools = Tools(SHOP, values={"germany": [("customers", "country", ["Germany"])]})
        agent(model, SHOP, tools).clarify("Which customers are in Germany?")
        names = [c[0] for c in tools.calls]
        self.assertIn("find_value", names)
        # the column the value was found in is sampled too
        self.assertIn(("sample_values", {"table": "customers", "column": "country", "n": 20}),
                      tools.calls)
        # and the second prompt shows what the probes found
        self.assertIn("find_value(value=Germany", model.sent[1]["user"])

    def test_the_tables_one_key_away_are_shown_from_the_start(self):
        model = Model([plan_turn(), conclude()])
        tools = Tools(SHOP, search=["order_lines"])
        agent(model, SHOP, tools).clarify("q?")
        first = model.sent[0]["user"]
        self.assertIn("neighbours", first)
        self.assertIn("TABLE orders", first)
        self.assertIn("TABLE products", first)

    def test_a_call_runs_its_tool_and_the_result_is_shown_once(self):
        model = Model([plan_turn(),
                       call("sample_values", table="orders", column="status"),
                       conclude("ANSWER", tables=["orders"])])
        tools = Tools(SHOP)
        agent(model, SHOP, tools).clarify("q?")
        self.assertIn(("sample_values", {"table": "orders", "column": "status"}), tools.calls)
        self.assertIn("NEW RESULTS", model.sent[2]["user"])
        self.assertIn("sample_values(table=orders, column=status)", model.sent[2]["user"])

    def test_the_turn_cap_asks_for_a_conclusion(self):
        replies = [plan_turn()] + [call("sample_values", table="orders", column="status")] * 3 \
            + [{"conclusion": conclusion("ANSWER", tables=["orders"])}]
        model = Model(replies)
        a = agent(model, SHOP, Tools(SHOP), max_turns=4)
        out = a.clarify("q?")
        self.assertEqual(verdict(out), coverage.ANSWERABLE)
        self.assertIs(model.sent[-1]["schema"], va.CONCLUSION_SCHEMA)
        self.assertIn("Conclude now", model.sent[-1]["user"])
        self.assertEqual(a.last_trace["stopped_by"], "turn_cap")

    def test_the_time_cap_asks_for_a_conclusion(self):
        # 550 s in, 50 s left of 600: under the 90 s margin, so conclude now
        ticks = iter([0, 0, 0, 0] + [550] * 30)
        model = Model([plan_turn(), {"conclusion": conclusion("ANSWER")}])
        a = agent(model, SHOP, Tools(SHOP), max_seconds=600)
        a.clock = lambda: next(ticks, 550)
        out = a.clarify("q?")
        self.assertEqual(out.action, "ANSWER")
        self.assertIs(model.sent[-1]["schema"], va.CONCLUSION_SCHEMA)

    def test_at_the_cap_with_nothing_usable_the_question_is_judged_again(self):
        model = Model([plan_turn()] + [call("sample_values", table="orders", column="status")] * 2
                      + [{"conclusion": {"verdict": "nonsense"}}])
        out = agent(model, SHOP, Tools(SHOP), max_turns=3).clarify("q?")
        self.assertEqual(out.action, "ERROR")
        self.assertEqual(verdict(out), coverage.UNKNOWN)

    def test_a_stopped_job_stops_the_question(self):
        ev = threading.Event()
        ev.set()
        model = Model([plan_turn(), conclude()])
        a = agent(model, SHOP, Tools(SHOP))
        a.cancel_event = ev
        with self.assertRaises(va.AgentCancelled):
            a.clarify("q?")
        # and coverage makes no verdict of it, not even UNKNOWN: the question
        # is left for the resume (review of 26 October: a Stop wrote
        # UNKNOWN rows that the bench scored as wrong)
        with self.assertRaises(va.AgentCancelled):
            coverage._judge_core(a, "q?", {}, False)

    def test_two_unusable_replies_are_an_error_and_the_retry_says_why(self):
        model = Model([{"thought_summary": "t"}, {"thought_summary": "t"}])
        out = agent(model, SHOP, Tools(SHOP)).clarify("q?")
        self.assertEqual(out.action, "ERROR")
        self.assertIn("YOUR LAST REPLY COULD NOT BE USED", model.sent[1]["user"])

    def test_a_conclusion_missing_is_asked_for_without_thinking(self):
        bare = {"thought_summary": "t", "notes": [], "plan": [], "action": "conclude"}
        model = Model([plan_turn(), bare, {"conclusion": conclusion("ANSWER")}])
        out = agent(model, SHOP, Tools(SHOP)).clarify("q?")
        self.assertEqual(out.action, "ANSWER")
        self.assertIs(model.sent[2]["schema"], va.CONCLUSION_SCHEMA)
        self.assertFalse(model.sent[2]["think"])

    def test_an_overflow_is_asked_again_without_thinking(self):
        model = Model([plan_turn(), conclude()], overflow_on={0})
        out = agent(model, SHOP, Tools(SHOP)).clarify("q?")
        self.assertEqual(out.action, "ANSWER")
        self.assertTrue(model.sent[0]["think"])
        self.assertFalse(model.sent[1]["think"])

    def test_the_phases_reach_the_page(self):
        seen = []
        model = Model([plan_turn(tables=["orders"]), conclude("ANSWER", tables=["orders"])])
        model.on_progress = lambda phase, said: seen.append(phase)
        agent(model, SHOP, Tools(SHOP)).clarify("q?")
        self.assertIn("tool:search_tables", seen)
        self.assertIn("tool:describe_tables", seen)

    def test_thinking_follows_the_setting_per_phase(self):
        model = Model([plan_turn(), call("sample_values", table="orders", column="status"),
                       conclude()])
        agent(model, SHOP, Tools(SHOP), think="plan_conclude").clarify("q?")
        self.assertTrue(model.sent[0]["think"])        # planning
        self.assertFalse(model.sent[1]["think"])       # exploring

    def test_a_model_that_cannot_think_is_never_made_to(self):
        model = Model([plan_turn(), conclude()], can_think=False)
        agent(model, SHOP, Tools(SHOP)).clarify("q?")
        self.assertFalse(any(s["think"] for s in model.sent))

    def test_more_pages_a_result_without_a_new_query(self):
        long = Result("describe_tables", data={"tables": [{"table": "orders"}]},
                      digest="1 table", text="x" * 20000, rows=1)
        tools = Tools(SHOP)
        real = tools.run

        def run(tool, args):
            if tool == "describe_tables":
                tools.calls.append((tool, dict(args)))
                return long
            return real(tool, args)
        tools.run = run
        model = Model([plan_turn(),
                       call("describe_tables", names=["orders"]),
                       lambda user, schema: call("more", step=2, cursor=4000),
                       conclude()])
        agent(model, SHOP, tools, result_tokens=1000).clarify("q?")
        self.assertIn("more: step=2", model.sent[2]["user"])
        self.assertIn("more(step=2, cursor=4000)", model.sent[3]["user"])
        runs = [c for c in tools.calls if c[0] == "describe_tables"]
        self.assertEqual(len(runs), 1)      # paging read no table again

    def test_num_predict_is_sent_when_the_model_takes_it(self):
        model = Model([plan_turn(), conclude()])
        agent(model, SHOP, Tools(SHOP)).clarify("q?")
        self.assertIn("num_predict", model.sent[0]["kw"])


# ---------------------------------------------------------------- budget

class BudgetTests(unittest.TestCase):

    def test_thinking_takes_room_only_where_it_happens(self):
        b = va.Budget(Model([]), "SYSTEM", settings())
        self.assertAlmostEqual(b.room(False) - b.room(True), va.THINK_ROOM * 0.9, delta=1)
        self.assertGreater(b.room(False), b.room(True))
        self.assertGreater(b.room(True), b.room(True, concluding=True))

    def test_the_time_left_is_said_in_bands_so_two_runs_read_the_same(self):
        b = va.Budget(Model([]), "SYSTEM", settings(max_seconds=600))
        nb = va.Notebook("How many orders?")
        nb.reading = reading(["orders"])
        one, _ = b.fit(nb, 2, 8, 412.7, thinks=False)
        two, _ = b.fit(nb, 2, 8, 377.1, thinks=False)
        self.assertEqual(one, two)
        self.assertNotIn("412", one)
        self.assertIn("time: ample", b.time_band(400))
        self.assertIn("half gone", b.time_band(200))
        self.assertIn("nearly out", b.time_band(60))

    def test_num_predict_never_pushes_the_prompt_out(self):
        b = va.Budget(Model([]), "SYSTEM", settings())
        self.assertLessEqual(10000 + b.num_predict(10000, True) + b.system, b.window)

    def test_a_small_window_still_gets_a_message_that_fits(self):
        b = va.Budget(Model([], num_ctx=4096), "SYSTEM", settings())
        nb = va.Notebook("How many orders?")
        nb.reading = reading(["orders"])
        for i in range(12):
            s = va.Step(n=i, phase="exploring", tool="sample_values",
                        args={"table": "orders", "column": f"c{i}"},
                        result=Result("sample_values", digest=f"values {i}", text="v" * 30000),
                        note=f"note {i}", shown=i < 10)
            nb.record(s)
        text, shown = b.fit(nb, 5, 8, 300, thinks=False)
        self.assertLessEqual(b.estimate(text), b.room(False))
        self.assertIn("(earlier:", text)
        self.assertIn("truncated yes", text)
        self.assertTrue(shown)


# -------------------------------------------------------------- verifier

class VerifierTests(unittest.TestCase):

    def check(self, concl, tools=None, final=False, view=SHOP, **kw):
        v = va.Verifier(view, tools or Tools(view), settings(**kw))
        return v.check(concl, va.Notebook("q?"), final)

    def test_readings_with_the_same_rows_are_one_reading(self):
        tools = Tools(SHOP, compare=lambda s: pairs([10, 10], same={(0, 1)}))
        c = conclusion("CHOICE", ["orders"], [issue("choice", "date", readings=[
            rd("order date", "orders", "order_date", "SELECT 1"),
            rd("promised", "orders", "promised_date", "SELECT 2")])])
        out = self.check(c, tools, final=True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)
        self.assertIn("coincide", out.outcome.reason)

    def test_same_rows_can_be_kept_a_choice_by_setting(self):
        tools = Tools(SHOP, compare=lambda s: pairs([10, 10], same={(0, 1)}))
        c = conclusion("CHOICE", ["orders"], [issue("choice", "date", readings=[
            rd("a", "orders", "order_date", "SELECT 1"),
            rd("b", "orders", "promised_date", "SELECT 2")])])
        out = self.check(c, tools, final=True, same_result="choice")
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_CHOICE)

    def test_readings_that_differ_are_a_choice_with_their_joins(self):
        tools = Tools(SHOP, compare=lambda s: pairs([300, 200]))
        c = conclusion("CHOICE", ["order_lines"], [issue("choice", "price", readings=[
            rd("list price", "products", "list_price", "SELECT 1"),
            rd("net", "orders", "net_amount", "SELECT 2")])])
        out = self.check(c, tools)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_CHOICE)
        self.assertEqual(len(out.outcome.options), 2)
        self.assertEqual(out.outcome.options[0].via,
                         "order_lines.product_id = products.product_id")

    def test_a_small_difference_goes_back_once_then_the_agent_decides(self):
        tools = Tools(SHOP, compare=lambda s: pairs([1735, 1735], share=0.003))
        c = conclusion("CHOICE", ["orders"], [issue("choice", "amount", readings=[
            rd("a", "orders", "net_amount", "SELECT 1"),
            rd("b", "orders", "gross_amount", "SELECT 2")])])
        first = self.check(c, tools, final=False)
        self.assertIsNone(first.outcome)
        self.assertTrue(any("differ on" in f for f in first.feedback))
        # the feedback says facts, not the verdict it questions
        self.assertFalse(any("CHOICE" in f for f in first.feedback))
        second = self.check(c, tools, final=True)
        self.assertEqual(verdict(second.outcome), coverage.NEEDS_CHOICE)

    def test_something_said_absent_but_held_needs_more(self):
        tools = Tools(SHOP, absent={"churn": (False, True, ["customers.churned_at"])})
        c = conclusion("NOT_COVERED", ["customers"],
                       [issue("absent_from_database", "churn", what="churn")])
        self.assertIsNone(self.check(c, tools).outcome)
        out = self.check(c, tools, final=True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        self.assertFalse(out.outcome.checked)

    def test_something_absent_from_the_whole_database_is_not_covered(self):
        tools = Tools(SHOP, absent={"audiobooks": (True, True, [])})
        c = conclusion("NOT_COVERED", ["products"],
                       [issue("absent_from_database", "audiobooks", what="audiobooks")])
        out = self.check(c, tools)
        self.assertEqual(verdict(out.outcome), coverage.NOT_COVERED)
        self.assertTrue(out.outcome.checked)

    def test_an_incomplete_sweep_never_refuses(self):
        tools = Tools(SHOP, absent={"x": (True, False, [])})
        c = conclusion("NOT_COVERED", [], [issue("absent_from_database", "x", what="x")])
        out = self.check(c, tools, final=True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)

    def test_no_matching_row_needs_a_count_of_zero(self):
        c = conclusion("NO_DATA", ["orders"], [issue(
            "no_matching_row", "2020", what="orders of 2020",
            check_sql="SELECT COUNT(*) FROM orders WHERE YEAR(order_date)=2020")])
        empty = self.check(c, Tools(SHOP, counts={"2020": 0}))
        self.assertEqual(verdict(empty.outcome), coverage.NO_DATA)
        held = self.check(c, Tools(SHOP, counts={"2020": 5}), final=True)
        self.assertEqual(verdict(held.outcome), coverage.ANSWERABLE)

    def test_a_missing_value_wins_over_a_choice(self):
        tools = Tools(SHOP, compare=lambda s: pairs([5, 7]), counts={"2027": 0})
        c = conclusion("NEEDS_MORE", ["orders"], [
            issue("choice", "cost", readings=[rd("net", "orders", "net_amount", "SELECT 1"),
                                              rd("gross", "orders", "gross_amount", "SELECT 2")]),
            issue("asker_must_say", "2027 rate", what="the 2027 budget rate",
                  check_sql="SELECT COUNT(*) FROM rates WHERE year=2027")])
        out = self.check(c, tools)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        self.assertIn("2027 budget rate", out.outcome.reason)
        self.assertIn("choice", out.outcome.reason)

    def test_an_unknown_table_goes_back_with_the_closest_names(self):
        c = conclusion("ANSWER", ["order"])
        out = self.check(c)
        self.assertIsNone(out.outcome)
        self.assertTrue(any("closest" in f and "orders" in f for f in out.feedback))

    def test_tables_that_do_not_join_go_back_then_need_more(self):
        c = conclusion("ANSWER", ["orders", "suppliers"])
        first = self.check(c)
        self.assertIsNone(first.outcome)
        self.assertTrue(any("join_path" in f for f in first.feedback))
        last = self.check(c, final=True)
        self.assertEqual(verdict(last.outcome), coverage.NEEDS_MORE)

    def test_a_stored_value_is_no_judgement(self):
        tools = Tools(SHOP, values={"high": [("orders", "status", ["HIGH"])]})
        c = conclusion("NEEDS_MORE", ["orders"],
                       [issue("asker_must_say", "high", what="what high means",
                              kind="AmbiContext")])
        first = self.check(c, tools)
        self.assertIsNone(first.outcome)
        self.assertTrue(any("holds the value HIGH" in f for f in first.feedback))
        out = self.check(c, tools, final=True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)

    def test_a_threshold_the_asker_sets_is_accepted(self):
        c = conclusion("NEEDS_MORE", ["products"],
                       [issue("asker_must_say", "cheap", what="the price under which a "
                              "product counts as cheap", kind="AmbiContext")])
        out = self.check(c)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        self.assertIn("counts as cheap", coverage.classify(out.outcome)[1])

    def test_a_verdict_without_an_issue_is_asked_for_one(self):
        out = self.check(conclusion("CHOICE", ["orders"]))
        self.assertIsNone(out.outcome)

    def test_every_winner_reads_as_the_right_verdict(self):
        cases = [
            (conclusion("ANSWER", ["orders"]), Tools(SHOP), coverage.ANSWERABLE),
            (conclusion("NOT_COVERED", [], [issue("absent_from_database", "x", what="x")]),
             Tools(SHOP, absent={"x": (True, True, [])}), coverage.NOT_COVERED),
        ]
        for c, tools, want in cases:
            self.assertEqual(verdict(self.check(c, tools).outcome), want)


# ------------------------------------------------------------- scenarios

ENTERPRISE = View(
    {"sales_orders": ["sales_order_id", "order_date", "promised_date", "status_code"],
     "sales_order_lines": ["line_id", "sales_order_id", "product_id", "quantity"],
     "products": ["product_id", "name"],
     "purchase_orders": ["purchase_order_id", "net_amount", "gross_amount", "status_code"],
     "exchange_rates": ["rate_date", "rate_type", "rate"],
     "machines": ["machine_id", "name"],
     "shipments": ["shipment_id", "ship_date"],
     "shipment_lines": ["shipment_line_id", "shipment_id", "sales_order_id"],
     "work_orders": ["work_order_id", "sales_order_id", "planned_end", "actual_end"]},
    joins=[("sales_order_lines", "sales_orders",
            "sales_order_lines.sales_order_id = sales_orders.sales_order_id"),
           ("sales_order_lines", "products",
            "sales_order_lines.product_id = products.product_id"),
           ("shipment_lines", "shipments", "shipment_lines.shipment_id = shipments.shipment_id"),
           ("shipment_lines", "sales_orders",
            "shipment_lines.sales_order_id = sales_orders.sales_order_id"),
           ("work_orders", "sales_orders",
            "work_orders.sales_order_id = sales_orders.sales_order_id")])


class ScenarioTests(unittest.TestCase):
    """The questions the single-call judge got wrong, as the agent works
    them. Each scenario scripts the agent's replies; the verdict comes from
    the verifier, on the facts the stand-in tools return."""

    def run_agent(self, view, tools, replies, **kw):
        model = Model(replies)
        return agent(model, view, tools, **kw).clarify("q?"), model

    def test_e16_an_invented_choice_on_dates_is_answered(self):
        # the top 10 products are the same by order date or promised date
        tools = Tools(ENTERPRISE, compare=lambda s: pairs([10, 10], same={(0, 1)}))
        out, _ = self.run_agent(ENTERPRISE, tools, [
            plan_turn(tables=["sales_order_lines", "sales_orders"]),
            conclude("CHOICE", ["sales_order_lines", "sales_orders"], [issue("choice", "in 2025",
                     readings=[rd("ordered", "sales_orders", "order_date", "SELECT a"),
                               rd("promised", "sales_orders", "promised_date", "SELECT b")])])])
        self.assertEqual(verdict(out), coverage.ANSWERABLE)

    def test_e17_a_difference_of_ten_rows_is_put_back_to_the_agent(self):
        tools = Tools(ENTERPRISE, compare=lambda s: pairs([1735, 1735], share=0.006))
        choice = conclude("CHOICE", ["sales_orders"], [issue("choice", "amount", readings=[
            rd("a", "sales_orders", "order_date", "SELECT a"),
            rd("b", "sales_orders", "promised_date", "SELECT b")])])
        out, model = self.run_agent(ENTERPRISE, tools, [
            plan_turn(tables=["sales_orders"]), choice,
            conclude("ANSWER", ["sales_orders"])])
        self.assertEqual(verdict(out), coverage.ANSWERABLE)
        self.assertIn("VERIFIER", model.sent[2]["user"])
        # with no tolerance the difference is a choice straight away
        out, _ = self.run_agent(ENTERPRISE, tools, [plan_turn(tables=["sales_orders"]), choice],
                                choice_tolerance=0)
        self.assertEqual(verdict(out), coverage.NEEDS_CHOICE)

    def test_e34_a_missing_rate_is_not_hidden_by_net_or_gross(self):
        tools = Tools(ENTERPRISE, compare=lambda s: pairs([40, 40], share=0.2),
                      counts={"2027": 0})
        out, _ = self.run_agent(ENTERPRISE, tools, [
            plan_turn(tables=["purchase_orders", "exchange_rates"]),
            call("time_columns", table="exchange_rates"),
            conclude("NEEDS_MORE", ["purchase_orders"], [
                issue("choice", "cost us", readings=[
                    rd("net", "purchase_orders", "net_amount", "SELECT n"),
                    rd("gross", "purchase_orders", "gross_amount", "SELECT g")]),
                issue("asker_must_say", "budget rate for 2027",
                      what="the 2027 budget exchange rate; rates are stored for 2023 to 2026 only",
                      check_sql="SELECT COUNT(*) FROM exchange_rates WHERE YEAR(rate_date)=2027")])])
        self.assertEqual(verdict(out), coverage.NEEDS_MORE)
        self.assertIn("2027", coverage.classify(out)[1])
        self.assertIn(("run_count", {"sql": "SELECT COUNT(*) FROM exchange_rates WHERE YEAR(rate_date)=2027"}),
                      tools.calls)

    def test_e27_e33_a_bridge_table_not_shown_is_found(self):
        # the search shows shipments and sales_orders, not shipment_lines;
        # the neighbours bring it in, and the answer joins through it
        tools = Tools(ENTERPRISE, search=["shipments", "sales_orders"])
        out, model = self.run_agent(ENTERPRISE, tools, [
            plan_turn(tables=["shipments", "sales_orders"]),
            conclude("ANSWER", ["shipments", "shipment_lines", "sales_orders"])])
        self.assertEqual(verdict(out), coverage.ANSWERABLE)
        self.assertIn("TABLE shipment_lines", model.sent[0]["user"])

    def test_e27_e33_no_link_claimed_without_looking_goes_back(self):
        tools = Tools(ENTERPRISE, search=["shipments", "sales_orders"])
        out, model = self.run_agent(ENTERPRISE, tools, [
            plan_turn(tables=["shipments", "machines"]),
            conclude("ANSWER", ["shipments", "machines"]),
            conclude("NEEDS_MORE", ["shipments"], [issue(
                "asker_must_say", "delayed", what="how shipments relate to work orders")])])
        self.assertIn("join_path", model.sent[2]["user"])
        self.assertEqual(verdict(out), coverage.NEEDS_MORE)

    def test_e35_late_is_a_choice_of_four_readings(self):
        tools = Tools(ENTERPRISE, compare=lambda s: pairs([312, 235, 278, 190]))
        out, _ = self.run_agent(ENTERPRISE, tools, [
            plan_turn(tables=["sales_orders", "shipments"]),
            conclude("CHOICE", ["sales_orders"], [issue("choice", "late", readings=[
                rd("shipped after promised", "shipments", "ship_date", "SELECT 1"),
                rd("delivered after promised", "sales_orders", "promised_date", "SELECT 2"),
                rd("work order late", "work_orders", "actual_end", "SELECT 3"),
                rd("status late", "sales_orders", "status_code", "SELECT 4")])])])
        self.assertEqual(verdict(out), coverage.NEEDS_CHOICE)
        self.assertEqual(len(out.options), 4)

    def test_a_reading_no_join_reaches_is_set_aside(self):
        tools = Tools(ENTERPRISE, compare=lambda s: pairs([10, 20, 30][:len(s)]))
        c = conclusion("CHOICE", ["sales_orders"], [issue("choice", "late", readings=[
            rd("a", "sales_orders", "promised_date", "SELECT 1"),
            rd("b", "shipments", "ship_date", "SELECT 2"),
            rd("c", "machines", "name", "SELECT 3")])])
        v = va.Verifier(ENTERPRISE, tools, settings())
        first = v.check(c, va.Notebook("q?"), False)
        self.assertIsNone(first.outcome)
        self.assertTrue(any("machines" in f for f in first.feedback))
        last = v.check(c, va.Notebook("q?"), True)
        self.assertEqual(verdict(last.outcome), coverage.NEEDS_CHOICE)
        self.assertEqual([o.table for o in last.outcome.options], ["sales_orders", "shipments"])

    def test_q09_most_reliable_is_a_choice_when_the_tops_differ(self):
        view = SHOP
        tools = Tools(view, compare=lambda s: pairs([1, 1]))
        readings = [rd("on time", "receipts", "promised", "SELECT 1"),
                    rd("rating", "suppliers", "rating", "SELECT 2")]
        out, _ = self.run_agent(view, tools, [
            plan_turn(tables=["suppliers", "receipts"]),
            conclude("CHOICE", ["suppliers"], [issue("choice", "most reliable", readings=readings)])])
        self.assertEqual(verdict(out), coverage.NEEDS_CHOICE)
        same = Tools(view, compare=lambda s: pairs([1, 1], same={(0, 1)}))
        out, _ = self.run_agent(view, same, [
            plan_turn(tables=["suppliers", "receipts"]),
            conclude("CHOICE", ["suppliers"], [issue("choice", "most reliable", readings=readings)])])
        self.assertEqual(verdict(out), coverage.ANSWERABLE)


# ------------------------------------------------------------------ time

def moment(column, has_time, type_="datetime"):
    return {"column": column, "type": type_, "min": "2023-01-01", "max": "2026-09-30",
            "nulls": 0, "has_time": has_time}


TICKETS = View({"tickets": ["ticket_id", "status", "priority", "opened_at", "closed_on"],
                "ticket_status_history": ["ticket_id", "status", "valid_from", "valid_to"],
                "events": ["event_id", "event_type", "occurred_at", "parent_event_id",
                           "ticket_id"]},
               joins=[("ticket_status_history", "tickets",
                       "ticket_status_history.ticket_id = tickets.ticket_id"),
                      ("events", "tickets", "events.ticket_id = tickets.ticket_id")])

NO_HISTORY = {"tickets": {"moments": [moment("opened_at", True), moment("closed_on", False, "date")],
                          "intervals": [], "history_tables": [], "event_type": None,
                          "parent_links": []}}
WITH_HISTORY = {"ticket_status_history": {
    "moments": [moment("valid_from", False, "date"), moment("valid_to", False, "date")],
    "intervals": [["valid_from", "valid_to"]], "history_tables": [], "event_type": None,
    "parent_links": []}, **NO_HISTORY}
EVENTS = {"events": {"moments": [moment("occurred_at", True)], "intervals": [],
                     "history_tables": [], "event_type": "event_type",
                     "parent_links": []}, **NO_HISTORY}
LINKED = {"events": dict(EVENTS["events"], parent_links=["parent_event_id"]), **NO_HISTORY}


class TimeTests(unittest.TestCase):
    """The time grid of the temporal note, checked on time_columns facts."""

    def check(self, question, time, tables, facts, final=False, columns=(), relations=()):
        nb = va.Notebook(question)
        nb.reading = dict(reading(tables, time=time), time_relations=list(relations))
        tools = Tools(TICKETS, time=facts)
        out = va.Verifier(TICKETS, tools, settings()).check(
            conclusion("ANSWER", tables, columns=columns), nb, final)
        return out, tools

    def test_a_state_at_a_date_needs_a_history(self):
        q = "How many tickets were open on 1 March 2026?"
        first, _ = self.check(q, "as_of", ["tickets"], NO_HISTORY)
        self.assertIsNone(first.outcome)
        self.assertTrue(any("only the current state" in f for f in first.feedback))
        last, _ = self.check(q, "as_of", ["tickets"], NO_HISTORY, final=True)
        self.assertEqual(verdict(last.outcome), coverage.NEEDS_MORE)
        self.assertIn("only the current state is stored", coverage.classify(last.outcome)[1])
        held, _ = self.check(q, "as_of", ["tickets", "ticket_status_history"], WITH_HISTORY)
        self.assertEqual(verdict(held.outcome), coverage.ANSWERABLE)

    def test_hours_need_a_time_of_day(self):
        q = "What is the average time in hours between opening and closing a ticket?"
        cols = [{"table": "tickets", "column": "opened_at", "role": "time"},
                {"table": "tickets", "column": "closed_on", "role": "time"}]
        out, _ = self.check(q, "duration", ["tickets"], NO_HISTORY, final=True, columns=cols)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        self.assertIn("tickets.closed_on", coverage.classify(out.outcome)[1])
        # in days, a date is enough
        out, _ = self.check("How many days does a ticket stay open on average?",
                            "duration", ["tickets"], NO_HISTORY, final=True, columns=cols)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)

    def test_a_sequence_needs_an_ordered_record(self):
        q = "Which tickets were reassigned after being escalated?"
        out, _ = self.check(q, "sequence", ["tickets"],
                            {"tickets": dict(NO_HISTORY["tickets"],
                                             moments=[moment("opened_at", True)])}, final=True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        out, _ = self.check(q, "sequence", ["events"], EVENTS, final=True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)

    def test_a_cause_needs_a_parent_link_not_only_an_order(self):
        q = "Which escalations were triggered by a reopening?"
        out, _ = self.check(q, "sequence", ["events"], EVENTS, final=True,
                            relations=["parent"])
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        self.assertIn("not linked", coverage.classify(out.outcome)[1])
        out, _ = self.check(q, "sequence", ["events"], LINKED, final=True,
                            relations=["parent"])
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)

    def test_a_question_without_time_reads_no_time_columns(self):
        out, tools = self.check("How many tickets are there?", "none", ["tickets"], NO_HISTORY)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)
        self.assertFalse([c for c in tools.calls if c[0] == "time_columns"])

    def test_time_facts_that_cannot_be_read_change_nothing(self):
        out, _ = self.check("How many tickets were open on 1 March?", "as_of",
                            ["tickets"], {}, final=True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)
        self.assertTrue(any(c["status"] == "unread" for c in out.checks))

    def test_an_issue_already_raised_is_not_doubled(self):
        nb = va.Notebook("How many tickets were open on 1 March?")
        nb.reading = reading(["tickets"], time="as_of")
        tools = Tools(TICKETS, time=NO_HISTORY)
        c = conclusion("NEEDS_MORE", ["tickets"], [issue(
            "asker_must_say", "on 1 March", what="the state on 1 March, which is not stored")])
        out = va.Verifier(TICKETS, tools, settings()).check(c, nb, True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        self.assertFalse([x for x in tools.calls if x[0] == "time_columns"])


# ----------------------------------------------------------- the review

class ReviewTests(unittest.TestCase):
    """The defects an independent review found, each pinned by a test."""

    def test_a_count_check_reads_the_count_not_its_one_row(self):
        # SELECT COUNT(*) returns one row; that row holds 0: nothing matches
        c = conclusion("NO_DATA", ["orders"], [issue(
            "no_matching_row", "2020", what="orders of 2020",
            check_sql="SELECT COUNT(*) FROM orders WHERE YEAR(order_date)=2020")])
        v = va.Verifier(SHOP, Tools(SHOP, counts={"2020": 0}), settings())
        self.assertEqual(verdict(v.check(c, va.Notebook("q"), False).outcome), coverage.NO_DATA)
        # and a SELECT of the rows: no row returned confirms it too
        c2 = conclusion("NEEDS_MORE", ["orders"], [issue(
            "asker_must_say", "rate for 2027", what="the 2027 rate",
            check_sql="SELECT * FROM rates WHERE year = 2027")])
        v2 = va.Verifier(SHOP, Tools(SHOP, counts={"2027": 0}), settings())
        self.assertEqual(verdict(v2.check(c2, va.Notebook("q"), False).outcome),
                         coverage.NEEDS_MORE)

    def test_a_count_the_database_could_not_give_confirms_nothing(self):
        c = conclusion("NO_DATA", ["orders"], [issue(
            "no_matching_row", "2020", what="orders of 2020",
            check_sql="SELECT * FROM orders o JOIN customers c ON c.customer_id = o.customer_id WHERE y = 2020")])
        v = va.Verifier(SHOP, Tools(SHOP, counts={"2020": None}), settings())
        out = v.check(c, va.Notebook("q"), True)
        self.assertNotEqual(verdict(out.outcome), coverage.NO_DATA)
        self.assertTrue(any(ch["status"] == "unread" for ch in out.checks))
        c2 = conclusion("NEEDS_MORE", ["orders"], [issue(
            "asker_must_say", "rate for 2027", what="the 2027 rate",
            check_sql="SELECT * FROM rates r JOIN orders o ON 1=1 WHERE year = 2027")])
        v2 = va.Verifier(SHOP, Tools(SHOP, counts={"2027": None}), settings())
        out2 = v2.check(c2, va.Notebook("q"), True).outcome
        self.assertEqual(verdict(out2), coverage.NEEDS_MORE)      # kept, unconfirmed

    def test_one_reading_that_cannot_run_does_not_sink_the_choice(self):
        # E35 live: three readings of "late", one naming a column its table
        # lacks; the two that run differ, so it is still a choice
        def compare(sqls):
            if any("bad" in s for s in sqls):
                return None
            return pairs([285, 312][:len(sqls)])
        tools = Tools(ENTERPRISE, compare=compare, counts={"good1": 285, "good2": 312})
        c = conclusion("CHOICE", ["sales_orders"], [issue("choice", "late", readings=[
            rd("work orders", "work_orders", "actual_end", "SELECT wo FROM good1"),
            rd("sales orders", "sales_orders", "promised_date", "SELECT id FROM good2"),
            rd("maintenance", "sales_orders", "status_code", "SELECT order_id FROM bad")])])
        out = va.Verifier(ENTERPRISE, tools, settings()).check(c, va.Notebook("q"), True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_CHOICE)
        self.assertEqual(len(out.outcome.options), 2)
        self.assertTrue(any(ch["check"] == "choice_reading" for ch in out.checks))

    def test_a_declared_refusal_without_an_issue_is_never_verified(self):
        c = conclusion("NOT_COVERED", ["orders"],
                       reason="The database has no table about employee engagement surveys.")
        tools = Tools(SHOP, absent={"x": (True, True, [])})
        v = va.Verifier(SHOP, tools, settings())
        first = v.check(c, va.Notebook("q"), False)
        self.assertIsNone(first.outcome)
        last = v.check(c, va.Notebook("q"), True)
        self.assertEqual(verdict(last.outcome), coverage.NEEDS_MORE)
        self.assertFalse(last.outcome.checked)
        # nothing was swept for a sentence
        self.assertFalse([x for x in tools.calls if x[0] == "absent_everywhere"])
        self.assertTrue(any(x["to"] == "asker_must_say" for x in last.coercions))

    def test_a_refusal_sweeps_the_question_words_and_names_them(self):
        c = conclusion("NOT_COVERED", ["products"], [issue(
            "absent_from_database", "audiobooks",
            what="the format of each product, which is recorded nowhere in this schema")])
        tools = Tools(SHOP, absent={"audiobooks": (True, True, [])})
        out = va.Verifier(SHOP, tools, settings()).check(c, va.Notebook("q"), False).outcome
        self.assertEqual(verdict(out), coverage.NOT_COVERED)
        self.assertEqual(out.question, "Nothing in the database holds audiobooks.")

    def test_counts_stay_with_their_reading_when_one_is_merged(self):
        # A and B give the same rows; C its own 99
        tools = Tools(SHOP, compare=lambda s: {
            "results": [{"i": 0, "count": 10}, {"i": 1, "count": 10}, {"i": 2, "count": 99}],
            "pairs": [{"a": 0, "b": 1, "same": True, "share": 0.0},
                      {"a": 0, "b": 2, "same": False, "only_a": 50, "only_b": 0, "share": 0.4},
                      {"a": 1, "b": 2, "same": False, "only_a": 50, "only_b": 0, "share": 0.4}]})
        c = conclusion("CHOICE", ["orders"], [issue("choice", "date", readings=[
            rd("A", "orders", "order_date", "SELECT 1"),
            rd("B", "orders", "order_date", "SELECT 2"),
            rd("C", "orders", "promised_date", "SELECT 3")])])
        out = va.Verifier(SHOP, tools, settings()).check(c, va.Notebook("q"), True).outcome
        self.assertIn("C: 99 rows", out.reason)
        self.assertNotIn("C: 10 rows", out.reason)

    def test_a_kind_that_contradicts_the_issue_is_replaced(self):
        c = conclusion("NOT_COVERED", ["products"], [issue(
            "absent_from_database", "audiobooks", what="audiobooks", kind="AmbiSchema")])
        tools = Tools(SHOP, absent={"audiobooks": (True, True, [])})
        out = va.Verifier(SHOP, tools, settings()).check(c, va.Notebook("q"), False).outcome
        self.assertEqual(out.kind, "AmbiFallacy")

    def test_ordinary_words_are_not_looked_up_as_values(self):
        tools = Tools(SHOP)
        c = conclusion("NEEDS_MORE", ["orders"], [issue(
            "asker_must_say", "the most important", what="what important means",
            kind="AmbiContext")])
        va.Verifier(SHOP, tools, settings()).check(c, va.Notebook("q"), True)
        looked = [x[1]["value"] for x in tools.calls if x[0] == "find_value"]
        self.assertEqual(looked, ["important"])

    def test_a_tool_that_raises_in_the_verifier_is_a_check_that_failed(self):
        tools = Tools(SHOP)

        def boom(_sqls):
            raise RuntimeError("database gone")
        tools.compare_readings = boom
        c = conclusion("CHOICE", ["orders"], [issue("choice", "date", readings=[
            rd("a", "orders", "order_date", "SELECT 1"),
            rd("b", "orders", "promised_date", "SELECT 2")])])
        out = va.Verifier(SHOP, tools, settings()).check(c, va.Notebook("q"), True)
        # unsure is NEEDS MORE: a choice the facts could not settle is never
        # an answer (review of 26 October)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        self.assertTrue(any(ch["status"] == "failed" for ch in out.checks))

    def test_any_failure_is_an_error_with_its_trace(self):
        model = Model([], raises=TypeError("bad call"))
        a = agent(model, SHOP, Tools(SHOP))
        out = a.clarify("q?")
        self.assertEqual(out.action, "ERROR")
        self.assertIn("TypeError", out.reason)
        self.assertEqual(a.last_trace["stopped_by"], "error")
        self.assertEqual(a.last_trace["mode"], "agent")

    def test_a_failure_while_setting_up_still_leaves_an_agent_trace(self):
        def broken(*_a):
            raise RuntimeError("no toolbox")
        clar = SimpleNamespace(llm=Model([]), _llm=None, profile=None)
        a = va.VerdictAgent(clar, view=SHOP, settings=settings(), system="S", toolbox=broken)
        out = a.clarify("q?")
        self.assertEqual(out.action, "ERROR")
        self.assertEqual(a.last_trace["mode"], "agent")
        self.assertEqual(a.last_trace["stopped_by"], "error")

    def test_an_overflow_without_thinking_is_asked_again_with_less(self):
        model = Model([plan_turn(), conclude()], can_think=False, overflow_on={0},
                      overflow_always=True)
        out = agent(model, SHOP, Tools(SHOP, search=list(SHOP.tables))).clarify("q?")
        self.assertEqual(out.action, "ANSWER")
        self.assertNotIn("COULD NOT BE USED", model.sent[1]["user"])
        self.assertLessEqual(len(model.sent[1]["user"]), len(model.sent[0]["user"]))

    def test_at_the_cap_without_a_conclusion_the_question_is_judged_again(self):
        self.assertEqual(va.Verifier.no_conclusion().action, "ERROR")

    def test_num_predict_is_not_sent_to_a_model_that_cannot_take_it(self):
        class Plain(Model):
            def json(self, system, user, schema=None):
                return Model.json(self, system, user, schema=schema)
        model = Plain([plan_turn(), conclude()])
        agent(model, SHOP, Tools(SHOP)).clarify("q?")
        self.assertNotIn("num_predict", model.sent[0]["kw"])
        self.assertNotIn("timeout", model.sent[0]["kw"])

    def test_every_call_is_bounded_by_the_time_left(self):
        model = Model([plan_turn(), conclude()])
        agent(model, SHOP, Tools(SHOP), max_seconds=300).clarify("q?")
        self.assertLessEqual(model.sent[0]["kw"]["timeout"], 300)
        self.assertGreaterEqual(model.sent[0]["kw"]["timeout"], 30)

    def test_a_small_window_does_not_think(self):
        model = Model([plan_turn(), conclude()], num_ctx=6000)
        agent(model, SHOP, Tools(SHOP)).clarify("q?")
        self.assertFalse(model.sent[0]["think"])

    def test_a_stop_between_turns_stops_the_question_and_says_so(self):
        ev = threading.Event()

        def stop_then_reply(user, schema):
            ev.set()
            return plan_turn()
        model = Model([stop_then_reply, conclude()])
        a = agent(model, SHOP, Tools(SHOP))
        a.cancel_event = ev
        with self.assertRaises(va.AgentCancelled):
            a.clarify("q?")
        self.assertEqual(a.last_trace["stopped_by"], "cancel")

    def test_size_only_shows_the_size_and_reads_nothing_in_full(self):
        model = Model([plan_turn(), call("describe_tables", names=["orders"], mode="size"),
                       conclude()])
        tools = Tools(SHOP)
        a = agent(model, SHOP, tools)
        a.clarify("q?")
        self.assertIn("size only", model.sent[2]["user"])
        self.assertNotIn("orders", a.last_trace["tables_seen"])
        sent = [x[1] for x in tools.calls if x[0] == "describe_tables"]
        self.assertTrue(all("mode" not in args for args in sent))

    def test_deciding_again_does_not_show_the_rejected_conclusion(self):
        nb = va.Notebook("q")
        nb.thought = "it is a CHOICE between the two dates"
        nb.plan = [{"do": "compare the two dates", "status": "done"},
                   {"do": "conclude CHOICE", "status": "todo"}]
        nb.forget_conclusion()
        self.assertEqual(nb.thought, "")
        self.assertEqual([p["do"] for p in nb.plan], ["compare the two dates"])

    def test_results_that_do_not_fit_wait_for_the_next_turn(self):
        b = va.Budget(Model([], num_ctx=4096), "SYSTEM", settings())
        nb = va.Notebook("q")
        for i in range(9):
            nb.record(va.Step(n=i, phase="probing", tool="sample_values", args={"column": f"c{i}"},
                              result=Result("sample_values", digest=f"d{i}", text="v" * 9000)))
        text, shown = b.fit(nb, 2, 8, 300, thinks=False)
        self.assertLessEqual(b.estimate(text), b.room(False))
        self.assertTrue(0 < len(shown) < 9)
        self.assertIn("shown in full next turn", text)
        self.assertNotIn("Conclude now", text)

    def test_the_prompt_names_every_tool_and_reading_field(self):
        import prompts
        for tool in va.AGENT_TOOLS:
            self.assertIn(tool, prompts.AGENT_SYSTEM)
        for key in va.READING["required"]:
            self.assertIn(key, prompts.AGENT_SYSTEM)
        for field_ in ("phrase", "what", "check_sql", "AmbiRef", "AmbiSource"):
            self.assertIn(field_, prompts.AGENT_SYSTEM)

    def test_the_budget_learns_upwards_from_a_reply_without_thinking(self):
        b = va.Budget(Model([]), "SYSTEM", settings())
        m = SimpleNamespace(last_prompt_tokens=2000)
        b.learn(m, "x" * 2700, thought=False)        # estimated about 1000
        self.assertGreater(b.scale, 1.5)
        before = b.scale
        b.learn(SimpleNamespace(last_prompt_tokens=10), "x" * 2700, thought=False)
        self.assertEqual(b.scale, before)            # never down within a question
        b2 = va.Budget(Model([]), "SYSTEM", settings())
        b2.learn(m, "x" * 2700, thought=True)
        self.assertEqual(b2.scale, 1.0)


class TimeBudgetTests(unittest.TestCase):
    """The question's time: the conclusion always comes."""

    class Slow(Model):
        """A model whose calls take `seconds` on a shared clock, and which
        times out on the calls listed in `expire`."""

        def __init__(self, replies, clock, seconds=100, expire=(), **kw):
            super().__init__(replies, **kw)
            self.clock, self.seconds, self.expire = clock, seconds, set(expire)

        def json(self, system, user, schema=None, **kw):
            n = len(self.sent)
            self.clock[0] += self.seconds
            if n in self.expire:
                self.sent.append({"system": system, "user": user, "schema": schema,
                                  "kw": kw, "think": self.thinks()})
                self.last_server = {}
                self.last_error = "http://x did not answer: timed out after 60 s"
                return None
            return Model.json(self, system, user, schema=schema, **kw)

    def run_slow(self, replies, expire=(), seconds=100, **kw):
        clock = [0.0]
        model = self.Slow(replies, clock, seconds=seconds, expire=expire)
        a = agent(model, SHOP, Tools(SHOP), **kw)
        a.clock = lambda: clock[0]
        return a.clarify("q?"), model, a

    def test_an_exploring_call_that_expires_leads_to_the_conclusion(self):
        out, model, a = self.run_slow(
            [plan_turn(), call("sample_values", table="orders", column="status"),
             {"conclusion": conclusion("ANSWER", ["orders"])}], expire={1})
        self.assertEqual(out.action, "ANSWER")
        self.assertIs(model.sent[-1]["schema"], va.CONCLUSION_SCHEMA)
        self.assertEqual(a.last_trace["stopped_by"], "time_cap")

    def test_a_conclusion_that_expires_is_asked_again_without_thinking(self):
        out, model, _a = self.run_slow(
            [plan_turn(), {"conclusion": conclusion("ANSWER", ["orders"])}],
            expire={1}, max_turns=2)
        self.assertEqual(out.action, "ANSWER")
        self.assertFalse(model.sent[-1]["think"])

    def test_the_conclusion_is_given_the_time_it_needs(self):
        out, model, _a = self.run_slow(
            [plan_turn(), call("sample_values", table="orders", column="status"),
             call("sample_values", table="orders", column="status"),
             {"conclusion": conclusion("ANSWER", ["orders"])}],
            seconds=150, max_seconds=600)
        self.assertEqual(out.action, "ANSWER")
        last = model.sent[-1]
        self.assertIs(last["schema"], va.CONCLUSION_SCHEMA)
        self.assertGreaterEqual(last["kw"]["timeout"], 180)

    def test_the_reserve_grows_with_the_slowest_call(self):
        a = agent(Model([]), SHOP, Tools(SHOP), max_seconds=600)
        self.assertEqual(a._margin(), 90)
        a._longest = 120
        self.assertEqual(a._margin(), 180)
        a._longest = 1000
        self.assertEqual(a._margin(), 300)       # never more than half the time


# ------------------------------------------------- the review of 20 October

STAFF = View({"employees": ["employee_id", "department_id", "status_code",
                            "termination_date"],
              "departments": ["department_id", "name"],
              "support_tickets": ["ticket_id", "resolved_at", "closed_at"],
              "members": ["member_id", "member_since", "birth_date"],
              "categories": ["category_id", "name"],
              "products": ["product_id", "category_id", "price"],
              "active_products_summary": ["category_name", "product_count"],
              "exchange_rates": ["rate_id", "from_currency", "to_currency",
                                 "rate_date", "rate"]},
             joins=[("employees", "departments",
                     "employees.department_id = departments.department_id"),
                    ("products", "categories",
                     "products.category_id = categories.category_id")])
STAFF.views = {"active_products_summary"}


class WordingTests(unittest.TestCase):
    """Cause 1: a choice the facts confirm is still asked of the question's
    words, without a model first, then in a fresh context."""

    ACTIVE = [rd("by status", "employees", "status_code",
                 "SELECT department_id, COUNT(*) FROM employees WHERE status_code = 'ACTIVE' "
                 "GROUP BY department_id"),
              rd("by termination", "employees", "termination_date",
                 "SELECT department_id, COUNT(*) FROM employees WHERE termination_date IS NULL "
                 "GROUP BY department_id")]

    def check(self, phrase, readings, tables, meaning=None, final=True, question="q?"):
        tools = Tools(STAFF, compare=lambda s: pairs([12, 9]))
        c = conclusion("CHOICE", tables, [issue("choice", phrase, readings=readings)])
        v = va.Verifier(STAFF, tools, settings(), meaning=meaning)
        return v.check(c, va.Notebook(question), final), v

    def test_a_stored_value_the_question_names_selects_its_reading(self):
        out, _ = self.check("active employees", self.ACTIVE, ["employees", "departments"])
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)
        self.assertIn('"active" names by status', out.outcome.reason)
        self.assertTrue(any(c["check"] == "wording" and c["status"] == "named"
                            for c in out.checks))

    def test_a_column_name_alone_decides_nothing_without_the_model(self):
        # "resolve" and resolved_at is the closed question's to weigh, as is
        # "year" and fiscal_year or "price" and list_price against unit_cost
        readings = [rd("time to fix", "support_tickets", "resolved_at", "SELECT 1"),
                    rd("time to closure", "support_tickets", "closed_at", "SELECT 2")]
        out, _ = self.check("resolve a support ticket", readings, ["support_tickets"])
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_CHOICE)
        out, _ = self.check("resolve a support ticket", readings, ["support_tickets"],
                            meaning=by_label("time to fix", "resolve names resolved_at"))
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)

    def test_a_value_the_other_reading_also_mentions_settles_nothing(self):
        readings = [rd("net", "employees", "status_code",
                       "SELECT SUM(net) FROM employees WHERE status_code = 'ACTIVE'"),
                    rd("gross", "employees", "termination_date",
                       "SELECT SUM(gross) FROM employees WHERE is_active = 1")]
        out, _ = self.check("revenue of active customers", readings, ["employees"])
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_CHOICE)

    def test_only_the_readings_tables_name_the_entity(self):
        # a table elsewhere named for "active" must not hide the word
        view = View({"employees": ["employee_id", "status_code", "termination_date"],
                     "status_active": ["id"]})
        tools = Tools(view, compare=lambda s: pairs([12, 9]))
        c = conclusion("CHOICE", ["employees"], [issue("choice", "active employees",
                                                       readings=self.ACTIVE)])
        out = va.Verifier(view, tools, settings()).check(c, va.Notebook("q?"), True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)

    def test_a_code_is_named_by_its_label_in_the_dictionary(self):
        view = View({"abs_point": ["point_id", "cat_code", "kind_code"]})
        view.columns_of = lambda t: [(c, "varchar") for c in view.tables[t]]
        tools = Tools(view, compare=lambda s: pairs([12, 9]))
        tools.clar = SimpleNamespace(enum_labels=lambda t, c: (
            {"CARTPT": "CARTESIAN-POINT", "GEOGPT": "GEOGRAPHIC-POINT"} if c == "cat_code"
            else {}))
        readings = [rd("by category", "abs_point", "cat_code",
                       "SELECT point_id FROM abs_point WHERE cat_code = 'CARTPT'"),
                    rd("by kind", "abs_point", "kind_code",
                       "SELECT point_id FROM abs_point WHERE kind_code = 'X'")]
        c = conclusion("CHOICE", ["abs_point"], [issue("choice", "cartesian points",
                                                       readings=readings)])
        out = va.Verifier(view, tools, settings()).check(c, va.Notebook("q?"), True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)
        self.assertIn('"cartesian" names by category', out.outcome.reason)

    def test_the_entity_asked_about_tells_no_reading_apart(self):
        readings = [rd("seniority", "members", "member_since", "SELECT 1"),
                    rd("age", "members", "birth_date", "SELECT 2")]
        out, _ = self.check("oldest members", readings, ["members"])
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_CHOICE)

    def test_a_word_both_readings_name_settles_nothing(self):
        readings = [rd("open status", "employees", "status_code",
                       "SELECT 1 FROM employees WHERE status_code = 'OPEN'"),
                    rd("open states", "employees", "status_code",
                       "SELECT 1 FROM employees WHERE status_code IN ('OPEN', 'NEW')")]
        out, _ = self.check("still open", readings, ["employees"])
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_CHOICE)

    def test_the_closed_question_can_settle_a_choice(self):
        asked = []

        def meaning(question, phrase, readings):
            asked.append((question, phrase, [r["label"] for r in readings]))
            return [r["label"] for r in readings].index("summary"), "the other reads a summary"
        readings = [rd("records", "employees", "employee_id", "SELECT 1"),
                    rd("summary", "employees", "department_id", "SELECT 2")]
        out, _ = self.check("headcount", readings, ["employees"], meaning=meaning,
                            question="What is the headcount?")
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)
        self.assertIn("means summary", out.outcome.reason)
        # asked in both orders, and the same reading named both times
        self.assertEqual(asked, [("What is the headcount?", "headcount", ["records", "summary"]),
                                 ("What is the headcount?", "headcount", ["summary", "records"])])

    def test_a_reading_named_in_one_order_only_keeps_the_choice(self):
        # E62, Library Q10, Warehouse Q10 (23 October): a single answer,
        # leaning to the first place, dropped real choices
        readings = [rd("first filing", "employees", "employee_id", "SELECT 1"),
                    rd("last filing", "employees", "department_id", "SELECT 2")]
        out, _ = self.check("from submitting", readings, ["employees"],
                            meaning=lambda q, p, rs: (0, "the plain sense"))
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_CHOICE)
        self.assertTrue(any(c["check"] == "wording" and c["status"] == "unsure"
                            for c in out.checks))

    def test_the_measure_never_names_a_stored_value(self):
        # E36, 23 October: REVENUE, a ledger account type, took "revenue"
        readings = [rd("invoiced", "employees", "employee_id",
                       "SELECT SUM(net) FROM employees"),
                    rd("ledger", "employees", "department_id",
                       "SELECT SUM(amount) FROM employees WHERE account_type = 'REVENUE'")]
        tools = Tools(STAFF, compare=lambda s: pairs([12, 9]))
        c = conclusion("CHOICE", ["employees"], [issue("choice", "revenue", readings=readings)])
        nb = va.Notebook("What was our revenue last year?")
        nb.reading = dict(reading(["employees"]), measure="revenue")
        out = va.Verifier(STAFF, tools, settings()).check(c, nb, True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_CHOICE)
        nb.reading = dict(reading(["employees"]), measure="amount")
        out = va.Verifier(STAFF, tools, settings()).check(c, nb, True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)

    def test_a_real_choice_stays_and_a_failing_check_keeps_it(self):
        readings = [rd("list", "products", "price", "SELECT 1"),
                    rd("cost", "products", "product_id", "SELECT 2")]
        out, _ = self.check("most expensive", readings, ["products"], meaning=lambda *a: None)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_CHOICE)
        self.assertTrue(any(c["check"] == "wording" and c["status"] == "choose"
                            for c in out.checks))

        def broken(*a):
            raise RuntimeError("model down")
        out, _ = self.check("most expensive", readings, ["products"], meaning=broken)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_CHOICE)

    def test_the_closed_question_is_asked_once_per_choice(self):
        calls = []
        readings = [rd("list", "products", "price", "SELECT 1"),
                    rd("cost", "products", "product_id", "SELECT 2")]
        tools = Tools(STAFF, compare=lambda s: pairs([12, 9]))
        c = conclusion("CHOICE", ["products"], [issue("choice", "most expensive",
                                                      readings=readings)])
        v = va.Verifier(STAFF, tools, settings(),
                        meaning=lambda *a: calls.append(a) or None)
        v.check(c, va.Notebook("q?"), False)
        v.check(c, va.Notebook("q?"), True)
        self.assertEqual(len(calls), 1)

    def test_the_agent_asks_in_a_fresh_context_without_thinking(self):
        choice = conclude("CHOICE", ["employees", "departments"], [issue(
            "choice", "headcount", readings=[
                rd("records", "employees", "employee_id", "SELECT 1"),
                rd("summary", "employees", "department_id", "SELECT 2")])])
        # the same reading named in both orders: A first, then B reversed
        model = Model([plan_turn(), choice,
                       {"choose": False, "reading": "A", "why": "B adds a summary"},
                       {"choose": False, "reading": "B", "why": "A adds a summary"}])
        tools = Tools(STAFF, compare=lambda s: pairs([12, 9]))
        a = agent(model, STAFF, tools, wording=True)
        out = a.clarify("What is the headcount per department?")
        self.assertEqual(verdict(out), coverage.ANSWERABLE)
        self.assertIn("READING A: summary", model.sent[-1]["user"])
        asked = model.sent[-2]
        import prompts
        self.assertIs(asked["system"], prompts.AGENT_WORDING)
        self.assertEqual(asked["schema"], va.WORDING_SCHEMA)
        self.assertFalse(asked["think"])
        self.assertIn("READING B: summary", asked["user"])
        self.assertNotIn("YOUR PLAN", asked["user"])    # never the agent's notebook
        self.assertTrue(any(t["phase"] == "wording" for t in a.last_trace["turns"]))
        # every entry says what it is, the side question no turn
        kinds = [t.get("kind") for t in a.last_trace["turns"]]
        self.assertLessEqual(set(kinds), {"turn", "tool", "wording", "values", "ranking"})
        self.assertIn("wording", kinds)
        self.assertIn("turn", kinds)

    def test_the_agent_keeps_a_choice_the_words_leave_open(self):
        choice = conclude("CHOICE", ["employees", "departments"], [issue(
            "choice", "headcount", readings=[
                rd("records", "employees", "employee_id", "SELECT 1"),
                rd("summary", "employees", "department_id", "SELECT 2")])])
        model = Model([plan_turn(), choice,
                       {"choose": True, "reading": "", "why": "both fit"}])
        tools = Tools(STAFF, compare=lambda s: pairs([12, 9]))
        out = agent(model, STAFF, tools, wording=True).clarify("q?")
        self.assertEqual(verdict(out), coverage.NEEDS_CHOICE)

    def test_without_the_setting_no_question_is_asked(self):
        choice = conclude("CHOICE", ["employees", "departments"], [issue(
            "choice", "headcount", readings=[
                rd("records", "employees", "employee_id", "SELECT 1"),
                rd("summary", "employees", "department_id", "SELECT 2")])])
        model = Model([plan_turn(), choice])
        tools = Tools(STAFF, compare=lambda s: pairs([12, 9]))
        out = agent(model, STAFF, tools, wording=False).clarify("q?")
        self.assertEqual(verdict(out), coverage.NEEDS_CHOICE)
        self.assertEqual(len(model.sent), 2)

    def test_the_wording_prompt_is_registered(self):
        import prompts
        self.assertIn("agent_wording", prompts.VERSIONS)
        self.assertNotIn("unregistered", prompts.version_of("agent_wording"))


class ReviewOctober20Tests(unittest.TestCase):
    """Causes 2 to 5: dated series, absences, thresholds, views."""

    def nb(self, question="q?", **reading_fields):
        nb = va.Notebook(question)
        nb.reading = dict(reading(), **reading_fields)
        return nb

    # cause 2
    def test_a_row_per_date_is_a_history_when_the_conclusion_reads_its_date(self):
        facts = {"exchange_rates": {
            "moments": [moment("rate_date", False, "date")], "intervals": [],
            "history_tables": [], "event_type": None, "parent_links": []}}
        facts["exchange_rates"]["moments"][0].update(min="2023-01-01", max="2026-09-30")
        tools = Tools(STAFF, time=facts)
        self.addCleanup(lambda: STAFF.__dict__.pop("profile", None))
        STAFF.profile = {"exchange_rates": {"rate_date": {"rows": 1149, "distinct": 49}}}
        self.addCleanup(lambda: STAFF.__dict__.pop("columns_of", None))
        STAFF.columns_of = lambda t: [(c, "decimal(14,6)" if c == "rate" else "date"
                                       if c == "rate_date" else "int") for c in STAFF.tables[t]]
        cols = [{"table": "exchange_rates", "column": "rate_date", "role": "filter"},
                {"table": "exchange_rates", "column": "rate", "role": "measure"}]
        nb = self.nb("What was the EUR to USD rate at the end of June 2026?",
                     tables=["exchange_rates"], time="as_of")
        out = va.Verifier(STAFF, tools, settings()).check(
            conclusion("ANSWER", ["exchange_rates"], columns=cols), nb, True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)
        self.assertTrue(any("dated by exchange_rates.rate_date" in c["detail"]
                            for c in out.checks))
        # the same table, its date not used: nothing says the value was kept
        out = va.Verifier(STAFF, tools, settings()).check(
            conclusion("ANSWER", ["exchange_rates"], columns=cols[1:]), nb, True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)

    # cause 3
    def test_the_term_swept_is_the_distinctive_words(self):
        term = va.Verifier._term
        self.assertEqual(term({"phrase": "Which patents protect our compressor designs?",
                               "what": "patent records or intellectual property data"},
                              {"measure": "patents"}), "patents")
        self.assertEqual(term({"phrase": "employee engagement score", "what": "x y z w"}),
                         "employee engagement score")
        self.assertEqual(term({"phrase": "the patents of our designs of 2024 in Europe",
                               "what": ""}, {}), "patents designs 2024 Europe")
        self.assertEqual(term({"phrase": "", "what": ""}, {}), "")

    def test_an_echo_of_the_kind_alone_is_said_in_the_check(self):
        tools = Tools(STAFF, absent={"engagement score": (True, True, [])})
        tools.last_echoes = [{"table": "surveys", "column": "nps_score", "how": "token"}]
        c = conclusion("NOT_COVERED", ["employees"], [issue(
            "absent_from_database", "engagement score", what="engagement score")])
        out = va.Verifier(STAFF, tools, settings()).check(c, self.nb(), True)
        self.assertEqual(verdict(out.outcome), coverage.NOT_COVERED)
        self.assertTrue(any("echoes of its kind only" in c["detail"] for c in out.checks))

    # cause 4
    def test_rows_never_settle_a_threshold_the_reading_names(self):
        tools = Tools(STAFF, counts={"ORDER BY price": 10})
        c = conclusion("NEEDS_MORE", ["products"], [issue(
            "asker_must_say", "cheap", what="the price under which a product is cheap",
            check_sql="SELECT price FROM products ORDER BY price LIMIT 10")])
        out = va.Verifier(STAFF, tools, settings()).check(
            c, self.nb("Which products are cheap?", comparisons=["cheap"]), True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        self.assertFalse([x for x in tools.calls if x[0] == "run_count"])
        self.assertTrue(any(c["status"] == "threshold" for c in out.checks))

    def test_a_threshold_stored_as_a_value_is_data(self):
        tools = Tools(STAFF, values={"cheap": [("products", "price_band", ["CHEAP"])]})
        c = conclusion("NEEDS_MORE", ["products"], [issue(
            "asker_must_say", "cheap", what="the price under which a product is cheap")])
        out = va.Verifier(STAFF, tools, settings()).check(
            c, self.nb("Which products are cheap?", comparisons=["cheap"]), True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)

    def test_a_missing_value_is_still_counted(self):
        tools = Tools(STAFF, counts={"2027": 3})
        c = conclusion("NEEDS_MORE", ["exchange_rates"], [issue(
            "asker_must_say", "budget rate for 2027", what="the 2027 budget rate",
            check_sql="SELECT rate FROM exchange_rates WHERE YEAR(rate_date) = 2027")])
        out = va.Verifier(STAFF, tools, settings()).check(c, self.nb(), True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)   # rows exist

    # cause 5
    def test_a_view_needs_no_join(self):
        c = conclusion("ANSWER", ["categories", "products", "active_products_summary"])
        out = va.Verifier(STAFF, Tools(STAFF), settings()).check(c, self.nb(), True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)
        # a real table that joins nothing still does
        c = conclusion("ANSWER", ["categories", "products", "members"])
        out = va.Verifier(STAFF, Tools(STAFF), settings()).check(c, self.nb(), True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)

    def test_a_reading_set_aside_takes_its_table_with_it(self):
        c = conclusion("CHOICE", ["categories", "products", "members"], [issue(
            "choice", "products", readings=[
                rd("all", "products", "product_id", "SELECT 1"),
                rd("members", "members", "member_id", "SELECT 2")])])
        out = va.Verifier(STAFF, Tools(STAFF), settings()).check(c, self.nb(), True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)
        self.assertFalse([x for x in out.coercions if x["to"] == "asker_must_say"])

    def test_a_reading_on_a_view_is_compared_like_any_other(self):
        tools = Tools(STAFF, compare=lambda s: pairs([12, 9]))
        c = conclusion("CHOICE", ["categories", "products"], [issue(
            "choice", "products", readings=[
                rd("all", "products", "product_id", "SELECT 1"),
                rd("summary", "active_products_summary", "product_count", "SELECT 2")])])
        v = va.Verifier(STAFF, tools, settings(),
                        meaning=by_label("all", "the summary adds a status"))
        out = v.check(c, self.nb(), False)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)
        self.assertTrue([x for x in tools.calls if x[0] == "compare_readings"])


class ReviewOfTheFixesTests(unittest.TestCase):
    """The independent review of the fixes of 20 October, finding by
    finding: each test is the scenario that failed."""

    def nb(self, question="q?", **fields):
        nb = va.Notebook(question)
        nb.reading = dict(reading(), **fields)
        return nb

    def test_the_entity_noun_is_left_out_of_the_term(self):
        # Library Q23: "copies" names a table, "braille" is what is missing
        term = va.Verifier._term
        self.assertEqual(term({"phrase": "braille copies"}, {}, {"copy"}), "braille")
        self.assertEqual(term({"phrase": "employee engagement score"}, {}, {"employee"}),
                         "engagement score")
        self.assertEqual(term({"phrase": "copies"}, {}, {"copy"}), "copies")

    def test_an_adjective_of_the_reading_is_never_swept(self):
        # Library Q09: "oldest" swept, nothing found, NOT COVERED
        term = va.Verifier._term({"phrase": "oldest", "what": "member birth date or age"},
                                 {"comparisons": ["oldest"]})
        self.assertEqual(term, "member birth date age")

    def test_a_measure_unrelated_to_the_claim_is_never_swept(self):
        term = va.Verifier._term({"phrase": "shift start and end times of employees",
                                  "what": "shift start and end time records"},
                                 {"measure": "headcount"})
        self.assertEqual(term, "shift start end times employees")

    def staff_with_types(self):
        view = View({"employees": ["employee_id", "department_id", "hire_date", "salary"],
                     "departments": ["department_id", "name"],
                     "exchange_rates": ["rate_id", "rate_date", "rate", "rate_type"]},
                    joins=[("employees", "departments",
                            "employees.department_id = departments.department_id")])
        types = {"salary": "decimal(12,2)", "rate": "decimal(14,6)", "rate_type": "varchar(10)",
                 "hire_date": "date", "rate_date": "date"}
        view.columns_of = lambda t: [(c, types.get(c, "int")) for c in view.tables[t]]
        return view

    def as_of(self, view, table, date_col, measure, profile):
        view.profile = profile
        facts = {table: {"moments": [moment(date_col, False, "date")], "intervals": [],
                         "history_tables": [], "event_type": None, "parent_links": []}}
        cols = [{"table": table, "column": date_col, "role": "filter"},
                {"table": table, "column": measure, "role": "measure"}]
        out = va.Verifier(view, Tools(view, time=facts), settings()).check(
            conclusion("ANSWER", [table], columns=cols),
            self.nb("as of a date?", tables=[table], time="as_of"), True)
        return verdict(out.outcome)

    def test_a_date_that_dates_the_row_is_no_history(self):
        view = self.staff_with_types()
        # about one employee per hire date: the salary then is not kept
        self.assertEqual(self.as_of(view, "employees", "hire_date", "salary",
                                    {"employees": {"hire_date": {"rows": 384, "distinct": 380}}}),
                         coverage.NEEDS_MORE)
        # many rates per month end: the rate at a date is kept
        self.assertEqual(self.as_of(view, "exchange_rates", "rate_date", "rate",
                                    {"exchange_rates": {"rate_date": {"rows": 1149,
                                                                      "distinct": 49}}}),
                         coverage.ANSWERABLE)

    def test_no_count_and_no_number_make_no_history(self):
        view = self.staff_with_types()
        self.assertEqual(self.as_of(view, "exchange_rates", "rate_date", "rate", {}),
                         coverage.NEEDS_MORE)        # the counts cannot be read
        self.assertEqual(self.as_of(view, "exchange_rates", "rate_date", "rate_type",
                                    {"exchange_rates": {"rate_date": {"rows": 1149,
                                                                      "distinct": 49}}}),
                         coverage.NEEDS_MORE)        # a code is no value kept at a date

    def test_the_counts_are_read_when_no_profile_has_them(self):
        view = self.staff_with_types()
        tools = Tools(view)
        sent = []
        tools.execute = lambda sql, fetch: sent.append(sql) or {"rows": [(1149, 49)]}
        v = va.Verifier(view, tools, settings())
        self.assertAlmostEqual(v._rows_per_value("exchange_rates", "rate_date"), 1149 / 49)
        self.assertIn("LIMIT 20000", sent[0])

    def test_a_table_a_column_uses_is_never_set_aside(self):
        c = conclusion("CHOICE", ["products", "members"], [issue(
            "choice", "products", readings=[
                rd("all", "products", "product_id", "SELECT 1"),
                rd("members", "members", "member_id", "SELECT 2")])],
            columns=[{"table": "products", "column": "price", "role": "measure"},
                     {"table": "members", "column": "member_id", "role": "group"}])
        out = va.Verifier(STAFF, Tools(STAFF), settings()).check(c, self.nb(), True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)

    def test_a_stopped_job_is_never_swallowed_by_the_wording_check(self):
        tools = Tools(STAFF, compare=lambda s: pairs([12, 9]))
        c = conclusion("CHOICE", ["products"], [issue("choice", "most expensive", readings=[
            rd("list", "products", "price", "SELECT 1"),
            rd("cost", "products", "product_id", "SELECT 2")])])

        def stopped(*a):
            raise va.AgentCancelled("the job was stopped")
        with self.assertRaises(va.AgentCancelled):
            va.Verifier(STAFF, tools, settings(), meaning=stopped).check(
                c, va.Notebook("q?"), True)

    def wording_agent(self, replies):
        model = Model(replies)
        a = agent(model, STAFF, Tools(STAFF), wording=True)
        a._trace_now, a._wordings = None, 0
        a._deadline = a.clock() + 5          # five seconds left
        return a, model

    READINGS = [rd("list", "products", "price", "SELECT 1"),
                rd("cost", "products", "product_id", "SELECT 2")]

    def test_the_wording_check_is_bounded_near_the_deadline(self):
        plain = {"choose": False, "reading": "A", "why": "w"}
        a, model = self.wording_agent([plain, plain, plain])
        self.assertEqual(a._wording("q?", "p", self.READINGS), (0, "w"))
        self.assertEqual(model.sent[0]["kw"]["timeout"], va.WORDING_SECONDS)
        a._wording("q?", "p", self.READINGS)
        self.assertIsNone(a._wording("q?", "p", self.READINGS))   # the third is not asked
        self.assertEqual(len(model.sent), va.MAX_WORDING_CALLS)

    def test_a_reading_named_in_words_is_read_and_garbage_keeps_the_choice(self):
        a, _ = self.wording_agent([{"choose": False, "reading": "Reading B", "why": "w"}])
        self.assertEqual(a._wording("q?", "p", self.READINGS), (1, "w"))
        a, _ = self.wording_agent([{"choose": False, "reading": "the second", "why": "w"}])
        self.assertIsNone(a._wording("q?", "p", self.READINGS))
        a, _ = self.wording_agent([{"choose": False, "reading": "D", "why": "w"}])
        self.assertIsNone(a._wording("q?", "p", self.READINGS))

    def test_a_longer_phrase_holding_a_comparison_is_counted(self):
        # E32, second run: "largest share" is a ranking, the rows decide
        tools = Tools(STAFF, counts={"machine_hours": 10})
        c = conclusion("NEEDS_MORE", ["products"], [issue(
            "asker_must_say", "largest share of their scheduled machine hours",
            what="the scheduled machine hours",
            check_sql="SELECT machine_hours FROM products")])
        out = va.Verifier(STAFF, tools, settings()).check(
            c, self.nb(comparisons=["largest share"]), True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)
        self.assertTrue([x for x in tools.calls if x[0] == "run_count"])

    def test_a_threshold_is_matched_by_whole_words(self):
        tools = Tools(STAFF, counts={"rate_date": 3})
        c = conclusion("NEEDS_MORE", ["exchange_rates"], [issue(
            "asker_must_say", "rate", what="the 2027 rate",
            check_sql="SELECT rate FROM exchange_rates WHERE rate_date > '2026-12-31'")])
        out = va.Verifier(STAFF, tools, settings()).check(
            c, self.nb(comparisons=["accurate"]), True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)   # counted: rows exist
        self.assertTrue([x for x in tools.calls if x[0] == "run_count"])

    def test_the_catalogue_says_which_tables_are_views(self):
        view = View({"categories": ["category_id", "name"],
                     "products": ["product_id", "category_id"],
                     "active_products_summary": ["category_name", "product_count"]},
                    joins=[("products", "categories",
                            "products.category_id = categories.category_id")])
        tools = Tools(view)
        tools.clar = SimpleNamespace(views={"active_products_summary": {"products"}})
        c = conclusion("ANSWER", ["categories", "products", "active_products_summary"])
        out = va.Verifier(view, tools, settings()).check(c, self.nb(), True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)


class RunOfOctober20Tests(unittest.TestCase):
    """The three questions the first run of 20 October got wrong."""

    def probed(self, question, comparisons):
        first = plan_turn(["tickets"])
        first["reading"]["comparisons"] = list(comparisons)
        model = Model([first, conclude("ANSWER", ["tickets"])])
        tools = Tools(TICKETS, time=NO_HISTORY)
        agent(model, TICKETS, tools).clarify(question)
        return [a for t, a in tools.calls if t == "time_columns"]

    def test_an_order_by_age_lays_out_the_dates_before_concluding(self):
        # Warehouse Q10, Q11, Library Q09: one date seen, the others missed
        self.assertEqual(self.probed("Which are the oldest tickets?", ["oldest"]),
                         [{"table": "tickets"}])
        self.assertEqual(self.probed("How many tickets last year?", []), [])
        self.assertEqual(self.probed("How many tickets were opened?", []), [])

    def test_the_words_of_an_order_by_age(self):
        import wording
        for q in ("Who are the oldest members?", "Who are our newest suppliers?",
                  "Show the latest orders", "Quels sont les clients les plus anciens ?"):
            self.assertTrue(wording.ORDERED_BY_AGE.search(q), q)
        for q in ("What was our revenue last year?", "In the first quarter, how many?",
                  "How many orders last month?"):
            self.assertFalse(wording.ORDERED_BY_AGE.search(q), q)

    def test_a_period_is_no_point_in_time(self):
        # E17: "in 2025" read as as_of, and a history asked for
        nb = va.Notebook("What was the scrap rate per machine in 2025?")
        nb.reading = reading(["tickets"], time="as_of")
        tools = Tools(TICKETS, time=NO_HISTORY)
        out = va.Verifier(TICKETS, tools, settings()).check(
            conclusion("ANSWER", ["tickets"]), nb, True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)
        self.assertTrue(any(c["check"] == "time.as_of" and c["status"] == "skipped"
                            for c in out.checks))
        self.assertFalse([x for x in tools.calls if x[0] == "time_columns"])

    def test_a_what_if_supposition_is_the_askers(self):
        # E26: the announced increase called absent, the run said NOT COVERED
        tools = Tools(SHOP, absent={"tariff increase": (True, True, [])})
        c = conclusion("NOT_COVERED", ["orders"], [issue(
            "absent_from_database", "tariff increase", what="tariff increase")])
        out = va.Verifier(SHOP, tools, settings()).check(
            c, va.Notebook("What would our 2025 spend have been with the tariff increase "
                           "the carriers announced?"), True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        self.assertEqual(out.outcome.kind, "AmbiSource")
        self.assertFalse([x for x in tools.calls if x[0] == "absent_everywhere"])
        # the same claim in a plain question is swept and stands
        out = va.Verifier(SHOP, tools, settings()).check(
            c, va.Notebook("Which tariff increase did the carriers announce?"), True)
        self.assertEqual(verdict(out.outcome), coverage.NOT_COVERED)

    def test_a_reading_may_name_its_tables_in_a_list(self):
        tools = Tools(SHOP, compare=lambda s: pairs([12, 9]))
        c = conclusion("CHOICE", ["orders"], [issue("choice", "amount", readings=[
            rd("summary", "orders", "net_amount", "SELECT 1"),
            rd("detail", "order_lines, orders", "quantity", "SELECT 2")])])
        out = va.Verifier(SHOP, tools, settings()).check(c, va.Notebook("q?"), True)
        self.assertFalse([x for x in out.checks if x["check"] == "table"])

    def test_what_a_question_compares_with_is_the_askers(self):
        # Warehouse Q15: "cheaper than a coffee" called NOT COVERED
        tools = Tools(SHOP, absent={"coffee": (True, True, []), "height": (True, True, [])})
        c = conclusion("NOT_COVERED", ["products"], [issue(
            "absent_from_database", "a coffee", what="coffee")])
        out = va.Verifier(SHOP, tools, settings()).check(
            c, va.Notebook("Which products are cheaper than a coffee?"), True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        # what is missing is the height, not the average it is compared with
        c = conclusion("NOT_COVERED", ["customers"], [issue(
            "absent_from_database", "height", what="height")])
        out = va.Verifier(SHOP, tools, settings()).check(
            c, va.Notebook("Which customers are taller than average?"), True)
        self.assertEqual(verdict(out.outcome), coverage.NOT_COVERED)

    def test_a_newest_alone_is_an_order_by_one_date(self):
        # Warehouse Q11: timed events asked of "who are our newest suppliers"
        def check(question):
            nb = va.Notebook(question)
            nb.reading = reading(["tickets"], time="first_last")
            facts = {"tickets": dict(NO_HISTORY["tickets"],
                                     moments=[moment("closed_on", False, "date")])}
            return va.Verifier(TICKETS, Tools(TICKETS, time=facts), settings()).check(
                conclusion("ANSWER", ["tickets"]), nb, True)
        self.assertEqual(verdict(check("Which are the newest tickets?").outcome),
                         coverage.ANSWERABLE)
        self.assertEqual(verdict(check("Which tickets were reopened after closing?").outcome),
                         coverage.NEEDS_MORE)

    def test_the_words_of_a_point_in_time_and_of_a_what_if(self):
        import wording
        for q in ("What tier was customer C1 in on 1 March 2025?",
                  "What was the rate at the end of June 2026?",
                  "Combien d'employés ont déjà travaillé à Lyon ?",
                  "By the tier each customer had when the order was placed"):
            self.assertTrue(wording.POINT_IN_TIME.search(q), q)
        for q in ("What was the scrap rate per machine in 2025?",
                  "What was our revenue last year?"):
            self.assertFalse(wording.POINT_IN_TIME.search(q), q)
        self.assertEqual(wording.supposition("What would it have cost with the raise?"),
                         "the raise")
        for polite in ("I would like the list of customers taller than average",
                       "Would you list the customers with a fax number?",
                       "Which customers said they would recommend us?",
                       "List each customer's country, and if the customer has a pet, its name"):
            self.assertEqual(wording.supposition(polite), "", polite)

    def test_more_points_in_time_and_periods(self):
        import wording
        for q in ("on March 1st, 2025", "on 1 Mar 2025", "on 01/03/2025", "at year-end 2024",
                  "at the end of 2024", "at the start of 2025", "au 31/12/2025",
                  "à la fin de l'année", "What tier did it have when it was opened?"):
            self.assertTrue(wording.POINT_IN_TIME.search(q), q)
        self.assertFalse(wording.POINT_IN_TIME.search("However, every month counts"))
        self.assertTrue(wording.PERIOD.search("the scrap rate per machine in 2025"))

    def test_a_question_naming_no_period_is_checked(self):
        # in the past it asks when, even with no date
        nb = va.Notebook("Which tier was customer C1 in?")
        nb.reading = reading(["tickets"], time="as_of")
        out = va.Verifier(TICKETS, Tools(TICKETS, time=NO_HISTORY), settings()).check(
            conclusion("ANSWER", ["tickets"]), nb, True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        # in the present the current row answers it (review of 27 October:
        # it was sent to the asker for a history)
        nb = va.Notebook("Which tier is customer C1 in?")
        nb.reading = reading(["tickets"], time="as_of")
        out = va.Verifier(TICKETS, Tools(TICKETS, time=NO_HISTORY), settings()).check(
            conclusion("ANSWER", ["tickets"]), nb, True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)

    def test_only_the_supposition_of_a_what_if_is_the_askers(self):
        tools = Tools(SHOP, absent={"drone deliveries": (True, True, [])})
        c = conclusion("NOT_COVERED", ["orders"], [issue(
            "absent_from_database", "drone deliveries", what="drone deliveries")])
        out = va.Verifier(SHOP, tools, settings()).check(
            c, va.Notebook("What would our spend on drone deliveries have been with a "
                           "5% increase?"), True)
        self.assertEqual(verdict(out.outcome), coverage.NOT_COVERED)

    def test_a_count_or_what_follows_is_no_reference(self):
        import wording
        self.assertEqual(wording.compared_with("Which customers have more than one pet?"), [])
        self.assertEqual(wording.compared_with("Members older than 30 and own a boat"), [])
        self.assertEqual(wording.compared_with("Contacted other than by phone"), [])
        self.assertEqual(wording.compared_with("Who has fewer than 3 complaints?"), [])
        self.assertEqual(wording.compared_with("Cheaper than a coffee and in stock"),
                         ["a coffee"])

    def test_an_absence_the_sweep_could_not_confirm_is_a_gap_in_the_data(self):
        # E38, 23 October: the absence of web analytics, unconfirmed, came
        # back as a blank to fill: "How many [website traffic data] last month?"
        tools = Tools(SHOP, absent={"website traffic": (True, False, [])})
        c = conclusion("NOT_COVERED", ["orders"], [issue(
            "absent_from_database", "visitors did our website have", what="website traffic data")])
        for final in (False, True):
            out = va.Verifier(SHOP, tools, settings()).check(
                c, va.Notebook("How many visitors did our website have last month?"), final)
            if out.outcome is not None:
                self.assertEqual((verdict(out.outcome), out.outcome.gap),
                                 (coverage.NEEDS_MORE, "data"), final)
        import verdict_tools
        self.assertGreaterEqual(verdict_tools.SWEEP_COLUMNS, 600)

    def test_a_form_word_is_never_swept_for(self):
        # E38, 23 October: "website traffic data" met a data_type column
        term = va.Verifier._term({"phrase": "", "what": "website traffic data"})
        self.assertNotIn("data", term.split())
        self.assertEqual(term, "website traffic")
        self.assertEqual(va.Verifier._term({"phrase": "", "what": "patent records"}), "patent")
        self.assertEqual(va.Verifier._term({"phrase": "", "what": "data"}), "data")

    def test_hours_after_a_date_need_its_time_of_day_whatever_its_role(self):
        # E60, 23 October: period_end, a DATE, named as a filter, passed
        facts = {"tickets": {"moments": [moment("opened_at", True),
                                         dict(moment("closed_on", None, "date"))],
                             "intervals": [], "history_tables": [], "event_type": None,
                             "parent_links": []}}
        nb = va.Notebook("On average, how many hours after closing are tickets reopened?")
        nb.reading = reading(["tickets"], time="duration")
        c = conclusion("ANSWER", ["tickets"], columns=[
            {"table": "tickets", "column": "closed_on", "role": "filter"},
            {"table": "tickets", "column": "opened_at", "role": "measure"}])
        out = va.Verifier(TICKETS, Tools(TICKETS, time=facts), settings()).check(c, nb, True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        self.assertIn("tickets.closed_on", out.outcome.reason)
        # in days, a date is enough
        nb = va.Notebook("On average, how many days after closing are tickets reopened?")
        nb.reading = reading(["tickets"], time="duration")
        out = va.Verifier(TICKETS, Tools(TICKETS, time=facts), settings()).check(c, nb, True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)

    def test_a_state_at_a_date_needs_a_date_or_a_time_asked(self):
        # review of 27 October: "Show me the oldest products" read as as_of
        # was sent to the asker for a history no question asked for
        nb = va.Notebook("Show me the oldest tickets.")
        nb.reading = reading(["tickets"], time="as_of")
        c = conclusion("ANSWER", ["tickets"])
        out = va.Verifier(TICKETS, Tools(TICKETS, time=NO_HISTORY), settings()).check(c, nb, True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)
        self.assertIn("no point in time is asked",
                      [k["detail"] for k in out.checks if k["check"] == "time.as_of"])
        # a date asked still needs the history
        nb = va.Notebook("What was the status of ticket 7 on 1 March 2025?")
        nb.reading = reading(["tickets"], time="as_of")
        out = va.Verifier(TICKETS, Tools(TICKETS, time=NO_HISTORY), settings()).check(c, nb, True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)

    def test_a_state_at_a_date_needs_a_history_of_that_very_value(self):
        # review of 26 October: E42 was answered from the status history,
        # which keeps no priority
        nb = va.Notebook("What was the priority of ticket 7 on 1 March 2025?")
        nb.reading = reading(["tickets", "ticket_status_history"], time="as_of")
        priority = [{"table": "tickets", "column": "priority", "role": "measure"}]
        c = conclusion("ANSWER", ["tickets", "ticket_status_history"], columns=priority)
        out = va.Verifier(TICKETS, Tools(TICKETS, time=WITH_HISTORY), settings()).check(
            c, nb, True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        self.assertIn("no history keeps tickets.priority", out.outcome.reason)
        # the status, which that history keeps, is read off it
        nb = va.Notebook("What was the status of ticket 7 on 1 March 2025?")
        nb.reading = reading(["tickets", "ticket_status_history"], time="as_of")
        status = [{"table": "tickets", "column": "status", "role": "measure"}]
        c = conclusion("ANSWER", ["tickets", "ticket_status_history"], columns=status)
        out = va.Verifier(TICKETS, Tools(TICKETS, time=WITH_HISTORY), settings()).check(
            c, nb, True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)

    def test_a_log_keeps_a_value_from_its_first_row_that_names_it(self):
        # a log of changes (field_name = 'priority'): kept from its first
        # such row, and only if there is one
        class Logged(Tools):
            first = None

            def run_count(self, sql):
                self.calls.append(("run_count", {"sql": sql}))
                return Result("run_count", data={"count": 1, "columns": ["first"],
                                                 "rows": [[self.first]]}, digest="1 row")
        nb = va.Notebook("What was the priority of ticket 7 on 1 March 2025?")
        nb.reading = reading(["tickets", "events"], time="as_of")
        priority = [{"table": "tickets", "column": "priority", "role": "measure"}]
        c = conclusion("ANSWER", ["tickets", "events"], columns=priority)
        for first, expected in (("2024-01-15 10:00:00", coverage.ANSWERABLE),
                                ("2026-02-01 09:00:00", coverage.NEEDS_MORE),
                                (None, coverage.NEEDS_MORE)):
            tools = Logged(TICKETS, time=EVENTS)
            tools.first = first
            out = va.Verifier(TICKETS, tools, settings()).check(c, nb, True)
            self.assertEqual(verdict(out.outcome), expected, first)
            sent = [a["sql"] for name, a in tools.calls if name == "run_count"]
            self.assertIn("= 'priority'", sent[0])

    def test_a_history_counts_only_when_it_reaches_back_to_the_date(self):
        # E42, 23 October: an audit log from February 2026 passed for 1 March 2025
        late = {"ticket_status_history": dict(WITH_HISTORY["ticket_status_history"], moments=[
                    dict(moment("valid_from", False, "date"), min="2026-02-01"),
                    moment("valid_to", False, "date")]), **NO_HISTORY}
        nb = va.Notebook("What was the status of ticket 7 on 1 March 2025?")
        nb.reading = reading(["tickets", "ticket_status_history"], time="as_of")
        c = conclusion("ANSWER", ["tickets", "ticket_status_history"])
        out = va.Verifier(TICKETS, Tools(TICKETS, time=late), settings()).check(c, nb, True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        self.assertIn("starts on 2026-02-01", out.outcome.reason)
        # a history that reaches back to the date answers it
        out = va.Verifier(TICKETS, Tools(TICKETS, time=WITH_HISTORY), settings()).check(c, nb, True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)
        import datetime
        import verdict_verifier as vv
        self.assertEqual(vv._asked_date("as of March 1, 2025"), datetime.date(2025, 3, 1))
        self.assertEqual(vv._asked_date("at the end of June 2025"), datetime.date(2025, 6, 30))
        self.assertIsNone(vv._asked_date("in 2025"))

    def test_a_time_issue_reaches_the_asker_in_words(self):
        # review of 23 October: the time check's sentence with its columns
        # went into the clarifying sentence
        v = va.Verifier(SHOP, Tools(SHOP), settings())
        v._question = "What was the status of order 7 on 1 March 2025?"
        issue_ = dict(va.Verifier._issue("asker_must_say", "", "the state at that date: only the "
                                         "current state is stored for orders.status", "AmbiRef"),
                      _time="as_of", _gap="data")
        out = v.to_outcome([issue_], conclusion("NEEDS_MORE", ["orders"]))
        self.assertNotIn("orders.status", out.missing)
        self.assertIn("orders.status", out.reason)
        self.assertEqual(out.phrase, "on 1 March")

    def test_a_held_term_is_a_data_gap_only_for_a_property_of_the_records(self):
        tools = Tools(SHOP, absent={"loyalty points": (False, True, ["orders.points"])})
        c = conclusion("NOT_COVERED", ["orders"], [issue(
            "absent_from_database", "loyalty points", what="loyalty points")])
        out = va.Verifier(SHOP, tools, settings()).check(
            c, va.Notebook("Which customers have loyalty points?"), True)
        self.assertEqual(out.outcome.gap, "asker")

    def test_a_need_says_who_can_fill_it(self):
        # the property asked is not kept: the data must record it
        tools = Tools(SHOP, absent={"time expense": (False, True, ["orders.order_date"])})
        c = conclusion("NOT_COVERED", ["orders"], [issue(
            "absent_from_database", "spent in the evening, after 6 pm", what="time expense")])
        out = va.Verifier(SHOP, tools, settings()).check(
            c, va.Notebook("How many orders were placed in the evening, after 6 pm?"), True)
        self.assertEqual((verdict(out.outcome), out.outcome.gap), (coverage.NEEDS_MORE, "data"))
        # what a what-if supposes is the asker's to give
        c = conclusion("NEEDS_MORE", ["orders"], [issue(
            "asker_must_say", "with the increase they announced", what="the increase")])
        out = va.Verifier(SHOP, Tools(SHOP), settings()).check(
            c, va.Notebook("What would our spend have been with the increase they announced?"),
            True)
        self.assertEqual(out.outcome.gap, "asker")

    def test_the_review_s_over_broad_cases_keep_their_verdict(self):
        """The independent review of 23 October: each rule added that day,
        on a question it must leave alone."""
        import wording
        # a year said in full, or a fiscal period, is no period from today
        for question, phrase, what in (
                ("What will the open orders cost at the budget rate for 2027?",
                 "budget rate for 2027", "the 2027 budget exchange rate"),
                ("What was our revenue last fiscal year?", "revenue last fiscal year",
                 "the months the fiscal year covers")):
            nb = va.Notebook(question)
            nb.reading = dict(reading(["orders"]), measure="cost at the budget rate revenue")
            c = conclusion("NEEDS_MORE", ["orders"], [issue("asker_must_say", phrase, what=what)])
            out = va.Verifier(SHOP, Tools(SHOP), settings()).check(c, nb, True)
            self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE, question)
        # an age word beside something else asked for is no ordering
        for question, phrase in (
                ("What is the latest firmware version installed on each device?",
                 "latest firmware version"),
                ("What are the first names of our pilots?", "first names")):
            tools = Tools(SHOP, absent={phrase.split()[-2] if "firmware" in phrase else "first names":
                                        (True, True, []),
                                        "firmware version": (True, True, []),
                                        "names": (True, True, [])})
            c = conclusion("NOT_COVERED", ["orders"], [issue(
                "absent_from_database", phrase, what=phrase)])
            out = va.Verifier(SHOP, tools, settings()).check(c, va.Notebook(question), True)
            self.assertNotIn("ordered_by_age", [k["status"] for k in out.checks], question)
        # a length is no place, and m alone is not metres
        self.assertEqual(wording.compared_with("Which cities have more than 100 km of bike lanes?"), [])
        self.assertEqual(wording.compared_with("Accounts more than 5 m from new customers"), [])
        # earn is not revenue
        self.assertEqual(wording.noun_forms("earn"), [])
        # "most recent" orders, it is no vague time
        self.assertFalse(wording.VAGUE_TIME.search("Show the most recent orders"))
        self.assertTrue(wording.VAGUE_TIME.search("Show recent orders"))
        # a JOIN filters: its rows are counted
        tools = Tools(SHOP, counts={"JOIN": 12})
        c = conclusion("NEEDS_MORE", ["orders"], [issue(
            "asker_must_say", "shipped late", what="the delay",
            check_sql="SELECT * FROM orders o JOIN orders s ON s.order_id = o.order_id "
                      "AND s.order_date > o.order_date")])
        out = va.Verifier(SHOP, tools, settings()).check(
            c, va.Notebook("Which orders were shipped late?"), True)
        self.assertNotIn("no_condition", [k["status"] for k in out.checks])

    def test_a_stored_word_settles_only_a_short_phrase_without_a_number(self):
        # E34, 23 October: BUDGET stored, the 2027 rates missing, dropped
        values = {"budget": [("orders", "status", ["BUDGET"])],
                  "high": [("orders", "status", ["HIGH"])]}
        c = conclusion("NEEDS_MORE", ["orders"], [issue(
            "asker_must_say", "budget exchange rate finance has set for 2027",
            what="the 2027 budget exchange rates")])
        out = va.Verifier(SHOP, Tools(SHOP, values=values), settings()).check(
            c, va.Notebook("What will the open orders cost at the budget exchange rate "
                           "finance has set for 2027?"), True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        c = conclusion("NEEDS_MORE", ["orders"], [issue("asker_must_say", "high status")])
        out = va.Verifier(SHOP, Tools(SHOP, values=values), settings()).check(
            c, va.Notebook("Which orders have a high status?"), True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)

    def test_a_calendar_period_asks_nothing_of_the_asker(self):
        # E36, 23 October: "revenue last year" stopped for a period
        nb = va.Notebook("What was our revenue last year?")
        nb.reading = dict(reading(["orders"]), measure="revenue")
        c = conclusion("NEEDS_MORE", ["orders"], [issue(
            "asker_must_say", "revenue last year", what="the period")])
        early = va.Verifier(SHOP, Tools(SHOP), settings()).check(c, nb, False)
        self.assertIsNone(early.outcome)
        self.assertTrue(any("calendar period" in f for f in early.feedback))
        out = va.Verifier(SHOP, Tools(SHOP), settings()).check(c, nb, True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)
        # a vague time word, or another word left open, is still the asker's
        for phrase in ("recently", "high-value orders last year"):
            c = conclusion("NEEDS_MORE", ["orders"], [issue("asker_must_say", phrase, what="w")])
            out = va.Verifier(SHOP, Tools(SHOP), settings()).check(c, nb, True)
            self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE, phrase)

    def test_a_verb_is_looked_for_as_the_nouns_of_its_tables(self):
        # Warehouse Q14, 23 October: "sell" swept, refused
        import wording
        self.assertEqual(wording.noun_forms("sell"), ["sale", "sold"])
        self.assertEqual(wording.noun_forms("drone"), [])
        tools = Tools(SHOP, absent={"sell": (True, True, []),
                                    "sale": (False, True, ["orders.sale_date"])})
        c = conclusion("NOT_COVERED", ["orders"], [issue(
            "absent_from_database", "sell", what="sell")])
        out = va.Verifier(SHOP, tools, settings()).check(
            c, va.Notebook("How many products did we sell in the last 30 days?"), True)
        self.assertNotEqual(verdict(out.outcome), coverage.NOT_COVERED)

    def test_what_the_asker_must_say_is_carried_to_ask(self):
        c = conclusion("NEEDS_MORE", ["orders"], [issue(
            "asker_must_say", "the budget rate", what="the 2027 budget exchange rates")])
        out = va.Verifier(SHOP, Tools(SHOP), settings()).check(
            c, va.Notebook("What will the open orders cost at the budget rate?"), True)
        self.assertEqual(out.outcome.missing, "the 2027 budget exchange rates")

    def test_what_a_what_if_supposes_is_never_counted(self):
        # E26, 23 October: SELECT * FROM freight_rates found 102 rows
        tools = Tools(SHOP, counts={"FROM orders": 102})
        c = conclusion("NEEDS_MORE", ["orders"], [issue(
            "asker_must_say", "with the tariff increase the carriers announced",
            what="the tariff increase percentage", check_sql="SELECT * FROM orders")])
        nb = va.Notebook("What would our 2025 spend per carrier have been with the tariff "
                         "increase the carriers announced?")
        out = va.Verifier(SHOP, tools, settings()).check(c, nb, True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        self.assertTrue(any(k["status"] == "the_askers" for k in out.checks))

    def test_a_check_with_no_condition_proves_nothing(self):
        tools = Tools(SHOP, counts={"FROM orders": 102})
        c = conclusion("NEEDS_MORE", ["orders"], [issue(
            "asker_must_say", "the budget rate", what="the 2027 budget rate",
            check_sql="SELECT * FROM orders")])
        out = va.Verifier(SHOP, tools, settings()).check(
            c, va.Notebook("What will the open orders cost at the budget rate for 2027?"), True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        self.assertTrue(any(k["status"] == "no_condition" for k in out.checks))

    def test_an_age_word_is_never_refused(self):
        # Library Q09, 23 October: "oldest" swept, found nowhere, refused
        tools = Tools(SHOP, absent={"oldest": (True, True, [])})
        c = conclusion("NOT_COVERED", ["orders"], [issue(
            "absent_from_database", "oldest", what="oldest")])
        v = va.Verifier(SHOP, tools, settings())
        early = v.check(c, va.Notebook("Which are the oldest orders?"), False)
        self.assertIsNone(early.outcome)
        self.assertTrue(any("orders them by one of their dates" in f for f in early.feedback))
        out = va.Verifier(SHOP, tools, settings()).check(
            c, va.Notebook("Which are the oldest orders?"), True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        # a word that is no age keeps its sweep
        c = conclusion("NOT_COVERED", ["orders"], [issue(
            "absent_from_database", "drone deliveries", what="drone deliveries")])
        out = va.Verifier(SHOP, Tools(SHOP, absent={"drone deliveries": (True, True, [])}),
                          settings()).check(c, va.Notebook("The oldest drone deliveries?"), True)
        self.assertEqual(verdict(out.outcome), coverage.NOT_COVERED)

    def test_a_place_a_distance_is_measured_from_is_the_askers(self):
        import wording
        self.assertEqual(wording.compared_with(
            "Which geographic points are within 50 km of our office?"), ["our office"])
        self.assertEqual(wording.compared_with(
            "Stores less than 10 miles from the depot that are open"), ["the depot"])
        self.assertEqual(wording.compared_with(
            "Quels points sont à moins de 5 km de notre siège ?"), ["notre siège"])
        self.assertEqual(wording.compared_with("Routes longer than 50 km"), [])
        self.assertEqual(wording.compared_with("How many points are 3 km apart?"), [])
        # pt-h26: the office is nowhere, and the asker gives where it is
        tools = Tools(SHOP, absent={"office": (True, True, [])})
        c = conclusion("NOT_COVERED", ["orders"], [issue(
            "absent_from_database", "our office", what="office")])
        out = va.Verifier(SHOP, tools, settings()).check(
            c, va.Notebook("Which orders were shipped within 50 km of our office?"), True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)

    def test_a_sequence_is_checked_whatever_its_words(self):
        nb = va.Notebook("Quels tickets ont été rouverts ?")
        nb.reading = reading(["tickets"], time="sequence")
        facts = {"tickets": dict(NO_HISTORY["tickets"], moments=[moment("closed_on", False, "date")])}
        out = va.Verifier(TICKETS, Tools(TICKETS, time=facts), settings()).check(
            conclusion("ANSWER", ["tickets"]), nb, True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        import wording
        self.assertTrue(wording.SEQUENCE.search("What was each ticket's previous status?"))

    def test_an_unknown_table_in_a_list_is_said(self):
        tools = Tools(SHOP, compare=lambda s: pairs([12, 9]))
        c = conclusion("CHOICE", ["orders"], [issue("choice", "amount", readings=[
            rd("summary", "orders", "net_amount", "SELECT 1"),
            rd("detail", "order_lnes, orders", "quantity", "SELECT 2")])])
        out = va.Verifier(SHOP, tools, settings()).check(c, va.Notebook("q?"), False)
        self.assertTrue(any("order_lnes" in f for f in out.feedback))

    def test_a_quoted_word_in_a_comment_names_no_reading(self):
        readings = [rd("net", "orders", "net_amount",
                       "SELECT SUM(net_amount) FROM orders -- 'gross' is before discounts"),
                    rd("gross", "orders", "gross_amount", "SELECT SUM(gross_amount) FROM orders")]
        v = va.Verifier(SHOP, Tools(SHOP), settings())
        self.assertIsNone(v._named_reading("gross revenue", readings))


class WarehouseRunTests(unittest.TestCase):
    """Warehouse Q14, Q17 and Q25 of the run of 20 October."""

    def test_a_vague_filter_is_a_threshold_rows_never_settle(self):
        # Q14: "recently" read as a filter, a MIN/MAX of the dates took it for data
        tools = Tools(SHOP, counts={"MIN(order_date)": 1})
        nb = va.Notebook("How many products did we sell recently?")
        nb.reading = dict(reading(["orders"]), filters=["recently"])
        c = conclusion("NEEDS_MORE", ["orders"], [issue(
            "asker_must_say", "recently", what="the period meant by recently",
            check_sql="SELECT MIN(order_date), MAX(order_date) FROM orders")])
        out = va.Verifier(SHOP, tools, settings()).check(c, nb, True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        self.assertFalse([x for x in tools.calls if x[0] == "run_count"])

    def weak(self, decided, hows=("described",), state=False):
        class Weighed(Tools):
            def absent_everywhere(self, what, columns=True):
                self.calls.append(("absent_everywhere", {"what": what, "columns": columns}))
                if columns:
                    return (False, True, [{"table": "orders", "column": "status", "how": h}
                                          for h in hows])
                return (True, True, [])
        tools = Weighed(SHOP)
        tools.clar = SimpleNamespace(records_a_state=lambda t, c: state)
        asked = []

        def weigh(term, columns, question):
            asked.append((term, columns))
            if isinstance(decided, Exception):
                raise decided
            return decided, "bread cannot be told from rice"
        c = conclusion("NOT_COVERED", ["products"], [issue(
            "absent_from_database", "gluten free", what="gluten free")])
        out = va.Verifier(SHOP, tools, settings(), weigh=weigh).check(
            c, va.Notebook("Which products are gluten free?"), True)
        return out, tools, asked

    def test_an_echo_in_a_description_is_weighed_on_the_values(self):
        # Q17: "free" met "Free-form JSON attributes"; the values decide
        out, tools, asked = self.weak("no")
        self.assertEqual(verdict(out.outcome), coverage.NOT_COVERED)
        self.assertEqual(asked[0][1], [{"table": "orders", "column": "status"}])
        self.assertIn({"what": "gluten free", "columns": False},
                      [a for t, a in tools.calls if t == "absent_everywhere"])
        out, _tools, _asked = self.weak("yes")
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        out, _tools, _asked = self.weak("unknown")
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)

    def test_strong_evidence_a_table_name_or_a_state_is_never_weighed(self):
        for kw in ({"hows": ("described", "token")}, {"hows": ("table",)}, {"state": True}):
            out, _tools, asked = self.weak("no", **kw)
            self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE, kw)
            self.assertEqual(asked, [], kw)

    def test_a_stopped_job_stops_the_values_question(self):
        with self.assertRaises(va.AgentCancelled):
            self.weak(va.AgentCancelled("stopped"))

    def test_a_period_filter_is_looked_up(self):
        # E32: "last quarter" is a period, its rows say whether it is held
        tools = Tools(SHOP, counts={"MAX(order_date)": 1})
        nb = va.Notebook("In the last quarter, which customers ordered?")
        nb.reading = dict(reading(["orders"]), filters=["last quarter"])
        c = conclusion("NEEDS_MORE", ["orders"], [issue(
            "asker_must_say", "last quarter", what="the dates of the last quarter",
            check_sql="SELECT MAX(order_date) FROM orders")])
        out = va.Verifier(SHOP, tools, settings()).check(c, nb, True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)

    def test_the_values_question_is_bounded(self):
        model = Model([{"decidable": "no"}] * 3)
        a = agent(model, SHOP, Tools(SHOP), wording=True)
        a._trace_now, a._weighings = None, 0
        calls = []
        a.clar.decide_on_values = lambda term, cols, q, llm=None, **kw: (
            calls.append((llm.thinks(), kw)) or ("no", None, None, "w"))
        for _ in range(3):
            a._weigh("gluten free", [{"table": "orders", "column": "status"}], "q?")
        self.assertEqual(len(calls), va.MAX_WEIGH_CALLS)
        self.assertEqual(calls[0], (False, {"timeout": va.WORDING_SECONDS,
                                            "num_predict": va.WEIGH_TOKENS}))

    def test_a_value_a_closed_column_cannot_hold_is_not_covered(self):
        # Q25: "by rail" when the mode is road, sea or air
        view = View({"shpmnt": ["shipment_id", "mode_code", "carrier"]})
        tools = Tools(view, counts={"RAIL": 0, "SEA": 0, "OCEAN": 0, "pend": 0, "Union": 0})
        tools.clar = SimpleNamespace(enum_labels=lambda t, c: (
            {"ROADSH": "ROAD-SHIPMENT", "SEASHP": "SEA-SHIPMENT", "AIRSHP": "AIR-SHIPMENT",
             "PENDING": ""} if c == "mode_code" else {}))
        said = {"rail": "no", "ocean": "yes"}

        def judge(where, word="rail", weigh=True):
            c = conclusion("NO_DATA", ["shpmnt"], [issue(
                "no_matching_row", f"by {word}", what=f"shipments by {word}",
                check_sql=f"SELECT * FROM shpmnt WHERE {where}")])
            w = (lambda term, cols, q: (said.get(term.lower(), "unknown"), "")) if weigh else None
            return verdict(va.Verifier(view, tools, settings(), weigh=w).check(
                c, va.Notebook("q?"), True).outcome)
        self.assertEqual(judge("mode_code LIKE '%RAIL%'"), coverage.NOT_COVERED)
        # a held code, read as a pattern; an IN with one value held
        self.assertEqual(judge("mode_code LIKE '%SEA%'"), coverage.NO_DATA)
        self.assertEqual(judge("mode_code LIKE 'pend%'"), coverage.NO_DATA)
        self.assertEqual(judge("mode_code IN ('SEASHP', 'RAIL')"), coverage.NO_DATA)
        # a subquery, the model reading "ocean" off SEASHP, no model at all
        self.assertEqual(judge("mode_code IN (SELECT mode_code FROM shpmnt "
                               "WHERE carrier = 'Union Pacific')"), coverage.NO_DATA)
        self.assertEqual(judge("mode_code = 'OCEAN'", word="ocean"), coverage.NO_DATA)
        self.assertEqual(judge("mode_code LIKE '%RAIL%'", weigh=False), coverage.NO_DATA)


class ReviewOf26OctoberTests(unittest.TestCase):
    """The verdict core's review of 26 October: each path to a silent
    ANSWER or a refusal it found, closed."""

    def nb(self, question="q?", **fields):
        nb = va.Notebook(question)
        nb.reading = dict(reading(), **fields)
        return nb

    def test_a_two_word_age_phrase_orders_and_is_never_swept(self):
        # finding 1: "most recent suppliers" was swept for "recent" and refused
        for question, phrase in (("Who are our most recent suppliers?", "most recent suppliers"),
                                 ("Who are our longest-standing customers?",
                                  "longest-standing customers")):
            tools = Tools(SHOP, absent={"recent": (True, True, []),
                                        "standing": (True, True, [])})
            c = conclusion("NOT_COVERED", ["suppliers"], [issue(
                "absent_from_database", phrase, what=phrase)])
            out = va.Verifier(SHOP, tools, settings()).check(c, va.Notebook(question), True)
            self.assertIn("ordered_by_age", [k["status"] for k in out.checks], question)
            self.assertNotEqual(verdict(out.outcome), coverage.NOT_COVERED, question)
            self.assertFalse([x for x in tools.calls if x[0] == "absent_everywhere"], question)

    def test_a_period_the_data_does_not_reach_stays_a_gap_in_the_data(self):
        # finding 3a: the period was dropped before its check ran
        tools = Tools(SHOP, counts={"2025-01-01": 0})
        c = conclusion("NEEDS_MORE", ["orders"], [issue(
            "asker_must_say", "revenue last year", what="the year asked: the orders stop before it",
            check_sql="SELECT order_id FROM orders WHERE order_date >= '2025-01-01'")])
        out = va.Verifier(SHOP, tools, settings()).check(
            c, self.nb("What was our revenue last year?", measure="revenue",
                       entities=["orders"]), True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        self.assertEqual(out.outcome.gap, "data")

    def test_a_threshold_folded_into_a_period_phrase_is_kept(self):
        # finding 3b: "late" was lost inside "late deliveries last month"
        c = conclusion("NEEDS_MORE", ["orders"], [issue(
            "asker_must_say", "late deliveries last month", what="when a delivery is late")])
        out = va.Verifier(SHOP, Tools(SHOP), settings()).check(
            c, self.nb("How many late deliveries last month?", measure="late deliveries",
                       entities=["deliveries"], comparisons=["late"]), True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)

    def test_a_vague_time_word_never_passes_in_silence(self):
        # finding 4: "borrowed recently" concluded ANSWER was accepted
        out = va.Verifier(SHOP, Tools(SHOP), settings()).check(
            conclusion("ANSWER", ["orders"]), self.nb("Which orders were placed recently?"), True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        self.assertEqual((out.outcome.phrase, out.outcome.gap), ("recently", "asker"))
        # never when the question gives the length
        out = va.Verifier(SHOP, Tools(SHOP), settings()).check(
            conclusion("ANSWER", ["orders"]),
            self.nb("Which orders were placed recently, in the last 30 days?"), True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)
        # "the most recent" orders by age, it is no vague time
        out = va.Verifier(SHOP, Tools(SHOP), settings()).check(
            conclusion("ANSWER", ["orders"]), self.nb("Show the most recent orders"), True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)

    def test_the_things_counted_are_never_looked_up_as_stored_values(self):
        # finding 5: "orders" is stored in audit_log.object_type
        tools = Tools(SHOP, values={"orders": [("orders", "status", ["orders"])]})
        c = conclusion("NEEDS_MORE", ["orders"], [issue(
            "asker_must_say", "recent orders", what="how recent", kind="AmbiContext")])
        out = va.Verifier(SHOP, tools, settings()).check(
            c, self.nb("Which recent orders shipped?", entities=["orders"]), True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        self.assertNotIn("orders", [x[1]["value"] for x in tools.calls if x[0] == "find_value"])

    def test_a_check_with_no_condition_counts_a_table_not_the_thing(self):
        # finding 6: SELECT rate FROM ... and SELECT COUNT(*) dropped the gap
        for sql in ("SELECT rate FROM exchange_rates", "SELECT COUNT(*) FROM exchange_rates"):
            tools = Tools(STAFF, counts={"exchange_rates": 102})
            c = conclusion("NEEDS_MORE", ["exchange_rates"], [issue(
                "asker_must_say", "the tariff increase", what="the increase announced",
                check_sql=sql)])
            out = va.Verifier(STAFF, tools, settings()).check(c, self.nb(), True)
            self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE, sql)
            self.assertIn("no_condition", [k["status"] for k in out.checks], sql)

    def test_a_period_word_does_not_make_a_threshold_data(self):
        # finding 6: "between" took "long gap between orders" for data
        tools = Tools(SHOP, counts={"orders": 40})
        c = conclusion("NEEDS_MORE", ["orders"], [issue(
            "asker_must_say", "long gap between orders", what="how long a gap is long",
            check_sql="SELECT order_id FROM orders WHERE order_date IS NOT NULL")])
        out = va.Verifier(SHOP, tools, settings()).check(
            c, self.nb("Which customers have a long gap between orders?",
                       entities=["orders"], comparisons=["long gap"]), True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)

    def test_french_words_are_whole_words(self):
        # finding 7: ASCII-only splitting made "caf\u00e9" into "caf"
        self.assertEqual(__import__("verdict_verifier")._words(
            "moins chers qu'un caf\u00e9 r\u00e9cents"),
            ["moins", "chers", "qu", "un", "caf\u00e9", "r\u00e9cents"])

    def test_hours_written_as_h_are_hours(self):
        # finding 8: "within 48 h" skipped the duration check
        fine = __import__("verdict_verifier").FINE_UNITS
        for q in ("within 48 h", "within 48h", "in 2 h", "how many hours"):
            self.assertTrue(fine.search(q), q)
        self.assertFalse(fine.search("in the 4th quarter"))

    def test_a_dated_series_must_reach_back_to_the_date(self):
        # finding 8: rates from 31 January 2026 passed for 1 March 2025
        facts = {"exchange_rates": {
            "moments": [dict(moment("rate_date", False, "date"), min="2026-01-31")],
            "intervals": [], "history_tables": [], "event_type": None, "parent_links": []}}
        tools = Tools(STAFF, time=facts)
        v = va.Verifier(STAFF, tools, settings())
        v._dated_series = lambda t, m, c: True
        c = conclusion("ANSWER", ["exchange_rates"],
                       columns=[{"table": "exchange_rates", "column": "rate_date", "role": "time"}])
        out = v.check(c, self.nb("What was the EUR rate on 1 March 2025?", time="as_of"), True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        self.assertIn("2026-01-31", out.outcome.reason)

    def test_ever_asks_of_the_past_the_rows_keep(self):
        # finding 9: "ever" demanded a history of an event table
        tools = Tools(SHOP, time={"orders": {"moments": [moment("order_date", False, "date")],
                                             "intervals": [], "history_tables": [],
                                             "event_type": None, "parent_links": []}})
        out = va.Verifier(SHOP, tools, settings()).check(
            conclusion("ANSWER", ["orders"]),
            self.nb("Has any customer ever ordered twice?", time="as_of"), True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)

    def test_a_choice_the_facts_cannot_settle_is_never_an_answer(self):
        # finding 11: one reading, readings that fail, or a CHOICE named with
        # no issue all came out ANSWERABLE
        c = conclusion("CHOICE", ["orders"], [issue("choice", "date", readings=[
            rd("a", "orders", "order_date", "SELECT 1")])])
        out = va.Verifier(SHOP, Tools(SHOP), settings()).check(c, va.Notebook("q"), True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        self.assertIn("fewer than two readings", [k["detail"] for k in out.checks])
        for declared in ("CHOICE", "NO_DATA"):
            out = va.Verifier(SHOP, Tools(SHOP), settings()).check(
                conclusion(declared, ["orders"]), va.Notebook("q"), True)
            self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE, declared)

    def test_a_missing_join_is_a_gap_in_the_data(self):
        # finding 13: it was the asker's to type in, with no phrase
        out = va.Verifier(SHOP, Tools(SHOP), settings()).check(
            conclusion("ANSWER", ["orders", "suppliers"]), va.Notebook("q"), True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        self.assertEqual(out.outcome.gap, "data")

    def test_the_joins_concluded_on_name_real_columns(self):
        # finding 14: the joins were asked for and never read
        c = conclusion("ANSWER", ["orders", "customers"])
        c["joins"] = ["orders.client_id = customers.customer_id"]
        out = va.Verifier(SHOP, Tools(SHOP), settings()).check(c, va.Notebook("q"), False)
        self.assertIn("orders.client_id", " ".join(out.feedback))
        self.assertIn("join_columns", [k["check"] for k in out.checks])

    def test_a_later_round_reads_the_first_round_s_calls(self):
        # finding 12: the last round ran every count and sweep again
        tools = Tools(SHOP, absent={"patents": (True, True, [])})
        v = va.Verifier(SHOP, tools, settings())
        c = conclusion("NOT_COVERED", ["orders"], [issue(
            "absent_from_database", "patents", what="patents")])
        v.check(c, va.Notebook("Which patents do we hold?"), False)
        v.check(c, va.Notebook("Which patents do we hold?"), True)
        self.assertEqual(len([x for x in tools.calls if x[0] == "absent_everywhere"]), 1)

    def test_review_of_the_fixes_vague_time_is_no_order_no_reference_no_future(self):
        # "most recently" orders, "than" refers, "upcoming" is after today,
        # "how soon" is a duration; "the past two weeks" gives the length
        for q in ("Which customer ordered most recently?", "List the least recently updated products",
                  "List upcoming deliveries", "How soon after ordering are items shipped?",
                  "Which orders are more recent than those from 2024?",
                  "Which orders were placed recently, in the past two weeks?",
                  "Which orders were placed recently, since 1 March 2026?",
                  "Which orders were placed last week, recently?"):
            out = va.Verifier(SHOP, Tools(SHOP), settings()).check(
                conclusion("ANSWER", ["orders"]), self.nb(q), True)
            self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE, q)

    def test_review_of_the_fixes_a_lambda_is_never_cached(self):
        # every lambda had one key: one term's sweep answered another's
        v = va.Verifier(SHOP, Tools(SHOP), settings())
        self.assertEqual((v._call(lambda: "gluten"), v._call(lambda: "vegan")), ("gluten", "vegan"))
        tools = Tools(SHOP, absent={"gluten free": (True, True, []), "vegan": (False, True, ["x.y"])})
        v = va.Verifier(SHOP, tools, settings())
        self.assertEqual(v._call(tools.absent_everywhere, "gluten free", False)[0], True)
        self.assertEqual(v._call(tools.absent_everywhere, "vegan", False)[0], False)

    def test_review_of_the_fixes_an_order_is_a_choice_only_when_asked(self):
        def pair(moved):
            return lambda sqls: {"results": [{"i": 0, "count": 4}, {"i": 1, "count": 4}],
                                 "pairs": [{"a": 0, "b": 1, "same": True, "only_a": 0, "only_b": 0,
                                            "share": 0, "order_moved": moved, "order_share": 0.75}]}
        c = conclusion("CHOICE", ["products"], [issue("choice", "oldest", readings=[
            rd("created", "products", "name", "SELECT 1"),
            rd("updated", "products", "list_price", "SELECT 2")])])
        out = va.Verifier(SHOP, Tools(SHOP, compare=pair(3)), settings()).check(
            c, self.nb("Show me the oldest products"), True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_CHOICE)
        out = va.Verifier(SHOP, Tools(SHOP, compare=pair(3)), settings()).check(
            c, self.nb("Which products are active?"), True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)    # an order for display

    def test_review_of_the_fixes_a_choice_whose_readings_all_join_nothing(self):
        c = conclusion("CHOICE", ["orders"], [issue("choice", "rating", readings=[
            rd("a", "suppliers", "rating", "SELECT 1"), rd("b", "receipts", "received", "SELECT 2")])])
        out = va.Verifier(SHOP, Tools(SHOP), settings()).check(c, va.Notebook("q"), True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)

    def test_review_of_the_fixes_ever_of_a_state_needs_a_history(self):
        tools = Tools(STAFF, time={"employees": {"moments": [moment("termination_date", False, "date")],
                                                 "intervals": [], "history_tables": [],
                                                 "event_type": None, "parent_links": []}})
        out = va.Verifier(STAFF, tools, settings()).check(
            conclusion("ANSWER", ["employees"]),
            self.nb("Which employees were ever in the Sales department?", time="as_of"), True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)

    def test_review_of_the_fixes_small_rules(self):
        vv = __import__("verdict_verifier")
        self.assertFalse(vv.FINE_UNITS.search("members who joined in the 1990s"))
        self.assertEqual(vv._asked_date("At the end of the day, what was the balance at the end "
                                        "of June 2025?"), __import__("datetime").date(2025, 6, 30))
        v = va.Verifier(SHOP, Tools(SHOP), settings())
        v._reading = {"entities": ["patents"]}
        self.assertFalse(v._age_only("newest patents"))      # patents is no table here
        # a table named like what is missing counts it; a qualified thing is not
        self.assertFalse(v._counts_a_table("SELECT COUNT(*) FROM machine_hours",
                                           {"phrase": "scheduled machine hours", "what": ""}))
        self.assertTrue(v._counts_a_table("SELECT rate FROM freight_rates",
                                          {"phrase": "", "what": "the freight rate after the increase"}))
        # a numeric comparison never takes the measure out of a period
        tools = Tools(SHOP)
        c = conclusion("NEEDS_MORE", ["orders"], [issue("asker_must_say", "revenue last year",
                                                        what="the year")])
        out = va.Verifier(SHOP, tools, settings()).check(
            c, self.nb("Revenue last year, above 10000?", measure="revenue",
                       comparisons=["revenue above 10000"]), True)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)

    def test_review_of_the_fixes_counting_names_and_div(self):
        vt = __import__("verdict_tools")
        said = vt._named_apart_sql("SELECT x, _c2, x FROM t")
        self.assertEqual(said.count("_c2"), 1)
        self.assertIsNone(vt._named_apart_sql("SELECT a, a FROM t WHERE b DIV 2 = 1"))
        self.assertIsNone(vt._count_sql("SELECT a FROM t WHERE b DIV 2 = 1"))

    def test_a_ranking_of_held_things_is_never_refused_whatever_its_word(self):
        # decided on 26 October: by the form of the phrase, not a list of
        # words; a word nobody listed must not be swept and refused
        for question, phrase in (("Which are our busiest suppliers?", "busiest suppliers"),
                                 ("Who are the most reliable suppliers?", "most reliable suppliers"),
                                 ("Which products are cheaper than other products?",
                                  "cheaper than other products"),
                                 ("Who are our top customers?", "top customers")):
            tools = Tools(SHOP, absent={w: (True, True, []) for w in phrase.split()})
            c = conclusion("NOT_COVERED", ["suppliers"], [issue(
                "absent_from_database", phrase, what=phrase)])
            out = va.Verifier(SHOP, tools, settings()).check(c, va.Notebook(question), True)
            self.assertIn("ranking", [k["status"] for k in out.checks], question)
            self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE, question)
            self.assertFalse([x for x in tools.calls if x[0] == "absent_everywhere"], question)
        # the agent's own reading listed it as a comparison
        tools = Tools(SHOP, absent={"reliable": (True, True, [])})
        c = conclusion("NOT_COVERED", ["suppliers"], [issue(
            "absent_from_database", "reliable", what="reliability")])
        out = va.Verifier(SHOP, tools, settings()).check(
            c, self.nb("Which suppliers are reliable?", comparisons=["reliable"]), True)
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)
        # a thing no table holds is still looked for, and may be refused
        tools = Tools(SHOP, absent={"newest patents": (True, True, [])})
        c = conclusion("NOT_COVERED", ["orders"], [issue(
            "absent_from_database", "newest patents", what="patents")])
        out = va.Verifier(SHOP, tools, settings()).check(
            c, va.Notebook("Which are our newest patents?"), True)
        self.assertNotIn("ranking", [k["status"] for k in out.checks])
        self.assertEqual(verdict(out.outcome), coverage.NOT_COVERED)

    def test_past_the_question_s_time_nothing_more_is_swept(self):
        # finding 12: the verifier had no deadline
        tools = Tools(SHOP, absent={"patents": (True, True, [])})
        c = conclusion("NOT_COVERED", ["orders"], [issue(
            "absent_from_database", "patents", what="patents")])
        out = va.Verifier(SHOP, tools, settings(), left=lambda: -1).check(
            c, va.Notebook("Which patents do we hold?"), True)
        self.assertFalse([x for x in tools.calls if x[0] == "absent_everywhere"])
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)    # never a refusal
        self.assertEqual(out.outcome.gap, "data")


MEMBERS = View({"members": ["member_id", "name", "joined_at", "renewed_at"],
                "books": ["book_id", "title", "price"],
                "loans": ["loan_id", "member_id", "book_id", "loaned_at"]},
               joins=[("loans", "members", "loans.member_id = members.member_id"),
                      ("loans", "books", "loans.book_id = books.book_id")])
TWO_DATES = {"members": {"moments": [moment("joined_at", False, "date"),
                                     moment("renewed_at", False, "date")],
                         "intervals": [], "history_tables": [], "event_type": None,
                         "parent_links": []}}
ONE_DATE = {"members": dict(TWO_DATES["members"], moments=[moment("joined_at", False, "date")])}


class AgeAndRankingTests(unittest.TestCase):
    """The age words and the rankings of held things, whatever the agent
    concluded (review of 26 October: Library Q09, Warehouse Q10, Q11 and
    Q09, and rule 3)."""

    def judge(self, c, question, facts=TWO_DATES, compare=lambda sqls: pairs([10, 10]),
              final=True, nb=None, **kw):
        tools = Tools(MEMBERS, compare=compare, time=facts, **kw)
        nb = nb or va.Notebook(question)
        out = va.Verifier(MEMBERS, tools, settings()).check(c, nb, final)
        return out, tools

    def sent(self, tools):
        return [sql for name, a in tools.calls if name == "compare_readings" for sql in a["sqls"]]

    def test_an_age_word_said_absent_is_a_choice_of_its_dates(self):
        # Library Q09 ended NEEDS MORE, "the asker says which date"
        c = conclusion("NOT_COVERED", ["members"], [issue(
            "absent_from_database", "oldest members", what="age of members")])
        out, tools = self.judge(c, "Who are the oldest members?")
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_CHOICE)
        self.assertEqual([o.column for o in out.outcome.options], ["joined_at", "renewed_at"])
        self.assertTrue(all("ASC" in s and "LIMIT 10" in s for s in self.sent(tools)))
        # one date orders them: the answer, said
        out, _ = self.judge(c, "Who are the oldest members?", facts=ONE_DATE)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)
        self.assertIn("joined_at, its only date", out.outcome.reason)
        # dates that agree are one reading
        out, _ = self.judge(c, "Who are the oldest members?",
                            compare=lambda sqls: pairs([10, 10], same={(0, 1)}))
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)
        # dates that cannot be read: the careful verdict, as before
        out, _ = self.judge(c, "Who are the oldest members?", facts={})
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)

    def test_an_age_word_is_no_number_for_the_asker_to_give(self):
        # Warehouse Q11: "newest suppliers" was asked how many
        c = conclusion("NEEDS_MORE", ["members"], [issue(
            "asker_must_say", "newest members", what="how many members, or since when")])
        out, _ = self.judge(c, "Who are our newest members?", final=False)
        self.assertIn("ordered_by_age", [k["status"] for k in out.checks])
        self.assertTrue(any("the order is the answer" in f for f in out.feedback))
        out, tools = self.judge(c, "Who are our newest members?")
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_CHOICE)
        self.assertTrue(all("DESC" in s for s in self.sent(tools)))
        # "recent" is a length of time, the asker's to give
        c = conclusion("NEEDS_MORE", ["members"], [issue(
            "asker_must_say", "recent members", what="how far back recent reaches")])
        out, _ = self.judge(c, "Who are our recent members?")
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_MORE)

    def test_an_answer_sorted_on_one_date_of_several_is_compared(self):
        # Warehouse Q10: created_at taken, updated_at never compared
        order = [{"table": "members", "column": "joined_at", "role": "order"}]
        c = conclusion("ANSWER", ["members"], columns=order)
        out, _ = self.judge(c, "Show me the oldest members.", final=False)
        self.assertTrue(any("compare them" in f for f in out.feedback))
        out, _ = self.judge(c, "Show me the oldest members.")
        self.assertEqual(verdict(out.outcome), coverage.NEEDS_CHOICE)
        # whatever role the date was given: Q10 and Q11 marked it a filter
        as_filter = conclusion("ANSWER", ["members"], columns=[
            {"table": "members", "column": "joined_at", "role": "filter"}])
        out, _ = self.judge(as_filter, "Show me the oldest members.", final=False)
        self.assertTrue(any("compare them" in f for f in out.feedback))
        # compared already, or a single date: it stands
        nb = va.Notebook("Show me the oldest members.")
        nb.steps.append(SimpleNamespace(tool="compare_readings"))
        out, _ = self.judge(c, "", nb=nb)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)
        out, _ = self.judge(c, "Show me the oldest members.", facts=ONE_DATE, final=False)
        self.assertEqual(out.feedback, [])
        # "first names" orders nothing
        names = conclusion("ANSWER", ["members"],
                           columns=[{"table": "members", "column": "name", "role": "order"}])
        out, _ = self.judge(names, "What are the first names of the members?", final=False)
        self.assertNotIn("age", [k["check"] for k in out.checks])

    def test_an_answer_that_ranks_without_comparing_goes_back_once(self):
        # Warehouse Q09 under v6: suppliers.rating taken, nothing compared
        nb = va.Notebook("Who are our most active members?")
        nb.reading = dict(reading(["members"]), comparisons=["most active"])
        c = conclusion("ANSWER", ["members"])
        out, _ = self.judge(c, "", nb=nb, final=False)
        self.assertIn("not_compared", [k["status"] for k in out.checks])
        self.assertTrue(any("compare the two best" in f for f in out.feedback))
        out, _ = self.judge(c, "", nb=nb)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)
        nb.steps.append(SimpleNamespace(tool="compare_readings"))
        out, _ = self.judge(c, "", nb=nb, final=False)
        self.assertEqual(out.feedback, [])

    def test_a_phrase_neither_rule_settles_is_asked_once(self):
        # rule 3: "popular books" has no superlative; the model says it ranks
        asked = []

        def rank(question, phrase, thing):
            asked.append((phrase, thing))
            return answer
        c = conclusion("NOT_COVERED", ["books"], [issue(
            "absent_from_database", "popular books", what="popularity")])
        swept = {"popular books": (True, True, []), "popularity": (True, True, []),
                 "popular": (True, True, [])}
        for answer, expected in (("ranking", coverage.NEEDS_MORE), ("thing", coverage.NOT_COVERED)):
            asked.clear()
            tools = Tools(MEMBERS, absent=swept)
            out = va.Verifier(MEMBERS, tools, settings(), rank=rank).check(
                c, va.Notebook("What are the popular books?"), True)
            self.assertEqual(verdict(out.outcome), expected, answer)
            self.assertEqual(asked, [("popular books", "book")])
            swept_calls = [x for x in tools.calls if x[0] == "absent_everywhere"]
            self.assertEqual(bool(swept_calls), answer == "thing")
        # no model to ask, or nothing held named: looked for as it is
        tools = Tools(MEMBERS, absent=swept)
        out = va.Verifier(MEMBERS, tools, settings()).check(
            c, va.Notebook("What are the popular books?"), True)
        self.assertEqual(verdict(out.outcome), coverage.NOT_COVERED)
        asked.clear()
        answer = "ranking"
        patents = conclusion("NOT_COVERED", ["books"], [issue(
            "absent_from_database", "patents", what="patents")])
        va.Verifier(MEMBERS, Tools(MEMBERS, absent={"patents": (True, True, [])}), settings(),
                    rank=rank).check(patents, va.Notebook("Which patents do we hold?"), True)
        self.assertEqual(asked, [])

    def test_the_probe_looks_for_the_columns_of_a_comparison(self):
        # v7: every column that could measure "most reliable" is looked for,
        # on the tables one key away too
        first = dict(plan_turn(tables=["suppliers"]),
                     reading=dict(reading(["suppliers"]), comparisons=["most reliable", "late",
                                                                       "oldest"]))
        model = Model([first, conclude("ANSWER", ["suppliers"]), conclude("ANSWER", ["suppliers"])])
        tools = Tools(SHOP)
        agent(model, SHOP, tools).clarify("Who are our most reliable suppliers?")
        looked = [a for name, a in tools.calls if name == "find_columns"]
        self.assertEqual([a["phrase"] for a in looked], ["most reliable", "late"])
        self.assertEqual(set(looked[0]["tables"]), {"suppliers", "receipts"})

    def test_the_rank_question_is_closed_bounded_and_traced(self):
        replies = [{"is": "ranking", "why": "w"}, {"is": "thing", "why": "w"},
                   {"is": "ranking", "why": "w"}]
        model = Model(replies)
        a = agent(model, SHOP, Tools(SHOP))
        a._trace_now = {"turns": []}
        self.assertEqual(a._rank("q", "popular books", "book"), "ranking")
        self.assertEqual(a._rank("q", "patents", "patent"), "thing")
        self.assertIsNone(a._rank("q", "x", "y"))          # past MAX_RANK_CALLS
        self.assertEqual([t["kind"] for t in a._trace_now["turns"]], ["ranking", "ranking"])

TIERS = View({"orders": ["order_id", "customer_id", "order_date", "net_amount"],
              "customer_tiers": ["tier_id", "customer_id", "tier", "valid_from", "valid_to"],
              "reports": ["report_id", "submitted_at"],
              "approvals": ["approval_id", "report_id", "round", "decided_at"]},
             joins=[("orders", "customer_tiers", "orders.customer_id = customer_tiers.customer_id"),
                    ("approvals", "reports", "approvals.report_id = reports.report_id")])
KEPT_TIERS = {"customer_tiers": {"moments": [moment("valid_from", False, "date"),
                                            moment("valid_to", False, "date")],
                                 "intervals": [["valid_from", "valid_to"]], "history_tables": [],
                                 "event_type": None, "parent_links": []},
              "orders": {"moments": [moment("order_date", False, "date")], "intervals": [],
                         "history_tables": [], "event_type": None, "parent_links": []}}


class TwoReadingsInTimeTests(unittest.TestCase):
    """Two readings the agent saw and answered past (review of 26 October):
    a state kept over time read today or at the time (E46), and a duration
    from the first or the last of a repeated event (E62)."""

    def test_a_filter_on_a_state_kept_over_time_is_compared_once(self):
        tier = [{"table": "customer_tiers", "column": "tier", "role": "filter"},
                {"table": "orders", "column": "net_amount", "role": "measure"}]
        c = conclusion("ANSWER", ["orders", "customer_tiers"], columns=tier)

        def judge(question, final=False, steps=()):
            nb = va.Notebook(question)
            nb.steps.extend(steps)
            return va.Verifier(TIERS, Tools(TIERS, time=KEPT_TIERS), settings()).check(c, nb, final)
        out = judge("What was the net amount of orders from Gold customers in 2025?")
        self.assertIn("state_over_time", [k["check"] for k in out.checks])
        self.assertTrue(any("value in force today" in f for f in out.feedback))
        # said when, compared already, or the final round: it stands
        for question, steps, final in (
                ("What was the net amount of orders from customers Gold at the time?", (), False),
                ("What is the net amount of orders from customers who are Gold today?", (), False),
                ("What was the net amount of orders from Gold customers in 2025?",
                 (SimpleNamespace(tool="compare_readings"),), False),
                ("What was the net amount of orders from Gold customers in 2025?", (), True)):
            out = judge(question, final, steps)
            self.assertNotIn("state_over_time", [k["check"] for k in out.checks], question)
        self.assertEqual(verdict(out.outcome), coverage.ANSWERABLE)

    def test_a_duration_to_a_repeated_event_is_compared_once(self):
        timed = [{"table": "reports", "column": "submitted_at", "role": "time"},
                 {"table": "approvals", "column": "decided_at", "role": "time"}]
        c = dict(conclusion("ANSWER", ["reports", "approvals"], columns=timed),
                 joins=["approvals.report_id = reports.report_id"])

        def judge(n, final=False, time="duration"):
            nb = va.Notebook("What is the average time from submitting a report to its approval?")
            nb.reading = reading(["reports", "approvals"], time=time)
            tools = Tools(TIERS, counts={"HAVING COUNT(*) > 1": n})
            return va.Verifier(TIERS, tools, settings()).check(c, nb, final), tools
        out, tools = judge(12)
        self.assertTrue(any("from the first of them or from the last" in f for f in out.feedback))
        sent = [a["sql"] for name, a in tools.calls if name == "run_count"]
        self.assertEqual(len(sent), 1)
        self.assertIn("FROM `approvals`", sent[0])
        self.assertIn("GROUP BY `report_id`", sent[0])
        # one row a key, the final round, or no duration: it stands
        for n, final, time in ((0, False, "duration"), (12, True, "duration"), (12, False, "none")):
            out, _ = judge(n, final, time)
            self.assertNotIn("repeated_event", [k["check"] for k in out.checks], (n, final, time))

if __name__ == "__main__":
    unittest.main()


class VoteTests(unittest.TestCase):
    """Step 20: three strategies, a majority, a tie to the more demanding."""

    def voter(self, replies):
        model = Model(replies)
        clar = SimpleNamespace(llm=model, _llm=model, profile=None)
        tools = Tools(SHOP, compare=lambda s: pairs([300, 200]))
        v = va.VotingAgent(clar, view=SHOP, settings=settings(arbiter="vote"),
                           system="SYSTEM", toolbox=lambda c, w, st: tools)
        return v, model

    CHOICE = conclude("CHOICE", ["orders"], [issue("choice", "date", readings=[
        rd("a", "orders", "order_date", "SELECT 1"), rd("b", "orders", "promised_date", "SELECT 2")])])
    MORE = conclude("NEEDS_MORE", ["products"], [issue(
        "asker_must_say", "cheap", what="the price under which a product is cheap",
        kind="AmbiContext")])
    ANSWER = conclude("ANSWER", ["orders"])

    def test_a_plain_answer_is_final_and_costs_one_pass(self):
        v, model = self.voter([plan_turn(), self.ANSWER])
        self.assertEqual(verdict(v.clarify("q?")), coverage.ANSWERABLE)
        self.assertEqual(len(model.sent), 2)
        self.assertNotIn("vote", v.last_trace)

    def test_the_majority_decides(self):
        v, model = self.voter([plan_turn(), self.CHOICE, plan_turn(), self.ANSWER,
                               plan_turn(), self.CHOICE])
        self.assertEqual(verdict(v.clarify("q?")), coverage.NEEDS_CHOICE)
        self.assertEqual([p["verdict"] for p in v.last_trace["vote"]["passes"]],
                         ["NEEDS A CHOICE", "ANSWERABLE", "NEEDS A CHOICE"])
        self.assertIn("values first", model.sent[2]["system"])
        self.assertIn("joins first", model.sent[4]["system"])
        self.assertEqual(v.system, "SYSTEM")        # the base prompt comes back

    def test_a_tie_goes_to_what_asks_more_of_the_asker(self):
        v, _model = self.voter([plan_turn(), self.CHOICE, plan_turn(), self.ANSWER,
                                plan_turn(), self.MORE])
        self.assertEqual(verdict(v.clarify("q?")), coverage.NEEDS_MORE)

    def test_the_strategies_are_registered_prompts(self):
        import prompts
        self.assertIn("agent_values", prompts.VERSIONS)
        self.assertIn("agent_joins", prompts.VERSIONS)
        self.assertNotIn("unregistered", prompts.version_of("agent_values"))
