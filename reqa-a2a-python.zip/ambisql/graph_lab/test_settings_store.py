"""The settings store: what the page writes and everything else reads.

Nothing here needs a database or a model. Every test runs against a store
in its own temporary directory, so the suite never touches a real
deployment's configuration."""

import json
import os

# the column index is on by default; a test never builds one in a real
# Qdrant, and the tests that need one give it directly
os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
import pathlib
import sys
import tempfile
import unittest

# Tests never trace. The Langfuse client reads the repository .env,
# so without this every run of the suite sent its stand-in questions
# to a real Langfuse, and a suite that must run offline depended on a
# tracing server being up.
os.environ["DATAGORA_TRACING"] = "off"
# the developer's own .env must not change what these tests check
os.environ["DATAGORA_DOTENV"] = "off"
from unittest.mock import patch

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))

import settings_store as store


class StoreTests(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        # the store writes into the environment on save. This patch.dict is
        # the outermost one and snapshots the whole environment, so whatever
        # a test's saves write is undone with it rather than left behind
        env = patch.dict("os.environ", {"DATAGORA_DATA_DIR": self.tmp.name})
        env.start()
        self.addCleanup(env.stop)
        # which variables the store set belongs to one run of the page; a
        # test starts with none, so the order tests run in cannot matter
        store._SET_HERE.clear()
        store._BEFORE.clear()

    def endpoint(self, **kw):
        base = {"id": "gpu0", "label": "RTX 32G", "url": "http://gpu0:11434/",
                "api": "ollama", "model": "gemma4:31b", "num_ctx": 16384,
                "parallel": 2, "keep_alive": "30m", "vram_gb": 32}
        base.update(kw)
        return base

    def test_nothing_configured_changes_nothing(self):
        # no file means the older sources decide, exactly as before
        self.assertFalse(store.exists())
        self.assertIsNone(store.models_document())
        self.assertIsNone(store.profiles_document())

    def test_a_save_is_atomic_and_private(self):
        store.update("endpoints", [self.endpoint()])
        path = store.store_path()
        self.assertTrue(path.is_file())
        # no temporary file is left behind beside it
        leftovers = [p for p in path.parent.iterdir()
                     if p.name.startswith(".datagora.")]
        self.assertEqual(leftovers, [])
        if os.name == "posix":
            self.assertEqual(path.stat().st_mode & 0o777, 0o600)

    def test_secrets_never_reach_the_browser(self):
        store.update("databases", [{"name": "warehouse", "host": "db.internal",
                                    "database": "warehouse", "user": "ro",
                                    "password": "s3cret-value"}])
        seen = json.dumps(store.redacted())
        self.assertNotIn("s3cret-value", seen)
        db = store.redacted()["databases"][0]
        self.assertEqual(db["password"], "")
        self.assertTrue(db["password_set"])
        self.assertNotIn("admin", store.redacted())

    def test_an_empty_secret_keeps_the_stored_one(self):
        # the page never holds a secret, so it sends back an empty string;
        # that must mean "unchanged", not "erase it"
        store.update("databases", [{"name": "warehouse", "database": "w",
                                    "password": "keep-me"}])
        page = store.redacted()["databases"]
        page[0]["host"] = "moved.internal"
        store.update("databases", page)
        stored = store.load()["databases"][0]
        self.assertEqual(stored["password"], "keep-me")
        self.assertEqual(stored["host"], "moved.internal")

    def test_a_password_follows_its_database_not_its_position(self):
        # deleting the first database must not hand its password to the
        # second, which a match by list position would do
        store.update("databases", [
            {"name": "a", "database": "a", "password": "pa"},
            {"name": "b", "database": "b", "password": "pb"}])
        page = store.redacted()["databases"]
        store.update("databases", [page[1]])          # drop "a"
        remaining = store.load()["databases"]
        self.assertEqual([d["name"] for d in remaining], ["b"])
        self.assertEqual(remaining[0]["password"], "pb")

    def test_endpoints_are_normalised_and_bounded(self):
        store.update("endpoints", [self.endpoint(num_ctx="99999999",
                                                 parallel=0, api="OpenAI")])
        e = store.load()["endpoints"][0]
        self.assertEqual(e["url"], "http://gpu0:11434")    # trailing / gone
        self.assertEqual(e["parallel"], 1)                 # at least one
        self.assertLessEqual(e["num_ctx"], 1_048_576)
        self.assertEqual(e["api"], "openai")

    def test_a_role_is_a_pool_and_the_first_answers_alone(self):
        store.update("endpoints", [self.endpoint(id="gpu0"),
                                   self.endpoint(id="gpu1", url="http://gpu1:11434")])
        store.update("roles", {"reasoner": ["gpu1", "gpu0"], "sql": ["gpu0"]})
        models = store.models_document()
        self.assertEqual(models["pools"]["reasoner"], ["gpu1", "gpu0"])
        self.assertEqual(models["roles"]["reasoner"], "gpu1")
        self.assertIn("gpu0", models["endpoints"])

    def test_two_servers_with_the_same_label_stay_two(self):
        # review of 26 October: both became gemma4-31b and the first was lost
        a = self.endpoint(url="http://a:11434", api_key="ka")
        b = self.endpoint(url="http://b:11434", api_key="kb")
        for e in (a, b):
            del e["id"]
            e["label"] = "gemma4:31b"
        store.update("endpoints", [a, b])
        ids = [e["id"] for e in store.load()["endpoints"]]
        self.assertEqual(ids, ["gemma4-31b", "gemma4-31b-2"])
        store.update("roles", {"reasoner": ids, "sql": ids})
        models = store.models_document()
        self.assertEqual({models["endpoints"][i]["url"] for i in ids},
                         {"http://a:11434", "http://b:11434"})
        # the page sends secrets back empty: each keeps its own
        sent = [dict(e, api_key="") for e in store.redacted()["endpoints"]]
        store.update("endpoints", sent)
        self.assertEqual([e["api_key"] for e in store.load()["endpoints"]], ["ka", "kb"])

    def test_a_file_saved_with_one_id_twice_reads_as_two_servers(self):
        doc = {"endpoints": [self.endpoint(id="rtx", url="http://a:1"),
                             self.endpoint(id="rtx", url="http://b:1")],
               "roles": {"reasoner": ["rtx", "rtx"], "sql": ["rtx"]}}
        models = store.models_document(doc)
        self.assertEqual(models["pools"]["reasoner"], ["rtx", "rtx-2"])
        self.assertEqual(models["endpoints"]["rtx-2"]["url"], "http://b:1")

    def test_deleting_an_endpoint_prunes_it_from_every_role(self):
        store.update("endpoints", [self.endpoint(id="gpu0"),
                                   self.endpoint(id="gpu1")])
        store.update("roles", {"reasoner": ["gpu0", "gpu1"], "sql": ["gpu1"]})
        store.update("endpoints", [self.endpoint(id="gpu0")])
        roles = store.load()["roles"]
        self.assertEqual(roles["reasoner"], ["gpu0"])
        self.assertEqual(roles["sql"], [])

    def test_a_disabled_endpoint_serves_no_role(self):
        store.update("endpoints", [self.endpoint(id="gpu0", enabled=False),
                                   self.endpoint(id="gpu1")])
        store.update("roles", {"reasoner": ["gpu0", "gpu1"], "sql": []})
        models = store.models_document()
        self.assertEqual(models["pools"]["reasoner"], ["gpu1"])
        self.assertNotIn("gpu0", models["endpoints"])

    def test_databases_become_profiles_with_their_own_account(self):
        store.update("databases", [{"name": "warehouse", "host": "db.internal",
                                    "port": 3307, "database": "wh",
                                    "user": "ro", "password": "p"}])
        store.update("services", {"neo4j": {"uri": "bolt://g:7687", "user": "neo4j",
                                            "password": "n"},
                                  "qdrant": {"url": "", "api_key": "",
                                             "collection": ""},
                                  "langfuse": {"base_url": "", "public_key": "",
                                               "secret_key": ""}})
        prof = store.profiles_document()["profiles"]["warehouse"]
        self.assertEqual(prof["mysql"], {"host": "db.internal", "port": 3307,
                                         "database": "wh", "user": "ro",
                                         "password": "p"})
        self.assertEqual(prof["neo4j_uri"], "bolt://g:7687")
        self.assertNotIn("qdrant_url", prof)      # not configured, not invented

    def test_a_service_the_page_does_not_set_is_the_env_s(self):
        # a database added on the page, Qdrant set only in the .env: its
        # corpus was indexed and never searched, and no column index built
        store.update("databases", [{"name": "warehouse", "database": "wh"}])
        env = {"QDRANT_URL": "http://qdrant.internal:6333",
               "NEO4J_URI": "bolt://graph.internal:7687", "NEO4J_USER": "reader",
               "DATAGORA_EMBED_URL": '"http://embed.internal:11434"',
               "EMBED_MODEL": "nomic-embed-text"}
        with patch.dict("os.environ", env):
            prof = store.profiles_document()["profiles"]["warehouse"]
        self.assertEqual(prof["qdrant_url"], "http://qdrant.internal:6333")
        self.assertEqual((prof["neo4j_uri"], prof["neo4j_user"]),
                         ("bolt://graph.internal:7687", "reader"))
        self.assertEqual(prof["ollama_url"], "http://embed.internal:11434")
        self.assertEqual(prof["embed_model"], "nomic-embed-text")

    def test_the_page_s_service_wins_over_the_env_s(self):
        store.update("databases", [{"name": "warehouse", "database": "wh"}])
        store.update("services", {"qdrant": {"url": "http://from-the-page:6333"}})
        with patch.dict("os.environ", {"QDRANT_URL": "http://from-the-env:6333",
                                       "NEO4J_URI": "off"}):
            prof = store.profiles_document()["profiles"]["warehouse"]
        self.assertEqual(prof["qdrant_url"], "http://from-the-page:6333")
        self.assertNotIn("neo4j_uri", prof)       # off means no graph

    SERVICES = {"neo4j": {"uri": "bolt://g", "user": "neo4j",
                          "password": "from-the-page"},
                "qdrant": {"url": "", "api_key": "", "collection": ""},
                "langfuse": {"base_url": "", "public_key": "", "secret_key": ""}}

    def test_the_page_wins_over_the_env(self):
        # the page is where a deployment is configured: what it says runs,
        # and a field emptied on it gives the .env's value back
        with patch.dict("os.environ", {"NEO4J_PASSWORD": "from-the-env"}):
            store.update("databases", [{"name": "w", "database": "w"}])
            store.update("services", self.SERVICES)
            self.assertEqual(os.environ.get("NEO4J_PASSWORD"), "from-the-page")
            # a stored secret is never emptied by the page (an empty field
            # keeps it), so the store is given without one directly
            store.apply_to_environment({"databases": [{"name": "w"}],
                                        "services": {"neo4j": {"password": ""}}})
            self.assertEqual(os.environ.get("NEO4J_PASSWORD"), "from-the-env")

    def test_the_page_fills_what_the_env_leaves_unset(self):
        with patch.dict("os.environ", {"NEO4J_PASSWORD": ""}):
            store.update("databases", [{"name": "w", "database": "w"}])
            store.update("services", self.SERVICES)
            self.assertEqual(os.environ.get("NEO4J_PASSWORD"), "from-the-page")

    def services_with_score(self, score):
        return {**self.SERVICES,
                "qdrant": {"url": "http://q:6333", "api_key": "", "min_score": score}}

    def test_the_corpus_minimum_score_is_set_on_the_page(self):
        # with the databases in the .env and none on the page, the score
        # typed on the page still applies
        with patch.dict("os.environ", {"DATAGORA_CORPUS_MIN_SCORE": ""}):
            store.update("services", self.services_with_score("0.85"))
            self.assertEqual(os.environ.get("DATAGORA_CORPUS_MIN_SCORE"), "0.85")
            # emptied on the page, the default comes back
            store.update("services", self.services_with_score(""))
            # what was there before comes back: nothing, so the default
            self.assertFalse(os.environ.get("DATAGORA_CORPUS_MIN_SCORE"))

    def test_a_minimum_score_outside_zero_and_one_is_refused(self):
        for bad in ("1.5", "-0.1", "high"):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                store.update("services", self.services_with_score(bad))
        self.assertFalse(store.store_path().exists())     # nothing was saved

    def test_the_page_minimum_score_wins_and_its_absence_gives_the_env_back(self):
        with patch.dict("os.environ", {"DATAGORA_CORPUS_MIN_SCORE": "0.7"}):
            store.update("services", self.services_with_score("0.9"))
            self.assertEqual(os.environ.get("DATAGORA_CORPUS_MIN_SCORE"), "0.9")
            store.update("services", self.services_with_score(""))
            self.assertEqual(os.environ.get("DATAGORA_CORPUS_MIN_SCORE"), "0.7")

    def test_a_key_copied_with_its_quotes_loses_them(self):
        # the .env writes LANGFUSE_SECRET_KEY="sk-lf-..."; copied with one of
        # its quotes, the key failed with a 401 that said nothing of why
        services = {**self.SERVICES,
                    "langfuse": {"base_url": ' "http://lf:3000" ', "public_key": '"pk-lf-1"',
                                 "secret_key": '"sk-lf-2'},
                    "neo4j": {"uri": "bolt://g", "user": "neo4j", "password": '"quoted"'}}
        store.update("services", services)
        saved = store.load()["services"]
        self.assertEqual(saved["langfuse"], {"base_url": "http://lf:3000",
                                             "public_key": "pk-lf-1", "secret_key": "sk-lf-2"})
        # a password may hold a quote, and keeps it
        self.assertEqual(saved["neo4j"]["password"], '"quoted"')

    def test_the_column_index_is_switched_on_the_page(self):
        import recall
        with patch.dict("os.environ", {"DATAGORA_COLUMN_INDEX": "", "DATAGORA_COLUMN_MIN_Z": ""}):
            self.assertTrue(recall.column_index_on())             # on by default
            store.update("databases", [{"name": "w", "database": "w"}])
            store.update("engine", {**store.load()["engine"], "column_index": False,
                                    "column_min_z": "4.5"})
            self.assertFalse(recall.column_index_on())
            self.assertEqual(recall.ColumnIndex(None, "p", None).min_z, 4.5)
            store.update("engine", {**store.load()["engine"], "column_index": True})
            self.assertTrue(recall.column_index_on())

    def test_a_standout_outside_one_and_ten_is_refused(self):
        for bad in ("0.5", "11", "high"):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                store.update("engine", {**store.load()["engine"], "column_min_z": bad})

    def test_an_untouched_store_imposes_no_engine_value(self):
        # the engine defaults on the page are the code's own; written into
        # the environment they would read as the .env having given them
        with patch.dict("os.environ", {"DATAGORA_SCHEMA_SAMPLES": ""}):
            store.update("services", self.SERVICES)
            self.assertEqual(os.environ.get("DATAGORA_SCHEMA_SAMPLES"), "")

    def test_a_preset_photographs_the_models_and_never_the_credentials(self):
        store.update("endpoints", [self.endpoint(id="gpu0")])
        store.update("databases", [{"name": "w", "database": "w",
                                    "password": "db-secret"}])
        preset = store.save_preset("Duo 31B")
        self.assertIn("endpoints", preset["payload"])
        self.assertNotIn("databases", preset["payload"])
        self.assertNotIn("db-secret", json.dumps(preset))

    def test_a_preset_restores_and_knows_it_is_active(self):
        store.update("endpoints", [self.endpoint(id="gpu0", model="gemma4:31b")])
        big = store.save_preset("31B")
        store.update("endpoints", [self.endpoint(id="local", model="gemma3:4b")])
        store.save_preset("local")
        active = {p["name"]: p["matches_current"] for p in store.list_presets()}
        self.assertEqual(active, {"31B": False, "local": True})

        store.restore_preset(big["id"])
        self.assertEqual(store.load()["endpoints"][0]["model"], "gemma4:31b")
        active = {p["name"]: p["matches_current"] for p in store.list_presets()}
        self.assertEqual(active, {"31B": True, "local": False})

    def test_saving_under_an_existing_name_replaces_it(self):
        store.update("endpoints", [self.endpoint(model="a")])
        store.save_preset("same")
        store.update("endpoints", [self.endpoint(model="b")])
        store.save_preset("same")
        presets = store.list_presets()
        self.assertEqual(len(presets), 1)
        self.assertEqual(presets[0]["payload"]["endpoints"][0]["model"], "b")

    def test_the_admin_password_is_hashed_and_sessions_are_signed(self):
        self.assertFalse(store.has_admin())
        with self.assertRaises(ValueError):
            store.set_admin_password("short")
        store.set_admin_password("a long enough password")
        raw = store.store_path().read_text(encoding="utf-8")
        self.assertNotIn("a long enough password", raw)
        self.assertTrue(store.check_password("a long enough password"))
        self.assertFalse(store.check_password("wrong"))

        token = store.issue_session()
        self.assertTrue(store.valid_session(token))
        # tampered: the last character changed to one it is not. Replacing
        # it with "0" left the token intact whenever it already ended in 0,
        # which made this test fail about one run in sixteen
        tampered = token[:-1] + ("1" if token[-1] == "0" else "0")
        self.assertFalse(store.valid_session(tampered))
        self.assertFalse(store.valid_session(""))

    def test_changing_the_password_needs_the_old_one_and_ends_sessions(self):
        store.set_admin_password("first long password")
        token = store.issue_session()
        with self.assertRaises(PermissionError):
            store.set_admin_password("second long password", current="nope")
        store.set_admin_password("second long password",
                                 current="first long password")
        self.assertFalse(store.valid_session(token))

    def test_the_page_is_what_the_engine_actually_uses(self):
        # the point of the store: once the page has saved something, the
        # database list, the roles and the endpoints all come from it, and
        # the page says so in the line that names its configuration source
        import db_profile
        import llm
        store.update("databases", [{"name": "warehouse", "host": "db.internal",
                                    "database": "wh", "user": "ro",
                                    "password": "p"}])
        store.update("endpoints", [self.endpoint(id="gpu0"),
                                   self.endpoint(id="gpu1",
                                                 url="http://gpu1:11434",
                                                 num_ctx=32768)])
        store.update("roles", {"reasoner": ["gpu0", "gpu1"], "sql": ["gpu1"]})

        self.assertEqual(db_profile.DbProfile.names(), ["warehouse"])
        prof = db_profile.DbProfile.load("warehouse")
        self.assertEqual(prof.mysql["host"], "db.internal")
        self.assertEqual(prof.mysql["user"], "ro")

        reasoner = llm.LLM.role("reasoner")
        self.assertEqual((reasoner.name, reasoner.model), ("gpu0", "gemma4:31b"))
        self.assertEqual([e.name for e in llm.LLM.pool("reasoner")],
                         ["gpu0", "gpu1"])
        self.assertEqual(llm.LLM.pool("sql")[0].num_ctx, 32768)

        self.assertIn("settings page", db_profile.profiles_source()[0])
        self.assertIn("settings page", llm.models_source()[0])
        self.assertFalse(db_profile.profiles_source()[1])     # not the demo

    def test_a_leftover_variable_cannot_override_the_page(self):
        # the failure this whole store exists to end: a value left in a
        # compose file silently replacing the one somebody chose
        import db_profile
        import llm
        store.update("databases", [{"name": "warehouse", "host": "db.internal",
                                    "database": "wh"}])
        store.update("endpoints", [self.endpoint(id="gpu0")])
        store.update("roles", {"reasoner": ["gpu0"], "sql": ["gpu0"]})
        with patch.dict("os.environ", {"DATAGORA_MYSQL_HOST": "mariadb",
                                       "DATAGORA_LLM_REASONER": "elsewhere",
                                       "MYSQL_DATABASE": "other"}):
            self.assertEqual(db_profile.DbProfile.load("warehouse").mysql["host"],
                             "db.internal")
            self.assertEqual(db_profile.DbProfile.names(), ["warehouse"])
            self.assertEqual(llm.LLM.role("reasoner").name, "gpu0")

    UNSET = {k: "" for k in ("DATAGORA_PROFILES", "DATAGORA_DATABASES",
                             "MYSQL_DATABASE", "DATAGORA_MODELS",
                             "DATAGORA_ENDPOINTS", "DATAGORA_LLM_URL",
                             "DATAGORA_LLM_MODEL", "DATAGORA_LLM_ENDPOINT")}

    def test_with_nothing_configured_nothing_is_offered(self):
        # there is no demo to fall back on any more: an empty configuration
        # lists nothing, says so, and refuses a name rather than guessing
        import db_profile
        import llm
        with patch.dict("os.environ", self.UNSET):
            self.assertIsNone(db_profile._saved_profiles())
            self.assertEqual(db_profile.DbProfile.names(), [])
            self.assertTrue(db_profile.profiles_source()[1])
            self.assertTrue(llm.models_source()[1])
            with self.assertRaises(SystemExit):
                db_profile.DbProfile.load("datagora_lib")
            with self.assertRaises(SystemExit):
                llm.LLM.role("reasoner")

    def test_a_database_from_the_page_has_its_corpus_and_its_embedding(self):
        # configured only on the page, a database used to reach Qdrant with
        # no embedding model, so its corpus was never searched; and a single
        # collection set for all databases made each search the others
        store.update("databases", [
            {"name": "w", "database": "w", "host": "db"},
            {"name": "b", "database": "b", "host": "db",
             "qdrant_collection": "billing_questions"}])
        store.update("services", {
            "neo4j": {"uri": "", "user": "neo4j", "password": ""},
            "qdrant": {"url": "http://q:6333", "api_key": ""},
            "embedding": {"url": "http://ollama:11434", "model": "nomic-embed-text"},
            "langfuse": {"base_url": "", "public_key": "", "secret_key": ""}})
        profiles = store.profiles_document()["profiles"]
        self.assertNotIn("qdrant_collection", profiles["w"])
        self.assertEqual(profiles["b"]["qdrant_collection"], "billing_questions")
        for p in profiles.values():
            self.assertEqual((p["ollama_url"], p["embed_model"]),
                             ("http://ollama:11434", "nomic-embed-text"))

    def test_the_page_databases_win_over_the_env(self):
        # a database added on the page is the one offered, whatever the
        # .env on the same machine lists; the .env's serve only while the
        # page has none
        import db_profile
        with patch.dict("os.environ", dict(
                self.UNSET, DATAGORA_DATABASES="listed",
                DATAGORA_DB_LISTED_HOST="db.internal")):
            self.assertEqual(db_profile.DbProfile.names(), ["listed"])
            self.assertIn("since the settings page has no database",
                          db_profile.profiles_source()[0])
            store.update("databases", [{"name": "saved", "host": "10.0.0.9",
                                        "port": 3306, "database": "saved",
                                        "user": "u", "password": "p"}])
            self.assertEqual(db_profile.DbProfile.names(), ["saved"])
            self.assertIn("settings page", db_profile.profiles_source()[0])
            self.assertEqual(db_profile.DbProfile.load("saved").mysql["host"], "10.0.0.9")

    def test_each_database_reads_the_graph_chosen_for_it(self):
        # by default the graph named after the database itself, never after
        # the name it is shown by; one can be picked, or the whole graph
        import db_profile
        from schema_graph import Graph

        class Driver:
            def session(self, **_kw):
                return self

            def __enter__(self):
                return self

            def __exit__(self, *_a):
                return False

            def run(self, *_a, **_kw):
                return []

        store.update("databases", [
            {"name": "Library", "database": "datagora_lib"},
            {"name": "Copy", "database": "datagora_lib", "neo4j_graph": "lib_v2"},
            {"name": "Only one", "database": "x", "neo4j_graph": "*"}])
        load = db_profile.DbProfile.load
        self.assertEqual(load("Library").graph_key, "datagora_lib")
        self.assertEqual(load("Copy").graph_key, "lib_v2")
        self.assertEqual(Graph.from_profile(load("Library"), Driver()).match,
                         {"db": "datagora_lib"})
        self.assertEqual(Graph.from_profile(load("Only one"), Driver()).match, {})

    def test_a_page_database_on_loopback_reaches_the_platform_in_a_container(self):
        # the rule the page's Test follows, so a test that says connected
        # is a database the questions reach; a real address is left alone
        import db_profile
        store.update("databases", [
            {"name": "here", "host": "127.0.0.1", "database": "h"},
            {"name": "there", "host": "db.internal", "database": "t"}])
        with patch.dict("os.environ", {"DATAGORA_MYSQL_HOST": "mariadb"}):
            self.assertEqual(db_profile.DbProfile.load("here").mysql["host"], "mariadb")
            self.assertEqual(db_profile.DbProfile.load("there").mysql["host"], "db.internal")

    def test_an_unreadable_file_is_the_defaults_not_a_crash(self):
        store.data_dir().mkdir(parents=True, exist_ok=True)
        store.store_path().write_text("{ not json", encoding="utf-8")
        self.assertEqual(store.load()["endpoints"], [])
        self.assertFalse(store.exists())


class SettingsHttpTests(unittest.TestCase):
    """The routes as a browser reaches them: only status, setup, login and
    logout are public, and a logout ends the session itself."""

    PUBLIC = {("GET", "/api/settings/status"), ("POST", "/api/settings/setup"),
              ("POST", "/api/settings/login"), ("POST", "/api/settings/logout")}

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        env = patch.dict("os.environ", {"DATAGORA_DATA_DIR": self.tmp.name})
        env.start()
        self.addCleanup(env.stop)
        store._SET_HERE.clear()
        store._BEFORE.clear()
        sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent / "ui"))
        import settings_api
        from fastapi import FastAPI
        from fastapi.testclient import TestClient
        app = FastAPI()
        app.include_router(settings_api.router)
        self.api, self.app = settings_api, app
        self.client = TestClient(app)

    def test_review_of_the_fixes_a_logout_always_drops_the_cookie(self):
        self.client.post("/api/settings/setup", json={"password": "a long password"})
        with patch.object(store, "end_session", side_effect=OSError("read-only volume")):
            r = self.client.post("/api/settings/logout")
        self.assertEqual(r.status_code, 200)
        self.assertIn("dg_admin=", r.headers.get("set-cookie", ""))

    def test_every_route_but_four_needs_the_login(self):
        # review of 26 October: nothing guarded this
        for route in self.app.routes:
            if not route.path.startswith("/api/settings"):
                continue          # FastAPI's own docs routes
            for method in sorted(getattr(route, "methods", None) or ()):
                key = (method, route.path)
                guarded = any(getattr(d.call, "__name__", "") == "require_admin"
                              for d in route.dependant.dependencies)
                self.assertEqual(guarded, key not in self.PUBLIC, key)

    def test_a_logout_ends_the_session_not_only_the_cookie(self):
        # review of 26 October: a cookie copied before logout still opened
        # the settings for twelve hours
        self.assertEqual(self.client.post("/api/settings/setup",
                                          json={"password": "a long password"}).status_code, 200)
        token = self.client.cookies.get(self.api.COOKIE)
        self.assertEqual(self.client.get("/api/settings").status_code, 200)
        self.client.post("/api/settings/logout")
        copied = {self.api.COOKIE: token}
        self.assertEqual(self.client.get("/api/settings", cookies=copied).status_code, 401)
        # a new login opens it again
        self.client.post("/api/settings/login", json={"password": "a long password"})
        self.assertEqual(self.client.get("/api/settings").status_code, 200)


if __name__ == "__main__":
    unittest.main(verbosity=2)
