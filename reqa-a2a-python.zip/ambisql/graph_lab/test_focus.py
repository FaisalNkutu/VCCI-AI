"""The schema a model is shown when the whole does not fit its window.

No database, no model, no Qdrant: the clarifier is handed its catalogue
directly, and the model is a stand-in that records what it was sent."""

import os

os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

import pathlib
import sys
import unittest
from unittest.mock import patch

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import dictionary  # noqa: E402
import focus  # noqa: E402
from ambisql import Clarifier  # noqa: E402

GENERIC = [("name", "varchar"), ("city", "varchar"), ("status", "varchar"),
           ("quantity", "int"), ("capacity", "int"), ("created_at", "datetime"),
           ("amount", "decimal"), ("notes", "varchar")]


class Model:
    """Stands in for an endpoint: a window, and what it was sent."""

    def __init__(self, num_ctx):
        self.num_ctx = num_ctx
        self.sent = []

    def json(self, system, user, schema=None):
        self.sent.append((system, user, schema))
        return {"reason": "", "ambiguous": False, "phrase": "", "kind": "",
                "candidates": [], "operations": [], "value": ""}


def clarifier(tables, fks=None, edges=None, num_ctx=4096, samples=None):
    clar = Clarifier(connect=lambda: None, schema="test", llm=Model(num_ctx))
    clar._columns = tables
    clar._keys = {(t.lower(), c.lower()) for t, cols in tables.items()
                  for c, _ in cols if c.endswith("_id")}
    clar._foreign_keys = fks or {}
    clar._samples = samples or {}
    clar._views = {}
    clar._meanings = dictionary.empty()
    clar._graph_edges = edges or []
    clar._index_checked = True
    clar._corpus_checked = True
    clar._reranker_checked = True
    return clar


def wide(extra=200):
    """A warehouse among many tables of other trades, the others sharing
    its common column names, as a real database does."""
    tables = {
        "warehouses": [("warehouse_id", "int"), ("code", "varchar"), ("name", "varchar"),
                       ("city", "varchar"), ("capacity_units", "int")],
        "inventory": [("product_id", "int"), ("warehouse_id", "int"),
                      ("quantity_on_hand", "int"), ("reorder_level", "int")],
        "products": [("product_id", "int"), ("product_name", "varchar"), ("price", "decimal")],
        "sea_shipments": [("sea_shipment_id", "int"), ("vessel_name", "varchar"),
                          ("container_count", "int")],
    }
    for i in range(extra):
        tables[f"dept{i}_records"] = [(f"dept{i}_record_id", "int")] + GENERIC
    fks = {("inventory", "warehouse_id"): ("warehouses", "warehouse_id"),
           ("inventory", "product_id"): ("products", "product_id")}
    return tables, fks


class WholeWhenItFitsTests(unittest.TestCase):
    def test_a_schema_that_fits_goes_whole_and_unchanged(self):
        tables, fks = wide(extra=3)
        clar = clarifier(tables, fks, num_ctx=16384)
        text, shown = clar.schema_for("How many warehouses are there per city?")
        self.assertIsNone(shown)
        self.assertIsNone(clar.last_focus)
        self.assertEqual(text, clar.schema_text())

    def test_a_model_that_does_not_say_its_window_gets_it_whole(self):
        tables, fks = wide()
        clar = clarifier(tables, fks)
        clar._llm = object()
        self.assertIsNone(clar.schema_for("How many warehouses per city?")[1])

    def test_it_can_be_switched_off(self):
        tables, fks = wide()
        clar = clarifier(tables, fks)
        with patch.dict(os.environ, {"DATAGORA_FOCUS": "off"}):
            self.assertIsNone(clar.schema_for("How many warehouses per city?")[1])


class CutToTheWindowTests(unittest.TestCase):
    def setUp(self):
        tables, fks = wide()
        self.clar = clarifier(tables, fks, num_ctx=4096)
        self.whole = sum(focus.tokens(b) + 1 for b in self.clar._table_blocks().values())

    def test_what_is_sent_fits_the_room(self):
        question = "What is the total storage capacity per warehouse city?"
        text, shown = self.clar.schema_for(question)
        room = self.clar.schema_room(question)
        self.assertGreater(self.whole, room)
        self.assertLessEqual(focus.tokens(text), room)
        self.assertLess(len(shown), len(self.clar.columns))
        self.assertIn("more tables of this database are not shown", text)

    def test_a_rare_word_outranks_a_common_one(self):
        # "city" and "capacity" are in two hundred tables, "warehouse" in two
        _text, shown = self.clar.schema_for(
            "What is the total storage capacity per warehouse city?")
        self.assertEqual(shown[0], "warehouses")

    def test_the_table_between_two_others_comes_with_them(self):
        # nothing in the question names inventory; it joins the two that are
        _text, shown = self.clar.schema_for(
            "Which products are in which warehouse?")
        self.assertIn("inventory", shown[:5])

    def test_the_tables_needed_are_first(self):
        _text, shown = self.clar.schema_for("Which vessels carried more than 10 containers?")
        self.assertEqual(shown[0], "sea_shipments")

    def test_a_value_points_at_its_table(self):
        tables, fks = wide()
        clar = clarifier(tables, fks, samples={
            ("sea_shipments", "vessel_name"): ["Nordic Star", "Atlantic Dawn"]})
        _text, shown = clar.schema_for("What did the Atlantic Dawn carry?")
        self.assertEqual(shown[0], "sea_shipments")

    def test_the_model_can_only_name_what_it_was_shown(self):
        self.clar.detect("What is the total storage capacity per warehouse city?")
        _system, user, schema = self.clar.llm.sent[-1]
        shown = schema["properties"]["candidates"]["items"]["properties"]["table"]["enum"]
        self.assertIn("warehouses", shown)
        self.assertLess(len(shown), len(self.clar.columns))
        self.assertTrue(all(f"TABLE {t}" in user for t in shown if t))

    def test_the_choice_is_reported(self):
        self.clar.schema_for("What is the total storage capacity per warehouse city?")
        report = self.clar.last_focus
        self.assertEqual(report["tables"], len(self.clar.columns))
        self.assertGreater(report["kept"], 0)
        self.assertIn("words", report["by"])


class CountedTests(unittest.TestCase):
    """The estimate of a schema's size, and its correction by the counts a
    model server returns."""

    def test_digits_cost_a_token_each(self):
        # Gemma reads 2026-03-15 as ten tokens, not three or four
        self.assertGreater(focus.tokens("2026-03-15 10:00:00 " * 50),
                           focus.tokens("warehouse capacity " * 50))

    def counted(self, clar, times, server=None):
        """The clarifier told its last schema counted `times` the estimate,
        by a reply that came with `server` as Ollama describes it."""
        schema, shown = clar.schema_for("How many warehouses per city?")
        estimated = focus.tokens(schema)
        user = "Schema:\n" + schema
        prose = (len(clar.system) + len(user) - len(schema)) / clar.PROSE_CHARS_PER_TOKEN
        clar.llm.last_prompt_tokens = int(estimated * times + prose)
        clar.llm.last_error = ""
        clar.llm.last_server = server or {}
        clar._learn_tokens(clar.llm, clar.system, user, schema)
        return shown

    def test_the_estimate_is_corrected_from_the_count(self):
        tables, fks = wide()
        clar = clarifier(tables, fks, num_ctx=4096)
        # every related table wanted, so the window is what limits the cut
        with patch.dict(os.environ, {"DATAGORA_FOCUS_MIN_SHARE": "0"}):
            # the server counted half as much again as the estimate said
            before = self.counted(clar, 1.5)
            self.assertGreater(clar._token_scale, 1.3)
            _again, shown = clar.schema_for("How many warehouses per city?")
        self.assertLess(len(shown), len(before))

    def test_a_reply_with_thinking_teaches_nothing(self):
        # Ollama's count took the thinking in: learned from it, the scale
        # climbed over a run and the later questions saw fewer tables
        tables, fks = wide()
        clar = clarifier(tables, fks, num_ctx=4096)
        self.counted(clar, 1.6, server={"thinking_chars": 4000})
        self.assertEqual(clar._token_scale, 1.0)
        # a reply without thinking still corrects it
        self.counted(clar, 1.5, server={"reply_tokens": 60})
        self.assertGreater(clar._token_scale, 1.3)

    def test_a_window_filled_while_thinking_leaves_the_scale_as_it_was(self):
        tables, fks = wide()
        clar = clarifier(tables, fks, num_ctx=4096)
        calls = []

        def json(system, user, schema=None):
            calls.append(len(user))
            clar.llm.last_server = {"thinking_chars": 9000}
            clar.llm.last_prompt_tokens = 4095
            if len(calls) == 1:
                clar.llm.last_error = "the prompt did not fit: about 5000 tokens were sent"
                return None
            clar.llm.last_error = ""
            return {"ambiguous": False}

        clar.llm.json = json
        with patch.dict(os.environ, {"DATAGORA_FOCUS_MIN_SHARE": "0"}):
            reply = clar.detect("What is the total storage capacity per warehouse city?")
        self.assertEqual(reply, {"ambiguous": False})
        self.assertLess(calls[1], calls[0])       # asked again smaller
        self.assertEqual(clar._token_scale, 1.0)  # and the next question as before

    def test_a_prompt_the_server_cut_is_asked_again_smaller(self):
        tables, fks = wide()
        clar = clarifier(tables, fks, num_ctx=4096)
        calls = []

        def json(system, user, schema=None):
            calls.append(len(user))
            if len(calls) == 1:
                clar.llm.last_error = "the prompt did not fit: about 5000 tokens were sent"
                return None
            clar.llm.last_error = ""
            return {"ambiguous": False}

        clar.llm.json = json
        clar.llm.last_prompt_tokens = None
        # every related table kept, so the window is what limits the cut
        with patch.dict(os.environ, {"DATAGORA_FOCUS_MIN_SHARE": "0"}):
            reply = clar.detect("What is the total storage capacity per warehouse city?")
        self.assertEqual(reply, {"ambiguous": False})
        self.assertEqual(len(calls), 2)
        self.assertLess(calls[1], calls[0])

    def test_a_reply_that_failed_otherwise_is_not_asked_again(self):
        tables, fks = wide()
        clar = clarifier(tables, fks, num_ctx=4096)
        calls = []

        def json(system, user, schema=None):
            calls.append(1)
            clar.llm.last_error = "http://gpu did not answer: timed out after 600 s."
            return None

        clar.llm.json = json
        self.assertIsNone(clar.detect("How many warehouses per city?"))
        self.assertEqual(len(calls), 1)


class OperationWordsTests(unittest.TestCase):
    def test_a_word_that_only_computes_brings_no_table_in(self):
        tables, fks = wide(extra=60)
        tables["exam_results"] = [("exam_result_id", "int"), ("average_score", "decimal")]
        clar = clarifier(tables, fks, num_ctx=131072)
        _text, shown = clar.schema_for("What is the average capacity of warehouses?")
        self.assertEqual(shown[0], "warehouses")
        self.assertNotIn("exam_results", shown[:focus.MIN_TABLES])


class LeftOutTests(unittest.TestCase):
    """What scores far below the best is left out, even with room to spare."""

    def test_tables_far_below_the_best_are_left_out(self):
        tables, fks = wide()
        clar = clarifier(tables, fks, num_ctx=131072)      # room for everything
        _text, shown = clar.schema_for("Which vessels carried more than 10 containers?")
        self.assertEqual(shown[0], "sea_shipments")
        self.assertLessEqual(len(shown), focus.MIN_TABLES)
        self.assertEqual(clar.last_focus["relevant_left_out"], [])

    def test_a_large_schema_is_cut_even_when_it_fits(self):
        tables, fks = wide(extra=focus.FROM_TABLES + 10)
        clar = clarifier(tables, fks, num_ctx=1_048_576)
        self.assertIsNotNone(clar.schema_for("How many warehouses per city?")[1])

    def test_a_small_one_that_fits_goes_whole(self):
        tables, fks = wide(extra=focus.FROM_TABLES - 10)
        clar = clarifier(tables, fks, num_ctx=1_048_576)
        self.assertIsNone(clar.schema_for("How many warehouses per city?")[1])

    def test_the_share_can_be_moved(self):
        tables, fks = wide()
        clar = clarifier(tables, fks, num_ctx=131072)
        question = "What is the total storage capacity per warehouse city?"
        strict = len(clar.schema_for(question)[1])
        with patch.dict(os.environ, {"DATAGORA_FOCUS_MIN_SHARE": "0"}):
            loose = len(clar.schema_for(question)[1])
        self.assertGreater(loose, strict)


class ShortFormTests(unittest.TestCase):
    """The best tables whole, the others kept in short form, so the table
    between two others is not the one the room leaves out."""

    def setUp(self):
        tables, fks = wide()
        self.clar = clarifier(tables, fks, num_ctx=4096)
        self.question = "What is the total storage capacity per warehouse city?"

    def test_a_short_table_is_its_names_and_its_joins(self):
        short = self.clar._short_blocks()["inventory"]
        self.assertEqual(short.splitlines()[0], "TABLE inventory")
        self.assertIn("product_id->products.product_id", short)
        self.assertIn("warehouse_id->warehouses.warehouse_id", short)
        self.assertIn("quantity_on_hand", short)
        self.assertNotIn(" int", short)
        self.assertLess(focus.tokens(short),
                        focus.tokens(self.clar._table_blocks()["inventory"]))

    def test_the_best_are_whole_and_the_rest_short(self):
        with patch.dict(os.environ, {"DATAGORA_FOCUS_MIN_SHARE": "0"}):
            text, shown = self.clar.schema_for(self.question)
        report = self.clar.last_focus
        whole = [t for t in shown if t not in report["short"]]
        self.assertEqual(whole, shown[:focus.FULL_TABLES])
        self.assertEqual(report["short"], shown[focus.FULL_TABLES:])
        self.assertTrue(report["short"])
        self.assertTrue(all(f"TABLE {t}" in text for t in shown))
        self.assertIn(self.clar._short_blocks()[report["short"][0]], text)
        self.assertIn("shown in short form", text)
        self.assertLessEqual(focus.tokens(text), self.clar.schema_room(self.question))
        self.assertEqual(report["kept"], len(shown))

    def test_more_tables_are_shown_than_whole_alone(self):
        blocks = self.clar._table_blocks()
        room = self.clar.schema_room(self.question)
        with patch.dict(os.environ, {"DATAGORA_FOCUS_MIN_SHARE": "0"}):
            whole, alone = focus.choose(self.clar, self.question, blocks, room)
            kept, report = focus.choose(self.clar, self.question, blocks, room,
                                        short=self.clar._short_blocks())
        self.assertEqual(alone["short"], [])
        self.assertGreater(len(kept), len(whole))
        self.assertEqual(kept[:focus.FULL_TABLES], whole[:focus.FULL_TABLES])
        self.assertLessEqual(report["tokens_kept"], room)

    def test_the_note_says_what_short_and_absent_mean(self):
        self.assertEqual(focus.note(0), "")
        said = focus.note(140, 30)
        self.assertIn("30 of the tables above are shown in short form", said)
        self.assertIn("real tables", said)
        self.assertIn("140 more tables", said)
        self.assertIn("may still exist", said)
        self.assertNotIn("short form", focus.note(140))


class Neo4jLinksTests(unittest.TestCase):
    def test_a_graph_link_is_shown_like_a_foreign_key(self):
        tables, _fks = wide(extra=2)
        clar = clarifier(tables, {}, edges=[("inventory", "warehouse_id",
                                             "warehouses", "warehouse_id")])
        block = clar._table_blocks()["inventory"]
        self.assertIn("-> warehouses.warehouse_id", block)

    def test_a_graph_link_brings_its_table_along(self):
        tables, _fks = wide()
        tables["stock_counts"] = [("count_id", "int"), ("site_ref", "int"),
                                  ("counted", "int")]
        clar = clarifier(tables, {}, edges=[("stock_counts", "site_ref",
                                             "warehouses", "warehouse_id")])
        _text, shown = clar.schema_for("How many warehouses are there?")
        self.assertIn("stock_counts", shown[:5])

    def test_a_composite_link_is_used_but_not_written(self):
        tables, _fks = wide(extra=2)
        clar = clarifier(tables, {}, edges=[("inventory", "product_id,warehouse_id",
                                             "warehouses", "x,y")])
        self.assertNotIn("->", clar._table_blocks()["inventory"])
        self.assertIn("warehouses", clar.table_links()["inventory"])


class RerankedTests(unittest.TestCase):
    """Coverage with a reranker: the columns it reads earn their tables
    points on top of the vector's, never in place of them."""

    class Index:
        def candidates(self, phrase, limit=40):
            return [("leads", "source", 0.81, "leads.source | source"),
                    ("product_suppliers", "lead_time_days", 0.74,
                     "product_suppliers.lead_time_days | lead time days")]

        def standing(self, phrase, limit=128):
            return [("leads", "source", 0.81, 2.0)]

    class Reranker:
        name, kind = "stand-in", "cross"
        model = type("InDatagora", (), {"api": "local"})()

        def rank(self, query, documents):
            return [(1, 0.95), (0, 0.05)]

    def test_the_column_it_keeps_earns_its_table_points(self):
        clar = clarifier(wide(extra=2)[0])
        clar._reranker = self.Reranker()
        best = focus._reranked(clar, self.Index(), "average lead time")
        self.assertEqual(best, {"product_suppliers": focus.RERANKED * 0.95})

    def test_an_embedding_model_as_reranker_leaves_coverage_alone(self):
        clar = clarifier(wide(extra=2)[0])
        clar._reranker = self.Reranker()
        clar._reranker.model = type("LLM", (), {"api": "ollama"})()
        self.assertEqual(focus._reranked(clar, self.Index(), "average lead time"), {})

    def test_without_a_reranker_nothing_is_added(self):
        self.assertEqual(focus._reranked(clarifier(wide(extra=2)[0]), self.Index(), "q"), {})


import llm  # noqa: E402


class EstimateTests(unittest.TestCase):
    """The cut counts a schema as the rest of the engine counts a prompt,
    llm.estimate_tokens, with the rates measured on gemma4:31b."""

    def test_the_cut_counts_as_the_engine_does(self):
        for text in ("warehouse capacity", "2026-03-15", "Société Générale",
                     "仓库容量", "", None):
            self.assertEqual(focus.tokens(text), int(llm.estimate_tokens(text or "")) + 1)
        # the scale a clarifier learned still applies before the rounding
        self.assertEqual(focus.tokens("x" * 270, 1.5), 151)

    def test_an_accent_costs_about_the_letter_it_sits_on(self):
        # token_calibration.py, 2026-10-19: French prose counted 300 tokens
        # with its accents and 316 without, a schema of French names 312
        # against 299; 0.021 of a token less than a plain letter overall
        self.assertEqual(llm.LATIN, 0.35)
        french = "Le délai de clôture prévu dépend de la gravité ; créances échues."
        plain = "Le delai de cloture prevu depend de la gravite ; creances echues."
        self.assertAlmostEqual(focus.tokens(french), focus.tokens(plain), delta=1)
        self.assertEqual(focus.tokens("é" * 100), 36)

    def test_an_accent_is_not_counted_as_a_digit_or_another_script(self):
        self.assertLess(focus.tokens("é" * 100), focus.tokens("漢" * 100))
        self.assertLess(focus.tokens("é" * 100), focus.tokens("1" * 100))

    def test_other_scripts_cost_half_as_much_again(self):
        # Chinese, Greek, Cyrillic: the ASCII rate counted them 1.5 times
        # too low (October 9)
        self.assertEqual(focus.tokens("仓" * 100), int(100 * llm.WIDE) + 1)
        self.assertGreater(focus.tokens("仓库" * 50), 1.4 * focus.tokens("e" * 100))
        self.assertEqual(focus.tokens("Склад" * 20), int(100 * llm.WIDE) + 1)

    def test_only_ascii_digits_are_a_token_each(self):
        self.assertEqual(focus.tokens("1234567890"), 11)
        # any other digit is counted with its script
        self.assertEqual(focus.tokens("\u0661" * 10), int(10 * llm.WIDE) + 1)


if __name__ == "__main__":
    unittest.main()
