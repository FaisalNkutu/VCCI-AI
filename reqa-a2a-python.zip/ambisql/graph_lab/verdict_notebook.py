"""What the agent judge knows about one question, and how much of it fits.

There is no tool calling in the model API we use and no history: every
turn of the agent is one JSON reply, and the user message is rebuilt each
turn from a Notebook (the question, the reading, the plan, one line per
step already read, the results not read yet). The Budget makes that
message fit the model's window: results are capped and paged, results
already noted are folded to one line, and when the window is still too
small, less is shown rather than the window overflowing. A result that
could not be shown this turn stays pending and is shown the next one.

The window is counted, not hoped for: the scale of the token estimate
starts at 1.0 for every question and only grows, from the server's own
count, when the estimate fell short.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

REPLY_ROOM = 1024           # tokens kept for an exploring reply
CONCLUDE_ROOM = 2048        # and for a conclusion, which is longer
# the time left as the agent reads it: share of the question's time above
# which each band applies, most time first (Budget.time_band)
TIME_BANDS = ((0.5, "time: ample"),
              (0.25, "time: half gone, conclude within two turns"),
              (-1.0, "time: nearly out, conclude unless one call settles it"))
THINK_ROOM = 4096           # kept for thinking, on the phases that think
MIN_RESULT_TOKENS = 400     # a result shown with less is no use
MIN_THINKING_ROOM = 2000    # below this, a phase does not think: its room would hold nothing
SHRINK_ON_OVERFLOW = 0.6    # the room of a turn asked again after an overflow
MAX_SCALE = 2.0


def tokens(text, scale=1.0):
    """The token estimate the engine uses everywhere (llm.estimate_tokens)."""
    if __package__:
        from . import focus
    else:
        import focus
    return focus.tokens(text or "", scale)


def clip(text, n):
    text = str(text or "")
    return text if len(text) <= n else text[:max(0, n - 1)] + "…"


def short_args(args):
    """A call's arguments as one short line, for the notebook."""
    parts = []
    for k, v in (args or {}).items():
        if v in (None, "", [], {}):
            continue
        if isinstance(v, list):
            v = "[" + ", ".join(clip(x, 40) for x in v[:4]) + (", …" if len(v) > 4 else "") + "]"
        parts.append(f"{k}={clip(v, 80)}")
    return ", ".join(parts)


@dataclass
class CodeResult:
    """A result the code made itself rather than a tool: the tables one key
    away from the first ones, an unknown table name, a call that failed.
    Renders like a verdict_tools.ToolResult."""
    tool: str
    text: str
    digest: str
    ok: bool = True
    data: object = None
    facts: list = field(default_factory=list)
    error: str = ""
    rows: int = 0
    complete: bool = True
    cursor: int | None = None

    def render(self, max_tokens, offset=0):
        body = (self.text if self.ok else f"error: {self.error}")[offset:]
        cap = max(0, int(max_tokens * 2.7))
        truncated = len(body) > cap
        shown = body[:cap]
        return shown, {"rows": self.rows, "tokens": tokens(shown),
                       "truncated": truncated,
                       "more": offset + cap if truncated else None}


@dataclass
class Step:
    n: int
    phase: str
    tool: str
    args: dict
    result: object = None
    note: str = ""
    seconds: float = 0.0
    shown: bool = False        # the model has had it in front of it
    offset: int = 0            # where its rendering starts (for "more")
    size_only: bool = False    # asked with mode "size": only its size was shown
    truncated: bool = False    # what was shown was cut


# the words of a plan item that would carry a rejected conclusion into the
# turn that decides again
_VERDICT_WORDS = re.compile(r"\b(conclude|answer|choice|needs?[_ ]more|not[_ ]covered|no[_ ]data)\b",
                            re.IGNORECASE)


class Notebook:
    """What the agent knows about one question, rebuilt into each prompt."""

    def __init__(self, question):
        self.question = question
        self.context = ""           # who asks and when (context.describe)
        self.earlier = ""           # what was decided before (context.earlier_note)
        self.unknowns: list = []    # what the agent does not know yet, and how to learn it
        self.reading = None
        self.plan = []
        self.steps: list[Step] = []
        self.thought = ""
        self.feedback: list[str] = []
        self.facts: dict = {}

    def record(self, step):
        self.steps.append(step)
        for f in getattr(step.result, "facts", None) or []:
            try:
                self.facts[(f.kind, f.key)] = f
            except AttributeError:
                continue
        return step

    def next_n(self):
        return len(self.steps)

    def apply_reply(self, reply):
        for note in reply.get("notes") or []:
            try:
                n = int(note.get("step"))
            except (TypeError, ValueError, AttributeError):
                continue
            if 0 <= n < len(self.steps):
                self.steps[n].note = clip(note.get("summary"), 300)
        if isinstance(reply.get("plan"), list) and reply["plan"]:
            self.plan = [p for p in reply["plan"] if isinstance(p, dict)][:8]
        if isinstance(reply.get("thought_summary"), str):
            self.thought = clip(reply["thought_summary"], 300)
        if isinstance(reply.get("unknowns"), list):
            self.unknowns = [u for u in reply["unknowns"] if isinstance(u, dict)][:4]
        elif "action" in reply:
            # a turn that lists none knows of none: the last list shown again
            # was a stale one (review of 26 October)
            self.unknowns = []
        if isinstance(reply.get("reading"), dict):
            self.reading = reply["reading"]

    def forget_conclusion(self):
        """Before the agent decides again on the verifier's facts: its last
        thought and the plan items that state the rejected conclusion go,
        so it decides from the facts rather than from its draft."""
        self.thought = ""
        self.plan = [p for p in self.plan
                     if not _VERDICT_WORDS.search(str(p.get("do") or ""))]

    def described(self):
        """The tables whose description the agent has read in full."""
        seen = []
        for s in self.steps:
            if s.tool != "describe_tables" or not getattr(s.result, "ok", False):
                continue
            if not s.shown or s.truncated or s.size_only:
                continue
            data = getattr(s.result, "data", None)
            items = data.get("tables", []) if isinstance(data, dict) else (data or [])
            for item in items:
                t = item.get("table") if isinstance(item, dict) else None
                if t and t not in seen:
                    seen.append(t)
        return seen

    def pending(self):
        return [s for s in self.steps if not s.shown]


class Budget:
    """How much of the window each part of a prompt may take.

    room = (window - system - think room if the phase thinks - reply room)
    times 0.9, and less for a turn asked again after an overflow. The
    window is the smaller of what the endpoint asks for and what the
    server says it loaded."""

    def __init__(self, llm, system, settings):
        num_ctx = int(getattr(llm, "num_ctx", 0) or 16384)
        loaded = None
        try:
            loaded = llm.loaded_window()
        except Exception:
            loaded = None
        self.window = min(num_ctx, loaded) if loaded else num_ctx
        self.scale = 1.0
        self.settings = settings
        self._system_raw = tokens(system)
        self._system_text = system or ""

    @property
    def system(self):
        return int(self._system_raw * self.scale)

    def estimate(self, text):
        return tokens(text, self.scale)

    def room(self, thinks, concluding=False, shrink=1.0):
        reply = CONCLUDE_ROOM if concluding else REPLY_ROOM
        return int((self.window - self.system - (THINK_ROOM if thinks else 0) - reply)
                   * 0.9 * shrink)

    def can_think(self, concluding=False):
        """Whether thinking leaves room for anything else."""
        return self.room(True, concluding) >= MIN_THINKING_ROOM

    def num_predict(self, prompt_tokens, thinks):
        cap = 8192 if thinks else 4096
        return max(512, min(cap, self.window - prompt_tokens - self.system - 64))

    def learn(self, model, user, thought):
        """Raise the scale when the server counted more than estimated.

        Only from a reply without thinking (Ollama's count grows with the
        thinking), and only upwards within a question: an over-estimate
        costs room, an under-estimate costs the start of the prompt."""
        if thought:
            return
        counted = getattr(model, "last_prompt_tokens", 0)
        if not isinstance(counted, int) or counted <= 0:
            return
        raw = self._system_raw + tokens(user)
        if raw > 0 and counted > raw * self.scale:
            self.scale = min(MAX_SCALE, counted / raw * 1.05)

    # ---------------------------------------------------------- fitting
    def fit(self, nb, turn, max_turns, seconds_left, thinks, concluding=False, shrink=1.0):
        """(the user message for this turn, the steps it shows), made to fit.

        Reductions in order, until it fits: the old notes folded, less of
        each result, the last thought and the list of tables seen dropped,
        the done part of the plan folded, then fewer results shown in full
        (the others wait for the next turn). Never retired: the question,
        the reading, the verifier's facts, the plan to do, the budget line."""
        room = self.room(thinks, concluding, shrink)
        pending = nb.pending()
        cap = max(MIN_RESULT_TOKENS, int(getattr(self.settings, "result_tokens", 3000) or 3000))
        state = {"merge_old": False, "keep_thought": True, "keep_seen": True,
                 "collapse_plan": False, "cap": cap, "full": len(pending)}
        for _ in range(64):
            text, shown = self._render(nb, pending, turn, max_turns, seconds_left,
                                       concluding, **state)
            if self.estimate(text) <= room:
                return text, shown
            if not self._reduce(state):
                break
        return self._render_minimal(nb, turn, max_turns, seconds_left, concluding), []

    @staticmethod
    def _reduce(state):
        """One more reduction; False when there is none left."""
        if not state["merge_old"]:
            state["merge_old"] = True
            return True
        floor = MIN_RESULT_TOKENS * max(1, state["full"])
        if state["full"] and state["cap"] > floor:
            state["cap"] = max(floor, int(state["cap"] * 0.75))
            return True
        if state["keep_thought"] or state["keep_seen"]:
            state["keep_thought"] = state["keep_seen"] = False
            return True
        if not state["collapse_plan"]:
            state["collapse_plan"] = True
            return True
        if state["full"] > 0:
            state["full"] -= 1
            state["cap"] = MIN_RESULT_TOKENS * max(1, state["full"])
            return True
        return False

    def _render(self, nb, pending, turn, max_turns, seconds_left, concluding,
                merge_old, keep_thought, keep_seen, collapse_plan, cap, full):
        out = self._head(nb)
        read = [s for s in nb.steps if s.shown]
        if read:
            out.append("WHAT YOU FOUND (one line per step, oldest first)")
            lines = [self.line(s) for s in read]
            if merge_old and len(lines) > 4:
                old = read[:-4]
                tables = sorted({t for s in old for t in self._tables_of(s)})
                out.append(f"(earlier: {len(old)} steps"
                           + (f" on {', '.join(tables[:8])}" if tables else "")
                           + ", collapsed)")
                lines = lines[-4:]
            out += lines + [""]
        out += self._plan(nb, keep_thought, collapse_plan)
        shown = []
        if pending:
            out.append("NEW RESULTS (read them; next turn each is reduced to your note)")
            each = max(MIN_RESULT_TOKENS, cap // max(1, full)) if full else 0
            for i, s in enumerate(pending):
                head = f"#{s.n} {s.tool}({short_args(s.args)})" + \
                    ("   [run by the code]" if s.phase == "probing" else "")
                if i >= full:
                    out += [head, f"  {self.digest(s)}   (shown in full next turn)"]
                    continue
                limit = 0 if s.size_only else each
                try:
                    text, size = s.result.render(limit, s.offset)
                except Exception as e:      # a result that cannot render is still a step
                    text, size = f"(could not show this result: {e})", {}
                more = size.get("more")
                s.truncated = bool(size.get("truncated"))
                out.append(head + f"   size: rows {size.get('rows', 0)}, tokens "
                           f"{size.get('tokens', 0)}, truncated "
                           + (f"yes, more: step={s.n} cursor={more}" if more is not None
                              else "no"))
                if s.size_only:
                    out.append("  (size only, as asked: call it again without mode to read it)")
                elif text:
                    out.append(text)
                shown.append(s)
            out.append("")
        seen = nb.described()
        if keep_seen and seen:
            out += ["TABLES SEEN IN FULL: " + ", ".join(seen) +
                    "   (describe again to reread)", ""]
        out += self._tail(nb, turn, max_turns, seconds_left, concluding, cap)
        return "\n".join(out), shown

    def _render_minimal(self, nb, turn, max_turns, seconds_left, concluding):
        out = self._head(nb) + self._plan(nb, False, True)
        out += self._tail(nb, turn, max_turns, seconds_left, concluding, MIN_RESULT_TOKENS)
        return "\n".join(out)

    @staticmethod
    def _head(nb):
        out = ["QUESTION", nb.question, ""]
        if getattr(nb, "context", ""):
            out += ["WHO ASKS AND WHEN", nb.context, ""]
        if getattr(nb, "earlier", ""):
            out += ["EARLIER IN THIS CONVERSATION", nb.earlier, ""]
        if nb.reading:
            r = nb.reading

            def j(key):
                v = r.get(key)
                return ", ".join(str(x) for x in v) if isinstance(v, list) else str(v or "")
            out += ["YOUR READING (as you wrote it)",
                    f"measure: {j('measure')} | entities: {j('entities')} | "
                    f"filters: {j('filters')} | values: {j('values')} | "
                    f"tables: {j('tables')} | period: {j('period')} | "
                    f"comparisons: {j('comparisons')} | time: {j('time')} | "
                    f"relations: {j('time_relations')}", ""]
        return out

    @staticmethod
    def _plan(nb, keep_thought, collapse_plan):
        if not nb.plan:
            return []
        out = ["YOUR PLAN (change it freely)"]
        if collapse_plan:
            done = sum(1 for p in nb.plan if p.get("status") == "done")
            todo = [p for p in nb.plan if p.get("status") == "todo"]
            out.append(f"done: {done} steps")
            out += [f"{i}. [todo] {clip(p.get('do'), 160)}" for i, p in enumerate(todo, 1)]
        else:
            out += [f"{i}. [{p.get('status', 'todo')}] {clip(p.get('do'), 160)}"
                    for i, p in enumerate(nb.plan, 1)]
        if keep_thought and nb.thought:
            out.append(f"Your last thought: {nb.thought}")
        unknowns = getattr(nb, "unknowns", None) or []
        if unknowns:
            out.append("WHAT YOU DO NOT KNOW YET")
            out += [f"- {clip(u.get('what'), 120)} (by {u.get('how') or 'data'})"
                    for u in unknowns]
        return out + [""]

    def time_band(self, seconds_left):
        """The time left, in words that change only at two thresholds.

        The exact seconds made every run's prompt different: at temperature
        0 two runs of one question then diverged from the first turn, and
        32 of 40 Enterprise verdicts only came back the same (19 October).
        The agent needs to know when to hurry, not the second."""
        total = float(getattr(self.settings, "max_seconds", 1200) or 1200)
        share = float(seconds_left) / total if total > 0 else 0.0
        for limit, words in TIME_BANDS:
            if share > limit:
                return words
        return TIME_BANDS[-1][1]

    def _tail(self, nb, turn, max_turns, seconds_left, concluding, cap):
        out = []
        if nb.feedback:
            out.append("VERIFIER (facts found when checking your conclusion; "
                       "decide again from the facts)")
            out += [f"- {f}" for f in nb.feedback] + [""]
        out.append(f"BUDGET: turn {turn} of {max_turns} · {self.time_band(seconds_left)} "
                   f"· next result up to ~{cap} tokens · window {self.window}")
        if concluding:
            out.append("Conclude now. Reply with one JSON object holding your "
                       "conclusion, built only from what you found.")
        else:
            out.append("Reply with one JSON object: notes on the new results first, "
                       "then your plan, then one call or your conclusion.")
        return out

    @staticmethod
    def digest(s):
        r = s.result
        if r is None:
            return "(no result)"
        if not getattr(r, "ok", True):
            return "error: " + clip(getattr(r, "error", ""), 200)
        return clip(getattr(r, "digest", ""), 240)

    def line(self, s):
        line = f"#{s.n} {s.tool}({short_args(s.args)}) -> {self.digest(s)}"
        if s.note:
            line += f" · your note: {s.note}"
        return line

    @staticmethod
    def _tables_of(s):
        out = []
        for k in ("table", "a", "b"):
            if isinstance(s.args.get(k), str):
                out.append(s.args[k])
        for k in ("names", "tables"):
            if isinstance(s.args.get(k), list):
                out += [str(x) for x in s.args[k]]
        return out
