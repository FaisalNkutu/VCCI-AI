"""scripts/make_enterprise_db.py: the Enterprise bench, built in memory.

No database is touched: the generator's World is run as the script runs
it and its rows are checked. The 156 original tables must keep the rows
they had at e2b66c5, which the 40 reference questions were verified on;
the tables added since must be complete, consistent, and every column
that points into several tables (POLYMORPHIC) must resolve."""

import os

os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

import contextlib
import datetime as dt
import hashlib
import importlib.util
import io
import pathlib
import subprocess
import sys
import tempfile
import unittest
from collections import defaultdict
from unittest import mock

HERE = pathlib.Path(__file__).resolve().parent
REPO = HERE.parent.parent
SCRIPT = REPO / "scripts" / "make_enterprise_db.py"

# the original bench, as generated at e2b66c5: 156 tables, 74,065 rows
REFERENCE_COMMIT = "e2b66c5"
ORIGINAL_TABLES = 156
ORIGINAL_ROWS = 74065
ORIGINAL_DIGEST = "7a022c7d1da5a7a4518091608ee3213d68c39b0987e247977c91933352cca620"


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


bench = load(SCRIPT, "make_enterprise_db_under_test")


def digest(module, rows, names):
    """One hash of the rows of these tables, column by column as inserted."""
    h = hashlib.sha256()
    for name in names:
        cols = [c.name for c in module.TABLES[name].cols]
        h.update(name.encode("utf-8") + b"\n")
        for row in rows[name]:
            h.update(repr(tuple(row.get(c) for c in cols)).encode("utf-8") + b"\n")
    return h.hexdigest()


class Bench(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows = bench.World(bench.SEED).build()
        cls.original = list(bench.TABLES)[:ORIGINAL_TABLES]
        cls.keys = {name: {row[t.pk[0]] for row in cls.rows[name]}
                    for name, t in bench.TABLES.items() if len(t.pk) == 1}

    # --- the original tables do not move ------------------------------
    def test_the_original_tables_come_first(self):
        self.assertEqual(self.original[0], "currencies")
        self.assertEqual(self.original[-1], "customer_surveys")

    def test_the_original_tables_keep_their_rows(self):
        self.assertEqual(sum(len(self.rows[n]) for n in self.original), ORIGINAL_ROWS)
        self.assertEqual(digest(bench, self.rows, self.original), ORIGINAL_DIGEST)

    def test_the_original_tables_match_the_generator_of_e2b66c5(self):
        """Table by table, against the old generator itself when git has it."""
        try:
            old = subprocess.run(["git", "-C", str(REPO), "show", f"{REFERENCE_COMMIT}:scripts/make_enterprise_db.py"],
                                 capture_output=True, timeout=60)
        except (OSError, subprocess.SubprocessError):
            self.skipTest("git is not available")
        if old.returncode:
            self.skipTest(f"{REFERENCE_COMMIT} is not in this clone")
        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "make_enterprise_db_e2b66c5.py"
            path.write_bytes(old.stdout)
            before = load(path, "make_enterprise_db_e2b66c5")
        then = before.World(before.SEED).build()
        self.assertEqual(list(before.TABLES), self.original)
        moved = [n for n in self.original if digest(before, then, [n]) != digest(bench, self.rows, [n])]
        self.assertEqual(moved, [])
        self.assertEqual(digest(before, then, list(before.TABLES)), ORIGINAL_DIGEST)

    # --- the whole bench is complete and consistent --------------------
    def test_the_bench_has_more_than_250_tables(self):
        self.assertGreaterEqual(len(bench.TABLES), 250)

    def test_no_table_is_empty(self):
        self.assertEqual([n for n in bench.TABLES if not self.rows.get(n)], [])

    def test_tables_are_created_after_what_they_reference(self):
        order = bench.creation_order()
        self.assertEqual(sorted(order), sorted(bench.TABLES))
        seen = set()
        for name in order:
            for c in bench.TABLES[name].cols:
                if c.ref and c.ref != name:
                    self.assertIn(c.ref, seen, f"{name}.{c.name}")
            seen.add(name)

    def test_primary_keys_are_unique(self):
        for name, t in bench.TABLES.items():
            values = [tuple(row.get(k) for k in t.pk) for row in self.rows[name]]
            self.assertEqual(len(values), len(set(values)), name)

    def test_every_foreign_key_finds_its_row(self):
        """And a row pointing into its own table comes after its parent, as
        InnoDB checks each row when it is inserted."""
        for name, t in bench.TABLES.items():
            for c in t.cols:
                if not c.ref:
                    continue
                if not c.null:
                    self.assertFalse(any(row.get(c.name) is None for row in self.rows[name]), f"{name}.{c.name} is NULL")
                if c.ref == name:
                    pk, done = t.pk[0], set()
                    for row in self.rows[name]:
                        if row.get(c.name) is not None:
                            self.assertIn(row[c.name], done, f"{name}.{c.name} points forward")
                        done.add(row[pk])
                    continue
                missing = {row[c.name] for row in self.rows[name] if row.get(c.name) is not None} - self.keys[c.ref]
                self.assertEqual(missing, set(), f"{name}.{c.name} -> {c.ref}")

    def test_every_value_fits_its_column(self):
        """MariaDB in strict mode refuses a text longer than its column or a
        number out of its type's range: the build would stop half way."""
        import re
        wrong = []
        for name, t in bench.TABLES.items():
            for c in t.cols:
                sqltype = (bench.key_type(c.ref) if c.ref else c.sqltype).upper()
                text = re.match(r"(?:VAR)?CHAR\((\d+)\)", sqltype)
                dec = re.match(r"DECIMAL\((\d+),(\d+)\)", sqltype)
                limit = {"TINYINT": 127, "SMALLINT": 32767}.get(sqltype.split()[0].split("(")[0])
                for row in self.rows[name]:
                    v = row.get(c.name)
                    if v is None:
                        continue
                    if text and len(str(v)) > int(text.group(1)):
                        wrong.append(f"{name}.{c.name} {v!r} longer than {text.group(1)}")
                    elif dec and abs(float(v)) >= 10 ** (int(dec.group(1)) - int(dec.group(2))):
                        wrong.append(f"{name}.{c.name} {v!r} too large for {sqltype}")
                    elif limit and not sqltype.startswith("TINYINT(1)") and abs(int(v)) > limit:
                        wrong.append(f"{name}.{c.name} {v!r} out of {sqltype}")
                    else:
                        continue
                    break
        self.assertEqual(wrong, [])

    def test_at_s_keeps_the_second(self):
        self.assertEqual(bench.World.at_s(dt.date(2026, 9, 30), 23, 59, 58), dt.datetime(2026, 9, 30, 23, 59, 58))

    # --- columns that point into several tables -------------------------
    def test_polymorphic_links_name_real_columns(self):
        self.assertIn(("stock_movements", "reference_id"), bench.POLYMORPHIC)
        self.assertIn(("lots", "supplier_id"), bench.POLYMORPHIC)
        for (table, column), link in bench.POLYMORPHIC.items():
            cols = {c.name: c for c in bench.TABLES[table].cols}
            self.assertIn(column, cols)
            self.assertIsNone(cols[column].ref, f"{table}.{column} is a declared foreign key")
            if link["type_column"]:
                self.assertIn(link["type_column"], cols)
            else:
                self.assertEqual(list(link["targets"]), [None])
            for code, (target, key) in link["targets"].items():
                self.assertEqual(bench.TABLES[target].pk, [key], f"{table}.{column} {code}")
            for ex in link.get("exceptions", []):
                self.assertIn(ex["column"], cols)
                self.assertEqual(bench.TABLES[ex["target"][0]].pk, [ex["target"][1]])

    def test_polymorphic_keys_resolve(self):
        for (table, column), link in bench.POLYMORPHIC.items():
            typed, found = link["type_column"], defaultdict(int)
            for row in self.rows[table]:
                value = row.get(column)
                if value is None:
                    continue
                target = next((ex["target"] for ex in link.get("exceptions", []) if row.get(ex["column"]) == ex["value"]), None)
                if target is None:
                    code = row.get(typed) if typed else None
                    self.assertIn(code, link["targets"], f"{table}.{typed} = {code!r} has no target")
                    target = link["targets"][code]
                self.assertIn(value, self.keys[target[0]], f"{table}.{column} = {value} not in {target[0]}")
                found[target[0]] += 1
            self.assertTrue(found, f"{table}.{column} never points anywhere")

    def test_the_maintenance_issues_are_the_documented_exception(self):
        mnt = [m for m in self.rows["stock_movements"] if m["movement_type_code"] == "MNT_ISS"]
        self.assertTrue(mnt)
        self.assertEqual({m["reference_type"] for m in mnt}, {"WORK_ORDER"})
        comment = next(c.comment for c in bench.TABLES["stock_movements"].cols if c.name == "reference_id")
        self.assertIn("MNT_ISS", comment)
        self.assertIn("MNT_ISS", bench.POLYMORPHIC[("stock_movements", "reference_id")]["note"])

    # --- time --------------------------------------------------------------
    def test_status_histories_chain_up_to_the_current_status(self):
        """valid_to is the next valid_from; the open row is the status the
        main table holds today."""
        for table, key, main in [("ticket_status_history", "ticket_id", "support_tickets"),
                                 ("work_order_status_history", "work_order_id", "work_orders"),
                                 ("shipment_status_history", "shipment_id", "shipments"),
                                 ("asset_status_history", "asset_id", "assets")]:
            chains = defaultdict(list)
            for row in self.rows[table]:
                chains[row[key]].append(row)
            today = {row[key]: row["status_code"] for row in self.rows[main]}
            for oid, chain in chains.items():
                for a, b in zip(chain, chain[1:]):
                    self.assertEqual(a["valid_to"], b["valid_from"], f"{table} {oid}")
                    self.assertLessEqual(a["valid_from"], b["valid_from"], f"{table} {oid}")
                self.assertIsNone(chain[-1]["valid_to"], f"{table} {oid}")
                self.assertEqual(chain[-1]["status_code"], today[oid], f"{table} {oid}")

    def test_validity_histories_do_not_overlap(self):
        for table, key in [("customer_tier_history", "customer_id"), ("employee_assignment_history", "employee_id"),
                           ("lead_score_history", "lead_id")]:
            if table not in bench.TABLES:
                continue
            chains = defaultdict(list)
            for row in self.rows[table]:
                chains[row[key]].append(row)
            for oid, chain in chains.items():
                for a, b in zip(chain, chain[1:]):
                    self.assertEqual(a["valid_to"], b["valid_from"], f"{table} {oid}")
                    self.assertLess(a["valid_from"], b["valid_from"], f"{table} {oid}")

    def test_partial_histories_start_where_their_comment_says(self):
        self.assertGreaterEqual(min(r["valid_from"] for r in self.rows["ticket_status_history"]), dt.datetime(2025, 1, 1))
        self.assertGreaterEqual(min(r["valid_from"] for r in self.rows["shipment_status_history"]), dt.datetime(2025, 3, 1))
        first = defaultdict(lambda: dt.datetime.max)
        for e in self.rows["events"]:
            first[e["object_type"]] = min(first[e["object_type"]], e["occurred_at"])
        self.assertGreaterEqual(first["ABSENCE"], dt.datetime(2026, 3, 1))
        self.assertGreaterEqual(first["PURCHASE_REQ"], dt.datetime(2024, 1, 1))

    def test_the_journal_has_one_event_per_object_and_second(self):
        keys = [(e["object_type"], e["object_id"], e["occurred_at"]) for e in self.rows["events"]]
        self.assertEqual(len(keys), len(set(keys)))
        times = [e["occurred_at"] for e in self.rows["events"]]
        self.assertEqual(times, sorted(times))

    def test_generated_activity_stops_at_the_reference_date(self):
        end = dt.datetime(2026, 10, 1)
        for table, column in [("events", "occurred_at"), ("approval_events", "occurred_at"), ("expense_approvals", "decided_at"),
                              ("project_time_entries", "submitted_at"), ("attachments", "uploaded_at"), ("comments", "created_at"),
                              ("audit_log", "changed_at"), ("badge_events", "occurred_at"), ("car_trips", "ended_at"),
                              ("email_sends", "sent_at"), ("customs_declarations", "lodged_at")]:
            if table in bench.TABLES:
                self.assertLess(max(r[column] for r in self.rows[table]), end, f"{table}.{column}")

    # --- the command line ------------------------------------------------
    def test_the_live_database_needs_i_know(self):
        for argv in (["make_enterprise_db.py"], ["make_enterprise_db.py", "--database", bench.DATABASE]):
            with mock.patch.object(sys, "argv", argv), mock.patch.object(bench, "World") as world, \
                    mock.patch.object(bench, "connect") as connect, contextlib.redirect_stdout(io.StringIO()):
                with self.assertRaises(SystemExit) as stop:
                    bench.main()
            self.assertIn("--i-know", str(stop.exception))
            world.assert_not_called()
            connect.assert_not_called()

    def test_a_database_name_is_checked(self):
        for name in ("x`; DROP", "datagora_lib", "datagora_generic", "datagora_points"):
            with mock.patch.object(sys, "argv", ["make_enterprise_db.py", "--database", name, "--i-know"]), \
                    mock.patch.object(bench, "World") as world, mock.patch.object(bench, "connect") as connect:
                with self.assertRaises(SystemExit):
                    bench.main()
            world.assert_not_called()
            connect.assert_not_called()

    def test_the_env_file_of_another_checkout_is_read(self):
        with tempfile.TemporaryDirectory() as tmp:
            env = pathlib.Path(tmp) / ".env"
            env.write_text("DATAGORA_BENCH_TEST_KEY=from-file\n", encoding="utf-8")
            with mock.patch.dict(os.environ, {"DATAGORA_ENV_FILE": str(env)}):
                os.environ.pop("DATAGORA_BENCH_TEST_KEY", None)
                bench.load_env()
                self.assertEqual(os.environ.get("DATAGORA_BENCH_TEST_KEY"), "from-file")
            os.environ.pop("DATAGORA_BENCH_TEST_KEY", None)


kb_script = load(REPO / "scripts" / "make_enterprise_kb.py", "make_enterprise_kb_under_test")
EXAMPLE_KB = HERE / "examples" / "kb_enterprise.json"


class KnowledgeBase(unittest.TestCase):
    """scripts/make_enterprise_kb.py, without a database: the relationships
    it writes for POLYMORPHIC, and the dictionary it produced in examples/."""

    def fresh(self):
        return {t: {"columns": {}, "relationships": []} for t in bench.TABLES}

    def test_the_file_written_is_always_named(self):
        # review of 26 October: the default overwrote the application's KB
        with mock.patch.object(sys, "argv", ["make_enterprise_kb.py"]), \
                mock.patch.object(kb_script, "connect") as connect, \
                contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            kb_script.main()
        connect.assert_not_called()

    def test_every_target_becomes_a_relationship_with_its_condition(self):
        kb = self.fresh()
        written = kb_script.polymorphic(kb, bench.POLYMORPHIC)
        expected = sum(len(link["targets"]) + len(link.get("exceptions", [])) for link in bench.POLYMORPHIC.values())
        self.assertEqual(written, expected)
        for (table, column), link in bench.POLYMORPHIC.items():
            if not link["type_column"]:
                continue
            rels = {(r["related_table"], r["when"]["column"], r["when"]["value"]): r for r in kb[table]["relationships"]}
            for code, (target, key) in link["targets"].items():
                rel = rels[(target, link["type_column"], code)]
                self.assertEqual(rel, {**{"role": "child_of", "name": f"{table}_{target}", "type": "Polymorphic",
                                          "related_table": target, "cardinality": "Zero or One",
                                          "join_on": f"{table}.{column} = {target}.{key}", "own_column": column,
                                          "related_column": key, "when": {"column": link["type_column"], "value": code}},
                                       **({"note": link["note"]} if link.get("note") else {})})
        mnt = [r for r in kb["stock_movements"]["relationships"] if r["related_table"] == "maintenance_orders"]
        self.assertEqual([r["when"] for r in mnt], [{"column": "movement_type_code", "value": "MNT_ISS"}])

    def test_the_lot_supplier_is_an_ordinary_undeclared_link(self):
        kb = self.fresh()
        kb_script.polymorphic(kb, bench.POLYMORPHIC)
        child = [r for r in kb["lots"]["relationships"] if r["own_column"] == "supplier_id"]
        parent = [r for r in kb["suppliers"]["relationships"] if r["related_table"] == "lots"]
        self.assertEqual([(r["role"], r["type"], r["join_on"]) for r in child],
                         [("child_of", "Non-Identifying", "lots.supplier_id = suppliers.supplier_id")])
        self.assertEqual([r["role"] for r in parent], ["parent_of"])
        self.assertNotIn("when", child[0])

    def test_each_event_type_says_which_columns_it_fills(self):
        kb = {"events": {"columns": {"event_type": {"description": "Type of event."}}}}
        kb_script.event_types(kb, [("FILED", "Filed", "actor_employee_id, object_type, object_id, to_status, amount", "Filed by the author.")])
        spec = kb["events"]["columns"]["event_type"]
        self.assertEqual(spec["allowed_values"]["FILED"]["label"], "filed")
        self.assertIn("Meaningful columns: actor_employee_id, object_type, object_id, to_status, amount.",
                      spec["allowed_values"]["FILED"]["description"])
        self.assertIn("FILED (actor, to_status, amount)", spec["description"])

    def test_the_example_dictionary_has_every_conditional_link_and_loads(self):
        import json
        import dictionary
        kb = json.loads(EXAMPLE_KB.read_text(encoding="utf-8"))
        self.assertEqual(sorted(kb), sorted(bench.TABLES))
        for (table, column), link in bench.POLYMORPHIC.items():
            if not link["type_column"]:
                continue
            found = {(r["related_table"], r["when"]["value"]) for r in kb[table]["relationships"]
                     if r.get("type") == "Polymorphic" and r["own_column"] == column}
            self.assertEqual(found, {(t, code) for code, (t, k) in link["targets"].items()} |
                             {(ex["target"][0], ex["value"]) for ex in link.get("exceptions", [])})
        self.assertTrue(kb["events"]["columns"]["event_type"]["allowed_values"]["REFILED"]["description"])
        parsed = dictionary.load(str(EXAMPLE_KB))
        self.assertEqual(len(parsed["tables"]), len(bench.TABLES))
        for (table, column), link in bench.POLYMORPHIC.items():
            targets = {t for t, k in link["targets"].values()} | {ex["target"][0] for ex in link.get("exceptions", [])}
            if link["type_column"]:
                # every target survives, with its condition, apart from the keys
                kept = {t for t, _c, _about in parsed["polymorphic"].get((table, column), [])}
                self.assertEqual(kept, targets, f"{table}.{column}")
                self.assertNotIn((table, column), parsed["links"])
            else:
                # a plain undeclared link (lots.supplier_id) is an ordinary key
                self.assertIn(parsed["links"][(table, column)][0], targets)


if __name__ == "__main__":
    unittest.main()
