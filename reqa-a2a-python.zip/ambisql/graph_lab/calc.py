"""A small, safe calculator for the agent judge: one Python expression on
numbers and dates, nothing else.

The agent reasons in steps, and some steps are a computation: which dates
"last year" or "the last 90 days" cover on the day of the question, how
many days lie between two dates, a share or a difference. A model doing
date arithmetic in its head gets it wrong often enough; so it writes the
expression, and the code works it out.

    evaluate("add_months(today(), -3)", today=date(2026, 10, 23))  ->  date(2026, 7, 23)
    evaluate("(date(2025, 12, 31) - date(2025, 1, 1)).days + 1")    ->  365

Only what is listed here can be used: no import, no name that is not a
function below, no attribute but those of a date, a datetime or a
duration, no loop, no lambda, no comprehension, no string longer than
MAX_STRING, no number past MAX_NUMBER. The expression is parsed and
checked, then rewritten so that every power, product, remainder, rounding
and attribute goes through a guard that refuses what would cost: a power
or a product whose result passes MAX_NUMBER, the repetition or the %
formatting of a string or a list, a rounding to more than MAX_DIGITS
places, a method of a string (reviewed on 23 October: a tower of powers
ran for minutes, and str(0) * 10 ** 8 built 100 MB). It runs with no
builtins. Anything else is refused with the reason.
"""

import ast
import datetime
import math

MAX_CHARS = 300
MAX_NUMBER = 10 ** 12
MAX_ITEMS = 20
MAX_STRING = 40
MAX_DIGITS = 12
MAX_SHOWN = 200
_TIMELIKE = (datetime.date, datetime.datetime, datetime.timedelta)


class Refused(ValueError):
    """An expression the calculator will not run, or that failed."""


def _day(d):
    return d.date() if isinstance(d, datetime.datetime) else d


def add_months(d, n):
    """The same day n months later (earlier when n < 0), on the month's
    last day when it has fewer days."""
    d0 = _day(d)
    months = d0.year * 12 + d0.month - 1 + int(n)
    year, month = divmod(months, 12)
    month += 1
    nxt = datetime.date(year + (month == 12), month % 12 + 1, 1)
    last = (nxt - datetime.timedelta(days=1)).day
    return d0.replace(year=year, month=month, day=min(d0.day, last))


def days_between(a, b):
    """Whole days from a to b."""
    return (_day(b) - _day(a)).days


def month_start(d):
    return _day(d).replace(day=1)


def quarter_start(d):
    d0 = _day(d)
    return d0.replace(month=3 * ((d0.month - 1) // 3) + 1, day=1)


def year_start(d):
    return _day(d).replace(month=1, day=1)


def _number(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool)


def _bounded(value):
    if _number(value) and math.isfinite(value) and abs(value) > MAX_NUMBER:
        raise Refused("a result past %d" % MAX_NUMBER)
    return value


def _pow(a, b):
    if not (_number(a) and _number(b)):
        raise Refused("a power of numbers only")
    if abs(a) > 1 and b > 0 and b * math.log10(abs(a)) > math.log10(MAX_NUMBER):
        raise Refused("a power past %d" % MAX_NUMBER)
    if abs(b) > MAX_DIGITS * 4:
        raise Refused("an exponent past %d" % (MAX_DIGITS * 4))
    return _bounded(a ** b)


def _mul(a, b):
    if not (_number(a) and _number(b)):
        raise Refused("no repetition of a string or a list: numbers only")
    return _bounded(a * b)


def _mod(a, b):
    if not (_number(a) and _number(b)):
        raise Refused("no % formatting: numbers only")
    return a % b


def _round(x, digits=None):
    if digits is not None and (not isinstance(digits, int) or abs(digits) > MAX_DIGITS):
        raise Refused("round to at most %d places" % MAX_DIGITS)
    return round(x) if digits is None else round(x, digits)


def _attr(obj, name):
    if not isinstance(obj, _TIMELIKE):
        raise Refused(f"{name} is only for a date, a datetime or a duration")
    return getattr(obj, name)


FUNCTIONS = {
    "date": datetime.date, "datetime": datetime.datetime, "timedelta": datetime.timedelta,
    "min": min, "max": max, "round": _round, "abs": abs, "sum": sum, "len": len,
    "int": int, "float": float, "str": str,
    "add_months": add_months, "days_between": days_between,
    "month_start": month_start, "quarter_start": quarter_start, "year_start": year_start,
}
ATTRIBUTES = {"year", "month", "day", "hour", "minute", "second", "days", "seconds",
              "weekday", "isoweekday", "isoformat", "date", "total_seconds", "replace"}
_NODES = (ast.Expression, ast.Constant, ast.Name, ast.Load, ast.BinOp, ast.UnaryOp,
          ast.BoolOp, ast.Compare, ast.Call, ast.Attribute, ast.keyword, ast.Tuple,
          ast.List, ast.IfExp, ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv,
          ast.Mod, ast.Pow, ast.USub, ast.UAdd, ast.Not, ast.And, ast.Or, ast.Eq,
          ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE)
_GUARDED = {ast.Pow: "_pow", ast.Mult: "_mul", ast.Mod: "_mod"}


def _check(tree):
    for node in ast.walk(tree):
        if not isinstance(node, _NODES):
            raise Refused(f"{type(node).__name__} is not allowed: one expression on "
                          "numbers and dates, with the listed functions")
        if isinstance(node, ast.Name) and node.id not in FUNCTIONS \
                and node.id not in ("today", "now"):
            raise Refused(f"unknown name {node.id}; the functions are today, now, "
                          + ", ".join(sorted(FUNCTIONS)))
        if isinstance(node, ast.Attribute) and (node.attr.startswith("_")
                                                or node.attr not in ATTRIBUTES):
            raise Refused(f"attribute {node.attr} is not allowed")
        if isinstance(node, ast.Constant):
            v = node.value
            if isinstance(v, str) and len(v) > MAX_STRING:
                raise Refused("a string longer than %d characters" % MAX_STRING)
            if _number(v) and abs(v) > MAX_NUMBER:
                raise Refused("a number past %d" % MAX_NUMBER)
            if not isinstance(v, (int, float, str, bool, type(None))):
                raise Refused("only numbers, short strings, True, False and None")
        if isinstance(node, (ast.List, ast.Tuple)) and len(node.elts) > MAX_ITEMS:
            raise Refused("more than %d items" % MAX_ITEMS)


class _Guard(ast.NodeTransformer):
    """Every power, product and remainder, and every attribute, through
    its guard: what a value is only shows when it runs."""

    def visit_BinOp(self, node):
        self.generic_visit(node)
        name = _GUARDED.get(type(node.op))
        if name is None:
            return node
        return ast.copy_location(ast.Call(func=ast.Name(id=name, ctx=ast.Load()),
                                          args=[node.left, node.right], keywords=[]), node)

    def visit_Attribute(self, node):
        self.generic_visit(node)
        return ast.copy_location(ast.Call(func=ast.Name(id="_attr", ctx=ast.Load()),
                                          args=[node.value, ast.Constant(node.attr)],
                                          keywords=[]), node)


def evaluate(expression, today=None, now=None):
    """The value of one expression, or Refused with the reason. today()
    and now() are the question's date and time, not the server's."""
    text = str(expression or "").strip()
    if not text:
        raise Refused("no expression")
    if len(text) > MAX_CHARS:
        raise Refused("an expression longer than %d characters" % MAX_CHARS)
    try:
        tree = ast.parse(text, mode="eval")
    except SyntaxError as e:
        raise Refused(f"not an expression: {e.msg}") from None
    _check(tree)
    tree = ast.fix_missing_locations(_Guard().visit(tree))
    day = _day(now) if now and not today else (_day(today) if today else datetime.date.today())
    moment = now or datetime.datetime.combine(day, datetime.datetime.now().time())
    env = dict(FUNCTIONS, today=lambda: day, now=lambda: moment,
               _pow=_pow, _mul=_mul, _mod=_mod, _attr=_attr)
    try:
        value = eval(compile(tree, "<compute>", "eval"), {"__builtins__": {}}, env)
    except Refused:
        raise
    except Exception as e:      # a bad date, a division by zero, an overflow
        raise Refused(f"{type(e).__name__}: {e}") from None
    return _bounded(value)


def show(value):
    """The value as the agent reads it: dates in ISO form, a duration in
    days, a float to six places."""
    if isinstance(value, (datetime.date, datetime.datetime)):
        text = value.isoformat()
    elif isinstance(value, datetime.timedelta):
        text = f"{value.days} days" + (f" {value.seconds} s" if value.seconds else "")
    elif isinstance(value, float):
        text = f"{round(value, 6):g}"
    elif isinstance(value, (list, tuple)):
        text = "[" + ", ".join(show(v) for v in value) + "]"
    else:
        text = str(value)
    return text if len(text) <= MAX_SHOWN else text[:MAX_SHOWN - 3] + "..."
