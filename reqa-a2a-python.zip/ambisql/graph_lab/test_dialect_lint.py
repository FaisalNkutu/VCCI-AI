"""The dialect check: a statement that means two things is refused, one
that only parses differently is not, and a function MariaDB lacks is a
warning, said and never a rejection, in the gates and in the run's steps.
No database."""

import unittest
import unittest.mock
from types import SimpleNamespace

from dialect_lint import lint, repair_message


def severities(sql):
    return [v[0] for v in lint(sql)[0]]


class DialectTests(unittest.TestCase):

    def test_a_function_one_parser_does_not_know_is_no_divergence(self):
        # E36, 23 October: Ask failed three times on YEAR(...), the two
        # readings written back the same character for character
        self.assertEqual(severities(
            "SELECT SUM(net_amount) FROM invoices WHERE YEAR(invoice_date) = 2025"), ["OK"])
        self.assertEqual(severities(
            "SELECT MONTH(d), DAY(d) FROM t WHERE YEAR(d) = 2024"), ["OK"])

    def test_concatenation_read_as_or_is_still_refused(self):
        self.assertIn("REJECT", severities("SELECT c.name || ' x' FROM c"))

    def test_mariadb_s_own_date_arithmetic_means_one_thing(self):
        # the filter behind every "in the last thirty days" question
        self.assertEqual(severities("SELECT COUNT(*) FROM orders WHERE order_date >= "
                                    "DATE_SUB(NOW(), INTERVAL 30 DAY)"), ["OK"])
        self.assertEqual(severities("SELECT TIMESTAMPDIFF(DAY, a, b) FROM t"), ["OK"])

    def test_a_function_mariadb_lacks_is_a_warning_and_no_repair(self):
        # review of 26 October (Ask 20): no case had a warning
        self.assertEqual(severities("SELECT julianday('now') - julianday(created_at) FROM t"),
                         ["WARN"])
        self.assertIn("julianday() does not exist on MariaDB",
                      lint("SELECT julianday(created_at) FROM t")[0][0][1])
        self.assertIsNone(repair_message("SELECT julianday(created_at) FROM t"))

    def test_the_date_of_now_is_refused_as_a_silent_null(self):
        self.assertEqual(severities("SELECT * FROM inventory WHERE counted_at > date('now')"),
                         ["REJECT"])
        self.assertEqual(severities("SELECT * FROM t WHERE d > datetime('now')"), ["REJECT"])
        # beside a warning, the rejection is what the generator is told
        sql = "WITH changes(id, n) AS (SELECT 1, 2) SELECT * FROM changes WHERE n > date('now')"
        self.assertEqual(severities(sql), ["REJECT", "WARN"])
        said = repair_message(sql)
        self.assertIn("date('now') returns NULL", said)
        self.assertNotIn("changes() does not exist", said)

    def test_the_repair_message_carries_the_mariadb_form(self):
        said = repair_message("SELECT first_name || ' ' || last_name FROM t")
        self.assertIn("rejected before execution", said)
        self.assertIn("Equivalent MariaDB form: SELECT CONCAT(first_name, ' ', last_name) FROM t",
                      said)

    def test_a_statement_that_cannot_be_read_is_a_warning(self):
        with unittest.mock.patch("dialect_lint.dialect_divergence",
                                 side_effect=ValueError("unexpected token")):
            verdicts, repaired = lint("SELECT 1")
        self.assertEqual(([v for v, _ in verdicts], repaired), (["WARN"], None))
        self.assertIn("not parseable by sqlglot: ValueError: unexpected token", verdicts[0][1])



class GatesTests(unittest.TestCase):
    """The gates of a generated statement (schema_graph.judge_sql and
    Pipeline.check): review of 26 October."""

    COLUMNS = {"risks": [("risk_id", "int"), ("level", "tinyint")],
               "sites": [("site_id", "int"), ("geo", "point"), ("code", "varchar(10)")]}

    def test_a_warning_never_stops_the_gates_nor_rejects(self):
        from types import SimpleNamespace

        import pipeline
        from schema_graph import judge_sql
        sql = "WITH changes(id, n) AS (SELECT 1, 2) SELECT * FROM changes"
        findings, ran = judge_sql(sql, columns=self.COLUMNS, stop_early=True)
        self.assertEqual([v for v, _ in findings], ["WARN"])
        self.assertIn("literals", ran)              # the gates went on
        p = pipeline.Pipeline.__new__(pipeline.Pipeline)
        p.clarifier = SimpleNamespace(columns=self.COLUMNS)
        with unittest.mock.patch.object(pipeline.Pipeline, "has_graph", False):
            correction, _ran = p.check(sql, None)
        self.assertIsNone(correction)

    def pipe(self, sql=None):
        """A pipeline whose model calls, anchors and execution are stubbed:
        its check is the real one, over a plan with one table."""
        import pipeline

        class Con:
            description = [("id",), ("table",), ("type",), ("ref",), ("rows",), ("Extra",)]

            def cursor(self):
                return self

            def __enter__(self):
                return self

            def __exit__(self, *exc):
                return False

            def execute(self, sql):
                pass

            def fetchall(self):
                return [(1, "risks", "ALL", None, 1, "")]

            def close(self):
                pass

        p = pipeline.Pipeline.__new__(pipeline.Pipeline)
        p.judge, p.reformulate = "single", False
        p.clarifier = SimpleNamespace(columns=self.COLUMNS, last_shown=[],
                                      clarify=lambda q: SimpleNamespace(action="ANSWER",
                                                                        reason="clear"))
        p.profile = SimpleNamespace(name="Shop", connect_mysql=Con)
        p._graph, p._driver = pipeline._EmptyGraph(), None      # no Neo4j: joins not checked
        p.sql_llm = SimpleNamespace(model="sql", chat=lambda system, user: sql)
        p.reasoner = SimpleNamespace(model="reasoner")
        p._sql_prompt = p._answer_prompt = SimpleNamespace(text="SYSTEM", version=1, source="t")
        p.anchors = lambda q: (["risks"], "model")
        p.examples_for = lambda q: []
        p.execute = lambda sql, con: (["id", "n"], [[1, 2]], 1)
        p.say = lambda q, columns, rows, total=None: "One."
        p._remember = lambda *a: None
        return p

    def test_a_warning_beside_a_rejection_is_never_the_correction(self):
        # review of 26 October (Ask 20): no test of a warning in check()
        p = self.pipe()
        correction, ran = p.check("SELECT julianday(x) FROM risks r WHERE r.level = 'high'", None)
        self.assertTrue(correction.startswith("This filter cannot match anything"), correction)
        self.assertNotIn("julianday", correction)
        self.assertEqual(len(p._here().warnings), 1)
        self.assertIn("julianday() does not exist on MariaDB", p._here().warnings[0])
        # the next statement is checked clean, the warning not carried over
        self.assertEqual(p.check("SELECT risk_id FROM risks", None), (None, ran))
        self.assertEqual(p._here().warnings, [])

    def test_a_warning_is_said_in_the_checks_step_and_the_question_answered(self):
        import pipeline
        p = self.pipe("WITH changes(id, n) AS (SELECT 1, 2) SELECT * FROM changes")
        run = pipeline.Run(question="q?", profile="Shop")
        p._ask(run, "q?", None, trace=None)
        checks = [s for s in run.steps if s.name.startswith("checks")]
        self.assertEqual(len(checks), 1)                # one attempt, never rejected
        self.assertTrue(checks[0].ok)
        self.assertIn("dialect, literals, EXPLAIN pass", checks[0].detail)
        self.assertIn("(warning: changes() does not exist on MariaDB", checks[0].detail)
        self.assertEqual(run.answer, "One.")

    def test_the_literal_audit_reads_real_columns_by_their_own_type(self):
        from schema_graph import audit_literals
        # an alias the query gives itself, and a spatial POINT, are no number
        self.assertEqual(audit_literals(
            "SELECT CASE WHEN x > 1 THEN 'high' END AS level FROM t WHERE level = 'high'",
            self.COLUMNS), [])
        self.assertEqual(audit_literals("SELECT * FROM sites WHERE geo = 'abc'", self.COLUMNS), [])
        self.assertEqual(audit_literals(
            "WITH r AS (SELECT 'high' AS level) SELECT * FROM r WHERE r.level = 'high'",
            self.COLUMNS), [])
        # a real tinyint compared to a word still is
        self.assertEqual(len(audit_literals("SELECT * FROM risks r WHERE r.level = 'high'",
                                            self.COLUMNS)), 1)


    def test_review_of_the_fixes_an_alias_never_hides_a_real_column(self):
        # WHERE reads the table's column: s.label AS status, then WHERE
        # status = 'shipped' on a tinyint orders.status is the wrong filter
        from schema_graph import audit_literals
        columns = {"orders": [("id", "int"), ("status", "tinyint")],
                   "order_status": [("id", "int"), ("label", "varchar")]}
        self.assertEqual(len(audit_literals(
            "SELECT o.id, s.label AS status FROM orders o JOIN order_status s ON s.id = o.status "
            "WHERE status = 'shipped'", columns)), 1)
        # a name the query alone has is still its own
        self.assertEqual(audit_literals(
            "SELECT CASE WHEN o.id > 1 THEN 'high' END AS level FROM orders o WHERE level = 'high'",
            dict(columns, risks=[("level", "tinyint")])), [])

if __name__ == "__main__":
    unittest.main()
