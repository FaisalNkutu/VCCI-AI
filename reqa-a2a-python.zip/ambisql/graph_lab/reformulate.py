"""Questions the asker can pick, when a question cannot be answered as asked.

The clarifier stops a question in two cases the asker can settle.

NEEDS A CHOICE: the words fit several readings of this database. The page
used to offer the readings as the database records them, "employees with
status_code = 'ACTIVE'" or "Uses the pre-aggregated quantity_good column",
which nobody outside the data team can choose between.

NEEDS MORE: the question lacks something only the asker holds, a
threshold, a period, the value of something outside the database. The
page used to say so and offer nothing to click.

Both are answered here the same way: with complete questions, in the
asker's words, that settle what was open. One per reading for a choice.
Two to four for a NEEDS MORE, built on what the data holds (a column's
range and quartiles, the latest date it records, today), and a question
with a [blank] when nothing concrete can be found, rather than a value
made up for the occasion.

    from graph_lab.reformulate import headline, suggest
    print(headline(question, outcome, clarifier))
    for s in suggest(clarifier, question, outcome):
        s.question   the question to show, and to ask when it is picked
        s.choice     the option label it settles a choice with, or None
        s.note       one plain sentence, or ""
        s.blank      True when it holds a [blank] the asker must fill in

One model call writes them (REFORMULATE_SYSTEM, thinking off, bounded).
Its text is never trusted to be plain: a suggestion that names a column,
shows a code or SQL, or brings a number nobody gave, is replaced by a
template built from the option's meaning. Without a model, or when the
call fails, the templates alone come back: a convenience must never be
the reason a person sees an error.

NOT COVERED and NO DATA get none. Their verdict is the answer, and a
reformulation would invite the asker to ask again for what is not there.

The switch is DATAGORA_REFORMULATE (on by default), read when it is used
so the settings page takes effect on the next question; `enabled()` is
the one place that reads it.
"""

import datetime
import inspect
import logging
import math
import os
import re

from pydantic import BaseModel, ConfigDict

if __package__:
    from . import wording
    from .ambisql import Clarifier, Option
    from .coverage import NEEDS_MORE, classify
    from .prompts import REFORMULATE_SYSTEM
else:
    import wording
    from ambisql import Clarifier, Option
    from coverage import NEEDS_MORE, classify
    from prompts import REFORMULATE_SYSTEM

log = logging.getLogger("datagora.reformulate")

ENV = "DATAGORA_REFORMULATE"
_OFF = {"off", "0", "false", "no"}

# the model call's bounds. Thinking is off and a reply is at most four
# short questions with a note each, which fits in a few hundred tokens;
# the cap stops a model that loops from holding the page for minutes.
REPLY_TOKENS = 900
SECONDS = 60
# at most this many suggestions for a NEEDS MORE, the blank included
MAX_MORE = 4
# distinct values read from a numeric or date column for its quartiles
SAMPLE = 400


def enabled(value=None):
    """Whether suggestions are made: True or False wins, None reads the
    environment at the moment of use, on unless it says off.

    One reading for every surface (the pipeline, the client, the page's
    setting through the environment), so the switch cannot mean one thing
    in one place and another elsewhere."""
    if value is not None:
        return bool(value)
    return str(os.environ.get(ENV) or "on").strip().lower() not in _OFF


class Suggestion(BaseModel):
    """One question the asker can pick instead of the one they asked."""

    model_config = ConfigDict(extra="forbid")

    question: str
    # the option this question settles a choice with; None for a NEEDS
    # MORE, whose suggestions are asked as new questions
    choice: str | None = None
    note: str = ""
    # True when the question holds a [blank] the asker must fill in first
    blank: bool = False


def needs(outcome):
    """"choice", "more" or "": which of the two cases this outcome is.

    Read through coverage.classify, so the Ask page and a coverage report
    can never disagree on whether a question is NEEDS MORE or NOT
    COVERED."""
    if outcome is None:
        return ""
    action = getattr(outcome, "action", "")
    if action == "CLARIFY":
        return "choice" if getattr(outcome, "options", None) else ""
    if action == "GUIDE":
        try:
            verdict, _why = classify(outcome)
        except Exception:
            return ""
        return "more" if verdict == NEEDS_MORE else ""
    return ""


# ------------------------------------------------------------ the schema

NUMERIC = ("int", "decimal", "float", "double", "numeric", "real")
DATES = ("date", "datetime", "timestamp")


def _catalogue(clarifier):
    """{table: [(column, type)]}, or {} when it cannot be read: a lost
    connection costs the check its names, never the suggestions."""
    try:
        return dict(getattr(clarifier, "columns", None) or {})
    except Exception:
        return {}


def _column(cols, table, column):
    """(table, column, type) as the catalogue spells them, or None."""
    for t, cs in cols.items():
        if t.lower() == str(table or "").lower():
            for c, d in cs:
                if c.lower() == str(column or "").lower():
                    return t, c, str(d or "").lower()
    return None


def _words(name):
    """An identifier as words: quantity_good, quantityGood -> quantity good."""
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", str(name or ""))
    return re.sub(r"[_\s]+", " ", s).strip().lower()


def _is_key(clarifier, table, column):
    low = str(column or "").lower()
    if low == "id" or low.endswith("_id"):
        return True
    try:
        return bool(clarifier.is_a_key(table, column))
    except Exception:
        return False


def _label(clarifier, table, column):
    """How a column is said to a person: its name in words, or what the
    dictionary says it is when the name is an abbreviation."""
    said = _words(column)
    if not _plain_word(said.replace(" ", "")) or len(said) <= 3:
        try:
            meant = str(clarifier.means(table, column) or "").strip().rstrip(".")
        except Exception:
            meant = ""
        if meant and len(meant.split()) <= 6 and not offending(meant):
            return meant[0].lower() + meant[1:] if meant[1:2].islower() else meant
    return said


# ------------------------------------------------------- what is plain

# short words that are words, so a column named after one may be said
_SHORT_WORDS = {
    "age", "day", "tax", "fee", "pay", "job", "due", "sex", "zip", "fax",
    "way", "use", "vat", "row", "key", "map", "art", "bus", "car", "sea",
    "air", "gas", "oil", "toy", "tip", "web", "app", "fan", "hub", "kit",
    "lot", "net", "pet", "pin", "set", "sum", "top", "van", "end", "law",
}
_SYMBOLS = re.compile(r"[`=<>\[\]{}|\\]")
_SQL_WORDS = re.compile(r"\b(?:SELECT|WHERE|GROUP BY|ORDER BY|IS NULL|IS NOT NULL|"
                        r"NOT NULL|JOIN|DISTINCT)\b|\b(?:COUNT|SUM|AVG|MIN|MAX)\s*\(")
_DOTTED = re.compile(r"\b([A-Za-z]\w*)\.([A-Za-z]\w*)\b")
_QUOTED_CODE = re.compile(r"['\"‘’“”]([A-Z0-9][A-Z0-9 \-]+)"
                          r"['\"‘’“”]")


def _plain_word(name):
    """Whether a schema name is also an everyday word a person would use.

    "price", "status" and "employees" are, and refusing them would refuse
    the very sentences the asker would write. "qty", "dob", "CustID" and
    anything with an underscore or a digit are not."""
    if not name or not name.isalpha():
        return False
    if re.search(r"[a-z][A-Z]", name):
        return False
    low = name.lower()
    if len(low) <= 3:
        return low in _SHORT_WORDS
    return bool(re.search(r"[aeiouy]", low))


def offending(text, clarifier=None, question="", columns=None):
    """The first thing in `text` that someone who never saw the schema
    could not read, or "" when there is none.

    An underscore, a symbol or SQL; a table.column; a schema name that is
    not an everyday word (one the asker typed themselves is theirs); a
    quoted code. Case-insensitive and on whole words, so "price" in
    "prices" is not taken for the column."""
    s = str(text or "")
    if "_" in s:
        return "_"
    for pattern in (_SYMBOLS, _SQL_WORDS):
        m = pattern.search(s)
        if m:
            return m.group(0)
    cols = columns if columns is not None else (
        _catalogue(clarifier) if clarifier is not None else {})
    tables = {t.lower() for t in cols}
    for m in _DOTTED.finditer(s):
        if m.group(1).lower() in tables:
            return m.group(0)
    asked = {w.lower() for w in re.findall(r"[A-Za-z0-9]+", str(question or ""))}
    # the text's own words looked up, not every name of the schema: on a
    # database of thousands of columns the other way round is thousands
    # of patterns for one sentence. A name with an underscore was refused
    # above, so a name left to find is one word.
    names = _names(cols)
    for word in re.findall(r"[A-Za-z0-9]+", s):
        name = names.get(word.lower())
        if name and not _plain_word(name) and word.lower() not in asked:
            return name
    for m in _QUOTED_CODE.finditer(s):
        # case-sensitive: an asker who typed "active" did not type 'ACTIVE'
        if m.group(1) not in str(question or ""):
            return m.group(0)
    # a code even without quotes: live, E34 came back "in the SPOT exchange
    # rate", the stored value of exchange_rates.rate_type. Case-sensitive,
    # so an acronym the asker typed (EUR, VIP) stays theirs.
    for word in re.findall(r"\b[A-Z][A-Z0-9_]{2,}\b", s):
        if not re.search(rf"\b{re.escape(word)}\b", str(question or "")):
            return word
    return ""


def _names(cols):
    """{lower-case name: name} for every table and column."""
    names = {t.lower(): t for t in cols}
    for cs in cols.values():
        for c, _t in cs:
            names.setdefault(str(c).lower(), str(c))
    return names


def _humanize(text, cols):
    """An option's meaning as the clarifier wrote it, in words a person
    reads: table.column becomes the column's name in words, = 'ACTIVE'
    becomes "is active", IS NULL "is empty". Only a template is built from
    it, so it has to be readable rather than elegant."""
    s = str(text or "").replace("`", "")
    tables = {t.lower() for t in cols}

    def dotted(m):
        return _words(m.group(2)) if m.group(1).lower() in tables else m.group(0)

    s = _DOTTED.sub(dotted, s)
    s = re.sub(r"\s+IS\s+NOT\s+NULL\b", " is filled in", s, flags=re.I)
    s = re.sub(r"\s+IS\s+NULL\b", " is empty", s, flags=re.I)
    for sign, said in (("<>", " is not "), ("!=", " is not "), (">=", " at least "),
                       ("<=", " at most "), (">", " above "), ("<", " below "),
                       ("=", " is ")):
        s = s.replace(sign, said)

    def unquote(m):
        inner = m.group(2)
        return inner.lower() if inner.isupper() else inner

    s = re.sub(r"(['\"])([^'\"]*)\1", unquote, s)
    # stored codes the dictionary lists ("SPOT, MONTH AVG or BUDGET") read
    # as words, so the model is not handed a code to copy
    s = re.sub(r"\b[A-Z][A-Z0-9]{2,}\b", lambda m: m.group(0).lower(), s)
    names = _names(cols)

    def said(m):
        name = names.get(m.group(0).lower())
        if name and not _plain_word(name) and len(name) > 3:
            return _words(name)
        return m.group(0)

    s = re.sub(r"[A-Za-z0-9_]+", said, s)
    s = s.replace("_", " ")
    s = re.sub(r"[\[\]{}|\\]", " ", s)
    s = re.sub(r"\s+", " ", s).strip().rstrip(".")
    # "employees with status code is active" reads as "whose ... is"
    s = re.sub(r"\bwith ([a-z][a-z ]*?) is\b", r"whose \1 is", s)
    if s[:1].isupper() and s[1:2].islower():
        s = s[0].lower() + s[1:]
    return s


# ------------------------------------------------------------ the numbers

_NUMBER = re.compile(r"\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?")


def _canon(token):
    try:
        x = float(token.replace(",", ""))
    except ValueError:
        return token
    return str(int(x)) if x.is_integer() else repr(x)


def _numbers_in(text):
    return {_canon(t) for t in _NUMBER.findall(str(text or ""))}


_STEPS = (1, 1.5, 2, 2.5, 3, 4, 5, 6, 7.5, 10)


def _nice(x):
    """A round number near x: 9.87 -> 10, 23 -> 25, 137 -> 150."""
    if not x:
        return 0
    sign = -1 if x < 0 else 1
    x = abs(x)
    base = 10 ** math.floor(math.log10(x))
    return sign * min((s * base for s in _STEPS), key=lambda v: abs(v - x))


def _fmt(x):
    x = float(x)
    if x.is_integer():
        return str(int(x))
    return f"{x:.2f}".rstrip("0").rstrip(".")


def _quantile(sorted_values, q):
    if not sorted_values:
        return None
    i = (len(sorted_values) - 1) * q
    lo, hi = math.floor(i), math.ceil(i)
    return sorted_values[lo] + (sorted_values[hi] - sorted_values[lo]) * (i - lo)


def _to_float(v):
    if isinstance(v, bool):
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _distinct(clarifier, table, column):
    """(values, complete): distinct values, and whether they are all of
    them, through the clarifier's bounded reader."""
    reader = getattr(clarifier, "_distinct_values_checked", None)
    try:
        if reader is not None:
            values, ok = reader(table, column, limit=SAMPLE)
        else:
            values, ok = clarifier.distinct_values(table, column, limit=SAMPLE), True
    except Exception:
        return [], False
    values = list(values or []) if ok else []
    return values, ok and len(values) < SAMPLE


def _aggregate(clarifier, table, column, what):
    """One aggregate over a column, bounded in time, or None.

    MariaDB is bounded by max_statement_time, MySQL by its hint; whichever
    the server does not know fails and the other is tried. A failure is
    only the absence of a fact: the suggestions then rest on the sample."""
    t = str(table).replace("`", "``")
    c = str(column).replace("`", "``")
    body = f"SELECT {what} FROM `{t}`"
    body = body.replace("{c}", c)
    statements = (f"SET STATEMENT max_statement_time=3 FOR {body}",
                  body.replace("SELECT ", "SELECT /*+ MAX_EXECUTION_TIME(3000) */ ", 1))
    try:
        con = clarifier.connect()
    except Exception:
        return None
    try:
        for sql in statements:
            cur = None
            try:
                cur = con.cursor()
                cur.execute(sql)
                return cur.fetchone()
            except Exception:
                continue
            finally:
                if cur is not None:
                    try:
                        cur.close()
                    except Exception:
                        pass
        return None
    finally:
        try:
            con.close()
        except Exception:
            pass


def _number_facts(clarifier, table, column):
    """The range and quartiles of a numeric column, or None.

    The range is said only when it is the real one (the aggregate, or a
    sample that held every value); the quartiles come from the distinct
    values read, which is enough to propose values that mean something
    in this data."""
    values, complete = _distinct(clarifier, table, column)
    nums = sorted(x for x in (_to_float(v) for v in values) if x is not None)
    row = _aggregate(clarifier, table, column, "MIN(`{c}`), MAX(`{c}`)")
    lo = hi = None
    if row and len(row) >= 2 and _to_float(row[0]) is not None \
            and _to_float(row[1]) is not None:
        lo, hi = _to_float(row[0]), _to_float(row[1])
    elif nums and complete:
        lo, hi = nums[0], nums[-1]
    if not nums and lo is None:
        return None
    if not nums:
        nums = [lo, hi]
    return {"min": lo, "max": hi,
            "q": {q: _quantile(nums, q) for q in (0.1, 0.25, 0.5, 0.75, 0.9)}}


def _as_date(v):
    if isinstance(v, datetime.datetime):
        return v.date()
    if isinstance(v, datetime.date):
        return v
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", str(v or ""))
    if m:
        try:
            return datetime.date(*map(int, m.groups()))
        except ValueError:
            return None
    return None


def _latest(clarifier, table, column):
    """The latest date a column holds, or None when it cannot be known."""
    row = _aggregate(clarifier, table, column, "MAX(`{c}`)")
    if row:
        found = _as_date(row[0])
        if found:
            return found
    values, complete = _distinct(clarifier, table, column)
    dates = [d for d in (_as_date(v) for v in values) if d]
    return max(dates) if dates and complete else None


# ------------------------------------------------------- what is missing

_TIME = re.compile(
    r"\b(?:recent|recently|lately|soon|upcoming|nowadays|these days|"
    r"(?:last|this|past|previous|next|coming)\s+(?:few\s+)?"
    r"(?:years?|months?|weeks?|quarters?|days?))\b", re.I)
_FUTURE = re.compile(r"\b(?:next|upcoming|soon|coming)\b", re.I)
_THAN = re.compile(
    r"\b(?!(?:other|rather|whether|either|neither)\b)"
    r"(?P<cmp>\w+er|more\s+\w+|less\s+\w+|fewer|less|more)\s+than\s+"
    r"(?P<ref>(?:a|an|the|my|our)\s+[^?.!,;]+)", re.I)
_LOW = {
    "cheap", "cheaper", "cheapest", "affordable", "small", "smaller",
    "smallest", "tiny", "low", "lower", "lowest", "few", "fewer", "less",
    "light", "lighter", "short", "shorter", "slow", "slower", "quiet",
    "rare", "empty", "insufficient", "limited", "understocked", "unpopular",
    "weak", "poor", "young", "younger", "under", "below", "idle", "dormant",
    "underused", "understaffed", "sluggish", "thin", "narrow", "near",
}
_HEDGES = r"(?:very|quite|rather|too|really|nearly|almost|so|pretty)"
_MONTHS = ("January", "February", "March", "April", "May", "June", "July",
           "August", "September", "October", "November", "December")


def _bag(text):
    return {w.strip(".,;:?!\"'()").lower() for w in str(text or "").split()}


def _direction(text):
    """"less" when the words ask for the low end (cheap, few, under)."""
    return "less" if _bag(text) & _LOW else "more"


def _judgement(clarifier, text):
    if not text:
        return False
    judge = getattr(clarifier, "is_a_judgement", None)
    if judge is not None:
        try:
            return bool(judge(text))
        except Exception:
            pass
    return bool(_bag(text) & Clarifier.JUDGEMENTS)


def _superlative(clarifier, text):
    if not text:
        return False
    rank = getattr(clarifier, "is_a_superlative", None)
    if rank is not None:
        try:
            return bool(rank(text))
        except Exception:
            pass
    return any(w in Clarifier.SUPERLATIVE_WORDS or (len(w) >= 6 and w.endswith("est"))
               for w in _bag(text))


def gap(clarifier, question, outcome):
    """What a NEEDS MORE lacks, by rules that need no model.

    The order is the one measured on the real NEEDS MORE rows of the
    coverage runs (deliverables/plans/plan_reformulate_needs_more.md):
    a value for something outside the database, a period, a criterion
    for a ranking word, a threshold for a judgement; a reading offered by
    the clarifier otherwise; anything else is said with a blank."""
    phrase = getattr(outcome, "phrase", "") or ""
    words = _asker_words(clarifier, question, outcome)
    if getattr(outcome, "gap", "") == "data":
        # first, whatever else the question says: nobody can type in what
        # the records do not keep, and "later than the close of business"
        # with no time of day recorded was offered a blank to fill (review
        # of 26 October). Say what must be recorded, and offer what the
        # data answers (E65, 23 October); a past state, the current one
        if wording.POINT_IN_TIME.search(words or phrase or question or ""):
            return "as_of"
        return "data"
    if _THAN.search(question or ""):
        return "outside"
    # a period when the open words are about time, not whenever the
    # question names one: live, "What was our revenue last year?" was
    # judged on "revenue" (nothing is called that), and was offered
    # periods for a word that is not one
    # a missing value with a number ("the 2027 budget figures") is a value,
    # whatever time word the question holds: it was offered periods
    # (review of 26 October)
    valued = bool(re.search(r"[0-9]", getattr(outcome, "missing", "") or ""))
    if (_TIME.search(words or phrase)
            or (not words and not valued and _TIME.search(question or ""))
            or wording.VAGUE_TIME.search(words or phrase)):
        return "period"
    if wording.POINT_IN_TIME.search(words or phrase):
        # "on 1 March 2025" when only the current state is kept: what the
        # data can answer is the current value (E42, 23 October)
        return "as_of"
    if _superlative(clarifier, phrase):
        return "criterion"
    if _judgement(clarifier, phrase) or _judgement(clarifier, question):
        return "threshold"
    if getattr(outcome, "options", None):
        return "reading"
    return "other"


def _in(question, phrase):
    return bool(phrase) and phrase.lower() in str(question or "").lower()


def _asker_words(clarifier, question, outcome):
    """The open words as the asker wrote them, or "".

    The clarifier's phrase is the model's, and sometimes a paraphrase
    ("what constitutes 'cheap'"); shown back, it must be words the asker
    recognises as theirs, spelt as they spelt them: live, the judge quoted
    "so100667" for the asker's SO100667."""
    found = _found_words(clarifier, question, outcome)
    m = re.search(re.escape(found), str(question or ""), re.I) if found else None
    return m.group(0) if m else found


def _found_words(clarifier, question, outcome):
    def theirs(words):
        # a span of the question, and a span rather than all of it: the
        # model sometimes names the whole question as its phrase, and
        # 'what "Which books cost less than 100?" means' asks nothing
        return (_in(question, words) and not offending(words, clarifier, question)
                and len(words) < 0.8 * len(str(question or "").strip()))

    phrase = (getattr(outcome, "phrase", "") or "").strip().strip("\"'")
    # the word the judge quoted, when the asker wrote it: 'Nothing in this
    # schema is named or described as "cost"' points at the word to settle,
    # and is the sharper of the two when the phrase merely contains it
    # ("cost" rather than "cost less than 100")
    said = f"{getattr(outcome, 'question', '')} {getattr(outcome, 'reason', '')}"
    spans = re.findall(r"\"([^\"]{2,60})\"|'([^']{2,60})'", said)
    quoted = [s.strip() for pair in spans for s in pair if s and theirs(s.strip())]
    if theirs(phrase):
        inside = [q for q in quoted if q.lower() in phrase.lower() and q.lower() != phrase.lower()]
        return max(inside, key=len) if inside else phrase
    if quoted:
        return max(quoted, key=len)
    if needs(outcome) != "more":
        return ""
    m = _THAN.search(question or "")
    if m:
        return m.group(0).strip()
    for w in re.findall(r"[A-Za-z][\w-]*", question or ""):
        if _judgement(clarifier, w):
            return w
    return ""


def headline(question, outcome, clarifier=None):
    """The clarifying sentence in plain words, for above the suggestions."""
    kind = needs(outcome)
    words = _asker_words(clarifier, question, outcome)
    if kind == "choice":
        return (f"By \"{words}\", which do you mean?" if words
                else "Your question can be read in more than one way. "
                     "Which do you mean?")
    if kind != "more":
        return ""
    missing = gap(clarifier, question, outcome)
    if missing == "outside":
        m = _THAN.search(question or "")
        ref = m.group("ref").strip() if m else words
        return (f"To answer, I need a value for \"{ref}\": the data does not "
                f"hold one.")
    if missing == "period":
        m = _TIME.search(question or "")
        words = m.group(0) if m and not _TIME.search(words or "") else words
    if missing == "data":
        said = _missing_said(outcome, clarifier, question)
        if not said:
            return ("The data does not record what this asks, so it cannot be answered as "
                    "asked: the database would have to record it.")
        return (f"The data does not record {said}, so it cannot be answered as asked. To "
                f"answer it, {said} would have to be added to the database.")
    if missing == "as_of":
        when = _moment(words or getattr(outcome, "phrase", "")) or words
        return (f"The data keeps only the current value, not the one {when}."
                if when else "The data keeps only the current value.")
    said = _missing_said(outcome, clarifier, question)
    if missing == "other" and said:
        # what the judge found missing, said as it is: "I need the
        # coordinates of the office", not "what 'our office' means" (pt-h26)
        if _CLAUSE.match(said):
            return f"To answer, I need to know {said}."
        return f"To answer, I need {said}."
    if not words:
        return "To answer, I need a little more detail."
    return {
        "period": f"To answer, I need to know which period \"{words}\" covers for you.",
        "criterion": f"To answer, I need to know what \"{words}\" is judged by.",
        "threshold": f"To answer, I need to know what \"{words}\" means for you.",
        "reading": f"To answer, I need to know what \"{words}\" refers to.",
    }.get(missing, f"To answer, I need to know more about what \"{words}\" means.")


# ------------------------------------------------------------ templates

def _body(question):
    return str(question or "").strip().rstrip("?.!").strip()


def _replace(body, span, text):
    """`span` replaced by `text`, once, whatever its case, or None."""
    if not span:
        return None
    m = re.search(re.escape(span), body, re.I)
    if not m:
        return None
    return re.sub(r"\s+", " ", body[:m.start()] + text + body[m.end():]).strip()


def _with_value(question, span, label, op, value):
    """A judgement or a comparison replaced by a threshold on a column:
    "Which products are cheap?" -> "Which products have a price below 10?".
    Replaced, never added beside it: a question that keeps "cheap" next
    to its definition is asked about "cheap" again."""
    body = _body(question)
    if span:
        m = re.search(rf"\b(is|are|was|were)\s+(?:{_HEDGES}\s+)?{re.escape(span)}\b",
                      body, re.I)
        if m:
            verb = "has" if m.group(1).lower() in ("is", "was") else "have"
            done = body[:m.start()] + f"{verb} a {label} {op} {value}" + body[m.end():]
            return re.sub(r"\s+", " ", done).strip() + "?"
        than = re.match(r"(?is)(.*?\bthan)\s+\S.*$", span)
        if than:
            # "cost more than my rent": the comparison kept, its reference
            # replaced by the value; "Which products cost, with a price
            # above 20?" was no sentence (review of 26 October)
            done = _replace(body, span, f"{than.group(1)} {value}")
            if done:
                # the column named: two columns give two readings, and
                # "cost more than 15" said neither (review of the fixes)
                return f"{done}, by {label}?"
        rest = _replace(body, span, "")
        if rest:
            return f"{rest.rstrip(' ,')}, with a {label} {op} {value}?"
    return f"{body}, with a {label} {op} {value}?"


def _missing_said(outcome, clarifier=None, question=""):
    """What the judge says is missing, ready for a sentence: twelve words at
    most, no column, code or SQL (then ""), an article for a bare noun
    ("office coordinates"), none for a clause ("what the 2027 rates are")
    nor a word in capitals made lower case ("The budget" -> "the budget")."""
    said = " ".join(str(getattr(outcome, "missing", "") or "").split()[:12]).strip(" .,;:")
    if not said or offending(said, clarifier, question):
        return ""
    first = said.split()[0]
    if _DETERMINER.match(first) and first[0].isupper():
        said = first.lower() + said[len(first):]
    if not _DETERMINER.match(said) and not _CLAUSE.match(said):
        said = f"the {said}"
    return said


# a clause, said after "to know": "what the rates are", "which warehouse"
_CLAUSE = re.compile(r"(?:what|which|how|when|where|who|whom|whose|whether|if)\b", re.I)

_DETERMINER = re.compile(r"(?:the|a|an|its|their|his|her|our|your|some|any|each|every|"
                         r"this|that|these|those|one|two|three)\b", re.I)
_LEADING = re.compile(r"^(with|at|in|of|for|from|on|by|to|under|over|than)\s+", re.I)


def _named_blank(question, words, said):
    """The open words replaced by what is missing, in brackets, reading as
    a sentence: the preposition the words began with is kept ("have been
    with [the tariff increase percentage]", E26) and an article the
    question already has is not said twice ("at the [2027 budget exchange
    rates]", E34)."""
    lead = _LEADING.match(words)
    span = words[lead.end():] if lead else words
    before = re.search(re.escape(words), question, re.I)
    if before and re.search(r"\bthe\s*$", question[:before.start()], re.I):
        said = re.sub(r"^the\s+", "", said, flags=re.I)
    return _with_text(question, span if lead else words, f"[{said}]")


def _canon_question(text):
    """A question as compared with another: case, spaces and the mark aside."""
    return " ".join(str(text or "").lower().rstrip("?. ").split())


def _with_text(question, span, text, after=""):
    body = _body(question)
    done = _replace(body, span, text) if span else None
    if done is None:
        done = f"{body} {text}"
    return f"{done}{after}?"


def _choice_template(question, words, option, plain, label=""):
    body = _body(question)
    if option.value is not None and words:
        done = _replace(body, words, plain)
        if done and done.lower() != body.lower():
            return done + "?"
        if done:
            # the value reads as the asker's own word ("active" for ACTIVE):
            # the question unchanged carried no reading, and picked, it went
            # to the SQL as ambiguous as it came (review of 26 October). The
            # column says which (review of the fixes: "with the value
            # active" twice, the caller gives no label)
            column = label or str(option.column or "").replace("_", " ") or "value"
            return f"{body}, with the {column} {option.value}?"
    # a meaning of a word or two says nothing as a definition: live, a
    # dictionary's "when" became 'taking "SO100667" to mean when'. Nor
    # does an identifier have a meaning to take; the column is named then.
    if label and (len(plain.split()) < 3 or re.search(r"\d", words or "")
                  or _bag(plain) & Clarifier.JUDGEMENTS):
        return f"{body}, going by the {label}?"
    if words:
        return f"{body}, taking \"{words}\" to mean {plain}?"
    return f"{body}, meaning {plain}?"


# what the clarifier writes as an option's meaning when it has none of its
# own: how the column was found, not what it holds
_GENERIC = re.compile(r"points at|close in meaning|described that way|"
                      r"the column that (?:actually )?holds|the state it records", re.I)


def _plain_option(clarifier, option, cols):
    """What an option means, in words a person reads.

    An option found by its name alone carries how it was found as its
    meaning: live, E60 offered four readings each "the column 'how many
    hours after the end of their trip' points at (token)", and the
    templates repeated it. What the dictionary says the column holds is
    used then, or the column and its table in words."""
    if option.value is not None:
        means = str(option.means or "")
        named = means.split(", as stored in")[0].strip() if ", as stored in" in means else ""
        if named:
            return named
        # a code as stored (GLD_PLUS) is no word a person reads (review of
        # 23 October): in words, lower case
        value = str(option.value)
        return value.replace("_", " ").lower() if re.fullmatch(r"[A-Z0-9_\-]+", value) else value
    if _GENERIC.search(str(option.means or "")) and option.table and option.column:
        try:
            said = str(clarifier.means(option.table, option.column) or "").strip()
        except Exception:
            said = ""
        return (_humanize(said, cols) if said else
                f"the {_label(clarifier, option.table, option.column)} "
                f"of {_words(option.table)}")
    said = _humanize(option.means, cols)
    if said:
        return said
    if option.table and option.column:
        return f"the {_label(clarifier, option.table, option.column)}"
    return _humanize(option.label, cols)


# --------------------------------------------------------- the model call

def _accepts(fn, name):
    try:
        params = inspect.signature(fn).parameters
    except (TypeError, ValueError):
        return False
    return name in params or any(p.kind is p.VAR_KEYWORD for p in params.values())


def _passes(model, name):
    """Whether `name` given to model.json reaches the call it makes."""
    return _accepts(model.json, name) and (
        not hasattr(model, "_chat") or _accepts(model._chat, name))


def _model(clarifier):
    """The clarifier's model without thinking, or None when there is none.

    A copy, so the clarifier's own model keeps thinking for the verdicts
    it is asked for. SystemExit too: an unconfigured models.json says so
    that way, and here it only means the templates are used."""
    try:
        base = clarifier.llm
    except (Exception, SystemExit):
        return None
    if base is None or not hasattr(base, "json"):
        return None
    if hasattr(base, "thinking"):
        try:
            return base.thinking(False)
        except Exception:
            return base
    return base


def _reply_schema(ids):
    return {"type": "object",
            "properties": {"suggestions": {
                "type": "array", "maxItems": len(ids),
                "items": {"type": "object",
                          "properties": {"id": {"type": "string", "enum": ids},
                                         "question": {"type": "string"},
                                         "note": {"type": "string"}},
                          "required": ["id", "question", "note"]}}},
            "required": ["suggestions"]}


def _written(clarifier, question, words, items, heading, facts, system):
    """{id: (question, note)} as the model wrote them, or {} on any
    failure: no model, an unreachable one, a reply that is not JSON."""
    if not items:
        return {}
    model = _model(clarifier)
    if model is None:
        return {}
    lines = [f"Question: {question}"]
    if words:
        lines.append(f"Open words: \"{words}\"")
    lines.extend(facts)
    lines.extend(f"{heading} {it['id']}: {it['say']}" for it in items)
    ids = [it["id"] for it in items]
    kw = {}
    try:
        if _passes(model, "schema"):
            kw["schema"] = _reply_schema(ids)
        if _passes(model, "num_predict"):
            kw["num_predict"] = REPLY_TOKENS
        if _passes(model, "timeout"):
            kw["timeout"] = SECONDS
        reply = model.json(system or REFORMULATE_SYSTEM, "\n".join(lines), **kw)
    except Exception as e:
        log.info("reformulate: the model call failed (%s)", str(e)[:80])
        return {}
    if not isinstance(reply, dict):
        return {}
    out = {}
    for s in reply.get("suggestions") or []:
        if isinstance(s, dict) and str(s.get("id")) in ids:
            out.setdefault(str(s.get("id")), (str(s.get("question") or ""),
                                              str(s.get("note") or "")))
    return out


def _tidy(text):
    text = re.sub(r"\s+", " ", str(text or "")).strip().strip("\"").strip()
    return text


def _usable(text, clarifier, question, cols, allowed, required=(), named="",
            settles=None, drops=()):
    """Whether a question the model wrote may be shown as it is.

    `named`: the word a value question must keep for what it compares.
    Measured live: "Which books cost less than 100?" came back NEEDS MORE,
    nothing in the schema being called "cost", where "Which books have a
    price below 100?" came back answerable. A NEEDS MORE suggestion is
    asked again as it is, so it has to say the measure by its name."""
    if not 5 < len(text) <= 300 or not text.endswith("?"):
        return False
    # the question as it was asked settles nothing (live, E60: the model
    # gave one reading the original question back)
    if re.sub(r"\W+", " ", text).strip().lower() == re.sub(
            r"\W+", " ", str(question or "")).strip().lower():
        return False
    # a bracket the asker did not write is a label pasted in: live, E65
    # came back "claimed on day claimed (the claim date)"
    if ("(" in text or ")" in text) and "(" not in str(question or ""):
        return False
    # about as long as what was asked: a suggestion half as long again
    # carries an explanation, not a question (live, E34: 188 characters
    # for a question of 117, two readings pasted into it)
    if len(text) > max(1.5 * len(str(question or "")), len(str(question or "")) + 60):
        return False
    if offending(text, clarifier, question, columns=cols):
        return False
    said = _numbers_in(text)
    if said - allowed:
        return False            # a number nobody gave
    # nor may it drop one the asker gave: live, E66 lost "in January 2026"
    # to a reading of "change", and asked about every January since
    if _numbers_in(question) - said - set(drops):
        return False
    if named and not re.search(rf"\b{re.escape(named)}", text, re.I):
        return False
    if settles is not None:
        # asked again as it is, so it must not bring a word the judge
        # takes for a threshold (live: "an empty date the book came back"
        # came back NEEDS MORE on "empty"), nor keep the one it settles
        vague = _bag(text) & Clarifier.JUDGEMENTS
        if vague - _bag(question) or vague & settles:
            return False
    return all(_canon(r) in said for r in required)


def _settle(clarifier, question, words, items, heading, facts, system, cols,
            model_notes=True, rejudged=False):
    """Each item's question: the model's when it is plain, its template
    otherwise. Two items given the same question by the model keep the
    first and fall back for the others, so no two buttons say the same.

    `model_notes` False keeps the notes to what the code read from the
    data. Measured live: for "cheaper than a coffee" the model noted that
    100 was "the lowest price in the data", on a column whose prices start
    at 1.10; and that warehouses "have a quantity on hand" when stock is
    held per product. A note about the data is a claim, and only the data
    may make it."""
    written = _written(clarifier, question, words, items, heading, facts, system)
    # a suggestion asked again as a new question (NEEDS MORE): the vague
    # words it settles, which it must not keep
    settles = (_bag(words) & Clarifier.JUDGEMENTS) if rejudged else None
    seen, out = set(), []
    base = _numbers_in(question) | _numbers_in(" ".join(facts))
    for it in items:
        text, note = written.get(it["id"], ("", ""))
        text, note = _tidy(text), _tidy(note)
        allowed = base | _numbers_in(it["say"])
        if text and not text.endswith("?") and not text.endswith("."):
            text += "?"
        if not text or text.lower() in seen or not _usable(
                text, clarifier, question, cols, allowed, it.get("keep", ()),
                it.get("named", ""), settles, it.get("drops", ())):
            text, note = it["template"], it.get("note", "")
            if offending(text, clarifier, question, columns=cols):
                # _humanize writes a meaning, which starts in lower case; a
                # question keeps its capital ("how many active employees,
                # with the status code active?" was offered for a stored value)
                text = _humanize(text, cols)
                text = text[:1].upper() + text[1:]
            if _canon_question(text) == _canon_question(question):
                # never the asker's own question back: it settles nothing
                text = f"{text.rstrip('?')} ({_words(it['say'])[:60]})?"
            if text.lower() in seen:
                # two readings worded alike: each says what it reads
                text = f"{text.rstrip('?')} ({_words(it['say'])[:60]})?"
        elif not model_notes or not note or (
                offending(note, clarifier, question, columns=cols)
                or _numbers_in(note) - allowed or len(note) > 200):
            # the fact read from the data, when the model added none of
            # its own or one that cannot be shown
            note = it.get("note", "")
        seen.add(text.lower())
        out.append((it, text, note))
    return out


# ------------------------------------------------------------ the cases

def _choice(clarifier, question, outcome, system, cols):
    words = _asker_words(clarifier, question, outcome)
    items = []
    for i, option in enumerate(outcome.options, 1):
        plain = _plain_option(clarifier, option, cols)
        items.append({"id": str(i), "say": plain, "option": option,
                      "template": _choice_template(question, words, option, plain)})
    settled = _settle(clarifier, question, words, items, "READING", [], system, cols)
    return [Suggestion(question=text, choice=it["option"].label, note=note)
            for it, text, note in settled]


def _columns_of(clarifier, outcome, cols, kinds):
    """The columns the outcome is about whose type is one of `kinds`.

    In order of authority: the outcome's own options, then the model's
    candidates for this very phrase (the clarifier keeps its last reply;
    one kept for another question is ignored), then a table.column the
    judge's text names. Each is confirmed in the catalogue, and keys are
    left out: a member_id is no threshold."""
    pairs = [(o.table, o.column) for o in getattr(outcome, "options", None) or []]
    raw = getattr(clarifier, "last_reply", None)
    if isinstance(raw, dict) and (raw.get("phrase") or "").strip() == (
            getattr(outcome, "phrase", "") or "").strip():
        pairs += [(c.get("table"), c.get("column"))
                  for c in raw.get("candidates") or [] if isinstance(c, dict)]
    text = f"{getattr(outcome, 'reason', '')} {getattr(outcome, 'question', '')}"
    pairs += [m.groups() for m in _DOTTED.finditer(text)]
    found, seen = [], set()
    for t, c in pairs:
        hit = _column(cols, t, c)
        if not hit or (hit[0].lower(), hit[1].lower()) in seen:
            continue
        seen.add((hit[0].lower(), hit[1].lower()))
        kind = hit[2]
        wanted = (any(k in kind for k in NUMERIC) if kinds is NUMERIC
                  else kind in kinds or kind.startswith(kinds))
        if wanted and not _is_key(clarifier, hit[0], hit[1]):
            found.append(hit[:2])
    return found


# what a judgement or a comparative is measured on, by the words a schema
# uses for it. Only ever a fallback, for when neither the clarifier nor its
# model named a column, and only in the tables the question names.
_MEASURES = (
    (("cheap", "expensive", "pricey", "affordable", "costly", "cost", "price",
      "pay", "spend"), ("price", "cost", "amount", "fee", "rate", "total")),
    (("heavy", "heavier", "light", "lighter", "weigh"), ("weight", "mass")),
    (("big", "bigger", "large", "larger", "small", "smaller", "tiny", "huge",
      "full", "empty"), ("size", "capacity", "area", "volume", "quantity")),
    (("long", "longer", "short", "shorter"), ("length", "duration", "pages", "minutes")),
    (("fast", "faster", "slow", "slower", "quick"), ("speed", "duration", "days", "time")),
)


def _measure_named(clarifier, question, words, cols):
    """Numeric columns the asker's words point at, in the tables the
    question names: "cheaper than a coffee" about products -> products.price.

    Measured live: "Which products are cheaper than a coffee?" came back
    NEEDS MORE with no column at all (the model's candidates were about
    "a coffee"), and the asker was offered a blank where the prices were
    right there. Nothing is guessed outside the named tables, and a key is
    never a measure."""
    said = {w.rstrip("s") for w in _bag(f"{words} {question}")} | _bag(f"{words} {question}")
    hints = [names for triggers, names in _MEASURES
             if any(t in said or any(w.startswith(t) for w in said) for t in triggers)]
    if not hints:
        return []
    asked = {w.rstrip("s") for w in _bag(question)} | _bag(question)
    tables = [t for t in cols if t.lower() in asked or t.lower().rstrip("s") in asked]
    found = []
    for names in hints:
        for t in tables:
            for c, kind in cols[t]:
                low = c.lower()
                if (any(n in low for n in names) and any(k in str(kind).lower() for k in NUMERIC)
                        and not _is_key(clarifier, t, c) and (t, c) not in found):
                    found.append((t, c))
    return found


def _value_items(clarifier, question, outcome, cols, missing):
    """Thresholds read from the data, for a judgement or for the value of
    something outside the database. Returns (items, facts, blank)."""
    words = _asker_words(clarifier, question, outcome)
    m = _THAN.search(question or "")
    span = m.group(0).strip() if missing == "outside" and m else words
    direction = _direction(m.group("cmp") if missing == "outside" and m
                           else f"{words} {question}")
    op = "below" if direction == "less" else "above"
    quantiles = ((0.25, 0.5, 0.75) if direction == "less" else (0.5, 0.75, 0.9))
    items, facts = [], []
    columns = (_columns_of(clarifier, outcome, cols, NUMERIC)
               or _measure_named(clarifier, question, f"{words} {span}", cols))[:2]
    for n, (table, column) in enumerate(columns):
        facts_of = _number_facts(clarifier, table, column)
        if not facts_of:
            continue
        label = _label(clarifier, table, column)
        lo, hi = facts_of["min"], facts_of["max"]
        fact = (f"Measured on: the {label}, from {_fmt(lo)} to {_fmt(hi)} in the data"
                if lo is not None and hi is not None else f"Measured on: the {label}")
        facts.append(fact)
        note = (f"In the data, the {label} goes from {_fmt(lo)} to {_fmt(hi)}."
                if lo is not None and hi is not None else "")
        values = []
        for q in quantiles[:3 if n == 0 else 1]:
            # strictly inside the range: "above 500" on a column whose
            # largest value is 500 matches nothing, and was proposed live
            # for "nearly full"; the rounded value, else the quantile itself
            for v in (_nice(facts_of["q"][q]), facts_of["q"][q]):
                if lo is None or hi is None or lo < v < hi:
                    break
            else:
                continue
            text = _fmt(v)
            if text not in values:
                values.append(text)
        for text in values:
            if len(items) >= MAX_MORE - 1:
                break
            items.append({
                "id": str(len(items) + 1),
                "say": f"{op} {text}" + (f", on the {label}" if len(columns) > 1 else ""),
                "keep": [text],
                "named": _head_word(label),
                "template": _with_value(question, span, label, op, text),
                "note": note if not items else ""})
    blank = None
    if not items:
        if columns:
            label = _label(clarifier, *columns[0])
            blank = _with_value(question, span, label, op, "[amount]")
        elif missing == "outside" and m:
            blank = _with_text(question, m.group("ref").strip(), "[amount]")
        elif words:
            blank = f"{_body(question)}, where \"{words}\" means [your limit]?"
        else:
            blank = f"{_body(question)} [say what you mean]?"
    return items, facts, blank


def _head_word(label):
    """The word a question must keep for a measure: "price" for "unit
    price", the longest word otherwise ("capacity" for "capacity units")."""
    words = [w for w in re.findall(r"[A-Za-z]+", label or "") if len(w) > 2]
    if not words:
        return ""
    return words[-1] if len(words) <= 2 and words[-1] not in ("units", "amount") \
        else max(words, key=len)


def _fmt_date(d):
    return f"{d.day} {_MONTHS[d.month - 1]} {d.year}"


def _period_items(clarifier, question, outcome, cols, today):
    """Periods anchored on today and on the latest date the data holds.

    Both, because they answer different things: "in the last 30 days" is
    what the asker probably meant, and on a database whose latest record
    is a year old it matches nothing; the 30 days up to that record is a
    period the data can answer, said with its dates."""
    words = _asker_words(clarifier, question, outcome)
    m = _TIME.search(question or "")
    # the time words themselves are what a period replaces, with the
    # preposition before them: every period says its own ("in the in 2025",
    # review of 23 October)
    span = m.group(0) if m else (words if _in(question, words) else "")
    if span:
        lead = re.search(r"(?:\b(?:in|during|over|within|for|from|since)\s+(?:the\s+)?)?"
                         + re.escape(span), question or "", re.I)
        span = lead.group(0) if lead else span
    text = f"{words} {question}".lower()
    this = re.search(r"\b(?:this|current)\s+(?:fiscal\s+)?(?:year|quarter|month|week)\b", text)
    few = re.search(r"\b(?:few|several|couple of)\b", text)
    columns = _columns_of(clarifier, outcome, cols, DATES)
    latest, label = None, ""
    for table, column in columns[:2]:
        latest = _latest(clarifier, table, column)
        if latest:
            label = _label(clarifier, table, column)
            break
    unit = ("year" if re.search(r"\byears?\b", text) else
            "quarter" if re.search(r"\bquarters?\b", text) else
            "month" if re.search(r"\bmonths?\b", text) else
            "week" if re.search(r"\bweeks?\b", text) else "recent")
    from_today = f"Counted back from today, {_fmt_date(today)}."
    periods = []                                  # (say, note)
    if _FUTURE.search(text):
        ahead = f"Counted from today, {_fmt_date(today)}."
        nxt = today.replace(day=1) + datetime.timedelta(days=32)
        periods = ([(f"in {today.year + 1}", "")] if unit == "year" else
                   [(f"in {_MONTHS[nxt.month - 1]} {nxt.year}", "")] if unit == "month" else
                   [("in the next 7 days", ahead), ("in the next 30 days", ahead)])
        latest = None
    elif this:
        # "this year", "this month": the one going on, never the last one
        periods = ([(f"in {today.year}", f"From 1 January to today, {_fmt_date(today)}.")]
                   if unit == "year" else
                   [(f"in {_MONTHS[today.month - 1]} {today.year}", "Up to today.")]
                   if unit == "month" else
                   [("in the last 3 months", from_today)] if unit == "quarter" else
                   [("in the last 7 days", from_today)])
    elif few:
        periods = {"year": [("in the last 2 years", from_today), ("in the last 3 years", from_today)],
                   "quarter": [("in the last 6 months", from_today),
                               ("in the last 12 months", from_today)],
                   "month": [("in the last 3 months", from_today),
                             ("in the last 6 months", from_today)],
                   "week": [("in the last 2 weeks", from_today), ("in the last 4 weeks", from_today)],
                   }.get(unit, [("in the last 7 days", from_today), ("in the last 30 days", from_today)])
    elif unit == "year":
        periods = [(f"in {today.year - 1}", ""), ("in the last 12 months", from_today)]
    elif unit == "quarter":
        periods = [("in the last 3 months", from_today)]
    elif unit == "month":
        first = today.replace(day=1) - datetime.timedelta(days=1)
        periods = [(f"in {_MONTHS[first.month - 1]} {first.year}", ""),
                   ("in the last 30 days", from_today)]
    elif unit == "week":
        periods = [("in the last 7 days", from_today)]
    else:
        periods = [("in the last 30 days", from_today),
                   ("in the last 90 days", from_today)]
    anchored = []
    if latest and latest < today:
        said = f"The latest date in the data is {_fmt_date(latest)}."
        if unit == "year":
            anchored = [(f"in the 12 months up to {_fmt_date(latest)}", said)]
        elif unit == "month":
            anchored = [(f"in {_MONTHS[latest.month - 1]} {latest.year}", said)]
        elif unit == "week":
            anchored = [(f"in the 7 days up to {_fmt_date(latest)}", said)]
        else:
            anchored = [(f"in the 30 days up to {_fmt_date(latest)}", said)]
    # a data whose latest date is well behind today first: the period it
    # can answer is the one the asker learns the most from
    stale = latest is not None and (today - latest).days > 30
    ordered = anchored + periods if stale else periods + anchored
    after = f", going by the {label}" if len(columns) > 1 and label else ""
    facts = ([f"Today is {_fmt_date(today)}."]
             + ([f"Measured on: the {label}; the latest in the data is "
                 f"{_fmt_date(latest)}."] if latest else []))
    items = []
    seen = set()
    for say, note in ordered:
        if say in seen or len(items) >= MAX_MORE - 1:
            continue
        seen.add(say)
        items.append({"id": str(len(items) + 1), "say": say + after,
                      "template": _with_text(question, span, say, after), "note": note})
    return items, facts, None


def _readings_of(clarifier, outcome, cols, words=""):
    """The readings to offer: the outcome's options, or else the columns
    the model proposed for this very phrase, confirmed in the catalogue and
    keys left out.

    Measured live: "How many loans are still open?" came back NEEDS MORE
    with no option and loans.returned_at among the model's candidates; the
    asker was offered only a blank, while "loans not returned yet" was the
    reading to put to them. A candidate is a lead, never a verdict: the
    question it gives is asked again and judged on its own words."""
    if getattr(outcome, "options", None):
        return list(outcome.options)
    raw = getattr(clarifier, "last_reply", None)
    if not isinstance(raw, dict) or (raw.get("phrase") or "").strip() != (
            getattr(outcome, "phrase", "") or "").strip():
        return []
    found, seen = [], set()
    for c in raw.get("candidates") or []:
        if not isinstance(c, dict):
            continue
        hit = _column(cols, c.get("table"), c.get("column"))
        if not hit or (hit[0], hit[1]) in seen or _is_key(clarifier, hit[0], hit[1]):
            continue
        seen.add((hit[0], hit[1]))
        # what the dictionary says the column holds, before what the model
        # said it means: live, loans.returned_at came with "when a loan is
        # currently active", which became "How many loans are currently
        # active?" and was judged NEEDS MORE again, while the dictionary
        # says "Date the book came back, empty while it is out"
        try:
            said = str(clarifier.means(hit[0], hit[1]) or "").strip()
        except Exception:
            said = ""
        option = Option(label=f"{hit[0]}.{hit[1]}", means=said or str(c.get("means") or ""),
                        table=hit[0], column=hit[1])
        found.append((option, f"{c.get('means') or ''} {said} {_words(hit[1])}".lower()))
    # the candidates about the open words, when the model said which: live,
    # E46 proposed segment_id for "Gold customers" beside the order date and
    # the status, there to filter 2025 and the cancelled orders, and all
    # three were offered as readings of "gold"
    low = (words or "").lower()
    about = [o for o, text in found if low and low in text]
    return about or [o for o, _text in found]


def _reading_items(clarifier, question, outcome, cols, missing):
    """A GUIDE that offers columns: each, said as a question."""
    words = _asker_words(clarifier, question, outcome)
    items = []
    for option in _readings_of(clarifier, outcome, cols, words)[:MAX_MORE - 1]:
        plain = _plain_option(clarifier, option, cols)
        if missing == "criterion" and option.table and option.column:
            label = _label(clarifier, option.table, option.column)
            say = f"judged by the {label}"
            template = f"{_body(question)}, judged by the {label}?"
        else:
            label = (_label(clarifier, option.table, option.column)
                     if option.table and option.column else "")
            # what the reading means, never a clause to paste: live, "read
            # off the net amount: total amount of the PO" came back pasted
            # whole into the question
            say = (f"{plain} (the {label})" if label and plain != f"the {label}"
                   else plain)
            template = _choice_template(question, words, option, plain, label)
        items.append({"id": str(len(items) + 1), "say": say, "template": template})
    said = " ".join(str(getattr(outcome, "missing", "") or "").split()[:10])
    blank = None if items else (
        f"{_body(question)}, judged by [what]?" if missing == "criterion"
        # what the judge knows is missing, named in the blank: "at the
        # [the 2027 budget exchange rates]" reads, "at the [what you mean
        # by \"budget exchange rate finance has set for 2027\"]" did not (E34)
        else _named_blank(question, words, said) if words and said
        else _with_text(question, words, f"[what you mean by \"{words}\"]")
        if words else f"{_body(question)} [say what you mean]?")
    return items, [], blank


def _moment(text):
    """The point in time the text names, with the year that follows it:
    "on 1 March 2025", not "on 1 March"."""
    text = str(text or "")
    m = wording.POINT_IN_TIME.search(text)
    if not m:
        return ""
    # the date after the words: "as of 1 March 2025", "on June 3, 2024",
    # "at the end of 2025", or a year alone (review of 23 October: "as of"
    # was taken alone and the date kept)
    months = "|".join(_MONTHS)
    date = re.match(r"[\s,]*(?:(?:the\s+)?\d{1,2}(?:st|nd|rd|th)?\s+(?:of\s+)?(?:" + months
                    + r")\.?,?\s*(?:\d{4})?|(?:" + months + r")\.?\s+\d{1,2}(?:st|nd|rd|th)?"
                    r",?\s*(?:\d{4})?|\d{4}-\d{2}-\d{2}|(?:" + months + r")\s+\d{4}|\d{4})\b",
                    text[m.end():], re.I)
    return m.group(0) + (date.group(0).rstrip() if date else "")


_DANGLING = re.compile(r"\s+(?:were|was|is|are|be|been|have|has|had|do|does|did|of|with|by|"
                       r"in|on|at|after|before|during|for|from|that|which|who|and|or|"
                       r"the|a|an|their|its|our|your)$", re.I)
_ASKING = re.compile(r"(?:what|which|who|whom|whose|when|where|why|how)\b", re.I)


def _without(question, phrase):
    """The question without the words the data cannot answer, or None."""
    body = _replace(_body(question), phrase, "") if phrase else None
    if not body:
        return None
    # a comparison left without what it compares: "more than 500", or
    # "later than" once "the close of business" is taken out (review of the
    # fixes: "Which products sold later than?")
    body = re.sub(r"\s+(?:more|less|fewer|over|under|above|below)(?:\s+than)?\s+[\d.,]+$",
                  "", body, flags=re.I)
    # the comparison and the words left dangling come off together, until
    # neither is left: the judge quoting "close of business" without its
    # article left "later than the", and "Which products sold later than?"
    # was offered
    while True:
        cut = re.sub(r"\s+(?:\w+er|more|less|fewer|other|rather)\s+than$", "",
                     body.rstrip(" ,;"), flags=re.I)
        cut = _DANGLING.sub("", cut)
        if cut == body:
            break
        body = cut
    # a preposition left before a verb: "At are most sales made"
    body = re.sub(r"^(?:at|in|on|by|for|from|of|with)\s+(?=(?:are|is|was|were|do|does|did)\b)",
                  "", body.strip(" ,;"), flags=re.I)
    body = re.sub(r"^(what|which|who|how)\s+(?=(?:what|which)\b)", "", body, flags=re.I)
    body = body.strip(" ,;")
    # a question that asked "what", "how many" and now asks nothing of the
    # kind is another question ("At what time... made?" -> "Are most sales
    # made?"): none rather than a wrong one
    asked = " ".join(_body(question).split()[:3])
    if len(body.split()) < 3 or (_ASKING.search(asked) and not _ASKING.match(body)):
        return None
    return body[0].upper() + body[1:] + "?"


def _data_items(question, outcome):
    """When the records do not keep what is asked: the nearest question the
    data answers, the words it cannot answer taken out, for the model to
    word; no blank, since nobody can type the missing data in."""
    phrase = getattr(outcome, "phrase", "") or ""
    if phrase and not _in(question, phrase):
        phrase = _asker_words(None, question, outcome) or phrase
    template = _without(question, phrase)
    if not template:
        return [], [], None
    said = _missing_said(outcome)
    return ([{"id": "1", "say": f"the same question without \"{phrase}\", which the data "
                                "does not record",
              "template": template,
              "note": "Without what the data does not record.",
              "drops": _numbers_in(phrase)}],
            [f"the data does not record {said}"] if said else [], None)


def _as_of_items(question, outcome):
    """The question asked of today, when only the current state is kept:
    the point in time taken out, the model asked to say "current"."""
    when = _moment(question)
    body = _replace(_body(question), when, "") if when else None
    if not body:
        return [], [], None
    return ([{"id": "1", "say": "its current value, the only one the data keeps",
              "template": _current(body) + "?", "note": "Only the current value is kept.",
              "drops": _numbers_in(when)}],
            ["only the current value is kept"], None)


def _current(body):
    """The question asked of today: "What was the priority of X" -> "What
    is the current priority of X"; as it was when it has no such verb."""
    m = re.match(r"(?i)(what|which|who)\s+(was|were)\s+(the\s+)?(.*)$", body)
    if not m:
        return body
    verb = "is" if m.group(2).lower() == "was" else "are"
    if m.group(3):
        return f"{m.group(1)} {verb} the current {m.group(4)}"
    return f"{m.group(1)} {verb} {m.group(4)} now"


def _more(clarifier, question, outcome, system, cols, today):
    missing = gap(clarifier, question, outcome)
    words = _asker_words(clarifier, question, outcome)
    if missing in ("threshold", "outside"):
        items, facts, blank = _value_items(clarifier, question, outcome, cols, missing)
    elif missing == "period":
        items, facts, blank = _period_items(clarifier, question, outcome, cols, today)
    elif missing == "as_of":
        items, facts, blank = _as_of_items(question, outcome)
    elif missing == "data":
        items, facts, blank = _data_items(question, outcome)
    else:
        items, facts, blank = _reading_items(clarifier, question, outcome, cols, missing)
    settled = _settle(clarifier, question, words, items, "PROPOSAL", facts, system, cols,
                      model_notes=False, rejudged=True)
    out = [Suggestion(question=text, note=note) for _it, text, note in settled]
    if not blank and out and missing in ("threshold", "outside"):
        # a value the asker holds: the question to edit comes first, the
        # data's own values below it (asked on 23 October), the value of
        # the first proposal left as the blank
        blank = _editable_in(out[0].question, question)
    if blank:
        note = "Replace the part in brackets, then ask."
        if facts:
            note += " " + facts[0].rstrip(".") + "."
        return ([Suggestion(question=blank, blank=True, note=note)] + out)[:MAX_MORE]
    return out[:MAX_MORE]


def _editable_in(text, question):
    """The proposal with its value made a blank: the first number the
    asker did not write (review of 23 October: "Which of the [value]
    products" took the asker's 3), its sign with it."""
    theirs = _numbers_in(question)
    for m in _NUMBER.finditer(str(text or "")):
        if _canon(m.group(0)) in theirs:
            continue
        start = m.start() - 1 if m.start() > 0 and text[m.start() - 1] == "-" else m.start()
        return text[:start] + "[value]" + text[m.end():]
    return None


def suggest(clarifier, question, outcome, *, system=None, today=None):
    """Questions the asker can pick instead of the one they asked.

    One per option for NEEDS A CHOICE, each carrying the option's label;
    two to four for NEEDS MORE, built on the data's own values; none for
    anything else. Never raises: whatever fails, the templates stand, and
    when even they cannot be built the list is empty."""
    kind = needs(outcome)
    if not kind or not str(question or "").strip():
        return []
    cols = _catalogue(clarifier)
    try:
        if kind == "choice":
            return _choice(clarifier, question, outcome, system, cols)
        return _more(clarifier, question, outcome, system, cols,
                     today or datetime.date.today())
    except Exception as e:
        log.info("reformulate: no suggestions (%s: %s)", type(e).__name__, str(e)[:80])
        return []
