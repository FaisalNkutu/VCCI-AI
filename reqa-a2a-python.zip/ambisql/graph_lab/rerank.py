"""Re-sorting what a vector search found, by a model that reads the question
and each candidate together.

Qdrant ranks by how close two embeddings are, each computed on its own: the
question once, every column or past question once, never side by side. It
is fast and it is coarse: "lead time" lands near the CRM's `leads`. A
reranker reads the question and a candidate together and says how well the
one answers the other, which is what the research deck planned as a
post-filter on the vector top-k.

Ollama serves no cross-encoder (no /api/rerank, no /v1/rerank; measured on
0.30.10), so the reranker is what the settings page's Reranker card names,
used the best way it allows:

  a cross-encoder   run inside Datagora with sentence-transformers, such as
  in Datagora       mxbai-rerank-large-v2: the question and each candidate
                    read together by the model, one score each; the one
                    kind that is a reranker by design (CROSS_ENCODERS)
  a rerank server   an endpoint speaking the OpenAI API whose server also
                    answers POST /v1/rerank (llama.cpp --reranking, vLLM,
                    Infinity): a real cross-encoder, one call per search
  an embedding      a model Ollama marks as embedding only, such as
  model             mxbai-embed-large: the question and every candidate
                    embedded in one call, each candidate scored by how
                    close it lands to the question. It does not read the
                    two together; it is a second opinion, from a model
                    trained otherwise, on the first embedding's order
  a language model  any chat model, on Ollama or an OpenAI-shaped server,
                    asked once per search to score every candidate from 0
                    to 10, the reply held to a JSON schema

No endpoint on the role, no reranking: the vector order stands, and nothing
waits on a model that is not there. A reranker that fails, or answers
something unusable, leaves the vector order too; it only ever refines.

Which model is best is measured, not assumed: the settings page tests the
one chosen on known cases when it is set (test()). A language model and a
rerank server score from 0 for unrelated to 1 for exactly it; an embedding
model's closeness has its own scale, so its own bar (keep()).
"""

import json
import math
import os
import threading
import time
import urllib.error
import urllib.request

if __package__:
    from .observability import get_logger
else:
    from observability import get_logger

log = get_logger("rerank")

ROLE = "reranker"

SYSTEM = """You rank candidates for a question asked of a database.

Each candidate is a column, a table or an earlier question, with what is
known about it. Score each one for how directly it holds or answers what
the question asks about:

  10  exactly what the question needs
  7   needed, alongside something else
  4   related, but not what is asked
  0   unrelated, even when it shares a word with the question

A shared word is not relevance: "lead time" is not the CRM's leads. List
the candidates that score 1 or more, by their number, best first; a
candidate you leave out scores 0.

Reply in JSON: {"scores": [{"id": 0, "score": 7}, ...]}"""

REPLY = {"type": "object",
         "properties": {"scores": {"type": "array", "items": {
             "type": "object",
             "properties": {"id": {"type": "integer"},
                            "score": {"type": "integer", "minimum": 0, "maximum": 10}},
             "required": ["id", "score"]}}},
         "required": ["scores"]}

# Known cases the settings page checks a reranker on when it is chosen: the
# first candidate is the right one each time, and a reranker that cannot
# put it first is not worth its time. Taken from what the measured runs got
# wrong without one.
CASES = [
    ("What is the average lead time in days per supplier?",
     ["product_suppliers.lead_time_days: days between order and delivery, per supplier",
      "leads.source: where a sales lead came from (CRM)",
      "suppliers.rating: a score given to the supplier",
      "warehouses.city: the city a warehouse is in"]),
    ("How many containers did each vessel carry?",
     ["sea_shpmnt.container_count: number of containers on the sea shipment",
      "inventory.quantity_on_hand: units in stock in a warehouse",
      "trucks.capacity: how much a truck can carry",
      "events.duration_minutes: how long an event lasted"]),
    ("Which members have unpaid fines?",
     ["loans.fine_amount: the fine owed on a late loan, 0 when paid",
      "members.full_name: the member's name",
      "books.price: what a book cost",
      "invoices.amount: the amount of a supplier invoice"]),
]

# An embedding model as reranker: what its question is prefixed with, the
# instruction it was trained with for a search, and the closeness from
# which a candidate counts. Measured on the Warehouse corpus, 25 questions,
# the 10 closest by nomic-embed-text re-scored by mxbai-embed-large: at
# 0.65, every needed table for 12 (4 by nomic's bar alone), none for 9,
# never only wrong ones, 0.5 s a question; 0.60 found 15 with three times
# the extra tables, 0.70 found 5. A model not measured keeps the corpus's
# own bar (recall.MIN_SCORE).
EMBED_QUERY = (("mxbai-embed", "Represent this sentence for searching relevant passages: "),)
EMBED_KEEP = (("mxbai-embed", 0.65),)
EMBED_KEEP_DEFAULT = 0.72

# A cross-encoder run inside Datagora with sentence-transformers: the
# question and one candidate read together by the model, one score out.
# Ollama cannot run one: it has no rerank route, and mxbai-rerank-v2 is
# scored through its logits, which Ollama does not hand out. The image
# holds the weights (Dockerfile), so the container loads them without the
# internet; on a laptop sentence-transformers fetches them once.
# mxbai-rerank-large-v2: Mixedbread (Germany), Apache 2.0, 1.5 billion
# parameters built on Qwen2.5, chosen by the user on 6 October 2026.
CROSS_ENCODERS = ("mixedbread-ai/mxbai-rerank-large-v2",)
CROSS_KEEP = (("mxbai-rerank", 0.5),)
CROSS_KEEP_DEFAULT = 0.5
# Where it runs: chosen on the Reranker card (DATAGORA_RERANKER_DEVICE),
# "cpu", "cuda:0", "cuda:1"..., empty for the first GPU when there is one.
# On a GPU in float16 and in batches of 8: mxbai-rerank-large-v2 then needs
# about 3.1 GB of weights, 0.5 GB for CUDA and up to 1.2 GB for the logits
# of a batch (127 tokens a pair in the median, 237 at most, a vocabulary of
# 151,936), some 5 GB, which an 8 GB card holds when no other model is on
# it; batches of 32 would take 6 to 8 GB. On the CPU in float32: its
# weights' bfloat16 is emulated on most CPUs and was slower still.
GPU_BATCH = 8
MAX_PAIR_TOKENS = 256
_ENCODERS = {}
_LOADING = threading.Lock()         # each model loaded once
_SCORING = threading.Lock()         # one batch at a time: the CPU is shared,
                                    # and two at once each take twice as long


def _by_model(table, model, default):
    name = str(model or "").lower()
    return next((value for marker, value in table if marker in name), default)


def _post(url, body, timeout):
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read())


class InDatagora:
    """What a cross-encoder run here stands on instead of an endpoint: no
    server, only the model's name."""
    api = "local"
    url = ""
    timeout = 0

    def __init__(self, model, device=""):
        self.model = model
        self.device = str(device or "").strip()
        self.name = "in Datagora" + (f", {self.device}" if self.device else "")
        self.last_error = ""


def devices():
    """{"gpus": [{id, name, vram_gb}], "cuda": bool}: the GPUs of the
    machine Datagora runs on, as nvidia-smi lists them, and whether the
    torch installed here can use them (a CPU build cannot, whatever the
    machine holds). Neither torch nor a GPU is touched to find out."""
    import importlib.metadata
    import shutil
    import subprocess
    gpus = []
    smi = shutil.which("nvidia-smi")
    if smi:
        try:
            listing = subprocess.run(
                [smi, "--query-gpu=index,name,memory.total", "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=10).stdout
            for line in listing.splitlines():
                index, name, mib = [p.strip() for p in line.split(",")[:3]]
                gpus.append({"id": f"cuda:{index}", "name": name,
                             "vram_gb": round(int(mib) / 1024, 1)})
        except (OSError, ValueError, subprocess.SubprocessError):
            pass
    try:
        cuda = "+cpu" not in importlib.metadata.version("torch")
    except importlib.metadata.PackageNotFoundError:
        cuda = False
    return {"gpus": gpus, "cuda": cuda}


def cross_encoders():
    """[{name, installed, cached}]: the cross-encoders Datagora can run,
    whether sentence-transformers is there to run them and whether the
    weights already are (the image holds them; elsewhere they are fetched
    on first use)."""
    # looked for, not imported: importing it brings torch, seconds and
    # hundreds of MB, which only the first real scoring should pay
    import importlib.util
    installed = importlib.util.find_spec("sentence_transformers") is not None
    out = []
    for name in CROSS_ENCODERS:
        cached = False
        if installed:
            try:
                from huggingface_hub import try_to_load_from_cache
                cached = isinstance(try_to_load_from_cache(name, "config.json"), str)
            except Exception:
                pass
        out.append({"name": name, "installed": installed, "cached": cached})
    return out


def embedding_server():
    """The embedding model's server, where a reranker that is an embedding
    model (mxbai-embed-large) is looked for when no server is named for
    it: as the .env names it, else as the settings page sets it; "" when
    neither does. The settings page's card and its test read it here too,
    so they look where the questions will."""
    try:
        if __package__:
            from .db_profile import environment
            from .settings_store import load
        else:
            from db_profile import environment
            from settings_store import load
        env = environment()
        for name in ("DATAGORA_EMBED_URL", "DATAGORA_OLLAMA_URL", "OLLAMA_URL"):
            value = str(env.get(name) or "").strip().strip("\"'").strip()
            if value:
                return value
        return str(((load().get("services") or {}).get("embedding") or {}).get("url") or "").strip()
    except Exception:
        return ""


def _encoder(name, device=""):
    """The cross-encoder on its device, loaded on first use and kept:
    loading takes seconds, scoring a few candidates less. One at a time:
    another model or device chosen frees the memory of the one before."""
    with _LOADING:
        key = (name, device)
        if key not in _ENCODERS:
            import torch
            from sentence_transformers import CrossEncoder
            started = time.monotonic()
            if device in ("", "gpu"):
                device = "cuda:0" if torch.cuda.is_available() else "cpu"
            for old in list(_ENCODERS):
                del _ENCODERS[old]
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            # max_length: Datagora's pairs, the question and a column or an
            # earlier question in mxbai's template, measured 127 tokens in
            # the median and 237 at most; 256 cuts none and bounds a column
            # whose description runs on
            kwargs = {"device": device, "max_length": MAX_PAIR_TOKENS, "model_kwargs": {
                "dtype": torch.float16 if device.startswith("cuda") else torch.float32}}
            try:
                # on the disk already, in the image or since a first load:
                # read from there, the internet never asked again, not
                # even whether a newer version exists
                _ENCODERS[key] = CrossEncoder(name, local_files_only=True, **kwargs)
            except Exception:
                log.info("cross-encoder %s is not on this machine: fetched once", name)
                _ENCODERS[key] = CrossEncoder(name, **kwargs)
            log.info("cross-encoder %s loaded on %s in %.1f s", name, device,
                     time.monotonic() - started)
        return _ENCODERS[key]


def _vram(device, reset=False):
    """GB of GPU memory torch has held at most on `device` since the last
    reset, or None off a GPU."""
    if not str(device or "").startswith("cuda"):
        return None
    try:
        import torch
        if reset:
            torch.cuda.reset_peak_memory_stats(device)
            return None
        return round(torch.cuda.max_memory_allocated(device) / 1e9, 2)
    except Exception:
        return None


class Reranker:
    """One endpoint playing the reranker role; see the module."""

    def __init__(self, model, device=""):
        self.model = model
        # "cpu" or "gpu", as the Reranker card says (DATAGORA_RERANKER_DEVICE):
        # an Ollama model asked to stay off the GPU (num_gpu 0), a
        # cross-encoder loaded on the CPU or on a GPU
        self.device = str(device or "").strip().lower()
        self.kind = None            # "rerank", "embed" or "chat", once known

    @classmethod
    def configured(cls):
        """The reranker the settings page chose, or None.

        The Reranker card first: a server and a model, which the page
        writes as DATAGORA_RERANKER_URL and DATAGORA_RERANKER_MODEL and the
        .env may set as well; without a server, the embedding model's
        (the same Ollama, most often). Then an endpoint given the reranker
        role. Unlike the other roles, none means none at all, never the
        first endpoint."""
        try:
            if __package__:
                from .db_profile import environment
                from .llm import LLM, host_gateway, models_data
            else:
                from db_profile import environment
                from llm import LLM, host_gateway, models_data
            env = environment()

            def first(*names):
                for n in names:
                    value = str(env.get(n) or "").strip().strip("\"'").strip()
                    if value:
                        return value
                return ""

            # switched off on the card (or DATAGORA_RERANKER=off): none at
            # all, whatever model or endpoint is named
            if first("DATAGORA_RERANKER").lower() in ("false", "off", "0", "no"):
                return None
            model = first("DATAGORA_RERANKER_MODEL")
            if model in CROSS_ENCODERS:
                # run here, whatever server is named: none can serve it
                return cls(InDatagora(model, first("DATAGORA_RERANKER_DEVICE")),
                           first("DATAGORA_RERANKER_DEVICE"))
            url = first("DATAGORA_RERANKER_URL") or embedding_server()
            if model and url:
                return cls(LLM(ROLE, {"api": first("DATAGORA_RERANKER_API") or "ollama",
                                      "url": host_gateway(url), "model": model,
                                      "num_ctx": 8192, "timeout": 120}),
                           first("DATAGORA_RERANKER_DEVICE"))
            ids = (models_data().get("pools") or {}).get(ROLE) or []
            return cls(LLM.load(ids[0])) if ids else None
        except (Exception, SystemExit) as e:
            log.info("reranker off: %s", str(e)[:90])
            return None

    @property
    def name(self):
        return f"{getattr(self.model, 'name', '?')} ({getattr(self.model, 'model', '?')})"

    def rank(self, query, documents):
        """[(index, score)] for the documents, best first, score from 0 to 1;
        None when the reranker could not say, and the caller keeps its own
        order."""
        documents = [str(d) for d in documents]
        if not documents:
            return []
        if getattr(self.model, "api", "") == "local":
            self.kind = "cross"
            return self._cross(query, documents)
        if self.kind is None and getattr(self.model, "api", "") == "ollama" \
                and self._embeds_only():
            self.kind = "embed"
        if self.kind == "embed":
            return self._embed(query, documents)
        if self.kind in (None, "rerank") and getattr(self.model, "api", "") == "openai":
            out = self._rerank_api(query, documents)
            if out is not None:
                self.kind = "rerank"
                return out
        self.kind = "chat"
        return self._chat(query, documents)

    def _rerank_api(self, query, documents):
        """POST /v1/rerank, the shape llama.cpp, vLLM, Infinity, Jina and
        Cohere share. None when the server has no such endpoint."""
        body = {"model": self.model.model, "query": query, "documents": documents,
                "top_n": len(documents)}
        req = urllib.request.Request(
            self.model.url.rstrip("/") + "/v1/rerank", data=json.dumps(body).encode("utf-8"),
            headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=getattr(self.model, "timeout", 60)) as r:
                data = json.loads(r.read())
        except (urllib.error.URLError, OSError, ValueError):
            return None
        results = data.get("results") if isinstance(data, dict) else None
        if not isinstance(results, list):
            return None
        out = []
        for item in results:
            try:
                score = float(item.get("relevance_score", item.get("score")))
                # a probability already, or a raw logit some servers return
                out.append((int(item["index"]),
                            score if 0.0 <= score <= 1.0 else 1 / (1 + math.exp(-score))))
            except (KeyError, TypeError, ValueError):
                continue
        return sorted(out, key=lambda x: -x[1]) or None

    def keep(self, default):
        """The score from which a candidate counts: `default`, on the 0 to 1
        scale a language model and a rerank server answer on, or for an
        embedding model its own measured bar (EMBED_KEEP)."""
        if self.kind == "embed":
            return _by_model(EMBED_KEEP, self.model.model, EMBED_KEEP_DEFAULT)
        if self.kind == "cross":
            return _by_model(CROSS_KEEP, self.model.model, CROSS_KEEP_DEFAULT)
        return default

    def _cross(self, query, documents):
        """Each (question, candidate) pair read whole by the cross-encoder;
        a score from 0 to 1 (a raw logit is squashed)."""
        try:
            encoder = _encoder(self.model.model, getattr(self.model, "device", ""))
            # where it really runs, the automatic choice resolved
            self.model.device = str(getattr(encoder, "device", "") or self.model.device)
            with _SCORING:
                raw = encoder.predict(
                    [(query, d) for d in documents], show_progress_bar=False,
                    batch_size=GPU_BATCH if self.model.device.startswith("cuda") else 32)
        except Exception as e:
            self.model.last_error = f"{type(e).__name__}: {e}"[:300]
            log.info("reranker %s could not score: %s", self.name, self.model.last_error)
            return None
        scores = []
        for i, s in enumerate(raw):
            s = float(s)
            scores.append((i, s if 0.0 <= s <= 1.0 else 1 / (1 + math.exp(-s))))
        return sorted(scores, key=lambda x: -x[1])

    def _embeds_only(self):
        """Whether Ollama says the model embeds and cannot chat."""
        try:
            caps = _post(self.model.url.rstrip("/") + "/api/show", {"model": self.model.model},
                         timeout=min(getattr(self.model, "timeout", 30), 30)).get("capabilities") or []
        except (urllib.error.URLError, OSError, ValueError, AttributeError):
            return False
        return "embedding" in caps and "completion" not in caps

    def _embed(self, query, documents):
        """The candidates scored by their closeness to the question, all
        embedded in one call."""
        prefix = _by_model(EMBED_QUERY, self.model.model, "")
        body = {"model": self.model.model, "input": [prefix + query] + documents}
        if self.device == "cpu":
            # kept off the GPU: the same scores (measured, mxbai-embed-large
            # on the 25 Warehouse questions, 12 complete either way), 1.7 s a
            # question on a CPU against 0.5 on a Tesla, and the GPU left
            # whole to the model that judges
            body["options"] = {"num_gpu": 0}
        try:
            vectors = _post(self.model.url.rstrip("/") + "/api/embed", body,
                            timeout=getattr(self.model, "timeout", 60)).get("embeddings")
        except (urllib.error.URLError, OSError, ValueError, AttributeError) as e:
            log.info("reranker %s did not embed: %s", self.name, str(e)[:90])
            return None
        if not isinstance(vectors, list) or len(vectors) != len(documents) + 1:
            return None

        def norm(v):
            return math.sqrt(sum(x * x for x in v)) or 1.0

        q, qn = vectors[0], norm(vectors[0])
        scores = [sum(a * b for a, b in zip(q, v)) / (qn * norm(v)) for v in vectors[1:]]
        return sorted(enumerate(scores), key=lambda x: -x[1])

    def _chat(self, query, documents):
        """The candidates scored by a language model, in one call."""
        user = (f"Question: {query}\n\nCandidates:\n"
                + "\n".join(f"[{i}] {d}" for i, d in enumerate(documents)))
        reply = self.model.json(SYSTEM, user, schema=REPLY)
        scores = (reply or {}).get("scores") if isinstance(reply, dict) else None
        if not isinstance(scores, list):
            log.info("reranker %s gave no scores: %s", self.name,
                     getattr(self.model, "last_error", "") or "unreadable reply")
            return None
        seen = {}
        for item in scores:
            try:
                i, s = int(item["id"]), float(item["score"])
            except (KeyError, TypeError, ValueError):
                continue
            if 0 <= i < len(documents):
                seen[i] = max(0.0, min(1.0, s / 10))
        if not seen:
            return None
        # a candidate the model skipped is taken as unrelated
        return sorted(((i, seen.get(i, 0.0)) for i in range(len(documents))),
                      key=lambda x: -x[1])

    def test(self):
        """The known cases, as the settings page shows them: whether the right
        candidate came first each time, how far ahead, and how long it took."""
        cases, ok = [], True
        started = time.monotonic()
        for query, documents in CASES:
            t0 = time.monotonic()
            ranked = self.rank(query, documents)
            seconds = round(time.monotonic() - t0, 2)
            if not ranked:
                ok = False
                cases.append({"question": query, "ok": False, "seconds": seconds,
                              "error": getattr(self.model, "last_error", "") or "no scores"})
                continue
            first, best = ranked[0]
            right = dict(ranked).get(0, 0.0)
            runner_up = max((s for i, s in ranked if i != 0), default=0.0)
            good = first == 0 and right > runner_up
            ok = ok and good
            cases.append({"question": query, "ok": good, "seconds": seconds,
                          "first": documents[first].split(":")[0],
                          "expected": documents[0].split(":")[0],
                          "margin": round(right - runner_up, 2)})
        out = {"ok": ok, "endpoint": getattr(self.model, "name", ""),
               "model": getattr(self.model, "model", ""), "kind": self.kind,
               "seconds": round(time.monotonic() - started, 2), "cases": cases}
        if self.kind == "cross":
            # where it ran and, on a GPU, the most memory it held: what the
            # card needs to keep free for it
            out["device"] = getattr(self.model, "device", "") or "cpu"
            out["vram_gb"] = _vram(out["device"])
        return out


def rerank(query, candidates, text=lambda c: c, reranker=None):
    """`candidates` re-sorted by the configured reranker, each with its
    score: [(candidate, score)]. The vector order, every score None, when
    there is no reranker or it could not say. `text` gives what the model
    reads of a candidate."""
    candidates = list(candidates)
    reranker = reranker if reranker is not None else Reranker.configured()
    if reranker is None or not candidates:
        return [(c, None) for c in candidates]
    if __package__:
        from .observability import step
    else:
        from observability import step
    with step("rerank", as_type="retriever",
              input={"question": query, "candidates": len(candidates),
                     "reranker": reranker.name}) as traced:
        ranked = reranker.rank(query, [text(c) for c in candidates])
        if not ranked:
            traced.update(output={"reranked": False})
            return [(c, None) for c in candidates]
        out = [(candidates[i], s) for i, s in ranked]
        traced.update(output={"reranked": True, "kind": reranker.kind,
                              "top": [f"{text(c)[:60]} {s:.2f}" for c, s in out[:8]]})
        return out
