"""The real verdict of a question labelled somewhere, for a saved run whose
own file does not carry it, so its accuracy can be shown too.

A developer's aid. The files that carry a real verdict are the bench's:
the question lists of src/graph_lab/examples, then those of the coverage
folder (<run>.questions.csv and the like). A question is found by its
words, whatever its case, spacing or punctuation; the first file that
labels it wins, so the answer key in examples overrides an older copy, and
two different verdicts for one question in the same file label none. The
questions of a production database match none of these files, and its
runs show nothing more.
"""

import csv
import re
from pathlib import Path

# the column of a real verdict, by its name now and before
COLUMNS = ("real_verdict", "expected")
EXAMPLES = Path(__file__).resolve().parent / "examples"


def key(question):
    """The words of a question, lower case, nothing else."""
    return " ".join(re.findall(r"[0-9a-z]+", str(question or "").lower()))


def read(path):
    """{key: (real verdict, also accepted)} of one question file, {} when it
    has no question or no real verdict column, or cannot be read."""
    try:
        with open(path, encoding="utf-8-sig", newline="") as fh:
            reader = csv.DictReader(fh)
            fields = reader.fieldnames or []
            column = next((c for c in COLUMNS if c in fields), None)
            if "question" not in fields or column is None:
                return {}
            found, clash = {}, set()
            for row in reader:
                k = key(row.get("question"))
                real = " ".join(str(row.get(column) or "").replace("_", " ").split()).upper()
                if not k or not real:
                    continue
                if k in found and found[k][0] != real:
                    clash.add(k)
                found.setdefault(k, (real, str(row.get("also_accepted") or "")))
    except (OSError, csv.Error, UnicodeDecodeError):
        return {}
    for k in clash:
        found.pop(k, None)
    return found


def sources(coverage_dir):
    """The files read, in order: the examples' question lists, then the
    question lists of the coverage folder."""
    files = sorted(EXAMPLES.glob("questions_*.csv"))
    if coverage_dir:
        files += sorted(Path(coverage_dir).glob("*.questions.csv"))
    return files


_cache = {}

# the databases each example list was written for, by the names a profile
# or a schema may give them
EXAMPLE_DATABASES = {"library": ("library", "datagora_lib"),
                     "products": ("warehouse", "products", "datagora_generic"),
                     "enterprise": ("enterprise", "datagora_ent", "datagora_enterprise")}


def database_of(path):
    """The names of the database a question file was written for: an
    example list by its name, a run's questions by its manifest's profile;
    () when nothing says."""
    path = Path(path)
    if path.parent == EXAMPLES and path.stem.startswith("questions_"):
        name = path.stem[len("questions_"):]
        return EXAMPLE_DATABASES.get(name, (name,))
    if path.name.endswith(".questions.csv"):
        stem = path.name[:-len(".questions.csv")]
        try:
            import json
            manifest = json.loads((path.parent / f"{stem}.csv.job.json").read_text(encoding="utf-8"))
            return (str(manifest.get("profile") or "").lower(),) if manifest.get("profile") else ()
        except (OSError, ValueError):
            return ()
    return ()


def known(coverage_dir, database=None):
    """{key: {"real_verdict", "also_accepted", "real_from"}}, read again
    only when one of the files changed.

    A question takes the key of `database`'s own list first; none when
    every list that holds it is another known database's (review of 26
    October: "How many products are there in each category?" took
    another database's answer key); else the key all its lists agree on;
    else the examples', when they agree, over a run's older list."""
    entries = _entries(coverage_dir)
    wanted = str(database or "").lower()
    found = {}
    for k, options in entries.items():
        mine = [e for e in options if wanted and wanted in e["databases"]]
        if mine:
            chosen = mine[0]
        else:
            # for a known database, only the lists that name none: another
            # database's key came through as soon as an old list without a
            # database disagreed with it (review of the fixes)
            pool = [e for e in options if not e["databases"]] if wanted else options
            examples = [e for e in pool if e["example"]]
            if pool and len({e["real_verdict"] for e in pool}) == 1:
                chosen = pool[0]
            elif examples and len({e["real_verdict"] for e in examples}) == 1:
                chosen = examples[0]
            else:
                continue
        found[k] = {n: chosen[n] for n in ("real_verdict", "also_accepted", "real_from")}
    return found


def _entries(coverage_dir):
    """{key: [entry, ...]} of every file, each with the databases it was
    written for, read again only when one of the files changed."""
    files = sources(coverage_dir)
    stamp = []
    for path in files:
        try:
            stamp.append((str(path), path.stat().st_mtime))
        except OSError:
            continue
    stamp = tuple(stamp)
    cached = _cache.get(str(coverage_dir))
    if cached and cached[0] == stamp:
        return cached[1]
    found = {}
    for path, _mtime in stamp:
        databases = database_of(path)
        for k, (real, also) in read(path).items():
            found.setdefault(k, []).append({"real_verdict": real, "also_accepted": also,
                                            "real_from": Path(path).name,
                                            "databases": databases,
                                            "example": Path(path).parent == EXAMPLES})
    _cache[str(coverage_dir)] = (stamp, found)
    return found


# the verdicts a run decides; anything else (UNKNOWN) is no verdict
VERDICTS = ("ANSWERABLE", "NEEDS A CHOICE", "NEEDS MORE", "NOT COVERED", "NO DATA")


def _norm(value):
    return " ".join(str(value or "").replace("_", " ").split()).upper()


def own(rows):
    """Whether a run's rows carry their real verdicts themselves: a value
    that is a verdict, not any text of a column named expected."""
    return any(_norm(r.get(c)) in VERDICTS for r in rows for c in COLUMNS)


def score(rows, found=None):
    """A run's rows against their real verdicts, their own column first,
    else `found` (known): {"right", "scored", "unknown", "unlabelled",
    "accuracy"}, a verdict listed in also_accepted counting as right and
    UNKNOWN left out of the share; None when no row has a real verdict."""
    mine = own(rows)
    right = scored = unknown = unlabelled = 0
    for r in rows:
        if mine:
            real, also = r.get("real_verdict") or r.get("expected"), r.get("also_accepted")
        else:
            got = (found or {}).get(key(r.get("question"))) or {}
            real, also = got.get("real_verdict"), got.get("also_accepted")
        real = _norm(real)
        if real not in VERDICTS:
            # an `expected` column holding the expected answer ("42") is no
            # label: it read as one, and such a file scored 0 % (review of
            # 26 October)
            unlabelled += 1
            continue
        verdict = _norm(r.get("verdict"))
        if verdict not in VERDICTS:
            unknown += 1
            continue
        scored += 1
        if verdict == real or verdict in {_norm(a) for a in re.split(r"[|;,]", str(also or ""))}:
            right += 1
    if not scored and not unknown:
        return None
    return {"right": right, "scored": scored, "unknown": unknown, "unlabelled": unlabelled,
            "accuracy": right / scored if scored else None}


def fill(verdicts, found):
    """Give each verdict without one the real verdict found for its
    question, in its `extra`; returns how many were given one. A run that
    carries its own real verdicts is never touched."""
    # its own labels only when they are verdicts, as own() reads them: an
    # expected answer ("1200") left the run unlabelled here and scored there
    # (review of the fixes)
    if any(_norm((v.get("extra") or {}).get(c)) in VERDICTS for v in verdicts for c in COLUMNS):
        return 0
    given = 0
    for v in verdicts:
        got = found.get(key(v.get("question")))
        if got:
            v.setdefault("extra", {}).update(got)
            given += 1
    return given
