"""The one place a deployment's configuration lives, when the page writes it.

Configuration used to arrive from four places at once, the environment, a
repository `.env`, a profiles file and a models file, each with a default,
and which one won depended on a precedence rule nobody could see. One
deployment ran an hour against a development server because every one of
those sources had quietly fallen back to its demo value.

This module is the replacement for that, and it is deliberately boring: one
JSON file in a volume, written by the settings page, read by the page, the
engine, the command line and the library alike. When the file does not
exist, nothing here changes anything, and the older sources behave exactly
as they always have. That is what keeps a clone of the repository and an
existing deployment working while a new one is configured from the page.

What it holds:

    endpoints   model servers: where, which model, context window, how many
                requests at once, how much VRAM the GPU behind it has
    roles       which endpoints play which part, as a POOL. Two endpoints on
                the reasoner role is how questions are spread over two GPUs
    databases   one entry per database the page offers, with its account
    services    Neo4j, Qdrant and Langfuse, each optional
    engine      the tunables that used to be environment variables
    presets     named snapshots of the model side, black-jack style
    admin       the settings password and the session secret

Secrets never leave the server in clear. Reading returns whether each one
is set; writing an empty value keeps the one already stored.
"""

import base64
import copy
import hashlib
import hmac
import json
import os
import re
import secrets
import tempfile
import threading
import time
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
VERSION = 1

# the fields that are secrets, wherever they sit. Listed once, so reading
# can mask every one of them and writing can keep every one of them.
SECRET_KEYS = {"password", "api_key", "secret_key"}

ROLES = ("reasoner", "sql")

DEFAULTS = {
    "version": VERSION,
    "endpoints": [],
    "roles": {"reasoner": [], "sql": []},
    "databases": [],
    "services": {
        "neo4j": {"uri": "", "user": "neo4j", "password": ""},
        # min_score: how close an answered question must be for its tables
        # to be used; empty follows the embedding model (0.72 for nomic,
        # 0.80 for e5, recall.MIN_SCORES)
        "qdrant": {"url": "", "api_key": "", "min_score": ""},
        # the model that turns a question into a vector for the corpus;
        # without it a corpus is never searched
        "embedding": {"url": "", "model": ""},
        # the model that re-reads the corpus's close questions for Ask
        # (rerank.py). On by default, the store of an older version
        # included, which has no such entry: mxbai-embed-large on the
        # embedding model's server unless a server is named. Measured on
        # the Warehouse corpus: every needed table found for 12 questions
        # of 25 against 4 without, never only wrong ones. An empty model,
        # chosen on the page as None, turns it off. On the CPU by default:
        # the same scores as on a GPU, under two seconds a question, and
        # the GPU left whole to the model that judges.
        # `enabled`, the card's switch: off, the reranker is not used at
        # all, and the model chosen stays for when it is switched back on
        "reranker": {"enabled": True, "url": "", "model": "mxbai-embed-large", "device": "cpu"},
        "langfuse": {"base_url": "", "public_key": "", "secret_key": ""},
    },
    "engine": {
        "ask_values": True,
        # a question the asker must settle (a choice, or more to say) comes
        # back with whole questions to pick from; off, the page shows the
        # clarifier's readings as before and no model call is made for it
        "reformulate": True,
        "schema_samples": 5,
        "sample_values": 30,
        "enumeration": 12,
        "kv_cache_type": "f16",
        # the column index for coverage, and how far a column must stand
        # out of the rest to count; empty is the engine's default, 3.4
        "column_index": True,
        "column_min_z": "",
        # the coverage judge: the single call and its checks, or the agent
        # that explores the database. Empty means the environment's value,
        # then the engine's default, so a test instance started with
        # DATAGORA_JUDGE=agent is not overruled by a store that never chose
        "judge_mode": "",
        # the judge of the Ask page, the same choice for one question at a
        # time; empty means DATAGORA_ASK_JUDGE, then the agent
        "ask_judge": "",
        "agent_max_turns": "",
        "agent_max_seconds": "",
        "agent_think": "",
        "agent_sql_seconds": "",
        "agent_result_tokens": "",
        "agent_choice_tolerance": "",
        "agent_same_result": "",
        "agent_arbiter": "",
    },
    "presets": [],
    "admin": {"password_hash": "", "session_secret": ""},
}

_lock = threading.RLock()


# ------------------------------------------------------------ the file
def data_dir():
    """Where the store lives: DATAGORA_DATA_DIR, or ./data beside the repo."""
    named = os.environ.get("DATAGORA_DATA_DIR")
    return Path(named) if named else HERE.parent.parent / "data"


def store_path():
    return data_dir() / "datagora.json"


# the files dropped on the page, a data dictionary or a vocabulary, kept
# beside the store. Named relative to the data folder, so the one store
# serves the laptop (./data) and the container (/data, the same folder).
FILES = "files"


def keep_file(database, kind, content):
    """Write a dropped file for one database; the name the store records."""
    folder = data_dir() / FILES
    folder.mkdir(parents=True, exist_ok=True)
    safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in str(database))
    name = f"{safe or 'database'}.{kind}.json"
    fd, tmp = tempfile.mkstemp(dir=str(folder), prefix=".upload.", suffix=".json")
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        json.dump(content, fh, indent=1, ensure_ascii=False)
    os.replace(tmp, folder / name)
    return f"{FILES}/{name}"


def file_path(named):
    """A file the store names, as a path that exists where this runs.

    A file the page kept is relative to the data folder; anything else, a
    path typed by hand or given by a .env, is returned unchanged for the
    usual search."""
    if named and not Path(named).is_absolute():
        kept = data_dir() / named
        if kept.exists():
            return str(kept)
    return named


def exists():
    """True when a deployment has configured itself from the page."""
    try:
        raw = _read_raw()
    except (OSError, ValueError):
        return False
    return bool(raw.get("endpoints") or raw.get("databases"))


def _read_raw():
    path = store_path()
    if not path.is_file():
        return {}
    return json.loads(path.read_text(encoding="utf-8") or "{}")


def _merged(raw):
    """The stored document with every missing key filled from DEFAULTS.

    A file written by an older build, or edited by hand, must still load:
    a missing section is an empty section, never an exception."""
    out = copy.deepcopy(DEFAULTS)
    for key, value in (raw or {}).items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            for k, v in value.items():
                if isinstance(v, dict) and isinstance(out[key].get(k), dict):
                    out[key][k] = {**out[key][k], **v}
                else:
                    out[key][k] = v
        else:
            out[key] = value
    if isinstance(out.get("endpoints"), list):
        out["endpoints"], out["roles"] = _distinct_ids(out["endpoints"], out.get("roles"))
    return out


def load():
    """The whole document, secrets included. Server side only."""
    with _lock:
        try:
            return _merged(_read_raw())
        except (OSError, ValueError):
            # an unreadable file is reported by the page, not raised into a
            # request: the settings screen is exactly where it gets fixed
            return copy.deepcopy(DEFAULTS)


def save(doc):
    """Write atomically: a crash mid-write leaves the previous file whole.

    Written to a temporary file in the same directory and renamed over the
    old one, which is atomic on every filesystem this runs on. Mode 0600,
    because the file holds database passwords."""
    with _lock:
        directory = data_dir()
        directory.mkdir(parents=True, exist_ok=True)
        doc = dict(doc)
        doc["version"] = VERSION
        fd, tmp = tempfile.mkstemp(dir=str(directory), prefix=".datagora.",
                                   suffix=".json")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(doc, fh, indent=2, ensure_ascii=False)
                fh.write("\n")
            try:
                os.chmod(tmp, 0o600)
            except OSError:
                pass          # Windows has no POSIX modes; the rename stands
            # On Windows a file just written is often held for a moment by
            # the antivirus or the indexer, and replacing it then fails with
            # a permission error. One run of this suite failed that way and
            # twelve after it did not. The rename is atomic when it happens;
            # it is simply given a few chances to happen.
            for attempt in range(6):
                try:
                    os.replace(tmp, store_path())
                    break
                except PermissionError:
                    if attempt == 5:
                        raise
                    time.sleep(0.05 * (attempt + 1))
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise
    apply_to_environment(doc)
    return doc


# ------------------------------------------------------------- secrets
def _walk(node, fn, path=()):
    if isinstance(node, dict):
        return {k: _walk(v, fn, path + (k,)) for k, v in node.items()}
    if isinstance(node, list):
        return [_walk(v, fn, path + (str(i),)) for i, v in enumerate(node)]
    return fn(path, node)


def redacted(doc=None):
    """The document as the browser may see it.

    Every secret becomes an empty string, and a sibling `<key>_set` says
    whether one is stored. The admin section is left out entirely: the
    browser has no use for a password hash or the session secret."""
    doc = copy.deepcopy(doc if doc is not None else load())
    doc.pop("admin", None)

    def mask(node):
        if isinstance(node, dict):
            out = {}
            for k, v in node.items():
                if k in SECRET_KEYS and not isinstance(v, (dict, list)):
                    out[k] = ""
                    out[f"{k}_set"] = bool(v)
                else:
                    out[k] = mask(v)
            return out
        if isinstance(node, list):
            return [mask(v) for v in node]
        return node

    return mask(doc)


def _keep_secrets(incoming, current):
    """Carry stored secrets across a save that did not change them.

    The page never has the secrets, so it sends empty strings for them. An
    empty secret therefore means "unchanged", and the stored one is kept.
    Lists are matched by `id`, or `name` for databases, never by position:
    deleting the first database must not hand its password to the second.
    """
    if isinstance(incoming, dict) and isinstance(current, dict):
        out = {}
        for k, v in incoming.items():
            if k.endswith("_set"):
                continue
            if k in SECRET_KEYS and not isinstance(v, (dict, list)):
                out[k] = v if v else current.get(k, "")
            else:
                out[k] = _keep_secrets(v, current.get(k))
        return out
    if isinstance(incoming, list) and isinstance(current, list):
        def ident(item):
            if isinstance(item, dict):
                return item.get("id") or item.get("name")
            return None
        by_id = {ident(c): c for c in current if ident(c) is not None}
        return [_keep_secrets(v, by_id.get(ident(v))) for v in incoming]
    return incoming


def update(section, value):
    """Replace one section, keeping every secret the page did not change."""
    if section not in DEFAULTS or section in ("admin", "version", "presets"):
        raise KeyError(f"not a settings section: {section!r}")
    if section == "services":
        _check_min_score(value)
        value = {name: ({k: unquote(v) if k in UNQUOTED else v for k, v in fields.items()}
                        if isinstance(fields, dict) else fields)
                 for name, fields in (value or {}).items()}
    if section == "engine":
        _check_min_z(value)
        _check_agent(value)
    with _lock:
        doc = load()
        if section == "engine":
            # a page from before the judge settings sends the engine without
            # them; the ones it does not send are kept, not reset
            value = {**(doc.get("engine") or {}), **(value or {})}
        doc[section] = _keep_secrets(value, doc.get(section))
        if section == "endpoints":
            doc["endpoints"] = [_normalise_endpoint(e) for e in doc["endpoints"]]
            doc["endpoints"], doc["roles"] = _distinct_ids(doc["endpoints"], doc.get("roles"))
            # a role pointing at an endpoint that no longer exists would
            # route questions nowhere; it is pruned rather than kept
            known = {e["id"] for e in doc["endpoints"]}
            doc["roles"] = {r: [i for i in ids if i in known]
                            for r, ids in doc.get("roles", {}).items()}
        return save(doc)


# fields that never hold a quote: an address or a key copied from a .env,
# where they are often written "between quotes", keeps one by accident and
# fails with a 401 that says nothing about why. A password may hold one.
UNQUOTED = {"uri", "url", "base_url", "api_key", "public_key", "secret_key"}


def unquote(value):
    if not isinstance(value, str):
        return value
    return value.strip().strip("\"'").strip()


# what each judge setting may hold; empty always means "the default". The
# agent reads them with verdict_tools.Settings, which keeps its default in
# silence for a value it cannot read, so a value is refused here, where the
# person sees why, unless Settings would use exactly that value
_AGENT_CHOICES = {"judge_mode": ("single", "agent"),
                  "ask_judge": ("single", "agent"),
                  "agent_think": ("all", "plan_conclude", "none"),
                  "agent_same_result": ("answer", "choice"),
                  "agent_arbiter": ("off", "vote")}
# whole numbers: "2.5" or "1e3" is no int() for Settings
_AGENT_WHOLE = {"agent_max_turns": (2, 30), "agent_max_seconds": (60, 3600),
                "agent_sql_seconds": (1, 60), "agent_result_tokens": (400, 12000)}
# the judge's keys, empty until chosen on the page
_AGENT_KEYS = {"judge_mode", "ask_judge", "agent_think", "agent_same_result", "agent_arbiter",
               "agent_choice_tolerance", *_AGENT_WHOLE}


def _whole_number(v):
    """The integer a stored value stands for, or None: an int, or a string
    of digits. Never a bool, which reaches the environment as "True"."""
    if isinstance(v, bool):
        return None
    if isinstance(v, int):
        return v
    if isinstance(v, str) and re.fullmatch(r"\s*[0-9]+\s*", v):
        return int(v)
    return None


def _share(v):
    """A share from 0 up to, not including, 1, as Settings reads it: a
    number, or a string float() reads. Never a bool."""
    if isinstance(v, bool) or not isinstance(v, (int, float, str)):
        return None
    try:
        n = float(v)
    except ValueError:
        return None
    return n if 0.0 <= n < 1.0 else None


def _check_agent(value):
    """Refuse a judge setting the agent could not use, with the reason."""
    for key, allowed in _AGENT_CHOICES.items():
        v = (value or {}).get(key)
        if v not in (None, "") and str(v) not in allowed:
            raise ValueError(f"{key} must be one of {', '.join(allowed)}, or empty")
    for key, (low, high) in _AGENT_WHOLE.items():
        v = (value or {}).get(key)
        if v in (None, ""):
            continue
        n = _whole_number(v)
        if n is None or not low <= n <= high:
            raise ValueError(f"{key} must be a whole number from {low} to {high}, "
                             f"or empty")
    v = (value or {}).get("agent_choice_tolerance")
    if v not in (None, "") and _share(v) is None:
        raise ValueError("agent_choice_tolerance must be a number from 0 up to, "
                         "not including, 1, or empty")


def _check_min_z(engine):
    """How far a column must stand out: a number from 1 to 10, or empty."""
    raw = str((engine or {}).get("column_min_z") or "").strip()
    if not raw:
        return
    try:
        value = float(raw)
    except ValueError:
        raise ValueError(f"the column standout must be a number, not {raw!r}") from None
    if not 1.0 <= value <= 10.0:
        raise ValueError(f"the column standout must be between 1 and 10, not {value}")


def _check_min_score(services):
    """A score is a number between 0 and 1, or empty for the default."""
    raw = str(((services or {}).get("qdrant") or {}).get("min_score") or "").strip()
    if not raw:
        return
    try:
        value = float(raw)
    except ValueError:
        raise ValueError(f"the minimum score must be a number between 0 and 1, "
                         f"not {raw!r}") from None
    if not 0.0 <= value <= 1.0:
        raise ValueError(f"the minimum score must be between 0 and 1, not {value}")


# ------------------------------------------------------------ endpoints
def _slug(text):
    keep = "".join(c.lower() if c.isalnum() else "-" for c in str(text))
    return "-".join(p for p in keep.split("-") if p)[:40] or "endpoint"


def _distinct_ids(endpoints, roles=None):
    """Every endpoint under an id of its own, and the roles pointing at them.

    The id was a slug of the label, which the wizard fills with the model's
    name: two servers serving gemma4:31b both became gemma4-31b, the second
    hid the first, and Edit or Remove touched both (review of 26 October).
    An id already given is kept by its first holder, wherever it stands;
    the others take -2, -3... A role naming a shared id twice, as a file
    saved before this did, points at the first holder, then the next."""
    eps = [dict(e) for e in endpoints or [] if isinstance(e, dict)]
    taken, holders, kept = set(), {}, set()
    for i, e in enumerate(eps):
        given = str(e.get("id") or "")
        if given and given not in taken:
            taken.add(given)
            holders[given] = [given]
            kept.add(i)
    for i, e in enumerate(eps):
        if i in kept:
            continue
        given = str(e.get("id") or "")
        base = given or _slug(e.get("label") or e.get("model") or "endpoint")
        new, n = base, 2
        while new in taken:
            new, n = f"{base[:36]}-{n}", n + 1
        taken.add(new)
        if given:
            holders[given].append(new)
        e["id"] = new
    if not isinstance(roles, dict):
        return eps, roles
    fixed = {}
    for role, ids in roles.items():
        if not isinstance(ids, list):
            fixed[role] = ids
            continue
        seen, out = {}, []
        for i in ids:
            names = holders.get(i) or [i]
            out.append(names[min(seen.get(i, 0), len(names) - 1)])
            seen[i] = seen.get(i, 0) + 1
        fixed[role] = out
    return eps, fixed


def _normalise_endpoint(e):
    e = dict(e or {})
    e.setdefault("id", _slug(e.get("label") or e.get("model") or "endpoint"))
    e["url"] = str(e.get("url") or "").strip().rstrip("/")
    e["api"] = "openai" if str(e.get("api") or "").lower() == "openai" else "ollama"
    for key, default, lo, hi in (("num_ctx", 16384, 2048, 1_048_576),
                                 ("parallel", 1, 1, 64),
                                 ("timeout", 600, 30, 7200)):
        try:
            e[key] = min(hi, max(lo, int(e.get(key) or default)))
        except (TypeError, ValueError):
            e[key] = default
    e["keep_alive"] = str(e.get("keep_alive") or "30m")
    # the cache type that server runs with (OLLAMA_KV_CACHE_TYPE), for the
    # estimate only; empty is the engine's setting
    kind = str(e.get("kv_cache_type") or "").lower()
    e["kv_cache_type"] = kind if kind in ("f16", "q8_0", "q4_0") else ""
    e["enabled"] = bool(e.get("enabled", True))
    # whether a model that can think first is let to (llm.py). Kept as a
    # boolean when it was said, read the way the .env's
    # DATAGORA_ENDPOINT_<NAME>_THINK is, so that "false" written into the
    # file stays false; left out when it was not, so an endpoint saved
    # before the page offered the choice takes llm.py's own default rather
    # than one written here
    if e.get("think") is None or str(e.get("think")).strip() == "":
        e.pop("think", None)
    else:
        e["think"] = str(e["think"]).strip().lower() in ("1", "true", "on", "yes")
    try:
        e["vram_gb"] = float(e["vram_gb"]) if e.get("vram_gb") else None
    except (TypeError, ValueError):
        e["vram_gb"] = None
    return e


def models_document(doc=None):
    """The store's endpoints in the shape llm.py already reads.

    `roles` becomes the first endpoint of each pool, which is what a caller
    asking for ONE endpoint gets; `pools` carries the whole list for the
    scheduler that spreads a batch over all of them. Returns None when no
    endpoint is configured, so llm.py falls back to its older sources."""
    doc = doc or load()
    endpoints, roles = _distinct_ids(doc.get("endpoints"), doc.get("roles"))
    doc = {**doc, "roles": roles or {}}
    live = {e["id"]: e for e in map(_normalise_endpoint, endpoints)
            if e.get("enabled") and e.get("url") and e.get("model")}
    if not live:
        return None
    pools = {}
    for role in ROLES:
        ids = [i for i in (doc.get("roles") or {}).get(role, []) if i in live]
        pools[role] = ids or [next(iter(live))]
    # the reranker only when one is chosen: unlike the roles above, an
    # empty one means no reranking, never the first endpoint (rerank.py)
    reranker = [i for i in (doc.get("roles") or {}).get("reranker", []) if i in live]
    if reranker:
        pools["reranker"] = reranker
    return {"roles": {r: ids[0] for r, ids in pools.items()},
            "pools": pools,
            "endpoints": {i: {k: v for k, v in e.items() if k != "id"}
                          for i, e in live.items()}}


def _environment():
    """The environment as db_profile reads it, the .env underneath the
    process's own; the process's alone when that cannot be had."""
    try:
        if __package__:
            from .db_profile import environment
        else:
            from db_profile import environment
        return environment()
    except Exception:
        return dict(os.environ)


def profiles_document(doc=None):
    """The store's databases in the shape db_profile.py already reads.

    Each database carries its own account inside `mysql`, which
    connect_mysql already consults before the environment. Neo4j and
    Qdrant are deployment-wide here and copied onto every profile, since a
    profile is what the rest of the code asks for them."""
    doc = doc or load()
    services = doc.get("services") or {}
    neo4j = dict(services.get("neo4j") or {})
    qdrant = dict(services.get("qdrant") or {})
    embedding = dict(services.get("embedding") or {})
    # A service the page does not set is the .env's, under the names the
    # .env's own databases read (db_profile.env_databases): the page wins,
    # the .env serves while the page has none. Without this a database
    # added on the page with Qdrant set only in the .env had its corpus
    # indexed (the indexer read the .env) and then never searched, and no
    # column index at all: "no Qdrant for this database".
    env = _environment()

    def first(*names):
        for name in names:
            value = unquote(str(env.get(name) or "").strip())
            if value:
                return value
        return ""

    if not neo4j.get("uri"):
        uri = first("DATAGORA_NEO4J_URI", "NEO4J_URI")
        if uri and uri.lower() != "off":
            neo4j = {"uri": uri, "user": first("NEO4J_USER", "NEO4J_USERNAME")}
    if not qdrant.get("url"):
        qdrant["url"] = first("DATAGORA_QDRANT_URL", "QDRANT_URL")
    if not embedding.get("url"):
        embedding["url"] = first("DATAGORA_EMBED_URL", "DATAGORA_OLLAMA_URL", "OLLAMA_URL")
    if not embedding.get("model"):
        embedding["model"] = first("EMBED_MODEL")
    profiles = {}
    for db in doc.get("databases") or []:
        name = str(db.get("name") or db.get("database") or "").strip()
        if not name or not db.get("database"):
            continue
        entry = {"mysql": {"host": db.get("host") or "127.0.0.1",
                           "port": int(db.get("port") or 3306),
                           "database": db["database"]}}
        if db.get("user"):
            entry["mysql"]["user"] = db["user"]
        if db.get("password"):
            entry["mysql"]["password"] = db["password"]
        for key in ("descriptions", "vocabulary"):
            if db.get(key):
                entry[key] = file_path(db[key])
        if str(db.get("neo4j_graph") or "").strip():
            entry["neo4j_graph"] = str(db["neo4j_graph"]).strip()
        if neo4j.get("uri"):
            entry["neo4j_uri"] = neo4j["uri"]
            entry["neo4j_user"] = neo4j.get("user") or "neo4j"
        if qdrant.get("url"):
            entry["qdrant_url"] = qdrant["url"]
            # one corpus per database: a collection set once for all of
            # them, as the page used to offer, made every database search
            # every other one's questions. Unset, it is <name>_corpus.
            if db.get("qdrant_collection"):
                entry["qdrant_collection"] = db["qdrant_collection"]
        if embedding.get("url"):
            entry["ollama_url"] = embedding["url"]
        if embedding.get("model"):
            entry["embed_model"] = embedding["model"]
        profiles[name] = entry
    return {"profiles": profiles} if profiles else None


# -------------------------------------------------------- environment
# The services and the engine tunables are read by code that already
# looks at the environment, at the moment it needs the value. Rather than
# thread the store through every one of those places, the store is
# written INTO the environment when it is loaded and whenever it is saved,
# so each existing reader sees the page's value. The store wins over
# whatever the container was started with, the .env included: the page is
# where a deployment is configured, and what it says is what runs.
_ENV_MAP = (
    (("services", "neo4j", "password"), "NEO4J_PASSWORD"),
    (("services", "neo4j", "user"), "NEO4J_USER"),
    (("services", "qdrant", "api_key"), "QDRANT_API_KEY"),
    (("services", "qdrant", "min_score"), "DATAGORA_CORPUS_MIN_SCORE"),
    (("services", "reranker", "url"), "DATAGORA_RERANKER_URL"),
    (("services", "reranker", "model"), "DATAGORA_RERANKER_MODEL"),
    (("services", "reranker", "device"), "DATAGORA_RERANKER_DEVICE"),
    (("services", "reranker", "enabled"), "DATAGORA_RERANKER"),
    (("services", "langfuse", "base_url"), "LANGFUSE_BASE_URL"),
    (("services", "langfuse", "public_key"), "LANGFUSE_PUBLIC_KEY"),
    (("services", "langfuse", "secret_key"), "LANGFUSE_SECRET_KEY"),
    (("engine", "schema_samples"), "DATAGORA_SCHEMA_SAMPLES"),
    (("engine", "sample_values"), "DATAGORA_SAMPLE_VALUES"),
    (("engine", "enumeration"), "DATAGORA_ENUMERATION"),
    (("engine", "reformulate"), "DATAGORA_REFORMULATE"),
    (("engine", "column_min_z"), "DATAGORA_COLUMN_MIN_Z"),
    (("engine", "judge_mode"), "DATAGORA_JUDGE"),
    (("engine", "ask_judge"), "DATAGORA_ASK_JUDGE"),
    (("engine", "agent_max_turns"), "DATAGORA_AGENT_MAX_TURNS"),
    (("engine", "agent_max_seconds"), "DATAGORA_AGENT_MAX_SECONDS"),
    (("engine", "agent_think"), "DATAGORA_AGENT_THINK"),
    (("engine", "agent_sql_seconds"), "DATAGORA_AGENT_SQL_SECONDS"),
    (("engine", "agent_result_tokens"), "DATAGORA_AGENT_RESULT_TOKENS"),
    (("engine", "agent_choice_tolerance"), "DATAGORA_AGENT_CHOICE_TOLERANCE"),
    (("engine", "agent_same_result"), "DATAGORA_AGENT_SAME_RESULT"),
    (("engine", "agent_arbiter"), "DATAGORA_AGENT_ARBITER"),
)


# the variables this module has set itself, which a later save may change,
# with the value each had before, from the platform or the .env, so that
# clearing a field on the page brings that value back rather than nothing
_SET_HERE: set = set()
_BEFORE: dict = {}


def _set(key, value):
    if key not in _SET_HERE:
        _BEFORE[key] = os.environ.get(key)
        _SET_HERE.add(key)
    os.environ[key] = value


def _unset(key):
    if key in _SET_HERE:
        before = _BEFORE.pop(key, None)
        if before is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = before
        _SET_HERE.discard(key)


def apply_to_environment(doc=None):
    """What the page saved, made visible to the code that reads variables.

    Over whatever the platform or the .env gives: the page is where a
    deployment is configured. A field left empty on the page leaves the
    .env's value in force, which is how the .env serves as the default."""
    doc = doc if doc is not None else load()
    # the engine's values have defaults of their own, which an untouched
    # store must not impose; a service value is empty until someone types
    # it, so it counts even when the databases come from the .env
    configured = bool(doc.get("endpoints") or doc.get("databases"))
    for path, key in _ENV_MAP:
        # the judge's keys are empty until chosen, and empty leaves the
        # environment's value: they impose nothing, so they apply on a
        # deployment configured by its .env alone too
        if path[0] == "engine" and not configured and path[1] not in _AGENT_KEYS:
            continue
        node = doc
        for part in path:
            node = node.get(part) if isinstance(node, dict) else None
        if node not in (None, ""):
            _set(key, str(node))
        else:
            # cleared on the page: what was there before the page set it
            # comes back, the .env's value or the engine's default
            _unset(key)
    engine = doc.get("engine") or {}
    if configured and "ask_values" in engine:
        _set("DATAGORA_ASK_VALUES", "on" if engine["ask_values"] else "off")
    if configured and "column_index" in engine:
        _set("DATAGORA_COLUMN_INDEX", "on" if engine["column_index"] else "off")


# -------------------------------------------------------------- presets
def _preset_payload(doc):
    """What a preset photographs: the model side, and only that.

    Switching from "two 31B GPUs" to "one local model" is a change of
    models; it must not swap a database password or a Langfuse key, so
    credentials are deliberately outside the snapshot."""
    return {"endpoints": [_normalise_endpoint(e) for e in doc.get("endpoints") or []],
            "roles": copy.deepcopy(doc.get("roles") or {})}


def _fingerprint(payload):
    return json.dumps(payload, sort_keys=True, default=str)


def list_presets():
    doc = load()
    current = _fingerprint(_preset_payload(doc))
    out = []
    for p in doc.get("presets") or []:
        item = redacted({"p": p})["p"]
        item["matches_current"] = _fingerprint(p.get("payload") or {}) == current
        out.append(item)
    return out


def save_preset(name):
    """Photograph the current model setup under a name; a name reused replaces."""
    name = str(name or "").strip()
    if not name:
        raise ValueError("a preset needs a name")
    with _lock:
        doc = load()
        payload = _preset_payload(doc)
        presets = [p for p in doc.get("presets") or [] if p.get("name") != name]
        preset = {"id": _slug(name) + "-" + secrets.token_hex(3),
                  "name": name,
                  "saved_at": datetime.now().isoformat(timespec="seconds"),
                  "payload": payload}
        presets.append(preset)
        doc["presets"] = presets
        save(doc)
    return preset


def restore_preset(preset_id):
    with _lock:
        doc = load()
        preset = next((p for p in doc.get("presets") or []
                       if p.get("id") == preset_id), None)
        if preset is None:
            raise KeyError(preset_id)
        payload = copy.deepcopy(preset.get("payload") or {})
        # an endpoint's stored API key survives a restore of a preset that
        # was photographed before the key was set
        doc["endpoints"] = _keep_secrets(payload.get("endpoints") or [],
                                         doc.get("endpoints") or [])
        doc["roles"] = payload.get("roles") or {}
        save(doc)
    return preset


def delete_preset(preset_id):
    with _lock:
        doc = load()
        before = len(doc.get("presets") or [])
        doc["presets"] = [p for p in doc.get("presets") or []
                          if p.get("id") != preset_id]
        if len(doc["presets"]) == before:
            raise KeyError(preset_id)
        save(doc)


# ---------------------------------------------------------------- admin
# The settings page writes database passwords, so it needs a door. There is
# no user system to lean on, so the first visit creates the one password,
# the way Langfuse and Grafana do on a fresh install, and every settings
# request after that carries a signed session cookie. PBKDF2 from the
# standard library: no new dependency for the one thing that must not be
# homemade.
_ITERATIONS = 240_000


def has_admin():
    return bool(load().get("admin", {}).get("password_hash"))


def _hash(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt,
                                 _ITERATIONS)
    return (f"pbkdf2${_ITERATIONS}${base64.b64encode(salt).decode()}"
            f"${base64.b64encode(digest).decode()}")


def _verify(password, stored):
    try:
        _algo, rounds, salt, digest = stored.split("$")
        expected = hashlib.pbkdf2_hmac(
            "sha256", password.encode("utf-8"), base64.b64decode(salt),
            int(rounds))
        return hmac.compare_digest(expected, base64.b64decode(digest))
    except Exception:
        return False


def set_admin_password(password, current=None):
    """Create the password on first run, or change it knowing the old one."""
    password = str(password or "")
    if len(password) < 10:
        raise ValueError("the settings password needs at least 10 characters")
    with _lock:
        doc = load()
        stored = doc.get("admin", {}).get("password_hash")
        if stored and not _verify(str(current or ""), stored):
            raise PermissionError("the current password is not right")
        admin = dict(doc.get("admin") or {})
        admin["password_hash"] = _hash(password)
        # a new password invalidates every session signed with the old secret
        admin["session_secret"] = secrets.token_hex(32)
        doc["admin"] = admin
        save(doc)


def check_password(password):
    stored = load().get("admin", {}).get("password_hash")
    return bool(stored) and _verify(str(password or ""), stored)


SESSION_SECONDS = 12 * 3600


def issue_session():
    secret = load().get("admin", {}).get("session_secret", "")
    expires = int(time.time()) + SESSION_SECONDS
    # a random part: two sessions opened in the same second were one token,
    # so a logout revoked the login that followed it
    body = f"{expires}:{secrets.token_hex(8)}"
    mac = hmac.new(secret.encode(), body.encode(), hashlib.sha256).hexdigest()
    return f"{body}.{mac}"


def valid_session(token):
    admin = load().get("admin", {})
    secret = admin.get("session_secret", "")
    if not (secret and token and "." in token):
        return False
    body, mac = token.rsplit(".", 1)
    expected = hmac.new(secret.encode(), body.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(mac, expected):
        return False
    if mac in (admin.get("revoked") or {}):
        return False
    try:
        return int(body.split(":")[0]) > time.time()
    except ValueError:
        return False


def end_session(token):
    """Revoke one session before it expires. The token is signed, not
    stored, so deleting the cookie in the browser left a copy of it valid
    for its twelve hours (review of 26 October); a logout now writes its
    signature down until then, and forgets the ones that expired."""
    if not valid_session(token):
        return
    body, mac = token.rsplit(".", 1)
    with _lock:
        doc = load()
        admin = dict(doc.get("admin") or {})
        now = time.time()
        revoked = {m: e for m, e in (admin.get("revoked") or {}).items()
                   if isinstance(e, (int, float)) and e > now}
        revoked[mac] = int(body.split(":")[0])
        admin["revoked"] = revoked
        doc["admin"] = admin
        save(doc)
