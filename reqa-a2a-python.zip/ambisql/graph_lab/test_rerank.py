"""The reranker: chosen on the settings page, or none; a language model's
scores or a rerank server's; the vector order kept whenever it cannot say;
and where it re-sorts, the corpus's neighbours. No model, no Qdrant:
stand-ins answer."""

import os

os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

import json
import pathlib
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import llm  # noqa: E402
import rerank  # noqa: E402
import settings_store as store  # noqa: E402
from recall import Recall  # noqa: E402


class Scorer:
    """A language model that scores candidates as told."""

    def __init__(self, scores=None, api="ollama", reply=None):
        self.api, self.url, self.model, self.name, self.timeout = api, "http://m", "m", "m", 5
        self.scores, self.reply, self.calls, self.last_error = scores or {}, reply, [], ""

    def json(self, system, user, schema=None):
        self.calls.append(user)
        if self.reply is not None:
            return self.reply
        lines = [line for line in user.splitlines() if line.startswith("[")]
        return {"scores": [{"id": i, "score": self.scores.get(line.split("] ", 1)[1].split(":")[0], 0)}
                           for i, line in enumerate(lines)]}


class NoOllama(unittest.TestCase):
    """The stand-ins are no Ollama: asking one what it can do fails at once,
    and it is taken for a chat model."""

    def setUp(self):
        super().setUp()
        p = patch.object(rerank, "_post", side_effect=OSError("no Ollama here"))
        p.start()
        self.addCleanup(p.stop)


class ChosenTests(NoOllama):
    def setUp(self):
        super().setUp()
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        env = patch.dict(os.environ, {"DATAGORA_DATA_DIR": self.tmp.name})
        env.start()
        self.addCleanup(env.stop)
        store._SET_HERE.clear()
        store._BEFORE.clear()
        store.update("endpoints", [
            {"id": "big", "url": "http://gpu:11434", "model": "gemma4:31b", "api": "ollama"},
            {"id": "small", "url": "http://gpu:11435", "model": "gemma3:4b", "api": "ollama"}])

    def test_no_reranker_unless_one_is_chosen(self):
        store.update("roles", {"reasoner": ["big"], "sql": ["big"]})
        self.assertNotIn("reranker", store.models_document()["pools"])
        self.assertIsNone(rerank.Reranker.configured())

    def test_the_one_chosen(self):
        store.update("roles", {"reasoner": ["big"], "sql": ["big"], "reranker": ["small"]})
        chosen = rerank.Reranker.configured()
        self.assertEqual((chosen.model.name, chosen.model.model), ("small", "gemma3:4b"))

    def test_on_by_default_even_in_a_store_written_before_it(self):
        # a store from an older version, migrated: no reranker entry at all
        store.update("services", {"embedding": {"url": "http://ollama:11434",
                                                "model": "nomic-embed-text"}})
        store.apply_to_environment()
        chosen = rerank.Reranker.configured()
        self.assertEqual((chosen.model.model, chosen.model.url, chosen.device),
                         ("mxbai-embed-large", "http://ollama:11434", "cpu"))

    def test_switched_off_there_is_none_and_the_model_is_kept(self):
        store.update("services", {"embedding": {"url": "http://ollama:11434"},
                                  "reranker": {"enabled": False, "model": "mxbai-embed-large"}})
        store.apply_to_environment()
        self.assertIsNone(rerank.Reranker.configured())
        # off wins over an endpoint given the reranker role too
        store.update("roles", {"reasoner": ["big"], "sql": ["big"], "reranker": ["small"]})
        self.assertIsNone(rerank.Reranker.configured())
        self.assertEqual(store.load()["services"]["reranker"]["model"], "mxbai-embed-large")
        # switched back on, the same model again
        store.update("services", {"embedding": {"url": "http://ollama:11434"},
                                  "reranker": {"enabled": True, "model": "mxbai-embed-large"}})
        store.apply_to_environment()
        self.assertEqual(rerank.Reranker.configured().model.model, "mxbai-embed-large")

    def test_on_by_default(self):
        self.assertIs(store.load()["services"]["reranker"]["enabled"], True)

    def test_none_on_the_page_turns_it_off(self):
        store.update("services", {"embedding": {"url": "http://ollama:11434"},
                                  "reranker": {"url": "", "model": ""}})
        store.apply_to_environment()
        self.assertIsNone(rerank.Reranker.configured())

    def test_the_card_on_the_page_chooses_it(self):
        store.update("services", {"reranker": {"url": "http://ollama:11434",
                                               "model": "mxbai-embed-large"}})
        store.apply_to_environment()
        chosen = rerank.Reranker.configured()
        self.assertEqual((chosen.model.url, chosen.model.model, chosen.model.api),
                         ("http://ollama:11434", "mxbai-embed-large", "ollama"))
        # over an endpoint given the role
        store.update("roles", {"reasoner": ["big"], "sql": ["big"], "reranker": ["small"]})
        self.assertEqual(rerank.Reranker.configured().model.model, "mxbai-embed-large")
        # None on the card, and no role: no reranker
        store.update("roles", {"reasoner": ["big"], "sql": ["big"]})
        store.update("services", {"reranker": {"url": "http://ollama:11434", "model": ""}})
        store.apply_to_environment()
        self.assertIsNone(rerank.Reranker.configured())

    def test_the_env_names_one_too(self):
        env = {"DATAGORA_ENDPOINTS": "a,b", "DATAGORA_ENDPOINT_A_URL": "http://a",
               "DATAGORA_ENDPOINT_A_MODEL": "gemma4:31b", "DATAGORA_ENDPOINT_B_URL": "http://b",
               "DATAGORA_ENDPOINT_B_MODEL": "gemma3:4b", "DATAGORA_LLM_RERANKER": "b"}
        self.assertEqual(llm.env_endpoints(env)["pools"]["reranker"], ["b"])
        env.pop("DATAGORA_LLM_RERANKER")
        self.assertNotIn("reranker", llm.env_endpoints(env)["pools"])


class RankTests(NoOllama):
    DOCS = ["product_suppliers.lead_time_days: days", "leads.source: CRM", "warehouses.city: city"]

    def test_a_language_model_s_scores_best_first(self):
        model = Scorer({"product_suppliers.lead_time_days": 10, "leads.source": 1})
        ranked = rerank.Reranker(model).rank("lead time", self.DOCS)
        self.assertEqual(ranked[0], (0, 1.0))
        self.assertEqual(dict(ranked)[2], 0.0)            # skipped: unrelated

    def test_an_unusable_reply_says_nothing(self):
        self.assertIsNone(rerank.Reranker(Scorer(reply={"no": "scores"})).rank("q", self.DOCS))

    def test_a_rerank_server_is_used_when_there_is_one(self):
        class Reply:
            def __enter__(self):
                return self

            def __exit__(self, *a):
                return False

            def read(self):
                return json.dumps({"results": [{"index": 1, "relevance_score": 0.9},
                                               {"index": 0, "relevance_score": 3.0}]}).encode()

        seen = []
        with patch("urllib.request.urlopen", lambda req, timeout=None: seen.append(req.full_url) or Reply()):
            reranker = rerank.Reranker(Scorer(api="openai"))
            ranked = reranker.rank("q", self.DOCS[:2])
        self.assertTrue(seen[0].endswith("/v1/rerank"))
        self.assertEqual(reranker.kind, "rerank")
        self.assertEqual(ranked[0][0], 0)                  # a logit of 3 is 0.95
        self.assertGreater(ranked[0][1], 0.9)

    def test_without_a_server_a_chat_model_scores_instead(self):
        model = Scorer({"leads.source": 9}, api="openai")
        with patch("urllib.request.urlopen", side_effect=OSError("404")):
            reranker = rerank.Reranker(model)
            ranked = reranker.rank("q", self.DOCS)
        self.assertEqual((reranker.kind, ranked[0][0]), ("chat", 1))

    def test_without_a_reranker_the_vector_order_stands(self):
        with patch.object(rerank.Reranker, "configured", classmethod(lambda cls: None)):
            self.assertEqual(rerank.rerank("q", ["a", "b"]), [("a", None), ("b", None)])

    def test_the_known_cases(self):
        good = Scorer({"product_suppliers.lead_time_days": 10, "sea_shpmnt.container_count": 10,
                       "loans.fine_amount": 10})
        self.assertTrue(rerank.Reranker(good).test()["ok"])
        self.assertFalse(rerank.Reranker(Scorer({"leads.source": 10})).test()["ok"])


class CorpusTests(NoOllama):
    def corpus(self, neighbours):
        r = Recall("http://q", "c", "http://e")
        r.neighbours = lambda question, limit=3: neighbours
        return r

    def test_the_reranker_decides_which_neighbours_count(self):
        # close in embedding space, asking something else
        r = self.corpus([(0.80, {"question": "How many leads per source?", "tables": ["leads"]}),
                         (0.70, {"question": "Average lead time per supplier?",
                                 "tables": ["product_suppliers"]})])
        model = Scorer({"How many leads per source?": 1, "Average lead time per supplier?": 9})
        reranker = rerank.Reranker(model)
        self.assertEqual(r.anchors("What is the average lead time?", min_score=0.72,
                                   reranker=reranker), ["product_suppliers"])
        # without it, the vector bar keeps the wrong one only
        self.assertEqual(r.anchors("What is the average lead time?", min_score=0.72,
                                   reranker=None), ["leads"])

    def test_a_reranker_that_cannot_say_leaves_the_vector_bar(self):
        r = self.corpus([(0.80, {"question": "q1", "tables": ["t1"]})])
        reranker = rerank.Reranker(Scorer(reply={}))
        self.assertEqual(r.anchors("q", min_score=0.72, reranker=reranker), ["t1"])


    def test_a_related_neighbour_counts_an_unrelated_one_does_not(self):
        # recall-first: a related question's table costs one edge
        r = self.corpus([(0.70, {"question": "Stock per warehouse?", "tables": ["inventory"]}),
                         (0.69, {"question": "Leads per source?", "tables": ["leads"]})])
        model = Scorer({"Stock per warehouse?": 4, "Leads per source?": 3})
        self.assertEqual(r.anchors("Which warehouse holds the most?", min_score=0.72,
                                   reranker=rerank.Reranker(model)), ["inventory"])


class EmbedTests(unittest.TestCase):
    """An embedding model on Ollama: Ollama says it only embeds, the
    candidates are scored by closeness, and its own bar applies."""

    def ollama(self, vectors, caps=("embedding",)):
        calls = []

        def post(url, body, timeout):
            calls.append((url, body))
            if url.endswith("/api/show"):
                return {"capabilities": list(caps)}
            return {"embeddings": vectors}
        return calls, patch.object(rerank, "_post", post)

    def mxbai(self):
        model = Scorer()
        model.model = "mxbai-embed-large"
        return rerank.Reranker(model)

    def test_an_embedding_model_scores_by_closeness(self):
        calls, ollama = self.ollama([[1, 0], [0, 1], [1, 0.1]])
        with ollama:
            reranker = self.mxbai()
            ranked = reranker.rank("lead time", ["leads.source", "product_suppliers.lead_time_days"])
        self.assertEqual(reranker.kind, "embed")
        self.assertEqual(ranked[0][0], 1)
        self.assertAlmostEqual(ranked[0][1], 0.995, places=3)
        # the question carries mxbai's search instruction, the candidates none
        sent = calls[1][1]["input"]
        self.assertTrue(sent[0].startswith("Represent this sentence for searching"))
        self.assertEqual(sent[1:], ["leads.source", "product_suppliers.lead_time_days"])
        self.assertEqual(reranker.keep(0.4), 0.65)

    def test_on_the_cpu_ollama_is_told_to_keep_it_off_the_gpu(self):
        calls, ollama = self.ollama([[1, 0], [0, 1]])
        with ollama:
            model = Scorer()
            model.model = "mxbai-embed-large"
            rerank.Reranker(model, "cpu").rank("q", ["a"])
            rerank.Reranker(model, "gpu").rank("q", ["a"])
        embeds = [body for url, body in calls if url.endswith("/api/embed")]
        self.assertEqual(embeds[0]["options"], {"num_gpu": 0})
        self.assertNotIn("options", embeds[1])

    def test_a_chat_model_is_not_taken_for_one(self):
        _calls, ollama = self.ollama(None, caps=("completion", "vision"))
        with ollama:
            reranker = rerank.Reranker(Scorer({"leads.source": 9}))
            ranked = reranker.rank("q", RankTests.DOCS)
        self.assertEqual((reranker.kind, ranked[0][0]), ("chat", 1))
        self.assertEqual(reranker.keep(0.4), 0.4)

    def test_an_embedding_that_fails_leaves_the_vector_order(self):
        _calls, ollama = self.ollama([[1, 0]])          # one vector for three texts
        with ollama:
            self.assertIsNone(self.mxbai().rank("q", ["a", "b"]))

    def test_the_corpus_counts_a_neighbour_from_the_model_s_own_bar(self):
        r = Recall("http://q", "c", "http://e")
        r.neighbours = lambda question, limit=3: [
            (0.70, {"question": "Stock per warehouse?", "tables": ["inventory"]}),
            (0.69, {"question": "Leads per source?", "tables": ["leads"]})]
        # closeness 0.70 and 0.60 to the question: only the first reaches 0.65
        _calls, ollama = self.ollama([[1, 0], [0.7, 0.714142842854285], [0.6, 0.8]])
        with ollama:
            self.assertEqual(r.anchors("Which warehouse holds the most?", min_score=0.72,
                                       reranker=self.mxbai()), ["inventory"])


class Encoder:
    """A cross-encoder stand-in: one score per (question, candidate) pair,
    by the candidate's name before the colon."""

    def __init__(self, scores=None, fail=None):
        self.scores, self.fail, self.pairs = scores or {}, fail, []

    def predict(self, pairs, show_progress_bar=False, **kw):
        if self.fail:
            raise self.fail
        self.pairs.extend(pairs)
        return [self.scores.get(d.split(":")[0], 0.0) for _q, d in pairs]


class CrossTests(unittest.TestCase):
    """A cross-encoder run in Datagora: chosen by its name, each pair read
    whole, its own bar."""
    NAME = "mixedbread-ai/mxbai-rerank-large-v2"

    def encoder(self, encoder):
        # kept per (model, device); "" is the automatic device
        p = patch.dict(rerank._ENCODERS, {(self.NAME, ""): encoder})
        p.start()
        self.addCleanup(p.stop)
        return rerank.Reranker(rerank.InDatagora(self.NAME))

    def test_each_pair_is_read_whole(self):
        enc = Encoder({"product_suppliers.lead_time_days": 0.97, "leads.source": 0.02})
        reranker = self.encoder(enc)
        ranked = reranker.rank("lead time", RankTests.DOCS)
        self.assertEqual((reranker.kind, ranked[0]), ("cross", (0, 0.97)))
        self.assertEqual(enc.pairs[1], ("lead time", "leads.source: CRM"))
        self.assertEqual(reranker.keep(0.4), 0.5)

    def test_a_raw_logit_is_squashed(self):
        ranked = self.encoder(Encoder({"leads.source": 4.0, "warehouses.city": -3.0})).rank(
            "q", RankTests.DOCS)
        self.assertEqual(ranked[0][0], 1)
        self.assertAlmostEqual(ranked[0][1], 0.982, places=3)
        self.assertAlmostEqual(dict(ranked)[2], 0.047, places=3)       # -3
        self.assertEqual(dict(ranked)[0], 0.0)                             # 0, kept

    def test_a_failure_leaves_the_vector_order(self):
        reranker = self.encoder(Encoder(fail=RuntimeError("out of memory")))
        self.assertIsNone(reranker.rank("q", ["a"]))
        self.assertIn("out of memory", reranker.model.last_error)

    def test_chosen_by_its_name_whatever_server_is_named(self):
        env = {"DATAGORA_RERANKER_MODEL": self.NAME, "DATAGORA_RERANKER_URL": "http://ollama:11434"}
        with patch.dict(os.environ, env):
            chosen = rerank.Reranker.configured()
        self.assertEqual((chosen.model.api, chosen.model.model), ("local", self.NAME))

    def test_listed_with_what_it_needs(self):
        listed = rerank.cross_encoders()
        self.assertEqual([m["name"] for m in listed], [self.NAME])
        self.assertIn("installed", listed[0])


if __name__ == "__main__":
    unittest.main()
