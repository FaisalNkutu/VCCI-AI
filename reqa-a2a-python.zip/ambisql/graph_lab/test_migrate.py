"""scripts/migrate.py: a deployment's configuration carried to a new version.

Two folders made in a temporary directory stand for the running version and
the one replacing it. Nothing else is touched."""

import os

os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

import contextlib
import hashlib
import importlib.util
import io
import json
import pathlib
import tempfile
import unittest

HERE = pathlib.Path(__file__).resolve().parent
SCRIPT = HERE.parent.parent / "scripts" / "migrate.py"
spec = importlib.util.spec_from_file_location("migrate", SCRIPT)
migrate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(migrate)

STORE = {"version": 1,
         "databases": [{"name": "Prod", "database": "prod_db", "host": "10.0.0.9",
                        "port": 3306, "user": "reader", "password": "s3cret-db",
                        "descriptions": "files/Prod.descriptions.json"}],
         "endpoints": [{"id": "gpu0", "label": "Tesla 0", "url": "http://gpu:11434",
                        "model": "gemma4:31b", "parallel": 4}],
         "roles": {"reasoner": ["gpu0"], "sql": ["gpu0"]},
         "services": {"qdrant": {"url": "http://qdrant:6333"}, "neo4j": {"uri": "",
                                                                      "password": "s3cret-neo"}},
         "admin": {"password_hash": "pbkdf2$abc", "session_secret": "s3cret-session"}}
COMPOSE = "services:\n  ambisql-ui:\n    ports:\n      - \"8080:8080\"\n"


def release(folder, version, compose=COMPOSE, example="DATAGORA_TRACING=on\n"):
    folder.mkdir(parents=True)
    (folder / "pyproject.toml").write_text(
        f'[project]\nname = "datagora"\nversion = "{version}"\n', encoding="utf-8")
    (folder / "docker-compose.yml").write_text(compose, encoding="utf-8")
    (folder / "docker-compose.platform.yml").write_text("services: {}\n", encoding="utf-8")
    (folder / ".env.example").write_text(example, encoding="utf-8")
    (folder / "deploy" / "config").mkdir(parents=True)
    (folder / "deploy" / "config" / "profiles.json").write_text(
        '{\n  "password": "replace-with-the-real-one"\n}\n', encoding="utf-8")


def deployed(folder):
    """What a deployment adds to its release."""
    (folder / "data" / "files").mkdir(parents=True)
    (folder / "data" / "datagora.json").write_text(json.dumps(STORE), encoding="utf-8")
    (folder / "data" / "files" / "Prod.descriptions.json").write_text("{}", encoding="utf-8")
    (folder / "coverage_runs").mkdir()
    (folder / "coverage_runs" / "run.csv").write_text("question,verdict\n", encoding="utf-8")
    (folder / ".env").write_text(
        f"DATAGORA_TRACING=on\nLANGFUSE_SECRET_KEY=s3cret-lf\n"
        f"DATAGORA_DESCRIPTIONS={folder}/deploy/config/kb.json\n"
        f"OTHER={folder}_backups/x\n", encoding="utf-8")
    (folder / "deploy" / "config" / "kb.json").write_text("{}", encoding="utf-8")


class MigrateTests(unittest.TestCase):
    def setUp(self):
        # the compose files here are stand-ins Docker would refuse; the
        # check that asks Docker is exercised on a real release instead
        self.which = migrate.shutil.which
        migrate.shutil.which = lambda _name: None
        self.addCleanup(setattr, migrate.shutil, "which", self.which)
        self.tmp = tempfile.TemporaryDirectory()
        root = pathlib.Path(self.tmp.name)
        self.old, self.new = root / "datagora-0.2.1", root / "datagora-0.2.3"
        release(self.old, "0.2.1")
        deployed(self.old)
        release(self.new, "0.2.3", compose=COMPOSE + "    # new in 0.2.3\n",
                example="DATAGORA_TRACING=on\n# DATAGORA_LLM_TIMEOUT=600\n")

    def tearDown(self):
        self.tmp.cleanup()

    def run_it(self, *extra):
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            code = migrate.main([str(self.old), str(self.new), *extra])
        return code, out.getvalue()

    def test_the_settings_store_and_the_runs_are_carried(self):
        code, _out = self.run_it()
        self.assertEqual(code, 0)
        self.assertEqual(json.loads((self.new / "data" / "datagora.json").read_text()), STORE)
        self.assertTrue((self.new / "data" / "files" / "Prod.descriptions.json").is_file())
        self.assertTrue((self.new / "coverage_runs" / "run.csv").is_file())
        self.assertTrue((self.new / "deploy" / "config" / "kb.json").is_file())

    def test_the_env_is_carried_and_leads_into_the_new_folder(self):
        self.run_it()
        env = (self.new / ".env").read_text()
        self.assertIn(f"DATAGORA_DESCRIPTIONS={self.new}/deploy/config/kb.json", env)
        # a longer name the old folder's begins is left alone
        self.assertIn(f"OTHER={self.old}_backups/x", env)

    def test_an_edited_compose_wins_and_the_new_one_is_kept_beside(self):
        _code, out = self.run_it()
        self.assertEqual((self.new / "docker-compose.yml").read_text(), COMPOSE)
        self.assertIn("# new in 0.2.3",
                      (self.new / "docker-compose.yml.new").read_text())
        self.assertIn("+    # new in 0.2.3", out)

    def test_a_compose_never_edited_gives_way_to_the_new_version(self):
        digest = hashlib.sha256((self.old / "docker-compose.yml").read_bytes()).hexdigest()
        (self.old / "RELEASE-FILES.sha256").write_text(f"{digest}  docker-compose.yml\n")
        _code, out = self.run_it()
        self.assertIn("# new in 0.2.3", (self.new / "docker-compose.yml").read_text())
        self.assertFalse((self.new / "docker-compose.yml.new").exists())
        self.assertIn("never edited", out)

    def test_no_secret_is_printed(self):
        (self.old / "deploy" / "config" / "profiles.json").write_text(
            '{\n  "password": "s3cret-profile"\n}\n', encoding="utf-8")
        _code, out = self.run_it()
        self.assertNotIn("s3cret", out)
        self.assertNotIn("s3cret", (self.new / "MIGRATED-FROM.txt").read_text())
        self.assertIn("a line holding a secret, not shown", out)
        self.assertIn("databases: Prod", out)
        self.assertIn("Tesla 0 (gemma4:31b, x4)", out)
        self.assertIn("admin account: set", out)

    def test_a_new_variable_is_pointed_out(self):
        _code, out = self.run_it()
        self.assertIn("DATAGORA_LLM_TIMEOUT", out)

    def test_a_variable_this_version_brought_is_added_at_its_default(self):
        # 27 October: the .env and the settings are never overwritten; a key
        # this version brought is added at its default, and said
        (self.old / ".env.example").write_text(
            "DATAGORA_TRACING=on\nDATAGORA_ENDPOINTS=local,fake_gpu\n", encoding="utf-8")
        (self.new / ".env.example").write_text(
            "DATAGORA_TRACING=off\nDATAGORA_ENDPOINTS=local,fake_gpu\n"
            "# who judges an Ask question\nDATAGORA_ASK_JUDGE=agent\n"
            "# the key of a new service\nNEW_SERVICE_TOKEN=change-me\n"
            "# DATAGORA_LLM_TIMEOUT=600\n", encoding="utf-8")
        _code, out = self.run_it()
        env = (self.new / ".env").read_text()
        self.assertIn("# who judges an Ask question\nDATAGORA_ASK_JUDGE=agent", env)
        self.assertIn("# NEW_SERVICE_TOKEN=", env)
        self.assertNotIn("NEW_SERVICE_TOKEN=change-me", env)
        self.assertIn("# DATAGORA_LLM_TIMEOUT=600", env)
        # what the .env said stays as it was, and a sample block is no setting
        self.assertTrue(env.startswith("DATAGORA_TRACING=on\nLANGFUSE_SECRET_KEY=s3cret-lf\n"))
        self.assertNotIn("DATAGORA_TRACING=off", env)
        self.assertNotIn("DATAGORA_ENDPOINTS", env)
        self.assertIn("DATAGORA_ASK_JUDGE=agent", out)
        self.assertIn("to fill in: NEW_SERVICE_TOKEN", out)
        self.assertNotIn("s3cret", out)
        # a second run adds nothing more
        _code, out = self.run_it()
        self.assertEqual((self.new / ".env").read_text().count("DATAGORA_ASK_JUDGE"), 1)
        self.assertIn("0 files copied", out)

    def test_a_key_the_env_already_sets_is_left_as_it_is(self):
        with open(self.old / ".env", "a", encoding="utf-8") as fh:
            fh.write("DATAGORA_ASK_JUDGE=single\n")
        (self.new / ".env.example").write_text(
            "DATAGORA_TRACING=on\nDATAGORA_ASK_JUDGE=agent\n", encoding="utf-8")
        self.run_it()
        env = (self.new / ".env").read_text()
        self.assertIn("DATAGORA_ASK_JUDGE=single", env)
        self.assertNotIn("DATAGORA_ASK_JUDGE=agent", env)

    def test_the_settings_this_version_brings_are_said_never_written(self):
        source = self.new / "src" / "graph_lab"
        source.mkdir(parents=True)
        (source / "settings_store.py").write_text(
            'VERSION = 3\nDEFAULTS = {"version": VERSION, "engine": '
            '{"ask_judge": "", "agent_max_seconds": ""}}\n', encoding="utf-8")
        store = dict(STORE, engine={"ask_judge": "agent"})
        (self.old / "data" / "datagora.json").write_text(json.dumps(store), encoding="utf-8")
        _code, out = self.run_it()
        said = [line for line in out.splitlines() if "settings this version brings" in line]
        self.assertEqual(len(said), 1)
        self.assertIn("agent_max_seconds", said[0])
        self.assertNotIn("ask_judge", said[0])
        self.assertEqual(json.loads((self.new / "data" / "datagora.json").read_text())["engine"],
                         {"ask_judge": "agent"})

    def test_a_dry_run_writes_nothing(self):
        before = sorted(p.name for p in self.new.rglob("*"))
        _code, out = self.run_it("--dry-run")
        self.assertEqual(sorted(p.name for p in self.new.rglob("*")), before)
        self.assertIn("dry run", out)

    def test_a_file_of_the_new_folder_is_backed_up_before_it_is_replaced(self):
        (self.new / "data").mkdir()
        (self.new / "data" / "datagora.json").write_text("{}", encoding="utf-8")
        self.run_it()
        self.assertEqual((self.new / "data" / "datagora.json.before-migration").read_text(), "{}")

    def test_running_it_twice_changes_nothing_more(self):
        self.run_it()
        _code, out = self.run_it()
        self.assertFalse((self.new / "data" / "datagora.json.before-migration").exists())
        self.assertIn("0 files copied", out)

    def test_the_old_folder_is_never_touched(self):
        def state():
            return {str(p): p.read_bytes() for p in self.old.rglob("*") if p.is_file()}
        before = state()
        self.run_it()
        self.assertEqual(state(), before)

    def test_the_new_folder_is_the_scripts_own_when_not_given(self):
        saved = migrate.HERE
        migrate.HERE = self.new
        self.addCleanup(setattr, migrate, "HERE", saved)
        code, _out = self.run_alone(str(self.old))
        self.assertEqual(code, 0)
        self.assertTrue((self.new / "data" / "datagora.json").is_file())

    def run_alone(self, *argv):
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            code = migrate.main(list(argv))
        return code, out.getvalue()

    def test_the_old_folder_is_found_from_the_running_container(self):
        saved = migrate.HERE, migrate.running_folder
        migrate.HERE, migrate.running_folder = self.new, lambda: self.old
        self.addCleanup(lambda: (setattr(migrate, "HERE", saved[0]),
                                 setattr(migrate, "running_folder", saved[1])))
        # found, not given: nothing is done without a yes
        with self.assertRaises(SystemExit):
            self.run_alone()
        self.assertFalse((self.new / "data").exists())
        code, out = self.run_alone("--yes")
        self.assertEqual(code, 0)
        self.assertIn("from 0.2.1", out)

    def test_with_nothing_given_and_nothing_running_it_says_how(self):
        saved = migrate.running_folder
        migrate.running_folder = lambda: None
        self.addCleanup(setattr, migrate, "running_folder", saved)
        with self.assertRaises(SystemExit) as stop, \
                contextlib.redirect_stderr(io.StringIO()):
            self.run_alone()
        self.assertIn("Name it", str(stop.exception.code))

    def test_only_a_yes_goes_ahead(self):
        class Terminal(io.StringIO):
            def isatty(self):
                return True
        saved = migrate.sys.stdin
        migrate.sys.stdin = Terminal()
        self.addCleanup(setattr, migrate.sys, "stdin", saved)
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertTrue(migrate.confirmed("?", ask=lambda _q: "oui"))
            self.assertFalse(migrate.confirmed("?", ask=lambda _q: ""))

            def gone(_q):
                raise EOFError
            self.assertFalse(migrate.confirmed("?", ask=gone))

    def test_a_folder_that_is_not_datagora_is_refused(self):
        with self.assertRaises(SystemExit):
            migrate.main([str(self.old), str(self.old.parent)])


if __name__ == "__main__":
    unittest.main()
