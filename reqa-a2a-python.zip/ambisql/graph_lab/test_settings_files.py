"""Files dropped on the settings page: what is accepted, refused and kept.

No database and no server: the schema a file is compared with is given
directly, and the store lives in a temporary folder."""

import json
import os

# the column index is on by default; a test never builds one in a real
# Qdrant, and the tests that need one give it directly
os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
import pathlib
import sys
import tempfile
import unittest

os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"
from unittest.mock import patch

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "ui"))

import settings_api as api
import settings_store as store

KB = {"books": {"label": "Books", "columns": {
          "book_id": {"type": "int", "description": "the key"},
          "status": {"type": "enum", "description": "where the copy is",
                     "values": {"AV": "available", "LN": "lent"}}},
          "sample_queries": [{"question": "how many books are lent?",
                              "sql": "SELECT COUNT(*) FROM books WHERE status='LN'"}]},
      "authors": {"label": "Authors", "columns": {
          "author_id": {"type": "int", "description": "the key"}}}}
SCHEMA = {"books": {"book_id", "status"}, "authors": {"author_id"}, "loans": {"loan_id"}}


def check(content, schema=SCHEMA):
    database = api.DatabaseTest(host="db", database="lib")
    with patch.object(api, "_schema", return_value=(schema, None)):
        return api.check_content(content, database)


class FileCheckTests(unittest.TestCase):

    def test_a_knowledge_base_is_read_and_compared(self):
        r = check(KB)
        self.assertTrue(r["ok"])
        self.assertEqual(r["kind"], "descriptions")
        self.assertIn("2 tables", r["summary"])
        self.assertEqual(r["checked"], "lib, 3 tables")
        # the one table of the database it does not describe is said
        self.assertTrue(any("loans" in w for w in r["warnings"]))

    def test_what_the_database_does_not_have_is_named(self):
        stale = json.loads(json.dumps(KB))
        stale["books"]["columns"]["isbn_old"] = {"type": "varchar", "description": "gone"}
        stale["archive"] = {"columns": {"id": {"type": "int"}}}
        warnings = " ".join(check(stale)["warnings"])
        self.assertIn("books.isbn_old", warnings)
        self.assertIn("archive", warnings)

    def test_a_view_left_out_is_a_note_not_a_warning(self):
        # a view is a stored query, used from its columns like a table; a
        # dictionary that does not describe it has forgotten nothing
        schema = api._Schema({**SCHEMA, "active_summary": {"sku"}})
        schema.views = frozenset({"active_summary"})
        r = check(KB, schema=schema)
        self.assertTrue(r["ok"])
        self.assertFalse(any("active_summary" in w for w in r["warnings"]))
        self.assertTrue(any("active_summary" in n for n in r["notes"]))
        self.assertTrue(any("loans" in w for w in r["warnings"]))     # a table still is
        self.assertEqual(r["checked"], "lib, 3 tables and 1 view")

    def test_the_file_of_another_database_is_refused(self):
        r = check(KB, schema={"shipments": {"id"}, "warehouses": {"id"}})
        self.assertFalse(r["ok"])
        self.assertIn("describes another one", r["problems"][0])

    def test_a_file_that_is_no_dictionary_is_refused_without_a_connection(self):
        with patch.object(api, "_schema") as schema:
            r = api.check_content({"hello": "world"}, api.DatabaseTest(host="db", database="lib"))
        self.assertFalse(r["ok"])
        schema.assert_not_called()
        self.assertEqual(r["warnings"], [])

    def test_json_that_is_not_an_object_is_refused(self):
        self.assertFalse(api.check_content([1, 2, 3])["ok"])

    def test_a_vocabulary_is_recognised_by_its_lists(self):
        r = api.check_content({"judgements": ["overdue", "late"], "label_words": ["titre"]})
        self.assertTrue(r["ok"])
        self.assertEqual(r["kind"], "vocabulary")
        self.assertIn("3 words", r["summary"])

    def test_a_vocabulary_list_must_hold_words(self):
        r = api.check_content({"judgements": "overdue"})
        self.assertFalse(r["ok"])

    def test_without_a_database_the_file_is_still_read(self):
        r = api.check_content(KB, None)
        self.assertTrue(r["ok"])
        self.assertIsNone(r["checked"])


class KeptFileTests(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        env = patch.dict("os.environ", {"DATAGORA_DATA_DIR": self.tmp.name})
        env.start()
        self.addCleanup(env.stop)
        store._SET_HERE.clear()
        store._BEFORE.clear()

    def test_a_kept_file_is_named_relative_to_the_data_folder(self):
        named = store.keep_file("datagora lib", "descriptions", KB)
        self.assertEqual(named, "files/datagora_lib.descriptions.json")
        # the same name finds it here, and would under /data in the container
        found = pathlib.Path(store.file_path(named))
        self.assertTrue(found.is_file())
        self.assertEqual(json.loads(found.read_text(encoding="utf-8")), KB)

    def test_a_profile_points_at_the_kept_file(self):
        named = store.keep_file("lib", "descriptions", KB)
        store.update("databases", [{"name": "lib", "database": "lib", "descriptions": named}])
        prof = store.profiles_document()["profiles"]["lib"]
        self.assertTrue(pathlib.Path(prof["descriptions"]).is_file())

    def test_how_an_indexing_ended_survives_a_restart(self):
        from types import SimpleNamespace

        rec = SimpleNamespace(
            index=lambda examples, progress=None: {"indexed": 2, "removed": 0, "reembedded": 0},
            size=lambda: 2)
        job = {"state": "running", "done": 0, "total": 2, "collection": "lib_corpus"}
        with patch.dict("os.environ", {"DATAGORA_COLUMN_INDEX": "off"}):
            api._run_index("lib", rec, [{"question": "q"}], job)
        api._INDEXING.clear()                      # what a restart forgets
        state = api.index_state("lib")
        self.assertEqual(state["state"], "done")
        self.assertEqual(state["indexed"], 2)

    def test_an_indexing_stopped_by_the_page_says_so_and_keeps_what_it_wrote(self):
        from types import SimpleNamespace

        job = {"state": "running", "done": 0, "total": 4, "collection": "lib_corpus"}

        def index(examples, progress=None):
            progress(1, 4)
            job["cancel"] = True              # the page's Stop, between two batches
            progress(2, 4)
            raise AssertionError("went on after the stop")

        rec = SimpleNamespace(index=index, size=lambda: 2)
        with patch.dict("os.environ", {"DATAGORA_COLUMN_INDEX": "on"}):
            api._run_index("lib", rec, [{"question": "q"}] * 4, job)
        self.assertEqual(job["state"], "stopped")
        self.assertEqual(job["done"], 2)
        self.assertNotEqual(job.get("phase"), "columns")   # no half-built column index
        self.assertNotIn("cancel", job)

    def test_an_indexing_cut_by_a_restart_is_said_unfinished(self):
        api._keep_ended("lib", {"state": "running", "done": 1, "total": 9})
        api._INDEXING.clear()
        state = api.index_state("lib")
        self.assertEqual(state["state"], "failed")
        self.assertIn("index it again", state["error"])

    def test_a_path_typed_by_hand_is_left_to_the_usual_search(self):
        self.assertEqual(store.file_path("examples/kb_library.json"), "examples/kb_library.json")


if __name__ == "__main__":
    unittest.main()
