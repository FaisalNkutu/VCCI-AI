"""The facts an agent's conclusion rests on, checked against the database.

Facts are settled by the database, never by the model: a table or a
column exists, a value is stored, two tables join, two readings give
different results, something is absent from the whole database. Meaning
is settled by the model, with the facts in front of it.

A conclusion the facts contradict goes back to the agent once, with the
facts and never with its own previous verdict (a model that sees its draft
repeats its mistakes). After that the code decides, always in the careful
direction: towards NEEDS MORE, never a refusal it did not verify. Every
change the code makes to the agent's conclusion is recorded as a
coercion in the trace.
"""

from __future__ import annotations

import datetime
import re
from dataclasses import dataclass, field

if __package__:
    from . import wording
    from .ambisql import TYPES, Clarifier, Option, Outcome
    from .verdict_notebook import clip
    from .verdict_tools import NUMBER_TYPES as _ALL_NUMBERS
    from .verdict_tools import strip_comments
else:
    import wording
    from ambisql import TYPES, Clarifier, Option, Outcome
    from verdict_notebook import clip
    from verdict_tools import NUMBER_TYPES as _ALL_NUMBERS
    from verdict_tools import strip_comments


VERDICTS = ("ANSWER", "CHOICE", "NEEDS_MORE", "NOT_COVERED", "NO_DATA")
ISSUES = ("choice", "asker_must_say", "absent_from_database", "no_matching_row")
# the most severe issue wins; the others are said in the reason. A value
# missing from the data hides behind a net-or-gross choice (E34): the
# asker cannot answer the choice usefully until the value exists.
SEVERITY = {"absent_from_database": 4, "asker_must_say": 3,
            "no_matching_row": 2, "choice": 1}
KIND_OF_ISSUE = {"choice": "AmbiSchema", "asker_must_say": "AmbiContext",
                 "absent_from_database": "AmbiFallacy", "no_matching_row": "AmbiValue"}
# the kinds a model may give an issue of each type; any other is replaced
# by the type's own, so the kind column of a run never holds a guess that
# contradicts the verdict
COMPATIBLE_KINDS = {"choice": {"AmbiSchema", "AmbiValue", "AmbiView"},
                    "asker_must_say": {"AmbiContext", "AmbiRef", "AmbiSource", "AmbiView"},
                    "absent_from_database": {"AmbiFallacy", "AmbiSource"},
                    "no_matching_row": {"AmbiValue"}}

# the reading's time kinds checked against time_columns facts
TIMED = ("as_of", "sequence", "duration", "first_last")
# a duration asked in units finer than a day needs a time of day
FINE_UNITS = re.compile(r"\b(hours?|minutes?|seconds?|hrs?|mins?|heures?|secondes?)\b"
                        # "48 h", "2h", "30 min", never "the 1990s"
                        r"|\d\s?(?:h|hrs?|min|mins|sec|secs)\b", re.IGNORECASE)
MAX_TIME_TABLES = 3
# a check_sql that counts: its one row is the count of matching rows
COUNTING = re.compile(r"^\s*select\s+count\s*\(", re.IGNORECASE)
# what a swept term may be: a few words, never a sentence
MAX_TERM_WORDS = 6
# words of a phrase never worth looking up as a stored value
STOPWORDS = frozenset("""a an the of in on at to for by with from and or not no is are was
were be been has have had do does did what which who whom whose how when where why
many much most least more less top total number count sum average per each every
all any some our their its this that these those than then there here it they we
you your my me us them""".split())
MAX_STORED_WORDS = 3
# a term swept for an absence: the distinctive words first, a sentence never
SHORT_TERM_WORDS = 3
# two spellings of one word: equal, or one the start of the other on at
# least this many letters ("resolve" and resolved_at)
SAME_STEM = 5
# a string literal of a reading's SQL
_LITERAL = re.compile(r"'((?:[^']|'')*)'")
# evidence that points at a neighbourhood, not at the thing: a description
# or a meaning close to the words ("free" in "Free-form JSON attributes"
# for "gluten free"); the model is then shown the values before a denial.
# Never a table's own name: a "no" must not refuse a table that exists
WEAK_EVIDENCE = ("described", "about", "similar")
# a date column keeps a value per date when several rows share each date
# (rates of each currency at each month end); about one row per date
# dates the row itself (employees.hire_date)
SERIES_ROWS_PER_DATE = 2.0
SERIES_ROWS = 20000           # the rows read to count them, when no profile says
# a check with no WHERE, HAVING nor JOIN counts a table, not the thing
# asked; a JOIN keeps only the rows that join, a condition (23 October)
_CONDITION = re.compile(r"\b(?:WHERE|HAVING|JOIN)\b", re.IGNORECASE)
# a period counted from today and nothing else: last year, this month. Not a
# year said in full (the 2027 rates may be what is missing), nor a fiscal
# period, whose start only the deployment knows (review of 23 October)
_CALENDAR = re.compile(r"\b(?:last|this|previous|past|current) (?:year|quarter|month|week)\b",
                       re.IGNORECASE)
# "ever", "at any time": the past as a whole, not a state at a date
_EVER = re.compile(r"\b(?:ever|at any (?:time|point))\b", re.IGNORECASE)
# a question in the past, which asks when even with no date
_PAST = re.compile(r"\b(?:was|were|had|did|used to|became|went)\b", re.IGNORECASE)
# words that say when a state kept over time is read: today's, or the one
# in force at the time of each record
_STATE_WHEN = re.compile(r"\b(?:at the time|at that time|when (?:they|it|he|she|we|the)\b"
                         r"|then|currently|current|today|now|still|as of|on the date"
                         r"|at the date|at present|presently)\b", re.IGNORECASE)
# a state asked of the past, "were ever in Sales", "has ever been": a history
# is needed after all (review of the fixes: it was spared one)
_EVER_STATE = re.compile(r"\b(?:was|were|is|are|be|been|being)\s+(?:\w+\s+)?ever\b"
                         r"|\bever\s+(?:been|be|was|were)\b", re.IGNORECASE)
# a length of time the question gives: "in the last 30 days", "in the past two
# weeks", "last week", "since 1 March 2026"
_A_LENGTH = re.compile(
    r"\b(?:\d+|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|a|an)\s+"
    r"(?:days?|weeks?|months?|quarters?|years?|hours?)\b"
    r"|\b(?:last|past|previous|this|current)\s+(?:day|week|month|quarter|year)\b"
    r"|\bsince\b|\byesterday\b|\btoday\b", re.IGNORECASE)
# a vague time an ANSWER cannot rest on: never "most recently" nor "least
# recently" (an order), "more recent than 2024" (a reference), "upcoming"
# (after today, which is counted) nor "how soon" (a duration)
_VAGUE_ANSWER = re.compile(
    r"\b(?:(?<!most )(?<!least )recent(?!ly)(?!\s+than)|(?<!most )(?<!least )recently(?!\s+than)"
    r"|lately|of late|nowadays|these days|in the near future|(?<!how )soon)\b", re.IGNORECASE)
# the age words that put the newest first; the others, the oldest
_NEWEST_FIRST = re.compile(r"\b(?:newest|latest|youngest|most recent|last)\b", re.IGNORECASE)
# a built reading of an age word reads at most this many dates
AGE_READINGS = 3
# words ending in -est that rank nothing
NOT_SUPERLATIVE = frozenset("""interest interests request requests forest guest guests test
tests rest west east honest harvest manifest contest protest digest suggest invest chest
nest quest vest crest arrest arrests latest earliest oldest newest""".split())
# words that make the order of the rows the answer: "the oldest products",
# "the top suppliers", "ranked by"
_RANKING = re.compile(r"\b(?:most|least|top|bottom|best|worst|highest|lowest|largest|smallest"
                      r"|biggest|greatest|rank\w*|ordered by|sorted by|in order)\b", re.IGNORECASE)
# what is missing qualified by a clause no column holds by itself: "the
# freight rate after the increase"
_QUALIFIED = re.compile(r"\b(?:after|before|following|once|if|assuming|unless|excluding"
                        r"|without|would)\b", re.IGNORECASE)
# the tools' number types, one list (review of 26 October: two lists had
# drifted apart); a YEAR is no value kept at a date
NUMBER_TYPES = frozenset(_ALL_NUMBERS) - {"year"}


def matching_rows(result, sql):
    """How many rows match, from a run_count result, or None when it is
    not known: a count the database could not give is never zero.

    run_count says how many rows the SELECT returned. A check written as
    SELECT COUNT(*) returns one row holding the count; that number is what
    the check means, not the 1 row it came in. When the total is unknown
    but some rows were read, they are a lower bound: more than none."""
    data = getattr(result, "data", None) or {}
    n = data.get("count")
    if n is None:
        bound = data.get("lower_bound") or len(data.get("rows") or [])
        return bound if bound else None
    rows, cols = data.get("rows") or [], data.get("columns") or []
    if COUNTING.match(str(sql or "")) and n == 1 and len(cols) == 1 and rows:
        try:
            return int(float(str(rows[0][0]).replace(",", "")))
        except (TypeError, ValueError, IndexError):
            return n
    return n


def _words(text):
    # letters of any alphabet: split on ASCII alone, "café" became "caf"
    # and "récents" two words (review of 26 October)
    return [w for w in re.split(r"[\W]+", str(text or "")) if w]


def _same_word(a, b):
    """One word in two spellings: equal, or one the start of the other on
    SAME_STEM letters or more ("resolve", "resolved")."""
    if len(a) < 3 or len(b) < 3:
        return False
    if a == b:
        return True
    return min(len(a), len(b)) >= SAME_STEM and (a.startswith(b) or b.startswith(a))


@dataclass
class Checked:
    outcome: Outcome | None
    feedback: list
    checks: list
    coercions: list = field(default_factory=list)


# a property of the records, which nobody can type in: when the thing is
# held and this of it is not, the data must record it
_RECORD_PROPERTY = re.compile(
    r"\b(?:time|times|hour|hours|minute|minutes|timestamps?|clock|evening|morning|night"
    r"|date|dates|day of|when|log|logged|link|linked|trigger|triggered|cause|caused|reason"
    r"|history|start|end|ended|began|before|after)\b", re.IGNORECASE)

def _day_of(value):
    """A date from a value time_columns shows ("2026-02-01 08:00:00"), or None."""
    try:
        return datetime.date.fromisoformat(str(value or "")[:10])
    except ValueError:
        return None


_MONTH_NAMES = ("january", "february", "march", "april", "may", "june", "july", "august",
                "september", "october", "november", "december")
# the same months in French, by their number
_MOIS = ("janvier", "f\u00e9vrier", "mars", "avril", "mai", "juin", "juillet",
         "ao\u00fbt", "septembre", "octobre", "novembre", "d\u00e9cembre")


def _month(name):
    name = str(name or "").lower().rstrip(".")
    for names in (_MONTH_NAMES, _MOIS):
        if name in names:
            return names.index(name) + 1
    return None


def _month_end(year, month):
    nxt = datetime.date(year + (month == 12), month % 12 + 1, 1)
    return nxt - datetime.timedelta(days=1)


def _asked_date(question, today=None):
    """The date a question asks the state at, or None: "on 1 March 2025",
    "as of March 1, 2025", "at the end of June 2025" (its last day),
    "2025-03-01", "at the end of 2024", "au 1er mars 2025", "fin juin 2025",
    "03/15/2025" when the day cannot be the month. "At the end of June"
    with no year is the last June that has ended by `today` (review of 26
    October: these returned None, and any history then passed)."""
    q = str(question or "").lower()
    m = re.search(r"\b(\d{4})-(\d{2})-(\d{2})\b", q)
    if m:
        try:
            return datetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            return None
    m = re.search(r"\b(\d{1,2})/(\d{1,2})/(\d{4})\b", q)
    if m:
        a, b, year = int(m.group(1)), int(m.group(2)), int(m.group(3))
        # 03/01/2025 is March or January depending on who wrote it: only a
        # day above 12 says which
        day, month = (a, b) if a > 12 else (b, a) if b > 12 else (None, None)
        try:
            return datetime.date(year, month, day) if day else None
        except ValueError:
            return None
    months = "|".join(_MONTH_NAMES + _MOIS)
    m = (re.search(r"\b(\d{1,2})(?:st|nd|rd|th|er)?\s+(?:of\s+)?(" + months + r")\.?,?\s+(\d{4})\b", q)
         or re.search(r"\b(" + months + r")\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})\b", q))
    if m:
        g = m.groups()
        day, month, year = (g[0], g[1], g[2]) if g[0].isdigit() else (g[1], g[0], g[2])
        try:
            return datetime.date(int(year), _month(month), int(day))
        except (TypeError, ValueError):
            return None
    # the first "end of" that says a month or a year: "at the end of the day"
    # comes before "at the end of June 2025" (review of the fixes)
    m = next((x for x in re.finditer(r"\b(?:end of|fin(?: de| d')?)\s*(?:(" + months
                                     + r")\s*)?(\d{4})?\b", q)
              if x.group(1) or x.group(2)), None)
    if m:
        month = _month(m.group(1)) if m.group(1) else 12
        if m.group(2):
            return _month_end(int(m.group(2)), month)
        # no year: the last such month to have ended by today
        today = today or datetime.date.today()
        end = _month_end(today.year, month)
        return end if end < today else _month_end(today.year - 1, month)
    return None


# words a "what" names a form with, beyond Clarifier.GENERIC_WORDS
SWEEP_GENERIC = {"details", "records", "figures", "figure", "statistics", "statistic",
                 "stats", "metrics", "metric", "numbers", "values", "info"}

# what a time check finds missing, said without a column
TIME_MISSING = {"as_of": "the past values (only the current one is kept)",
                "duration": "the time of day of each moment",
                "sequence": "the order of the events",
                "first_last": "the order of the events"}


def _time_words(question, kind):
    """The words of the question that ask about time, for a time issue."""
    pattern = {"as_of": wording.POINT_IN_TIME, "duration": FINE_UNITS}.get(kind, wording.SEQUENCE)
    m = pattern.search(str(question or "")) if pattern is not None else None
    return m.group(0).strip() if m else ""


class Verifier:
    """Checks one conclusion; see the module's docstring."""

    def __init__(self, view, tools, settings, meaning=None, weigh=None, left=None,
                 rank=None):
        """meaning(question, phrase, readings) -> (index, why) | None: the
        closed question on the wording of a choice the facts confirmed,
        asked of a model in a fresh context (VerdictAgent._wording). None
        leaves choices to the facts alone.

        rank(question, phrase, thing) -> "ranking" | "thing" | None: the
        closed question on a phrase said absent that neither the age words
        nor the form of a ranking settle ("popular books"): does it rank the
        things the database holds, or name a thing it would have to store
        (VerdictAgent._rank). None: the phrase is looked for as it is.

        weigh(term, columns, question) -> (verdict, why): can the term be
        read off these columns' real values, "yes", "no" or "unknown"
        (VerdictAgent._weigh, bounded). None: no denial rests on values.

        left() -> seconds: the question's time still left. Past it, the
        lookups that only add to what is known are skipped and the check
        goes the careful way (review of 26 October: the verifier ran its
        sweeps again in the last round, with no deadline at all)."""
        self.view = view
        self._left = left or (lambda: float("inf"))
        self.tools = tools
        self.settings = settings
        self.meaning = meaning
        self.weigh = weigh
        self.rank = rank
        self._ranked = {}          # the ranking answers of this question
        self._weighed = {}         # the values answers of this question
        self._question = ""
        self._reading = {}
        # tables read by a reading set aside and by nothing else: no column
        # of the conclusion, no reading kept
        self._aside = set()
        self._worded = {}          # the wording answers of this question
        self._view_names = None
        # the asker's day, which "at the end of June" with no year is read by
        self.today = getattr(getattr(tools, "clar", None), "today", None)

    def _late(self):
        try:
            return self._left() <= 0
        except Exception:
            return False

    # ---------------------------------------------------------- entry
    def check(self, conclusion, nb, final):
        checks, feedback, coercions = [], [], []
        self._question = str(getattr(nb, "question", "") or "")
        self._reading = getattr(nb, "reading", None) or {}
        self._steps = list(getattr(nb, "steps", None) or [])
        self._aside = set()
        c = self._canonical(conclusion, feedback, checks)
        issues = list(c["issues"])
        declared = c["verdict"]
        if not issues and declared != "ANSWER":
            synth = self._from_declared(c, declared)
            feedback.append(
                f"your conclusion says {declared.replace('_', ' ').lower()} but names no "
                "issue: give the issue, with the words of the question that raise it "
                "(phrase), what is missing in a few words (what), and its readings or "
                "check_sql")
            if not final:
                return Checked(None, feedback, checks, coercions)
            if synth is not None:
                issues = [synth]
                coercions.append({"from": "none", "to": synth["type"],
                                  "why": f"declared {declared} without an issue"})

        kept, notes = [], []
        for issue in issues:
            decision = self._check_issue(issue, c, final, feedback, checks)
            if decision == "keep":
                kept.append(issue)
            elif decision[0] == "downgrade":
                kept.append(decision[1])
                coercions.append({"from": issue["type"], "to": decision[1]["type"],
                                  "why": decision[2]})
            elif decision[0] == "drop":
                if decision[1]:
                    notes.append(decision[1])
                if final or decision[1]:
                    coercions.append({"from": issue["type"], "to": "dropped",
                                      "why": decision[1] or "the facts contradict it"})

        vague = self._vague_time(kept)
        if vague:
            # "borrowed recently" says no length of time, and nothing in the
            # database does either; an ANSWER on it passed unchecked
            # (review of 26 October)
            checks.append({"check": "vague_time", "status": "failed", "detail": vague})
            feedback.append(f"\"{vague}\" gives no length of time: where it begins is the "
                            "asker's to say, unless the question gives it; say so as "
                            "asker_must_say")
            if final:
                kept.append(dict(self._issue("asker_must_say", vague,
                                             f"how far back \"{vague}\" reaches",
                                             "AmbiContext"), _gap="asker"))
                coercions.append({"from": "none", "to": "asker_must_say",
                                  "why": f"{vague}: a vague time"})

        if not issues:
            # an answer that sorts by age, or ranks, on one column while
            # others could: compared before it stands (Warehouse Q10, and
            # Q09's choice lost under v6, review of 26 October)
            aged = self._age_answer(c, nb, final, feedback, checks)
            if aged is not None and aged[0] == "downgrade":
                kept.append(aged[1])
                coercions.append({"from": "none", "to": "choice", "why": aged[2]})
            elif aged is not None and aged[0] == "drop" and aged[1]:
                notes.append(aged[1])
            self._ranked_answer(nb, final, feedback, checks)
            self._state_over_time(c, final, feedback, checks)
            self._repeated_event(c, nb, final, feedback, checks)

        self._check_joins(c, final, feedback, checks)

        timed = self._check_time(c, kept, nb, final, feedback, checks)
        if timed is not None:
            kept.append(timed)
            coercions.append({"from": "none", "to": "asker_must_say", "why": timed["what"]})

        # the tables of an answer or a choice must join
        if not any(i["type"] in ("absent_from_database", "asker_must_say") for i in kept):
            # a view has no key to join by, and a table only a reading that
            # was set aside read is no table of the answer
            tables = [t for t in self._tables_used(c)
                      if t not in self._aside and not self._is_view(t)]
            if len(tables) > 1:
                ok, cut_off = self._connected(tables)
                checks.append({"check": "join", "status": "ok" if ok else "failed",
                               "detail": ", ".join(cut_off)})
                if not ok:
                    feedback.append(
                        f"no join was found between {tables[0]} and {', '.join(cut_off)}; "
                        "call join_path before concluding they do not join")
                    if final:
                        what = (f"how {tables[0]} relates to {', '.join(cut_off)}, "
                                "which no join in the database connects")
                        # a link the schema lacks, not words the asker can type
                        # in (review of 26 October)
                        kept.append(dict(self._issue("asker_must_say", "", what, "AmbiSchema"),
                                         _gap="data"))
                        coercions.append({"from": "none", "to": "asker_must_say", "why": what})

        if feedback and not final:
            return Checked(None, feedback, checks, coercions)
        return Checked(self.to_outcome(kept, c, notes), feedback, checks, coercions)

    # ------------------------------------------------------ the issues
    def _check_issue(self, issue, c, final, feedback, checks):
        """"keep", ("drop", note) or ("downgrade", issue, why)."""
        kind = issue["type"]
        if kind == "choice":
            return self._check_choice(issue, c, final, feedback, checks)
        if kind == "asker_must_say":
            return self._check_asker(issue, c, final, feedback, checks)
        if kind == "absent_from_database":
            return self._check_absent(issue, final, feedback, checks, c)
        if kind == "no_matching_row":
            return self._check_no_row(issue, final, feedback, checks)
        return ("drop", "")

    def _check_choice(self, issue, c, final, feedback, checks):
        readings = [r for r in issue.get("readings") or [] if str(r.get("sql") or "").strip()]
        given = len(readings)
        # a reading whose table joins none of the question's tables cannot
        # answer it: it goes back once, then it is set aside
        start = (c.get("tables") or [None])[0]
        if start:
            joined = []
            for r in readings:
                t = self.view.table(r.get("table") or "") if r.get("table") else None
                ok = True
                if t and t != start and not self._is_view(t) and not self._is_view(start):
                    ok, _cut = self._connected([start, t])
                if ok:
                    joined.append(r)
                else:
                    feedback.append(f"reading {r.get('label')} reads {t}, which no join "
                                    f"connects to {start}; call join_path or drop it")
                    checks.append({"check": "choice_join", "status": "failed",
                                   "detail": f"{start} - {t}"})
            if len(joined) < len(readings):
                if not final:
                    return "keep"
                used = {self.view.table(r.get("table") or "") for r in joined}
                used |= {col.get("table") for col in c.get("columns") or []}
                for r in readings:
                    t = self.view.table(r.get("table") or "") if r.get("table") else None
                    if r not in joined and t and t not in used:
                        self._aside.add(t)
                readings = joined
        phrase = issue.get("phrase") or issue.get("what")
        if len(readings) < 2:
            feedback.append(f"a choice on \"{phrase}\" needs at least two readings, each with "
                            "the SQL that answers the question that way: look for every column "
                            "that could measure it (find_columns on the word, and on the tables "
                            "one key away)")
            checks.append({"check": "choice", "status": "failed",
                           "detail": "fewer than two readings"})
            if not final:
                return "keep"
            if given >= 2 and len(readings) == 1:
                # the others could not answer the question, joining none of
                # its tables: the one left is the answer, a fact, no choice
                return ("drop", "")
            if given >= 2:
                return self._unconfirmed(issue, "no reading joins the question's tables")
            return self._unconfirmed(issue, "fewer than two readings")
        res = self._call(self.tools.compare_readings, [r["sql"] for r in readings])
        if not getattr(res, "ok", False) and len(readings) > 2:
            # one reading that cannot run must not sink the others: each is
            # tried on its own, the ones that fail are set aside and said
            runnable = []
            for r in readings:
                alone = self._call(self.tools.run_count, r["sql"])
                if getattr(alone, "ok", False):
                    runnable.append(r)
                else:
                    why = clip(getattr(alone, "error", "") or "it failed", 160)
                    feedback.append(f"reading {r.get('label')} could not run: {why}")
                    checks.append({"check": "choice_reading", "status": "failed",
                                   "detail": f"{r.get('label')}: {why}"})
            if 2 <= len(runnable) < len(readings):
                readings = runnable
                res = self._call(self.tools.compare_readings, [r["sql"] for r in readings])
        if not getattr(res, "ok", False):
            feedback.append(f"the readings of \"{phrase}\" could not be run: "
                            f"{clip(getattr(res, 'error', '') or 'the comparison failed', 200)}")
            checks.append({"check": "choice", "status": "failed",
                           "detail": "readings did not run: "
                                     + clip(getattr(res, "error", "") or "the comparison failed", 160)})
            return self._unconfirmed(issue, "the readings could not be run") if final else "keep"
        data = res.data or {}
        # the same rows in another order differ only when the question asks
        # for an order ("the oldest products"): an ORDER BY for display
        # separates nothing (review of the fixes)
        ordered = self._asks_order()
        pairs = [dict(p, same=False, only_a=p["order_moved"], only_b=p["order_moved"],
                      share=p.get("order_share") or 0)
                 if p.get("same") and p.get("order_moved") and ordered else p
                 for p in data.get("pairs") or []]
        counts = {r.get("i"): r.get("count") for r in data.get("results") or []}
        for i, r in enumerate(readings):
            r["_count"] = counts.get(i)
        # readings that give the same rows are one reading
        same_as = {}
        for p in pairs:
            if p.get("same") and p.get("b") not in same_as and p.get("a") not in same_as:
                same_as[p["b"]] = p["a"]
        distinct = [i for i in range(len(readings)) if i not in same_as]
        tol = float(getattr(self.settings, "choice_tolerance", 0.01) or 0)
        small = [p for p in pairs
                 if not p.get("same") and not p.get("undetermined")
                 and p.get("a") in distinct and p.get("b") in distinct
                 and float(p.get("share") or 0) < tol]
        undetermined = [p for p in pairs if p.get("undetermined")]

        def label(i):
            return readings[i].get("label") if 0 <= i < len(readings) else i
        checks.append({"check": "choice", "status": "compared", "detail": "; ".join(
            f"{label(p['a'])} vs {label(p['b'])}: "
            + ("same rows" if p.get("same") else "undetermined" if p.get("undetermined") else
               f"differ on {int(p.get('only_a') or 0) + int(p.get('only_b') or 0)} rows "
               f"({100 * float(p.get('share') or 0):.1f}%)")
            for p in pairs)})
        if len(distinct) < 2:
            rows = readings[0].get("_count")
            note = (f"the readings of \"{phrase}\" coincide on current data"
                    + (f" ({rows} rows)" if rows is not None else ""))
            if getattr(self.settings, "same_result", "answer") == "choice":
                return "keep"
            return ("drop", note)       # a fact the database settles
        selected = self._selected_by_wording(issue, [readings[i] for i in distinct], checks)
        if selected is not None:
            return ("drop", selected)    # the words settle it, the data could not
        if small and not final:
            p = small[0]
            feedback.append(
                f"readings {label(p['a'])} and {label(p['b'])} differ on "
                f"{int(p.get('only_a') or 0) + int(p.get('only_b') or 0)} rows out of "
                f"{counts.get(p['a'])} and {counts.get(p['b'])}: decide whether the wording "
                "already selects one, or whether the asker must choose")
            return "keep"
        if undetermined and not final:
            feedback.append("some readings return more rows than can be compared one by one "
                            "and the same count: compare an aggregate of each (a total, a "
                            "count per group) to tell whether they differ")
            return "keep"
        issue["readings"] = [readings[i] for i in distinct]
        return "keep"

    def _check_joins(self, c, final, feedback, checks):
        """Each join the conclusion names ("a.x = b.y", several joined by
        AND) on columns that exist. The prompt asks for them and nothing
        read them (review of 26 October). Said back before the last round,
        recorded in it; the tables' own connection is checked apart."""
        bad = []
        for join in c.get("joins") or []:
            for a, b in re.findall(r"([\w.]+)\s*=\s*([\w.]+)", str(join or "")):
                for side in (a, b):
                    if side.count(".") != 1:
                        continue
                    table, column = side.split(".")
                    real = self.view.table(table)
                    if real and not self._has(real, column):
                        bad.append(f"{real}.{column}")
        if not bad:
            return
        checks.append({"check": "join_columns", "status": "failed", "detail": ", ".join(bad[:4])})
        if not final:
            feedback.append(f"the joins name columns that do not exist: {', '.join(bad[:4])}; "
                            "join on the keys join_path gives")

    def _asks_order(self):
        """Whether the question makes the order of the rows its answer."""
        q = self._question
        return bool(wording.ORDERED_BY_AGE.search(q) or _RANKING.search(q))

    def _vague_time(self, kept):
        """The vague time word of the question ("recently") when no issue
        kept speaks of it and the question gives no length; else ""."""
        m = _VAGUE_ANSWER.search(self._question)
        if not m or _A_LENGTH.search(self._question):
            return ""
        word = m.group(0).lower()
        for i in kept:
            said = f"{i.get('phrase') or ''} {i.get('what') or ''}".lower()
            if word in said or wording.VAGUE_TIME.search(said):
                return ""
        return m.group(0)

    def _unconfirmed(self, issue, why):
        """A choice the agent saw and the facts could not settle: never an
        answer, which is what dropping it gave (review of 26 October:
        unsure is NEEDS MORE). The asker says which reading they mean."""
        what = (f"which reading of \"{issue.get('phrase') or issue.get('what')}\" is meant "
                f"({why})")
        return ("downgrade", dict(issue, type="asker_must_say", kind="AmbiContext", what=what,
                                  readings=[]), why)

    def _check_asker(self, issue, c, final, feedback, checks):
        said = issue.get("phrase") or issue.get("what")
        sql = str(issue.get("check_sql") or "").strip()
        period = self._calendar_period(issue.get("phrase"), issue.get("what"))
        if period and sql:
            # the period is today's to settle, the rows the data's: a check
            # finding none says the data stops before it (review of 26
            # October: the period was dropped before the check was run)
            res = self._call(self.tools.run_count, sql)
            n = matching_rows(res, sql) if getattr(res, "ok", False) else None
            if n == 0:
                checks.append({"check": "asker_must_say", "status": "counted",
                               "detail": f"{period}: no row of the period"})
                issue["_confirmed"] = True
                issue["_gap"] = "data"
                return "keep"
        if period:
            # "What was our revenue last year?": last year is 2025, today
            # says so. Asked, the asker picked 2025 and was then asked what
            # revenue meant, the question to ask first (E36, 23 October)
            checks.append({"check": "asker_must_say", "status": "period",
                           "detail": f"{period}: a calendar period, settled by today's date"})
            if not final:
                feedback.append(f"\"{period}\" is a calendar period, settled by today's date: "
                                "the asker has nothing to say about it. If the measure can be "
                                "read in more than one way, that is a choice with its readings")
                return "keep"
            return ("drop", "")
        phrase = str(issue.get("phrase") or "")
        if wording.ORDERED_BY_AGE.search(phrase) and not wording.VAGUE_TIME.search(phrase) \
                and self._age_only(phrase):
            # "our newest suppliers" asks for no number and no window: the
            # order is the answer, by one of their dates (Warehouse Q11 was
            # asked how many, review of 26 October)
            checks.append({"check": "asker_must_say", "status": "ordered_by_age",
                           "detail": f"{phrase} orders by a date"})
            if not final:
                feedback.append(f"\"{phrase}\" orders them by one of their dates: no number "
                                "and no window is needed, the order is the answer. Look at "
                                "their dates (time_columns), and when more than one could be "
                                "meant, give each as a reading of a choice")
                return "keep"
            built = self._by_age(phrase, c, final, feedback, checks)
            if built is not None:
                return built
        if self._is_threshold(issue) or wording.VAGUE_TIME.search(
                str(issue.get("phrase") or "")):
            # where "cheap" begins is the asker's to say: rows coming back
            # from the agent's query never say it (Q12 listed ten cheapest
            # products, and the threshold was taken for data). Only a value
            # stored under that word settles it, checked below.
            checks.append({"check": "asker_must_say", "status": "threshold",
                           "detail": f"{said}: a comparison of the reading, not counted"})
            sql = ""
        theirs = self._the_askers(said)
        if sql and theirs:
            # "with the tariff increase the carriers announced": what the
            # question supposes, or measures from, no row can hold. Counted,
            # SELECT * FROM freight_rates found 102 rows and the gap was
            # dropped (E26, 23 October)
            checks.append({"check": "asker_must_say", "status": "the_askers",
                           "detail": f"{said}: {theirs}, not counted"})
            sql = ""
        if sql and self._counts_a_table(sql, issue):
            # with no condition it counts a table, and a table has rows:
            # SELECT rate FROM freight_rates or SELECT COUNT(*) found 102 and
            # the gap was dropped (E26; review of 26 October). Unless it
            # selects the very column said missing (E32: machine_hours)
            checks.append({"check": "asker_must_say", "status": "no_condition",
                           "detail": "the check has no condition: not counted"})
            sql = ""
        if sql:
            res = self._call(self.tools.run_count, sql)
            n = matching_rows(res, sql) if getattr(res, "ok", False) else None
            if getattr(res, "ok", False) and n is None:
                # could not be counted: the gap stays, unconfirmed
                checks.append({"check": "asker_must_say", "status": "unread",
                               "detail": "the check could not be counted"})
            elif getattr(res, "ok", False):
                checks.append({"check": "asker_must_say", "status": "counted",
                               "detail": f"{n} matching rows"})
                if n:
                    feedback.append(f"for \"{said}\" the check finds {n} matching rows: "
                                    "the data holds it")
                    return ("drop", "") if final else "keep"
                issue["_confirmed"] = True
            else:
                feedback.append(f"the check for \"{said}\" could not run: "
                                f"{clip(getattr(res, 'error', '') or 'it failed', 160)}")
                if not final:
                    return "keep"
        # a word of the phrase stored as a value is no judgement: "high
        # priority" when a column holds HIGH. Only for a short phrase with
        # no number: in "the budget exchange rate finance has set for
        # 2027", BUDGET is stored and the 2027 rates are what is missing
        # (E34, 23 October); what the question supposes is never stored
        content = [w for w in _words(issue.get("phrase")) if w.lower() not in STOPWORDS]
        if theirs or re.search(r"\d", str(issue.get("phrase") or "")) \
                or len(content) > SHORT_TERM_WORDS:
            return "keep"
        if self._late():
            checks.append({"check": "stored_value", "status": "skipped",
                           "detail": "out of time: the gap stays the asker's"})
            return "keep"
        stored = self._stored_words(issue.get("phrase"), self._tables_used(c),
                                    self._entities() | self._reading_nouns())
        if stored:
            t, col, v = stored
            checks.append({"check": "stored_value", "status": "found",
                           "detail": f"{t}.{col} holds {v}"})
            feedback.append(f"{t}.{col} holds the value {v}: \"{issue.get('phrase')}\" "
                            "names stored data, not a judgement")
            return ("drop", "") if final else "keep"
        return "keep"

    def _age_only(self, phrase):
        """Whether the phrase is an age word and the thing it orders, nothing
        else: "oldest", "the newest suppliers", "most recent suppliers",
        "longest-standing customers". Not "the latest firmware version" nor
        "first names", where something else is asked for. Read on the whole
        phrase: a word at a time, "most recent" and "longest standing" never
        matched, and were swept as missing things (review of 26 October)."""
        text = " ".join(_words(phrase))
        if not wording.ORDERED_BY_AGE.search(text):
            return False
        # the catalogue's things only: the reading may name the very thing
        # said absent ("newest patents" with patents among its entities was
        # never swept, review of the fixes)
        entities = self._entities()
        rest = [w for w in _words(wording.ORDERED_BY_AGE.sub(" ", text))
                if w.lower() not in STOPWORDS and Clarifier._singular(w.lower()) not in entities]
        return not rest

    def _held_noun(self, phrase):
        """The thing a phrase qualifies when the database holds it and the
        phrase says more of it ("popular" in "popular books"): its noun, or
        "" when the phrase names nothing held, or nothing but it."""
        entities = self._entities() | self._reading_nouns()
        words = [w.lower() for w in _words(phrase) if w.lower() not in STOPWORDS
                 and not re.search(r"\d", w)]
        held = [w for w in words if Clarifier._singular(w) in entities]
        rest = [w for w in words if Clarifier._singular(w) not in entities]
        return Clarifier._singular(held[-1]) if held and rest else ""

    def _asked_rank(self, phrase, thing):
        """The rank question's answer, asked once per phrase; None when there
        is no model to ask or it could not tell."""
        if self.rank is None:
            return None
        key = (str(phrase).lower(), thing)
        if key not in self._ranked:
            try:
                self._ranked[key] = self.rank(self._question, phrase, thing)
            except Exception:
                self._ranked[key] = None
        return self._ranked[key]

    def _table_of(self, phrase, c):
        """The table whose things a phrase orders: the one named for a noun
        of the phrase ("members"), else the conclusion's first table."""
        names = list(getattr(self.view, "lower", {}) or {})
        for word in reversed([w.lower() for w in _words(phrase or "") if w.lower() not in STOPWORDS]):
            noun = Clarifier._singular(word)
            exact = [n for n in names if Clarifier._singular(n) == noun]
            last = [n for n in names
                    if Clarifier._singular(_words(n.replace("_", " "))[-1].lower()) == noun]
            for found in (exact, last):
                if len(found) == 1:
                    return self.view.table(found[0])
        first = (c.get("tables") or [None])[0]
        return self.view.table(first) if first else None

    def _key_of(self, table):
        """The column naming one row of a table: its own id, else the first."""
        try:
            columns = [col for col, _d in self.view.columns_of(table)]
        except Exception:
            columns = []
        stem = Clarifier._singular(_words(table.replace("_", " "))[-1].lower())
        for col in columns:
            if col.lower() in (f"{stem}_id", "id"):
                return col
        return columns[0] if columns else None

    def _dates_of(self, table, limit=AGE_READINGS):
        """The date columns of a table that hold values, as time_columns
        reads them, at most `limit` (all with None); None when they cannot
        be read."""
        # the probe's own reading of this table, when the agent made one in
        # this question: read again, it was a second query for the same facts
        res = next((getattr(s, "result", None) for s in reversed(getattr(self, "_steps", None) or [])
                    if getattr(s, "tool", None) == "time_columns"
                    and str((getattr(s, "args", None) or {}).get("table") or "").lower()
                    == str(table).lower()
                    and getattr(getattr(s, "result", None), "ok", False)), None)
        if res is None:
            res = self._call(self.tools.run, "time_columns", {"table": table})
        if res is None or not getattr(res, "ok", False) or not isinstance(res.data, dict):
            return None
        found = [m["column"] for m in res.data.get("moments") or []
                 if m.get("column") and not m.get("error")
                 and (m.get("null_share") or 0) < 0.95]
        return found[:limit] if limit else found

    def _by_age(self, phrase, c, final, feedback, checks):
        """An age word over things the database holds ("the oldest members",
        "our newest suppliers"), at the final round: each date of their
        table is a reading of their age, built here and sorted on it. Two or
        more go through a choice's own checks, compared and then worded; a
        single date orders them, and the question is answered by it. A
        decision as _check_issue gives, or None when the dates cannot be
        read: the caller then keeps its careful verdict."""
        table = self._table_of(phrase, c)
        if table is None:
            return None
        dates = self._dates_of(table)
        if not dates:
            return None
        if len(dates) == 1:
            checks.append({"check": "age", "status": "one_date", "detail": f"{table}.{dates[0]}"})
            return ("drop", f"{phrase}: {table} ordered by {dates[0]}, its only date")
        key = self._key_of(table)
        if key is None:
            return None
        order = "DESC" if _NEWEST_FIRST.search(phrase or "") else "ASC"
        readings = [{"label": f"by {d.replace('_', ' ')}", "means": f"{table} ordered by {d}",
                     "table": table, "column": d,
                     "sql": (f"SELECT `{key}` FROM `{table}` WHERE `{d}` IS NOT NULL "
                             f"ORDER BY `{d}` {order}, `{key}` LIMIT 10")} for d in dates]
        built = dict(self._issue("choice", phrase, f"which date orders the {table}",
                                 "AmbiSchema"), readings=readings)
        checks.append({"check": "age", "status": "readings",
                       "detail": f"{table}: {', '.join(dates)}"})
        decision = self._check_choice(built, c, final, feedback, checks)
        if decision == "keep":
            return ("downgrade", built, f"{phrase}: the dates of {table} order it differently")
        return decision

    def _age_answer(self, c, nb, final, feedback, checks):
        """An answer to "the oldest products" that sorts them on one of their
        own dates while they have others (Warehouse Q10: created_at, and
        updated_at never compared). Sent back once to compare them; at the
        final round, compared here (_by_age). None when there is nothing to
        check, or after the feedback."""
        m = wording.ORDERED_BY_AGE.search(self._question)
        if not m:
            return None
        phrase = " ".join([m.group(0)] + _words(self._question[m.end():])[:2])
        if not self._age_only(phrase):
            return None
        table = self._table_of(phrase, c)
        if not table or any(s.tool == "compare_readings"
                            for s in getattr(nb, "steps", None) or []):
            return None
        # the date it sorts on, whatever role the agent gave it: created_at
        # came as a filter in Warehouse Q10 and Q11, and nothing was checked
        # (review of 27 October)
        every = self._dates_of(table, None) or []
        sorted_on = [str(col.get("column")) for col in c.get("columns") or []
                     if self.view.table(col.get("table") or "") == table
                     and str(col.get("column")) in every]
        dates = every[:AGE_READINGS]
        if not sorted_on or len(dates) < 2:
            return None
        checks.append({"check": "age", "status": "answered",
                       "detail": f"{table} sorted on {sorted_on[0]} of {', '.join(dates)}"})
        if not final:
            feedback.append(f"\"{phrase}\" orders the {table} by a date, and {table} has "
                            f"{', '.join(dates)}: compare them (compare_readings, one ORDER BY "
                            f"each) before answering with {sorted_on[0]}. Two that order them "
                            "differently are a choice, unless the question's words select one")
            return None
        return self._by_age(phrase, c, final, feedback, checks)

    def _ranked_answer(self, nb, final, feedback, checks):
        """An answer whose reading ranks ("most reliable", "busiest") with no
        comparison of readings made: sent back once, to look for every
        column that could measure it and compare the two best. The answer
        stands at the final round (review of 26 October, Q09)."""
        if final or any(s.tool == "compare_readings" for s in getattr(nb, "steps", None) or []):
            return
        for comp in self._reading.get("comparisons") or []:
            comp = str(comp or "")
            if not comp or re.search(r"\d", comp) or wording.ORDERED_BY_AGE.search(comp) \
                    or wording.VAGUE_TIME.search(comp):
                continue
            ranked = self._ranking(comp)
            if ranked:
                checks.append({"check": "ranking", "status": "not_compared",
                               "detail": f"{comp}: {ranked}"})
                feedback.append(f"\"{comp}\" ranks {ranked} by a measure: before answering "
                                "with one column, look for every column that could measure it "
                                "(find_columns on the word, on the tables one key away) and "
                                "compare the two best with compare_readings. Two that differ "
                                "are a choice, unless the question's words select one")
                return

    def _compared(self):
        """Whether the agent compared readings in this question."""
        return any(s.tool == "compare_readings" for s in getattr(self, "_steps", None) or [])

    def _state_over_time(self, c, final, feedback, checks):
        """An answer that filters on a value a history keeps over time while
        the question does not say when ("orders from Gold customers", the
        tier read off customer_tier_history): the value in force today and
        the value at the time of each record are two readings (E46, review
        of 26 October). Sent back once to compare them; at the final round
        the answer stands."""
        if final or self._compared() or _STATE_WHEN.search(self._question):
            return
        seen = set()
        for col in c.get("columns") or []:
            table = self.view.table(col.get("table") or "")
            if col.get("role") != "filter" or not table or table in seen:
                continue
            seen.add(table)
            res = self._call(self.tools.run, "time_columns", {"table": table})
            data = res.data if res is not None and getattr(res, "ok", False) else None
            pairs = (data or {}).get("intervals") if isinstance(data, dict) else None
            if not pairs:
                continue
            checks.append({"check": "state_over_time", "status": "not_compared",
                           "detail": f"{table}.{col.get('column')} kept from {pairs[0][0]} "
                                     f"to {pairs[0][1]}"})
            feedback.append(f"{table} keeps {col.get('column')} over time ({pairs[0][0]}, "
                            f"{pairs[0][1]}) and the question does not say when: the value in "
                            "force today and the value at the time of each record are two "
                            "readings. Compare them (compare_readings) before answering; two "
                            "that differ are a choice, unless the question's words select one")
            return

    def _repeated_event(self, c, nb, final, feedback, checks):
        """A duration measured to or from an event some records have more
        than once (a second approval round, a report filed again after a
        rejection): from the first or from the last of them are two readings
        (E62, review of 26 October). Found by the conclusion's own join: the
        table of a time column has several rows for one key. Sent back once
        to compare them; at the final round the answer stands."""
        reading = getattr(nb, "reading", None) or {}
        if final or self._compared() or str(reading.get("time") or "") != "duration":
            return
        timed = {self.view.table(col.get("table") or "") for col in c.get("columns") or []
                 if col.get("role") == "time"} - {None}
        for join in c.get("joins") or []:
            sides = [s.strip() for s in str(join).split("=")]
            if len(sides) != 2:
                continue
            for here, there in (sides, sides[::-1]):
                if "." not in here or "." not in there:
                    continue
                table, key = here.rsplit(".", 1)
                table = self.view.table(table.strip("` "))
                key = key.strip("` ")
                if table not in timed or not re.fullmatch(r"[A-Za-z0-9_]+", key) \
                        or self.view.table(there.rsplit(".", 1)[0].strip("` ")) == table:
                    continue
                sql = (f"SELECT `{key}` FROM `{table}` WHERE `{key}` IS NOT NULL "
                       f"GROUP BY `{key}` HAVING COUNT(*) > 1")
                res = self._call(self.tools.run_count, sql)
                n = matching_rows(res, sql) if getattr(res, "ok", False) else None
                if not n:
                    continue
                checks.append({"check": "repeated_event", "status": "not_compared",
                               "detail": f"{table}: {n} {key} with more than one row"})
                feedback.append(f"{table} has more than one row for {n} {key}: the duration "
                                "can run from the first of them or from the last. Compare the "
                                "two readings (compare_readings) before answering; two that "
                                "differ are a choice, unless the question's words select one")
                return

    def _ranking(self, phrase):
        """What the phrase ranks, when it is a ranking of things the
        database holds rather than a thing to find; "" otherwise.

        By its form: a superlative ("busiest", "most reliable", "least
        used", "top") or a comparative ("cheaper than", "more active than")
        set on a noun a table is named for, or with no noun at all left,
        which then ranks the question's own things. Or by the agent's own
        reading, which listed the phrase among its comparisons while its
        conclusion said absent. A superlative over a noun no table holds
        ("newest patents" with no patents) is no ranking: that thing may
        truly be absent, and is swept."""
        words = [w for w in _words(phrase)]
        if not words:
            return ""
        lowered = [w.lower() for w in words]
        said = {Clarifier._singular(w) for w in lowered if w not in STOPWORDS}
        mine = {Clarifier._singular(w.lower()) for c in self._reading.get("comparisons") or []
                for w in _words(c) if w.lower() not in STOPWORDS}
        ranking = [i for i, w in enumerate(lowered)
                   if w in ("most", "least", "top", "bottom", "best", "worst")
                   or (len(w) > 4 and w.endswith("est") and w not in NOT_SUPERLATIVE)
                   or (w.endswith("er") and i + 1 < len(lowered) and lowered[i + 1] == "than")]
        if not ranking and not (said and said <= mine):
            return ""
        entities = self._entities()
        # the noun ranked: the words after the ranking word that name a table
        rest = [Clarifier._singular(w) for w in lowered[(ranking[0] + 1) if ranking else 0:]
                if w not in STOPWORDS and w not in ("most", "least", "than", "more", "less")]
        nouns = [w for w in rest if w in entities]
        if nouns:
            return nouns[-1]
        if ranking and len(rest) <= 1:
            # "the busiest", "most reliable": no noun left, the question's
            # own things are ranked
            return "the question's things"
        if said and said <= mine and not (set(rest) - entities - mine):
            return "the question's things"
        return ""

    def _entities(self):
        """The things the tables count, by the last word of their names."""
        out = set()
        for name in getattr(self.view, "lower", {}) or {}:
            parts = _words(name.replace("_", " "))
            if parts:
                out.add(Clarifier._singular(parts[-1].lower()))
        return out

    def _reading_nouns(self):
        """The words of the entities the agent's reading names."""
        return {Clarifier._singular(w.lower()) for e in self._reading.get("entities") or []
                for w in _words(e)}

    def _counts_a_table(self, sql, issue):
        """Whether a check has no condition and selects nothing named like
        what is said missing: it then counts a table, whatever is missing."""
        clean = strip_comments(sql)
        if _CONDITION.search(clean):
            return False
        if _QUALIFIED.search(f"{issue.get('phrase') or ''} {issue.get('what') or ''}"):
            # "the freight rate after the increase": no column holds the
            # clause, and SELECT rate FROM freight_rates found 102 rows (E26)
            return True
        said = {Clarifier._singular(w.lower())
                for w in _words(f"{issue.get('phrase') or ''} {issue.get('what') or ''}")
                if w.lower() not in STOPWORDS}
        try:
            import sqlglot
            from sqlglot import exp
            tree = sqlglot.parse_one(clean, read="mysql")
            names = [c.name for e in getattr(tree, "expressions", None) or []
                     for c in e.find_all(exp.Column)]
            # the table it counts too: COUNT(*) FROM machine_hours
            names += [t.name for t in tree.find_all(exp.Table)]
        except Exception:
            names = []
        for name in names:
            if any(_same_word(Clarifier._singular(w.lower()), s)
                   for w in _words(str(name).replace("_", " ")) for s in said):
                return False
        return True

    def _calendar_period(self, phrase, what=""):
        """The period counted from today the phrase names when that is all
        it leaves open ("revenue last year"), else "". The other words must
        be the reading's own measure or entities, and what is missing must
        hold no number: "the 2027 budget exchange rate" is a value, not a
        period. A vague time word (recently) is no calendar period."""
        if re.search(r"\d", str(what or "")):
            return ""
        m = _CALENDAR.search(str(phrase or ""))
        if not m:
            return ""
        rest = {Clarifier._singular(w) for w in _words(phrase[:m.start()] + " " + phrase[m.end():])
                if w.lower() not in STOPWORDS}
        r = self._reading or {}
        known = {Clarifier._singular(w) for part in [r.get("measure")] + list(
            r.get("entities") or []) for w in _words(part)}
        # a comparison folded into the phrase ("late deliveries last month")
        # is a threshold, never part of the measure the period dates
        # the measure's head noun and the catalogue's things stay: in
        # "revenue above 10000", revenue is the measure (review of the fixes)
        head = {Clarifier._singular(w) for w in _words(r.get("measure"))[-1:]}
        known -= ({Clarifier._singular(w) for part in r.get("comparisons") or []
                   for w in _words(part)} - head - self._entities())
        return m.group(0).strip() if rest <= known else ""

    def _the_askers(self, said):
        """Why the words `said` are the asker's to give, or "": what the
        question supposes, or a reference it compares with or measures a
        distance from."""
        words = {Clarifier._singular(w) for w in _words(said) if w.lower() not in STOPWORDS}
        if not words:
            return ""

        def within(text):
            return words <= {Clarifier._singular(w) for w in _words(text)}
        supposed = wording.supposition(self._question)
        if supposed and within(supposed):
            return "what the question supposes"
        if any(within(r) for r in wording.compared_with(self._question)):
            return "what the question compares with"
        return ""

    def _history_starts(self, facts):
        """(name, first date) of each history the facts point at: the
        opening column of a validity pair, a history table one join away
        (read with time_columns), an event log, a dated series; only those
        whose first date can be read."""
        out = []

        def first_of(data, columns=None):
            days = [_day_of(m.get("min")) for m in data.get("moments") or []
                    if columns is None or m.get("column") in columns]
            days = [d for d in days if d]
            return min(days) if days else None
        for t, f in facts.items():
            for pair in f.get("intervals") or []:
                d = first_of(f, {pair[0]})
                if d:
                    out.append((f"{t}.{pair[0]}", d))
            if f.get("event_type"):
                d = first_of(f)
                if d:
                    out.append((t, d))
            for h in (f.get("history_tables") or [])[:2]:
                if self._late():
                    break
                res = self._call(self.tools.run, "time_columns", {"table": h})
                if res is not None and getattr(res, "ok", False) and isinstance(res.data, dict):
                    d = first_of(res.data)
                    if d:
                        out.append((h, d))
        return out

    def _keeping(self, facts, held):
        """(name, first date) of each history that keeps one of the values
        `held` [(table, column)], [] when none does, None when it cannot be
        told (a value read could not be). A history keeps a value when it is
        that very row versioned (a validity pair on the value's own table),
        when one of its columns is named after it (priority, to_priority),
        or, for a log of changes, when its rows name it (field_name =
        'priority'), from the first of those rows."""
        out, unread = [], False
        wanted = [(str(tb).lower(), str(col)) for tb, col in held]

        def words(name):
            return {Clarifier._singular(w) for w in re.split(r"[^a-z0-9]+", name.lower()) if w}

        def first_of(data, columns=None):
            days = [_day_of(m.get("min")) for m in data.get("moments") or []
                    if columns is None or m.get("column") in columns]
            days = [d for d in days if d]
            return min(days) if days else None

        def named_in(table):
            try:
                columns = [c for c, _d in self.tools.view.columns_of(table)]
            except Exception:
                return False
            return any(words(col) <= words(c) for _tb, col in wanted for c in columns
                       if words(col))

        def logged_in(table, data):
            # a log of changes names the value in a row: the first such row
            nonlocal unread
            moments = [m.get("column") for m in data.get("moments") or [] if m.get("column")]
            try:
                texts = [c for c, d in self.tools.view.columns_of(table)
                         if any(k in str(d).lower() for k in ("char", "text", "enum"))][:6]
            except Exception:
                texts = []
            names = [col.lower() for _tb, col in wanted if re.fullmatch(r"[A-Za-z0-9_]+", col)]
            if not (moments and texts and names):
                return None
            where = " OR ".join(f"LOWER(`{c}`) = '{n}'" for c in texts for n in names)
            res = self._call(self.tools.run_count,
                             f"SELECT MIN(`{moments[0]}`) FROM `{table}` WHERE {where}")
            if res is None or not getattr(res, "ok", False):
                unread = True
                return None
            rows = (res.data or {}).get("rows") or []
            return _day_of(rows[0][0]) if rows and rows[0] and rows[0][0] else None

        for t, f in facts.items():
            # a validity pair versions its own row: the value's own table,
            # or a history the conclusion reads that has a column for it
            if any(tb == t.lower() for tb, _c in wanted) or named_in(t):
                for pair in f.get("intervals") or []:
                    d = first_of(f, {pair[0]})
                    if d:
                        out.append((f"{t}.{pair[0]}", d))
            others = [(h, None) for h in (f.get("history_tables") or [])[:2]]
            if f.get("event_type") and not any(tb == t.lower() for tb, _c in wanted):
                others.append((t, f))
            for h, data in others:
                if self._late():
                    unread = True
                    break
                if data is None:
                    res = self._call(self.tools.run, "time_columns", {"table": h})
                    if res is None or not getattr(res, "ok", False) \
                            or not isinstance(res.data, dict):
                        unread = True
                        continue
                    data = res.data
                if named_in(h):
                    d = first_of(data)
                else:
                    d = logged_in(h, data)
                if d:
                    out.append((h, d))
        return out if out or not unread else None

    def _check_absent(self, issue, final, feedback, checks, c=None):
        said = {Clarifier._singular(w) for w in _words(issue.get("phrase") or issue.get("what"))
                if w.lower() not in STOPWORDS}

        def within(text):
            return said and said <= {Clarifier._singular(w) for w in _words(text)}
        supposed = wording.supposition(self._question)
        if supposed and within(supposed):
            # "what would it have been with the increase they announced":
            # what the question supposes is the asker's to give (E26); the
            # rest of a what-if question is looked for as any other
            checks.append({"check": "absent", "status": "what_if",
                           "detail": f"what the question supposes: {supposed}"})
            return ("downgrade", dict(issue, type="asker_must_say", kind="AmbiSource"),
                    f"the question supposes {supposed}: the asker gives it")
        for reference in wording.compared_with(self._question):
            if within(reference):
                # "cheaper than a coffee": the price of a coffee is the
                # asker's to give, as a threshold is (Warehouse Q15)
                checks.append({"check": "absent", "status": "compared_with",
                               "detail": f"what the question compares with: {reference}"})
                return ("downgrade", dict(issue, type="asker_must_say", kind="AmbiSource"),
                        f"the question compares with {reference}: the asker gives its value")
        if wording.ORDERED_BY_AGE.search(self._question) and self._age_only(issue.get("phrase")):
            # "Who are the oldest members?": the age word orders the members
            # by one of their dates. Said absent, "oldest" was swept, found
            # nowhere, and the question was refused while members.joined_at
            # was there (Library Q09, 23 October). Never a refusal: the
            # agent is shown why, and in the end the asker says which date
            checks.append({"check": "absent", "status": "ordered_by_age",
                           "detail": f"{issue.get('phrase')} orders by a date"})
            if not final:
                feedback.append(f"\"{issue.get('phrase')}\" orders them by one of their dates, "
                                "it is not a thing to find: look at the dates of the question's "
                                "tables (time_columns), and when more than one could be meant, "
                                "give each as a reading of a choice")
                return "keep"
            # their dates, compared here: a choice when they order them
            # differently, the answer when one date does (Library Q09 ended
            # NEEDS MORE, review of 26 October); unread, the asker says
            built = self._by_age(issue.get("phrase"), c or {}, final, feedback, checks)
            if built is not None:
                return built
            return ("downgrade", dict(issue, type="asker_must_say", kind="AmbiContext"),
                    f"{issue.get('phrase')} orders by a date: the asker says which")
        ranked = self._ranking(issue.get("phrase"))
        if not ranked:
            # neither an age word nor the form of a ranking: "popular books"
            # may still rank the books. A closed question, asked once, in a
            # fresh context, settles it (review of 26 October, rule 3)
            thing = self._held_noun(issue.get("phrase"))
            if thing and self._asked_rank(issue.get("phrase"), thing) == "ranking":
                ranked = thing
        if ranked:
            # "the busiest warehouses", "our most reliable suppliers": a
            # ranking of things the database holds, by a measure it does not
            # name. Not only the age words of a list (review of 26 October:
            # a word nobody listed was swept and refused): found by the form
            # of the phrase, or by the agent's own reading listing it as a
            # comparison. Never a refusal: what is missing is the measure
            checks.append({"check": "absent", "status": "ranking",
                           "detail": f"{issue.get('phrase')}: {ranked}"})
            if not final:
                feedback.append(f"\"{issue.get('phrase')}\" ranks {ranked} by a measure, it is not "
                                "a thing to find: look for the columns that could measure it "
                                "(find_columns on the word, on the tables one key away), and when "
                                "more than one could be meant, give each as a reading of a choice")
                return "keep"
            return ("downgrade", dict(issue, type="asker_must_say", kind="AmbiContext"),
                    f"{issue.get('phrase')} ranks {ranked}: the asker says by what")
        term = self._term(issue, self._reading, self._entities())
        if issue.get("_synth") or not term:
            # nothing short enough to look for: a sentence is no term, and
            # a refusal is only ever earned by a sweep that meant something
            checks.append({"check": "absent", "status": "failed",
                           "detail": "no term to sweep"})
            if not final:
                feedback.append("say in a few words what is absent (what), and the words of "
                                "the question that ask for it (phrase), so it can be looked for")
                return "keep"
            return ("downgrade", dict(issue, type="asker_must_say",
                                      kind="AmbiContext"), "nothing to sweep for")
        # out of time, nothing is swept: an absence unconfirmed is never a
        # refusal, it goes to the asker as data that could not be checked
        swept = not self._late()
        found = self._call(self.tools.absent_everywhere, term) if swept else (False, False, [])
        for other in wording.noun_forms(term):
            if self._late() or not (isinstance(found, tuple) and len(found) == 3 and found[0]):
                break
            again = self._call(self.tools.absent_everywhere, other)
            if isinstance(again, tuple) and len(again) == 3 and (not again[0] or again[2]):
                found, term = again, other
        absent, complete, hits = found if isinstance(found, tuple) and len(found) == 3 \
            else (False, False, [])
        weighed = self._weigh_on_values(term, hits, checks)
        if weighed is not None:
            absent, complete, hits = weighed
        echoes = (getattr(self.tools, "last_echoes", None) or []) if swept else []
        checks.append({"check": "absent", "status": "absent" if absent and not hits else "found",
                       "detail": f"{term}: " + ("; ".join(str(h) for h in (hits or [])[:3])
                                                or "nothing")
                       + ("" if complete else " (sweep incomplete)")
                       + (f" (echoes of its kind only: {'; '.join(str(e) for e in echoes[:3])})"
                          if echoes and not hits else "")})
        if hits:
            feedback.append(f"\"{term}\" is held: {', '.join(str(h) for h in hits[:3])}")
            if final:
                # the thing is there, the property asked of it is not: "the
                # time of each expense" when expense_lines keeps a date only
                # (E52, E55, E60, E65, 23 October); the records lack it
                # only when what is asked of it is a property the records
                # would keep (a time, a date, a link, a reason, a history):
                # a term found whole is no proof of anything missing
                gap = "data" if _RECORD_PROPERTY.search(
                    f"{issue.get('phrase') or ''} {issue.get('what') or ''}") else "asker"
                return ("downgrade", dict(issue, type="asker_must_say", kind="AmbiContext",
                                          _gap=gap),
                        f"{term} is held")
            return "keep"
        if absent and complete:
            issue["_checked"] = True
            issue["_term"] = term
            return "keep"
        # not found, but not everything could be looked at
        if final:
            return ("downgrade", dict(issue, type="asker_must_say", _gap="data"),
                    "the sweep was incomplete")
        return "keep"

    def _check_no_row(self, issue, final, feedback, checks):
        said = issue.get("phrase") or issue.get("what")
        sql = str(issue.get("check_sql") or "").strip()
        if not sql:
            feedback.append(f"\"no matching row\" for \"{said}\" needs the SELECT of the "
                            "matching rows in check_sql")
            return ("drop", "") if final else "keep"
        res = self._call(self.tools.run_count, sql)
        if not getattr(res, "ok", False):
            feedback.append(f"the check for \"{said}\" could not run: "
                            f"{clip(getattr(res, 'error', '') or 'it failed', 160)}")
            return ("drop", "") if final else "keep"
        n = matching_rows(res, sql)
        if n is None:
            # NO DATA rests on a count of zero; an unknown count earns nothing
            checks.append({"check": "no_matching_row", "status": "unread",
                           "detail": "the check could not be counted"})
            feedback.append(f"the check for \"{said}\" could not be counted: "
                            "select fewer columns, or the key alone")
            return ("drop", "") if final else "keep"
        checks.append({"check": "no_matching_row", "status": "counted",
                       "detail": f"{n} matching rows"})
        if n:
            feedback.append(f"the check for \"{said}\" finds {n} matching rows")
            return ("drop", "") if final else "keep"
        missed = self._closed_miss(sql)
        if missed is not None:
            # "by rail" when the mode is one of road, sea and air: not a
            # match that happens to be missing, a thing the database does
            # not cover (Warehouse Q25)
            t, col, value, held = missed
            checks.append({"check": "no_matching_row", "status": "not_a_value",
                           "detail": f"{value} is none of the values of {t}.{col}: {held}"})
            return ("downgrade", dict(issue, type="absent_from_database", kind="AmbiFallacy",
                                      _checked=True, _term=str(said or value)),
                    f"{value} is none of the values {t}.{col} can hold")
        issue["_empty"] = True
        return "keep"

    # ------------------------------------------------------ time
    def _check_time(self, c, kept, nb, final, feedback, checks):
        """What a question about time needs, checked on the tables the
        conclusion uses (deliverables/notes/temporalite_methodes_2026-10.md,
        section 3). The code reads time_columns itself: whether the agent
        did or not, the fact is the database's.

          as_of        a history (validity pairs, a history table, an event
                       log) for at least one table, else only the current
                       state is stored
          duration     in hours or minutes, every time column used holds a
                       time of day, else only the day is recorded
          sequence,    an event log or an ordered history, else the order of
          first_last   events is not recorded; a cause ("parent" among the
                       relations) needs a parent link, never the order alone

        Returns the issue to add, or None. Nothing is added when the
        conclusion already says the asker must say something or that it is
        absent, or when the facts could not be read (a check that cannot run
        never turns into a verdict)."""
        reading = nb.reading or {}
        kind = str(reading.get("time") or "none")
        if kind not in TIMED:
            return None
        if any(i["type"] in ("asker_must_say", "absent_from_database") for i in kept):
            return None
        question = nb.question or ""
        if kind == "as_of" and wording.PERIOD.search(question) \
                and not wording.POINT_IN_TIME.search(question):
            # "in 2025" is a period, read off that period's rows; only a
            # question asked at a point in time needs the state kept at a
            # date (E17 was refused a history it never needed). A question
            # naming neither is checked
            checks.append({"check": "time.as_of", "status": "skipped",
                           "detail": "a period and no point in time: read off its rows"})
            return None
        if kind == "as_of" and _EVER.search(question) and not _EVER_STATE.search(question) \
                and not _asked_date(question, getattr(self, "today", None)):
            # "has any customer ever returned a product": the returns kept,
            # with their dates, are the past; no state at a date is asked
            # (review of 26 October: refused for want of a history)
            checks.append({"check": "time.as_of", "status": "skipped",
                           "detail": "ever: the rows kept are the past"})
            return None
        if kind == "as_of" and not wording.POINT_IN_TIME.search(question) \
                and not _asked_date(question, getattr(self, "today", None)) \
                and not _PAST.search(question):
            # "Show me the oldest products", "Which tier is C1 in?" read as a
            # state at a date: no date, no time of an event and no past is
            # asked, the rows kept answer it (Warehouse Q10 was sent to the
            # asker for a history, review of 27 October). "Which tier was
            # C1 in?" still asks when
            checks.append({"check": "time.as_of", "status": "skipped",
                           "detail": "no point in time is asked"})
            return None
        facts = {}
        for t in self._tables_used(c, kept)[:MAX_TIME_TABLES]:
            if facts and self._late():
                break
            res = self._call(self.tools.run, "time_columns", {"table": t})
            if res is not None and getattr(res, "ok", False) and isinstance(res.data, dict):
                facts[t] = res.data
        if not facts:
            checks.append({"check": f"time.{kind}", "status": "unread",
                           "detail": "time_columns could not be read"})
            return None

        def any_of(key):
            return [t for t, f in facts.items() if f.get(key)]

        histories = any_of("intervals") + any_of("history_tables") + any_of("event_type")
        # a table with rows per date (rates by month end) keeps the value
        # at each date: a history of that value (E04, exchange_rates)
        dated_moments = [(t, m) for t, f in facts.items() for m in f.get("moments") or []
                         if self._dated_series(t, m, c)]
        dated = [f"{t}.{m.get('column')}" for t, m in dated_moments]
        problem = None
        # the values whose state at the date is asked: a history counts only
        # when it keeps one of them. A status history says nothing of a
        # ticket's priority, and E42 was answered from it (review of 26
        # October)
        held = [(col.get("table"), col.get("column")) for col in c.get("columns") or []
                if col.get("role") in ("measure", "label") and col.get("table")
                and col.get("column")] if kind == "as_of" else []
        kept_by = self._keeping(facts, held) if held and histories else None
        if kind == "as_of" and not histories and not dated:
            problem = ("the state at that date: only the current state is stored for "
                       + ", ".join(facts))
        elif kind == "as_of" and kept_by == [] and not dated:
            problem = ("the state at that date: no history keeps "
                       + ", ".join(f"{t}.{col}" for t, col in held[:3])
                       + "; only its current value is stored")
        elif kind == "as_of":
            # a history counts only when it reaches back to the date asked:
            # an audit log kept since February 2026 says nothing of 1 March
            # 2025 (E42, 23 October)
            asked = _asked_date(question, getattr(self, "today", None))
            # a dated series too: rates kept from 31 January 2026 say nothing
            # of 1 March 2025 (review of 26 October)
            starts = ((kept_by if kept_by is not None else self._history_starts(facts))
                      + [(f"{t}.{m.get('column')}", _day_of(m.get("min")))
                         for t, m in dated_moments if _day_of(m.get("min"))]) if asked else []
            if starts and all(d > asked for _n, d in starts):
                first = min(d for _n, d in starts)
                problem = (f"the state at that date: the history kept starts on "
                           f"{first.isoformat()} ({', '.join(n for n, _d in starts)}), after "
                           f"{asked.isoformat()}")
        elif kind == "duration" and FINE_UNITS.search(nb.question or ""):
            # every moment the conclusion names, whatever role the agent
            # gave it ("hours after the end of their trip" read period_end
            # as a filter and passed, E60, 23 October); a DATE holds no
            # time of day at all, whatever was read of it
            named = {(col.get("table"), str(col.get("column") or "").lower())
                     for col in c.get("columns") or []}
            moments = [(t, m) for t, f in facts.items() for m in f.get("moments") or []]
            used = [(t, m) for t, m in moments
                    if (t, str(m.get("column") or "").lower()) in named]

            def no_time(m):
                return m.get("has_time") is False or str(m.get("type") or "").lower() == "date"
            if used:
                day_only = [f"{t}.{m.get('column')}" for t, m in used if no_time(m)]
            else:
                day_only = ([f"{t}.{m.get('column')}" for t, m in moments]
                            if moments and all(no_time(m) for _t, m in moments) else [])
            if day_only:
                problem = ("the time of day: only the day is recorded for "
                           + ", ".join(day_only[:4]))
        elif kind in ("sequence", "first_last"):
            relations = [str(r).lower() for r in reading.get("time_relations") or []]
            if any("parent" in r or "caus" in r for r in relations) \
                    and not any_of("parent_links"):
                problem = "which event led to which: the events are not linked"
            elif not histories and (kind == "sequence"
                                    or wording.SEQUENCE.search(nb.question or "")):
                # events put in an order ("reopened after"); a "newest" alone
                # (first_last) is an order by one date, which any date
                # column gives
                moments = sum(1 for f in facts.values() for m in f.get("moments") or []
                              if m.get("has_time"))
                if moments < 2:
                    problem = ("the order of events: they are not recorded with "
                               "times that order them")
        checks.append({"check": f"time.{kind}", "status": "failed" if problem else "ok",
                       "detail": problem or ", ".join(
                           [f"{t}: history" if t in histories else t for t in facts]
                           + [f"dated by {d}" for d in dated[:3]])})
        if problem is None:
            return None
        feedback.append(f"for this question about time ({kind}), {problem}")
        if not final:
            return None
        # a history, a time of day, an order of events the records do not keep
        return dict(self._issue("asker_must_say", "", problem, "AmbiRef"), _time=kind,
                    _gap="data")

    # -------------------------------------------------- the outcome
    def to_outcome(self, kept, c, notes=()):
        if not kept:
            reason = c.get("reason") or ""
            if notes:
                reason = (reason + " " if reason else "") + "Also: " + "; ".join(notes) + "."
            return Outcome(action="ANSWER", reason=reason)
        kept = sorted(kept, key=lambda i: -SEVERITY.get(i["type"], 0))
        win, others = kept[0], kept[1:]
        also = [f"{o['type'].replace('_', ' ')}: {o.get('phrase') or o.get('what')}"
                for o in others] + list(notes)
        kind = win.get("kind") if win.get("kind") in COMPATIBLE_KINDS[win["type"]] \
            else KIND_OF_ISSUE[win["type"]]
        phrase = str(win.get("phrase") or "")
        what = str(win.get("what") or "").strip()
        tail = (" Also: " + "; ".join(also) + ".") if also else ""
        if win["type"] == "choice":
            diff = ", ".join(f"{r.get('label')}: {r['_count']} rows"
                             for r in win.get("readings") or [] if r.get("_count") is not None)
            return Outcome(action="CLARIFY", phrase=phrase, kind=kind,
                           reason=(what or c.get("reason") or "")
                           + (f" ({diff})" if diff else "") + tail,
                           question=f"By \"{phrase}\", which do you mean?",
                           options=self._options(win, c))
        if win["type"] == "absent_from_database" and win.get("_checked"):
            # the sentence names the term that was swept, not the model's prose
            return Outcome(action="GUIDE", phrase=phrase, kind=kind, checked=True,
                           reason=(c.get("reason") or "") + tail,
                           question=f"Nothing in the database holds {win['_term']}." + tail)
        if win["type"] == "no_matching_row" and win.get("_empty"):
            return Outcome(action="GUIDE", phrase=phrase, kind=kind, empty=True,
                           reason=(c.get("reason") or "") + tail,
                           question=(f"{what}: no row matches." if what else "No row matches.")
                           + tail)
        missing = what
        if win.get("_time"):
            # the verifier's own time check: its sentence names columns, kept
            # in the reason for whoever maintains the data; the asker reads
            # words (review of 23 October), and the question's time words
            # are the phrase
            phrase = phrase or _time_words(self._question, win["_time"])
            missing = TIME_MISSING.get(win["_time"], "the moments this needs")
        # what the asker must say: the sentence the reader sees
        return Outcome(action="GUIDE", phrase=phrase, kind=kind, checked=False,
                       reason=(what or c.get("reason") or "what the question leaves open") + tail,
                       question=f"What do you mean by \"{phrase}\"?" if phrase else "",
                       missing=missing,
                       # an absence the agent saw and the sweep could not
                       # confirm is still nothing the asker can type in
                       gap=win.get("_gap") or (
                           "data" if win["type"] == "absent_from_database" else "asker"))

    @staticmethod
    def no_conclusion():
        """At the cap, with no usable conclusion: an error, which a resumed
        run judges again. A choice rebuilt from the facts found would have
        no options to offer and no phrase to ask about, so none is."""
        return Outcome(action="ERROR", reason="the turn cap was reached without a conclusion")

    # ------------------------------------------------------ helpers
    @staticmethod
    def _issue(type_, phrase, what, kind):
        return {"type": type_, "phrase": phrase, "kind": kind, "what": what,
                "readings": [], "check_sql": "", "evidence": []}

    def _call(self, fn, *args):
        """A tool call that never raises: None when it fails. The same call
        in a later round of the question is read from the first: the last
        round ran every count and sweep again, with no cache (review of 26
        October). A sweep's echoes come back with it."""
        try:
            key = (getattr(fn, "__name__", repr(fn)), repr(args))
        except Exception:
            key = None
        if key is not None and key[0] == "<lambda>":
            # a lambda's arguments are in its closure, not in args: every
            # one had the same key, and one term's sweep answered another's
            # (review of the fixes: a false NOT COVERED)
            key = None
        seen = self.__dict__.setdefault("_seen", {})
        if key is not None and key in seen:
            out, echoes = seen[key]
            if echoes is not None:
                try:
                    self.tools.last_echoes = echoes
                except Exception:
                    pass
            return out
        try:
            out = fn(*args)
        except Exception:
            return None
        if key is not None:
            seen[key] = (out, getattr(self.tools, "last_echoes", None))
        return out

    @staticmethod
    def _term(issue, reading=None, entities=()):
        """What to sweep for: the distinctive words, never a sentence. The
        question's own words when they are few, else the agent's, else the
        measure of its reading when it shares a word with them; then the
        first of those up to MAX_TERM_WORDS. Words that only ask (which,
        our) are left out: swept as a whole, "Which patents protect our
        compressor designs" met "compressor" in a description and the
        absence of patents was never said (E39). A measure sharing no word
        with what is claimed absent is another thing: sweeping it would
        refuse, or keep, the wrong one. Nor is a comparison of the reading
        swept ("oldest"): no column is named for an adjective, and finding
        none proved the absence of "member birth date or age" while the
        members' join dates were there (Library Q09). The noun a table is
        named for (`entities`) is left out when another word remains."""
        compared = {Clarifier._singular(w) for c in (reading or {}).get("comparisons") or []
                    for w in _words(c)}
        phrase = issue.get("phrase")
        if compared and {Clarifier._singular(w) for w in _words(phrase)} <= compared:
            phrase = None
        content = [[w for w in _words(c) if w.lower() not in STOPWORDS]
                   for c in (phrase, issue.get("what"))]
        # the noun a table is named for is the thing asked about, not what
        # is missing: "braille copies" was kept from a refusal because a
        # table is named copies (Library Q23); the distinctive word is swept
        content = [[w for w in words if Clarifier._singular(w) not in entities] or words
                   for words in content]
        measure = [w for w in _words((reading or {}).get("measure"))
                   if w.lower() not in STOPWORDS]
        said = {Clarifier._singular(w) for words in content for w in words}
        if measure and said & {Clarifier._singular(w) for w in measure}:
            content.append(measure)
        # a word that only names a form is never swept, once the words are
        # chosen: "website traffic data" met product_attributes.data_type
        # (E38, 23 October)
        plain = {Clarifier._singular(w) for w in Clarifier.GENERIC_WORDS | SWEEP_GENERIC}
        for limit in (SHORT_TERM_WORDS, MAX_TERM_WORDS):
            for words in content:
                if 0 < len(words) <= limit:
                    kept = [w for w in words if Clarifier._singular(w.lower()) not in plain]
                    return " ".join(kept or words)
        return ""

    def _canonical(self, conclusion, feedback, checks):
        c = dict(conclusion or {})
        c["verdict"] = c.get("verdict") if c.get("verdict") in VERDICTS else "ANSWER"
        tables = []
        for t in c.get("tables") or []:
            real = self._table(t, feedback, checks)
            if real and real not in tables:
                tables.append(real)
        c["tables"] = tables
        cols = []
        for col in c.get("columns") or []:
            if not isinstance(col, dict):
                continue
            t = self._table(col.get("table"), feedback, checks)
            if t and self._has(t, col.get("column")):
                cols.append(dict(col, table=t))
            elif t:
                feedback.append(f"{t} has no column {col.get('column')}")
                checks.append({"check": "column", "status": "failed",
                               "detail": f"{t}.{col.get('column')}"})
        c["columns"] = cols
        issues = []
        for i in c.get("issues") or []:
            if not isinstance(i, dict) or i.get("type") not in ISSUES:
                continue
            i = dict(i)
            i["readings"] = [dict(r, table=(self._reading_table(r.get("table"), feedback, checks)
                                            if r.get("table") else None) or r.get("table"))
                             for r in i.get("readings") or [] if isinstance(r, dict)]
            issues.append(i)
        c["issues"] = issues
        return c

    def _from_declared(self, c, declared):
        """The issue a verdict declared without one stands for, marked so
        it is never taken as verified."""
        what = c.get("reason") or ""
        if declared == "NOT_COVERED":
            return dict(self._issue("absent_from_database", "", what, "AmbiFallacy"), _synth=True)
        if declared in ("NEEDS_MORE", "CHOICE", "NO_DATA"):
            # a choice or an empty result the agent saw and never named is
            # unverified: what the asker must settle, never an answer
            # (review of 26 October)
            return dict(self._issue("asker_must_say", "", what, "AmbiContext"), _synth=True)
        return None

    def _reading_table(self, name, feedback, checks):
        """A reading's table; "scrap_records, work_order_operations" names
        two, and the first the schema holds is its table (its SQL reads
        the others), rather than an unknown table sent back."""
        parts = [p.strip() for p in str(name).split(",") if p.strip()]
        if len(parts) > 1:
            # each name checked, so an unknown one is said
            known = [t for t in (self._table(p, feedback, checks) for p in parts) if t]
            return known[0] if known else None
        return self._table(name, feedback, checks)

    def _table(self, name, feedback, checks):
        if not name:
            return None
        real = self.view.table(name)
        if real:
            return real
        near = []
        try:
            near = self.view.closest(name, 3)
        except Exception:
            pass
        feedback.append(f"there is no table {name}"
                        + (f" (closest: {', '.join(near)})" if near else ""))
        checks.append({"check": "table", "status": "failed", "detail": str(name)})
        return None

    def _has(self, table, column):
        try:
            return bool(self.view.has(table, column))
        except Exception:
            return False

    def _tables_used(self, c, issues=()):
        out = list(c.get("tables") or [])
        for col in c.get("columns") or []:
            if col.get("table") and col["table"] not in out:
                out.append(col["table"])
        for i in issues:
            for r in i.get("readings") or []:
                t = self.view.table(r.get("table") or "") if r.get("table") else None
                if t and t not in out:
                    out.append(t)
        return out

    def _connected(self, tables):
        try:
            return self.view.connected(tables)
        except Exception:
            return True, []

    def _options(self, issue, c):
        readings = issue.get("readings") or []
        labels = [f"{r.get('table')}.{r.get('column')}" for r in readings]
        start = (c.get("tables") or [None])[0]
        options = []
        for r, label in zip(readings, labels):
            if labels.count(label) > 1 or not (r.get("table") and r.get("column")):
                label = str(r.get("label") or label)
            via = None
            t = self.view.table(r.get("table") or "") if r.get("table") else None
            if start and t and t != start:
                try:
                    paths = self.view.paths(start, t, max_hops=5, limit=1)
                    if paths:
                        via = " AND ".join(paths[0].get("via") or []) or None
                except Exception:
                    via = None
            col = r.get("column") if t and self._has(t, r.get("column")) else None
            options.append(Option(label=label, means=str(r.get("means") or label),
                                  table=t, column=col, via=via))
        return options

    def _is_view(self, table):
        """Whether the table is a view: the schema view's `views` when it
        has one, else the catalogue's (Clarifier.views, through the
        toolbox's clarifier, a {view: tables built from} map); nothing
        known, nothing is a view."""
        if self._view_names is None:
            found = getattr(self.view, "views", None)
            if found is None:
                clar = getattr(self.tools, "clar", None)
                try:
                    found = clar.views if clar is not None else None
                except Exception:
                    found = None
            self._view_names = {str(v).lower() for v in (found or ())}
        return str(table or "").lower() in self._view_names

    def _is_threshold(self, issue):
        """An asker_must_say on a comparison or a filter the reading names
        ("cheap", "recently"), with no number in it: a threshold only the
        asker knows. "recently" was read as a filter and a MIN/MAX of the
        dates took it for data (Warehouse Q14); "the 2027 rate" holds a
        number and is counted. A stored value ("high" where a column holds
        HIGH) still settles it, after."""
        phrase = str(issue.get("phrase") or "")
        # a number is data to look up: its rows say whether it is held (E32).
        # A period word is set aside rather than taken for data: "long gap
        # between orders" is still the asker's "long" (review of 26 October)
        if re.search(r"\d", phrase):
            return False
        nouns = self._entities() | self._reading_nouns()
        said = {Clarifier._singular(w.lower()) for w in _words(wording.PERIOD.sub(" ", phrase))
                if w.lower() not in STOPWORDS}
        said = (said - nouns) or said
        if not said:
            return False
        named = list(self._reading.get("comparisons") or []) + \
            [f for f in self._reading.get("filters") or []
             if not wording.PERIOD.search(str(f))]
        for comp in named:
            if re.search(r"\d", str(comp)):
                continue          # "above 10000": the asker gave the threshold
            # by whole words: "rate" is not in "accurate", nor "late" in
            # "latest"; and only a phrase within the comparison: "largest
            # share of their scheduled machine hours" holds "largest share"
            # and asks for no threshold, it ranks (E32 lost its answer)
            words = {Clarifier._singular(w) for w in _words(comp)}
            if words and said <= words:
                return True
        return False

    def _selected_by_wording(self, issue, readings, checks):
        """The note saying which reading the question's words select, or
        None when the asker must choose.

        The facts showed the readings differ; whether the question already
        says which one it means is a matter of words. First without a
        model: a word of the phrase that is a value one reading alone
        filters on ("active" and status_code = 'ACTIVE'). Then the closed
        question to a model in a fresh context (self.meaning), which never
        sees the agent's notes nor its verdict. A check that cannot run
        keeps the choice; a stopped job stops it."""
        phrase = str(issue.get("phrase") or issue.get("what") or "")
        # the question's measure is what is counted, never a filter: in
        # "What was our revenue last year?", REVENUE stored as a ledger
        # account type took the choice of revenue for the ledger (E36)
        measure = {Clarifier._singular(w) for w in _words((self._reading or {}).get("measure"))}
        named = self._named_reading(phrase, readings, measure)
        if named is not None:
            i, word = named
            label = readings[i].get("label") or f"reading {i + 1}"
            checks.append({"check": "wording", "status": "named",
                           "detail": f"\"{word}\" names {label}"})
            return f"the question's word \"{word}\" names {label}"
        if self.meaning is None:
            return None
        got = self._asked_meaning(phrase, readings)
        if not got:
            checks.append({"check": "wording", "status": "choose",
                           "detail": f"the words of \"{phrase}\" fit several readings"})
            return None
        i, why = got
        if not (isinstance(i, int) and 0 <= i < len(readings)):
            checks.append({"check": "wording", "status": "choose",
                           "detail": "the check named no reading"})
            return None
        # asked again with the readings in the other order: a model judging
        # between options leans to one place in the list, and a single
        # answer dropped real choices (E62, Library Q10, Warehouse Q10, 23
        # October). Only the same reading named both ways settles it
        again = self._asked_meaning(phrase, readings[::-1])
        back = again[0] if again else None
        if not (isinstance(back, int) and len(readings) - 1 - back == i):
            checks.append({"check": "wording", "status": "unsure",
                           "detail": f"the words of \"{phrase}\" named "
                                     f"{readings[i].get('label') or i + 1} in one order only"})
            return None
        label = readings[i].get("label") or f"reading {i + 1}"
        checks.append({"check": "wording", "status": "selected",
                       "detail": clip(f"{label}: {why}", 240)})
        return clip(f"the wording of \"{phrase}\" means {label}: {why}", 240)

    def _asked_meaning(self, phrase, readings):
        """The wording check's (index, why) for the readings in this order,
        asked once and kept; None when it says choose or cannot run."""
        key = (self._question, phrase, tuple(str(r.get("sql")) for r in readings))
        if key not in self._worded:
            try:
                self._worded[key] = self.meaning(self._question, phrase, readings)
            except Exception as e:
                if getattr(e, "stops_the_job", False):
                    raise
                self._worded[key] = None
        return self._worded[key]

    def _named_reading(self, phrase, readings, measure=()):
        """(index, word) when a word of the phrase is a value one reading
        alone filters on, as stored or by its label in the dictionary
        (CARTPT is "cartesian point"); None otherwise.

        Values only, never column names: a column's name is one word among
        others ("price" in list_price against unit_cost, "year" in
        fiscal_year), and whether the question means it is for the closed
        question to weigh. The word must also appear nowhere in the other
        readings' SQL: two readings that both keep active customers and
        differ by net or gross are not told apart by "active". The noun
        the readings' tables are named for is the entity asked about
        ("oldest members"), and a word that only names a value's form
        (code, type, number) decides nothing."""
        singular = Clarifier._singular
        entity = set()
        for r in readings:
            parts = _words(str(r.get("table") or "").replace("_", " "))
            if parts:
                entity.add(singular(parts[-1]))
        plain = {singular(w) for w in Clarifier.GENERIC_WORDS | Clarifier.FORM_WORDS}
        # a number is no name: a year sits in the date literals of a
        # reading that spells its period out, and not of one using YEAR()
        words = [singular(w) for w in _words(phrase)
                 if len(w) >= 3 and w.isalpha() and w.lower() not in STOPWORDS]
        words = [w for w in words if w not in entity and w not in plain and w not in measure]
        if not words:
            return None
        said = []       # per reading: the words its values name, every word of its SQL
        for r in readings:
            # the SQL as it runs: a quoted word in a comment is no value
            try:
                sql = strip_comments(str(r.get("sql") or ""))
            except ValueError:
                sql = ""
            labels = self._value_labels(r.get("table"))
            values = set()
            for literal in _LITERAL.findall(sql):
                for text in (literal, labels.get(literal.strip().lower(), "")):
                    values |= {singular(w) for w in _words(text.replace("_", " "))}
            every = values | {singular(w) for w in _words(sql.replace("_", " "))}
            said.append((values, every))
        hits = []
        for i, (values, _every) in enumerate(said):
            others = set()
            for j, (_values, every) in enumerate(said):
                if j != i:
                    others |= every
            found = next((w for w in words
                          if any(_same_word(w, v) for v in values)
                          and not any(_same_word(w, o) for o in others)), None)
            if found:
                hits.append((i, found))
        return hits[0] if len(hits) == 1 else None

    def _dated_series(self, table, moment, c):
        """Whether a date column keeps, for the conclusion, a value at each
        date: the conclusion uses the column and a numeric measure of the
        same table, the column holds more than one date, and several rows
        share each date (rates for each currency at each month end, 23 rows
        per date). employees.hire_date has about one row per date: it
        dates the employee, and keeps no department at a date. A count
        that cannot be read never makes a history."""
        column = str(moment.get("column") or "")
        cols = [col for col in c.get("columns") or [] if col.get("table") == table]
        if not any(str(col.get("column") or "").lower() == column.lower() for col in cols):
            return False
        if moment.get("min") is None or moment.get("min") == moment.get("max"):
            return False
        if not any(col.get("role") == "measure" and self._is_number(table, col.get("column"))
                   for col in cols):
            return False
        per_date = self._rows_per_value(table, column)
        return per_date is not None and per_date >= SERIES_ROWS_PER_DATE

    def _is_number(self, table, column):
        """A numeric column that is not a key: a value, not an identifier."""
        name = str(column or "").lower()
        if not name or name.endswith("_id"):
            return False
        clar = getattr(self.tools, "clar", None)
        try:
            if clar is not None and clar.is_a_key(table, column):
                return False
        except Exception:
            pass
        for col, dtype in (getattr(self.view, "columns_of", lambda t: [])(table) or []):
            if str(col).lower() == name:
                base = (re.split(r"[\s(]", str(dtype or "").lower()) or [""])[0]
                return base in NUMBER_TYPES
        return False

    def _rows_per_value(self, table, column):
        """Rows per distinct value of a column, from the column profile
        when it has the counts, else one bounded query; None unknown."""
        spec = ((getattr(self.view, "profile", None) or {}).get(table.lower()) or {}).get(
            column.lower()) or {}
        rows, distinct = spec.get("rows"), spec.get("distinct")
        if isinstance(rows, (int, float)) and isinstance(distinct, (int, float)) and distinct > 0:
            return rows / distinct
        execute = getattr(self.tools, "execute", None)
        if execute is None:
            return None
        try:
            got = execute(f"SELECT COUNT(*), COUNT(DISTINCT `{column}`) FROM (SELECT `{column}` "
                          f"FROM `{table}` LIMIT {SERIES_ROWS}) AS s", 1)
            row = (got.get("rows") or [None])[0] if not got.get("error") else None
            if not row or not row[1]:
                return None
            return float(row[0]) / float(row[1])
        except Exception:
            return None

    def _weigh_on_values(self, term, hits, checks):
        """(absent, complete, hits) again when the only evidence against an
        absence points at a neighbourhood (WEAK_EVIDENCE) and the model,
        shown those columns' real values (Clarifier.decide_on_values, the
        old judge's measured question), says the concept cannot be read
        off them: then the rows alone decide. None to keep what was found:
        strong evidence, no clarifier, a "yes" or an "unknown"."""
        if not hits or self.weigh is None \
                or any(h.get("how") not in WEAK_EVIDENCE for h in hits):
            return None
        # a column recording a state (a date, a short closed list) answers
        # a concept the model may not see in its values: "a no does not
        # authorise a denial" there (the old judge's measured lesson)
        clar = getattr(self.tools, "clar", None)
        try:
            if clar is not None and any(clar.records_a_state(h.get("table"), h.get("column"))
                                        for h in hits):
                return None
        except Exception:
            return None
        verdict, why = self._values_say(term, [{"table": h.get("table"),
                                                "column": h.get("column")} for h in hits])
        checks.append({"check": "absent", "status": f"values_{verdict}",
                       "detail": clip(f"{term} on the values of "
                                      + ", ".join(f"{h.get('table')}.{h.get('column')}"
                                                  for h in hits[:4])
                                      + (f": {why}" if why else ""), 240)})
        if verdict != "no":
            return None
        again = self._call(self.tools.absent_everywhere, term, False)
        return again if isinstance(again, tuple) and len(again) == 3 else None

    def _values_say(self, term, columns):
        """(verdict, why) of self.weigh for a term on some columns, asked
        once per question and term; ("unknown", "") without it or when it
        fails. A stopped job stops it."""
        if self.weigh is None:
            return "unknown", ""
        key = (str(term).lower(), tuple((c.get("table"), c.get("column")) for c in columns))
        if key not in self._weighed:
            try:
                got = self.weigh(term, columns, self._question)
            except Exception as e:
                if getattr(e, "stops_the_job", False):
                    raise
                got = None
            self._weighed[key] = got if isinstance(got, tuple) and len(got) == 2 \
                else ("unknown", "")
        return self._weighed[key]

    def _closed_miss(self, sql):
        """(table, column, value, values held) when the check filters a
        closed column (the dictionary's labels) directly, "column = 'x'",
        "column LIKE '%x%'" or "column IN ('x', 'y')", on values none of its
        codes or labels holds (a LIKE read as a pattern, every value of an
        IN missing), no row holds them either, and the model, shown the
        column's values, says the phrase cannot be read off them ("by
        ocean" is "SEASHP"). None otherwise: a subquery, an expression, a
        held code, a check that cannot run."""
        try:
            import sqlglot
            from sqlglot import exp
            tree = sqlglot.parse_one(strip_comments(sql), read="mysql")
        except Exception:
            return None
        aliases = {}
        for t in tree.find_all(exp.Table):
            real = self.view.table(t.name)
            if real:
                aliases[(t.alias_or_name or t.name).lower()] = real
                aliases[t.name.lower()] = real
        only = next(iter(set(aliases.values()))) if len(set(aliases.values())) == 1 else None
        clar = getattr(self.tools, "clar", None)
        for node in tree.find_all(exp.EQ, exp.Like, exp.ILike, exp.In):
            if node.find(exp.Select):
                continue
            column, values = node.this, None
            if isinstance(node, exp.In):
                values = None if node.args.get("query") else list(node.expressions)
            elif isinstance(node.expression, exp.Column) and isinstance(node, exp.EQ):
                column, values = node.expression, [node.this]
            else:
                values = [node.expression]
            if not isinstance(column, exp.Column) or not values \
                    or not all(isinstance(v, exp.Literal) and v.is_string for v in values):
                continue
            table = aliases.get((column.table or "").lower()) if column.table else only
            held = self._closed_values(clar, table, column.name) if table else {}
            if not held:
                continue
            like = isinstance(node, (exp.Like, exp.ILike))
            names = [str(c) for c in held] + [str(lbl) for lbl in held.values() if lbl]

            def holds(text):
                if like:
                    pattern = "".join(".*" if ch == "%" else "." if ch == "_" else re.escape(ch)
                                      for ch in text)
                    return any(re.fullmatch(pattern, n, re.IGNORECASE) for n in names)
                return any(text.strip().lower() == n.lower() for n in names)
            texts = [str(v.this) for v in values]
            if any(holds(t) for t in texts):
                continue
            if not self._no_row_holds(table, column.name, texts, like):
                continue
            verdict, _why = self._values_say(" ".join(t.strip("%_ ") for t in texts),
                                             [{"table": table, "column": column.name}])
            if verdict != "no":
                continue
            return table, column.name, ", ".join(t.strip("%_ ") for t in texts), \
                ", ".join(sorted(str(c) for c in held))
        return None

    def _no_row_holds(self, table, column, texts, like):
        """Whether no row of the table holds these values in the column,
        on their own, counted; False when the count cannot be read."""
        quoted = ["'" + t.replace("\\", "\\\\").replace("'", "''") + "'" for t in texts]
        where = (f"`{column}` LIKE {quoted[0]}" if like and len(quoted) == 1
                 else f"`{column}` IN ({', '.join(quoted)})")
        sql = f"SELECT 1 FROM `{table}` WHERE {where} LIMIT 1"
        res = self._call(self.tools.run_count, sql)
        if not getattr(res, "ok", False):
            return False
        return matching_rows(res, sql) == 0

    def _closed_values(self, clar, table, column):
        """{code: label} of a column whose values the dictionary lists, {}
        else. The catalogue's types are not read: it says "enum" without
        the values."""
        try:
            return dict(clar.enum_labels(table, column) or {}) if clar is not None else {}
        except Exception:
            return {}

    def _value_labels(self, table):
        """{code in lower case: label} over the closed columns of a table,
        as the dictionary declares them (Clarifier.enum_labels); {} when
        the table, its columns or the dictionary are unknown. Labels only,
        never descriptions: a description is prose ("NULL for current
        employees" under termination_date) and a word met in it says
        nothing; given to the closed question, descriptions also lost a
        real choice in the offline replay (Library Q08, 21 of 25 against
        22 without)."""
        clar = getattr(self.tools, "clar", None)
        columns_of = getattr(self.view, "columns_of", None)
        t = self.view.table(table or "") if table else None
        if clar is None or columns_of is None or not t:
            return {}
        out = {}
        try:
            for column, _type in columns_of(t):
                for code, label in (clar.enum_labels(t, column) or {}).items():
                    out[str(code).lower()] = str(label or "")
        except Exception:
            return {}
        return out

    def _stored_words(self, phrase, tables, nouns=()):
        """(table, column, value) when a word of the phrase is stored as a
        value; ordinary words, operation words and the names of the things
        counted (`nouns`) are not looked up: "orders" is stored in
        audit_log.object_type, which says nothing of where "recent" begins
        (review of 26 October)."""
        words = [w for w in _words(phrase) if len(w) >= 3 and w.lower() not in STOPWORDS
                 and Clarifier._singular(w.lower()) not in nouns]
        for w in words[:MAX_STORED_WORDS]:
            res = self._call(self.tools.find_value, w, tables or None)
            if not getattr(res, "ok", False):
                continue
            for hit in (res.data or {}).get("hits") or []:
                for m in hit.get("matches") or []:
                    if str(m).strip().lower() == w.lower():
                        return hit.get("table"), hit.get("column"), m
        return None
