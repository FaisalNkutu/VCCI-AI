"""The acceptance test that turns "reusable" from a claim into a result.

The same audit code runs against two databases with no table name in
common: our products sandbox and a library schema. The QUERIES differ,
because the schemas differ; the CODE does not, and neither do the
verdicts. Anything hardcoded to one schema fails here rather than at a
customer's site, which is the whole point of keeping a second database
around.

Both graphs are built by build_graph.py from information_schema, so the
test also proves G1 reads a schema it has never seen.

    .venv/Scripts/python src/graph_lab/test_portability.py
"""

import os

# the column index is on by default; a test never builds one in a real
# Qdrant, and the tests that need one give it directly
os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")

from db_profile import DbProfile
from schema_graph import Graph, audit_joins, audit_traps, explain_check

# Per database: the same five situations, written in that schema's own
# vocabulary. The expected verdict is what must match across databases.
CASES = {
    "datagora_generic": {
        "anchors": ("warehouses", "suppliers"),
        "cases": [
            ("valid multi-hop join", "OK",
             "SELECT DISTINCT s.supplier_name FROM warehouses w "
             "JOIN inventory i ON i.warehouse_id = w.warehouse_id "
             "JOIN products p ON i.product_id = p.product_id "
             "JOIN product_suppliers ps ON ps.product_id = p.product_id "
             "JOIN suppliers s ON ps.supplier_id = s.supplier_id"),
            ("invented edge", "REJECT no-edge",
             "SELECT * FROM products p "
             "JOIN warehouses w ON p.category_id = w.warehouse_id"),
            ("wrong keys", "REJECT wrong-keys",
             "SELECT * FROM inventory i "
             "JOIN warehouses w ON i.product_id = w.warehouse_id"),
            ("chasm", "REJECT chasm/fan",
             "SELECT p.product_name, SUM(i.quantity_on_hand), "
             "COUNT(ps.supplier_id) FROM products p "
             "JOIN inventory i ON i.product_id = p.product_id "
             "JOIN product_suppliers ps ON ps.product_id = p.product_id "
             "GROUP BY p.product_name"),
            ("clean aggregate", "OK",
             "SELECT w.name, SUM(i.quantity_on_hand) FROM warehouses w "
             "JOIN inventory i ON i.warehouse_id = w.warehouse_id "
             "GROUP BY w.name"),
        ],
    },
    "datagora_lib": {
        "anchors": ("members", "authors"),
        "cases": [
            ("valid multi-hop join", "OK",
             "SELECT DISTINCT a.last_name FROM members m "
             "JOIN loans l ON l.member_id = m.member_id "
             "JOIN books b ON l.book_id = b.book_id "
             "JOIN book_authors ba ON ba.book_id = b.book_id "
             "JOIN authors a ON ba.author_id = a.author_id"),
            ("invented edge", "REJECT no-edge",
             "SELECT * FROM books b "
             "JOIN members m ON b.genre_id = m.member_id"),
            ("wrong keys", "REJECT wrong-keys",
             "SELECT * FROM loans l "
             "JOIN members m ON l.book_id = m.member_id"),
            ("chasm", "REJECT chasm/fan",
             "SELECT b.title, COUNT(ba.author_id), COUNT(l.loan_id) "
             "FROM books b "
             "JOIN book_authors ba ON ba.book_id = b.book_id "
             "JOIN loans l ON l.book_id = b.book_id GROUP BY b.title"),
            ("clean aggregate", "OK",
             "SELECT m.last_name, COUNT(*) FROM members m "
             "JOIN loans l ON l.member_id = m.member_id "
             "GROUP BY m.last_name"),
        ],
    },
}


def kind(verdicts):
    """The worst verdict of a join audit, as a comparable label."""
    bad = [v for v in verdicts if v[0] != "OK"]
    return bad[0][0] if bad else "OK"


def main():
    results = {}
    for name, spec in CASES.items():
        profile = DbProfile.load(name)
        drv = profile.connect_neo4j()
        graph = Graph.from_profile(profile, drv)
        con = profile.connect_mysql()

        print(f"\n{'='*70}\n{name}  ({len(graph.edges)} edges read from "
              f"the graph built by G1)\n{'='*70}")

        a, b = spec["anchors"]
        sub = graph.force_union_subschema([a, b])
        print(f"  shortest path {a} -> {b}: {' > '.join(sub)}")

        passed = []
        for label, expected, sql in spec["cases"]:
            got = kind(audit_joins(sql, graph))
            if got == "OK":
                trap = audit_traps(sql, graph)
                if trap[0] != "OK":
                    got = trap[0]
            ok = got == expected
            passed.append(ok)
            print(f"  {'PASS' if ok else 'FAIL'}  {label:22} "
                  f"expected {expected:18} got {got}")

        cart = ("SELECT * FROM " +
                ", ".join(sorted({t for t, *_ in
                                  [(e[0],) for e in graph.edges]})[:2]))
        print(f"  EXPLAIN dry-run: {explain_check(cart, con)[0]}")

        results[name] = passed
        con.close()
        drv.close()

    print(f"\n{'='*70}")
    every = [p for ps in results.values() for p in ps]
    for name, ps in results.items():
        print(f"  {name:20} {sum(ps)}/{len(ps)}")
    print(f"  the same code, two unrelated schemas: "
          f"{sum(every)}/{len(every)}")
    if all(every):
        print("  PORTABLE: no verdict depended on a table name.")
    else:
        raise SystemExit("a verdict differed between schemas")


if __name__ == "__main__":
    main()
