"""Fast, model-free checks for resumable coverage batches.

    .venv/Scripts/python src/graph_lab/test_coverage.py
"""

import contextlib
import csv
import io
import os

# the column index is on by default; a test never builds one in a real
# Qdrant, and the tests that need one give it directly
os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
import pathlib
import sys
import tempfile
import unittest

# Tests never trace. The Langfuse client reads the repository .env,
# so without this every run of the suite sent its stand-in questions
# to a real Langfuse, and a suite that must run offline depended on a
# tracing server being up.
os.environ["DATAGORA_TRACING"] = "off"
# the developer's own .env must not change what these tests check
os.environ["DATAGORA_DOTENV"] = "off"
# nor the settings page's real file: a store of its own, empty
os.environ["DATAGORA_DATA_DIR"] = tempfile.mkdtemp(prefix="datagora-tests-")
from types import SimpleNamespace
from unittest.mock import Mock, patch

import coverage as subject


def outcome(action="ANSWER", reason=""):
    return SimpleNamespace(action=action, reason=reason, question="",
                           checked=False, kind="AmbiValue", options=[])


class AssessTests(unittest.TestCase):
    def test_one_column_csv_header_is_not_treated_as_a_question(self):
        rows = subject.read_questions_from_text(
            'question\nfirst\n"second, with comma"\n')
        self.assertEqual(rows, [
            {"question": "first"}, {"question": "second, with comma"}])

    def test_a_csv_row_without_a_question_cannot_shift_stream_indices(self):
        rows = subject.read_questions_from_text(
            "id,question\n1,first\n2,\n3,third\n")
        self.assertEqual([(r["id"], r["question"]) for r in rows],
                         [("1", "first"), ("3", "third")])

    def test_the_question_column_is_never_an_id_that_says_question(self):
        # review of 26 October: question_id,question judged "Q1", "Q2"...
        rows = subject.read_questions_from_text(
            "question_id,question\nQ1,How many staff?\nQ2,Which teams?\n")
        self.assertEqual([r["question"] for r in rows], ["How many staff?", "Which teams?"])
        self.assertEqual(rows[0]["question_id"], "Q1")
        rows = subject.read_questions_from_text("question_no,question_text\n1,Who?\n")
        self.assertEqual(rows[0]["question"], "Who?")

    def test_a_short_row_and_a_stray_comma_leave_text_under_named_columns(self):
        # a None key broke sorted() in job_id, a None value a later resume
        rows = subject.read_questions_from_text(
            "id,theme,question\nQ1,staff,How many staff, and teams?\nQ2,teams\nQ3,x,Short\n")
        self.assertEqual([r["question"] for r in rows], ["How many staff, and teams?", "Short"])
        self.assertTrue(all(None not in r and None not in r.values() for r in rows))
        subject.job_id(rows)
        rows = subject.read_questions_from_text("id,question,theme\nQ1,Short\n")
        self.assertEqual(rows, [{"id": "Q1", "question": "Short", "theme": ""}])

    def test_a_quoted_question_over_two_lines_keeps_them(self):
        rows = subject.read_questions_from_text('id,question\nQ1,"line one\n\nline two"\n')
        self.assertEqual(rows[0]["question"], "line one\n\nline two")
        rows = subject.read_questions_from_text('\n\nquestion\nfirst\n')
        self.assertEqual(rows, [{"question": "first"}])

    def test_review_of_the_fixes_the_csv_shapes(self):
        read = subject.read_questions_from_text
        # a one-column file keeps a stray comma, whatever its header says
        self.assertEqual(read("question\nWhat is A, and B?\n"), [{"question": "What is A, and B?"}])
        self.assertEqual(read("Questions\nfirst\n"), [{"question": "first"}])
        # doubled quotes are quotes, over two lines too
        rows = read('id,question\n1,"He said ""hi"", then?"\n2,"one\n""two"""\n')
        self.assertEqual([r["question"] for r in rows], ['He said "hi", then?', 'one\n"two"'])
        # a delimiter that ends the line is no cell
        self.assertEqual(read("id,question\n1,What is A?,\n")[0]["question"], "What is A?")
        # a plain list whose first line holds "question" and a comma
        self.assertEqual([r["question"] for r in read("Which question types, by month?\nAnd more?\n")],
                         ["Which question types, by month?", "And more?"])
        # the text, never its id, number, type or index
        for header, want in (("Question #,Question text", "Who?"),
                             ("question_type,question_text", "Who?"),
                             ("question_index,question_body", "Who?")):
            self.assertEqual(read(f"{header}\n7,Who?\n")[0]["question"], want, header)

    def test_remaining_positions_distinguish_identical_questions(self):
        questions = [{"question": "same"}, {"question": "same"},
                     {"question": "last"}]
        remaining = subject.remaining_questions(questions, completed=[1])
        self.assertEqual([index for index, _question in remaining], [0, 2])

    def test_a_threshold_a_person_holds_is_not_a_gap_in_the_database(self):
        # NOT COVERED tells a client their data cannot express something,
        # so it may only rest on a sweep that could have found it. A
        # judgement can never be found: no schema stores "nearly full",
        # it stores a capacity. Claiming absence on that sweep told a
        # client their warehouses table could not answer a question about
        # the capacity column sitting in it.
        import ambisql

        clar = ambisql.Clarifier.for_connection(lambda: None, "theirs")
        for phrase in ("nearly full", "cheap", "what constitutes 'cheap'",
                       "expensive in what sense?", "sell fast",
                       "recently", "the best suppliers"):
            self.assertTrue(clar.is_a_judgement(phrase),
                            f"{phrase!r} should be read as a judgement")
        # A precise operation is not a judgement, however superlative it
        # sounds. "top 5 by capacity" and "average lead time" say exactly
        # what they want, and reading them as vague turned two ordinary
        # aggregates into "tell me more".
        for phrase in ("the top 5 warehouses by capacity",
                       "average lead time in days", "how many loans",
                       "taller than average"):
            self.assertFalse(clar.is_a_judgement(phrase),
                             f"{phrase!r} is precise, not a judgement")
        # a real attribute the schema may or may not hold is not a
        # judgement, so a denial about it stays available
        for phrase in ("warranty duration", "blood type", "gluten free",
                       "email address", "shipping weight"):
            self.assertFalse(clar.is_a_judgement(phrase),
                             f"{phrase!r} is an attribute, not a judgement")

    def test_only_a_checked_sweep_may_say_the_database_cannot_do_it(self):
        # the rule the verdicts rest on, in one place
        guided = SimpleNamespace(action="GUIDE", reason="needs a threshold",
                                 question="say more", kind="AmbiValue",
                                 checked=False, options=[])
        self.assertEqual(subject.classify(guided)[0], subject.NEEDS_MORE)
        guided.checked = True
        self.assertEqual(subject.classify(guided)[0], subject.NOT_COVERED)

    def test_a_foreign_model_may_fence_its_json_like_a_real_one_does(self):
        # a production team passes a plain function, and their model wraps
        # JSON in prose and ``` fences exactly like ours. Accepting only a
        # bare object made every question UNKNOWN for them.
        import ambisql

        adapter = ambisql._Callable(
            lambda system, user: 'Here is the analysis:\n'
                                 '```json\n{"ambiguous": false}\n```\n')
        self.assertEqual(adapter.json("s", "u"), {"ambiguous": False})
        self.assertEqual(adapter.last_error, "")

        # a dict straight from their client is still taken as it is
        plain = ambisql._Callable(lambda system, user: {"ambiguous": True})
        self.assertEqual(plain.json("s", "u"), {"ambiguous": True})

        # and prose with no JSON in it is still reported, not guessed at
        prose = ambisql._Callable(lambda system, user: "I am not sure.")
        self.assertIsNone(prose.json("s", "u"))
        self.assertIn("did not return JSON", prose.last_error)

    def test_held_verdicts_are_matched_by_question_not_by_position(self):
        # the page holds verdicts for two questions and a third is added
        # at the top: positions all shift, so matching on them would
        # credit each verdict to its neighbour
        questions = [{"question": "new one"}, {"question": "alpha"},
                     {"question": "beta"}]
        todo = subject.remaining_by_text(questions, ["alpha", "beta"])
        self.assertEqual([index for index, _q in todo], [0])

    def test_editing_one_question_leaves_only_that_one_to_assess(self):
        questions = [{"question": "alpha"}, {"question": "beta, reworded"}]
        todo = subject.remaining_by_text(questions, ["alpha", "beta"])
        self.assertEqual([q["question"] for _i, q in todo], ["beta, reworded"])

    def test_two_identical_questions_need_two_held_verdicts(self):
        questions = [{"question": "same"}] * 3
        todo = subject.remaining_by_text(questions, ["same", "same"])
        self.assertEqual([index for index, _q in todo], [2])

    def test_choice_sentence_lists_more_than_two_options(self):
        verdict = subject.Verdict(question="which date", verdict=subject.NEEDS_CHOICE,
            choices=["created_at", "updated_at", "closed_at"])
        sentence = verdict.sentence()
        self.assertNotIn("two ways", sentence)
        self.assertIn("created_at, updated_at, closed_at", sentence)

    def test_ordinary_failure_becomes_unknown_and_batch_continues(self):
        clarifier = Mock()
        clarifier.clarify.side_effect = [RuntimeError("offline"), outcome()]
        with patch.object(subject, "Clarifier", return_value=clarifier):
            verdicts = subject.assess(
                [{"id": "1", "question": "first"},
                 {"id": "2", "question": "second"}],
                profile=object())

        self.assertEqual([v.verdict for v in verdicts],
                         [subject.UNKNOWN, subject.ANSWERABLE])
        self.assertEqual(verdicts[0].extra, {"id": "1"})

    def test_keyboard_interrupt_is_not_turned_into_a_verdict(self):
        clarifier = Mock()
        clarifier.clarify.side_effect = KeyboardInterrupt
        with patch.object(subject, "Clarifier", return_value=clarifier), \
                self.assertRaises(KeyboardInterrupt):
            subject.assess(["question"], profile=object())

    def test_model_configuration_exit_becomes_unknown(self):
        clarifier = Mock()
        clarifier.clarify.side_effect = SystemExit("missing model")
        with patch.object(subject, "Clarifier", return_value=clarifier):
            verdicts = subject.assess(["question"], profile=object())
        self.assertEqual(verdicts[0].verdict, subject.UNKNOWN)
        self.assertIn("missing model", verdicts[0].missing)

    def test_stop_on_error_stops_on_an_error_outcome(self):
        clarifier = Mock()
        clarifier.clarify.return_value = outcome("ERROR", "model offline")
        with patch.object(subject, "Clarifier", return_value=clarifier), \
                self.assertRaisesRegex(RuntimeError, "model offline"):
            subject.assess(["question"], profile=object(),
                           stop_on_error=True)


class LedgerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = pathlib.Path(self.tmp.name) / "verdicts.csv"

    def tearDown(self):
        self.tmp.cleanup()

    def test_a_saved_run_uses_its_ledger_not_browser_completion(self):
        # The browser may remember Q01-Q02 from another output name.  It
        # cannot recreate their complete verdict rows in a newly named
        # server file, so that file's own ledger must decide what remains.
        questions = [{"question": "first"}, {"question": "second"}]
        empty_ledger = SimpleNamespace(pending=lambda rows: list(rows))
        self.assertEqual(subject.saved_todo(questions, empty_ledger),
                         list(enumerate(questions)))

    def open_ledger(self):
        return subject.Ledger(self.path, ["id"])

    def test_each_verdict_leaves_how_it_was_reached_beside_the_csv(self):
        import json
        ledger = self.open_ledger()
        reply = {"ambiguous": True, "phrase": "per department"}
        ledger.add(subject.Verdict(
            question="q", verdict=subject.ANSWERABLE, kind="AmbiSchema",
            choices=["departments.name"], extra={"id": "E18"},
            trace={"reply": reply, "tables_shown": ["absences"]}), index=17)
        # a verdict with no trace, from a clarifier of another make
        ledger.add(subject.Verdict(question="r", verdict=subject.UNKNOWN,
                                   extra={"id": "E19"}))
        ledger.close()
        with open(self.path, encoding="utf-8-sig", newline="") as fh:
            self.assertEqual(csv.DictReader(fh).fieldnames,
                             ["id"] + subject.RESULT_FIELDS)
        lines = [json.loads(line) for line in subject.trace_path(self.path)
                 .read_text(encoding="utf-8").splitlines()]
        self.assertEqual(len(lines), 2)
        self.assertEqual(lines[0]["index"], 17)
        self.assertEqual(lines[0]["id"], "E18")
        # the kind the CSV blanks on an answer is kept here
        self.assertEqual(lines[0]["kind"], "AmbiSchema")
        self.assertEqual(lines[0]["reply"], reply)
        self.assertEqual(lines[0]["tables_shown"], ["absences"])
        self.assertIsNone(lines[1]["index"])

    def test_a_trace_that_cannot_be_written_never_costs_the_verdict(self):
        ledger = self.open_ledger()
        with patch.object(subject, "trace_path",
                          side_effect=OSError("disk full")):
            ledger.add(subject.Verdict(question="q", verdict=subject.ANSWERABLE,
                                       extra={"id": "1"}))
        ledger.close()
        with open(self.path, encoding="utf-8-sig", newline="") as fh:
            self.assertEqual(len(list(csv.DictReader(fh))), 1)

    def test_judging_records_what_the_clarifier_kept(self):
        result = SimpleNamespace(action="ANSWER", reason="r", question="",
                                 checked=False, empty=False, kind="AmbiSchema",
                                 options=[])
        clar = SimpleNamespace(clarify=lambda _t: result,
                               last_reply={"ambiguous": False},
                               last_shown=None)
        v = subject._judge_core(clar, "q", {}, False)
        self.assertEqual(v.trace["reply"], {"ambiguous": False})
        self.assertNotIn("trace", v.model_dump())

    def test_resume_counts_identical_duplicate_rows(self):
        questions = [
            {"id": "1", "question": "same"},
            {"id": "1", "question": "same"},
        ]
        ledger = self.open_ledger()
        ledger.add(subject.Verdict(question="same", verdict=subject.ANSWERABLE,
                                   extra={"id": "1"}))
        ledger.close()

        ledger = self.open_ledger()
        try:
            self.assertEqual(ledger.pending(questions), [questions[1]])
        finally:
            ledger.close()

    def test_unknown_is_saved_then_retried_on_resume(self):
        questions = [{"id": "1", "question": "retry me"}]
        ledger = self.open_ledger()
        ledger.add(subject.Verdict(question="retry me", verdict=subject.UNKNOWN,
                                   missing="offline", extra={"id": "1"}))
        ledger.close()
        with open(self.path, encoding="utf-8-sig", newline="") as fh:
            self.assertEqual(len(list(csv.DictReader(fh))), 1)

        ledger = self.open_ledger()
        try:
            self.assertEqual(ledger.pending(questions), questions)
        finally:
            ledger.close()
        with open(self.path, encoding="utf-8-sig", newline="") as fh:
            self.assertEqual(len(list(csv.DictReader(fh))), 0)

    def test_different_question_list_requires_restart(self):
        ledger = self.open_ledger()
        ledger.add(subject.Verdict(question="old", verdict=subject.ANSWERABLE,
                                   extra={"id": "1"}))
        ledger.close()

        ledger = self.open_ledger()
        try:
            with self.assertRaisesRegex(ValueError, "--restart"):
                ledger.pending([{"id": "2", "question": "new"}])
        finally:
            ledger.close()

    def test_incompatible_header_is_rejected(self):
        self.path.write_text("question,verdict\nold,ANSWERABLE\n",
                             encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "does not match"):
            self.open_ledger()

    def test_truncated_last_record_is_retried(self):
        questions = [{"id": "1", "question": "done"},
                     {"id": "2", "question": "truncated"}]
        ledger = self.open_ledger()
        ledger.add(subject.Verdict(question="done", verdict=subject.ANSWERABLE,
                                   extra={"id": "1"}))
        ledger.close()
        with open(self.path, "a", encoding="utf-8", newline="") as fh:
            fh.write("2,truncated,ANSWERABLE")

        ledger = self.open_ledger()
        try:
            self.assertEqual(ledger.pending(questions), [questions[1]])
        finally:
            ledger.close()

    def test_resumed_rows_are_restored_to_input_order(self):
        questions = [{"id": "1", "question": "first"},
                     {"id": "2", "question": "second"}]
        ledger = self.open_ledger()
        ledger.add(subject.Verdict(question="second", verdict=subject.ANSWERABLE,
                                   extra={"id": "2"}))
        ledger.add(subject.Verdict(question="first", verdict=subject.ANSWERABLE,
                                   extra={"id": "1"}))
        ledger.close()
        ledger.order_like(questions)

        with open(self.path, encoding="utf-8-sig", newline="") as fh:
            rows = list(csv.DictReader(fh))
        self.assertEqual([row["question"] for row in rows],
                         ["first", "second"])

    def test_write_verdicts_replaces_instead_of_appending(self):
        subject.write_verdicts(
            self.path,
            [subject.Verdict(question="old", verdict=subject.ANSWERABLE,
                             extra={"id": "1"})])
        subject.write_verdicts(
            self.path,
            [subject.Verdict(question="new", verdict=subject.NOT_COVERED,
                             missing="missing", extra={"id": "2"})])
        with open(self.path, encoding="utf-8-sig", newline="") as fh:
            rows = list(csv.DictReader(fh))
        self.assertEqual([(r["id"], r["question"]) for r in rows],
                         [("2", "new")])

    def test_input_metadata_cannot_collide_with_result_columns(self):
        questions = [{"kind": "customer-kind", "verdict": "expected",
                      "question": "can this be answered?"}]
        ledger = subject.Ledger(self.path, ["kind", "verdict"])
        ledger.add(subject.Verdict(
            question=questions[0]["question"], verdict=subject.ANSWERABLE,
            extra={"kind": "customer-kind", "verdict": "expected"}))
        ledger.close()

        with open(self.path, encoding="utf-8-sig", newline="") as fh:
            reader = csv.DictReader(fh)
            rows = list(reader)
        self.assertEqual(len(reader.fieldnames), len(set(reader.fieldnames)))
        self.assertEqual(rows[0]["kind"], "")
        self.assertEqual(rows[0]["verdict"], subject.ANSWERABLE)
        self.assertEqual(rows[0]["input_kind"], "customer-kind")
        self.assertEqual(rows[0]["input_verdict"], "expected")

        ledger = subject.Ledger(self.path, ["kind", "verdict"])
        try:
            self.assertEqual(ledger.pending(questions), [])
        finally:
            ledger.close()

    def test_assess_file_is_resumable_library_surface(self):
        questions = pathlib.Path(self.tmp.name) / "questions.csv"
        questions.write_text("id,question\n1,first\n2,second\n",
                             encoding="utf-8")
        progress = []
        clarifier = Mock()
        clarifier.clarify.return_value = outcome()
        with patch.object(subject, "Clarifier", return_value=clarifier):
            report = subject.assess_file(
                questions, self.path, profile=object(),
                on_each=lambda verdict, done, total:
                progress.append((verdict.question, done, total)))

        self.assertTrue(report.complete)
        self.assertEqual((report.total, report.processed, report.already_done),
                         (2, 2, 0))
        self.assertEqual(progress, [("first", 1, 2), ("second", 2, 2)])

        clarifier.reset_mock()
        with patch.object(subject, "Clarifier", return_value=clarifier):
            resumed = subject.assess_file(
                questions, self.path, profile=object())
        self.assertEqual((resumed.processed, resumed.already_done), (0, 2))
        clarifier.clarify.assert_not_called()


class GroundingTests(unittest.TestCase):
    """The shapes a capable model produces, and what they must become.

    Every case here is a real reply from gemma4:31b on the demo schema.
    They are replayed rather than re-asked, because the defect they cover
    only appears with a model good enough to propose columns that exist:
    the smaller model never produced them, so the whole family went
    unnoticed until a better reasoner made the output worse.
    """

    def setUp(self):
        # Every test here must leave the DATAGORA_* environment exactly as
        # it found it. A leak does not fail the test that caused it; it
        # fails some later one, only when the whole suite runs, which is
        # the most expensive kind of bug to find. So it is checked on the
        # way out of every test, and named.
        self._environment_before = {
            k: v for k, v in os.environ.items() if k.startswith("DATAGORA_")}
        self.addCleanup(self._check_nothing_leaked)

    def _check_nothing_leaked(self):
        after = {k: v for k, v in os.environ.items()
                 if k.startswith("DATAGORA_")}
        self.assertEqual(after, self._environment_before,
                         "this test left the DATAGORA_* environment changed")

    def clarifier(self, columns, views=None, rows=(), distinct=None,
                  soundex=None,
                  keys=(), boom=False):
        """A clarifier on a catalogue we state and data we state.

        The connection is a stub that answers every value lookup with
        `rows`, because AmbiValue is now decided against the data rather
        than against a word list: a literal the database really holds is
        a literal, whatever words it contains. A `lambda: None` factory
        used to be enough only because the guard returned before any
        query ran, which is exactly the behaviour being removed."""
        import ambisql

        # a literal lookup and a read of the distinct values are different
        # questions, and a stub that answers both the same way cannot
        # express the interesting state: no column NAMED for the phrase and
        # no row holding it, yet real values there to be looked at. Both
        # queries select distinct, so that word cannot tell them apart; a
        # literal lookup is the one that matches, by LIKE and then by
        # SOUNDEX when the LIKE finds nothing. Missing the SOUNDEX fallback
        # sent it the distinct values and every phrase looked like a
        # literal the database held. The stub ignores LIMIT, so a case that
        # turns on the ceiling states its values either side of it.
        class Cursor:
            def __init__(self):
                self.rows = rows

            def execute(self, sql, *_a, **_k):
                if boom:
                    raise RuntimeError("database lookup failed")
                text = str(sql).upper()
                a_value_lookup = "LIKE" in text or "SOUNDEX" in text
                if "SOUNDEX" in text and soundex is not None:
                    self.rows = soundex
                else:
                    self.rows = (distinct if distinct is not None
                                 and not a_value_lookup else rows)

            def fetchall(self):
                return [(r,) for r in self.rows]

            def fetchone(self):
                return (self.rows[0],) if self.rows else None

            def close(self):
                return None

        class Connection:
            def cursor(self):
                return Cursor()

            def close(self):
                return None

        # the value decision calls a model, which these tests must not do:
        # they pin the rules around it. One dedicated test below turns it
        # on with a model of its own.
        #
        # One key, set and restored by hand, and NOT a patch.dict. A
        # patch.dict snapshots the whole environment and restores the whole
        # snapshot, so a clarifier built inside a test's own
        # `with patch.dict({"DATAGORA_SCHEMA_SAMPLES": "0"})` photographed
        # that "0" and put it back at cleanup, after the `with` had removed
        # it. Every later test then ran with no schema values, and the one
        # that checked for them failed only when the whole suite ran.
        if not getattr(self, "_ask_values_pinned", False):
            previous = os.environ.get("DATAGORA_ASK_VALUES")
            os.environ["DATAGORA_ASK_VALUES"] = "off"

            def restore(previous=previous):
                if previous is None:
                    os.environ.pop("DATAGORA_ASK_VALUES", None)
                else:
                    os.environ["DATAGORA_ASK_VALUES"] = previous

            self.addCleanup(restore)
            self._ask_values_pinned = True
        clar = ambisql.Clarifier.for_connection(Connection, "theirs")
        clar._columns = columns
        # view name -> the tables it is built from, which is what decides
        # whether two readings are the same number written twice
        clar._views = dict(views or {})
        # which columns identify a row. Stated rather than queried, for the
        # same reason the catalogue is: a test should say what it assumes.
        clar._keys = {(t.lower(), c.lower()) for t, c in keys}
        return clar

    def verdict(self, clar, raw, question):
        return subject.classify(clar.ground(raw, question=question))[0]

    def test_a_comparison_to_something_absent_asks_rather_than_denies(self):
        # "cheaper than a coffee": the catalogue holds no coffee, so the
        # price to compare against can only come from the asker. It must
        # not be denied as a gap in the data, and must not be answered
        # with a menu of whatever the lookup happened to match.
        clar = self.clarifier({"products": [("product_name", "varchar"),
                                            ("price", "decimal")]}, rows=())
        got = self.verdict(clar, {
            "ambiguous": True, "kind": "AmbiValue", "phrase": "a coffee",
            "value": "coffee", "reason": "the price of a coffee is not given",
            "candidates": [{"table": "products", "column": "product_name"}]},
            "Which products are cheaper than a coffee?")
        self.assertEqual(got, subject.NEEDS_MORE)

    def test_soundex_does_not_turn_coffee_into_a_menu_of_drills(self):
        # MariaDB's phonetic match is evidence for a misspelling, not proof
        # that two unrelated concepts are equivalent.  This is the exact
        # shape seen in Q15 of the measured 31B coverage run.
        drills = ("Heavy Duty Drill", "Stainless Steel Drill",
                  "Galvanised Drill", "Professional Drill")
        clar = self.clarifier(
            {"products": [("product_name", "varchar"),
                          ("price", "decimal")]},
            rows=(), soundex=drills)
        out = clar.ground({
            "ambiguous": True, "kind": "AmbiValue", "phrase": "a coffee",
            "value": "coffee", "reason": "the price of coffee is unknown",
            "candidates": [{"table": "products",
                            "column": "product_name"}]},
            question="Which products are cheaper than a coffee?")
        self.assertEqual(subject.classify(out)[0], subject.NEEDS_MORE)
        self.assertEqual(out.options, [])

    def test_an_explicit_count_is_not_a_count_or_sum_choice(self):
        # Q14 says "how many", so the operation is already explicit.  A
        # model-proposed count/sum menu must not manufacture ambiguity.
        clar = self.clarifier({"products": [("product_id", "int")]})
        out = clar.ground({
            "ambiguous": True, "kind": "AmbiView",
            "phrase": "how many products",
            "reason": "count rows or add quantities",
            "operations": ["count", "sum"]},
            question="How many products did we sell recently?")
        self.assertEqual(subject.classify(out)[0], subject.ANSWERABLE)
        self.assertEqual(out.options, [])

    def test_a_literal_the_database_holds_is_a_literal_whatever_it_is_called(self):
        # "New York" contains "new" and "Heavy Duty Drill" contains
        # "heavy", both words that describe vagueness elsewhere. A value
        # sitting in a column is not an opinion, and deciding it against
        # a word list made the whole of near_values unreachable for every
        # name starting with New, Old, High or Long.
        clar = self.clarifier({"warehouses": [("city", "varchar")]},
                              rows=("New York",))
        out = clar.ground({
            "ambiguous": True, "kind": "AmbiValue", "phrase": "New York",
            "value": "New York", "reason": "stored form",
            "candidates": [{"table": "warehouses", "column": "city"}]},
            question="Which warehouses are in New York?")
        self.assertTrue(out.options, "a value that is really there must ground")
        self.assertEqual(out.options[0].label, "New York")

    def test_a_judgement_is_not_a_menu_of_operations(self):
        clar = self.clarifier({"products": [("price", "decimal")]})
        got = self.verdict(clar, {
            "ambiguous": True, "kind": "AmbiView", "phrase": "cheap",
            "reason": "'cheap' is subjective",
            "operations": ["list", "minimum", "rank"]},
            "Which products are cheap?")
        self.assertEqual(got, subject.NEEDS_MORE)

    def test_number_of_is_also_an_explicit_count(self):
        # The second common spelling of a count must behave identically.
        clar = self.clarifier({"loans": [("loan_id", "int"),
                                         ("quantity", "int")]})
        got = self.verdict(clar, {
            "ambiguous": True, "kind": "AmbiView", "phrase": "how many loans",
            "reason": "count rows or add quantities",
            "operations": ["count", "sum"]},
            "Number of loans still open")
        self.assertEqual(got, subject.ANSWERABLE)

    def test_absence_the_model_states_and_the_data_confirms_is_not_covered(self):
        # the model said so plainly and we downgraded it to "tell me
        # more", throwing away the answer a better reasoner got right
        clar = self.clarifier({"products": [("price", "decimal")]})
        got = self.verdict(clar, {
            "ambiguous": True, "kind": "AmbiFallacy",
            "phrase": "warranty duration", "candidates": [],
            "reason": "The database does not contain any information "
                      "regarding product warranties."},
            "What is the warranty duration of each product?")
        self.assertEqual(got, subject.NOT_COVERED)

    def test_a_view_and_its_table_are_not_a_choice(self):
        # the same number written twice is not an ambiguity
        clar = self.clarifier(
            {"inventory": [("quantity_on_hand", "int")],
             "inventory_reorder_report": [("quantity_on_hand", "int")]},
            views={"inventory_reorder_report": {"inventory"}})
        got = self.verdict(clar, {
            "ambiguous": True, "kind": "AmbiSchema", "phrase": "reorder level",
            "reason": "two columns hold it",
            "candidates": [
                {"table": "inventory", "column": "quantity_on_hand"},
                {"table": "inventory_reorder_report",
                 "column": "quantity_on_hand"}]},
            "Which products are below their reorder level?")
        self.assertEqual(got, subject.ANSWERABLE)

    def test_two_tables_sharing_a_column_name_are_still_a_choice(self):
        # the collapse used to match on the bare column name, so any two
        # readings that happened to be called created_at became one. It
        # now requires the view to be built from that very table.
        clar = self.clarifier(
            {"products": [("created_at", "timestamp")],
             "suppliers": [("created_at", "timestamp")],
             "active_products_summary": [("created_at", "timestamp")]},
            views={"active_products_summary": {"products"}})
        out = clar.ground({
            "ambiguous": True, "kind": "AmbiSchema", "phrase": "created",
            "reason": "two tables record it",
            "candidates": [{"table": "products", "column": "created_at"},
                           {"table": "suppliers", "column": "created_at"}]},
            question="Which ones were created first?")
        self.assertEqual(subject.classify(out)[0], subject.NEEDS_CHOICE)
        self.assertEqual(len(out.options), 2)

    def test_a_description_lets_a_question_find_a_column_its_name_hides(self):
        # the synonym problem, which no amount of string matching on
        # identifiers can solve: a question about "how reliable" a supplier
        # is will never match a column called `rating`. A dictionary is the
        # only thing that can connect them, and it is optional.
        import json as _json
        import tempfile as _tempfile

        with _tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "d.json"
            path.write_text(_json.dumps({"columns": {
                "suppliers.rating": "our own score, how reliable they were"}}),
                encoding="utf-8")
            bare = self.clarifier({"suppliers": [("rating", "decimal")]})
            self.assertEqual(bare.resembles_column("how reliable"), [])

            described = self.clarifier({"suppliers": [("rating", "decimal")]})
            described.profile = SimpleNamespace(descriptions=str(path))
            described._meanings = None
            self.assertEqual(described.resembles_column("how reliable"),
                             ["suppliers.rating"])
            self.assertIn("how reliable they were", described.schema_text())

    def test_an_unreadable_dictionary_is_ignored_not_fatal(self):
        clar = self.clarifier({"suppliers": [("rating", "decimal")]})
        clar.profile = SimpleNamespace(descriptions="/no/such/file.json")
        clar._meanings = None
        self.assertEqual(clar.means("suppliers", "rating"), "")
        # the schema still renders, table and column, with no description
        # line: an unreadable dictionary must cost the meanings and nothing
        # else
        text = clar.schema_text()
        self.assertIn("TABLE suppliers", text)
        self.assertIn("rating", text)
        self.assertNotIn("--", text)

    def test_the_model_sees_types_keys_joins_and_real_values(self):
        # Sending names alone is what made a model propose genres.genre_id
        # for a question about genres: nothing said the id holds 1, 2, 3
        # and the name holds Fantasy, Poetry, History. AmbiSQL renders a
        # column as name, primary key, type, description and sample values,
        # and that is the part of their design that transfers whatever the
        # model, because it is evidence in the prompt rather than length.
        clar = self.clarifier(
            {"genres": [("genre_id", "int"), ("name", "varchar")],
             "books": [("book_id", "int"), ("genre_id", "int")]},
            distinct=("Fantasy", "Poetry", "History"),
            keys=(("genres", "genre_id"), ("books", "book_id")))
        clar._foreign_keys = {("books", "genre_id"): ("genres", "genre_id")}
        text = clar.schema_text()
        self.assertIn("PRIMARY KEY", text)
        self.assertIn("-> genres.genre_id", text)       # the join path
        self.assertIn("e.g. Fantasy, Poetry, History", text)
        self.assertIn("varchar", text)

    def test_no_values_are_sent_when_a_deployment_says_so(self):
        # a schema holding personal data and a model endpoint outside the
        # building: the values stay home, and the rest of the line still
        # goes, since types and keys disclose nothing about a person
        with patch.dict("os.environ", {"DATAGORA_SCHEMA_SAMPLES": "0"}):
            clar = self.clarifier({"members": [("email", "varchar")]},
                                  distinct=("alice@example.com",))
            text = clar.schema_text()
            self.assertNotIn("alice@example.com", text)
            self.assertNotIn("e.g.", text)
            self.assertIn("email", text)

    def test_the_model_decides_on_real_values_when_no_name_matches(self):
        # nothing is CALLED gluten, so no match can settle it. The columns
        # are identified first, their distinct values are read, and only
        # then is the model asked. A "no" is a denial the reason can be
        # quoted for; anything else must never become one.
        clar = self.clarifier(
            {"products": [("product_name", "varchar")]},
            rows=("18V Cordless Drill", "Heavy Duty Drill"))
        switch = patch.dict("os.environ", {"DATAGORA_ASK_VALUES": "on"})
        switch.start()
        self.addCleanup(switch.stop)
        candidates = [{"table": "products", "column": "product_name"}]

        clar._llm = SimpleNamespace(json=lambda *_a, **_k: {
            "decidable": False, "table": "products",
            "column": "product_name",
            "why": "these are power tool names and say nothing about gluten"})
        verdict, table, column, why = clar.decide_on_values(
            "gluten free", candidates, "Which products are gluten free?")
        self.assertEqual((verdict, table, column), ("no", None, None))
        self.assertIn("power tool", why)

        clar._llm = SimpleNamespace(json=lambda *_a, **_k: {
            "decidable": True, "table": "products", "column": "product_name",
            "why": "the names say Cordless"})
        self.assertEqual(clar.decide_on_values("cordless", candidates)[0],
                         "yes")

        # a model that cannot be reached, or invents a column, decides
        # nothing: not knowing must never be reported as an absence
        def boom(*_a, **_k):
            raise OSError("unreachable")

        clar._llm = SimpleNamespace(json=boom)
        self.assertEqual(clar.decide_on_values("gluten", candidates)[0],
                         "unknown")
        clar._llm = SimpleNamespace(json=lambda *_a, **_k: {
            "decidable": True, "table": "invented", "column": "nope",
            "why": "made up"})
        verdict, table, _c, _w = clar.decide_on_values("gluten", candidates)
        self.assertEqual(verdict, "unknown")
        self.assertIsNone(table)

    def test_a_value_yes_is_answerable_and_model_casing_is_normalised(self):
        clar = self.clarifier(
            {"products": [("product_name", "varchar"),
                          ("description", "text")]},
            rows=(), distinct=("Bread", "Rice", "Cordless drill"))
        switch = patch.dict("os.environ", {"DATAGORA_ASK_VALUES": "on"})
        switch.start()
        self.addCleanup(switch.stop)
        clar._llm = SimpleNamespace(json=lambda *_a, **_k: {
            "decidable": True, "table": "Products",
            "column": "Product_Name",
            "why": "the product names distinguish the concept"})
        out = clar.ground({
            "ambiguous": True, "kind": "AmbiSchema",
            "phrase": "gluten free", "reason": "two columns could mean it",
            "candidates": [{"table": "products", "column": "product_name"},
                           {"table": "products", "column": "description"}]},
            question="Which products are gluten free?")
        self.assertEqual(subject.classify(out)[0], subject.ANSWERABLE)
        self.assertEqual(out.options, [])

    def test_a_failed_database_sweep_never_becomes_not_covered(self):
        clar = self.clarifier(
            {"products": [("product_name", "varchar")]}, boom=True)
        out = clar.ground({
            "ambiguous": True, "kind": "AmbiFallacy",
            "phrase": "warranty duration", "candidates": [],
            "reason": "the schema appears not to contain warranties"},
            question="What is each product's warranty duration?")
        self.assertEqual(subject.classify(out)[0], subject.NEEDS_MORE)
        self.assertFalse(out.checked)

    def test_the_value_decision_is_off_when_the_deployment_says_so(self):
        clar = self.clarifier({"products": [("product_name", "varchar")]},
                              rows=("a drill",))
        clar._llm = SimpleNamespace(
            json=lambda *_a, **_k: self.fail("must not be called"))
        self.assertEqual(clar.decide_on_values(
            "gluten", [{"table": "products", "column": "product_name"}])[0],
            "unknown")

    def test_a_short_column_name_is_not_invisible_to_the_guard(self):
        # the length filter ran before punctuation was stripped, so "fee"
        # was invisible and "fee?" was not. A denial then went out about
        # a column sitting in the schema.
        clar = self.clarifier({"appointments": [("fee", "decimal")],
                               "products": [("sku", "varchar")]})
        self.assertEqual(clar.resembles_column("consultation fee"),
                         ["appointments.fee"])
        self.assertEqual(clar.resembles_column("fee"), ["appointments.fee"])
        self.assertEqual(clar.resembles_column("the sku"), ["products.sku"])
        # and a stopword must not echo a column it merely shares letters
        # with: "the" is inside "theme"
        clar = self.clarifier({"questions": [("theme", "varchar")]})
        self.assertEqual(clar.resembles_column("the oldest products"), [])

    def test_a_state_is_recognised_from_the_catalogue_not_from_a_word_list(self):
        # what may overrule the model has to be a fact, not a guess. A
        # moment is a moment because the catalogue says so; a closed
        # vocabulary is closed because asking for one more value than the
        # ceiling allows brought back fewer.
        clar = self.clarifier(
            {"loans": [("status", "varchar"), ("returned_at", "date")]},
            distinct=("borrowed", "returned", "late"))
        self.assertTrue(clar.records_a_state("loans", "returned_at"))
        self.assertTrue(clar.records_a_state("loans", "status"))
        # free text is not a state however suggestive its name. Thirteen
        # values, one past the default ceiling of twelve.
        clar = self.clarifier(
            {"products": [("product_name", "varchar")]},
            distinct=tuple(f"drill {n}" for n in range(13)))
        self.assertFalse(clar.records_a_state("products", "product_name"))
        # and a column nothing could be read from decides nothing either
        # way, rather than counting as a small vocabulary because zero is
        # a number below the ceiling
        clar = self.clarifier({"products": [("product_name", "varchar")]},
                              distinct=())
        self.assertFalse(clar.records_a_state("products", "product_name"))

    def test_a_key_is_not_a_state_however_few_values_it_holds(self):
        # measured on the real demo schemas: books.genre_id and
        # genres.genre_id both passed as closed vocabularies, because the
        # library has twelve genres. That is a count of rows, not a state,
        # and on a customer's larger table the same column would behave
        # differently. Exclusion is on being a key, read from the
        # catalogue, and not on being a number, because a boolean flag is
        # a real state.
        clar = self.clarifier(
            {"books": [("genre_id", "int"), ("status", "varchar")],
             "categories": [("is_active", "tinyint")]},
            distinct=("a", "b", "c"),
            keys=(("books", "genre_id"),))
        self.assertFalse(clar.records_a_state("books", "genre_id"))
        self.assertTrue(clar.records_a_state("books", "status"))
        self.assertTrue(clar.records_a_state("categories", "is_active"))
        # a catalogue that cannot be read excludes nothing rather than
        # taking the schema down with it
        clar._keys = None
        self.assertFalse(clar.is_a_key("books", "genre_id"))

    def test_the_model_may_not_withdraw_a_menu_built_on_a_state(self):
        # measured on gemma3:4b: "how many loans are still open" was
        # offered loans.status and loans.returned_at, which are exactly
        # the two columns that answer it, and the model said no. The menu
        # must stand. NOT COVERED is the one verdict a client repeats to
        # their management, and a 4b model's opinion is not evidence for
        # it when the catalogue says otherwise.
        clar = self.clarifier(
            {"loans": [("status", "varchar"), ("returned_at", "date")]},
            rows=(), distinct=("borrowed", "returned", "late"))
        switch = patch.dict("os.environ", {"DATAGORA_ASK_VALUES": "on"})
        switch.start()
        self.addCleanup(switch.stop)
        clar._llm = SimpleNamespace(json=lambda *_a, **_k: {
            "decidable": False, "table": "loans", "column": "status",
            "why": "the values do not say whether a loan is open"})
        got = clar.ground({
            "ambiguous": True, "kind": "AmbiSchema", "phrase": "still open",
            "reason": "two columns could mean it",
            "candidates": [{"table": "loans", "column": "status"},
                           {"table": "loans", "column": "returned_at"}]},
            question="How many loans are still open?")
        self.assertEqual(subject.classify(got)[0], subject.NEEDS_CHOICE)
        self.assertEqual(sorted(o.label for o in got.options),
                         ["loans.returned_at", "loans.status"])
        # the doubt is carried, not acted on: a reader sees what the model
        # saw without the component having denied anything
        self.assertIn("unsure", got.reason)

    def test_the_model_may_withdraw_a_menu_built_on_names(self):
        # the case the value step exists for. Nothing is CALLED gluten, no
        # row holds it, and the columns proposed hold power tool names. A
        # menu there would answer a question about gluten with
        # products.product_name, which no LIKE will ever satisfy. No
        # candidate records a state, so the model's no stands.
        clar = self.clarifier(
            {"products": [("product_name", "varchar"),
                          ("description", "text")]},
            rows=(), distinct=tuple(f"18V Drill {n}" for n in range(13)))
        switch = patch.dict("os.environ", {"DATAGORA_ASK_VALUES": "on"})
        switch.start()
        self.addCleanup(switch.stop)
        clar._llm = SimpleNamespace(json=lambda *_a, **_k: {
            "decidable": False, "table": "products",
            "column": "product_name",
            "why": "these are power tool names and say nothing about gluten"})
        got = clar.ground({
            "ambiguous": True, "kind": "AmbiSchema", "phrase": "gluten free",
            "reason": "two columns could mean it",
            "candidates": [{"table": "products", "column": "product_name"},
                           {"table": "products", "column": "description"}]},
            question="Which products are gluten free?")
        self.assertEqual(got.options, [])
        self.assertIn("power tool", got.reason)
        # withdrawn, and still not a denial: only our own sweep of the
        # database may write NOT COVERED
        self.assertNotEqual(subject.classify(got)[0], subject.NOT_COVERED)

    def vocabulary_file(self, **lists):
        """A vocabulary file on disk, cleaned up after the test."""
        import json
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        path = pathlib.Path(tmp.name) / "vocabulary.json"
        path.write_text(json.dumps(lists), encoding="utf-8")
        return str(path)

    def test_an_empty_result_is_an_answer_and_not_a_gap(self):
        # This component says whether a result is reachable, positive or
        # negative. It writes no SQL, so "the columns are there and no row
        # matches" is a verdict it owes the reader, and it is not the same
        # claim as "this database cannot express it".
        #
        # Measured on the demo library: "which books were written by
        # Shakespeare in 2020" came back NOT COVERED, "Nothing here can
        # express it", while authors.name and books.published_on both sit
        # in the schema and answer it in one query. There is simply no
        # Shakespeare among the authors. A benchmark needs this separated
        # too: a question whose correct answer is the empty set cannot be
        # scored like one the schema cannot reach.
        reachable = self.clarifier(
            {"authors": [("author_id", "int"), ("name", "varchar"),
                         ("born_year", "int")],
             "books": [("book_id", "int"), ("title", "varchar"),
                       ("published_on", "date")]})
        out = reachable.ground(
            {"ambiguous": True, "kind": "AmbiValue", "phrase": "Shakespeare",
             "reason": "the question names an author",
             "candidates": [{"table": "authors", "column": "name"}]},
            question="Which books were written by Shakespeare in 2020?")
        self.assertEqual(subject.classify(out)[0], subject.NO_DATA)
        self.assertTrue(out.empty)
        self.assertFalse(out.checked)
        # and it names the column that would have held it, so the reader
        # can repeat the check in one query
        self.assertIn("authors.name", out.question)

        # no column of any kind could hold a place, so this one is about
        # the schema and stays the denial it was
        unreachable = self.clarifier(
            {"members": [("member_id", "int"), ("full_name", "varchar"),
                         ("joined_at", "date")]})
        out = unreachable.ground(
            {"ambiguous": True, "kind": "AmbiValue", "phrase": "Paris",
             "reason": "the question names a city", "candidates": []},
            question="Which members live in Paris?")
        self.assertEqual(subject.classify(out)[0], subject.NOT_COVERED)
        self.assertFalse(out.empty)

        # a candidate that is not a text column cannot hold a literal, so
        # proposing one must not turn a denial into an empty result
        out = unreachable.ground(
            {"ambiguous": True, "kind": "AmbiValue", "phrase": "Paris",
             "reason": "the question names a city",
             "candidates": [{"table": "members", "column": "joined_at"}]},
            question="Which members live in Paris?")
        self.assertEqual(subject.classify(out)[0], subject.NOT_COVERED)

    def test_no_data_counts_as_judged_and_is_not_retried(self):
        # a resumed run must not re-ask it, and a batch must not fail on it
        self.assertIn(subject.NO_DATA, subject.FINAL_VERDICTS)

    def test_a_trade_adds_its_own_words_for_a_degree(self):
        # The 81 adjectives that withhold a denial were written by hand in
        # one language, and they are what stands between a vague word and
        # the worst claim this component makes. Measured on a shipments
        # schema holding due_date and delivered_at, "which shipments are
        # overdue?" came back NOT COVERED, "Nothing here can express it",
        # because `overdue` was not among them. So did delayed, stale and
        # urgent. Every one needs a threshold from the asker, which is the
        # case the set exists for.
        columns = {"shipments": [("due_date", "date"),
                                 ("delivered_at", "date"),
                                 ("carrier", "varchar")]}
        raw = {"ambiguous": True, "kind": "AmbiView",
               "reason": "a threshold is needed", "candidates": []}

        # four of them are in the defaults now
        for word in ("overdue", "delayed", "stale", "urgent"):
            clar = self.clarifier(columns)
            got = subject.classify(clar.ground(
                dict(raw, phrase=word), question=f"Which shipments are {word}?"))[0]
            self.assertEqual(got, subject.NEEDS_MORE, word)

        # a word no list elsewhere would carry is not, and that is what
        # the file is for
        clar = self.clarifier(columns)
        self.assertFalse(clar.is_a_judgement("knackered"))
        got = subject.classify(clar.ground(
            dict(raw, phrase="knackered"),
            question="Which shipments are knackered?"))[0]
        self.assertEqual(got, subject.NOT_COVERED)

        with patch.dict("os.environ", {"DATAGORA_VOCABULARY":
                                       self.vocabulary_file(
                                           judgements=["knackered"])}):
            clar = self.clarifier(columns)
            self.assertTrue(clar.is_a_judgement("knackered"))
            got = subject.classify(clar.ground(
                dict(raw, phrase="knackered"),
                question="Which shipments are knackered?"))[0]
            self.assertEqual(got, subject.NEEDS_MORE)

    def test_a_vocabulary_file_adds_and_never_replaces(self):
        # Additive is the safety property. A word a deployment adds can
        # only move a verdict from NOT COVERED to NEEDS MORE, so a
        # customer file cannot silence a denial the data earned, and a file
        # that forgets a word does not lose the engine's own.
        path = self.vocabulary_file(judgements=["knackered"],
                                    not_a_value=[], stopwords=[])
        with patch.dict("os.environ", {"DATAGORA_VOCABULARY": path}):
            clar = self.clarifier({"products": [("price", "decimal")]})
            self.assertTrue(clar.is_a_judgement("cheap"))      # ours
            self.assertTrue(clar.is_a_judgement("knackered"))  # theirs
            self.assertFalse(clar.is_a_judgement("audiobooks"))
            # the sets it left empty are still ours
            self.assertIn("nothing", clar.words_for(
                "not_a_value", clar.NOT_A_VALUE))
            self.assertIn("the", clar.words_for("stopwords", clar.STOPWORDS))

    def test_an_unreadable_vocabulary_leaves_the_defaults_in_place(self):
        # It must not take the database down, and it must not silently
        # become an empty vocabulary either, which would withdraw the
        # protection at the moment the file was meant to strengthen it.
        for bad in ("/nowhere/at/all/vocabulary.json",
                    self.vocabulary_file(judgements="not-a-list")):
            with patch.dict("os.environ", {"DATAGORA_VOCABULARY": bad}):
                clar = self.clarifier({"products": [("price", "decimal")]})
                self.assertTrue(clar.is_a_judgement("cheap"), bad)
                self.assertTrue(clar.is_a_judgement("overdue"), bad)

    def test_a_ceiling_moves_without_editing_the_source(self):
        # a customer schema that spells its states with more values than
        # ours must not need a patch. And a variable compose could not
        # resolve arrives as an empty string, which is not an answer.
        clar = self.clarifier({"products": [("grade", "varchar")]},
                              distinct=tuple(f"g{n}" for n in range(13)))
        self.assertFalse(clar.records_a_state("products", "grade"))
        with patch.dict("os.environ", {"DATAGORA_ENUMERATION": "20"}):
            self.assertTrue(clar.records_a_state("products", "grade"))
        for junk in ("", "   ", "lots", "0", "-5"):
            with patch.dict("os.environ", {"DATAGORA_ENUMERATION": junk}):
                self.assertEqual(clar.tuning("DATAGORA_ENUMERATION", 12), 12)

    def schema_for_echoes(self):
        return self.clarifier(
            {"genres": [("genre_id", "int"), ("name", "varchar")],
             "books": [("book_id", "int"), ("title", "varchar")],
             "questions": [("theme", "varchar")],
             "members": [("member_id", "int"), ("email", "varchar")]},
            keys=(("genres", "genre_id"), ("books", "book_id"),
                  ("members", "member_id")))

    def test_a_word_naming_a_table_points_at_its_label_not_its_key(self):
        # "genre" used to find genres.genre_id, the one column that could
        # never answer a question about genres, because the test was a
        # substring search on identifiers and genre_id contains "genre".
        clar = self.schema_for_echoes()
        self.assertEqual(clar.resembles_column("genre"), ["genres.name"])
        self.assertEqual(clar.resembles_column("book"), ["books.title"])
        self.assertNotIn("genres.genre_id", clar.resembles_column("genres"))

    def test_a_shared_word_is_not_enough_to_say_yes(self):
        # The same function decided two opposite things with one bar: to
        # withhold a denial, where any echo is enough, and to declare a
        # flagged question answerable, where it must not be. "theme park"
        # came back ANSWERABLE on the strength of questions.theme.
        clar = self.schema_for_echoes()
        self.assertEqual(clar.resembles_column("theme park"),
                         ["questions.theme"])   # still withholds a denial
        self.assertEqual(clar.answers_directly("theme park"), [])
        # and the case the shortcut exists for still gets its yes, because
        # "address" names the form of the value, not another concept
        self.assertEqual(clar.answers_directly("email addresses"),
                         ["members.email"])

    def test_a_partial_echo_is_a_suggestion_never_a_verdict(self):
        clar = self.schema_for_echoes()
        out = clar.ground(
            {"ambiguous": True, "kind": "AmbiSchema", "phrase": "theme park",
             "reason": "unclear", "candidates": []},
            question="Which theme parks are open?")
        verdict = subject.classify(out)[0]
        self.assertNotEqual(verdict, subject.ANSWERABLE)
        self.assertNotEqual(verdict, subject.NOT_COVERED)
        self.assertEqual([o.label for o in out.options], ["questions.theme"])

    def test_a_judgement_the_model_called_clear_still_needs_a_threshold(self):
        # replayed from gemma3:4b on the rewritten prompt: it named the word
        # it hesitated over and then said the question was clear. The
        # return used to happen before any judgement check could run, so
        # "which books are cheap?" was reported ANSWERABLE.
        clar = self.clarifier({"books": [("price", "decimal")]})
        out = clar.ground({"ambiguous": False, "kind": "AmbiSchema",
                           "phrase": "cheap",
                           "candidates": [{"table": "books",
                                           "column": "price"}]},
                          question="Which books are cheap?")
        self.assertEqual(subject.classify(out)[0], subject.NEEDS_MORE)
        # a ranking is exact and stays the model's call
        out = clar.ground({"ambiguous": False, "kind": "", "phrase": "cheapest",
                           "candidates": []},
                          question="What are the 5 cheapest books?")
        self.assertEqual(subject.classify(out)[0], subject.ANSWERABLE)
        # and a clear question with no phrase is simply clear
        out = clar.ground({"ambiguous": False, "phrase": "", "candidates": []},
                          question="How many books are there?")
        self.assertEqual(subject.classify(out)[0], subject.ANSWERABLE)

    def test_only_a_false_premise_may_become_a_denial(self):
        # AmbiContext was allowed to reach a denial once, to recover
        # "audiobooks", and it turned "how many loans are still open?" into
        # NOT COVERED: a degree the asker holds is never a gap in the data,
        # and the label that says so must not be able to deny. AmbiFallacy,
        # a premise the schema contradicts, is the one that may.
        clar = self.clarifier({"books": [("title", "varchar")]}, rows=())
        out = clar.ground({"ambiguous": True, "kind": "AmbiFallacy",
                           "phrase": "audiobooks", "reason": "not held",
                           "candidates": []},
                          question="Which books are available as audiobooks?")
        self.assertEqual(subject.classify(out)[0], subject.NOT_COVERED)
        # the replayed failure: no candidate, labelled AmbiContext, and the
        # table holds the state that answers it
        loans = self.clarifier({"loans": [("status", "varchar"),
                                          ("returned_at", "date")]}, rows=())
        out = loans.ground({"ambiguous": True, "kind": "AmbiContext",
                            "phrase": "still open", "reason": "which state?",
                            "candidates": []},
                           question="How many loans are still open?")
        self.assertNotEqual(subject.classify(out)[0], subject.NOT_COVERED)
        # a genuine context need is still not a denial, whatever the label:
        # the judgement check, not the kind, is what protects it
        out = clar.ground({"ambiguous": True, "kind": "AmbiContext",
                           "phrase": "busiest", "reason": "measured how?",
                           "candidates": []},
                          question="Which team is the busiest?")
        self.assertNotEqual(subject.classify(out)[0], subject.NOT_COVERED)
        # and a scope in time is the asker's, not a gap in the data
        out = clar.ground({"ambiguous": True, "kind": "AmbiRef",
                           "phrase": "after the 2018 World Cup",
                           "reason": "which date?", "candidates": []},
                          question="Which books came out after the 2018 World Cup?")
        self.assertNotEqual(subject.classify(out)[0], subject.NOT_COVERED)

    def test_a_plain_group_by_is_not_a_request_for_context(self):
        # replayed: the model filed "suppliers per country" under
        # AmbiContext with no candidate, and it was reported NEEDS MORE while
        # suppliers.country_code answers it. The schema decides.
        clar = self.clarifier({"suppliers": [("supplier_id", "int"),
                                             ("name", "varchar"),
                                             ("country_code", "char")]},
                              keys=(("suppliers", "supplier_id"),))
        out = clar.ground({"ambiguous": True, "kind": "AmbiContext",
                           "phrase": "suppliers per country",
                           "reason": "unclear", "candidates": []},
                          question="How many suppliers are there per country?")
        self.assertEqual(subject.classify(out)[0], subject.ANSWERABLE)
        # and a judgement keeps its request for a threshold even when a
        # column echoes it
        clar = self.clarifier({"products": [("price", "decimal")]})
        out = clar.ground({"ambiguous": True, "kind": "AmbiContext",
                           "phrase": "cheap price", "reason": "how cheap?",
                           "candidates": []},
                          question="Which products have a cheap price?")
        self.assertEqual(subject.classify(out)[0], subject.NEEDS_MORE)

    def test_two_real_columns_are_still_a_real_choice(self):
        # the rule being tightened must not swallow the case it exists for
        clar = self.clarifier({"suppliers": [("rating", "decimal"),
                                             ("is_active", "tinyint")]})
        got = self.verdict(clar, {
            "ambiguous": True, "kind": "AmbiSchema", "phrase": "most reliable",
            "reason": "two columns could mean it",
            "candidates": [{"table": "suppliers", "column": "rating"},
                           {"table": "suppliers", "column": "is_active"}]},
            "Which supplier is the most reliable?")
        self.assertEqual(got, subject.NEEDS_CHOICE)

    # --------------------------------------------- keys, joins, empty rows
    def library(self, rows=(), distinct=None, boom=False):
        clar = self.clarifier(
            {"genres": [("genre_id", "int"), ("name", "varchar")],
             "books": [("book_id", "int"), ("genre_id", "int"),
                       ("title", "varchar"), ("published_on", "date")],
             "authors": [("author_id", "int"), ("country", "varchar"),
                         ("name", "varchar")]},
            rows=rows, distinct=distinct, boom=boom,
            keys=(("genres", "genre_id"), ("books", "book_id"),
                  ("books", "genre_id"), ("authors", "author_id")))
        clar._foreign_keys = {("books", "genre_id"): ("genres", "genre_id")}
        return clar

    def test_a_key_is_read_as_the_column_it_stands_for(self):
        clar = self.library()
        self.assertEqual(
            clar.through_keys([{"table": "books", "column": "genre_id",
                                "means": "the genre"}]),
            [{"table": "genres", "column": "name", "means": "the genre",
              "via": "books.genre_id = genres.genre_id"}])
        # a primary key that references nothing stands for its own name
        self.assertEqual(
            clar.through_keys([{"table": "authors", "column": "author_id"}]),
            [{"table": "authors", "column": "name"}])
        # the label words win over catalogue order, where country is first
        self.assertEqual(clar.label_column("authors"), "name")
        self.assertEqual(
            clar.through_keys([{"table": "books", "column": "title"}]),
            [{"table": "books", "column": "title"}])

    def test_a_key_and_the_name_it_points_at_are_one_reading(self):
        got = self.verdict(self.library(), {
            "ambiguous": True, "kind": "AmbiSchema", "phrase": "genre",
            "reason": "the number or the name",
            "candidates": [{"table": "books", "column": "genre_id"},
                           {"table": "genres", "column": "name"}]},
            "How many books are there per genre?")
        self.assertEqual(got, subject.ANSWERABLE)

    def test_a_reading_one_join_away_carries_its_join(self):
        out = self.library().ground({
            "ambiguous": True, "kind": "AmbiSchema", "phrase": "kind of book",
            "reason": "its genre or its title",
            "candidates": [{"table": "books", "column": "genre_id",
                            "means": "its genre"},
                           {"table": "books", "column": "title",
                            "means": "its title"}]},
            question="Which kind of book is read most?")
        self.assertEqual(out.action, "CLARIFY")
        first = out.options[0]
        self.assertEqual((first.table, first.column, first.via),
                         ("genres", "name", "books.genre_id = genres.genre_id"))
        self.assertIn("through books.genre_id = genres.genre_id", out.render())

    SHAKESPEARE = "Which books were written by Shakespeare in 2020?"
    CLEAR = {"ambiguous": False, "phrase": "Shakespeare in 2020",
             "kind": "AmbiSchema", "reason": "", "operations": [], "value": "",
             "candidates": [{"table": "authors", "column": "name"},
                            {"table": "books", "column": "published_on"}]}

    def test_a_clear_question_whose_literal_no_row_holds_is_no_data(self):
        # measured on the demo library: the model rightly found nothing to
        # ask, and the question was reported answerable while no author of
        # that name exists
        clar = self.library(rows=(), distinct=("Tolkien", "Austen"))
        out = clar.ground(dict(self.CLEAR), question=self.SHAKESPEARE)
        self.assertEqual(subject.classify(out)[0], subject.NO_DATA)
        self.assertIn("authors.name", out.question)
        # with no "were" in the sentence, only "by" marks the name
        out = clar.ground(dict(self.CLEAR),
                          question="List the books written by Shakespeare.")
        self.assertEqual(subject.classify(out)[0], subject.NO_DATA)

    def test_an_empty_result_is_claimed_only_on_evidence(self):
        # the row is there
        clar = self.library(rows=("William Shakespeare",))
        self.assertEqual(self.verdict(clar, dict(self.CLEAR), self.SHAKESPEARE),
                         subject.ANSWERABLE)
        # the lookup failed, and not knowing is never an empty result
        clar = self.library(boom=True)
        self.assertEqual(self.verdict(clar, dict(self.CLEAR), self.SHAKESPEARE),
                         subject.ANSWERABLE)
        # nothing in the question is a literal
        clar = self.library()
        self.assertEqual(self.verdict(clar, dict(self.CLEAR, phrase="", candidates=[]),
                                      "How many books are there?"),
                         subject.ANSWERABLE)
        # a judgement put in `value` is a threshold, not a name
        self.assertEqual(self.verdict(clar, dict(
            self.CLEAR, phrase="", value="cheap",
            candidates=[{"table": "books", "column": "title"}]),
            "Which books are cheap?"), subject.ANSWERABLE)

    def test_a_column_of_codes_is_asked_before_a_result_is_called_empty(self):
        # "Germany" is in no row and DE is: only the values can say so
        clar = self.clarifier(
            {"suppliers": [("supplier_id", "int"), ("country_code", "varchar")]},
            rows=(), distinct=("DE", "FR", "US"),
            keys=(("suppliers", "supplier_id"),))
        switch = patch.dict("os.environ", {"DATAGORA_ASK_VALUES": "on"})
        switch.start()
        self.addCleanup(switch.stop)
        raw = {"ambiguous": False, "phrase": "", "kind": "", "reason": "",
               "operations": [], "value": "Germany",
               "candidates": [{"table": "suppliers", "column": "country_code"}]}
        question = "Which suppliers are based in Germany?"
        clar._llm = SimpleNamespace(json=lambda *_a, **_k: {
            "why": "DE is Germany", "decidable": True,
            "table": "suppliers", "column": "country_code"})
        self.assertEqual(self.verdict(clar, dict(raw), question),
                         subject.ANSWERABLE)
        clar._llm = SimpleNamespace(json=lambda *_a, **_k: {
            "why": "no code stands for Germany", "decidable": False,
            "table": "", "column": ""})
        self.assertEqual(self.verdict(clar, dict(raw), question),
                         subject.NO_DATA)

    def test_a_judgement_settled_to_one_column_still_needs_its_threshold(self):
        # measured: "recently" came back answerable once the values picked
        # borrowed_at, while nobody had said how recent
        clar = self.clarifier({"loans": [("borrowed_at", "date"),
                                         ("returned_at", "date")]},
                              rows=(), distinct=("2026-09-01",))
        raw = {"ambiguous": True, "kind": "AmbiContext", "phrase": "recently",
               "reason": "which date, and how recent",
               "candidates": [{"table": "loans", "column": "borrowed_at"},
                              {"table": "loans", "column": "returned_at"}]}
        question = "Which members borrowed something recently?"
        self.assertEqual(self.verdict(clar, dict(raw), question),
                         subject.NEEDS_MORE)
        switch = patch.dict("os.environ", {"DATAGORA_ASK_VALUES": "on"})
        switch.start()
        self.addCleanup(switch.stop)
        clar._llm = SimpleNamespace(json=lambda *_a, **_k: {
            "why": "borrowing is dated there", "decidable": True,
            "table": "loans", "column": "borrowed_at"})
        out = clar.ground(dict(raw), question=question)
        self.assertEqual(subject.classify(out)[0], subject.NEEDS_MORE)
        self.assertEqual([o.label for o in out.options], ["loans.borrowed_at"])

    def test_a_neighbourhood_withholds_a_denial_and_never_says_yes(self):
        class Index:
            def similar(self, phrase):
                return ([("warehouses", "capacity_units", 0.67)]
                        if "storage" in phrase else [])

        clar = self.clarifier(
            {"warehouses": [("warehouse_id", "int"), ("city", "varchar"),
                            ("capacity_units", "int")]},
            rows=(), keys=(("warehouses", "warehouse_id"),))
        raw = {"ambiguous": True, "kind": "AmbiFallacy",
               "phrase": "storage space", "reason": "nothing records space",
               "candidates": []}
        question = "How much storage space does each warehouse have?"
        # no index: the sweep finds nothing and the denial stands
        self.assertEqual(self.verdict(clar, dict(raw), question),
                         subject.NOT_COVERED)
        clar._index, clar._index_checked, clar._similar = Index(), True, {}
        self.assertIn("warehouses.capacity_units",
                      clar.resembles_column("storage space"))
        self.assertEqual(clar.answers_directly("storage space"), [])
        self.assertEqual(self.verdict(clar, dict(raw), question),
                         subject.NEEDS_MORE)

    WAREHOUSE = {"suppliers": [("supplier_id", "int"), ("supplier_name", "varchar")],
                 "inventory_movements": [("movement_id", "int"), ("movement_type", "enum"),
                                         ("movement_note", "text")],
                 "categories": [("category_id", "int"), ("name", "varchar"),
                                ("metadata", "json")]}
    WAREHOUSE_KEYS = (("suppliers", "supplier_id"), ("inventory_movements", "movement_id"),
                      ("categories", "category_id"))

    def fallacy(self, phrase):
        return {"ambiguous": True, "phrase": phrase, "kind": "AmbiFallacy",
                "reason": f"nothing in the schema records {phrase}",
                "candidates": [], "operations": [], "value": ""}

    def test_a_generic_word_does_not_keep_an_absent_concept_from_a_denial(self):
        # "type" echoes movement_type, "blood" echoes nothing, and the data
        # holds neither: the model's "no such thing" is confirmed
        clar = self.clarifier(self.WAREHOUSE, keys=self.WAREHOUSE_KEYS)
        self.assertEqual(self.verdict(clar, self.fallacy("blood type"),
                                      "What is the blood type of our suppliers?"),
                         subject.NOT_COVERED)

    def test_one_word_met_in_a_description_still_keeps_a_denial_away(self):
        # "free" occurs in "Free-form JSON attributes" and "gluten" nowhere,
        # yet the denial stays withheld: the rule that would deny it (every
        # word must echo) also denied "storage space", which capacity_units
        # answers. A missed denial is the side to be wrong on.
        clar = self.clarifier(self.WAREHOUSE, keys=self.WAREHOUSE_KEYS)
        clar._meanings = {"tables": {}, "columns": {
            "categories.metadata": "Free-form JSON attributes.",
            "inventory_movements.movement_note": "Free text note."}}
        self.assertEqual(self.verdict(clar, self.fallacy("gluten free"),
                                      "Which products are gluten free?"),
                         subject.NEEDS_MORE)

    def test_a_synonym_met_in_a_description_is_never_denied(self):
        clar = self.clarifier({"warehouses": [("warehouse_id", "int"),
                                              ("capacity_units", "int")]},
                              keys=(("warehouses", "warehouse_id"),))
        clar._meanings = {"tables": {}, "columns": {
            "warehouses.capacity_units": "Storage capacity, in units."}}
        self.assertEqual(self.verdict(clar, self.fallacy("storage space"),
                                      "How much storage space does each warehouse have?"),
                         subject.NEEDS_MORE)

    def test_a_word_naming_a_column_still_keeps_the_denial_away(self):
        # the safe direction: "supplier" names a table, so "supplier rating
        # history" is not denied on the model's word, even with no rating
        clar = self.clarifier(self.WAREHOUSE, keys=self.WAREHOUSE_KEYS)
        self.assertEqual(self.verdict(clar, self.fallacy("supplier history"),
                                      "What is the supplier history?"),
                         subject.NEEDS_MORE)

    def vessels(self, unique):
        clar = self.clarifier({"sea_shpmnt": [("sea_shpmnt_id", "int"),
                                              ("vessel_name", "varchar"),
                                              ("container_count", "int")]},
                              keys=(("sea_shpmnt", "sea_shpmnt_id"),),
                              distinct=[1 if unique else 0])
        raw = {"ambiguous": True, "phrase": "more than 10 containers", "kind": "AmbiView",
               "reason": "per shipment or in total per vessel",
               "candidates": [{"table": "sea_shpmnt", "column": "container_count"},
                              {"table": "sea_shpmnt", "column": "vessel_name"}],
               "operations": ["sum"], "value": ""}
        return self.verdict(clar, raw, "Which vessels carried more than 10 containers?")

    def test_per_shipment_and_in_total_are_one_reading_when_no_vessel_repeats(self):
        self.assertEqual(self.vessels(unique=True), subject.ANSWERABLE)

    def test_a_vessel_that_repeats_keeps_the_question(self):
        self.assertNotEqual(self.vessels(unique=False), subject.ANSWERABLE)

    def test_a_table_description_points_near_and_never_answers(self):
        clar = self.clarifier({"members": [("member_id", "int"),
                                           ("full_name", "varchar")]},
                              keys=(("members", "member_id"),))
        clar._meanings = {"tables": {"members": "people holding a library card"},
                          "columns": {}}
        self.assertIn(("members", "full_name", "about"),
                      clar.column_evidence("card holders"))
        self.assertEqual(clar.answers_directly("card holders"), [])

    def test_phrase_words_are_split_like_identifiers(self):
        clar = self.clarifier({"members": [("email", "varchar")],
                               "order_items": [("item_id", "int"),
                                               ("label", "varchar")]},
                              keys=(("order_items", "item_id"),))
        self.assertEqual(clar._content_words("member's city/region"),
                         {"member", "city", "region"})
        # a table of several words is named by all of them, not by one
        self.assertIn(("order_items", "label", "table"),
                      clar.column_evidence("order items"))
        self.assertNotIn(("order_items", "label", "table"),
                         clar.column_evidence("items"))

    # ------------------------------------------ a knowledge base in force
    def points(self, rows=(), boom=False):
        """The production pattern: no constraint declared anywhere, the
        joins, keys and codes known only from the knowledge base."""
        import dictionary
        import test_dictionary
        clar = self.clarifier(
            {"abs_point": [("abs_point_id", "int"), ("cat_code", "varchar"),
                           ("name_txt", "varchar")],
             "crts_point": [("crts_point_id", "int"), ("x_coord", "decimal")],
             "geo_point": [("geo_point_id", "int"), ("elev_dim", "decimal")]},
            rows=rows, boom=boom)
        clar._meanings = dictionary.parse(test_dictionary.point_kb())
        clar._meanings["columns"]["geo_point.elev_dim"] = (
            "Elevation above sea level, in metres.")
        clar._foreign_keys = {}
        return clar

    def test_the_dictionary_supplies_codes_keys_and_joins(self):
        clar = self.points()
        self.assertEqual(clar.near_values("abs_point", "cat_code",
                                          "geographic points"), ["GEOGPT"])
        # a word that fits every code selects none of them
        self.assertEqual(clar.codes_for(
            "points", clar.enum_labels("abs_point", "cat_code")), [])
        self.assertTrue(clar.records_a_state("abs_point", "cat_code"))
        self.assertTrue(clar.is_a_key("geo_point", "geo_point_id"))
        self.assertEqual(clar.foreign_keys[("geo_point", "geo_point_id")],
                         ("abs_point", "abs_point_id"))
        # which code's rows are in which child is the data's answer
        clar._codes_joined = lambda _t, _c, _pc, child, _cc, _con=None: {
            "crts_point": ["CARTPT"], "geo_point": ["GEOGPT"]}[child]
        text = clar.schema_text()
        self.assertIn("GEOGPT (GEOGRAPHIC-POINT)", text)
        self.assertIn("GEOGPT rows continue in geo_point", text)
        self.assertIn("-> abs_point.abs_point_id", text)

    def test_a_code_is_linked_to_a_child_only_on_the_data(self):
        def linked(answers):
            clar = self.points()
            clar._codes_joined = lambda _t, _c, _pc, child, _cc, _con=None: answers[child]
            return clar.continues_in("abs_point", "cat_code")

        got = linked({"crts_point": ["CARTPT"], "geo_point": ["GEOGPT"]})
        self.assertEqual({code: sub for code, (sub, _j) in got.items()},
                         {"CARTPT": "crts_point", "GEOGPT": "geo_point"})
        # a child whose rows carry both codes continues no single kind
        self.assertNotIn("CARTPT", linked({"crts_point": ["CARTPT", "GEOGPT"],
                                           "geo_point": ["GEOGPT"]}))
        # an empty child, or a query that failed, proves nothing
        self.assertEqual(linked({"crts_point": [], "geo_point": None}), {})
        # two children claiming one code is no link for either
        self.assertEqual(linked({"crts_point": ["GEOGPT"],
                                 "geo_point": ["GEOGPT"]}), {})

    def test_a_kind_outside_a_closed_vocabulary_is_not_covered(self):
        raw = {"ambiguous": True, "kind": "AmbiValue", "phrase": "polar points",
               "reason": "no such category", "value": "polar",
               "candidates": [{"table": "abs_point", "column": "cat_code"}]}
        question = "How many polar points are there?"
        out = self.points().ground(dict(raw), question=question)
        self.assertEqual(subject.classify(out)[0], subject.NOT_COVERED)
        self.assertIn("CARTPT (CARTESIAN-POINT)", out.question)
        # a lookup that failed proves nothing about the vocabulary
        self.assertNotEqual(
            self.verdict(self.points(boom=True), dict(raw), question),
            subject.NOT_COVERED)

    def test_a_key_described_as_its_entity_is_never_the_answer(self):
        # "Geographic point identifier" once made geo_point_id the answer
        # to a question about geographic points
        direct = self.points().answers_directly("geographic points")
        self.assertIn("abs_point.cat_code", direct)
        self.assertNotIn("geo_point.geo_point_id", direct)

    def test_a_ranking_answers_on_a_named_measure_and_not_on_an_entity(self):
        self.assertEqual(self.points().answers_directly("highest elevation"),
                         ["geo_point.elev_dim"])
        # best by what? rating sits in suppliers, and nobody said rating
        clar = self.clarifier({"suppliers": [("supplier_id", "int"),
                                             ("supplier_name", "varchar"),
                                             ("rating", "decimal")]},
                              keys=(("suppliers", "supplier_id"),))
        self.assertEqual(clar.answers_directly("best supplier"), [])

    def test_a_column_put_on_the_wrong_table_is_found_one_join_away(self):
        # measured: road_shpmnt.state_code was proposed for "still in
        # transit", thrown away as not existing, and the question denied,
        # while state_code sits on shpmnt, one join away
        clar = self.clarifier(
            {"shpmnt": [("shpmnt_id", "int"), ("state_code", "char")],
             "road_shpmnt": [("road_shpmnt_id", "int"),
                             ("truck_plate", "varchar")]},
            rows=(), keys=(("shpmnt", "shpmnt_id"),
                           ("road_shpmnt", "road_shpmnt_id")))
        clar._foreign_keys = {("road_shpmnt", "road_shpmnt_id"):
                              ("shpmnt", "shpmnt_id")}
        self.assertEqual(
            clar.through_keys([{"table": "road_shpmnt",
                                "column": "state_code"}]),
            [{"table": "shpmnt", "column": "state_code",
              "via": "road_shpmnt.road_shpmnt_id = shpmnt.shpmnt_id"}])
        got = self.verdict(clar, {
            "ambiguous": True, "kind": "AmbiValue", "phrase": "still in transit",
            "reason": "which state is in transit", "value": "",
            "candidates": [{"table": "road_shpmnt", "column": "state_code"}]},
            "Which road shipments are still in transit?")
        self.assertNotEqual(got, subject.NOT_COVERED)

    SAID_CLEAR = {"ambiguous": False, "kind": "AmbiSchema", "reason": "",
                  "operations": [], "value": ""}

    def large(self, extra=60):
        """Products among many tables of other trades, most of which hold a
        duration_minutes, as a database of hundreds does."""
        columns = {
            "products": [("product_id", "int"), ("product_name", "varchar"),
                         ("price", "decimal")],
            "suppliers": [("supplier_id", "int"), ("supplier_name", "varchar")],
            "product_suppliers": [("product_id", "int"), ("supplier_id", "int"),
                                  ("lead_time_days", "int")],
            "leads": [("lead_id", "int"), ("source", "varchar")],
        }
        for i in range(extra):
            columns[f"trade{i}_events"] = [(f"trade{i}_event_id", "int"),
                                           ("duration_minutes", "int")]
        clar = self.clarifier(columns, keys=tuple(
            (t, c) for t, cols in columns.items() for c, _ in cols
            if c.endswith("_id")))
        clar._foreign_keys = {
            ("product_suppliers", "product_id"): ("products", "product_id"),
            ("product_suppliers", "supplier_id"): ("suppliers", "supplier_id")}
        clar._graph_edges = []
        return clar

    def test_a_calculation_word_needs_no_column(self):
        # "how many products" came back asking which column holds "many"
        clar = self.large(extra=0)
        self.assertEqual(self.verdict(clar, dict(
            self.SAID_CLEAR, phrase="How many products",
            candidates=[{"table": "products", "column": "product_id"}]),
            "How many products are there?"), subject.ANSWERABLE)

    def test_a_word_is_not_lost_to_a_table_it_does_not_mean(self):
        # "lead" was taken for the CRM's leads and left out unchecked
        clar = self.large()
        self.assertEqual(self.verdict(clar, dict(
            self.SAID_CLEAR, phrase="average lead time",
            candidates=[{"table": "product_suppliers", "column": "lead_time_days"}]),
            "What is the average lead time in days per supplier?"),
            subject.ANSWERABLE)

    def test_a_number_in_words_and_a_verb_of_a_table_need_no_column(self):
        # "more than three suppliers" asked which column holds "supplied
        # three"
        clar = self.large()
        self.assertEqual(self.verdict(clar, dict(
            self.SAID_CLEAR,
            phrase="products are supplied by more than three suppliers",
            candidates=[{"table": "product_suppliers", "column": "supplier_id"},
                        {"table": "suppliers", "column": "supplier_name"}]),
            "Which products are supplied by more than three suppliers?"),
            subject.ANSWERABLE)

    def test_a_trade_adds_its_own_calculation_words(self):
        clar = self.large(extra=0)
        reply = dict(self.SAID_CLEAR, phrase="turnover of products",
                     candidates=[{"table": "products", "column": "price"}])
        question = "What is the turnover of products?"
        self.assertEqual(self.verdict(clar, dict(reply), question), subject.NEEDS_MORE)
        clar._vocabulary = {k: set() for k in type(clar).VOCABULARIES}
        clar._vocabulary["calculations"] = {"turnover"}
        self.assertEqual(self.verdict(clar, dict(reply), question), subject.ANSWERABLE)

    def test_an_operation_word_is_left_out_everywhere_alike(self):
        clar = self.clarifier({
            "shipments": [("shipment_id", "int"), ("weight_kg", "decimal"),
                          ("total_cost", "decimal"), ("container_count", "int")],
            "suppliers": [("supplier_id", "int"), ("rating", "int"),
                          ("country", "varchar")]},
            keys=(("shipments", "shipment_id"), ("suppliers", "supplier_id")))
        # it points at no column: "total" is not total_cost
        found = {f"{t}.{c}" for t, c, _how in
                 clar.column_evidence("total weight", semantic=False)}
        self.assertIn("shipments.weight_kg", found)
        self.assertNotIn("shipments.total_cost", found)
        # it needs no column: an average is taken of rating
        self.assertEqual(clar.answers_directly("average rating of suppliers"),
                         ["suppliers.rating"])
        # it is no echo that forbids a denial: "count" is not container_count
        self.assertFalse(clar.withholds_denial("count of gluten"))
        # and a trade's own word is taken out the same way
        clar._vocabulary = {k: set() for k in type(clar).VOCABULARIES}
        clar._vocabulary["calculations"] = {"tally"}
        self.assertIn("tally", clar.operation_words())
        self.assertNotIn("shipments.weight_kg", {
            f"{t}.{c}" for t, c, _how in clar.column_evidence("tally", semantic=False)})

    def test_how_many_counts_unless_what_is_counted_is_a_quantity(self):
        clar = self.clarifier({
            "members": [("member_id", "int"), ("full_name", "varchar")],
            "sea_shpmnt": [("sea_shpmnt_id", "int"), ("vessel_name", "varchar"),
                           ("container_count", "int")]},
            keys=(("members", "member_id"), ("sea_shpmnt", "sea_shpmnt_id")))
        view = {"ambiguous": True, "kind": "AmbiView", "reason": "count or sum",
                "value": "", "operations": ["count", "sum"]}
        # "how many members" counts members, whatever the model offered
        self.assertEqual(self.verdict(clar, dict(
            view, phrase="how many members",
            candidates=[{"table": "members", "column": "member_id"}]),
            "How many members are there?"), subject.ANSWERABLE)
        # "how many containers" adds up container_count, or counts the
        # shipments: two answers, so the asker chooses
        out = clar.ground(dict(
            view, phrase="how many containers",
            candidates=[{"table": "sea_shpmnt", "column": "container_count"}]),
            question="How many containers did each vessel carry?")
        self.assertEqual(subject.classify(out)[0], subject.NEEDS_CHOICE)
        self.assertEqual({o.label for o in out.options}, {"count", "sum"})
        # with no sum proposed, a count it stays
        self.assertEqual(self.verdict(clar, dict(
            view, operations=["count"], phrase="how many containers",
            candidates=[{"table": "sea_shpmnt", "column": "container_count"}]),
            "How many containers did each vessel carry?"), subject.ANSWERABLE)

    def test_a_clear_question_filtering_on_what_nothing_holds_is_withheld(self):
        # "how many shipments went by rail?" came back clear, no phrase named
        reply = dict(self.SAID_CLEAR, phrase="", candidates=[])
        question = "How many shipments went by rail?"
        none = self.clarifier({"shpmnt": [("shpmnt_id", "int"), ("mode_code", "varchar")]},
                              rows=(), keys=(("shpmnt", "shpmnt_id"),))
        self.assertEqual(self.verdict(none, dict(reply), question), subject.NEEDS_MORE)
        # a row holds it: an answer
        held = self.clarifier({"shpmnt": [("shpmnt_id", "int"), ("mode_code", "varchar")]},
                              rows=("rail",), keys=(("shpmnt", "shpmnt_id"),))
        self.assertEqual(self.verdict(held, dict(reply), question), subject.ANSWERABLE)
        # a verb is never in that place
        self.assertEqual(self.verdict(none, dict(reply),
                                      "How many shipments went somewhere?"),
                         subject.ANSWERABLE)

    def test_a_word_that_can_be_a_column_is_still_looked_for(self):
        # "rate" computes in "the return rate" and is held in "exchange
        # rate": it is looked for, so a schema without one asks
        clar = self.large(extra=0)
        self.assertEqual(self.verdict(clar, dict(
            self.SAID_CLEAR, phrase="rate of products",
            candidates=[{"table": "products", "column": "price"}]),
            "What is the rate of products?"), subject.NEEDS_MORE)

    def test_on_a_large_database_other_trades_are_no_evidence(self):
        # "warranty duration" passed on the duration_minutes of other trades
        clar = self.large()
        question = "What is the warranty duration of each product?"
        self.assertEqual(self.verdict(clar, dict(
            self.SAID_CLEAR, phrase="warranty duration",
            candidates=[{"table": "trade3_events", "column": "duration_minutes"}]),
            question), subject.NEEDS_MORE)
        # nor are they a choice to offer
        got = clar.ground(dict(
            self.SAID_CLEAR, ambiguous=True, phrase="warranty duration",
            candidates=[{"table": "trade3_events", "column": "duration_minutes"},
                        {"table": "trade7_events", "column": "duration_minutes"}]),
            question=question)
        self.assertFalse(any("trade" in o.label for o in got.options), got.options)
        self.assertNotEqual(subject.classify(got)[0], subject.ANSWERABLE)

    def test_on_a_large_database_the_question_tables_still_answer(self):
        clar = self.large()
        self.assertEqual(self.verdict(clar, dict(
            self.SAID_CLEAR, phrase="lead time of each product",
            candidates=[{"table": "product_suppliers", "column": "lead_time_days"}]),
            "What is the lead time of each product?"), subject.ANSWERABLE)

    def test_a_clear_reading_of_what_the_schema_never_names_is_withheld(self):
        # measured with the library's knowledge base: "unpaid fines" came
        # back clear on loans.status and was reported answerable
        clar = self.clarifier(
            {"loans": [("loan_id", "int"), ("status", "varchar"),
                       ("borrowed_at", "date")],
             "members": [("member_id", "int"), ("full_name", "varchar")]},
            keys=(("loans", "loan_id"), ("members", "member_id")))
        clear = {"ambiguous": False, "kind": "AmbiSchema", "reason": "",
                 "operations": [], "value": ""}
        self.assertEqual(self.verdict(clar, dict(
            clear, phrase="unpaid fines",
            candidates=[{"table": "loans", "column": "status"}]),
            "Which members have unpaid fines?"), subject.NEEDS_MORE)
        # a phrase whose words the schema holds stays answerable
        self.assertEqual(self.verdict(clar, dict(
            clear, phrase="never been borrowed", candidates=[]),
            "Which members have never borrowed?"), subject.ANSWERABLE)

    def test_columns_found_through_the_table_alone_are_no_choice(self):
        # "braille copies" was offered four columns of copies, all found
        # through "copies", none about braille, and read as a choice
        clar = self.clarifier(
            {"copies": [("copy_id", "int"), ("kind_code", "varchar"),
                        ("acquired_on", "date")]},
            rows=(), keys=(("copies", "copy_id"),))
        flagged = {"ambiguous": True, "kind": "AmbiSchema", "reason": "",
                   "candidates": []}
        self.assertEqual(self.verdict(clar, dict(flagged, phrase="braille copies"),
                                      "How many braille copies are there?"),
                         subject.NEEDS_MORE)
        # a column that accounts for the added word is not withheld:
        # acquired_on answers "acquired copies" outright
        self.assertEqual(self.verdict(clar, dict(flagged, phrase="acquired copies"),
                                      "How many copies were acquired?"),
                         subject.ANSWERABLE)

    def test_a_value_is_looked_up_by_its_longest_word(self):
        import ambisql
        sent = []

        class Cursor:
            def execute(self, _sql, params=None):
                sent.append(params)

            def fetchall(self):
                return []

            def close(self):
                pass

        class Connection:
            def cursor(self):
                return Cursor()

            def close(self):
                pass

        clar = ambisql.Clarifier.for_connection(Connection, "theirs")
        clar._columns = {"shpmnt": [("state_code", "varchar")]}
        clar._keys = set()
        clar._near_values_checked("shpmnt", "state_code", "still in transit")
        self.assertEqual(sent[0][0], "%transit%")

    def test_a_no_data_verdict_reads_as_the_sentence_it_was_given(self):
        said = "This database can ask the question, and no row answers it."
        verdict = subject.Verdict(question="q", verdict=subject.NO_DATA,
                                  missing=said)
        self.assertEqual(verdict.sentence(), said)

    # ----------------------------------------- replayed from the enterprise run
    def values_on(self):
        switch = patch.dict("os.environ", {"DATAGORA_ASK_VALUES": "on"})
        switch.start()
        self.addCleanup(switch.stop)

    def test_two_prices_stay_a_choice_whatever_the_values_say(self):
        # E37: the model picked list_price off the values and the cost
        # reading, as good, was dropped. Two numbers are a choice.
        clar = self.clarifier({"products": [("product_id", "int"),
                                            ("product_name", "varchar"),
                                            ("list_price", "decimal"),
                                            ("standard_cost", "decimal")]},
                              rows=(), distinct=("10.00", "12.50"),
                              keys=(("products", "product_id"),))
        self.values_on()
        clar._llm = SimpleNamespace(json=lambda *_a, **_k: {
            "why": "list price is what a customer pays", "decidable": True,
            "table": "products", "column": "list_price"})
        out = clar.ground({
            "ambiguous": True, "kind": "AmbiSchema", "phrase": "most expensive",
            "reason": "sales price or cost",
            "candidates": [{"table": "products", "column": "list_price"},
                           {"table": "products", "column": "standard_cost"}]},
            question="Which products are the most expensive?")
        self.assertEqual(subject.classify(out)[0], subject.NEEDS_CHOICE)
        self.assertEqual([o.label for o in out.options],
                         ["products.list_price", "products.standard_cost"])

    def test_a_qualifier_nothing_holds_denies_a_kind_the_schema_has(self):
        # E40: "score" echoes nps_score and csat_score, "engagement" echoes
        # nothing at all; the scores held are other scores
        clar = self.clarifier(
            {"employees": [("employee_id", "int"), ("first_name", "varchar")],
             "customer_surveys": [("survey_id", "int"), ("nps_score", "int"),
                                  ("csat_score", "int")]},
            keys=(("employees", "employee_id"), ("customer_surveys", "survey_id")))
        self.assertFalse(clar.withholds_denial("employee engagement score"))
        self.assertEqual(self.verdict(clar, self.fallacy("employee engagement score"),
                                      "What is the employee engagement score per department?"),
                         subject.NOT_COVERED)
        # the head echoing nothing, or a qualifier met somewhere, still
        # withholds: "storage space" and "gluten free" above, and here a
        # qualifier the schema does name
        self.assertTrue(clar.withholds_denial("csat score"))

    def test_one_column_proposed_twice_is_answered_with_it(self):
        # E18: departments.name through the employee and through the
        # position history is one column, and the database holds it
        clar = self.clarifier({"departments": [("department_id", "int"),
                                               ("name", "varchar")],
                               "absences": [("absence_id", "int"),
                                            ("days_taken", "int")]},
                              keys=(("departments", "department_id"),
                                    ("absences", "absence_id")))
        out = clar.ground({
            "ambiguous": True, "kind": "AmbiSchema", "phrase": "per department",
            "reason": "current department or the one at the time",
            "candidates": [{"table": "departments", "column": "name",
                            "means": "current department"},
                           {"table": "departments", "column": "name",
                            "means": "department at the time"}]},
            question="How many approved absence days were taken per department in 2025?")
        self.assertEqual(subject.classify(out)[0], subject.ANSWERABLE)
        self.assertIn("departments.name", out.reason)
        verdict = subject.Verdict(question="q", verdict=subject.ANSWERABLE,
                                  choices=[o.label for o in out.options])
        self.assertIn("departments.name", verdict.sentence())

    def test_a_reading_the_schema_lacks_still_asks(self):
        # the "oldest members" with no birth date: the one reading left is
        # the database's, not the asker's, and that is said
        clar = self.clarifier({"members": [("member_id", "int"),
                                           ("joined_at", "date")]},
                              keys=(("members", "member_id"),))
        out = clar.ground({
            "ambiguous": True, "kind": "AmbiSchema", "phrase": "oldest",
            "reason": "age or seniority",
            "candidates": [{"table": "members", "column": "birth_date"},
                           {"table": "members", "column": "joined_at"}]},
            question="Who are the oldest members?")
        self.assertEqual(subject.classify(out)[0], subject.NEEDS_MORE)
        self.assertEqual([o.label for o in out.options], ["members.joined_at"])

    def test_an_adjective_of_a_stored_code_is_held(self):
        # E29: "at the monthly average rate", the rate type stored MONTH_AVG
        import ambisql
        stored = ("MONTH_AVG", "SPOT")

        class Cursor:
            def execute(self, _sql, params=None):
                wanted = str((params or ("",))[0]).strip("%").lower()
                self.rows = [v for v in stored if wanted and wanted in v.lower()]

            def fetchall(self):
                return [(r,) for r in self.rows]

            def close(self):
                pass

        class Connection:
            def cursor(self):
                return Cursor()

            def close(self):
                pass

        clar = ambisql.Clarifier.for_connection(Connection, "theirs")
        clar._columns = {"exchange_rates": [("rate_type", "varchar"),
                                            ("rate", "decimal")]}
        clar._keys = set()
        self.assertEqual(clar.unheld_filter_words(
            "What was the revenue converted at the monthly average rate?"), [])
        self.assertEqual(clar.unheld_filter_words(
            "What was the revenue converted at the quarterly rate?"), ["quarterly"])

    @staticmethod
    def stored_values(stored, columns):
        """A clarifier on a database whose text columns hold `stored`: a
        LIKE or a SOUNDEX finds each value that holds what is looked for."""
        import ambisql

        class Cursor:
            def execute(self, _sql, params=None):
                wanted = str((params or ("",))[0]).strip("%").lower()
                self.rows = [v for v in stored if wanted and wanted in v.lower()]

            def fetchall(self):
                return [(r,) for r in self.rows]

            def close(self):
                pass

        class Connection:
            def cursor(self):
                return Cursor()

            def close(self):
                pass

        clar = ambisql.Clarifier.for_connection(Connection, "theirs")
        clar._columns = columns
        clar._keys = set()
        return clar

    def test_an_adjective_is_not_cut_into_a_word_the_data_holds_by_chance(self):
        # cut by rule, "rental" was rent, "electric" electr and "public"
        # publ, which CURRENT, ELECTRONICS and PUBLISHED hold: three values
        # the data lacks counted as held
        clar = self.stored_values(("CURRENT", "PARENT", "ELECTRONICS", "PUBLISHED"),
                                  {"contracts": [("status", "varchar"),
                                                 ("amount", "decimal")]})
        for question, word in (("How much revenue came from rental?", "rental"),
                               ("How many contracts were signed in electric?", "electric"),
                               ("How many contracts were filed in public?", "public")):
            with self.subTest(word=word):
                self.assertEqual(clar.unheld_filter_words(question), [word])

    def test_an_adjective_is_held_by_its_word_and_not_inside_another(self):
        # "daily" is day: PER_DAY holds it as a word, MONDAY only as letters
        question = "How many contracts were closed at the daily cutoff?"
        columns = {"contracts": [("period", "varchar"), ("amount", "decimal")]}
        self.assertEqual(self.stored_values(("MONDAY", "HOLIDAY"), columns)
                         .unheld_filter_words(question), ["daily"])
        self.assertEqual(self.stored_values(("PER_DAY", "PER_WEEK"), columns)
                         .unheld_filter_words(question), [])
        self.assertEqual(self.stored_values(("DAYS", "WEEKS"), columns)
                         .unheld_filter_words(question), [])

    def test_a_number_is_never_a_state(self):
        # sales_order_lines.quantity holds 1, 2, 3, 5, 10, 20, 50
        clar = self.clarifier({"sales_order_lines": [("quantity", "int"),
                                                     ("status", "varchar"),
                                                     ("is_open", "tinyint")]},
                              distinct=(1, 2, 3, 5, 10, 20, 50))
        self.assertFalse(clar.records_a_state("sales_order_lines", "quantity"))
        self.assertTrue(clar.records_a_state("sales_order_lines", "status"))
        self.assertTrue(clar.records_a_state("sales_order_lines", "is_open"))

    def test_a_word_two_tables_end_in_stays_a_choice_between_them(self):
        # E35: "orders" is sales_orders and work_orders alike, and the asker
        # is asked which
        clar = self.clarifier({"work_orders": [("work_order_id", "int"),
                                               ("wo_number", "varchar")],
                               "sales_orders": [("sales_order_id", "int"),
                                                ("order_number", "varchar")]},
                              keys=(("work_orders", "work_order_id"),
                                    ("sales_orders", "sales_order_id")))
        out = clar.ground({
            "ambiguous": True, "kind": "AmbiSchema", "phrase": "orders",
            "reason": "work orders or sales orders",
            "candidates": [{"table": "work_orders", "column": "wo_number"},
                           {"table": "sales_orders", "column": "order_number"}]},
            question="Which orders were late?")
        self.assertEqual(subject.classify(out)[0], subject.NEEDS_CHOICE)
        self.assertEqual(len(out.options), 2)

    def test_clarify_keeps_the_reply_the_tables_and_the_branch(self):
        clar = self.clarifier({"books": [("book_id", "int"), ("title", "varchar")]},
                              keys=(("books", "book_id"),))
        reply = {"ambiguous": False, "phrase": "", "kind": "", "reason": "",
                 "candidates": [], "operations": [], "value": ""}
        clar._llm = SimpleNamespace(json=lambda *_a, **_k: dict(reply),
                                    reachable=lambda: True)
        out = clar.clarify("How many books are there?")
        self.assertEqual(out.action, "ANSWER")
        self.assertEqual(clar.last_reply, reply)
        self.assertIsNone(clar.last_shown)


class ColumnIndexTests(unittest.TestCase):
    """The bar a column must clear to count as a lead, with no server."""

    def index(self, scores):
        import recall
        idx = recall.ColumnIndex(None, "t_columns", None)
        idx.scored = lambda _phrase, limit=5: [
            ("t", f"c{i}", s) for i, s in enumerate(scores)][:limit]
        idx.size = lambda: len(scores)
        return idx

    def test_a_column_that_stands_out_is_a_lead(self):
        idx = self.index([0.74] + [0.50 + 0.001 * i for i in range(24)])
        self.assertEqual([c for _t, c, _s in idx.similar("date of birth")],
                         ["c0"])

    def test_a_flat_schema_gives_no_lead_however_high_the_scores(self):
        # multilingual-e5 scores everything between 0.77 and 0.85: a high
        # number means nothing unless one column stands out from the rest
        idx = self.index([0.82] + [0.80 + 0.01 * ((i % 5) - 2)
                                   for i in range(24)])
        self.assertEqual(idx.similar("warranty"), [])

    def test_the_bar_rises_with_the_size_of_the_schema(self):
        import recall
        idx = recall.ColumnIndex(None, "t_columns", None)
        self.assertAlmostEqual(idx.bar(25), recall.COLUMN_MIN_Z)
        self.assertEqual(idx.bar(10), recall.COLUMN_MIN_Z)
        self.assertGreater(idx.bar(500), idx.bar(25))

    def test_another_embedding_model_never_reuses_an_index(self):
        import recall
        clar = SimpleNamespace(columns={"t": [("c", "varchar")]},
                               means=lambda _t, _c=None: "")
        a = recall.ColumnIndex(None, "p", None, embed_model="nomic-embed-text")
        b = recall.ColumnIndex(None, "p", None, embed_model="e5-large")
        self.assertNotEqual(a.fingerprint(clar), b.fingerprint(clar))


class CorpusMinScoreTests(unittest.TestCase):
    """The score a remembered question must reach, read at every search."""

    def recall_with(self, scores):
        import recall
        rec = recall.Recall(None, "t_corpus", None)
        rec.neighbours = lambda _q, limit=3: [
            (s, {"question": f"q{i}", "tables": [f"t{i}"]})
            for i, s in enumerate(scores)][:limit]
        return rec

    def test_the_configured_score_decides_which_neighbours_count(self):
        rec = self.recall_with([0.84, 0.74])
        with patch.dict("os.environ", {"DATAGORA_CORPUS_MIN_SCORE": ""}):
            self.assertEqual(rec.anchors("q"), ["t0", "t1"])      # 0.72
        with patch.dict("os.environ", {"DATAGORA_CORPUS_MIN_SCORE": "0.8"}):
            self.assertEqual(rec.anchors("q"), ["t0"])
        with patch.dict("os.environ", {"DATAGORA_CORPUS_MIN_SCORE": "0.9"}):
            self.assertEqual(rec.anchors("q"), [])

    def test_an_unreadable_score_falls_back_to_the_default(self):
        import recall
        for bad in ("high", "1.5", "-1"):
            with self.subTest(bad=bad), \
                    patch.dict("os.environ", {"DATAGORA_CORPUS_MIN_SCORE": bad}):
                self.assertEqual(recall.corpus_min_score(), recall.MIN_SCORE)

    def test_a_score_given_by_the_caller_wins(self):
        rec = self.recall_with([0.84, 0.74])
        with patch.dict("os.environ", {"DATAGORA_CORPUS_MIN_SCORE": "0.9"}):
            self.assertEqual(rec.anchors("q", min_score=0.7), ["t0", "t1"])


class RunRecordTests(unittest.TestCase):
    """Each run of a job keeps its time with the job, written as it goes."""

    def test_a_run_is_brought_up_to_date_and_the_next_one_added(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = pathlib.Path(tmp) / "lib_coverage.csv"
            out.write_text("question,verdict\n", encoding="utf-8")
            subject.write_manifest(out, "job1", pathlib.Path(tmp) / "q.csv", 4)
            subject.record_run(out, {"id": "a", "seconds": 1.0, "judged": 1})
            subject.record_run(out, {"id": "a", "seconds": 3.0, "judged": 2})   # the same run, later
            subject.record_run(out, {"id": "b", "seconds": 2.0, "judged": 2})   # a Resume
            runs = subject.read_manifest(out)["runs"]
            self.assertEqual([(r["id"], r["seconds"]) for r in runs], [("a", 3.0), ("b", 2.0)])
            # what a Resume carries on from, and what the saved runs list adds up
            self.assertEqual(sum(r["seconds"] for r in runs), 5.0)

    def test_a_resume_keeps_the_runs_before_it(self):
        # a Resume writes the manifest again; the earlier runs must survive
        with tempfile.TemporaryDirectory() as tmp:
            out = pathlib.Path(tmp) / "lib_coverage.csv"
            out.write_text("question,verdict\n", encoding="utf-8")
            subject.write_manifest(out, "job1", pathlib.Path(tmp) / "q.csv", 4)
            subject.record_run(out, {"id": "a", "seconds": 4.0, "judged": 3})
            subject.write_manifest(out, "job1", pathlib.Path(tmp) / "q.csv", 4)   # the Resume
            self.assertEqual([r["id"] for r in subject.read_manifest(out)["runs"]], ["a"])


class CorpusIndexTests(unittest.TestCase):
    """A dictionary indexed a batch at a time, with no Qdrant and no model."""

    class Client:
        """The few Qdrant calls the corpus makes, over a list of points."""

        def __init__(self, points):
            self.points, self.deleted, self.dropped = points, [], False

        def get_collections(self):
            return SimpleNamespace(collections=[] if self.dropped
                                   else [SimpleNamespace(name="t_corpus")])

        def scroll(self, _collection, scroll_filter=None, **_kw):
            points = self.points
            if scroll_filter is not None:
                wanted = scroll_filter.must[0].match.value
                points = [x for x in points if x["payload"].get("source") == wanted]
            return [SimpleNamespace(id=x["id"], payload=x["payload"]) for x in points], None

        def delete(self, _collection, points_selector):
            self.deleted += list(points_selector.points)

        def delete_collection(self, _collection):
            self.dropped, self.points = True, []

    def point(self, question, source, model="nomic-embed-text"):
        import recall
        return {"id": recall.Recall.point_id(question),
                "payload": {"question": question, "tables": ["t"], "sql": "",
                            "source": source, "model": model}}

    def recall(self, points=None, written=None, model="nomic-embed-text"):
        import recall
        rec = recall.Recall("http://q", "t_corpus", "http://e", embed_model=model)
        rec._client, rec._checked = self.Client(points if points is not None else [
            self.point("a question the old version had", "dictionary"),
            self.point("question 1", "dictionary")]), True
        self.seeded = []
        rec.seed = written or (lambda chunk, source=None: self.seeded.append(chunk) or len(chunk))
        return rec

    def test_progress_is_said_and_what_left_the_dictionary_goes(self):
        rec = self.recall()
        steps = []
        pairs = [{"question": f"question {i}", "sql": "SELECT 1 FROM t"} for i in range(30)]
        done = rec.index(pairs, progress=lambda d, t: steps.append((d, t)))
        self.assertEqual(done["indexed"], 30)
        self.assertEqual(steps[0], (0, 30))
        self.assertEqual(steps[-1], (30, 30))
        self.assertGreater(len(steps), 3)                 # several steps, not one jump
        # the question the new version dropped is removed, the kept one is not
        self.assertEqual(done["removed"], 1)
        self.assertEqual(rec.client.deleted, [rec.point_id("a question the old version had")])
        self.assertEqual(done["reembedded"], 0)           # same model: nothing rebuilt

    def test_a_model_that_gives_no_vector_is_an_error_not_a_silence(self):
        rec = self.recall(written=lambda chunk, source=None: 0)
        with self.assertRaises(RuntimeError):
            rec.index([{"question": "q", "sql": "SELECT 1 FROM t"}])

    def test_a_new_model_rebuilds_the_corpus_and_keeps_what_was_learned(self):
        # vectors of two models cannot be compared: the collection goes, and
        # every question is embedded again, the one learned from use included
        rec = self.recall(model="jeffh/intfloat-multilingual-e5-large:f16", points=[
            self.point("how many genres are there?", "dictionary"),
            self.point("which loans are late?", "asked")])
        done = rec.index([{"question": "how many genres are there?", "sql": "SELECT 1 FROM genres"}])
        self.assertTrue(rec.client.dropped)
        self.assertEqual(done["reembedded"], 1)
        written = [q for chunk in self.seeded for q in chunk]
        self.assertEqual({(q["question"], q["source"]) for q in written},
                         {("which loans are late?", "asked"),
                          ("how many genres are there?", "dictionary")})

    def test_a_corpus_of_another_model_is_never_searched(self):
        rec = self.recall(model="jeffh/intfloat-multilingual-e5-large:f16")
        rec.embed = lambda _texts: self.fail("searched with vectors of another model")
        self.assertEqual(rec.neighbours("how many genres?"), [])

    def test_each_model_has_its_own_bar(self):
        import recall
        with patch.dict("os.environ", {"DATAGORA_CORPUS_MIN_SCORE": ""}):
            self.assertEqual(recall.corpus_min_score("nomic-embed-text:latest"), 0.72)
            self.assertEqual(recall.corpus_min_score("jeffh/intfloat-multilingual-e5-large:f16"), 0.80)
            self.assertEqual(recall.corpus_min_score("some-other-model"), recall.MIN_SCORE)
        with patch.dict("os.environ", {"DATAGORA_CORPUS_MIN_SCORE": "0.9"}):
            self.assertEqual(recall.corpus_min_score("e5-large"), 0.9)   # the one typed wins


class ParallelTests(unittest.TestCase):
    """A batch spread over several slots, on one GPU or several machines.

    The slots are stand-in clarifiers that answer after a set delay, so the
    tests can make the LAST question finish first and see where its verdict
    lands. No model and no database are involved."""

    class SlowClarifier:
        def __init__(self, delays, log, lock):
            self.delays, self.log, self.lock = delays, log, lock

        def clarify(self, text):
            import threading
            import time
            with self.lock:
                self.log.append(("start", text, threading.get_ident()))
            time.sleep(self.delays.get(text, 0.01))
            from ambisql import Outcome
            return Outcome(action="ANSWER")

    def slots(self, n, delays):
        import threading
        log, lock = [], threading.Lock()
        return [self.SlowClarifier(delays, log, lock) for _ in range(n)], log

    def test_a_slow_first_question_holds_nothing_back(self):
        # the first question is the slowest: the others are handed over as
        # they finish, before it, each with the place it was asked at, which
        # is what puts it on its row; the list returned is in the order asked
        work = [(f"q{i}", {"id": str(i)}) for i in range(6)]
        delays = {"q0": 0.30, "q1": 0.05, "q2": 0.01}
        slots, _ = self.slots(3, delays)
        seen = []
        out = subject._assess_in_parallel(slots, work, seen.append, False)
        self.assertEqual([v.question for v in out], [q for q, _ in work])
        self.assertEqual(seen[-1].question, "q0")
        self.assertEqual(sorted(v.question for v in seen), [q for q, _ in work])
        self.assertTrue(all(v.question == f"q{v.position}" for v in seen))
        self.assertEqual([v.extra["id"] for v in out],
                         [str(i) for i in range(6)])

    def test_the_callback_is_never_called_twice_at_once(self):
        import threading
        import time
        busy, clash = threading.Lock(), []

        def on_each(v):
            if not busy.acquire(blocking=False):
                clash.append(v.question)
                return
            try:
                time.sleep(0.02)          # widen the window a clash needs
            finally:
                busy.release()

        work = [(f"q{i}", {}) for i in range(8)]
        slots, _ = self.slots(4, {})
        subject._assess_in_parallel(slots, work, on_each, False)
        self.assertEqual(clash, [])

    def test_the_work_really_runs_at_the_same_time(self):
        import time
        work = [(f"q{i}", {}) for i in range(4)]
        slots, log = self.slots(4, {f"q{i}": 0.25 for i in range(4)})
        start = time.monotonic()
        subject._assess_in_parallel(slots, work, None, False)
        elapsed = time.monotonic() - start
        # four quarter-second questions on four slots: well under the
        # second they would take one after another
        self.assertLess(elapsed, 0.8)
        self.assertEqual(len({ident for _, _, ident in log}), 4)

    def test_a_stop_keeps_what_was_decided_and_starts_nothing_more(self):
        # the page's Stop: the questions being judged finish and are handed
        # back in order, no new one starts, and a resume picks up after them
        import threading
        cancel = threading.Event()
        work = [(f"q{i}", {}) for i in range(12)]
        slots, log = self.slots(2, {f"q{i}": 0.05 for i in range(12)})
        seen = []

        def on_each(v):
            seen.append(v.question)
            if len(seen) == 3:
                cancel.set()

        out = subject._assess_in_parallel(slots, work, on_each, False, cancel=cancel)
        started = [text for kind, text, _ in log if kind == "start"]
        self.assertLess(len(out), 12)
        # an unbroken run from the first question, nothing skipped
        self.assertEqual([v.question for v in out], [f"q{i}" for i in range(len(out))])
        # every question started was finished and kept
        self.assertEqual(sorted(started), sorted(v.question for v in out))

    def test_a_stop_before_the_next_question_on_one_slot(self):
        import threading
        cancel = threading.Event()
        seen = []

        def on_each(v):
            seen.append(v.question)
            cancel.set()

        slots, _ = self.slots(1, {})
        with patch.object(subject, "_slots", return_value=slots):
            out = subject.assess([f"q{i}" for i in range(5)], profile=SimpleNamespace(name="p"),
                                 on_each=on_each, cancel=cancel)
        self.assertEqual([v.question for v in out], ["q0"])

    def test_a_failure_stops_the_batch_when_asked_to(self):
        class Boom(self.SlowClarifier):
            def clarify(self, text):
                if text == "q1":
                    raise RuntimeError("the model is down")
                return super().clarify(text)

        import threading
        log, lock = [], threading.Lock()
        slots = [Boom({}, log, lock) for _ in range(2)]
        work = [(f"q{i}", {}) for i in range(5)]
        with self.assertRaises(RuntimeError):
            subject._assess_in_parallel(slots, work, None, True)

    def test_a_failure_is_one_unknown_otherwise(self):
        class Boom(self.SlowClarifier):
            def clarify(self, text):
                if text == "q1":
                    raise RuntimeError("the model is down")
                return super().clarify(text)

        import threading
        log, lock = [], threading.Lock()
        slots = [Boom({}, log, lock) for _ in range(2)]
        work = [(f"q{i}", {}) for i in range(4)]
        out = subject._assess_in_parallel(slots, work, None, False)
        self.assertEqual([v.verdict for v in out],
                         ["ANSWERABLE", "UNKNOWN", "ANSWERABLE", "ANSWERABLE"])

    def test_a_callers_own_model_gets_one_slot(self):
        # it may not be safe to share across threads, so parallelism is
        # only ever switched on for endpoints this package built itself
        own = SimpleNamespace(json=lambda *a, **k: {"ambiguous": False},
                              parallel=8)
        # the slots, not the judge: the single call, which reads no schema
        slots = subject._slots(None, lambda: None, "s", own, judge="single")
        self.assertEqual(len(slots), 1)

    def test_each_slot_has_a_model_object_of_its_own(self):
        # an endpoint with parallel 3 gives three slots, and the error one
        # request records must not be readable as another's
        endpoint = SimpleNamespace(json=lambda *a, **k: {"ambiguous": False},
                                   parallel=3, last_error="")
        other = SimpleNamespace(json=lambda *a, **k: {"ambiguous": False},
                                parallel=2, last_error="")
        slots = subject._slots(None, lambda: None, "s", [endpoint, other], judge="single")
        self.assertEqual(len(slots), 5)
        self.assertEqual(len({id(s.llm) for s in slots}), 5)
        # and a cap on workers is honoured
        self.assertEqual(len(subject._slots(None, lambda: None, "s",
                                            [endpoint, other], workers=2, judge="single")), 2)


class PromptVersionTests(unittest.TestCase):
    """A prompt cannot change without its version changing.

    The detection prompt was rewritten this cycle and six verdicts moved,
    four of them the wrong way, before it was right. A prompt is code that
    decides verdicts, and a silent edit to it is a silent change of
    behaviour; the registry makes every edit a named, dated version."""

    def test_no_prompt_changes_without_a_new_version(self):
        import prompts
        stale = []
        for name, entry in prompts.VERSIONS.items():
            live = prompts.fingerprint(getattr(prompts, entry["text"]))
            if live != entry["sha"]:
                stale.append(
                    f"{name}: the text is now {live}, registered as "
                    f"v{entry['version']} {entry['sha']}. Bump its version, "
                    f"set sha to {live}, and say what changed in PROMPTS.md")
        self.assertEqual(stale, [], "\n".join(stale))

    def test_every_prompt_in_the_module_is_registered(self):
        import prompts
        defined = {n for n in dir(prompts) if n.endswith("_SYSTEM")}
        registered = {e["text"] for e in prompts.VERSIONS.values()}
        self.assertEqual(defined - registered, set(),
                         "a prompt with no version cannot be traced back")

    def test_an_edited_prompt_says_so_wherever_it_is_recorded(self):
        import prompts
        original = prompts.DECIDE_SYSTEM
        try:
            prompts.DECIDE_SYSTEM = original + " An edit nobody registered."
            self.assertIn("unregistered", prompts.version_of("decide"))
        finally:
            prompts.DECIDE_SYSTEM = original
        self.assertNotIn("unregistered", prompts.version_of("decide"))

    def test_the_clarifier_uses_the_registered_texts(self):
        import ambisql
        import prompts
        self.assertIs(ambisql.SYSTEM, prompts.DETECT_SYSTEM)
        self.assertIs(ambisql.Clarifier.DECIDE_SYSTEM, prompts.DECIDE_SYSTEM)

    def test_a_run_records_the_prompts_it_was_judged_with(self):
        import json
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        out = pathlib.Path(tmp.name) / "run.csv"
        subject.write_manifest(out, "job", "q.csv", 3, profile="lib")
        manifest = json.loads(subject.manifest_path(out).read_text(encoding="utf-8"))
        self.assertIn("prompts", manifest)
        self.assertTrue(manifest["prompts"]["detect"].startswith("detect v"))


class VersionTests(unittest.TestCase):
    """The version is written twice, so it is checked once.

    pyproject.toml names the wheel and graph_lab.__version__ is what an
    integrator prints to say which build they are running. Nothing forces
    them to agree, and a customer holding a wheel labelled one thing that
    reports another has no way to tell which is true.

    The version is read out of the source file rather than imported. In a
    working copy whose venv also has the wheel installed, `import
    graph_lab` resolves to site-packages, so an imported version would
    report the last build and this guard would pass while the repository
    drifted. That is not a hypothetical: it is what the first run of this
    test found."""

    def source_version(self):
        init = pathlib.Path(__file__).resolve().parent / "__init__.py"
        for line in init.read_text(encoding="utf-8").splitlines():
            if line.strip().startswith("__version__"):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
        return None

    def test_the_package_and_the_wheel_claim_the_same_version(self):
        version = self.source_version()
        self.assertIsNotNone(version, "__init__.py declares no __version__")
        pyproject = (pathlib.Path(__file__).resolve().parents[2]
                     / "pyproject.toml")
        if not pyproject.is_file():
            self.skipTest("installed without its pyproject")
        declared = None
        for line in pyproject.read_text(encoding="utf-8").splitlines():
            if line.strip().startswith("version"):
                declared = line.split("=", 1)[1].strip().strip('"').strip("'")
                break
        self.assertIsNotNone(declared, "pyproject.toml declares no version")
        self.assertEqual(version, declared)

    def test_the_readme_installs_the_version_it_documents(self):
        version = self.source_version()
        here = pathlib.Path(__file__).resolve().parent
        for name in ("README.md", "INTEGRATION.md"):
            doc = here / name
            if not doc.is_file():
                continue
            text = doc.read_text(encoding="utf-8")
            stale = [line.strip() for line in text.splitlines()
                     if "datagora_graph_lab-" in line
                     and f"datagora_graph_lab-{version}" not in line]
            self.assertEqual(stale, [], f"{name} names another wheel")


class OllamaSpellingTests(unittest.TestCase):
    """Values Ollama refuses or lists under another name, as measured
    against a real 0.30.10 through the realistic fake."""

    def test_keep_alive_is_a_number_or_a_duration_with_its_unit(self):
        import llm
        # "-1" and "300" as strings were refused with HTTP 400, which made
        # every chat fail on an endpoint set to "always"
        self.assertEqual(llm.keep_alive("-1"), -1)
        self.assertEqual(llm.keep_alive("0"), 0)
        self.assertEqual(llm.keep_alive(" 300 "), 300)
        self.assertEqual(llm.keep_alive("30m"), "30m")
        self.assertEqual(llm.LLM("x", {"api": "ollama", "url": "http://h",
                                       "model": "m", "keep_alive": "-1"}
                                 ).keep_alive, -1)

    def test_a_model_without_a_tag_is_its_latest(self):
        import llm
        self.assertEqual(llm.model_name("mistral"), "mistral:latest")
        self.assertEqual(llm.model_name("gemma4:31b"), "gemma4:31b")


class ConfigurationTests(unittest.TestCase):
    """Where the databases and models come from, in what order."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = pathlib.Path(self.tmp.name)
        self.profiles = self.root / "profiles.json"
        self.profiles.write_text(
            '{"profiles": {"one": {"mysql": {"database": "a"}},'
            ' "two": {"mysql": {"database": "b"}}}}', encoding="utf-8")
        self.models = self.root / "models.json"
        self.models.write_text(
            '{"roles": {"reasoner": "x", "sql": "y"}, "endpoints": {'
            '"x": {"api": "ollama", "url": "http://h:1", "model": "mx"},'
            '"y": {"api": "ollama", "url": "http://h:2", "model": "my"}}}',
            encoding="utf-8")
        for module in ("db_profile", "llm"):
            __import__(module)

    def tearDown(self):
        self.tmp.cleanup()

    def env(self, **values):
        keys = ["DATAGORA_PROFILES", "DATAGORA_MODELS", "MYSQL_DATABASE",
                "MYSQL_HOST", "DATAGORA_LLM_URL", "DATAGORA_LLM_MODEL",
                "DATAGORA_DATABASES", "DATAGORA_ENDPOINTS"]
        return patch.dict("os.environ",
                          {k: v for k, v in values.items() if v is not None},
                          clear=False) if False else patch.dict(
            "os.environ", {k: values.get(k, "") for k in keys})

    def test_one_database_and_one_model_need_no_file(self):
        import db_profile
        import llm
        with self.env(MYSQL_DATABASE="warehouse", MYSQL_HOST="db.internal",
                      DATAGORA_LLM_URL="http://models:8000",
                      DATAGORA_LLM_MODEL="theirs"):
            self.assertEqual(db_profile.DbProfile.names(), ["warehouse"])
            profile = db_profile.DbProfile.load("warehouse")
            self.assertEqual(profile.mysql["host"], "db.internal")
            self.assertEqual(llm.LLM.role("reasoner").model, "theirs")
            self.assertEqual(llm.LLM.role("sql").model, "theirs")

    def test_optional_services_are_off_until_they_are_configured(self):
        import db_profile
        with patch.dict("os.environ", {
                "DATAGORA_PROFILES": "", "MYSQL_DATABASE": "warehouse",
                "NEO4J_URI": "", "DATAGORA_NEO4J_URI": "",
                "QDRANT_URL": "", "DATAGORA_QDRANT_URL": "",
                "OLLAMA_URL": "", "DATAGORA_OLLAMA_URL": ""}, clear=False):
            profile = db_profile.DbProfile.load("warehouse")
            self.assertIsNone(profile.neo4j_uri)
            self.assertIsNone(profile.qdrant_url)
            self.assertIsNone(profile.ollama_url)
            with self.assertRaisesRegex(RuntimeError, "not configured"):
                profile.connect_neo4j()

    def test_a_named_file_wins_over_the_environment(self):
        # the only reason to name a file is to describe more than the
        # environment can. Letting MYSQL_DATABASE win reduced a mounted
        # file of several databases to one, silently.
        import db_profile
        import llm
        with self.env(DATAGORA_PROFILES=str(self.profiles),
                      DATAGORA_MODELS=str(self.models),
                      MYSQL_DATABASE="ignored",
                      DATAGORA_LLM_URL="http://ignored:1",
                      DATAGORA_LLM_MODEL="ignored"):
            self.assertEqual(db_profile.DbProfile.names(), ["one", "two"])
            self.assertEqual(llm.LLM.names(), ["x", "y"])
            self.assertEqual(llm.LLM.role("sql").model, "my")

    def test_an_empty_variable_means_unset_not_blank(self):
        # compose passes a variable it cannot resolve as "", and a read
        # that trusted the key's presence blanked the value it should
        # have defaulted to: the page showed a model with no name at all
        import llm
        with self.env(DATAGORA_LLM_URL="", DATAGORA_LLM_MODEL="",
                      DATAGORA_MODELS=str(self.models)):
            self.assertEqual(llm.LLM.role("reasoner").model, "mx")
            self.assertEqual(llm.LLM.role("reasoner").url, "http://h:1")

    def test_a_split_sql_role_takes_its_own_host(self):
        import llm
        with patch.dict("os.environ", {
                "DATAGORA_MODELS": "", "DATAGORA_LLM_URL": "http://a:1",
                "DATAGORA_LLM_MODEL": "reasoner-model",
                "DATAGORA_LLM_SQL_URL": "http://b:2",
                "DATAGORA_LLM_SQL_MODEL": "sql-model"}):
            self.assertEqual(llm.LLM.role("reasoner").model, "reasoner-model")
            self.assertEqual(llm.LLM.role("sql").model, "sql-model")
            self.assertEqual(llm.LLM.role("sql").url, "http://b:2")

    # the .env as production writes it: one block per database and per
    # endpoint, everything about each in one place
    ENV = {
        "DATAGORA_PROFILES": "", "DATAGORA_MODELS": "", "MYSQL_DATABASE": "",
        "DATAGORA_LLM_URL": "", "DATAGORA_LLM_MODEL": "",
        "DATAGORA_MYSQL_HOST": "", "DATAGORA_NEO4J_HOST": "",
        "DATAGORA_DATABASES": "warehouse, billing",
        "DATAGORA_DB_WAREHOUSE_HOST": "db.internal",
        "DATAGORA_DB_WAREHOUSE_PORT": "3307",
        "DATAGORA_DB_WAREHOUSE_DATABASE": "wh",
        "DATAGORA_DB_WAREHOUSE_USER": "reader",
        "DATAGORA_DB_WAREHOUSE_PASSWORD": "secret-1",
        "DATAGORA_DB_WAREHOUSE_DESCRIPTIONS": "examples/kb_library.json",
        "DATAGORA_DB_BILLING_USER": "clerk",
        "DATAGORA_DB_BILLING_NEO4J_URI": "off",
        "NEO4J_URI": "bolt://graph.internal:7687", "NEO4J_USER": "neo",
        "NEO4J_PASSWORD": "graph-secret",
        "DATAGORA_ENDPOINTS": "gpu_a,gpu_b",
        "DATAGORA_ENDPOINT_GPU_A_URL": "http://10.0.0.5:11434",
        "DATAGORA_ENDPOINT_GPU_A_MODEL": "gemma4:31b",
        "DATAGORA_ENDPOINT_GPU_A_PARALLEL": "2",
        "DATAGORA_ENDPOINT_GPU_A_KEEP_ALIVE": "-1",
        "DATAGORA_ENDPOINT_GPU_B_URL": "http://10.0.0.6:11434",
        "DATAGORA_ENDPOINT_GPU_B_MODEL": "mistral-small:24b",
        "DATAGORA_ENDPOINT_GPU_B_NUM_CTX": "32768",
        "DATAGORA_LLM_REASONER": "gpu_a,gpu_b", "DATAGORA_LLM_SQL": "gpu_b",
    }

    def test_several_databases_are_one_block_each_in_the_env(self):
        import db_profile
        with patch.dict("os.environ", self.ENV):
            self.assertEqual(db_profile.DbProfile.names(),
                             ["warehouse", "billing"])
            wh = db_profile.DbProfile.load("warehouse")
            self.assertEqual(wh.mysql, {"host": "db.internal", "port": 3307,
                                        "database": "wh", "user": "reader",
                                        "password": "secret-1"})
            # the shared graph settings fill what the block does not say
            self.assertEqual(wh.neo4j_uri, "bolt://graph.internal:7687")
            self.assertEqual((wh.neo4j_user, wh.neo4j_password),
                             ("neo", "graph-secret"))
            self.assertNotIn("graph-secret", repr(wh))
            # a relative dictionary is found in the package, as in the image
            self.assertTrue(pathlib.Path(wh.descriptions).is_file())
            billing = db_profile.DbProfile.load("billing")
            self.assertEqual(billing.mysql["database"], "billing")
            self.assertEqual(billing.mysql["host"], "127.0.0.1")
            self.assertIsNone(billing.neo4j_uri)
            self.assertIn(".env", db_profile.profiles_source()[0])
            with self.assertRaises(SystemExit):
                db_profile.DbProfile.load("payroll")

    def test_endpoints_roles_and_pools_come_from_the_env(self):
        import llm
        with patch.dict("os.environ", self.ENV):
            self.assertEqual(llm.LLM.names(), ["gpu_a", "gpu_b"])
            self.assertEqual([e.name for e in llm.LLM.pool("reasoner")],
                             ["gpu_a", "gpu_b"])
            sql = llm.LLM.role("sql")
            self.assertEqual((sql.name, sql.model, sql.num_ctx),
                             ("gpu_b", "mistral-small:24b", 32768))
            gpu_a = llm.LLM.role("reasoner")
            self.assertEqual((gpu_a.parallel, gpu_a.keep_alive), (2, -1))
            self.assertIn(".env", llm.models_source()[0])

    def test_a_listed_endpoint_must_say_where_and_what(self):
        import llm
        broken = dict(self.ENV, DATAGORA_ENDPOINT_GPU_B_MODEL="")
        with patch.dict("os.environ", broken), \
                self.assertRaisesRegex(SystemExit, "DATAGORA_ENDPOINT_GPU_B_"):
            llm.LLM.names()
        unknown = dict(self.ENV, DATAGORA_LLM_SQL="gpu_c")
        with patch.dict("os.environ", unknown), \
                self.assertRaisesRegex(SystemExit, "gpu_c"):
            llm.LLM.role("sql")


class JobTests(unittest.TestCase):
    """Versions keyed on the questions, not on the output's name."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = pathlib.Path(self.tmp.name)
        self.out = self.root / "verdicts.csv"

    def tearDown(self):
        self.tmp.cleanup()

    def write(self, name, body):
        path = self.root / name
        path.write_text(body, encoding="utf-8")
        return path

    def run_file(self, questions, profile_name=None, **kw):
        clarifier = Mock()
        clarifier.clarify.return_value = outcome()
        profile = SimpleNamespace(name=profile_name) if profile_name else object()
        with patch.object(subject, "Clarifier", return_value=clarifier):
            report = subject.assess_file(questions, self.out,
                                         profile=profile, **kw)
        return report, clarifier.clarify.call_count

    def test_the_job_is_the_whole_row_so_it_matches_what_resume_matches(self):
        first = subject.job_id([{"id": "1", "question": "how many"}])
        self.assertEqual(first, subject.job_id([{"question": "how many",
                                                 "id": "1"}]))
        self.assertNotEqual(first, subject.job_id([{"id": "1",
                                                    "question": "how much"}]))
        # a changed metadata column is a changed row: it has to be a new
        # job, or the run is sent back to a file whose rows no longer
        # match it and fails there with no way out
        self.assertNotEqual(first, subject.job_id([{"id": "2",
                                                    "question": "how many"}]))

    def test_an_edited_metadata_column_versions_instead_of_dead_ending(self):
        self.write("q.csv", "id,theme,question\n1,stock,first\n2,stock,second\n")
        before, _ = self.run_file(self.root / "q.csv")
        self.write("q.csv",
                   "id,theme,question\n1,stock,first\n2,logistics,second\n")
        after, asked = self.run_file(self.root / "q.csv")

        self.assertIsNone(after.stopped)
        self.assertTrue(after.complete)
        self.assertNotEqual(after.output, before.output)
        self.assertEqual((asked, after.already_done), (1, 1))

    def test_a_second_job_lands_beside_the_first_instead_of_over_it(self):
        a = self.write("a.csv", "id,question\n1,first\n2,second\n")
        b = self.write("b.csv", "id,question\n1,third\n2,fourth\n")
        first, _ = self.run_file(a)
        second, _ = self.run_file(b)

        self.assertEqual(first.output, str(self.out))
        self.assertNotEqual(second.output, first.output)
        self.assertIn(second.job, second.output)
        self.assertIn("belongs to another job", second.note)
        # the first job's verdicts are still exactly where they were
        with open(first.output, encoding="utf-8-sig", newline="") as fh:
            kept = [row["question"] for row in csv.DictReader(fh)]
        self.assertEqual(kept, ["first", "second"])

    def test_resume_is_keyed_on_the_question_file_not_the_output_name(self):
        a = self.write("a.csv", "id,question\n1,first\n2,second\n")
        b = self.write("b.csv", "id,question\n1,third\n2,fourth\n")
        self.run_file(a)
        self.run_file(b)
        # b again, still pointed at the original --out: it finds its own
        # version and has nothing left to do
        again, asked = self.run_file(b)
        self.assertEqual((again.processed, again.already_done, asked), (0, 2, 0))

    def test_an_edited_question_is_rejudged_and_the_others_are_not(self):
        before = self.write("q.csv", "id,question\n1,first\n2,second\n")
        self.run_file(before)
        after = self.write("q.csv",
                           "id,question\n1,first\n2,second with more words\n")
        report, asked = self.run_file(after)

        self.assertEqual(asked, 1)                  # only the edited one
        # "first" was carried over untouched, "second..." was judged again
        self.assertEqual((report.already_done, report.processed), (1, 1))
        self.assertIn("carrying 1 verdict", report.note)
        self.assertTrue(report.complete)
        with open(report.output, encoding="utf-8-sig", newline="") as fh:
            rows = [row["question"] for row in csv.DictReader(fh)]
        self.assertEqual(rows, ["first", "second with more words"])

    def test_restart_writes_the_named_file_and_asks_everything_again(self):
        q = self.write("q.csv", "id,question\n1,first\n2,second\n")
        self.run_file(q)
        report, asked = self.run_file(q, restart=True)
        self.assertEqual((asked, report.already_done), (2, 0))
        self.assertEqual(report.output, str(self.out))

    def test_restart_of_a_version_never_deletes_the_base_job(self):
        first = self.write("first.csv", "id,question\n1,first\n")
        second = self.write("second.csv", "id,question\n2,second\n")
        base, _asked = self.run_file(first)
        version, _asked = self.run_file(second)
        base_text = pathlib.Path(base.output).read_text(encoding="utf-8-sig")
        self.assertNotEqual(base.output, version.output)

        restarted, asked = self.run_file(second, restart=True)
        self.assertEqual(asked, 1)
        self.assertEqual(restarted.output, version.output)
        self.assertEqual(pathlib.Path(base.output).read_text(encoding="utf-8-sig"),
                         base_text)

    def test_a_failed_run_reports_where_it_stopped_and_keeps_its_rows(self):
        q = self.write("q.csv", "id,question\n1,first\n2,second\n3,third\n")

        def die_on_the_second(questions, on_each, **_):
            on_each(subject.Verdict(question=questions[0]["question"],
                                    verdict=subject.ANSWERABLE,
                                    extra={"id": "1"}))
            raise RuntimeError("the database went away")

        with patch.object(subject, "assess", side_effect=die_on_the_second):
            report = subject.assess_file(q, self.out, profile=object())
        self.assertIn("the database went away", report.stopped)
        self.assertFalse(report.complete)
        self.assertEqual(report.processed, 1)

        # and the resume picks up the two that never ran
        resumed, asked = self.run_file(q)
        self.assertEqual((asked, resumed.already_done), (2, 1))
        self.assertTrue(resumed.complete)

    def test_restart_of_a_version_carries_nothing_over(self):
        # review of 26 October: the restart seeded the version again from
        # its siblings, and a re-measurement kept the old verdicts
        self.run_file(self.write("q.csv", "id,question\n1,a\n2,b\n3,c\n"))
        q = self.write("q.csv", "id,question\n1,a\n2,b\n3,c\n4,d\n")
        carried, asked = self.run_file(q)
        self.assertEqual((asked, carried.already_done), (1, 3))
        restarted, asked = self.run_file(q, restart=True)
        self.assertEqual((asked, restarted.already_done, restarted.processed), (4, 0, 4))

    def test_verdicts_of_another_database_are_never_resumed_or_carried(self):
        # review of 26 October: dbB resumed dbA's verdicts as its own
        q = self.write("q.csv", "id,question\n1,a\n2,b\n")
        first, _ = self.run_file(q, profile_name="dbA")
        with self.assertRaisesRegex(ValueError, "judged against dbA"):
            self.run_file(q, profile_name="dbB")
        self.assertEqual(subject.read_manifest(first.output)["profile"], "dbA")
        # a version of the list for dbB carries nothing of dbA's
        q2 = self.write("q.csv", "id,question\n1,a\n2,b\n3,c\n")
        version, asked = self.run_file(q2, profile_name="dbB")
        self.assertEqual((asked, version.already_done), (3, 0))

    def test_review_of_the_fixes_carried_verdicts_keep_their_prompts_and_date(self):
        # verdicts of another prompt version are never carried
        self.run_file(self.write("q.csv", "id,question\n1,a\n2,b\n"), context={"date": "2025-03-01"})
        q = self.write("q.csv", "id,question\n1,a\n2,b\n3,c\n")
        with patch.object(subject, "prompt_versions", return_value={"agent": "v99"}):
            other, asked = self.run_file(q)
        self.assertEqual((asked, other.already_done), (3, 0))

    def test_review_of_the_fixes_carried_verdicts_set_the_version_s_date(self):
        self.run_file(self.write("q.csv", "id,question\n1,a\n2,b\n"), context={"date": "2025-03-01"})
        q = self.write("q.csv", "id,question\n1,a\n2,b\n3,c\n")
        report, asked = self.run_file(q)
        self.assertEqual((asked, report.already_done), (1, 2))
        self.assertEqual(subject.read_manifest(report.output)["asked_on"], "2025-03-01")

    def test_review_of_the_fixes_a_hand_given_schema_is_a_database(self):
        q = self.write("q.csv", "id,question\n1,a\n2,b\n")
        clarifier = Mock()
        clarifier.clarify.return_value = outcome()
        with patch.object(subject, "Clarifier") as made:
            made.return_value = made.for_connection.return_value = clarifier
            subject.assess_file(q, self.out, connect=lambda: None, schema="sales")
            with self.assertRaisesRegex(ValueError, "judged against schema sales"):
                subject.assess_file(q, self.out, connect=lambda: None, schema="hr")

    def test_review_of_the_fixes_a_date_set_on_purpose_wins_over_the_pinned_one(self):
        q = self.write("q.csv", "id,question\n1,a\n2,b\n")
        self.run_file(q, context={"date": "2025-03-01"})
        with patch.dict(os.environ, {"DATAGORA_CONTEXT": '{"date": "2025-12-31"}'}):
            self.assertIsNone(subject.resume_context(self.out))
        self.assertEqual(subject.resume_context(self.out), {"date": "2025-03-01"})

    def test_a_stop_in_the_middle_of_a_question_writes_no_row_for_it(self):
        # review of 26 October: AgentCancelled became an UNKNOWN row
        class Cancelled(RuntimeError):
            stops_the_job = True

        q = self.write("q.csv", "id,question\n1,a\n2,b\n3,c\n")
        clarifier = Mock()
        clarifier.clarify.side_effect = [outcome(), Cancelled("the job was stopped")]
        with patch.object(subject, "Clarifier", return_value=clarifier):
            report = subject.assess_file(q, self.out, profile=object())
        self.assertEqual((report.processed, report.counts), (1, {"ANSWERABLE": 1}))
        with open(self.out, encoding="utf-8-sig", newline="") as fh:
            self.assertEqual([row["verdict"] for row in csv.DictReader(fh)], ["ANSWERABLE"])
        resumed, asked = self.run_file(q)
        self.assertEqual((asked, resumed.already_done), (2, 1))

    def test_a_resume_counts_from_the_date_its_first_run_did(self):
        q = self.write("q.csv", "id,question\n1,a\n2,b\n")

        def one_then_die(questions, on_each, **kw):
            on_each(subject.Verdict(question=questions[0]["question"],
                                    verdict=subject.ANSWERABLE, extra={"id": "1"}))
            raise RuntimeError("the database went away")

        with patch.object(subject, "assess", side_effect=one_then_die):
            subject.assess_file(q, self.out, profile=object(), context={"date": "2025-03-01"})
        seen = {}

        def rest(questions, on_each, context=None, **kw):
            seen["context"] = context

        with patch.object(subject, "assess", side_effect=rest):
            subject.assess_file(q, self.out, profile=object())
        self.assertEqual(seen["context"], {"date": "2025-03-01"})
        manifest = subject.read_manifest(self.out)
        self.assertEqual(manifest["asked_on"], "2025-03-01")
        self.assertEqual([r["asked_on"] for r in manifest["runs"]], ["2025-03-01", "2025-03-01"])
        self.assertIn("agent", manifest["runs"][-1]["prompts"])


class MainTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = pathlib.Path(self.tmp.name)
        self.questions = root / "questions.csv"
        self.output = root / "verdicts.csv"
        self.questions.write_text(
            "id,question\n1,first\n2,second\n", encoding="utf-8")

    def tearDown(self):
        self.tmp.cleanup()

    def run_main(self, fake_assess):
        argv = ["coverage.py", "--profile", "demo", "--questions",
                str(self.questions), "--out", str(self.output)]
        profile = SimpleNamespace(name="demo")
        stdout = io.StringIO()
        with patch.object(sys, "argv", argv), \
                patch("db_profile.DbProfile.load", return_value=profile), \
                patch.object(subject, "assess", side_effect=fake_assess), \
                contextlib.redirect_stdout(stdout):
            subject.main()
        return stdout.getvalue()

    def test_second_run_skips_work_and_summarizes_saved_rows(self):
        calls = []

        def answer_all(questions, on_each, **_):
            calls.append(len(questions))
            for row in questions:
                on_each(subject.Verdict(
                    question=row["question"], verdict=subject.ANSWERABLE,
                    extra={"id": row["id"]}))

        self.run_main(answer_all)
        text = self.run_main(answer_all)
        self.assertEqual(calls, [2, 0])
        self.assertIn("2 of those were already decided", text)
        self.assertIn("2 of 2 answerable today", text)
        # the second run is the same job, so it stays in the same file
        self.assertTrue(self.output.exists())
        self.assertEqual(subject.read_manifest(self.output)["job"],
                         subject.job_id(subject.read_questions(self.questions)))

    def test_command_progress_shows_count_and_percentage(self):
        def answer_all(questions, on_each, **_):
            for row in questions:
                on_each(subject.Verdict(
                    question=row["question"], verdict=subject.ANSWERABLE,
                    extra={"id": row["id"]}))

        text = self.run_main(answer_all)
        self.assertIn("1/   2  50.0%", text)
        self.assertIn("2/   2 100.0%", text)

    def test_unknown_makes_shell_run_fail_but_stays_in_output(self):
        def fail(questions, on_each, **_):
            row = questions[0]
            on_each(subject.Verdict(
                question=row["question"], verdict=subject.UNKNOWN, missing="offline",
                extra={"id": row["id"]}))

        with self.assertRaises(SystemExit) as stopped:
            self.run_main(fail)
        self.assertEqual(stopped.exception.code, 1)
        with open(self.output, encoding="utf-8-sig", newline="") as fh:
            rows = list(csv.DictReader(fh))
        self.assertEqual(rows[0]["verdict"], subject.UNKNOWN)


if __name__ == "__main__":
    unittest.main(verbosity=2)
