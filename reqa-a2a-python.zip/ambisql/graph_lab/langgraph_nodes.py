"""The pipeline as LangGraph nodes, for a production graph that already exists.

`Datagora.ask` runs the whole journey in one call, which is right for a
script and wrong for an application that already owns its control flow.
A LangGraph pipeline wants the steps separately, so it can interrupt at
the clarification, retry on its own terms, stream, and checkpoint.

So the same stages are exposed here as plain functions of a state dict.
They import nothing from LangGraph: each one takes a state and returns
the keys it changed, which is exactly the contract a LangGraph node
already has. That keeps this file usable with LangGraph, with LangChain,
with a plain loop, or in a test, and keeps our side free of a dependency
on a version of their framework.

The clarify node runs the pipeline's own first step (Pipeline.prepare and
Pipeline.judge_stage), the very code Datagora.ask runs: who asks and when,
what was decided before, the judge, the stop on a choice or a GUIDE, the
suggestions, a choice coming back to readings no longer offered. The two
paths cannot judge a question differently (review of 26 October: the
nodes kept their own copy, which had fallen behind).

    from graph_lab import Datagora
    from graph_lab.langgraph_nodes import (nodes_for, should_clarify,
                                           after_anchors, after_check,
                                           after_execute)

    dg = Datagora(mysql=...)
    n = nodes_for(dg)

    g = StateGraph(dict)
    for name in ("clarify", "anchors", "generate", "check", "execute", "answer"):
        g.add_node(name, n[name])

    g.set_entry_point("clarify")
    g.add_conditional_edges("clarify", should_clarify,
                            {"ask_user": END, "continue": "anchors", "give_up": END})
    g.add_conditional_edges("anchors", after_anchors,
                            {"continue": "generate", "give_up": END})
    g.add_edge("generate", "check")
    g.add_conditional_edges("check", after_check,
                            {"retry": "generate", "run": "execute", "give_up": END})
    g.add_conditional_edges("execute", after_execute,
                            {"answer": "answer", "retry": "generate", "give_up": END})
    g.add_edge("answer", END)

The state keys are listed in STATE below. Nothing is hidden in objects:
every value is a string, a list or a dict, so a checkpointer can
serialise it and a trace can show it.
"""

STATE = """
    question             what the user asked, in their own words
    choice               the option label they picked, if they were asked
    suggestion           with choice, the suggested question they picked
                         for it: answered as it is, no second clarify
    context              in: who asks and when for this question, a dict of
                         facts over the client's (date, time, timezone,
                         language...); out: the context resolved
    earlier              in: what was decided before, the note the clarify
                         node returned for the question this one follows
                         (a suggestion picked) or for the question that
                         stopped (a choice); out: this question's note
    clarification        {action, kind, reason, question, phrase, checked,
                         empty, missing, gap, options[]}
    clarifying           when the graph stops for the user (a choice, a
                         NEEDS MORE): the sentence to show, in plain words
    suggestions          and the questions they can pick instead,
                         [{question, choice, note, blank}]; [] when the
                         pipeline's reformulate switch is off
    judged_tables        the tables the judge looked at
    steps                [{name, ok, detail}] of the clarify step
    technical_question   the question restated once the choice is known;
                         "" while the user must answer
    tables               anchor tables, confirmed against the catalogue
    anchor_source        where they came from (the corpus or a model)
    sub_schema           those plus whatever the graph had to add
    joins                the imposed join list, [] when there is no graph
    examples             verified questions and their SQL shown to the
                         generator
    sql                  the statement the specialist wrote
    verdict              why it was rejected, or "" when it passed
    attempts             how many generations have been spent
    columns, rows        what the database returned, read-only
    total_rows           how many rows the query matches, which is not
                         len(rows) once the ceiling bit; None unknown
    answer               the sentence the user reads
    error                set when a step could not run at all
"""

if __package__:
    from .pipeline import MAX_ATTEMPTS
else:
    from pipeline import MAX_ATTEMPTS


def nodes_for(datagora):
    """A dict of node name to callable(state) -> partial state."""
    pipe = datagora.pipeline

    def tell(state):
        # every node that reads the clarifier tells it again for its own
        # thread: a graph may run its nodes on another thread than the one
        # that ran clarify, and another question's context must never leak
        pipe.tell(state.get("context") or {}, state.get("earlier") or "")

    def clarify(state):
        """The pipeline's own first step: Pipeline.prepare then
        Pipeline.judge_stage, as Datagora.ask runs them."""
        question = state["question"]
        choice, suggestion = state.get("choice"), state.get("suggestion")
        run = pipe.prepare(question, choice, suggestion, state.get("context"),
                           state.get("earlier"))
        technical = pipe.judge_stage(run, question, choice, suggestion)
        c = run.clarification
        patch = {
            "context": run.context, "earlier": run.earlier,
            "clarification": None if c is None else {
                "action": c.action, "kind": c.kind, "reason": c.reason,
                "question": c.question, "phrase": c.phrase,
                "checked": c.checked, "empty": c.empty,
                "missing": getattr(c, "missing", "") or "",
                "gap": getattr(c, "gap", "") or "",
                "options": [{"label": o.label, "means": o.means} for o in c.options]},
            "clarifying": run.clarifying or "",
            "suggestions": list(run.suggestions or []),
            "judged_tables": list(run.judged_tables or []),
            "steps": [{"name": s.name, "ok": s.ok, "detail": s.detail} for s in run.steps],
            "technical_question": technical or ""}
        if run.failed:
            patch["error"] = run.failed
        return patch

    def anchors(state):
        tell(state)
        q = state.get("technical_question") or state["question"]
        # anchors returns (tables, source): the source says whether
        # the corpus or a model named them
        tables, source = pipe.anchors(q)
        if not tables:
            return {"error": "no table of this database matches the question"}
        # the pipeline's own subschema, which reconnects once to a graph
        # whose driver went stale rather than raising
        sub = pipe.subschema(tables)
        return {"tables": tables, "anchor_source": source, "sub_schema": sub,
                "joins": pipe.imposed_joins(sub), "examples": pipe.examples_for(q)}

    def generate(state):
        tell(state)
        q = state.get("technical_question") or state["question"]
        if __package__:
            from .pipeline import strip_sql
        else:
            from pipeline import strip_sql
        # the pipeline's own prompt (managed in Langfuse when it is), with
        # the examples and the context the clarifier was told
        raw = pipe.sql_llm.chat(
            pipe.sql_prompt.text, pipe.prompt_for_sql(
                q, state.get("sub_schema") or state.get("tables") or [],
                state.get("joins") or [], state.get("verdict") or None,
                examples=state.get("examples") or []))
        return {"sql": strip_sql(raw),
                "attempts": int(state.get("attempts", 0)) + 1,
                "verdict": ""}

    def check(state):
        sql = state.get("sql") or ""
        if not sql:
            return {"verdict": "You returned no SQL. Return the query only."}
        con = datagora.profile.connect_mysql()
        try:
            # (correction or None, the gates that ran)
            correction, _ran = pipe.check(sql, con)
            return {"verdict": correction or ""}
        finally:
            con.close()

    def execute(state):
        con = datagora.profile.connect_mysql()
        try:
            columns, rows, total = pipe.execute(state["sql"], con)
            return {"columns": columns, "rows": rows, "total_rows": total, "verdict": ""}
        except Exception as e:
            return {"verdict": f"MariaDB refused it: {str(e)[:200]}"}
        finally:
            con.close()

    def answer(state):
        tell(state)
        # the rows answer the technical question, which a choice made
        # precise, and `total_rows` is the count, not the fetch ceiling
        q = state.get("technical_question") or state["question"]
        try:
            said = pipe.say(q, state.get("columns") or [], state.get("rows") or [],
                            state.get("total_rows"))
        except RuntimeError as e:
            # a silent reasoner stays a failure, as in Pipeline.ask
            return {"error": f"the answer step failed: {e}"}
        # the corpus grows as Pipeline.ask grows it: rows a database
        # returned, tables a model (not the corpus) named, joins a graph
        # verified (without one the checks let any join through)
        if __package__:
            from .pipeline import remembers
        else:
            from pipeline import remembers
        if state.get("rows") and state.get("anchor_source") != "corpus" and remembers() \
                and pipe.has_graph:
            try:
                pipe.recall.remember(q, state.get("tables") or [], state.get("sql") or "")
            except Exception:
                pass
        return {"answer": said}

    return {"clarify": clarify, "anchors": anchors, "generate": generate,
            "check": check, "execute": execute, "answer": answer}


# ------------------------------------------------------------ the edges

def should_clarify(state):
    """After clarify: stop and put the question to the user, give up on an
    error, or carry on."""
    if state.get("error"):
        return "give_up"
    if not state.get("technical_question"):
        return "ask_user"
    return "continue"


def after_anchors(state):
    """After anchors: no table of the database matches, give up."""
    return "give_up" if state.get("error") else "continue"


def after_check(state):
    """After check: run it, write it again, or stop trying.

    A rejection is not a failure, it is the next attempt's instruction,
    which is why the verdict travels in the state and lands in the
    generator's prompt."""
    if not state.get("verdict"):
        return "run"
    if int(state.get("attempts", 0)) >= MAX_ATTEMPTS:
        return "give_up"
    return "retry"


def after_execute(state):
    """Execution can still be refused by the database; that is a verdict
    like any other and deserves the same retry."""
    if state.get("verdict"):
        return after_check(state)
    return "answer"
