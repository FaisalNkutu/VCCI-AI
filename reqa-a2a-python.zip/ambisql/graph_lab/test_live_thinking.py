"""A reply read as it is written, while a page follows a job or an Ask:
what the model thinks, then answers, handed on as it grows; the reply put
back together as if it had come whole. No model: a stand-in for urlopen
sends Ollama's chunks."""

import os

os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

import json
import pathlib
import sys
import threading
import unittest
from unittest.mock import patch

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import llm  # noqa: E402

ENDPOINT = {"api": "ollama", "url": "http://gpu:11434", "model": "gemma4:31b", "timeout": 600}

CHUNKS = [
    {"message": {"thinking": "The question asks for "}, "done": False},
    {"message": {"thinking": "a count per category."}, "done": False},
    {"message": {"content": "{\"verdict\": "}, "done": False},
    {"message": {"content": "\"ANSWERABLE\"}"}, "done": False},
    {"message": {"content": ""}, "done": True, "done_reason": "stop",
     "prompt_eval_count": 812, "eval_count": 9, "total_duration": 3_000_000_000},
]


class _Stream:
    """Ollama's reply with stream: true, one JSON object a line."""

    def __init__(self, chunks):
        self.lines = [(json.dumps(c) + "\n").encode() for c in chunks]

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def __iter__(self):
        return iter(self.lines)

    def read(self):
        return b"".join(self.lines)


def serve(chunks, sent):
    def urlopen(req, timeout=None):
        if req.full_url.endswith("/api/show"):
            return _Stream([{"capabilities": ["completion", "thinking"]}])
        if req.full_url.endswith("/api/ps"):
            return _Stream([{"models": []}])
        sent.append(json.loads(req.data))
        return _Stream(chunks)
    return patch("urllib.request.urlopen", urlopen)


class StreamTests(unittest.TestCase):
    def setUp(self):
        # what Ollama said a model can do is kept per server and model: left
        # behind, it would make the next tests' gemma4 think
        llm._THINKERS.clear()
        self.addCleanup(llm._THINKERS.clear)
        p = patch.object(llm.LLM, "PROGRESS_EVERY", 0.0)     # every chunk is said
        p.start()
        self.addCleanup(p.stop)

    def test_the_reply_is_read_as_written_and_put_back_together(self):
        model, heard, sent = llm.LLM("gpu", ENDPOINT), [], []
        model.on_progress = lambda phase, said: heard.append((phase, said))
        with serve(CHUNKS, sent):
            out = model.chat("system", "user")
        self.assertIs(sent[0]["stream"], True)
        self.assertEqual(out, '{"verdict": "ANSWERABLE"}')
        self.assertEqual(model.last_prompt_tokens, 812)
        self.assertEqual(model.last_server.get("reply_tokens"), 9)
        self.assertEqual(heard[0], ("thinking", "The question asks for "))
        self.assertIn(("thinking", "The question asks for a count per category."), heard)
        self.assertEqual(heard[-1], ("answering", '{"verdict": "ANSWERABLE"}'))

    def test_without_a_watcher_the_reply_comes_whole(self):
        model, sent = llm.LLM("gpu", ENDPOINT), []
        whole = {"message": {"content": "{}"}, "done": True, "done_reason": "stop"}
        with serve([whole], sent):
            self.assertEqual(model.chat("system", "user"), "{}")
        self.assertIs(sent[0]["stream"], False)

    def test_a_watcher_that_fails_never_fails_the_reply(self):
        model, sent = llm.LLM("gpu", ENDPOINT), []
        model.on_progress = lambda phase, said: 1 / 0
        with serve(CHUNKS, sent):
            self.assertEqual(model.chat("system", "user"), '{"verdict": "ANSWERABLE"}')

    def test_an_error_in_the_stream_is_no_reply(self):
        model, sent = llm.LLM("gpu", ENDPOINT), []
        model.on_progress = lambda phase, said: None
        with serve([{"error": "model runner has unexpectedly stopped"}], sent):
            self.assertIsNone(model.chat("system", "user"))
        self.assertIn("unexpectedly stopped", model.last_error)

    def test_an_ask_watches_the_calls_of_its_own_thread_only(self):
        model, heard, sent, other = llm.LLM("gpu", ENDPOINT), [], [], []
        with serve(CHUNKS, sent):
            with llm.watching(lambda phase, said: heard.append(phase)):
                model.chat("system", "user")
                # another request, on another thread, is not this Ask's
                t = threading.Thread(target=lambda: other.append(model.chat("system", "user")))
                t.start()
                t.join()
            model.chat("system", "user")
        self.assertEqual([s["stream"] for s in sent], [True, False, False])
        self.assertTrue(heard)


class JobTests(unittest.TestCase):
    def test_each_question_of_a_job_speaks_for_itself(self):
        import coverage
        heard = []

        class Clar:
            _llm = llm.LLM("gpu", ENDPOINT)

        with patch.object(coverage, "_judge_core",
                          lambda clar, text, extra, stop: clar._llm.on_progress("thinking", text)
                          or coverage.Verdict(question=text, verdict="ANSWERABLE")):
            coverage._judge_one(Clar(), "q7", {}, False, position=7,
                                on_thinking=lambda p, phase, said: heard.append((p, phase, said)))
        self.assertEqual(heard, [(7, "thinking", "q7")])


if __name__ == "__main__":
    unittest.main()
