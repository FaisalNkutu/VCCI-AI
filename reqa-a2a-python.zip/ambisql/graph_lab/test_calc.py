"""The agent's calculator and its two reasoning tools, compute and clock.
No model, no database."""

import os

os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

import datetime
import unittest
from types import SimpleNamespace

import calc
import verdict_agent
import verdict_notebook
import verdict_tools

TODAY = datetime.date(2026, 10, 23)


class CalcTests(unittest.TestCase):

    def test_dates_are_worked_out_from_the_question_s_day(self):
        ev = lambda e: calc.evaluate(e, today=TODAY)
        self.assertEqual(ev("today()"), TODAY)
        self.assertEqual(ev("add_months(today(), -3)"), datetime.date(2026, 7, 23))
        self.assertEqual(ev("add_months(date(2026, 3, 31), -1)"), datetime.date(2026, 2, 28))
        self.assertEqual(ev("today() - timedelta(days=90)"), datetime.date(2026, 7, 25))
        self.assertEqual(ev("year_start(today()).year - 1"), 2025)
        self.assertEqual(ev("days_between(date(2025, 1, 1), date(2025, 12, 31)) + 1"), 365)
        self.assertEqual(ev("quarter_start(today())"), datetime.date(2026, 10, 1))
        self.assertEqual(ev("round(17 / 40 * 100, 1)"), 42.5)

    def test_anything_else_is_refused(self):
        for expr in ("__import__('os')", "open('x')", "today().__class__",
                     "[x for x in range(3)]", "lambda: 1", "9 ** 99", "'a' * 1000000",
                     "[1] * 100000", "x = 1", "date(2026, 13, 1)", "1 / 0",
                     "1" * 400, "eval('1')", "str.join", "today().strftime('%Y')"):
            with self.subTest(expr=expr), self.assertRaises(calc.Refused):
                calc.evaluate(expr, today=TODAY)

    def test_what_would_cost_is_refused_quickly(self):
        # the independent review of 23 October: a tower of powers ran for
        # minutes, and str(0) * 10 ** 8 built 100 MB
        import time
        for expr in ("((((((9**12)**12)**12)**12)**12)**12) > 1", "round(10**12, -10**7)",
                     "len(str(0) * 10**8)", "len((\"a\" + \"\") * 10**8)",
                     "len(today().isoformat() * 10**7)", "len(\"%0100000000d\" % 1)",
                     "len(\"%.100000000f\" % 1.0)", "len(([0] + []) * 10**7)",
                     "str(1).replace(\"\", \"x\")", "10**12 * 10**12", "2 ** 100"):
            started = time.monotonic()
            with self.subTest(expr=expr), self.assertRaises(calc.Refused):
                calc.evaluate(expr, today=TODAY)
            self.assertLess(time.monotonic() - started, 0.5, expr)

    def test_a_date_s_own_methods_still_work(self):
        ev = lambda e: calc.evaluate(e, today=TODAY)
        self.assertEqual(ev("today().replace(day=1)"), datetime.date(2026, 10, 1))
        self.assertEqual(ev("today().isoformat()"), "2026-10-23")
        self.assertEqual(ev("(today() - date(2026, 1, 1)).days"), 295)
        self.assertEqual(ev("10 % 3"), 1)
        self.assertEqual(ev("2 ** 10"), 1024)
        now = datetime.datetime(2026, 10, 23, 9, 15)
        self.assertEqual(calc.evaluate("now().hour", today=TODAY, now=now), 9)

    def test_values_are_shown_plainly(self):
        self.assertEqual(calc.show(datetime.date(2025, 1, 1)), "2025-01-01")
        self.assertEqual(calc.show(datetime.timedelta(days=3)), "3 days")
        self.assertEqual(calc.show(1 / 3), "0.333333")


class Cursor:
    def __init__(self, rows):
        self.rows, self.sql = rows, []

    def execute(self, sql, *a):
        self.sql.append(sql)

    def fetchone(self):
        return self.rows


class ToolTests(unittest.TestCase):

    def box(self, now_row=(datetime.datetime(2026, 10, 23, 12, 0), "SYSTEM", "EDT")):
        tools = verdict_tools.ToolBox.__new__(verdict_tools.ToolBox)
        cur = Cursor(now_row)
        tools.clar = SimpleNamespace(today=TODAY, context="Asked on Friday 23 October 2026.",
                                     MOMENTS=("date", "datetime"))
        tools.settings = verdict_tools.Settings()
        # the timer the sweeps use, as __init__ sets it: the clock tool must
        # not be hidden by it (23 October, every clock call failed)
        import time
        tools.clock = time.monotonic
        tools.view = SimpleNamespace(
            table=lambda t: "orders" if t == "orders" else None,
            columns_of=lambda t: [("order_id", "int"), ("order_date", "date")])
        tools._moments_read = lambda t, m: {"order_date": ("2023-01-02", "2026-09-30")}

        class Lent:
            def __enter__(self_):
                return SimpleNamespace(cursor=lambda: cur)

            def __exit__(self_, *a):
                return False
        tools._bounded = lambda seconds: Lent()
        return tools, cur

    def test_compute_reads_today_from_the_question(self):
        tools, _ = self.box()
        r = tools.run("compute", {"expression": "add_months(today(), -12)"})
        self.assertTrue(r.ok)
        self.assertEqual(r.data["value"], "2025-10-23")
        bad = tools.run("compute", {"expression": "__import__('os')"})
        self.assertFalse(bad.ok)

    def test_clock_gives_the_asker_s_day_the_database_s_clock_and_the_latest_dates(self):
        tools, cur = self.box()
        r = tools.run("clock", {"table": "orders"})
        self.assertTrue(r.ok)
        self.assertEqual(r.data["today"], "2026-10-23")
        self.assertEqual(r.data["database_time_zone"], "SYSTEM")
        self.assertEqual(r.data["latest"], [{"column": "order_date", "latest": "2026-09-30"}])
        self.assertIn("NOW()", cur.sql[0])
        self.assertFalse(tools.run("clock", {"table": "nope"}).ok)

    def test_the_agent_may_call_both(self):
        self.assertIn("compute", verdict_agent.AGENT_TOOLS)
        self.assertIn("clock", verdict_agent.AGENT_TOOLS)
        self.assertIn("unknowns", verdict_agent.TURN_SCHEMA["properties"])
        self.assertNotIn("unknowns", verdict_agent.TURN_SCHEMA["required"])

    def test_what_it_does_not_know_is_shown_back_to_it(self):
        nb = verdict_notebook.Notebook("What was our revenue last year?")
        nb.apply_reply({"plan": [{"do": "find revenue", "status": "todo"}],
                        "unknowns": [{"what": "the dates of last year", "how": "compute"}]})
        text = "\n".join(verdict_notebook.Budget._plan(nb, True, False))
        self.assertIn("WHAT YOU DO NOT KNOW YET", text)
        self.assertIn("- the dates of last year (by compute)", text)


if __name__ == "__main__":
    unittest.main()
