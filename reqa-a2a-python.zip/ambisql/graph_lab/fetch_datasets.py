"""Fetch the public corpora the clarifier is evaluated against.

Reports by default and downloads only when asked, because one of these
is 763 MB and nobody should discover that after the fact.

What each one is for, which matters because they are easy to confuse:

  bird-minidev   The subset AmbiSQL itself evaluates on. Questions with
                 gold SQL over real schemas, which is what the branch
                 protocol needs: follow every option the clarifier
                 offers, execute each, and a branch counts as right when
                 its result matches the gold. The gold is what makes the
                 A/B automatic.

  tag-bench      NOT an ambiguity corpus, and using it as one would
                 measure nothing. Its questions are unambiguous; they
                 are simply beyond plain SQL, needing reasoning or world
                 knowledge. It belongs to the `non-sql` cause of the
                 unanswerability taxonomy, a different branch of the
                 policy, and it is the right corpus for the TAG node.

  ambisql        The reference implementation, for its prompts, its
                 taxonomy and its .claude/skills/ambisql. Read rather
                 than run: our clarifier grounds its options against the
                 live schema, which theirs does not do.

    .venv/Scripts/python src/graph_lab/fetch_datasets.py
    .venv/Scripts/python src/graph_lab/fetch_datasets.py --get tag-bench
"""

import argparse
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data" / "corpora"

SOURCES = {
    "bird-minidev": {
        "url": "https://bird-bench.oss-cn-beijing.aliyuncs.com/minidev.zip",
        "use": "ambiguity A/B with gold SQL, the branch protocol",
        "note": "large; the databases come with it",
    },
    "tag-bench": {
        "url": "https://codeload.github.com/TAG-Research/TAG-Bench/"
               "zip/refs/heads/main",
        "use": "questions beyond plain SQL, for the TAG node, NOT ambiguity",
        "note": "",
    },
    "ambisql": {
        "url": "https://codeload.github.com/JustinzjDing/AmbiSQL/"
               "zip/refs/heads/main",
        "use": "reference prompts, taxonomy and their Claude skill",
        "note": "read it, do not run it in the pipeline",
    },
}


def head(url, timeout=25):
    req = urllib.request.Request(url, method="HEAD")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            size = r.headers.get("Content-Length")
            return r.status, int(size) if size else None
    except (urllib.error.URLError, TimeoutError, OSError):
        return None, None


def human(n):
    if n is None:
        return "unknown size"
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


def report():
    print(f"target directory: {DATA}\n")
    for name, src in SOURCES.items():
        status, size = head(src["url"])
        here = DATA / name
        state = "already here" if here.exists() else "not downloaded"
        mark = "reachable" if status else "UNREACHABLE"
        print(f"  {name:14} {mark:12} {human(size):>12}   {state}")
        print(f"                 {src['use']}")
        if src["note"]:
            print(f"                 ({src['note']})")
    print("\n  download one with:  --get <name>")


def fetch(name):
    src = SOURCES[name]
    DATA.mkdir(parents=True, exist_ok=True)
    archive = DATA / f"{name}.zip"
    status, size = head(src["url"])
    if not status:
        raise SystemExit(f"{name} is unreachable at {src['url']}")
    print(f"{name}: {human(size)} from {src['url']}")

    seen = [0]

    def progress(blocks, block_size, total):
        seen[0] = blocks * block_size
        if total > 0 and blocks % 200 == 0:
            print(f"\r  {human(seen[0])} / {human(total)}", end="", flush=True)

    urllib.request.urlretrieve(src["url"], archive, reporthook=progress)
    print(f"\r  downloaded {human(archive.stat().st_size)}          ")

    target = DATA / name
    target.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        z.extractall(target)
    archive.unlink()
    files = sum(1 for _ in target.rglob("*") if _.is_file())
    print(f"  extracted {files} files into {target}")
    print(f"  use: {src['use']}")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--get", choices=sorted(SOURCES),
                    help="download and extract one corpus")
    args = ap.parse_args()
    if args.get:
        fetch(args.get)
    else:
        report()


if __name__ == "__main__":
    main()
