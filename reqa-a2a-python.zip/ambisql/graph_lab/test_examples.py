"""The verified examples Ask shows its SQL generator (recall.Recall.examples
and pipeline.Pipeline.prompt_for_sql). No Qdrant, no model."""

import os
import tempfile

os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"
os.environ["DATAGORA_DATA_DIR"] = tempfile.mkdtemp(prefix="datagora-tests-")

import unittest
from types import SimpleNamespace
from unittest.mock import patch

import recall


def corpus(*points):
    r = recall.Recall("", "c", "")
    r.neighbours = lambda question, limit=3: list(points)[:limit]
    return r


def point(score, question, sql, source="dictionary"):
    return (score, {"question": question, "sql": sql, "source": source, "tables": ["t"]})


class ExampleTests(unittest.TestCase):

    def test_the_closest_verified_pairs_with_sql(self):
        r = corpus(point(0.9, "How many orders in 2025?", "SELECT COUNT(*) FROM orders WHERE y = 2025"),
                   point(0.8, "Orders per customer?", "SELECT c, COUNT(*) FROM orders GROUP BY c"),
                   point(0.7, "Top products?", "SELECT p FROM lines GROUP BY p ORDER BY 2 DESC"))
        out = r.examples("How many orders in 2024?", k=2)
        self.assertEqual([e["question"] for e in out],
                         ["How many orders in 2025?", "Orders per customer?"])
        self.assertEqual(out[0]["source"], "dictionary")

    def test_sql_a_model_wrote_is_no_example(self):
        r = corpus(point(0.95, "Q1", "SELECT 1 FROM a", source="asked"),
                   point(0.80, "Q2", "SELECT 2 FROM b"))
        self.assertEqual([e["question"] for e in r.examples("q", k=3)], ["Q2"])

    def test_two_of_the_same_shape_teach_one_thing(self):
        r = corpus(point(0.9, "Orders in 2025?", "SELECT * FROM o WHERE y = 2025"),
                   point(0.8, "Orders in 2024?", "SELECT * FROM o WHERE y = 2024"),
                   point(0.7, "Orders in Paris?", "SELECT * FROM o WHERE city = 'Paris'"))
        out = r.examples("q", k=3)
        self.assertEqual([e["question"] for e in out], ["Orders in 2025?", "Orders in Paris?"])

    def test_the_question_itself_is_never_its_own_example(self):
        r = corpus(point(0.99, "How many orders?", "SELECT COUNT(*) FROM o"),
                   point(0.70, "Orders per day?", "SELECT d, COUNT(*) FROM o GROUP BY d"))
        self.assertEqual([e["question"] for e in r.examples("how many  orders?", k=2)],
                         ["Orders per day?"])

    def test_the_question_however_punctuated_is_never_its_own_example(self):
        r = corpus(point(0.99, "How many orders?!", "SELECT COUNT(*) FROM o"),
                   point(0.70, "Orders per day?", "SELECT d, COUNT(*) FROM o GROUP BY d"))
        self.assertEqual([e["question"] for e in r.examples("how many orders", k=2)],
                         ["Orders per day?"])

    def test_an_evaluation_denies_its_questions_and_their_sql(self):
        import json
        r = corpus(point(0.95, "How many Book records are there?", "SELECT COUNT(*) FROM books"),
                   point(0.90, "Books per genre?", "SELECT g, COUNT(*) FROM books GROUP BY g"),
                   point(0.80, "How many authors are there?", "SELECT COUNT(*) FROM authors"))
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "deny.json")
            with open(path, "w", encoding="utf-8") as fh:
                json.dump({"questions": ["Books per genre?"],
                           "sql": ["select count(*) from books"]}, fh)
            with patch.dict("os.environ", {"DATAGORA_EXAMPLES_DENY": path}):
                got = [e["question"] for e in r.examples("How many books are there?", k=3)]
        # the same SQL as the measured question, and a measured question, are out
        self.assertEqual(got, ["How many authors are there?"])

    def test_pairs_without_sql_are_skipped(self):
        r = corpus((0.9, {"question": "Q", "tables": ["t"], "source": "dictionary"}))
        self.assertEqual(r.examples("q", k=3), [])

    def test_settings_from_the_environment(self):
        with patch.dict("os.environ", {"DATAGORA_EXAMPLES": "0"}):
            self.assertEqual(corpus(point(0.9, "Q", "SELECT 1")).examples("q"), [])
        with patch.dict("os.environ", {"DATAGORA_EXAMPLES": "9",
                                       "DATAGORA_EXAMPLES_SOURCES": "asked, none"}):
            k, sources = recall.example_settings()
            self.assertEqual(k, 5)
            self.assertEqual(sources, ("asked", ""))

    def test_the_shape_ignores_literals_and_spacing(self):
        self.assertEqual(recall.sql_shape("SELECT a FROM t WHERE x = 'it''s'  AND y=3"),
                         recall.sql_shape("select a from t where x = 'b' and y=42"))

    def test_what_ask_remembers_is_marked_unverified(self):
        r = recall.Recall("", "c", "")
        sent = []
        r.client  # noqa: B018  (no url: no client)
        r._client, r._checked = object(), True
        r.seed = lambda pairs, source=None: sent.append((pairs, source)) or 1
        self.assertTrue(r.remember("q", ["t"], "SELECT 1"))
        pairs, source = sent[0]
        self.assertEqual(source, "asked")
        self.assertIs(pairs[0]["verified"], False)

    def test_ask_keeps_the_tables_its_sql_reads_and_says_its_point(self):
        # review of 26 October: the tables offered were kept, all of them
        r = recall.Recall("", "c", "")
        sent = []
        r._client, r._checked = object(), True
        r.seed = lambda pairs, source=None: sent.append(pairs) or 1
        got = r.remember("How many loans per member?", ["loans", "members", "books", "authors"],
                         "SELECT m.name, COUNT(*) FROM loans l JOIN members m "
                         "ON m.member_id = l.member_id GROUP BY m.name")
        self.assertEqual(got, recall.Recall.point_id("How many loans per member?"))
        self.assertEqual(sorted(sent[0][0]["tables"]), ["loans", "members"])
        r.seed = lambda pairs, source=None: 0
        self.assertEqual(r.remember("q", ["t"], "SELECT 1"), "")

    def test_only_what_ask_wrote_with_that_sql_is_forgotten(self):
        r = recall.Recall("", "c", "")
        ids = {n: recall.Recall.point_id(n) for n in ("mine", "dictionary", "asked again", "absent")}
        stored = {ids["mine"]: {"source": "asked", "sql": "SELECT 1"},
                  ids["dictionary"]: {"source": "dictionary", "sql": "SELECT 2"},
                  ids["asked again"]: {"source": "asked", "sql": "SELECT other"}}
        deleted = []

        class Client:
            def retrieve(self, collection, ids, with_payload, with_vectors):
                return [SimpleNamespace(id=i, payload=stored[i]) for i in ids if i in stored]

            def delete(self, collection, points_selector):
                deleted.extend(points_selector.points)
        r._client, r._checked = Client(), True
        n = r.forget([(ids["mine"], "SELECT 1"), (ids["dictionary"], "SELECT 2"),
                      (ids["asked again"], "SELECT 3"), (ids["absent"], "SELECT 4")])
        self.assertEqual((n, deleted), (1, [ids["mine"]]))
        self.assertEqual(recall.Recall("", "c", "").forget([(ids["mine"], "SELECT 1")]), 0)


class PromptTests(unittest.TestCase):

    def pipe(self):
        import pipeline
        p = pipeline.Pipeline.__new__(pipeline.Pipeline)
        p.clarifier = SimpleNamespace(columns={"orders": [("id", "int"), ("y", "int")]})
        return p

    def test_the_examples_are_in_the_prompt_before_the_question(self):
        text = self.pipe().prompt_for_sql(
            "How many orders in 2024?", ["orders"], [],
            examples=[{"question": "How many orders in 2025?",
                       "sql": "SELECT COUNT(*) FROM orders WHERE y = 2025"}])
        self.assertIn("Q: How many orders in 2025?", text)
        self.assertLess(text.index("SQL: SELECT COUNT(*)"), text.index("Question: How many orders in 2024?"))

    def test_no_example_no_section(self):
        text = self.pipe().prompt_for_sql("How many orders?", ["orders"], [])
        self.assertNotIn("Examples of questions", text)

    def test_a_failing_corpus_never_stops_a_question(self):
        p = self.pipe()

        class Broken:
            def examples(self, q):
                raise RuntimeError("qdrant down")
        p.__dict__["_recall"] = Broken()
        with patch.object(type(p), "recall", property(lambda self: self._recall), create=True):
            self.assertEqual(p.examples_for("q"), [])


if __name__ == "__main__":
    unittest.main()
