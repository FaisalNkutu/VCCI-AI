"""The coverage bench scripts (docs/test_strategy/coverage_bench), offline.

compare_runs.py and trace_check.py are pure Python and checked here on
hand-made runs and on the synthetic trace fixtures; the live scripts are
checked only for what needs no database and no model: their --help, the
judge argument, the prompt sources and the --local rewrite.

    .venv/Scripts/python src/graph_lab/test_bench_scripts.py
"""

import csv
import io
import os
import subprocess
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path

os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

HERE = Path(__file__).resolve().parent
BENCH = HERE.parents[1] / "docs" / "test_strategy" / "coverage_bench"
FIXTURES = BENCH / "fixtures"
if str(BENCH) not in sys.path:
    sys.path.append(str(BENCH))

import bench_common as bc  # noqa: E402
import compare_runs  # noqa: E402
import judge_sample  # noqa: E402
import prompt_ab  # noqa: E402
import stats  # noqa: E402
import trace_check  # noqa: E402

SCRIPTS = ["compare_runs", "trace_check", "cut_check", "replay_ground",
           "judge_sample", "prompt_ab"]


def write_csv(path, fields, rows):
    with open(path, "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


class StatisticsTests(unittest.TestCase):
    def test_wilson_at_thirty_of_forty_is_sixty_to_eighty_six(self):
        low, high = stats.wilson(30, 40)
        self.assertAlmostEqual(low, 0.5980, places=3)
        self.assertAlmostEqual(high, 0.8580, places=3)

    def test_wilson_bounds(self):
        self.assertEqual(stats.wilson(0, 10)[0], 0.0)
        self.assertAlmostEqual(stats.wilson(10, 10)[1], 1.0)
        self.assertEqual(stats.wilson(0, 0), (0.0, 1.0))
        low, high = stats.wilson(1, 1)
        self.assertAlmostEqual(low, 0.2065, places=3)

    def test_mcnemar_exact(self):
        self.assertEqual(stats.mcnemar_exact(0, 0), 1.0)
        self.assertEqual(stats.mcnemar_exact(3, 3), 1.0)
        self.assertAlmostEqual(stats.mcnemar_exact(0, 5), 0.0625)
        self.assertAlmostEqual(stats.mcnemar_exact(0, 6), 0.03125)
        # n = 10, k = 1: 2 * (1 + 10) / 1024
        self.assertAlmostEqual(stats.mcnemar_exact(1, 9), 22 / 1024)
        self.assertEqual(stats.mcnemar_exact(9, 1), stats.mcnemar_exact(1, 9))


class CompareRunsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="bench-compare-"))
        self.key = self.tmp / "key.csv"
        write_csv(self.key, ["id", "question", "difficulty", "expected", "also_accepted", "theme"], [
            {"id": "Q1", "question": "How many books?", "difficulty": "simple",
             "expected": "ANSWERABLE", "also_accepted": "", "theme": "t"},
            {"id": "Q2", "question": "Which books are cheap?", "difficulty": "simple",
             "expected": "NEEDS MORE", "also_accepted": "", "theme": "t"},
            {"id": "Q3", "question": "Most expensive products?", "difficulty": "medium",
             "expected": "NEEDS A CHOICE", "also_accepted": "ANSWERABLE", "theme": "t"},
            {"id": "Q4", "question": "Loans per member?", "difficulty": "complex",
             "expected": "ANSWERABLE", "also_accepted": "", "theme": "t"},
        ])
        fields = ["id", "question", "verdict", "kind", "answer_to_give", "choices"]
        self.run1 = self.tmp / "run1.csv"
        write_csv(self.run1, fields, [
            {"id": "Q1", "question": "How many books?", "verdict": "ANSWERABLE"},
            {"id": "Q2", "question": "Which books are cheap?", "verdict": "NEEDS A CHOICE"},
            {"id": "Q3", "question": "Most expensive products?", "verdict": "ANSWERABLE"},
            {"id": "Q4", "question": "Loans per member?", "verdict": "ANSWERABLE"},
        ])
        # no id column: matched on the question text, case and spaces aside
        self.run2 = self.tmp / "run2.csv"
        write_csv(self.run2, ["question", "verdict"], [
            {"question": "how many  books?", "verdict": "ANSWERABLE"},
            {"question": "Which books are cheap?", "verdict": "NEEDS MORE"},
            {"question": "Most expensive products?", "verdict": "NEEDS A CHOICE"},
            {"question": "Loans per member?", "verdict": "NOT COVERED"},
            {"question": "A question not in the key", "verdict": "ANSWERABLE"},
        ])

    def test_scores_on_expected_or_also_accepted(self):
        rep = compare_runs.report(self.key, [self.run1, self.run2])
        r1, r2 = rep["runs"]
        self.assertEqual((r1["right"], r1["scored"]), (3, 4))
        self.assertEqual(r1["wrong_ids"], ["Q2"])
        self.assertEqual(r1["by_difficulty"]["simple"], {"right": 1, "total": 2})
        self.assertEqual(list(r1["by_difficulty"]), ["simple", "medium", "complex"])
        self.assertEqual((r2["right"], r2["wrong_ids"]), (3, ["Q4"]))
        self.assertEqual(r2["unmatched_rows"], 1)
        self.assertEqual(r2["missing_ids"], [])

    def test_changes_between_two_runs(self):
        pair = compare_runs.report(self.key, [self.run1, self.run2])["pairs"][0]
        self.assertEqual(pair["fixed"], ["Q2"])
        self.assertEqual(pair["broke"], ["Q4"])
        self.assertEqual(pair["still_wrong"], [])
        # Q3 changed verdict but was accepted both times
        self.assertEqual(pair["unchanged"], ["Q1", "Q3"])
        self.assertEqual(pair["verdict_changed"], ["Q2", "Q3", "Q4"])
        self.assertEqual(pair["stability"]["identical"], 1)
        self.assertEqual(pair["mcnemar"], {"b_broke": 1, "c_fixed": 1, "p": 1.0})

    def test_review_of_the_fixes_the_gates_still_fail(self):
        # eval_ask's RIGHT and WRONG are judged results; a question right
        # before and UNKNOWN now is lost, a regression
        import report
        key = {"q1": {"id": "q1", "question": "a", "expected": "RIGHT", "also_accepted": [],
                      "difficulty": ""},
               "q2": {"id": "q2", "question": "b", "expected": "RIGHT", "also_accepted": [],
                      "difficulty": ""}}
        c = report.comparison(key, {"q1": "RIGHT", "q2": "WRONG"}, {"q1": "WRONG", "q2": "RIGHT"},
                              "before", "after", judged=lambda v: v in ("RIGHT", "WRONG"))
        self.assertEqual((c["broke"], c["fixed"]), (["q1"], ["q2"]))
        questions = bc.read_questions(self.key)
        pair = compare_runs.compare(questions, {"Q1": "ANSWERABLE"}, {"Q1": "UNKNOWN"})
        self.assertEqual(pair["lost"], ["Q1"])
        # an UNKNOWN is no false alarm
        s = report.summary(questions, [{"id": "Q1", "got": "UNKNOWN", "expected": "ANSWERABLE",
                                        "right": False}], "p", "agent", [])
        self.assertEqual((s["false_alarms"]["ids"], s["unjudged_ids"][:1]), ([], ["Q1"]))

    def test_a_missing_row_or_an_unknown_is_left_out_of_the_score(self):
        # review of 26 October: the pages leave them out, the bench counted
        # them wrong, and a run with 21 UNKNOWN read as a regression
        run = self.tmp / "short.csv"
        write_csv(run, ["id", "question", "verdict"],
                  [{"id": "Q1", "question": "How many books?", "verdict": "ANSWERABLE"},
                   {"id": "Q2", "question": "Which books are cheap?", "verdict": "UNKNOWN"}])
        r = compare_runs.report(self.key, [run])["runs"][0]
        self.assertEqual((r["right"], r["scored"]), (1, 1))
        self.assertEqual(r["missing_ids"], ["Q3", "Q4"])
        self.assertEqual(r["unjudged_ids"], ["Q2", "Q3", "Q4"])
        # an UNKNOWN after a right verdict is no break
        pair = compare_runs.report(self.key, [self.run1, run])["pairs"][0]
        self.assertEqual((pair["broke"], pair["fixed"]), ([], []))
        self.assertEqual(pair["unjudged"], ["Q2"])

    def test_markdown_and_json_outputs(self):
        md_out, json_out = self.tmp / "out.md", self.tmp / "out.json"
        with redirect_stdout(io.StringIO()) as printed:
            compare_runs.main([str(self.key), str(self.run1), str(self.run2),
                               "--md", str(md_out), "--json", str(json_out)])
        md = md_out.read_text(encoding="utf-8")
        self.assertIn("| `run1` | 3/4 |", md)
        self.assertIn("McNemar exact bilatéral", md)
        self.assertIn("Corrigées (FIXED) | 1 | Q2", md)
        self.assertNotIn("—", md)
        self.assertEqual(printed.getvalue().strip(), md.strip())
        self.assertIn('"wilson95"', json_out.read_text(encoding="utf-8"))


class TraceCheckTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.agent = trace_check.check(FIXTURES / "trace_agent.jsonl", FIXTURES / "questions.json")
        cls.single = trace_check.check(FIXTURES / "trace_single.jsonl", FIXTURES / "questions.json")

    def row(self, rep, qid):
        return next(r for r in rep["per_question"] if r["id"] == qid)

    def test_agent_tables_reached_by_description_path_and_sql(self):
        e27 = self.row(self.agent, "E27")
        self.assertEqual(e27["missing"], [])
        self.assertEqual(e27["reached_by"]["goods_receipts"], ["counted"])
        self.assertEqual(e27["reached_by"]["purchase_order_lines"], ["counted", "described", "joined"])
        self.assertEqual(e27["reached_by"]["material_shortages"], ["described", "joined"])
        self.assertEqual(self.row(self.agent, "E16")["missing"], ["products"])
        self.assertEqual(self.row(self.agent, "E16")["described_not_needed"], ["purchase_order_lines"])

    def test_agent_counts(self):
        e27, e34 = self.row(self.agent, "E27"), self.row(self.agent, "E34")
        # ten entries: five model calls, five tools, two of them asked for
        self.assertEqual((e27["turns"], e27["model_calls"], e27["malformed"]), (10, 5, 1))
        self.assertEqual(e27["tools"]["describe_tables"], 2)
        self.assertEqual((e34["overflows"], e34["coercions"], e34["feedback"]), (1, 1, 1))
        self.assertEqual(e34["coerced"], ["choice -> dropped"])
        self.assertTrue(e34["declared_differs"])
        self.assertEqual(e34["prompt_tokens"], 15890 + 5300 + 8020 + 8410 + 8600)

    def test_the_agent_record_as_verdict_agent_writes_it(self):
        # contract 2: caps in settings.max_turns and max_seconds, feedback
        # rounds an int, coercions a list; verifier statuses count neither
        model = {"phase": "exploring", "think": True, "tool": None, "prompt_tokens": 10}
        tool = {"n": 1, "phase": "exploring", "tool": "run_count",
                "args": {"sql": "SELECT COUNT(*) FROM x"}, "digest": "3", "error": None}
        line = {"mode": "agent", "turns": [model, tool, model, tool, model],
                "settings": {"max_turns": 2, "max_seconds": 30}, "seconds": 31,
                "verifier": [{"check": "choice", "status": "failed", "detail": ""},
                             {"check": "absent", "status": "absent", "detail": ""}],
                "feedback_rounds": 2,
                "coercions": [{"from": "choice", "to": "asker_must_say", "why": "w"},
                              {"from": "no_matching_row", "to": "dropped", "why": "w"}]}
        r = trace_check.check_agent(line, ["x"])
        self.assertEqual((r["turns"], r["model_calls"], r["reached"]), (5, 3, ["x"]))
        self.assertEqual((r["over_turn_cap"], r["over_time_cap"]), (True, True))
        self.assertEqual((r["feedback"], r["coercions"]), (2, 2))
        self.assertEqual(r["coerced"], ["choice -> asker_must_say", "no_matching_row -> dropped"])
        # the settings page's names, when a trace carries those
        old = dict(line, settings={"agent_max_turns": 3, "agent_max_seconds": 40})
        r = trace_check.check_agent(old, ["x"])
        self.assertEqual((r["over_turn_cap"], r["over_time_cap"]), (False, False))
        # no caps written: the defaults, 8 turns and 600 seconds
        r = trace_check.check_agent(dict(line, settings={}), ["x"])
        self.assertEqual((r["over_turn_cap"], r["over_time_cap"]), (False, False))
        # the short questions on the side are no turns (review of 26
        # October: a question within its cap was said over it), with a
        # kind or, written before kind, by their phase
        side = [{"kind": "wording", "phase": "wording", "tool": None, "error": "timed out"},
                {"phase": "values", "tool": None}]
        two = dict(line, turns=[dict(model, kind="turn"), tool, dict(model, kind="turn")] + side,
                   settings={"max_turns": 2, "max_seconds": 60})
        r = trace_check.check_agent(two, ["x"])
        self.assertEqual((r["model_calls"], r["side_calls"], r["over_turn_cap"]), (2, 2, False))
        self.assertEqual((r["malformed"], r["tool_errors"]), (0, 0))

    def test_agent_summary(self):
        s = self.agent["summary"]
        self.assertEqual(self.agent["lines_replaced"], 1)
        self.assertEqual((s["complete"], s["with_needed_tables"]), (3, 4))
        self.assertEqual((s["needed_reached"], s["needed_total"]), (14, 15))
        self.assertEqual(s["over_time_cap"], ["E16"])
        self.assertEqual(s["over_turn_cap"], [])
        self.assertEqual(s["declared_differs"], ["E16", "E34"])
        self.assertEqual(s["tools"]["search_tables"], 4)
        self.assertEqual(s["stopped_by"], {"concluded": 3, "time_cap": 1})
        self.assertEqual(s["right"], 4)
        self.assertEqual((s["feedback"], s["coercions"]), (1, 2))
        self.assertEqual(s["coerced"], {"choice -> dropped": 2})

    def test_single_mode(self):
        self.assertEqual(self.row(self.single, "E27")["missing"], ["goods_receipt_lines"])
        e34 = self.row(self.single, "E34")
        self.assertEqual((e34["overflows"], e34["malformed"]), (1, 0))
        self.assertTrue(e34["schema_unknown"])
        self.assertEqual(self.row(self.single, "E16")["malformed"], 1)
        s = self.single["summary"]
        self.assertEqual(s["modes"], {"single": 4})
        self.assertEqual(s["incomplete_ids"], ["E27", "E34"])
        self.assertEqual(s["right"], 1)

    def test_whole_schema_reaches_every_table(self):
        line = {"reply": {"ambiguous": False}, "tables_shown": None}
        r = trace_check.check_single(line, ["a", "b"])
        self.assertEqual((r["reached"], r["whole_schema"]), (["a", "b"], True))

    def test_join_path_not_found_reaches_nothing(self):
        line = {"mode": "agent", "turns": [
            {"n": 1, "phase": "exploring", "tool": "join_path", "args": {"a": "x", "b": "y"},
             "digest": "no path between x and y within 5 hops", "prompt_tokens": 10}]}
        self.assertEqual(trace_check.check_agent(line, ["x", "y"])["reached"], [])

    def test_sql_tables(self):
        sql = ("SELECT * FROM `shop`.`orders` o JOIN order_lines l ON l.id = o.id "
               "LEFT JOIN (SELECT 1 FROM hidden) h ON 1=1")
        self.assertEqual(trace_check.sql_tables(sql), {"orders", "order_lines", "hidden"})

    def test_markdown(self):
        md = trace_check.to_markdown(self.agent)
        self.assertIn("| E16 | agent | ANSWERABLE ok | ANSWERABLE | 2/3 | products |", md)
        self.assertIn("1 tours de retour, 2 coercitions (choice -> dropped 2)", md)
        self.assertNotIn("—", md)


class CommonTests(unittest.TestCase):
    def test_local_url_keeps_port_user_and_path(self):
        self.assertEqual(bc.local_url("bolt://neo4j:7687"), "bolt://127.0.0.1:7687")
        self.assertEqual(bc.local_url("http://u:p@host.docker.internal:11434/api"),
                         "http://u:p@127.0.0.1:11434/api")
        self.assertIsNone(bc.local_url(None))

    def test_localised_profile(self):
        from db_profile import DbProfile
        p = DbProfile(name="x", mysql={"host": "mariadb", "port": 3307, "database": "d"},
                      neo4j_uri="bolt://neo4j:7687", qdrant_url="http://qdrant:6333",
                      ollama_url="http://host.docker.internal:11434")
        q = bc.localised(p)
        self.assertEqual(q.mysql, {"host": "127.0.0.1", "port": 3307, "database": "d"})
        self.assertEqual((q.neo4j_uri, q.qdrant_url, q.ollama_url),
                         ("bolt://127.0.0.1:7687", "http://127.0.0.1:6333", "http://127.0.0.1:11434"))
        self.assertEqual(p.mysql["host"], "mariadb")

    def test_read_questions_shapes(self):
        q = bc.read_questions(FIXTURES / "questions.json")
        self.assertEqual(list(q), ["E01", "E16", "E27", "E34"])
        self.assertEqual(q["E34"]["needed_tables"], ["exchange_rates", "purchase_orders"])
        tmp = Path(tempfile.mkdtemp(prefix="bench-key-"))
        write_csv(tmp / "k.csv", ["id", "question", "expected", "also_accepted"],
                  [{"id": "E37", "question": "q", "expected": "needs a choice",
                    "also_accepted": "ANSWERABLE | NEEDS MORE"}])
        k = bc.read_questions(tmp / "k.csv")["E37"]
        self.assertEqual(k["expected"], "NEEDS A CHOICE")
        self.assertEqual(k["also_accepted"], ["ANSWERABLE", "NEEDS MORE"])
        self.assertTrue(bc.is_right(k, "answerable"))
        self.assertFalse(bc.is_right(k, ""))

    def test_select_ids_refuses_an_unknown_id(self):
        q = bc.read_questions(FIXTURES / "questions.json")
        self.assertEqual([x["id"] for x in bc.select_ids(q, "E27, E01")], ["E27", "E01"])
        with self.assertRaises(SystemExit):
            bc.select_ids(q, "E99")


class LiveScriptsOfflineTests(unittest.TestCase):
    def test_every_script_has_help_without_graph_lab(self):
        for name in SCRIPTS:
            with self.subTest(script=name):
                done = subprocess.run([sys.executable, str(BENCH / f"{name}.py"), "--help"],
                                      capture_output=True, text=True, encoding="utf-8",
                                      cwd=tempfile.gettempdir(), timeout=60)
                self.assertEqual(done.returncode, 0, done.stderr)
                self.assertIn("usage:", done.stdout)

    def test_live_scripts_take_the_runtime_options(self):
        for name in ("cut_check", "replay_ground", "judge_sample", "prompt_ab"):
            text = (BENCH / f"{name}.py").read_text(encoding="utf-8")
            with self.subTest(script=name):
                self.assertIn("bc.add_runtime_options(ap)", text)
                self.assertIn("bc.prepare(args)", text)

    def test_no_absolute_path_in_the_scripts(self):
        # the Ask scripts too (review of 26 October: they were skipped)
        for path in list(BENCH.glob("*.py")) + list((BENCH.parent / "ask_reformulate").glob("*.py")):
            text = path.read_text(encoding="utf-8")
            with self.subTest(script=path.name):
                self.assertNotRegex(text, r"[A-Za-z]:[\\/]+Users")
                self.assertNotIn("192.168.", text)

    def test_judge_passed_only_when_assess_takes_it(self):
        def with_judge(questions, *, judge=None):
            return []

        def without(questions, *, think=None):
            return []

        self.assertEqual(judge_sample.judge_argument(with_judge, "agent"),
                         ({"judge": "agent"}, "agent", ""))
        kwargs, mode, note = judge_sample.judge_argument(without, "agent")
        self.assertEqual((kwargs, mode), ({}, "single"))
        self.assertIn("no judge parameter", note)
        self.assertEqual(judge_sample.judge_argument(without, None), ({}, "single", ""))

    def test_prompt_sources_from_files(self):
        tmp = Path(tempfile.mkdtemp(prefix="bench-prompt-"))
        (tmp / "draft.py").write_text('DETECT_SYSTEM = "draft prompt"\n', encoding="utf-8")
        (tmp / "plain.txt").write_text("plain prompt", encoding="utf-8")
        self.assertEqual(prompt_ab.load_prompt(f"file:{tmp / 'draft.py'}", "DETECT_SYSTEM", HERE, "")[0],
                         "draft prompt")
        self.assertEqual(prompt_ab.load_prompt(f"text:{tmp / 'plain.txt'}", "DETECT_SYSTEM", HERE, "")[0],
                         "plain prompt")
        with self.assertRaises(SystemExit):
            prompt_ab.load_prompt("svn:1", "DETECT_SYSTEM", HERE, "")



class ReleaseTests(unittest.TestCase):
    """scripts/release.py, with git stood in: nothing is built or tagged."""

    def test_a_tag_behind_head_is_never_zipped(self):
        # review of 26 October: the checks read the working tree and the
        # zip the tag, so commits after it were silently left out
        import importlib.util
        from unittest.mock import patch
        path = Path(__file__).resolve().parents[2] / "scripts" / "release.py"
        spec = importlib.util.spec_from_file_location("release_under_test", path)
        release = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(release)
        answers = {("tag", "--list", "v9.9.9"): b"v9.9.9\n",
                   ("rev-parse", "HEAD"): b"aaaaaaaaaa\n",
                   ("rev-list", "-n", "1", "v9.9.9"): b"bbbbbbbbbb\n"}
        with patch.object(release, "git", lambda *a: answers[a]):
            with self.assertRaises(SystemExit) as e:
                release.build("9.9.9")
        self.assertIn("bbbbbbb, HEAD is aaaaaaa", str(e.exception))


if __name__ == "__main__":
    unittest.main()
