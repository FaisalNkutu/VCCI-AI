"""The column profiler (scripts/profile_columns.py) on a stand-in database:
what it reads, what it keeps, and that it never writes."""

import os
import pathlib
import re
import sys
import tempfile
import unittest
from types import SimpleNamespace

os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "scripts"))
import profile_columns as pc  # noqa: E402


class Cursor:
    """Answers the profiler's queries from rows held per table."""

    def __init__(self, db):
        self.db = db
        self.result = []

    def execute(self, sql, args=()):
        self.db.sent.append(sql)
        s = re.sub(r"^SET STATEMENT max_statement_time=[0-9.]+ FOR ", "", sql)
        if s.startswith("SELECT VERSION()"):
            self.result = [("10.11.6-MariaDB",)]
        elif s.startswith("START TRANSACTION"):
            self.result = []
        elif "information_schema.columns" in s:
            self.result = [(t, c, ty) for t, cols in self.db.schema.items() for c, ty in cols]
        else:
            self.result = self.answer(s)

    def answer(self, s):
        table = re.search(r"FROM `(\w+)` LIMIT", s).group(1)
        col = re.search(r"`(\w+)`", s.split(" FROM ")[0] + " `x`").group(1)
        rows = self.db.rows[table]
        values = [r[col] for r in rows]
        present = [v for v in values if v is not None]
        if s.startswith("SELECT COUNT(*), COUNT(*) - COUNT("):
            return [(len(values), len(values) - len(present), len(set(present)))]
        if s.startswith("SELECT MIN("):
            return [(min(present) if present else None, max(present) if present else None)]
        if s.startswith("SELECT SUM(TIME("):
            return [(sum(1 for v in present if (v.hour, v.minute, v.second) != (0, 0, 0)),)]
        if "GROUP BY" in s:
            from collections import Counter
            return sorted(Counter(present).items(), key=lambda kv: (-kv[1], kv[0]))[:pc.TOP]
        if " IS NOT NULL LIMIT" in s:
            return [(v,) for v in present[:pc.SHAPE_SAMPLE]]
        raise AssertionError(f"unexpected query: {s}")

    def fetchall(self):
        return self.result

    def fetchone(self):
        return self.result[0]

    def close(self):
        pass


class Conn:
    def __init__(self, schema, rows):
        self.schema, self.rows, self.sent = schema, rows, []
        self.rolled_back = False

    def cursor(self):
        return Cursor(self)

    def rollback(self):
        self.rolled_back = True


def db():
    import datetime as dt
    schema = {"tickets": [("ticket_id", "int"), ("code", "varchar"), ("priority", "varchar"),
                          ("opened_at", "datetime"), ("due_on", "date"), ("note", "text")]}
    rows = {"tickets": [
        {"ticket_id": i, "code": f"TK-{1000 + i}", "priority": ["HIGH", "LOW", "LOW"][i % 3],
         "opened_at": dt.datetime(2026, 3, 1, 9 + i % 5, 15), "due_on": dt.date(2026, 3, 10),
         "note": None if i % 2 else "x" * 80}
        for i in range(12)]}
    return Conn(schema, rows)


class ProfilerTests(unittest.TestCase):

    def run_profiler(self, **kw):
        conn = db()
        return pc.Profiler(conn, "theirs", **kw).run(), conn

    def test_every_column_gets_counts_and_a_range(self):
        out, _ = self.run_profiler()
        cols = out["tables"]["tickets"]["columns"]
        self.assertEqual(cols["ticket_id"]["distinct"], 12)
        self.assertEqual((cols["ticket_id"]["min"], cols["ticket_id"]["max"]), (0, 11))
        self.assertEqual(cols["note"]["null_share"], 0.5)
        self.assertEqual(out["tables"]["tickets"]["rows_seen"], 12)

    def test_a_datetime_says_whether_it_holds_a_time_and_a_date_does_not(self):
        cols = self.run_profiler()[0]["tables"]["tickets"]["columns"]
        self.assertIs(cols["opened_at"]["has_time"], True)
        self.assertNotIn("has_time", cols["due_on"])      # a DATE says nothing of time

    def test_short_text_gets_its_frequent_values_and_shape(self):
        cols = self.run_profiler()[0]["tables"]["tickets"]["columns"]
        self.assertEqual(cols["priority"]["top"][0], {"value": "LOW", "count": 8})
        self.assertEqual(cols["code"]["format"]["shape"], "AA-9999")
        # prose gets a length, never its values
        self.assertNotIn("top", cols["note"])
        self.assertEqual(cols["note"]["format"]["length"], "80")

    def test_no_values_keeps_no_stored_text(self):
        cols = self.run_profiler(values=False)[0]["tables"]["tickets"]["columns"]
        self.assertNotIn("top", cols["priority"])
        self.assertIn("format", cols["code"])
        self.assertIn("min", cols["ticket_id"])

    def test_it_only_reads_bounded_and_rolls_back(self):
        out, conn = self.run_profiler(rows=500, seconds=3)
        self.assertTrue(conn.rolled_back)
        reads = [s for s in conn.sent if "FROM (SELECT * FROM" in s]
        self.assertTrue(reads)
        self.assertTrue(all("LIMIT 500" in s and s.startswith("SET STATEMENT max_statement_time=3 FOR")
                            for s in reads))
        self.assertFalse([s for s in conn.sent if re.search(r"\b(INSERT|UPDATE|DELETE|DROP|CREATE)\b", s)])

    def test_the_file_goes_beside_the_descriptions(self):
        p = SimpleNamespace(name="Enterprise", descriptions="files/Enterprise.descriptions.json")
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(pc.profile_path(p, d), pathlib.Path(d) / "files" / "Enterprise.profile.json")

    def test_the_profile_reads_back_as_the_agent_loads_it(self):
        import json
        out, _ = self.run_profiler()
        with tempfile.TemporaryDirectory() as d:
            path = pathlib.Path(d) / "p.json"
            path.write_text(json.dumps({"tables": out["tables"]}, default=str), encoding="utf-8")
            try:
                import verdict_tools
            except ImportError:
                self.skipTest("verdict_tools is not merged yet")
            loaded = verdict_tools.load_profile(str(path))
        self.assertIn("priority", loaded["tickets"])


if __name__ == "__main__":
    unittest.main()
