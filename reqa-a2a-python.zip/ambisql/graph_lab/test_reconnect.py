"""A service down at the first question is tried again after a while:
Qdrant (the recall, the clarifier's corpus and column index) and Neo4j
(the pipeline's graph). No service, no model."""

import os

os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

import sys
import unittest
from types import SimpleNamespace
from unittest.mock import patch

import ambisql
import pipeline
import recall


class Clock:
    def __init__(self):
        self.now = 1000.0

    def monotonic(self):
        return self.now


class Qdrant:
    """A Qdrant down until `up`, counting the clients made."""

    def __init__(self, collections=("c",)):
        self.up, self.made, self.collections = False, 0, list(collections)

    def client(self, url=None, timeout=None, api_key=None):
        self.made += 1
        server = self

        class Client:
            def get_collections(self):
                if not server.up:
                    raise ConnectionError("connection refused")
                return SimpleNamespace(collections=[SimpleNamespace(name=n)
                                                    for n in server.collections])
        return Client()


PROFILE = SimpleNamespace(name="Shop", qdrant_url="http://qdrant:6333", qdrant_collection="c",
                          ollama_url="", embed_model="nomic-embed-text")


class QdrantTests(unittest.TestCase):

    def setUp(self):
        self.clock, self.server = Clock(), Qdrant()
        for p in (patch.dict(sys.modules, {"qdrant_client":
                                           SimpleNamespace(QdrantClient=self.server.client)}),
                  patch.object(recall, "time", self.clock)):
            p.start()
            self.addCleanup(p.stop)

    def later(self):
        self.clock.now += recall.RETRY_SECONDS + 1

    def clarifier(self):
        c = ambisql.Clarifier.__new__(ambisql.Clarifier)
        c.profile = PROFILE
        c._corpus, c._corpus_checked = None, False
        c._index, c._index_checked = None, False
        return c

    def test_the_recall_tries_qdrant_again_after_a_while_never_each_call(self):
        # review of 26 October: down at the first question, off until a restart
        r = recall.Recall(PROFILE.qdrant_url, "c", "")
        self.assertFalse(r.available())
        self.server.up = True
        self.assertFalse(r.available())
        self.assertEqual(self.server.made, 1)
        self.later()
        self.assertTrue(r.available())
        self.assertEqual(self.server.made, 2)
        self.later()
        self.assertTrue(r.available())
        self.assertEqual(self.server.made, 2)

    def test_no_url_is_no_qdrant_and_is_never_tried(self):
        r = recall.Recall("", "c", "")
        self.assertFalse(r.available())
        self.later()
        self.assertFalse(r.available())
        self.assertEqual(self.server.made, 0)

    def test_the_clarifier_takes_the_corpus_once_qdrant_answers(self):
        c = self.clarifier()
        self.assertIsNone(c.corpus)
        self.server.up = True
        self.assertIsNone(c.corpus)
        self.later()
        self.assertIsNotNone(c.corpus)
        self.assertEqual(c.corpus.collection, "c")

    def test_a_corpus_reached_and_absent_costs_no_call_after(self):
        self.server.up, self.server.collections = True, []
        c = self.clarifier()
        self.assertIsNone(c.corpus)
        made = self.server.made
        self.later()
        self.assertIsNone(c.corpus)
        self.assertEqual(self.server.made, made)

    def test_the_clarifier_readies_the_index_once_qdrant_answers(self):
        readied = []

        def ready(index, clar, progress=None):
            readied.append(clar)
            return index.available()
        with patch.object(recall, "column_index_on", lambda: True), \
                patch.object(recall.ColumnIndex, "ready", ready):
            c = self.clarifier()
            self.assertIsNone(c.index)
            self.server.up = True
            self.later()
            self.assertIsNotNone(c.index)
            self.assertEqual(readied, [c, c])
            self.assertIs(c.index, c.index)
            self.assertEqual(len(readied), 2)


class GraphTests(unittest.TestCase):

    def test_the_graph_is_tried_again_after_a_while_and_the_failed_driver_closed(self):
        clock, closed, tries = Clock(), [], []

        class Driver:
            def close(self):
                closed.append(self)

        def connect():
            tries.append(clock.now)
            return Driver()

        def graph(profile, driver):
            if len(tries) == 1:
                raise ConnectionError("neo4j starting")
            return SimpleNamespace(edges={("orders", "customers"): "o.c = c.c"})
        p = pipeline.Pipeline.__new__(pipeline.Pipeline)
        p.profile = SimpleNamespace(connect_neo4j=connect)
        p._graph = p._driver = None
        with patch.object(pipeline, "time", clock), \
                patch.object(pipeline.Graph, "from_profile", graph):
            self.assertFalse(p.has_graph)
            self.assertFalse(p.has_graph)
            self.assertEqual(len(tries), 1)
            clock.now += pipeline.GRAPH_RETRY_SECONDS + 1
            self.assertTrue(p.has_graph)
            self.assertEqual(len(tries), 2)
            self.assertEqual(len(closed), 1)


if __name__ == "__main__":
    unittest.main()
