"""Anchors from questions already answered, rather than from a model.

Step 2 names the tables a question is about. A model can do it, and does
it well enough, but it costs a call, it varies between runs, and it knows
nothing about what this team actually asks. A corpus of questions whose
SQL executed correctly knows all three.

So the order is: ask the corpus, and only ask a model when the corpus has
nothing close. Every answered question then joins the corpus, which means
the second week costs fewer model calls than the first and the tenth
almost none.

    rec = Recall.from_profile(profile)
    rec.seed([{"question": "...", "tables": [...], "sql": "..."}])
    rec.anchors("how many orders per city")     # [] when nothing is close

Optional by construction, exactly like the graph. No Qdrant, or an empty
collection, and `anchors` returns nothing: the pipeline falls back to the
model and says so. Adopting this is therefore never a migration, and
switching it off is never an outage.
"""

import json
import os
import threading
import time
import urllib.request
import uuid

if __package__:
    from .observability import get_logger
else:
    from observability import get_logger

log = get_logger("recall")
import traceback

# below this cosine score the neighbour is not about the same thing, and
# borrowing its tables would anchor the question on the wrong part of the
# schema. Returning nothing and paying for a model call is the cheaper
# mistake, so the bar is deliberately high. The default only:
# corpus_min_score() reads the configured one.
MIN_SCORE = 0.72
NEIGHBOURS = 3

# Examples of questions and their SQL shown to the SQL generator. The first
# one does most of the good and more than five add nothing (DAIL-SQL); a
# pool a few times larger leaves room to skip near-duplicates. SQL a model
# wrote and that merely ran ("asked") is no example: a query that runs is
# not therefore right, and unfiltered pairs lowered scores elsewhere.
EXAMPLES = 3
EXAMPLE_POOL = 12
# a Qdrant that could not be reached is tried again after this long
RETRY_SECONDS = 60
EXAMPLE_SOURCES = ("dictionary", "pairs", "hand", "")


def example_settings():
    """(how many examples, from which sources), from DATAGORA_EXAMPLES and
    DATAGORA_EXAMPLES_SOURCES (comma separated; "none" for a source-less
    pair); 0 examples switches them off."""
    try:
        k = int(os.environ.get("DATAGORA_EXAMPLES", EXAMPLES))
    except ValueError:
        k = EXAMPLES
    raw = os.environ.get("DATAGORA_EXAMPLES_SOURCES")
    if raw is None:
        sources = EXAMPLE_SOURCES
    else:
        sources = tuple("" if s.strip().lower() == "none" else s.strip().lower()
                        for s in raw.split(",") if s.strip())
    return max(0, min(k, 5)), sources


def question_key(text):
    """A question with its case, punctuation and spacing taken out."""
    import re
    return " ".join(re.sub(r"[^0-9a-z]+", " ", str(text or "").lower()).split())


_DENY = {}


def example_deny():
    """(questions, sql shapes) never shown as examples, from the JSON file
    DATAGORA_EXAMPLES_DENY names ({"questions": [...], "sql": [...]}): what
    an evaluation sets so that an example never answers the question it
    measures. Empty sets without the variable."""
    path = os.environ.get("DATAGORA_EXAMPLES_DENY")
    if not path:
        return set(), set()
    try:
        stamp = os.stat(path).st_mtime_ns
    except OSError:
        return set(), set()
    if _DENY.get("key") != (path, stamp):
        try:
            with open(path, encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, ValueError):
            data = {}
        _DENY["key"] = (path, stamp)
        _DENY["value"] = ({question_key(q) for q in data.get("questions") or []},
                          {sql_shape(s) for s in data.get("sql") or []})
    return _DENY["value"]


def sql_shape(sql):
    """A query with its literals and its spacing taken out: two examples of
    the same shape teach the generator one thing, not two."""
    import re
    s = re.sub(r"'(?:[^'\\]|\\.|'')*'", "?", str(sql or ""))
    s = re.sub(r"\b\d+(?:\.\d+)?\b", "?", s)
    return re.sub(r"\s+", " ", s).strip().lower()

# Each model has its own scale, so each has its own default. Measured on the
# Library corpus, best score of six questions, in English and in French, and
# of six about nothing it holds:
#   nomic-embed-text       related EN 0.70-0.96, FR 0.43-0.63; unrelated up
#                          to 0.54. French falls under the bar, and below
#                          unrelated questions: no bar separates them.
#   multilingual-e5-large  related EN 0.88-0.95, FR 0.84-0.89; unrelated
#                          0.69-0.77. Separated, but 0.72 would let almost
#                          every unrelated question through: 0.80.
MIN_SCORES = (("e5", 0.80), ("nomic-embed", 0.72))

# a prefix the model was trained with, for question against question. e5
# is asked with "query: " on both sides for a symmetric task; nomic has
# been used without one since the corpus began, and its bar is set so.
CORPUS_PREFIXES = (("e5", "query: "),)


def _by_model(table, model, default):
    name = str(model or "").lower()
    return next((value for marker, value in table if marker in name), default)


def same_model(a, b):
    """Whether two model names are the one model: nomic-embed-text and
    nomic-embed-text:latest are."""
    def norm(m):
        return str(m or "").strip().lower().removesuffix(":latest")
    return norm(a) == norm(b)


def corpus_min_score(model=None):
    """The score a neighbour must reach for its tables to be used.

    DATAGORA_CORPUS_MIN_SCORE, set on the settings page (the Qdrant card)
    or in the .env, a number between 0 and 1. Unset, empty or unreadable,
    the embedding model's own default (MIN_SCORES), MIN_SCORE for a model
    not measured. Read at every search, so a change made on the page
    applies to the next question without a restart."""
    default = _by_model(MIN_SCORES, model, MIN_SCORE)
    try:
        if __package__:
            from .db_profile import environment
        else:
            from db_profile import environment
        raw = environment().get("DATAGORA_CORPUS_MIN_SCORE")
    except Exception:
        raw = os.environ.get("DATAGORA_CORPUS_MIN_SCORE")
    try:
        value = float(str(raw).strip()) if raw not in (None, "") else default
    except ValueError:
        return default
    return value if 0.0 <= value <= 1.0 else default


def collection_stem(database):
    """A database's name made into one Qdrant always accepts, the start of
    every collection Datagora keeps for it: "Library" is library, "Stock
    2024" stock_2024."""
    safe = "".join(c if c.isalnum() else "_" for c in str(database).lower()).strip("_")
    return safe or "database"


def corpus_collection(database):
    """The collection of a database's corpus when none is named:
    library_corpus for "Library"."""
    return f"{collection_stem(database)}_corpus"


def _sql_tables(sql):
    """The tables a query reads, [] when it cannot be parsed."""
    if __package__:
        from .schema_graph import parse_sql
    else:
        # In script mode the sibling directory is placed on sys.path;
        # use a dynamic import so static analysis does not require a
        # top-level package named ``schema_graph``.
        from importlib import import_module
        parse_sql = import_module("schema_graph").parse_sql
    try:
        return list(parse_sql(sql)[0])
    except Exception:
        return []

import logging
logging.basicConfig(level=logging.INFO,format='A2A %(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("RECALL") 



class Recall:
    """The corpus of answered questions, as a table-naming service."""

    def __init__(self, url, collection, embed_url,
                 embed_model="nomic-embed-text"):
        self.url = (url or "").rstrip("/")
        self.collection = collection
        self.embed_url = (embed_url or "").rstrip("/")
        self.embed_model = embed_model
        self._client = None
        self._checked = False

        logger.info(f"Recall.__init__(url={self.url}, collection={self.collection},  ... )")

    @classmethod
    def from_profile(cls, profile):

        logger.info(f"Recall.from_profile(\"{profile}\")")
        
        """Everything already lives on the profile, so a database that
        has a corpus and one that does not are configured the same way."""
        return cls(profile.qdrant_url,
                   profile.qdrant_collection or corpus_collection(profile.name),
                   profile.ollama_url, profile.embed_model)

    # ------------------------------------------------------- the client
    @property
    def client(self):
        failed = getattr(self, "_failed_at", None)
        if self._client is None and failed is not None                 and time.monotonic() - failed > RETRY_SECONDS:
            # Qdrant still starting at the first question left every later
            # one without the corpus until a restart (review of 26 October):
            # it is tried again after a while, as the graph is
            self._checked = False
        if not self._checked:
            self._checked = True
            self._failed_at = None
            if not self.url:
                return None
            try:
                from qdrant_client import QdrantClient
                # the key, when the deployment requires one.
                # Without this, turning the key on in compose
                # made every corpus call fail with a 403 that
                # reads like an empty corpus.
                key = os.environ.get("QDRANT_API_KEY") or None
                c = QdrantClient(url=self.url, timeout=5,
                                 api_key=key)
                c.get_collections()          # fails fast when it is not there
                self._client = c
            except Exception as e:
                log.info("recall off: %s", str(e)[:90])
                self._client = None
                self._failed_at = time.monotonic()
        return self._client

    def available(self):
        return self.client is not None

    def size(self):
        """How many questions the corpus holds, 0 when there is none."""
        if not self.available():
            return 0
        try:
            return self.client.count(self.collection, exact=True).count
        except Exception:
            return 0

    # ---------------------------------------------------- the embedding
    def embed(self, texts):
        """One vector per text. Ollama first, then the OpenAI shape, so a
        production embedding service needs no code change here either."""
        for path, body, pick in (
                ("/api/embed",
                 {"model": self.embed_model, "input": texts},
                 lambda d: d["embeddings"]),
                ("/v1/embeddings",
                 {"model": self.embed_model, "input": texts},
                 lambda d: [x["embedding"] for x in d["data"]])):
            req = urllib.request.Request(
                self.embed_url + path,
                data=json.dumps(body).encode("utf-8"),
                headers={"Content-Type": "application/json"})
            try:
                with urllib.request.urlopen(req, timeout=120) as r:
                    return pick(json.loads(r.read()))
            except Exception:
                continue
        return None

    # --------------------------------------------------------- the reads
    def neighbours(self, question, limit=NEIGHBOURS):
        """The closest answered questions, with their score."""
        if not self.available():
            return []
        stored = self.stored_model()
        if stored and not same_model(stored, self.embed_model):
            # vectors of two models are not comparable, and a corpus built
            # with the old one would hand out the wrong tables with a high
            # score; nothing is used until it is indexed again
            if not getattr(self, "_said_mismatch", False):
                self._said_mismatch = True
                log.info("corpus %s was built with %s, not %s: not used until "
                         "it is indexed again", self.collection, stored, self.embed_model)
            return []
        vec = self.embed([self._corpus_prefix() + question])
        if not vec:
            return []
        try:
            hits = self.client.query_points(
                self.collection, query=vec[0], limit=limit).points
        except Exception as e:
            log.info("recall query failed: %s", str(e)[:90])
            traceback.print_exc()
            return []
        return [(h.score, h.payload or {}) for h in hits]

    def _corpus_prefix(self):
        return _by_model(CORPUS_PREFIXES, self.embed_model, "")

    def examples(self, question, k=None, sources=None, pool=EXAMPLE_POOL):
        """The answered questions closest to this one that carry their SQL,
        for the SQL prompt: [{"question", "sql", "score", "source"}].

        Only from the sources given (verified ones by default), never two
        of the same SQL shape, never the question itself. Empty when the
        corpus is off or holds no SQL."""
        default_k, default_sources = example_settings()
        k = default_k if k is None else max(0, int(k))
        sources = default_sources if sources is None else tuple(sources)
        if not k:
            return []
        out, shapes = [], set()
        asked = question_key(question)
        denied_questions, denied_sql = example_deny()
        for score, p in self.neighbours(question, limit=max(pool, k)):
            sql = str(p.get("sql") or "").strip()
            if not sql or str(p.get("source") or "") not in sources:
                continue
            # the question itself, however it is punctuated; and during an
            # evaluation, nothing that reproduces an evaluation question or
            # its reference SQL: shown its own answer, the generator is not
            # being measured. A question that differs by a value ("in 2025"
            # for "in 2024") is the best example there is, and stays.
            seen = question_key(p.get("question"))
            if seen == asked or seen in denied_questions or sql_shape(sql) in denied_sql:
                continue
            shape = sql_shape(sql)
            if shape in shapes:
                continue
            shapes.add(shape)
            out.append({"question": p.get("question"), "sql": sql,
                        "score": round(float(score), 4), "source": p.get("source") or ""})
            if len(out) == k:
                break
        return out

    def exists(self):
        try:
            return self.collection in {c.name for c in self.client.get_collections().collections}
        except Exception:
            return False

    def stored_model(self):
        """The embedding model the corpus was built with, or None when it
        is empty, missing, or older than the field. Read again after 30
        seconds: a corpus being indexed again with a new model must be used
        as soon as it is, not after a restart."""
        cached = self.__dict__.get("_stored_model")
        if cached is not None and time.monotonic() - cached[1] < 30:
            return cached[0]
        model = None
        try:
            if self.exists():
                points, _ = self.client.scroll(self.collection, limit=1,
                                               with_payload=True, with_vectors=False)
                if points:
                    model = (points[0].payload or {}).get("model")
        except Exception:
            model = None
        self._stored_model = (model, time.monotonic())
        return model

    # With a reranker (rerank.py): the neighbours looked at, how far under
    # the vector bar they may start, and the reranker's score a neighbour
    # needs for its tables to be used (4 of 10: related; recall-first).
    # Measured on the Warehouse corpus, 25 questions, gemma3:4b: every
    # needed table found for 12 against 4 by the vector bar alone, none
    # for 4 against 18; 0.5 to 0.7 found 9. About 8 s a question.
    RERANK_POOL = 10
    RERANK_BELOW = 0.15
    RERANK_KEEP = 0.4

    def anchors(self, question, limit=NEIGHBOURS, min_score=None, reranker="configured"):
        """Tables named by the neighbours that are close enough.

        The union rather than the best one, because the layer is
        recall-first: an extra table costs one edge in the sub-schema,
        a missing table costs the answer. `min_score`, when not given, is
        the configured bar (see corpus_min_score()).

        With a reranker, more neighbours are looked at, from a little under
        the bar, and it is the reranker, reading each one against the
        question, that decides which are close enough: two questions can
        sit near in embedding space and ask different things. Without one,
        or when it cannot say, the vector bar decides, as before."""
        bar = min_score if min_score is not None else corpus_min_score(self.embed_model)
        if reranker == "configured":
            if __package__:
                from .rerank import Reranker
            else:
                from rerank import Reranker
            reranker = Reranker.configured()
        if reranker is not None:
            chosen = self._reranked_anchors(question, bar, reranker)
            if chosen is not None:
                return chosen
        tables, used = [], []
        for score, payload in self.neighbours(question, limit):
            if score < bar:
                continue
            used.append((round(score, 3), payload.get("question", "")[:48]))
            for t in payload.get("tables", []):
                if t not in tables:
                    tables.append(t)
        if tables:
            log.info("anchors from corpus %s, neighbours %s", tables, used)
        return tables

    def _reranked_anchors(self, question, bar, reranker):
        """The tables of the neighbours the reranker keeps, or None when it
        could not say and the vector bar must decide."""
        if __package__:
            from .rerank import rerank
        else:
            from rerank import rerank
        pool = [(s, p) for s, p in self.neighbours(question, self.RERANK_POOL)
                if s >= bar - self.RERANK_BELOW]
        if not pool:
            return []
        ranked = rerank(question, pool, text=lambda sp: sp[1].get("question", ""),
                        reranker=reranker)
        if not ranked or ranked[0][1] is None:
            return None
        # an embedding model's closeness has its own scale (rerank.EMBED_KEEP)
        keep = reranker.keep(self.RERANK_KEEP)
        tables, used = [], []
        for (score, payload), kept in ranked:
            if kept < keep:
                continue
            used.append((round(kept, 2), round(score, 3), payload.get("question", "")[:48]))
            for t in payload.get("tables", []):
                if t not in tables:
                    tables.append(t)
        log.info("anchors from corpus, reranked by %s: %s, neighbours %s",
                 reranker.name, tables, used)
        return tables

    # -------------------------------------------------------- the writes
    def _ensure(self, dim):
        from qdrant_client.models import Distance, VectorParams
        names = {c.name for c in self.client.get_collections().collections}
        if self.collection not in names:
            self.client.create_collection(
                self.collection,
                vectors_config=VectorParams(size=dim,
                                            distance=Distance.COSINE))
            log.info("created collection %s (dim %d)", self.collection, dim)

    @staticmethod
    def point_id(question):
        """One id per question, whatever its case and surrounding spaces."""
        key = " ".join(str(question).lower().split())
        return str(uuid.uuid5(uuid.NAMESPACE_URL, "datagora-corpus:" + key))

    def seed(self, pairs, source=None):
        """Load questions whose SQL is known good.

        A pair needs a `question` and either its `tables` or the `sql`
        they can be read from. Reading them from the SQL is what makes an
        existing query log usable as it stands: a team hands over what
        their analysts already ask and what they already run, and the
        corpus is populated without anyone labelling anything. `source`
        is kept with each question ("dictionary", "asked"), so a new
        version of a dictionary can replace its own questions and only
        those."""
        if not self.available() or not pairs:
            return 0
        from qdrant_client.models import PointStruct
        prepared = []
        for p in pairs:
            tables = list(p.get("tables") or [])
            if not tables and p.get("sql"):
                tables = _sql_tables(p["sql"])
            if p.get("question") and tables:
                prepared.append({"question": p["question"], "tables": tables,
                                 "sql": p.get("sql", ""),
                                 "verified": bool(p.get("verified", True)),
                                 # so a corpus built with another model is
                                 # seen for what it is, and never searched
                                 "model": self.embed_model})
                if source or p.get("source"):
                    prepared[-1]["source"] = source or p["source"]
        if not prepared:
            return 0
        vectors = self.embed([self._corpus_prefix() + p["question"] for p in prepared])
        if not vectors:
            return 0
        self._ensure(len(vectors[0]))
        # the id is the question itself, so a question seeded again, or
        # remembered a second time, replaces its point instead of adding a
        # copy that would count twice among the neighbours
        points = [PointStruct(id=self.point_id(p["question"]), vector=v, payload=p)
                  for p, v in zip(prepared, vectors)]
        self.client.upsert(self.collection, points=points)
        log.info("corpus %s: %d questions added", self.collection, len(points))
        return len(points)

    def index(self, pairs, progress=None, source="dictionary"):
        """Seed a whole dictionary, a batch at a time, saying how far it is.

        `progress(done, total)` is called after each batch, which is what
        lets a page draw how much is left: a production dictionary holds
        thousands of questions. Once every batch is written, the questions
        of the same source that this version no longer holds are removed;
        the questions remembered from use are a source of their own and
        are never touched.

        A corpus built with another embedding model is rebuilt whole: its
        vectors cannot be compared with the new ones, so the collection is
        dropped and every question is embedded again, the ones learned from
        use included, read back from what the corpus stored.

        Returns {"indexed", "removed", "reembedded"}. Raises when the
        embedding model gives no vector, rather than reporting nothing."""
        pairs = [dict(p, source=source) for p in pairs if p.get("question")]
        if not self.available():
            raise RuntimeError(f"Qdrant does not answer at {self.url}")
        carried = self._take_for_new_model()
        work = carried + pairs
        total = len(work)
        # about twenty steps, whatever the size, in batches of 4 to 32
        size = max(4, min(32, total // 20 or 1))
        indexed, done = 0, 0
        if progress:
            progress(0, total)
        for start in range(0, total, size):
            chunk = work[start:start + size]
            written = self.seed(chunk)
            if not written and any(p.get("tables") or p.get("sql") for p in chunk):
                raise RuntimeError(f"the embedding model {self.embed_model} at "
                                   f"{self.embed_url} gave no vectors")
            indexed += written
            done += len(chunk)
            if progress:
                progress(done, total)
        kept = {self.point_id(p["question"]) for p in pairs}
        removed = self._drop_stale(source, kept) if self.exists() else 0
        self.__dict__.pop("_stored_model", None)
        return {"indexed": indexed, "removed": removed, "reembedded": len(carried)}

    def _take_for_new_model(self):
        """When the corpus holds another model's vectors: the questions it
        learned from use, read back, and the collection dropped. Otherwise
        nothing, and the corpus is left as it is."""
        if not self.exists():
            return []
        stored = self.stored_model()
        if stored and same_model(stored, self.embed_model):
            return []
        if not stored:
            # built before the model was recorded: compare the sizes
            try:
                info = self.client.get_collection(self.collection)
                size = info.config.params.vectors.size
                probe = self.embed([self._corpus_prefix() + "size"])
                if probe and len(probe[0]) == size and same_model(self.embed_model, "nomic-embed-text"):
                    return []          # the model every older corpus was built with
            except Exception:
                pass
        carried, offset = [], None
        while True:
            points, offset = self.client.scroll(self.collection, limit=256, offset=offset,
                                                with_payload=True, with_vectors=False)
            carried += [dict(pt.payload or {}) for pt in points
                        if (pt.payload or {}).get("source") != "dictionary"]
            if offset is None:
                break
        for p in carried:
            p.setdefault("source", "asked")
        self.client.delete_collection(self.collection)
        self.__dict__.pop("_stored_model", None)
        log.info("corpus %s held %s vectors: rebuilt with %s, %d questions from use "
                 "embedded again", self.collection, stored or "older", self.embed_model,
                 len(carried))
        return carried

    def _drop_stale(self, source, kept):
        """Remove the points of `source` whose question is not in `kept`."""
        from qdrant_client.models import FieldCondition, Filter, MatchValue, PointIdsList
        stale, offset = [], None
        only = Filter(must=[FieldCondition(key="source", match=MatchValue(value=source))])
        while True:
            points, offset = self.client.scroll(
                self.collection, scroll_filter=only, limit=256, offset=offset,
                with_payload=False, with_vectors=False)
            stale += [pt.id for pt in points if str(pt.id) not in kept]
            if offset is None:
                break
        if stale:
            self.client.delete(self.collection, points_selector=PointIdsList(points=stale))
            log.info("corpus %s: %d questions no longer in the dictionary removed",
                     self.collection, len(stale))
        return len(stale)

    def reset(self):
        """Drop the collection so it can be rebuilt from scratch.

        A corpus drifts: questions quoting values the data no longer
        holds, entries seeded twice, a schema that has moved on. Seeding
        again only adds to it, so there has to be a way to start over."""
        if not self.available():
            return False
        try:
            self.client.delete_collection(self.collection)
            log.info("corpus %s dropped", self.collection)
            return True
        except Exception as e:
            log.info("could not drop %s: %s", self.collection, str(e)[:80])
            return False

    def remember(self, question, tables, sql=""):
        """One answered question, added after the fact; the id of its
        point, "" when nothing was kept.

        Called only when the SQL executed, so the corpus holds nothing
        that was not run by a database. Ran is not right: the pair is kept
        as "asked" and unverified, which names tables for later questions
        but is never shown to the generator as an example. The tables kept
        are those the SQL reads: the tables the question was offered were
        more than it used, and a later neighbour was anchored on all of
        them (review of 26 October). `tables` serves only when the SQL
        cannot be read."""
        used = _sql_tables(sql) if sql else []
        if not (self.available() and question and (used or tables)):
            return ""
        try:
            kept = self.seed([{"question": question, "tables": used or list(tables),
                               "sql": sql, "verified": False}], source="asked")
        except Exception as e:
            log.info("could not remember: %s", str(e)[:90])
            return ""
        return self.point_id(question) if kept else ""

    def forget(self, points):
        """Remove what Ask remembered, given as (point id, sql) pairs: a
        question deleted from the history leaves the corpus with it
        (review of 26 October: its tables went on anchoring later
        questions). Only a point Ask wrote with that very SQL is removed:
        the same question seeded since by the dictionary, or asked again
        with another query, is not this one. How many were removed."""
        wanted = {str(i): s for i, s in points or [] if i}
        if not (wanted and self.available()):
            return 0
        from qdrant_client.models import PointIdsList
        try:
            found = self.client.retrieve(self.collection, ids=list(wanted),
                                         with_payload=True, with_vectors=False)
            mine = [pt.id for pt in found
                    if (pt.payload or {}).get("source") == "asked"
                    and (pt.payload or {}).get("sql", "") == wanted.get(str(pt.id))]
            if mine:
                self.client.delete(self.collection, points_selector=PointIdsList(points=mine))
                log.info("corpus %s: %d questions deleted from the history removed",
                         self.collection, len(mine))
            return len(mine)
        except Exception as e:
            log.info("could not forget: %s", str(e)[:90])
            return 0


# Retrieval prefixes some embedding models are trained with. nomic-embed-text
# and the e5 family score a query against a document noticeably better
# when each side says which it is, and both document it. A model not
# listed gets no prefix, which is what every other model expects.
PREFIXES = {"nomic-embed": ("search_query: ", "search_document: "),
            "e5": ("query: ", "passage: ")}

# How far above the other columns the best one must stand before it counts
# as a lead. Measured, not chosen: 24 phrases on the two demo schemas, half
# of them naming something the schema holds under another word ("storage
# space" for capacity_units) and half naming nothing it holds (warranty,
# blood type, audiobooks), with nomic-embed-text and multilingual-e5-large.
#
# A raw cosine cannot tell the two halves apart with either model. Related
# pairs scored 0.54 to 0.74 on nomic and unrelated ones up to 0.63, and e5
# squeezes everything into 0.77 to 0.85. What does separate them is how
# much the best column stands out from the rest of the schema: a phrase
# that means one column points at it, a phrase that means nothing scores
# every column about the same. Counted in standard deviations above the
# mean of the others, related phrases reached 1.96 to 6.84 and unrelated
# ones at most 3.32. At 3.4, neither model let one unrelated phrase
# through, and 7 (nomic) and 9 (e5) of the 13 related ones were found.
#
# Twenty-four phrases is a small sample and two schemas of twenty-odd
# columns are small schemas. The bar is therefore raised with the size of
# the schema, by the amount the largest of n random scores grows,
# sqrt(2 ln n), so a schema of five hundred columns does not produce a lead
# by chance more often than one of twenty-five. `python recall.py columns`
# prints the numbers for a real schema; DATAGORA_COLUMN_MIN_Z moves the bar.
COLUMN_MIN_Z = 3.4
CALIBRATED_ON = 25


def column_index_on():
    """Whether coverage may use the column index: on unless
    DATAGORA_COLUMN_INDEX says off. On by default because its one power is
    to stop a false NOT COVERED, the most damaging verdict, and it can never
    make a question answerable. It also needs a Qdrant and an embedding
    model; without them it stays off by itself."""
    try:
        if __package__:
            from .db_profile import environment
        else:
            from db_profile import environment
        raw = environment().get("DATAGORA_COLUMN_INDEX")
    except Exception:
        raw = os.environ.get("DATAGORA_COLUMN_INDEX")
    return str(raw or "on").strip().lower() not in ("off", "0", "false", "no")

_BUILDING = threading.Lock()


class ColumnIndex(Recall):
    """What each column of one schema holds, searchable by meaning.

    The name matching in ambisql finds `fee` for "fee" and never for
    "charges"; a data dictionary fixes that for the columns somebody
    described, and this fixes it for the rest, by comparing the phrase with
    a short text per column: its name spelt out, its type, what it is
    documented to mean, what its table is for, and a few values it holds.

    RECALL ONLY, and that is a design rule rather than a precaution. A
    close vector says two texts are about related things, which is exactly
    the evidence needed to stop "your database cannot do this", and far too
    little to say "yes it can". So a hit here withholds a denial and is
    shown as a lead, and it never makes a question answerable.

    One collection per schema, named after a fingerprint of its tables,
    columns, types and descriptions, so a schema that changes gets a new
    index on first use and the old one is dropped. Values are not in the
    fingerprint: data moves every day and the index would never settle.
    """

    def __init__(self, url, prefix, embed_url, embed_model="nomic-embed-text",
                 min_z=None):
        super().__init__(url, prefix, embed_url, embed_model)
        self.prefix = prefix
        if min_z is None:
            try:
                min_z = float(os.environ.get("DATAGORA_COLUMN_MIN_Z")
                              or COLUMN_MIN_Z)
            except ValueError:
                min_z = COLUMN_MIN_Z
        self.min_z = min_z
        self._count = None

    @classmethod
    def from_profile(cls, profile):
        # library_columns_<fingerprint> for "Library", as the corpus is
        # library_corpus: one rule for every collection of a database
        return cls(profile.qdrant_url, f"{collection_stem(profile.name)}_columns",
                   profile.ollama_url, profile.embed_model)

    def _prefix(self, side):
        for marker, pair in PREFIXES.items():
            if marker in (self.embed_model or "").lower():
                return pair[0 if side == "query" else 1]
        return ""

    @staticmethod
    def describe(clar, table, column, dtype):
        """The text a column is searched by."""
        spelt = " ".join(sorted(clar._identifier_tokens(column)))
        parts = [f"{table}.{column}", spelt, str(dtype or "").lower()]
        said = clar.means(table, column)
        if said:
            parts.append(said)
        about = clar.means(table)
        if about:
            parts.append(f"in {table}: {about}")
        values = clar.samples.get((table.lower(), column.lower()))
        if values:
            parts.append("e.g. " + ", ".join(values))
        return " | ".join(parts)

    def fingerprint(self, clar):
        """Of the schema's shape and of the embedding model: vectors from
        two models are not comparable, and usually not even the same size,
        so switching models must never reuse an index."""
        import hashlib
        shape = [f"model:{self.embed_model}"]
        for table, cols in sorted(clar.columns.items()):
            shape.append(f"{table}:{clar.means(table)}")
            for column, dtype in cols:
                shape.append(f"{table}.{column}:{dtype}:"
                             f"{clar.means(table, column)}")
        return hashlib.sha256("\n".join(shape).encode("utf-8")
                              ).hexdigest()[:10]

    def ready(self, clar, progress=None):
        """Point at this schema's collection, building it if it is missing.

        False when Qdrant or the embedding model cannot be reached, which
        leaves the clarifier exactly as it is without an index. `progress`
        is given to build, when there is one to do."""
        if not self.available():
            return False
        self.collection = f"{self.prefix}_{self.fingerprint(clar)}"
        with _BUILDING:
            if self.size() > 0:
                return True
            return self.build(clar, progress=progress) > 0

    def build(self, clar, progress=None):
        """Embed every column that is not a key, and drop stale indexes.
        `progress(done, total)` follows the columns embedded."""
        from qdrant_client.models import PointStruct
        items = [(t, c, d) for t, cols in clar.columns.items()
                 for c, d in cols if not clar.is_a_key(t, c)]
        if not items:
            return 0
        texts = [self.describe(clar, t, c, d) for t, c, d in items]
        vectors = []
        if progress:
            progress(0, len(texts))
        for start in range(0, len(texts), 64):
            batch = self.embed([self._prefix("document") + x
                                for x in texts[start:start + 64]])
            if not batch:
                log.info("column index %s: embedding failed", self.collection)
                return 0
            vectors.extend(batch)
            if progress:
                progress(len(vectors), len(texts))
        self._ensure(len(vectors[0]))
        points = [PointStruct(id=str(uuid.uuid4()), vector=v,
                              payload={"table": t, "column": c, "text": x})
                  for (t, c, _d), x, v in zip(items, texts, vectors)]
        self.client.upsert(self.collection, points=points)
        log.info("column index %s: %d columns", self.collection, len(points))
        try:
            for old in self.client.get_collections().collections:
                if (old.name.startswith(self.prefix + "_")
                        and old.name != self.collection):
                    self.client.delete_collection(old.name)
                    log.info("column index %s dropped, schema moved on",
                             old.name)
        except Exception:
            pass
        return len(points)

    def candidates(self, phrase, limit=40):
        """[(table, column, score, text)], the closest columns with the text
        they are searched by, for a reranker to read (rerank.py)."""
        if not self.available():
            return []
        vec = self.embed([self._prefix("query") + str(phrase)])
        if not vec:
            return []
        try:
            hits = self.client.query_points(
                self.collection, query=vec[0], limit=limit).points
        except Exception as e:
            log.info("column index query failed: %s", str(e)[:90])
            return []
        return [((h.payload or {}).get("table"), (h.payload or {}).get("column"),
                 round(h.score, 3), (h.payload or {}).get("text") or "")
                for h in hits]

    def scored(self, phrase, limit=5):
        """[(table, column, score)] for the closest columns, unfiltered."""
        if not self.available():
            return []
        vec = self.embed([self._prefix("query") + str(phrase)])
        if not vec:
            return []
        try:
            hits = self.client.query_points(
                self.collection, query=vec[0], limit=limit).points
        except Exception as e:
            log.info("column index query failed: %s", str(e)[:90])
            return []
        return [((h.payload or {}).get("table"),
                 (h.payload or {}).get("column"), round(h.score, 3))
                for h in hits]

    def bar(self, n):
        """The standout needed on a schema of n indexed columns."""
        import math
        grow = (math.sqrt(2 * math.log(max(n, 2)))
                - math.sqrt(2 * math.log(CALIBRATED_ON)))
        return self.min_z + max(0.0, grow)

    def standing(self, phrase, limit=256):
        """[(table, column, score, z)], z being how many standard deviations
        a column's score stands above the mean of the others returned."""
        import statistics
        hits = self.scored(phrase, limit=limit)
        if len(hits) < 3:
            return []
        scores = [s for _t, _c, s in hits]
        out = []
        for i, (t, c, s) in enumerate(hits):
            rest = scores[:i] + scores[i + 1:]
            spread = statistics.pstdev(rest) or 1e-9
            out.append((t, c, s, round((s - statistics.mean(rest)) / spread,
                                       2)))
        return out

    def similar(self, phrase, limit=3):
        """The columns that stand out enough to count as a lead."""
        if self._count is None:
            self._count = self.size()
        n = min(self._count or 0, 256)
        needed = self.bar(n)
        return [(t, c, s) for t, c, s, z in self.standing(phrase, limit=n)
                if t and c and z >= needed][:limit]


def _cli():
    """Inspect or seed the corpus of one database.

        python recall.py --profile datagora_generic
        python recall.py --profile datagora_generic --ask "how many products"
        python recall.py --profile datagora_generic --seed corpus_demo.json
        python recall.py --profile datagora_lib --columns "date of birth"

    --columns builds the column index if needed and prints, for each phrase,
    every column's score and standout against the bar, which is how the bar
    is checked on a real schema before DATAGORA_COLUMN_INDEX is turned on.
    """
    import argparse
    from pathlib import Path
    if __package__:
        from .db_profile import DbProfile
    else:
        from db_profile import DbProfile

    ap = argparse.ArgumentParser(
        description=_cli.__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--profile", required=True)
    ap.add_argument("--ask", default=None, help="what the corpus would anchor")
    ap.add_argument("--seed", default=None, metavar="FILE",
                    help="JSON list, or {corpus: [...]}, of answered questions")
    ap.add_argument("--reset", action="store_true",
                    help="empty the corpus first, for a clean rebuild")
    ap.add_argument("--seed-dictionary", action="store_true",
                    help="seed from the sample queries of the database's own "
                         "knowledge base, the one its profile names")
    ap.add_argument("--columns", nargs="+", default=None, metavar="PHRASE",
                    help="score phrases against the column index")
    args = ap.parse_args()

    if args.columns:
        if __package__:
            from .ambisql import Clarifier
        else:
            from ambisql import Clarifier
        clar = Clarifier(DbProfile.load(args.profile), llm=lambda s, u: "{}")
        idx = ColumnIndex.from_profile(clar.profile)
        if not idx.ready(clar):
            print("  column index unavailable: Qdrant or the embedding "
                  "model could not be reached")
            return
        n = min(idx.size(), 256)
        print(f"\n  {idx.collection}: {idx.size()} columns, "
              f"{idx.embed_model}, bar z >= {idx.bar(n):.2f}")
        for phrase in args.columns:
            print(f"\n  {phrase!r}")
            for t, c, sc, z in idx.standing(phrase, limit=n)[:5]:
                mark = "lead" if z >= idx.bar(n) else ""
                print(f"    {sc:.3f}  z {z:5.2f}  {t}.{c}  {mark}")
        return

    rec = Recall.from_profile(DbProfile.load(args.profile))
    print(f"\n  collection {rec.collection} at {rec.url}")
    if not rec.available():
        print("  not reachable. The pipeline will name tables with a model.")
        return
    if args.reset:
        print("  dropped" if rec.reset() else "  nothing to drop")
    if args.seed:
        data = json.loads(Path(args.seed).read_text(encoding="utf-8"))
        pairs = data if isinstance(data, list) else data.get("corpus", [])
        for p in pairs:                      # the demo corpus names them so
            p.setdefault("tables", p.get("expected_tables", []))
        print(f"  seeded {rec.seed(pairs)} questions")
    if args.seed_dictionary:
        # a knowledge base carries sample questions with their SQL, which
        # is exactly what the corpus holds: seeding from it needs no one to
        # write a corpus by hand
        if __package__:
            from . import dictionary
        else:
            import dictionary
        profile = DbProfile.load(args.profile)
        examples = dictionary.load(profile.descriptions)["examples"]
        if not examples:
            print(f"  {profile.descriptions or 'no dictionary'} holds no "
                  f"sample queries")
        else:
            print(f"  seeded {rec.seed(examples)} questions from "
                  f"{Path(profile.descriptions).name}")
    print(f"  {rec.size()} questions in the corpus")
    if args.ask:
        print(f"\n  question: {args.ask}   (minimum score "
              f"{corpus_min_score(rec.embed_model):.2f})")
        for score, payload in rec.neighbours(args.ask):
            mark = "used" if score >= corpus_min_score(rec.embed_model) else "too far"
            print(f"    {score:.3f} {mark:8} {payload.get('question','')[:52]}")
            print(f"            tables {payload.get('tables')}")
        print(f"\n  anchors -> {rec.anchors(args.ask) or 'nothing, a model will be asked'}")


if __name__ == "__main__":
    _cli()
