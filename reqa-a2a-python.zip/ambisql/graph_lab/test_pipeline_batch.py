"""Batch run of the whole pipeline, on two unrelated schemas.

The clarifier already has its own batch; this one measures the part
nobody had measured: what happens between a settled question and an
answer. It matters because the interesting number is not how often the
generator is right, it is **how often the checks catch it when it is
wrong**, and whether handing the verdict back actually rescues the next
attempt.

So the report counts three things that are usually left implicit:

  answered       the chain produced an answer the checks had approved
  saved by retry answer reached only after a rejection was fed back;
                 each one is a wrong query that never touched the data
  rejections     by gate, which says where the generator actually fails

Clarifications are resolved automatically by taking the first option, so
the batch never stalls waiting for a human. That is a measurement
convenience and nothing else: it is not how the product behaves.

    .venv/Scripts/python src/graph_lab/test_pipeline_batch.py
    .venv/Scripts/python src/graph_lab/test_pipeline_batch.py --profile datagora_lib
"""

import os

# the column index is on by default; a test never builds one in a real
# Qdrant, and the tests that need one give it directly
os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")

import argparse
import collections
import time

from db_profile import DbProfile
from llm import LLM
from pipeline import Pipeline

QUESTIONS = {
    "datagora_generic": [
        "how many products are there in each category",
        "total quantity on hand per warehouse city",
        "which suppliers provide products stored in the warehouse with code 'code 0001'",
        "average lead time in days per supplier",
        "products whose quantity is below their reorder level",
    ],
    "datagora_lib": [
        "how many books are there in each genre",
        "number of loans per member",
        "which authors wrote books borrowed by members",
        "how many books does each author have",
        "books that have never been borrowed",
    ],
}


def classify_rejection(detail):
    d = (detail or "").lower()
    if "dialect-ambiguous" in d or "concat" in d:
        return "dialect"
    if "no joins_on edge" in d or "join audit" in d or "wrong-keys" in d:
        return "join audit"
    if "multiplies rows" in d or "chasm" in d or "fan" in d:
        return "fan or chasm"
    if "cartesian" in d:
        return "EXPLAIN"
    if "refused" in d:
        return "MariaDB refused"
    if "no sql" in d or "empty" in d:
        return "empty answer"
    return "other"


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--profile", default=None)
    args = ap.parse_args()

    reasoner, sqlm = LLM.role("reasoner"), LLM.role("sql")
    for llm, role in ((reasoner, "reasoner"), (sqlm, "sql")):
        if not llm.reachable():
            raise SystemExit(f"{role} endpoint {llm.name} ({llm.url}) "
                             f"is unreachable")
    print(f"reasoner {reasoner.model}   sql {sqlm.model}\n")

    names = [args.profile] if args.profile else list(QUESTIONS)
    totals = collections.Counter()
    rejections = collections.Counter()
    t0 = time.time()

    for name in names:
        pipe = Pipeline(DbProfile.load(name))
        print(f"{'='*74}\n{name}\n{'='*74}")
        try:
            for q in QUESTIONS[name]:
                started = time.time()
                # a measure: nothing it answers goes into the corpus
                run = pipe.ask(q, remember=False)
                c = run.clarification
                asked = bool(c is not None and getattr(c, "options", None)
                             and not run.answer)
                if asked:                      # resolve and carry on
                    run = pipe.ask(q, c.options[0].label, remember=False)

                fails = [s for s in run.steps if not s.ok]
                for s in fails:
                    if "checks" in s.name or "generate" in s.name \
                            or s.name == "execute":
                        rejections[classify_rejection(s.detail)] += 1
                attempts = sum(1 for s in run.steps
                               if s.name.startswith("generate"))
                saved = bool(run.answer and attempts > 1)

                totals["asked"] += asked
                totals["answered"] += bool(run.answer)
                totals["saved"] += saved
                totals["failed"] += bool(not run.answer)
                totals["questions"] += 1

                mark = "answered" if run.answer else "NO ANSWER"
                extra = []
                if asked:
                    extra.append("clarified")
                if saved:
                    extra.append(f"saved on attempt {attempts}")
                tail = ("  [" + ", ".join(extra) + "]") if extra else ""
                print(f"  {mark:10} {time.time() - started:5.0f}s  "
                      f"{q[:56]}{tail}")
                if not run.answer:
                    print(f"             why: {run.failed[:120]}")
        finally:
            pipe.close()
        print()

    n = totals["questions"]
    print(f"{'='*74}")
    print(f"  questions                {n}")
    print(f"  answered end to end      {totals['answered']}/{n}")
    print(f"  needed a clarification   {totals['asked']}/{n}")
    print(f"  saved by a retry         {totals['saved']}"
          f"   (wrong queries the checks stopped before execution)")
    if rejections:
        print("  rejections by gate:")
        for gate, count in rejections.most_common():
            print(f"     {gate:18} {count}")
    else:
        print("  no rejection: every first attempt passed every gate")
    print(f"  {time.time() - t0:.0f}s total on {sqlm.model}")


if __name__ == "__main__":
    main()
