"""Runnable examples shipped with the graph_lab wheel."""
