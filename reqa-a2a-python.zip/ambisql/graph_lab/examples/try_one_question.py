"""Verify the installed package and ask one question end to end.

After installing the wheel, with the Qdrant client for complete():

    pip install "datagora_graph_lab-<version>-py3-none-any.whl[qdrant]"

run:

    python -m graph_lab.examples.try_one_question
    python -m graph_lab.examples.try_one_question --question "who are the oldest members"

Two ways to build the client are shown below. complete() passes every
service by hand: the two models, the schema graph (Neo4j), the corpus and
the column index (Qdrant) with their embedding model, the data dictionary,
and who asks. simple(), kept as a comment in main(), passes the fewest
parameters: the database and one model, with no graph and no corpus. Read
them side by side to see what each piece adds.

Every address can be changed through the environment, so the same file runs
on a laptop, in a container or against a team's own services:

    DATAGORA_MYSQL_HOST, DATAGORA_MYSQL_PORT, MYSQL_USER, MYSQL_PASSWORD
    DATAGORA_LLM_URL, DATAGORA_LLM_MODEL       the model server (Ollama)
    DATAGORA_EMBED_URL, EMBED_MODEL             the embedding model
    NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD
    QDRANT_URL, QDRANT_API_KEY

The defaults are the local Docker services and a model served by Ollama on
this machine. From inside a container, the host's Ollama is
http://host.docker.internal:11434.

Against a Qdrant shared with an application, set DATAGORA_REMEMBER=off and
DATAGORA_COLUMN_INDEX=off for a trial run: an answered question is written
into the corpus, and the column index builds its collection when it is
missing.
"""

import argparse
import os
from pathlib import Path

import graph_lab
from graph_lab import LLM, Datagora

HERE = Path(__file__).resolve().parent
MODEL_URL = os.environ.get("DATAGORA_LLM_URL", "http://192.168.2.129:11435")
MODEL = os.environ.get("DATAGORA_LLM_MODEL", "gemma3:latest")


def mysql_of(database):
    """The connection to the database the question is asked of."""
    return {
        "host": os.environ.get("DB_HOST", "192.168.2.128"),
        "port": int(os.environ.get("DB_PORT", "3306")),
        "database": database,
        "user": os.environ.get("DB_USER", "readonly_user"),
        "password": os.environ.get("DB_PASSWORD", ""),
    }


def model(name, url=MODEL_URL, model_name=MODEL):
    """A model served by Ollama, without any settings file."""
    return LLM(name, {"api": "ollama", "url": url, "model": model_name,
                      "num_ctx": 16384, "timeout": 600})


def simple(database):
    """The fewest parameters: the database and one model for both roles.

    No graph, so joins are not verified, and no corpus, so the tables of a
    question are found from the schema alone. Enough to see the client
    work."""
    local = model("local")
    return Datagora(mysql=mysql_of(database), reasoner=local, sql=local)


def complete(database):
    """Every parameter given by hand.

    - two models: the reasoner judges the question and writes the answer,
      the sql model writes the query; here the same server, two clients;
    - the schema graph in Neo4j, which imposes and audits the joins (built
      once per database with build_graph());
    - Qdrant, for the corpus of questions already answered and the column
      index, searched with an embedding model;
    - the data dictionary, the descriptions of the tables and columns;
    - suggestions when a question needs a choice or more detail, the judge,
      and who asks (location, timezone and the like)."""
    dictionary = HERE / "kb_library.json"
    return Datagora(
        mysql=mysql_of(database),
        name=database,
        reasoner=model("reasoner"),
        sql=model("sql"),
        neo4j_uri=os.environ.get("NEO4J_URI", "bolt://127.0.0.1:7687"),
        neo4j_user=os.environ.get("NEO4J_USER", "neo4j"),
        neo4j_password=os.environ.get("NEO4J_PASSWORD"),
        qdrant_url=os.environ.get("QDRANT_URL", "http://127.0.0.1:6333"),
        # None is the default, <database>_corpus
        qdrant_collection=os.environ.get("QDRANT_COLLECTION"),
        embed_url=os.environ.get("DATAGORA_EMBED_URL", MODEL_URL),
        embed_model=os.environ.get("EMBED_MODEL", "nomic-embed-text"),
        descriptions=str(dictionary) if database == "datagora_lib" and dictionary.exists() else None,
        reformulate=True,
        judge="single",
        context={"location": "Montreal", "timezone": "America/Toronto"},
    )


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument(
        "--question", default="how many books per genre",
        help="one natural-language question to ask")
    parser.add_argument(
        "--database", default="datagora_lib",
        help="local MySQL database (default: %(default)s)")
    parser.add_argument(
        "--choice",
        help="option label returned by an earlier ambiguous run")
    args = parser.parse_args(argv)

    imported_from = Path(graph_lab.__file__).resolve()
    print(f"graph_lab {graph_lab.__version__} imported from {imported_from}")
    print(f"Question: {args.question}")
    print(f"Model: {MODEL} at {MODEL_URL}")
    print("Running the pipeline; the model may take a moment...", flush=True)

    # the fewest parameters, to compare with complete():
    # with simple(args.database) as datagora:
    with complete(args.database) as datagora:
        result = datagora.ask(args.question, choice=args.choice)

    if result.failed:
        print(f"FAILED: {result.failed}")
        return 1

    if result.waiting or result.suggestions:
        print(f"Clarification needed: {result.clarifying or result.clarification}")
        for option in result.options:
            print(f"  option {option.label}: {getattr(option, 'means', '')}")
        for s in result.suggestions:
            print(f"  suggestion: {s.question}")
        print("Ask a suggestion as a new question, or run again with --choice and a label.")
        return 2

    if not result.answer:
        print(result.clarification or "The pipeline returned no answer.")
        return 2

    print(f"SQL: {result.sql}")
    print(f"Rows returned: {len(result.rows)}")
    print(f"Answer: {result.answer}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
