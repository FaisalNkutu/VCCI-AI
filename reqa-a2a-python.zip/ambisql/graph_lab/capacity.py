"""How much GPU memory a model server needs, and how many requests it fits.

Ported from black-jack's capacity panel, with the two corrections a
measurement forced on it. Both concern Gemma, which is the model this
engine is meant to run on.

First, the head dimension. black-jack takes it as embedding_length divided
by head_count, which is true of most architectures and false of Gemma:
Gemma declares its own, `attention.key_length` and `value_length`, and on
gemma3:4b that is 256 where the division gives 320. The KV cache came out
a quarter too large.

Second, sliding-window attention. On Gemma 3 five layers in six attend to
the last 1024 tokens only, so they hold 1024 tokens of cache whatever the
window. black-jack charged every layer the full window. Measured on
gemma3:4b at 16K, the whole model loaded in 2.58 GB, while the naive cache
alone came to 2.66 GB: without the window the weights would have had to
weigh 0.46 GB, which a 4B model at Q4 cannot. Ollama applies the window;
the estimate has to as well.

An estimate is still an estimate. Once a model is loaded, /api/ps reports
what it really occupies, and the page shows that figure over any computed
one. The estimate is for deciding before loading, and it errs large: when
the architecture's pattern is not known, every layer is charged the full
window.
"""

GB = 1024 ** 3

# bytes per cached element for each cache type Ollama accepts through
# OLLAMA_KV_CACHE_TYPE. q8_0 and q4_0 store a scale per block of 32, which
# is where the fractions come from.
KV_BYTES = {"f16": 2.0, "q8_0": 34 / 32, "q4_0": 18 / 32}

# one global-attention layer every N, for architectures whose GGUF does not
# say. Gemma 3 is five local to one global; Gemma 2 alternates. A model not
# listed here is charged the full window on every layer, which is the safe
# direction for a "does it fit" answer.
#
# Gemma 4 follows Gemma 3. Its 31B has 60 layers, 10 global and 50 on a
# 1024-token window, with 16 KV heads of 256; black-jack measured its cache
# on vLLM at 2.0 GB per request at 8K, 5.8 GB at 32K and 10.8 GB at 64K,
# and this pattern reproduces all three to the tenth of a gigabyte. The
# arithmetic that ignores the window would have charged 30 GB at 32K, more
# than the card it runs on.
#
# Mistral 7B from v0.2 on, Mistral Small and Mistral Nemo attend to the
# whole window on every layer and need no entry; their GGUF is labelled
# `llama`, which is not listed either, and is charged in full, correctly.
GLOBAL_EVERY = {"gemma4": 6, "gemma3": 6, "gemma3n": 6, "gemma2": 2}

# What a loaded model holds besides its weights and its cache: the compute
# buffers. Measured with flash attention, which llama.cpp turns on by itself
# on CUDA ("flash_attn = auto"): gemma4:31b on a Tesla, four requests at 16K,
# 197 + 141 MiB; gemma3:4b on a GTX 1060, four at 16K, 99 MiB. Without it the
# attention buffer grows with the window, 570 MiB for that same gemma3:4b. A
# floor and a share of the weights covers the three with a little to spare.
# It replaces a flat 10% of the weights, which charged gemma4:31b 1.85 GB of
# buffers where it uses 0.33.
COMPUTE_FLOOR = 0.25 * GB
COMPUTE_SHARE = 0.01

# The token embeddings stay in host memory however many layers go to the
# GPU ("CPU_Mapped model buffer"). In a Q4 or Q5 file they are Q6_K: for
# gemma4:31b, 262 144 tokens of 5376 values at 6.5625 bits, 1102.5 MiB, the
# figure its load log gives to the half megabyte.
Q6_K = 6.5625 / 8
EMBEDDING_BYTES = (("Q8", 34 / 32), ("BF16", 2.0), ("F16", 2.0), ("F32", 4.0))


def compute_bytes(weights_bytes):
    """The compute buffers of a model of this size, as a margin."""
    return int(COMPUTE_FLOOR + COMPUTE_SHARE * (weights_bytes or 0))


def cpu_weights_bytes(info, quantization=None):
    """The share of the weights that stays on the CPU, or None when the
    vocabulary size is not known (Ollama gives it only when asked verbosely)."""
    vocab = (info or {}).get("datagora.vocab_size")
    embedding = _get(info or {}, architecture(info), "embedding_length")
    if not (vocab and embedding):
        return None
    q = str(quantization or "").upper()
    per = next((b for marker, b in EMBEDDING_BYTES if q.startswith(marker)), Q6_K)
    return int(vocab * embedding * per)


def _get(info, arch, suffix):
    value = info.get(f"{arch}.{suffix}")
    return value if isinstance(value, (int, float)) and value > 0 else None


def architecture(info):
    return str((info or {}).get("general.architecture") or "")


def native_context(info):
    """The context length the model was trained for, from any key naming it."""
    for key, value in (info or {}).items():
        if key.endswith(".context_length") and isinstance(value, int):
            return value
    return None


# A layer on a sliding window holds the window and one batch more: llama.cpp
# keeps n_swa + n_ubatch cells. Measured on gemma3:4b at 16K, Ollama 0.30.10:
# "SWA KV cache, size = 1536 cells, 29 layers", for a window of 1024.
SWA_PAD = 512


def _list(info, arch, suffix):
    value = info.get(f"{arch}.{suffix}")
    return value if isinstance(value, list) and value else None


def _layers(info):
    """[(cached elements per token, on a window)] for each layer, and the window.

    Gemma 4 gives its layers different shapes, and says so per layer: on
    gemma4:31b the 50 windowed layers hold 16 KV heads of 256, the 10 global
    ones 4 heads of 512, given as arrays (attention.head_count_kv,
    attention.sliding_window_pattern) and as key_length / key_length_swa.
    Read as one shape for all, with the 32 query heads standing in for the
    KV heads Ollama leaves out unless asked verbosely, the cache came out at
    7 GB a request at 16K where the layers hold 1.3. A scalar is used for
    every layer, as for the older models."""
    arch = architecture(info)
    count = _get(info, arch, "block_count")
    heads = _get(info, arch, "attention.head_count")
    if not count:
        return None, None
    per_layer_kv = _list(info, arch, "attention.head_count_kv")
    kv = _get(info, arch, "attention.head_count_kv") or heads
    embedding = _get(info, arch, "embedding_length")
    fallback = (embedding // heads) if (embedding and heads) else None
    key = _get(info, arch, "attention.key_length") or fallback
    value = _get(info, arch, "attention.value_length") or key
    key_swa = _get(info, arch, "attention.key_length_swa") or key
    value_swa = _get(info, arch, "attention.value_length_swa") or value
    window = _get(info, arch, "attention.sliding_window")
    pattern = _list(info, arch, "attention.sliding_window_pattern")
    every = _get(info, arch, "attention.sliding_window_pattern") or GLOBAL_EVERY.get(arch)
    layers = []
    for i in range(int(count)):
        h = per_layer_kv[i] if per_layer_kv and i < len(per_layer_kv) else kv
        if pattern and i < len(pattern):
            windowed = bool(pattern[i])
        else:
            # one global layer every `every`, the last of each group
            windowed = bool(every) and (i + 1) % int(every) != 0
        windowed = windowed and bool(window)
        k, v = (key_swa, value_swa) if windowed else (key, value)
        if not (h and k and v):
            return None, None
        layers.append((int(h) * (int(k) + int(v)), windowed))
    return layers, window


def kv_bytes_per_token(info, cache_type="f16"):
    """Cache bytes for one token across all layers, before any window.

    Per layer, kv_heads x (key_length + value_length) x bytes per element,
    each layer with its own shape when the model gives one. The head size is
    the model's own when it declares one, and the division only when it
    does not."""
    layers, _window = _layers(info)
    if not layers:
        return None
    per = KV_BYTES.get(str(cache_type or "f16").lower(), KV_BYTES["f16"])
    return int(sum(elements for elements, _ in layers) * per)


def windowed_bytes(info, num_ctx, cache_type="f16", swa_pad=SWA_PAD):
    """The windowed layers' share of one request's cache.

    Ollama 0.32.1 leaves it out of the size /api/ps reports. Measured on
    gemma4:31b, four requests at 16K: /api/ps said 22 927 MiB, which is the
    weights (17 790), the global layers' cache (5 120) and a buffer, and
    left out the windowed layers' 4 800 MiB the load log lists; the card
    held about 28 000."""
    layers, window = _layers(info)
    if not layers or not num_ctx or not window or window >= num_ctx:
        return 0
    per = KV_BYTES.get(str(cache_type or "f16").lower(), KV_BYTES["f16"])
    local = min(int(num_ctx), int(window) + int(swa_pad))
    return int(sum(e for e, on_window in layers if on_window) * local * per)


def kv_bytes_for_context(info, num_ctx, cache_type="f16", swa_pad=SWA_PAD):
    """Cache bytes for one request at a given window, windowed layers included.

    Returns (bytes, how), where `how` says which rule was used so the page
    can say whether the figure accounts for a sliding window or charges
    every layer the whole context. `swa_pad` is what a windowed layer holds
    beyond its window, llama.cpp's batch; 0 for a server that keeps none."""
    layers, window = _layers(info)
    if not layers or not num_ctx:
        return None, "unknown"
    per = KV_BYTES.get(str(cache_type or "f16").lower(), KV_BYTES["f16"])
    windowed = sum(1 for _, on_window in layers if on_window)
    if not windowed or window >= num_ctx:
        return (int(sum(e for e, _ in layers) * per * num_ctx),
                "full window on every layer")
    local = min(int(num_ctx), int(window) + int(swa_pad))
    total = sum(e * (local if on_window else num_ctx) for e, on_window in layers) * per
    return int(total), (f"{windowed} of {len(layers)} layers keep only "
                        f"the last {int(window)} tokens")


def estimate(*, weights_bytes, info, num_ctx, parallel=1, vram_gb=None,
             cache_type="f16", quantization=None):
    """The footprint of one endpoint, and whether it fits the GPU behind it.

    `parallel` requests each hold their own cache, so the cache is charged
    once per slot and the weights once in all. With the GPU's memory
    declared, it also says how many requests could fit at this window,
    which is the number to set `parallel` and OLLAMA_NUM_PARALLEL to."""
    kv_session, how = kv_bytes_for_context(info, num_ctx, cache_type)
    parallel = max(1, int(parallel or 1))
    on_cpu = cpu_weights_bytes(info, quantization) if weights_bytes else None
    on_gpu = (weights_bytes - on_cpu if (weights_bytes and on_cpu and on_cpu < weights_bytes)
              else weights_bytes)
    out = {"kv_per_token_bytes": kv_bytes_per_token(info, cache_type),
           "kv_per_request_bytes": kv_session,
           "kv_rule": how,
           "cache_type": cache_type,
           "weights_bytes": weights_bytes,
           "weights_gpu_bytes": on_gpu,
           "weights_cpu_bytes": on_cpu,
           "overhead_bytes": compute_bytes(weights_bytes) if weights_bytes else None,
           "parallel": parallel,
           "num_ctx": num_ctx,
           "native_context": native_context(info),
           "total_bytes": None, "fits": None, "max_requests": None}
    if weights_bytes and kv_session:
        overhead = out["overhead_bytes"] or 0
        out["total_bytes"] = int(on_gpu + overhead + kv_session * parallel)
        if vram_gb:
            budget = int(float(vram_gb) * GB) - on_gpu - overhead
            out["max_requests"] = max(0, budget // kv_session)
            out["fits"] = out["total_bytes"] <= int(float(vram_gb) * GB)
    if out["native_context"] and num_ctx and num_ctx > out["native_context"]:
        out["warning"] = (f"the window {num_ctx} is larger than the "
                          f"{out['native_context']} tokens this model was "
                          f"trained for")
    return out


def loaded_state(ps_entry):
    """What a loaded model really occupies, from Ollama's /api/ps.

    This is measured, not estimated, and it is the figure to trust once it
    exists. The trap it catches is a model that no longer fits: Ollama
    moves the rest onto the CPU without failing, and generation drops to a
    token a second. black-jack flagged it only when nothing at all was on
    the GPU; a model half on the CPU is the more common case and far harder
    to notice, so it is measured as a share."""
    if not ps_entry:
        return None
    size = ps_entry.get("size") or 0
    vram = ps_entry.get("size_vram") or 0
    on_cpu = max(0, size - vram)
    return {"size_bytes": size, "vram_bytes": vram, "cpu_bytes": on_cpu,
            "cpu_share": (on_cpu / size) if size else 0.0,
            "context_length": ps_entry.get("context_length"),
            "expires_at": ps_entry.get("expires_at")}
