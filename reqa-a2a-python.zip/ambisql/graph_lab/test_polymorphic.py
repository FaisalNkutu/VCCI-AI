"""A column whose target depends on a type code (object_type, object_id),
read from the dictionary and the graph: never a foreign key, always shown
with the condition it holds under. No database, no Neo4j."""

import json
import os
import pathlib
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"
os.environ["DATAGORA_DATA_DIR"] = tempfile.mkdtemp(prefix="datagora-tests-")

import ambisql
import dictionary
import schema_graph


def rel(table, column, other, other_column, code=None, role="child_of"):
    r = {"role": role, "name": f"{table}_{other}", "related_table": other,
         "own_column": column, "related_column": other_column,
         "join_on": f"{table}.{column} = {other}.{other_column}",
         "cardinality": "Zero or One", "type": "Non-Identifying"}
    if code is not None:
        r.update(type="Polymorphic", when={"column": "object_type", "value": code})
    return r


def kb_file(relationships):
    tables = {
        "attachments": {"description": "files attached to an order or a ticket",
                        "columns": {"attachment_id": {}, "object_type": {}, "object_id": {},
                                    "uploaded_by": {}},
                        "relationships": relationships},
        "sales_orders": {"description": "orders", "columns": {"order_id": {}, "customer_id": {}}},
        "support_tickets": {"description": "tickets", "columns": {"ticket_id": {}}},
        "employees": {"description": "staff", "columns": {"employee_id": {}}},
    }
    d = tempfile.mkdtemp(prefix="kb-")
    path = pathlib.Path(d) / "kb.json"
    # the shape of a real knowledge base: the tables at the top level
    path.write_text(json.dumps(tables), encoding="utf-8")
    return str(path)


RELS = [rel("attachments", "object_id", "sales_orders", "order_id", "ORDER"),
        rel("attachments", "object_id", "support_tickets", "ticket_id", "TICKET"),
        rel("attachments", "uploaded_by", "employees", "employee_id")]


class DictionaryTests(unittest.TestCase):

    def test_every_target_is_kept_with_its_condition(self):
        kb = dictionary.load(kb_file(RELS))
        targets = kb["polymorphic"][("attachments", "object_id")]
        self.assertEqual([(t, c, a["when"]["value"]) for t, c, a in targets],
                         [("sales_orders", "order_id", "ORDER"),
                          ("support_tickets", "ticket_id", "TICKET")])

    def test_a_polymorphic_column_is_no_foreign_key(self):
        kb = dictionary.load(kb_file(RELS))
        self.assertNotIn(("attachments", "object_id"), kb["links"])
        # an ordinary relationship of the same table still is one
        self.assertIn(("attachments", "uploaded_by"), kb["links"])

    def test_a_target_written_twice_is_kept_once(self):
        kb = dictionary.load(kb_file(RELS + [RELS[0]]))
        self.assertEqual(len(kb["polymorphic"][("attachments", "object_id")]), 2)

    def test_written_from_the_parent_side_it_lands_on_the_child_column(self):
        parent_side = rel("sales_orders", "order_id", "attachments", "object_id",
                          "ORDER", role="parent_of")
        kb = dictionary.load(kb_file([parent_side]))
        self.assertIn(("attachments", "object_id"), kb["polymorphic"])


def clarifier(kb_path, edges=()):
    clar = ambisql.Clarifier.for_connection(lambda: None, "theirs", llm=object())
    clar._columns = {"attachments": [("attachment_id", "int"), ("object_type", "varchar"),
                                     ("object_id", "int"), ("uploaded_by", "int")],
                     "sales_orders": [("order_id", "int"), ("customer_id", "int")],
                     "support_tickets": [("ticket_id", "int")],
                     "employees": [("employee_id", "int")]}
    clar._keys = {("attachments", "attachment_id"), ("sales_orders", "order_id"),
                  ("support_tickets", "ticket_id"), ("employees", "employee_id")}
    clar._foreign_keys = {}
    clar._views = {}
    clar._samples = {}
    clar._graph_edges = list(edges)
    clar._meanings = dictionary.load(kb_path)
    return clar


class ClarifierTests(unittest.TestCase):

    def test_the_schema_shows_each_target_with_its_condition(self):
        blocks = clarifier(kb_file(RELS))._table_blocks()
        line = next(l for l in blocks["attachments"].splitlines() if "object_id" in l)
        self.assertIn("-> sales_orders.order_id when object_type = 'ORDER'", line)
        self.assertIn("-> support_tickets.ticket_id when object_type = 'TICKET'", line)

    def test_the_short_form_lists_every_target(self):
        short = clarifier(kb_file(RELS))._short_blocks()["attachments"]
        self.assertIn("object_id->sales_orders.order_id|support_tickets.ticket_id", short)

    def test_the_tables_it_reaches_count_as_joined(self):
        links = clarifier(kb_file(RELS)).table_links()
        self.assertIn("sales_orders", links["attachments"])
        self.assertIn("support_tickets", links["attachments"])

    def test_graph_edges_with_a_condition_are_polymorphic_too(self):
        edges = [("attachments", "object_id", "sales_orders", "order_id",
                  "attachments.object_type = 'ORDER'"),
                 ("attachments", "uploaded_by", "employees", "employee_id")]
        clar = clarifier(kb_file([]), edges)
        self.assertEqual(clar.polymorphic_links()[("attachments", "object_id")],
                         [("sales_orders", "order_id", "object_type = 'ORDER'")])
        # an ordinary graph edge is still read as a key, a conditional one is not
        links = clar._graph_links()
        self.assertIn(("attachments", "uploaded_by"), links)
        self.assertNotIn(("attachments", "object_id"), links)


class GraphTests(unittest.TestCase):

    def test_the_graph_keeps_conditions_beside_its_edges(self):
        rows = [{"f": "attachments", "lc": "object_id", "t": "sales_orders", "rc": "order_id",
                 "w": 1, "inf": False, "card": "N:1", "meaning": None,
                 "cond": "attachments.object_type = 'ORDER'"},
                {"f": "orders", "lc": "customer_id", "t": "customers", "rc": "customer_id",
                 "w": 1, "inf": False, "card": "N:1", "meaning": None, "cond": None}]

        class Session:
            def __enter__(self):
                return self

            def __exit__(self, *a):
                return False

            def run(self, query, **kw):
                return rows
        g = schema_graph.Graph(SimpleNamespace(session=Session))
        self.assertEqual(len(g.edges[0]), 8)        # what every reader unpacks
        self.assertEqual(g.conditions, {("attachments", "object_id", "sales_orders", "order_id"):
                                        "attachments.object_type = 'ORDER'"})


class BuildGraphTests(unittest.TestCase):

    def test_one_documented_edge_per_target_with_its_condition(self):
        import build_graph
        profile = SimpleNamespace(descriptions=kb_file(RELS))
        tables = ["attachments", "sales_orders", "support_tickets", "employees"]
        found = build_graph.documented(profile, tables, [], {"attachments": ("attachment_id",)})
        poly = [e for e in found if e["left_col"] == "object_id"]
        self.assertEqual(sorted((e["right"], e["condition"]) for e in poly),
                         [("sales_orders", "attachments.object_type = 'ORDER'"),
                          ("support_tickets", "attachments.object_type = 'TICKET'")])
        plain = [e for e in found if e["left_col"] == "uploaded_by"]
        self.assertEqual([e["condition"] for e in plain], [None])

    def test_the_condition_is_written_to_the_edge(self):
        import build_graph
        self.assertIn("r.condition    = e.condition", build_graph.WRITE_DOCUMENTED)


if __name__ == "__main__":
    unittest.main()


class SchemaViewTests(unittest.TestCase):

    def test_the_agent_finds_the_join_through_a_type_code(self):
        import verdict_tools
        clar = clarifier(kb_file(RELS))
        with patch.object(verdict_tools.SchemaView, "_read_flavour", staticmethod(lambda c: "mariadb")):
            view = verdict_tools.SchemaView(clar)
        paths = view.paths("attachments", "support_tickets")
        self.assertTrue(paths)
        self.assertIn("WHEN attachments.object_type = 'TICKET'", paths[0]["via"][0])


class AskJoinTests(unittest.TestCase):

    def test_ask_is_given_the_type_code_with_the_join(self):
        import pipeline
        pipe = pipeline.Pipeline.__new__(pipeline.Pipeline)
        pipe.clarifier = SimpleNamespace(columns={"attachments": [("object_id", "int")],
                                                  "sales_orders": [("order_id", "int")]})
        pipe.__dict__["graph"] = SimpleNamespace(
            edges=[("attachments", "object_id", "sales_orders", "order_id", 1, False, "N:1", None)],
            conditions={("attachments", "object_id", "sales_orders", "order_id"):
                        "attachments.object_type = 'ORDER'"})
        with patch.object(pipeline.Pipeline, "graph", property(lambda self: self.__dict__["graph"]),
                          create=True):
            joins = pipe.imposed_joins(["attachments", "sales_orders"])
            text = pipe.prompt_for_sql("attachments of orders", ["attachments", "sales_orders"], joins)
        self.assertEqual(joins[0]["condition"], "attachments.object_type = 'ORDER'")
        self.assertIn("attachments.object_id = sales_orders.order_id AND "
                      "attachments.object_type = 'ORDER'", text)
