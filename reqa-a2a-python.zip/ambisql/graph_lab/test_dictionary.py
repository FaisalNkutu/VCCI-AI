"""The data dictionary: both shapes, and what a knowledge base implies.

    python -m unittest test_dictionary
"""

import json
import os

# the column index is on by default; a test never builds one in a real
# Qdrant, and the tests that need one give it directly
os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
import tempfile
import unittest

import dictionary


def point_kb(children=False):
    """The shape of the production knowledge base: one parent entry whose
    ENUM column names two kinds, and whose relationships name two child
    tables, one row at most each. With `children`, the children have
    entries of their own; without, only their names say which is which."""
    kb = {"abs_point": {
        "label": "Absolute Point",
        "description": "Extension table. Use cat_code to classify records.",
        "columns": {
            "abs_point_id": {"description": "Absolute point identifier.",
                             "data_type": "INTEGER"},
            "cat_code": {"description": "Category code.", "data_type": "ENUM",
                         "allowed_values": {
                             "CARTPT": {"label": "CARTESIAN-POINT"},
                             "GEOGPT": {"label": "GEOGRAPHIC-POINT"}}},
            "name_txt": {"description": "Name", "data_type": "VARCHAR"}},
        "primary_key": "abs_point_id",
        "relationships": [
            {"role": "parent_of", "name": "abs_point_crts_point",
             "type": "Identifying", "related_table": "crts_point",
             "cardinality": "Zero Or One",
             "join_on": "abs_point.abs_point_id = crts_point.crts_point_id",
             "own_column": "abs_point_id", "related_column": "crts_point_id"},
            {"role": "parent_of", "name": "abs_point_geo_point",
             "type": "Identifying", "related_table": "geo_point",
             "cardinality": "Zero Or One",
             "join_on": "abs_point.abs_point_id = geo_point.geo_point_id",
             "own_column": "abs_point_id", "related_column": "geo_point_id"},
            {"role": "child_of", "name": "point_abs_point",
             "type": "Identifying", "related_table": "point",
             "cardinality": "Exactly One",
             "join_on": "abs_point.abs_point_id = point.point_id",
             "own_column": "abs_point_id", "related_column": "point_id"}],
        "sample_queries": [
            {"question": "How many Absolute Point records are there?",
             "sql": "SELECT COUNT(*) FROM abs_point;"}],
        "keywords": ["reference point", "abs_point"],
        "semantic": {"aliases": ["coordinate", "absolute point"]}}}
    if children:
        kb["crts_point"] = {"label": "Cartesian Point", "columns": {
            "crts_point_id": {"data_type": "INTEGER"}}}
        kb["geo_point"] = {"label": "Geographic Point", "columns": {
            "geo_point_id": {"data_type": "INTEGER"}}}
    return kb


class KnowledgeBaseTests(unittest.TestCase):

    def test_codes_labels_keys_and_joins_are_read(self):
        d = dictionary.parse(point_kb())
        self.assertEqual(d["enums"][("abs_point", "cat_code")],
                         {"CARTPT": "CARTESIAN-POINT",
                          "GEOGPT": "GEOGRAPHIC-POINT"})
        self.assertIn(("abs_point", "abs_point_id"), d["keys"])
        self.assertTrue(d["tables"]["abs_point"].startswith("Absolute Point."))
        self.assertEqual(d["columns"]["abs_point.name_txt"], "Name")
        # child_of as written, parent_of stored on the child's column
        self.assertEqual(d["links"][("abs_point", "abs_point_id")][:2],
                         ("point", "point_id"))
        self.assertEqual(d["links"][("geo_point", "geo_point_id")][:2],
                         ("abs_point", "abs_point_id"))
        self.assertIn("coordinate", d["aliases"]["abs_point"])
        self.assertNotIn("abs_point", d["aliases"]["abs_point"])
        self.assertEqual(d["examples"][0]["table"], "abs_point")

    def test_the_children_a_table_continues_in_are_read_not_guessed(self):
        # which tables continue abs_point's rows is stated by the
        # relationships; which CODE goes where is not, and is left to the
        # data, so nothing here links CARTPT to crts_point
        d = dictionary.parse(point_kb())
        self.assertEqual(d["children"]["abs_point"], {
            "crts_point": ("crts_point_id", "abs_point_id",
                           "abs_point.abs_point_id = crts_point.crts_point_id"),
            "geo_point": ("geo_point_id", "abs_point_id",
                          "abs_point.abs_point_id = geo_point.geo_point_id")})
        # abs_point is child_of point "Exactly One" and point has no entry,
        # so nothing proves the key-on-key shape: point gets no child
        self.assertNotIn("point", d["children"])

    def test_a_many_to_one_parent_is_no_subtype(self):
        # a book has exactly one genre; that does not make books a kind of
        # genre, whatever the genre codes are called
        kb = {"genres": {"columns": {
                  "genre_id": {"data_type": "INTEGER"},
                  "kind_code": {"data_type": "ENUM", "allowed_values": {
                      "BK": {"label": "BOOK"}, "MG": {"label": "MAGAZINE"}}}},
                  "primary_key": "genre_id"},
              "books": {"columns": {"genre_id": {"data_type": "INTEGER"}},
                        "primary_key": "book_id",
                        "relationships": [{
                            "role": "child_of", "related_table": "genres",
                            "cardinality": "Exactly One",
                            "type": "Non-Identifying",
                            "own_column": "genre_id",
                            "related_column": "genre_id"}]}}
        self.assertEqual(dictionary.parse(kb)["children"], {})

    def test_a_junction_is_no_child(self):
        # book_authors keys on a book AND an author: several rows per book.
        # Its reference is part of its key without being all of it, which
        # is what once listed it as a child of books.
        kb = {"books": {"columns": {"book_id": {"data_type": "INTEGER"}},
                        "primary_key": "book_id"},
              "book_authors": {
                  "columns": {"book_id": {"data_type": "INTEGER"},
                              "author_id": {"data_type": "INTEGER"}},
                  "primary_key": ["book_id", "author_id"],
                  "relationships": [{
                      "role": "child_of", "name": "books_book_authors",
                      "type": "Identifying", "related_table": "books",
                      "cardinality": "Exactly One",
                      "own_column": "book_id", "related_column": "book_id"}]}}
        self.assertEqual(dictionary.parse(kb)["children"], {})


class ShapeTests(unittest.TestCase):

    def test_the_short_shape_still_reads(self):
        d = dictionary.parse({"tables": {"Loans": "one row per loan"},
                              "columns": {"Loans.Fee": "late fee"}})
        self.assertEqual(d["tables"], {"loans": "one row per loan"})
        self.assertEqual(d["columns"], {"loans.fee": "late fee"})
        self.assertEqual(d["enums"], {})

    def test_an_unreadable_dictionary_is_an_empty_one(self):
        self.assertEqual(dictionary.load(None)["tables"], {})
        self.assertEqual(dictionary.load("no/such/file.json")["tables"], {})
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False,
                                         encoding="utf-8") as fh:
            fh.write("{not json")
        self.addCleanup(os.unlink, fh.name)
        self.assertEqual(dictionary.load(fh.name)["columns"], {})

    def test_a_file_is_read_like_the_data(self):
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False,
                                         encoding="utf-8") as fh:
            json.dump(point_kb(), fh)
        self.addCleanup(os.unlink, fh.name)
        self.assertIn("geo_point",
                      dictionary.load(fh.name)["children"]["abs_point"])


if __name__ == "__main__":
    unittest.main()
