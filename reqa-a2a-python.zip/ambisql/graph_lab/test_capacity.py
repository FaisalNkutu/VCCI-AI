"""GPU capacity arithmetic, checked against a measured load.

The reference is gemma3:4b as Ollama 0.30.10 reported it on a GTX 1060:
its GGUF metadata, and a model loaded at a 16 384-token window occupying
2.58 GB in all. No server is contacted."""

import os

# the column index is on by default; a test never builds one in a real
# Qdrant, and the tests that need one give it directly
os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")

import pathlib
import sys
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))

import capacity

GB = 1024 ** 3

# /api/show model_info for gemma3:4b, the keys that matter, as measured
GEMMA3_4B = {
    "general.architecture": "gemma3",
    "gemma3.block_count": 34,
    "gemma3.embedding_length": 2560,
    "gemma3.attention.head_count": 8,
    "gemma3.attention.head_count_kv": 4,
    "gemma3.attention.key_length": 256,
    "gemma3.attention.value_length": 256,
    "gemma3.attention.sliding_window": 1024,
    "gemma3.context_length": 131072,
}

# an architecture with no declared head size and no window
PLAIN = {
    "general.architecture": "llama",
    "llama.block_count": 32,
    "llama.embedding_length": 4096,
    "llama.attention.head_count": 32,
    "llama.attention.head_count_kv": 8,
    "llama.context_length": 131072,
}


# gemma4:31b as black-jack described it for vLLM, and as the fake GPU serves it
GEMMA4_31B = {
    "general.architecture": "gemma4",
    "gemma4.block_count": 60,
    "gemma4.attention.head_count": 32,
    "gemma4.attention.head_count_kv": 16,
    "gemma4.attention.key_length": 256,
    "gemma4.attention.value_length": 256,
    "gemma4.attention.sliding_window": 1024,
    "gemma4.context_length": 131072,
}

# mistral-small:24b, whose GGUF says `llama`: every layer, the whole window
MISTRAL_SMALL = {
    "general.architecture": "llama",
    "llama.block_count": 40,
    "llama.embedding_length": 5120,
    "llama.attention.head_count": 32,
    "llama.attention.head_count_kv": 8,
    "llama.attention.key_length": 128,
    "llama.attention.value_length": 128,
    "llama.context_length": 32768,
}


class ReferenceModelTests(unittest.TestCase):
    """Figures somebody measured, reproduced by the arithmetic."""

    def test_gemma4_31b_matches_what_vllm_reported(self):
        # black-jack, deploy/vllm: 2.0 GB at 8K, 5.8 GB at 32K, 10.8 at 64K.
        # vLLM keeps no batch beyond the window, hence swa_pad=0
        for window, measured in ((8192, 2.0), (32768, 5.8), (65536, 10.8)):
            kv, rule = capacity.kv_bytes_for_context(GEMMA4_31B, window, swa_pad=0)
            self.assertAlmostEqual(kv / GB, measured, delta=0.06,
                                   msg=f"{window} tokens")
            self.assertIn("50 of 60", rule)

    def test_ignoring_the_window_would_not_fit_the_card(self):
        # what the older arithmetic charged at 32K: every layer, full window
        full = capacity.kv_bytes_per_token(GEMMA4_31B) * 32768
        self.assertGreater(full / GB, 29)

    def test_one_31b_request_at_32k_fits_a_32gb_card_with_room(self):
        e = capacity.estimate(weights_bytes=18.6 * GB, info=GEMMA4_31B,
                              num_ctx=32768, parallel=1, vram_gb=32)
        self.assertTrue(e["fits"])
        # with buffers measured rather than a flat tenth of the weights
        self.assertEqual(e["max_requests"], 2)
        # at 16K there is room for two, which is what OLLAMA_NUM_PARALLEL=2
        # on that card would buy
        e16 = capacity.estimate(weights_bytes=18.6 * GB, info=GEMMA4_31B,
                                num_ctx=16384, parallel=2, vram_gb=32)
        self.assertTrue(e16["fits"])
        self.assertGreaterEqual(e16["max_requests"], 2)

    def test_mistral_is_charged_the_whole_window_on_every_layer(self):
        # 40 layers x 8 heads x (128 + 128) x 2 bytes = 160 KB per token
        per = capacity.kv_bytes_per_token(MISTRAL_SMALL)
        self.assertEqual(per, 40 * 8 * 256 * 2)
        kv, rule = capacity.kv_bytes_for_context(MISTRAL_SMALL, 32768)
        self.assertEqual(kv, per * 32768)                  # 5 GB at 32K
        self.assertIn("every layer", rule)


class RealGemma4Tests(unittest.TestCase):
    """gemma4:31b as Ollama 0.32.1 describes it when asked verbosely: its
    layers have two shapes, given one value a layer."""

    PATTERN = ([True] * 5 + [False]) * 10           # 50 windowed, 10 global
    INFO = {
        "general.architecture": "gemma4",
        "gemma4.block_count": 60,
        "gemma4.attention.head_count": 32,
        "gemma4.attention.head_count_kv": [16 if w else 4 for w in PATTERN],
        "gemma4.attention.key_length": 512, "gemma4.attention.value_length": 512,
        "gemma4.attention.key_length_swa": 256, "gemma4.attention.value_length_swa": 256,
        "gemma4.attention.sliding_window": 1024,
        "gemma4.attention.sliding_window_pattern": PATTERN,
        "gemma4.embedding_length": 5376,
        "gemma4.context_length": 262144,
    }

    def test_each_layer_is_charged_its_own_shape(self):
        kv, rule = capacity.kv_bytes_for_context(self.INFO, 16384, "q8_0")
        # 10 global x 4 heads x (512 + 512) x 16384 + 50 windowed x 16 heads
        # x (256 + 256) x (1024 + 512), at 34/32 bytes a value
        expected = (10 * 4 * 1024 * 16384 + 50 * 16 * 512 * 1536) * 34 / 32
        self.assertEqual(kv, int(expected))
        self.assertAlmostEqual(kv / GB, 1.29, delta=0.01)
        self.assertIn("50 of 60", rule)

    def test_the_arrays_left_out_would_have_said_seven_gigabytes(self):
        # Ollama without verbose: the arrays come back null, and the query
        # heads stood in for the KV heads, at the global head size everywhere
        short = {k: (None if isinstance(v, list) else v) for k, v in self.INFO.items()}
        kv, _ = capacity.kv_bytes_for_context(short, 16384, "q8_0")
        self.assertGreater(kv / GB, 6.5)

    # the load log of ollama-gpu0, Ollama 0.32.1 on a 32 GB Tesla, four
    # requests at 16K, cache f16, flash attention on: what each part holds
    MIB = 1024 ** 2
    LOG = {"gpu_weights": 17790.11, "cpu_weights": 1102.50, "global_kv": 5120.00,
           "windowed_kv": 4800.00, "buffers": 12.51 + 196.52 + 140.50}

    def info_with_vocab(self):
        return dict(self.INFO, **{"datagora.vocab_size": 262144})

    def test_the_card_holds_what_its_load_log_lists(self):
        weights = (self.LOG["gpu_weights"] + self.LOG["cpu_weights"]) * self.MIB
        e = capacity.estimate(weights_bytes=int(weights), info=self.info_with_vocab(),
                              num_ctx=16384, parallel=4, vram_gb=32, cache_type="f16",
                              quantization="Q4_K_M")
        # the embeddings left on the CPU, to the half megabyte
        self.assertAlmostEqual(e["weights_cpu_bytes"] / self.MIB, self.LOG["cpu_weights"], delta=0.5)
        # the cache, to the megabyte: 4 x (1280 global + 1200 windowed)
        self.assertEqual(e["kv_per_request_bytes"] * 4,
                         (self.LOG["global_kv"] + self.LOG["windowed_kv"]) * self.MIB)
        # in all, within half a percent and on the safe side
        real = (self.LOG["gpu_weights"] + self.LOG["global_kv"] + self.LOG["windowed_kv"]
                + self.LOG["buffers"]) * self.MIB
        self.assertGreaterEqual(e["total_bytes"], real)
        self.assertLess(e["total_bytes"] / real, 1.005)
        self.assertTrue(e["fits"])

    def test_what_ollama_leaves_out_of_its_figure(self):
        # /api/ps said 22 927 MiB: weights, global cache and a buffer, and
        # not the windowed layers' 4800 MiB
        hidden = capacity.windowed_bytes(self.INFO, 16384, "f16") * 4
        self.assertEqual(hidden, self.LOG["windowed_kv"] * self.MIB)

    def test_two_at_16k_fit_a_32gb_card_with_room(self):
        e = capacity.estimate(weights_bytes=int(18.5 * GB), info=self.INFO,
                              num_ctx=16384, parallel=2, vram_gb=32, cache_type="q8_0")
        self.assertTrue(e["fits"])
        self.assertGreaterEqual(e["max_requests"], 8)


class CapacityTests(unittest.TestCase):

    def test_gemma3_4b_cache_is_what_ollama_allocated(self):
        # the load log on the GTX 1060: 320 MiB for the 5 global layers at
        # 16384 cells, 174 MiB for the 29 windowed ones at 1536
        kv, rule = capacity.kv_bytes_for_context(GEMMA3_4B, 16384)
        self.assertEqual(kv, (320 + 174) * 1024 ** 2)
        self.assertIn("29 of 34", rule)

    def test_gemma_head_size_is_its_own_not_a_division(self):
        # black-jack divided embedding by heads: 2560 / 8 = 320. Gemma
        # declares 256. Per token: 34 layers x 4 kv heads x (256 + 256) x 2
        self.assertEqual(capacity.kv_bytes_per_token(GEMMA3_4B),
                         34 * 4 * (256 + 256) * 2)
        blackjack = 2 * 34 * 4 * (2560 // 8) * 2
        self.assertLess(capacity.kv_bytes_per_token(GEMMA3_4B), blackjack)

    def test_the_sliding_window_is_what_makes_the_measurement_possible(self):
        # measured: the whole model, weights and cache, 2.58 GB at 16K
        measured_total = 2.58 * GB
        full, how_full = capacity.kv_bytes_for_context(
            dict(GEMMA3_4B, **{"gemma3.attention.sliding_window": 0}), 16384)
        windowed, how = capacity.kv_bytes_for_context(GEMMA3_4B, 16384)
        # charging every layer the whole window leaves under half a GB for
        # the weights of a 4B model at Q4, which is impossible
        self.assertLess(measured_total - full, 0.6 * GB)
        # the windowed figure leaves a plausible two gigabytes for them
        self.assertGreater(measured_total - windowed, 1.8 * GB)
        self.assertIn("1024", how)
        self.assertIn("every layer", how_full)

    def test_without_a_known_pattern_every_layer_is_charged_in_full(self):
        # the safe direction for a "does it fit" answer
        per = capacity.kv_bytes_per_token(PLAIN)
        self.assertEqual(per, 32 * 8 * (128 + 128) * 2)       # 4096/32 = 128
        total, how = capacity.kv_bytes_for_context(PLAIN, 8192)
        self.assertEqual(total, per * 8192)
        self.assertIn("every layer", how)

    def test_a_window_wider_than_the_context_changes_nothing(self):
        total, _ = capacity.kv_bytes_for_context(GEMMA3_4B, 512)
        self.assertEqual(total, capacity.kv_bytes_per_token(GEMMA3_4B) * 512)

    def test_a_quantised_cache_is_smaller(self):
        f16 = capacity.kv_bytes_per_token(GEMMA3_4B, "f16")
        q8 = capacity.kv_bytes_per_token(GEMMA3_4B, "q8_0")
        q4 = capacity.kv_bytes_per_token(GEMMA3_4B, "q4_0")
        self.assertGreater(f16, q8)
        self.assertGreater(q8, q4)

    def test_each_request_holds_its_own_cache(self):
        one = capacity.estimate(weights_bytes=2 * GB, info=GEMMA3_4B,
                                num_ctx=16384, parallel=1)
        four = capacity.estimate(weights_bytes=2 * GB, info=GEMMA3_4B,
                                 num_ctx=16384, parallel=4)
        self.assertEqual(four["total_bytes"] - one["total_bytes"],
                         3 * one["kv_per_request_bytes"])

    def test_it_says_how_many_requests_the_gpu_can_take(self):
        e = capacity.estimate(weights_bytes=2 * GB, info=GEMMA3_4B,
                              num_ctx=16384, parallel=2, vram_gb=6)
        self.assertTrue(e["fits"])
        self.assertGreaterEqual(e["max_requests"], 2)
        tight = capacity.estimate(weights_bytes=5.8 * GB, info=GEMMA3_4B,
                                  num_ctx=16384, parallel=4, vram_gb=6)
        self.assertFalse(tight["fits"])

    def test_a_window_beyond_the_model_is_flagged(self):
        e = capacity.estimate(weights_bytes=GB, info=GEMMA3_4B,
                              num_ctx=262144)
        self.assertIn("warning", e)

    def test_unknown_metadata_says_so_rather_than_guessing(self):
        self.assertIsNone(capacity.kv_bytes_per_token({}))
        e = capacity.estimate(weights_bytes=GB, info={}, num_ctx=8192)
        self.assertIsNone(e["total_bytes"])
        self.assertEqual(e["kv_rule"], "unknown")

    def test_a_model_half_on_the_cpu_is_measured_as_a_share(self):
        # black-jack only flagged size_vram == 0; half on the CPU is the
        # common case and generation is already crawling by then
        state = capacity.loaded_state({"size": 20 * GB, "size_vram": 12 * GB})
        self.assertAlmostEqual(state["cpu_share"], 0.4)
        whole = capacity.loaded_state({"size": 2 * GB, "size_vram": 2 * GB})
        self.assertEqual(whole["cpu_share"], 0.0)
        self.assertIsNone(capacity.loaded_state(None))


if __name__ == "__main__":
    unittest.main(verbosity=2)
