"""The real verdict of each question: scripts/add_real_verdict.py, the
question files it keeps in step with the evaluation sets, and the readers
that take the column under its new name or its old one.

No database and no model.

    .venv/Scripts/python src/graph_lab/test_real_verdict.py
"""

import importlib.util
import io
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import unittest
from contextlib import redirect_stderr

os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

HERE = pathlib.Path(__file__).resolve().parent
REPO = HERE.parent.parent
BENCH = REPO / "docs" / "test_strategy" / "coverage_bench"
DATASETS = BENCH / "datasets"
if str(BENCH) not in sys.path:
    sys.path.append(str(BENCH))

import bench_common as bc  # noqa: E402

spec = importlib.util.spec_from_file_location("add_real_verdict",
                                              REPO / "scripts" / "add_real_verdict.py")
arv = importlib.util.module_from_spec(spec)
spec.loader.exec_module(arv)

DATASET = {
    "Q1": {"question": "How many books?", "expected": "ANSWERABLE", "also_accepted": []},
    "Q2": {"question": "The best authors", "expected": "NEEDS A CHOICE",
           "also_accepted": ["ANSWERABLE", "NEEDS MORE"]},
}

# every question file of the repository, with the set that holds its key
COMMITTED = [
    (HERE / "examples" / "questions_library.csv", "Library"),
    (HERE / "examples" / "questions_products.csv", "Warehouse"),
    (HERE / "examples" / "questions_enterprise.csv", "Enterprise"),
    (REPO / "docs" / "test_strategy" / "bench" / "targets" / "points" / "questions.csv", "Point"),
]


class MergeTests(unittest.TestCase):

    def test_both_columns_go_before_the_question(self):
        text = "id,theme,question\nQ1,stock,How many books?\nQ2,people,The best authors\n"
        out, changes = arv.merge(text, DATASET)
        self.assertEqual(out, "id,theme,real_verdict,also_accepted,question\n"
                              "Q1,stock,ANSWERABLE,,How many books?\n"
                              "Q2,people,NEEDS A CHOICE,ANSWERABLE | NEEDS MORE,The best authors\n")
        self.assertIn("column real_verdict added", changes)

    def test_a_second_run_changes_nothing(self):
        text = "id,question\nQ1,How many books?\nQ2,The best authors\n"
        once, _changes = arv.merge(text, DATASET)
        twice, _changes = arv.merge(once, DATASET)
        self.assertEqual(twice, once)

    def test_the_bom_the_crlf_and_a_missing_last_newline_are_kept(self):
        text = '\ufeffid,question,note\r\nQ1,How many books?,"a, b"\r\nQ2,The best authors,x'
        out, _changes = arv.merge(text, DATASET)
        self.assertTrue(out.startswith("\ufeffid,real_verdict,also_accepted,question,note\r\n"))
        self.assertIn('Q1,ANSWERABLE,,How many books?,"a, b"\r\n', out)
        self.assertTrue(out.endswith("The best authors,x"))
        self.assertNotIn("\n", out.replace("\r\n", ""))

    def test_an_old_column_is_renamed_in_place(self):
        text = "id,intended,question\nQ1,ANSWERABLE,How many books?\n"
        out, changes = arv.merge(text, DATASET)
        self.assertEqual(out, "id,real_verdict,also_accepted,question\n"
                              "Q1,ANSWERABLE,,How many books?\n")
        self.assertIn("column intended renamed real_verdict", changes)

    def test_also_accepted_written_otherwise_is_kept_as_written(self):
        text = ("id,question,expected,also_accepted\n"
                "Q2,The best authors,NEEDS A CHOICE,ANSWERABLE; NEEDS MORE\n")
        out, _changes = arv.merge(text, DATASET)
        self.assertEqual(out.splitlines()[1], "Q2,The best authors,NEEDS A CHOICE,ANSWERABLE; NEEDS MORE")

    def test_another_question_under_the_same_id_is_refused(self):
        text = "id,question\nQ1,How many loans?\nQ3,Who?\n"
        with self.assertRaises(arv.Refused) as caught:
            arv.merge(text, DATASET)
        self.assertEqual(len(caught.exception.problems), 2)
        self.assertIn("Q1: the file asks 'How many loans?'", caught.exception.problems[0])
        self.assertIn("Q3: not in the dataset", caught.exception.problems[1])

    def test_a_verdict_the_dataset_contradicts_is_refused(self):
        text = "id,expected,question\nQ1,NOT COVERED,How many books?\n"
        with self.assertRaises(arv.Refused) as caught:
            arv.merge(text, DATASET)
        self.assertIn("the file says NOT COVERED, the dataset ANSWERABLE",
                      caught.exception.problems[0])

    def test_a_refusal_writes_nothing(self):
        with tempfile.TemporaryDirectory() as tmp:
            csv_path = pathlib.Path(tmp) / "q.csv"
            data = pathlib.Path(tmp) / "d.jsonl"
            csv_path.write_bytes(b"id,question\r\nQ1,Something else\r\n")
            data.write_text(json.dumps({"id": "Q1", "question": "How many books?",
                                        "expected": "ANSWERABLE", "also_accepted": []}) + "\n",
                            encoding="utf-8")
            said = io.StringIO()
            with redirect_stderr(said):
                self.assertEqual(arv.main([str(csv_path), str(data)]), 1)
            self.assertIn("nothing written", said.getvalue())
            self.assertEqual(csv_path.read_bytes(), b"id,question\r\nQ1,Something else\r\n")


class CommittedFilesTests(unittest.TestCase):
    """The question files say what the evaluation sets say."""

    def test_every_file_is_up_to_date(self):
        for path, profile in COMMITTED:
            with self.subTest(path.name):
                text = path.read_bytes().decode("utf-8")
                merged, _changes = arv.merge(text, arv.read_dataset(DATASETS / f"{profile}.jsonl"))
                self.assertEqual(merged, text)
                self.assertIn("real_verdict", text.splitlines()[0])


class ReaderTests(unittest.TestCase):

    def test_the_bench_reads_the_new_name_and_the_old_one(self):
        self.assertEqual(bc.real_verdict({"real_verdict": "needs more"}), "NEEDS MORE")
        self.assertEqual(bc.real_verdict({"expected": "no data"}), "NO DATA")
        self.assertEqual(bc.real_verdict({}), "")
        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "k.csv"
            path.write_text("id,question,real_verdict,also_accepted\n"
                            "E37,q,NEEDS A CHOICE,ANSWERABLE | NEEDS MORE\n", encoding="utf-8")
            q = bc.read_questions(path)["E37"]
        self.assertEqual(q["expected"], "NEEDS A CHOICE")
        self.assertEqual(q["also_accepted"], ["ANSWERABLE", "NEEDS MORE"])


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class PageScoreTests(unittest.TestCase):
    """ui/accuracy.js, which the coverage page scores a run with, as rows
    arrive: also_accepted counts as right, UNKNOWN and the questions not
    judged yet are counted apart, and a run without real verdicts is null."""

    def score(self, rows, total):
        script = (f"const s = require({json.dumps(str(HERE / 'ui' / 'accuracy.js'))});"
                  f"process.stdout.write(JSON.stringify(s.score({json.dumps(rows)}, {total})));")
        done = subprocess.run(["node", "-e", script], capture_output=True, text=True, timeout=30)
        self.assertEqual(done.returncode, 0, done.stderr)
        return json.loads(done.stdout)

    def test_the_accuracy_of_a_run(self):
        rows = [
            {"verdict": "ANSWERABLE", "extra": {"real_verdict": "ANSWERABLE"}},
            {"verdict": "NEEDS A CHOICE", "extra": {"real_verdict": "ANSWERABLE",
                                                    "also_accepted": "NEEDS A CHOICE"}},
            {"verdict": "NOT COVERED", "extra": {"expected": "needs_more"}},
            {"verdict": "UNKNOWN", "extra": {"real_verdict": "ANSWERABLE"}},
            {"verdict": "ANSWERABLE", "extra": {"real_verdict": ""}},
        ]
        s = self.score(rows, 7)
        self.assertEqual((s["hits"], s["scored"], s["unknown"], s["pending"], s["unlabelled"]),
                         (2, 3, 1, 2, 1))
        self.assertAlmostEqual(s["accuracy"], 2 / 3)
        self.assertEqual(s["classes"]["ANSWERABLE"], {"hits": 2, "scored": 2, "unknown": 1})
        self.assertEqual(s["matrix"]["NEEDS MORE"], {"NOT COVERED": 1})
        self.assertEqual(s["accepted"], {"ANSWERABLE": {"NEEDS A CHOICE": 1}})
        self.assertEqual(s["real"], ["ANSWERABLE", "NEEDS MORE"])
        self.assertEqual(s["judged"], ["ANSWERABLE", "NEEDS A CHOICE", "NOT COVERED", "UNKNOWN"])

    def test_a_run_without_real_verdicts_scores_nothing(self):
        self.assertIsNone(self.score([{"verdict": "ANSWERABLE", "extra": {"id": "Q1"}}], 1))


if __name__ == "__main__":
    unittest.main()
