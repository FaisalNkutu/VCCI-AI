"""Thinking before answering, the cap on a reply, and the server's own
account of where a reply's time went.

gemma4:31b on Ollama 0.32 thinks before every reply unless the request says
otherwise; whether it does is a setting of each endpoint. No model, no
network: every request is answered by a stand-in for urlopen, which also
keeps what was sent. Nothing here depends on which way the default goes."""

import os

os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

import contextlib
import json
import pathlib
import sys
import unittest
from unittest.mock import patch

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "ui"))

import llm  # noqa: E402
import observability  # noqa: E402
import settings_store  # noqa: E402

OLLAMA = {"api": "ollama", "url": "http://gpu:11434", "model": "gemma4:31b"}
VLLM = {"api": "openai", "url": "http://gpu:8000", "model": "gemma-3-27b"}

# What Ollama 0.32 answers for one verdict with thinking on, its durations
# in nanoseconds; the figures are those of the measured 22.3 s request.
THOUGHT = {"model": "gemma4:31b", "done": True, "done_reason": "stop",
           "message": {"role": "assistant", "content": '{"kind": "none"}',
                       "thinking": "x" * 1856},
           "total_duration": 22_300_000_000, "load_duration": 120_000_000,
           "prompt_eval_count": 2210, "prompt_eval_duration": 1_400_000_000,
           "eval_count": 612, "eval_duration": 20_700_000_000}


class _Reply:
    def __init__(self, data):
        self.data = data

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def read(self):
        return json.dumps(self.data).encode("utf-8")


class _Server:
    """urlopen's stand-in: one reply for the chat, nothing loaded on
    /api/ps unless `loaded` names a window, a model that can think on
    /api/show (gemma4's capabilities), and every chat request body kept
    to be read back."""

    def __init__(self, reply, loaded=None):
        self.reply = reply
        self.loaded = loaded
        self.sent = []

    def __call__(self, req, timeout=None):
        # /api/ps is asked with a plain address, the others with a Request
        if getattr(req, "full_url", req).endswith("/api/ps"):
            return _Reply({"models": [] if self.loaded is None else [
                {"name": "gemma4:31b", "context_length": self.loaded}]})
        if req.full_url.endswith("/api/show"):
            return _Reply({"capabilities": ["completion", "vision", "tools", "thinking"]})
        self.sent.append(json.loads(req.data))
        return _Reply(self.reply)


def ask(cfg, reply, system="system", user="user", loaded=None, **kw):
    """(the model, its reply, the body it sent) for one chat."""
    server = _Server(reply, loaded)
    llm._THINKERS.clear()
    model = llm.LLM("a", cfg)
    with patch("urllib.request.urlopen", server):
        out = model.chat(system, user, **kw)
    return model, out, server.sent[-1]


class ThinkTests(unittest.TestCase):
    def test_the_request_says_what_the_endpoint_says(self):
        for value in (True, "true", "on", "1"):
            _m, out, sent = ask({**OLLAMA, "think": value}, THOUGHT)
            self.assertIs(sent["think"], True, value)
            self.assertEqual(out, '{"kind": "none"}')
        for value in (False, "false", "off", "0"):
            _m, _out, sent = ask({**OLLAMA, "think": value}, THOUGHT)
            self.assertIs(sent["think"], False, value)

    def test_the_request_always_says_it(self):
        # silent, Ollama 0.32 lets a model that can think do so, unbounded
        _m, _out, sent = ask(OLLAMA, THOUGHT)
        self.assertIn(sent["think"], (True, False))

    def test_an_openai_shaped_server_is_not_sent_it(self):
        reply = {"choices": [{"message": {"content": "{}"}, "finish_reason": "stop"}]}
        _m, _out, sent = ask({**VLLM, "think": True}, reply)
        self.assertNotIn("think", sent)


class ReplyCapTests(unittest.TestCase):
    def test_ollama_is_sent_a_cap(self):
        _m, _out, sent = ask(OLLAMA, THOUGHT)
        self.assertIsInstance(sent["options"]["num_predict"], int)
        self.assertGreater(sent["options"]["num_predict"], 0)

    def test_an_openai_shaped_server_is_sent_none(self):
        # vLLM refuses a prompt and a max_tokens that together pass its window
        reply = {"choices": [{"message": {"content": "{}"}, "finish_reason": "stop"}]}
        _m, out, sent = ask(VLLM, reply)
        self.assertEqual(out, "{}")
        self.assertNotIn("max_tokens", sent)
        self.assertNotIn("max_completion_tokens", sent)
        self.assertNotIn("options", sent)

    def test_a_reply_cut_at_the_cap_is_not_passed_on(self):
        # measured on Jarvis with a cap of 64: the thinking stops at 64
        # tokens, done_reason "length", and no answer at all
        cut = {**THOUGHT, "done_reason": "length", "eval_count": 4096,
               "message": {"role": "assistant", "content": '{"kind": "no'}}
        model, out, _sent = ask(OLLAMA, cut)
        self.assertIsNone(out)
        self.assertIn("tokens", model.last_error)
        self.assertIn(model.url, model.last_error)

    def test_a_caller_may_ask_for_less(self):
        _m, _out, sent = ask({**OLLAMA, "think": True}, THOUGHT, num_predict=1500)
        self.assertEqual(sent["options"]["num_predict"], 1500)
        _m, _out, sent = ask({**OLLAMA, "think": False}, THOUGHT, num_predict="700")
        self.assertEqual(sent["options"]["num_predict"], 700)

    def test_never_for_more_than_the_cap(self):
        _m, _out, sent = ask({**OLLAMA, "think": True}, THOUGHT, num_predict=50_000)
        self.assertEqual(sent["options"]["num_predict"], llm.LLM.MAX_THINKING_TOKENS)
        _m, _out, sent = ask({**OLLAMA, "think": False}, THOUGHT, num_predict=50_000)
        self.assertEqual(sent["options"]["num_predict"], llm.LLM.MAX_REPLY_TOKENS)

    def test_nor_for_no_bound_at_all(self):
        # Ollama reads -1 as "until the window is full"
        _m, _out, sent = ask(OLLAMA, THOUGHT, num_predict=-1)
        self.assertEqual(sent["options"]["num_predict"], 1)

    def test_a_json_call_passes_it_on(self):
        server = _Server(THOUGHT)
        llm._THINKERS.clear()
        with patch("urllib.request.urlopen", server):
            llm.LLM("a", OLLAMA).json("system", "user", num_predict=900)
        self.assertEqual(server.sent[-1]["options"]["num_predict"], 900)

    def test_a_reply_cut_at_a_smaller_bound_says_that_bound(self):
        cut = {**THOUGHT, "done_reason": "length", "eval_count": 1500}
        model, out, _sent = ask({**OLLAMA, "think": True}, cut, num_predict=1500)
        self.assertIsNone(out)
        self.assertIn("ran past 1500 tokens", model.last_error)


class OverflowTests(unittest.TestCase):
    """A reply whose thinking ran past the window: Ollama dropped the start
    of the prompt to write on, and what it wrote is not passed on."""

    # what was measured at full load: a schema of about 9 000 tokens left
    # some 7 400 for a thinking capped at 8 192
    FULL = {**THOUGHT, "prompt_eval_count": 9000, "eval_count": 7600}

    def test_a_reply_past_the_window_is_no_reply(self):
        model, out, _sent = ask({**OLLAMA, "think": True}, self.FULL)
        self.assertIsNone(out)
        self.assertIs(model.last_server["overflow"], True)
        self.assertIn("did not fit", model.last_error)
        for said in ("9000", "7600", "16384", "thinking included", model.url):
            self.assertIn(said, model.last_error)
        self.assertEqual(model.last_usage, {"prompt": 9000, "reply": 7600, "window": 16384})

    def test_also_when_gemma_stops_on_length(self):
        # the window full stops Gemma on "length" too: that is not a loop
        model, out, _sent = ask({**OLLAMA, "think": True},
                                {**self.FULL, "done_reason": "length"})
        self.assertIsNone(out)
        self.assertIn("did not fit", model.last_error)
        self.assertNotIn("looped", model.last_error)

    def test_a_reply_cut_under_the_window_still_looped(self):
        cut = {**THOUGHT, "done_reason": "length", "eval_count": 8192}
        model, out, _sent = ask({**OLLAMA, "think": True}, cut)
        self.assertIsNone(out)
        self.assertIn("looped", model.last_error)
        self.assertNotIn("did not fit", model.last_error)
        self.assertIs(model.last_server["overflow"], False)

    def test_the_window_is_the_one_loaded(self):
        reply = {**THOUGHT, "prompt_eval_count": 5000, "eval_count": 3500}
        model, out, _sent = ask({**OLLAMA, "think": True}, reply)
        self.assertEqual(out, '{"kind": "none"}')
        model, out, _sent = ask({**OLLAMA, "think": True}, reply, loaded=8192)
        self.assertIsNone(out)
        self.assertIn("8192-token window", model.last_error)

    def test_the_server_count_is_believed_over_the_estimate(self):
        # the estimate says about 10 000 tokens for this prompt, the server
        # counted 500: the server is right (0.32.1 counts a kept prefix too,
        # and the estimate overshoots prose), so 500 + 7000 fits
        system = "x" * 27_000
        reply = {**THOUGHT, "prompt_eval_count": 500, "eval_count": 7000}
        model, out, _sent = ask({**OLLAMA, "think": True}, reply, system=system)
        self.assertEqual(out, '{"kind": "none"}')
        self.assertEqual(model.last_usage["prompt"], 500)

    def test_the_estimate_stands_in_when_the_server_gives_no_count(self):
        system = "x" * 27_000
        reply = {**THOUGHT, "prompt_eval_count": 0, "eval_count": 7000}
        model, out, _sent = ask({**OLLAMA, "think": True}, reply, system=system)
        self.assertIsNone(out)
        self.assertIn("about 10001 tokens", model.last_error)

    def test_without_thinking_the_message_says_no_thinking(self):
        reply = {**self.FULL, "message": {"role": "assistant", "content": "{}"}}
        model, out, _sent = ask({**OLLAMA, "think": False}, reply)
        self.assertIsNone(out)
        self.assertIn("did not fit", model.last_error)
        self.assertNotIn("thinking", model.last_error)


class ServerTimingTests(unittest.TestCase):
    def test_where_the_time_went_is_read_from_the_reply(self):
        model, _out, _sent = ask({**OLLAMA, "think": True}, THOUGHT)
        self.assertEqual(model.last_server, {
            "load_seconds": 0.1, "prompt_seconds": 1.4, "reply_seconds": 20.7,
            "server_seconds": 22.3, "reply_tokens": 612, "thinking_chars": 1856,
            "done_reason": "stop", "overflow": False})
        self.assertEqual(model.last_prompt_tokens, 2210)

    def test_what_the_reply_took_of_the_window_is_kept(self):
        model, _out, _sent = ask({**OLLAMA, "think": True}, THOUGHT)
        self.assertEqual(model.last_usage, {"prompt": 2210, "reply": 612, "window": 16384})

    def test_a_failed_call_leaves_no_usage(self):
        model, _out, _sent = ask(OLLAMA, THOUGHT)

        def urlopen(req, timeout=None):
            raise TimeoutError("timed out")

        with patch("urllib.request.urlopen", urlopen):
            self.assertIsNone(model.chat("s", "u"))
        self.assertEqual(model.last_usage, {})

    def test_a_reply_without_thinking_has_no_thinking_count(self):
        plain = {**THOUGHT, "message": {"role": "assistant", "content": "{}"}}
        model, _out, _sent = ask({**OLLAMA, "think": False}, plain)
        self.assertNotIn("thinking_chars", model.last_server)

    def test_a_failed_call_leaves_no_timings_of_the_one_before(self):
        model, _out, _sent = ask(OLLAMA, THOUGHT)

        def urlopen(req, timeout=None):
            raise TimeoutError("timed out")

        with patch("urllib.request.urlopen", urlopen):
            self.assertIsNone(model.chat("s", "u"))
        self.assertEqual(model.last_server, {})

    def test_the_trace_is_given_them(self):
        recorded = {}

        class Obs:
            @contextlib.contextmanager
            def generation(self, **_kw):
                yield lambda **r: recorded.update(r)

        with patch.object(llm, "_tracing", lambda: (Obs(), None)):
            ask(OLLAMA, THOUGHT)
        self.assertEqual(recorded["reply_tokens"], 612)
        self.assertEqual(recorded["server"]["server_seconds"], 22.3)
        self.assertEqual(recorded["prompt_tokens"], 2210)
        self.assertIsNone(recorded["error"])

    def test_the_generation_counts_the_reply_tokens_as_output(self):
        updates = []

        class Handle:
            def update(self, **kw):
                updates.append(kw)

        class Span:
            def __enter__(self):
                return Handle()

            def __exit__(self, *a):
                return False

        class Client:
            def start_as_current_observation(self, **_kw):
                return Span()

        with patch.object(observability, "client", lambda: Client()):
            with observability.generation(endpoint="a", model="m", url="u",
                                          system="s", user="u") as record:
                record(output="{}", prompt_tokens=2210, reply_tokens=612,
                       server={"server_seconds": 22.3})
        self.assertEqual(updates[0]["usage_details"], {"input": 2210, "output": 612})
        self.assertEqual(updates[0]["metadata"]["server"], {"server_seconds": 22.3})


class SettingTests(unittest.TestCase):
    def test_the_settings_page_keeps_what_it_was_told(self):
        norm = settings_store._normalise_endpoint
        self.assertIs(norm({**OLLAMA, "think": True})["think"], True)
        self.assertIs(norm({**OLLAMA, "think": False})["think"], False)
        self.assertIs(norm({**OLLAMA, "think": "false"})["think"], False)
        self.assertIs(norm({**OLLAMA, "think": "on"})["think"], True)
        doc = settings_store.models_document({"endpoints": [
            {**OLLAMA, "id": "gpu", "think": True},
            {**OLLAMA, "id": "other", "think": False}], "roles": {}})
        self.assertTrue(llm.LLM("gpu", doc["endpoints"]["gpu"]).think)
        self.assertFalse(llm.LLM("other", doc["endpoints"]["other"]).think)

    def test_an_endpoint_that_never_said_takes_the_engines_default(self):
        # saved before the page offered the choice: nothing is written for
        # it, so the default of llm.py applies, whichever way it goes
        norm = settings_store._normalise_endpoint
        self.assertNotIn("think", norm({**OLLAMA}))
        self.assertNotIn("think", norm({**OLLAMA, "think": None}))
        self.assertNotIn("think", norm({**OLLAMA, "think": ""}))
        doc = settings_store.models_document({"endpoints": [
            {**OLLAMA, "id": "gpu"}], "roles": {}})
        self.assertEqual(llm.LLM("gpu", doc["endpoints"]["gpu"]).think,
                         llm.LLM("gpu", OLLAMA).think)

    def test_an_environment_endpoint_takes_its_own(self):
        env = {"DATAGORA_ENDPOINTS": "gpu_a,gpu_b,gpu_c",
               "DATAGORA_ENDPOINT_GPU_A_URL": "http://gpu:11434",
               "DATAGORA_ENDPOINT_GPU_A_MODEL": "gemma4:31b",
               "DATAGORA_ENDPOINT_GPU_A_THINK": "on",
               "DATAGORA_ENDPOINT_GPU_B_URL": "http://gpu:11435",
               "DATAGORA_ENDPOINT_GPU_B_MODEL": "gemma4:31b",
               "DATAGORA_ENDPOINT_GPU_B_THINK": "off",
               "DATAGORA_ENDPOINT_GPU_C_URL": "http://gpu:11436",
               "DATAGORA_ENDPOINT_GPU_C_MODEL": "gemma4:31b"}
        doc = llm.env_endpoints(env)
        self.assertTrue(llm.LLM("gpu_a", doc["endpoints"]["gpu_a"]).think)
        self.assertFalse(llm.LLM("gpu_b", doc["endpoints"]["gpu_b"]).think)
        self.assertNotIn("think", doc["endpoints"]["gpu_c"])


if __name__ == "__main__":
    unittest.main()
