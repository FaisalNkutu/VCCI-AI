"""The one place a database is described.

Every other module takes a DbProfile and reads nothing else about the
database it serves: no table name, no collection name, no connection
string appears in the logic. Serving one more database is an entry in
profiles.json, which is the property that makes the pipeline portable to
a customer's schema instead of tied to ours.

`name` doubles as the Neo4j namespace. Nodes carry `db: <name>`, so
several databases share one Neo4j instance without colliding and a
rebuild of one never touches another.

Secrets stay out: MySQL and Neo4j passwords are read from .env.
"""

import json
import os
from pathlib import Path
from typing import ClassVar

from pydantic import BaseModel, ConfigDict, Field

# resolved: imported through a sys.path entry such as "..", the parent of
# the parent was the package itself, and the repository's .env was missed
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent

# What every lookup says when nothing is configured. There used to be a
# packaged demo instead: two example databases on 127.0.0.1 with root/root,
# used whenever a deployment configured nothing. It made a clone run, and it
# made a production page answer from databases nobody there had named, with
# only an amber line to say so. Now nothing configured is said, and where to
# configure it.
NOTHING_CONFIGURED = (
    "no database is configured. List them in .env with DATAGORA_DATABASES "
    "and one block of DATAGORA_DB_<NAME>_* variables each (deploy/TESTING.md "
    "has a complete example), or add them on the settings page.")


def environment():
    """The environment, with the repository's .env underneath it.

    The real environment wins, so a container given its values by compose
    or a secret manager is never overridden by a file in a working copy.
    The .env fills what the environment does not set, which is what lets a
    script run from a clone read the same configuration the container gets.
    DATAGORA_DOTENV=off leaves the file out, which the tests do so that a
    developer's .env cannot change what they check."""
    values = {}
    if str(os.environ.get("DATAGORA_DOTENV", "on")).lower() not in (
            "off", "0", "false", "no"):
        # weakest first: the repository's, then the one where the program
        # is started, then the one DATAGORA_ENV_FILE names. Installed as a
        # package, the code sits in site-packages and the repository's
        # .env is nowhere near it; an application's own .env is in the
        # folder it runs from.
        files = [ROOT / ".env", Path.cwd() / ".env"]
        if os.environ.get("DATAGORA_ENV_FILE"):
            files.append(Path(os.environ["DATAGORA_ENV_FILE"]))
        seen = set()
        for env_file in files:
            try:
                key = env_file.resolve()
            except OSError:
                continue
            if key in seen or not env_file.is_file():
                continue
            seen.add(key)
            for line in env_file.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    v = v.strip().strip('"').strip("'")
                    if v:
                        values[k.strip()] = v
    values.update({k: v for k, v in os.environ.items() if v})
    return values


def _block_key(name):
    """DATAGORA_DB_<NAME>_ for a database called `name`: upper case, and
    anything that is not a letter or a digit written as an underscore."""
    return "".join(c if c.isalnum() else "_" for c in name).upper()


def _resolve(path_text):
    """A path from the configuration, found where it can be.

    Absolute is used as written. Relative is tried from the working folder,
    the repository and the package, in that order, so `examples/kb_library.json`
    names the same file from a clone and from the container, where the
    package is all there is."""
    if not path_text:
        return path_text
    path = Path(path_text)
    if path.is_absolute():
        return str(path)
    for base in (Path.cwd(), ROOT, HERE):
        if (base / path).exists():
            return str((base / path).resolve())
    return str(path)


def env_databases(env=None):
    """{name: profile} from the .env, or None when it lists no database.

        DATAGORA_DATABASES=warehouse,billing
        DATAGORA_DB_WAREHOUSE_HOST=db.internal
        DATAGORA_DB_WAREHOUSE_PORT=3306
        DATAGORA_DB_WAREHOUSE_DATABASE=warehouse
        DATAGORA_DB_WAREHOUSE_USER=reader
        DATAGORA_DB_WAREHOUSE_PASSWORD=...
        DATAGORA_DB_WAREHOUSE_DESCRIPTIONS=/config/kb_warehouse.json

    One block per database, everything about it in one place, which is how
    a production team writes its .env. Neo4j, Qdrant and the embedding model
    may be set once for all (NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD,
    QDRANT_URL, DATAGORA_EMBED_URL, EMBED_MODEL) and overridden in a block
    (DATAGORA_DB_WAREHOUSE_NEO4J_URI and so on). NEO4J_URI=off, globally or
    in a block, means no graph for that database."""
    env = environment() if env is None else env
    names = [n.strip() for n in (env.get("DATAGORA_DATABASES") or "").split(",")
             if n.strip()]
    if not names:
        return None
    out = {}
    for name in names:
        prefix = f"DATAGORA_DB_{_block_key(name)}_"

        def get(field, *shared, prefix=prefix):
            if env.get(prefix + field):
                return env[prefix + field]
            for key in shared:
                if env.get(key):
                    return env[key]
            return None

        port = get("PORT")
        try:
            port = int(port) if port else 3306
        except ValueError:
            raise SystemExit(f"{prefix}PORT is {port!r}, which is not a "
                             f"port number") from None
        mysql = {"host": get("HOST") or "127.0.0.1", "port": port,
                 "database": get("DATABASE") or name}
        if get("USER"):
            mysql["user"] = get("USER")
        if get("PASSWORD"):
            mysql["password"] = get("PASSWORD")
        cfg = {"mysql": mysql, "dialect": get("DIALECT") or "mysql"}
        for field, key, shared in (
                ("descriptions", "DESCRIPTIONS", ()),
                ("vocabulary", "VOCABULARY", ("DATAGORA_VOCABULARY",)),
                ("neo4j_uri", "NEO4J_URI", ("DATAGORA_NEO4J_URI", "NEO4J_URI")),
                ("neo4j_user", "NEO4J_USER", ("NEO4J_USER", "NEO4J_USERNAME")),
                ("neo4j_password", "NEO4J_PASSWORD", ("NEO4J_PASSWORD",)),
                ("neo4j_graph", "NEO4J_GRAPH", ()),
                ("qdrant_url", "QDRANT_URL", ("DATAGORA_QDRANT_URL", "QDRANT_URL")),
                ("qdrant_collection", "QDRANT_COLLECTION", ()),
                ("ollama_url", "EMBED_URL", ("DATAGORA_EMBED_URL",
                                             "DATAGORA_OLLAMA_URL", "OLLAMA_URL")),
                ("embed_model", "EMBED_MODEL", ("EMBED_MODEL",))):
            value = get(key, *shared)
            if value:
                cfg[field] = value
        if str(cfg.get("neo4j_uri", "")).strip().lower() in (
                "off", "none", "no", "disabled", "-"):
            cfg.pop("neo4j_uri", None)
        for field in ("descriptions", "vocabulary"):
            if cfg.get(field):
                cfg[field] = _resolve(cfg[field])
        out[name] = cfg
    return out


def env_profile():
    """The one database the environment describes, or None.

    The common deployment has a single database and does not need a file
    to say so. MYSQL_DATABASE is the trigger; the rest have sensible
    defaults. A `profiles.json` is for the case it cannot express: several
    databases offered side by side in the same page.

    Absent optional services mean exactly what they look like. No
    NEO4J_URI means no join graph, and the engine says so on every run
    rather than refusing to start.
    """
    env = environment()
    if env.get("DATAGORA_PROFILES") or env.get("DATAGORA_DATABASES"):
        # naming a file, or a list, is a deliberate act, and the only reason
        # to do it is to describe more than one database. Letting
        # MYSQL_DATABASE win here reduced several to whichever one the
        # environment happened to mention, without saying so.
        return None
    database = env.get("MYSQL_DATABASE")
    if not database:
        return None
    mysql = {"host": env.get("MYSQL_HOST") or "127.0.0.1",
             "port": int(env.get("MYSQL_PORT") or 3306),
             "database": database}
    cfg = {"name": env.get("DATAGORA_DB_NAME") or database,
           "mysql": mysql}
    # only what is set. A default address for a service nobody deployed
    # would be reported as unreachable rather than as unused.
    for key, field in (("NEO4J_URI", "neo4j_uri"),
                       ("NEO4J_USER", "neo4j_user"),
                       ("QDRANT_URL", "qdrant_url"),
                       ("QDRANT_COLLECTION", "qdrant_collection"),
                       ("OLLAMA_URL", "ollama_url"),
                       ("EMBED_MODEL", "embed_model")):
        value = env.get(key) or env.get(f"DATAGORA_{key}")
        if value:
            cfg[field] = value
    return cfg


def profiles_path():
    """The profiles file DATAGORA_PROFILES names, or a SystemExit saying
    that nothing is configured. There is no packaged file to fall back on
    any more; see NOTHING_CONFIGURED."""
    named = environment().get("DATAGORA_PROFILES")
    if not named:
        raise SystemExit(NOTHING_CONFIGURED)
    path = Path(named)
    if not path.is_file():
        # the alternative is a FileNotFoundError from three frames deeper,
        # which in a container reads like a broken package rather than a
        # mistyped path in one environment variable
        raise SystemExit(f"DATAGORA_PROFILES names {path}, which is not a "
                         f"readable file. Mount the file there, or list "
                         f"the databases in .env with DATAGORA_DATABASES.")
    return path


def _rewrite_loopback(url, host):
    """The same URL with a loopback host swapped for `host`, or unchanged.

    Only loopback is touched, never a real address, which is the rule that
    stopped a profile naming its own server being sent somewhere else."""
    if not url or not host:
        return url
    from urllib.parse import urlsplit, urlunsplit
    try:
        parts = urlsplit(url)
    except ValueError:
        return url
    if (parts.hostname or "").lower() not in DbProfile.LOOPBACK:
        return url
    netloc = host + (f":{parts.port}" if parts.port else "")
    return urlunsplit((parts.scheme, netloc, parts.path, parts.query,
                       parts.fragment))


def _settings_store():
    """The settings page's store, or None where it is not shipped.

    Imported the way every sibling is, as a package first. A bare
    `import settings_store` only worked when this folder was on sys.path,
    so an application importing graph_lab as a package silently ignored
    everything the settings page saved."""
    try:
        if __package__:
            from . import settings_store
        else:
            import settings_store
        return settings_store
    except ImportError:
        return None


def _saved_profiles():
    """The databases the settings page saved, or None when it saved none.

    First in every lookup, because configuring the page is the most
    deliberate act a deployment performs. None, and not an empty dict, when
    nothing is there: that is what hands the lookup back to the older
    sources so a clone and an existing deployment keep working."""
    settings_store = _settings_store()
    if settings_store is None:
        return None
    try:
        doc = settings_store.profiles_document()
    except Exception:
        return None
    return (doc or {}).get("profiles") or None


def profiles_source():
    """Where the databases on offer are actually being read from.

    Returns (description, missing): `missing` is True when nothing is
    configured at all, so a page can say so in the colour it deserves. It
    used to be (description, packaged), for a demo that no longer exists.

    The settings page comes first: a deployment is configured there, and
    what somebody changes on it must be what runs. It used to be the other
    way round, and a database added on the page was saved and then ignored
    because a .env on the same machine listed others. The .env serves when
    the page has no database, which is how the package runs without the
    page: from a script, a test, or another application.
    """
    if _saved_profiles() is not None:
        try:
            where = _settings_store().store_path()
        except Exception:
            where = "the settings file"
        return (f"the settings page ({where})", False)
    listed = env_databases()
    if listed:
        return (f"the .env (DATAGORA_DATABASES: {', '.join(listed)}), "
                f"since the settings page has no database", False)
    env = environment()
    if env.get("DATAGORA_PROFILES"):
        return (f"the file named by DATAGORA_PROFILES "
                f"({env['DATAGORA_PROFILES']})", False)
    if env.get("MYSQL_DATABASE"):
        return ("the environment (MYSQL_DATABASE and friends)", False)
    return ("nothing: " + NOTHING_CONFIGURED, True)


def _env(key, default=None):
    """The real environment first, then the repo .env, then the default.

    This order matters in production and used to be the other way round:
    a `.env` sitting in the repository outranked whatever the platform
    injected, so a container given its password by a secret manager
    silently used a developer's instead. A file checked into a working
    copy is the weakest source of truth there is, not the strongest.

    An empty value counts as unset, in both sources. Compose passes a
    variable it cannot resolve as an empty string, and treating that as an
    answer blanked the value it was supposed to default to.
    """
    value = environment().get(key)
    if value:
        return value
    if default is None:
        raise SystemExit(f"{key} not found in the environment or .env")
    return default


class DbProfile(BaseModel):
    """Where one database lives, and nothing about what is in it.

    Built from profiles.json, from a dict of credentials a caller
    already holds, or field by field. A key that belongs to no field is
    refused here rather than being silently ignored: a typo in a profile
    used to leave the default in place and send the pipeline at the
    wrong host with no sign that anything had been misread."""

    model_config = ConfigDict(extra="forbid")

    name: str
    mysql: dict
    dialect: str = "mysql"
    qdrant_collection: str | None = None
    neo4j_uri: str | None = None
    neo4j_user: str = "neo4j"
    # per database when a block of the .env sets one; otherwise the shared
    # NEO4J_PASSWORD. Never shown: repr leaves it out.
    neo4j_password: str | None = Field(default=None, repr=False)
    # which graph of the Neo4j server holds this database's joins: the
    # value of the `db` property its Table nodes carry. Unset, the
    # database's own name; "*" reads the whole graph, for a server that
    # holds one database and files its nodes under no name at all.
    neo4j_graph: str | None = None
    qdrant_url: str | None = None
    ollama_url: str | None = None
    embed_model: str = "nomic-embed-text"
    # an optional data dictionary: what each table and column MEANS, which
    # a schema cannot say. Names alone carry only what somebody managed to
    # fit in an identifier, and "fee", "sku" and "qty" carry almost
    # nothing. Absent, everything works exactly as before.
    descriptions: str | None = None
    # an optional vocabulary: the words this trade uses for a degree, added
    # to the engine's own. The engine ships 81 English adjectives that mark
    # a phrase as needing a threshold from the asker rather than a column
    # the schema lacks, and that list is what withholds the worst claim the
    # component makes. Measured on a shipments schema holding due_date,
    # "which shipments are overdue?" came back NOT COVERED because
    # `overdue` was not among them. Additive only: a word here can move a
    # verdict from NOT COVERED to NEEDS MORE and never the other way.
    vocabulary: str | None = None
    extra: dict = Field(default_factory=dict)

    # ---------------------------------------------------------- loading
    @classmethod
    def load(cls, name, path=None):
        if path is None:
            saved = _saved_profiles()
            if saved is not None:
                if name not in saved:
                    raise SystemExit(
                        f"unknown database {name!r}; the settings page "
                        f"offers {sorted(saved)}")
                cfg = {k: v for k, v in saved[name].items()
                       if not k.startswith("_")}
                # used as the page saved it. No environment variable may
                # replace a value: that is how one left in a compose file
                # used to override what somebody had typed, with nothing to
                # say it had happened. A relative file path is still found,
                # as for the .env: typed as examples/kb_points.json, it was
                # looked for in the server's working folder, missed, and the
                # knowledge base was never read.
                for key in ("descriptions", "vocabulary"):
                    if cfg.get(key):
                        cfg[key] = _resolve(cfg[key])
                profile = cls(name=name, **cfg)
                # Only a loopback address is redirected, as the page's Test
                # does: inside the container 127.0.0.1 is the container, and
                # the test said "connected" for a database every question
                # then failed to reach. A real address is left as typed.
                profile._rewrite_loopback_hosts()
                return profile
            listed = env_databases()
            if listed:
                if name not in listed:
                    raise SystemExit(
                        f"unknown database {name!r}; the .env lists "
                        f"{sorted(listed)} in DATAGORA_DATABASES")
                profile = cls(name=name, **listed[name])
                # written for the machine the .env sits on; inside a
                # container a loopback address is sent to the platform's
                # service, and nothing else is touched
                profile._rewrite_loopback_hosts()
                return profile
            single = env_profile()
            if single is not None:
                if name and name != single["name"]:
                    raise SystemExit(
                        f"unknown profile {name!r}; the environment "
                        f"describes {single['name']!r}. List several in "
                        f".env with DATAGORA_DATABASES to offer more than "
                        f"one database.")
                profile = cls(**single)
                profile._apply_env()
                return profile
        path = Path(path) if path else profiles_path()
        data = json.loads(path.read_text(encoding="utf-8"))["profiles"]
        if name not in data:
            raise SystemExit(f"unknown profile {name!r}; "
                             f"known: {sorted(k for k in data)}")
        cfg = {k: v for k, v in data[name].items() if not k.startswith("_")}
        for key in ("descriptions", "vocabulary"):
            named = cfg.get(key)
            if named and not Path(named).is_absolute():
                # a path written in a profiles file is read from where that
                # file is, so a mounted file finds the dictionary beside it
                cfg[key] = str((path.parent / named).resolve())
        profile = cls(name=name, **cfg)
        profile._apply_env()
        return profile

    # what "this machine" means, and therefore what a container has to
    # have rewritten for it
    LOOPBACK: ClassVar[set] = {"127.0.0.1", "localhost", "::1",
                               "0.0.0.0", ""}

    def _apply_env(self):
        """A loopback address, rewritten to where the service really is.

        Inside a container 127.0.0.1 is the container, so a profile
        written for a laptop points at nothing. Compose sets
        DATAGORA_MYSQL_HOST and loopback becomes the service name.

        Only loopback, and this is the important part. Applied to every
        profile it silently redirected a deployment that named its own
        server: a profile saying `db.internal` was sent to whatever the
        variable held, and the error that came back was `Unknown database`
        from the wrong host rather than anything about db.internal. A real
        address, a server or a hostname, is left exactly as written. This
        is the same rule host_gateway applies to model endpoints, for the
        same reason.
        """
        self._rewrite_loopback_hosts(services=False)
        neo4j = (os.environ.get("DATAGORA_NEO4J_URI")
                 or os.environ.get("NEO4J_URI") or "")
        if neo4j.strip().lower() in ("off", "none", "no", "disabled", "-"):
            self.neo4j_uri = None
        elif neo4j:
            self.neo4j_uri = neo4j
        self.qdrant_url = (os.environ.get("DATAGORA_QDRANT_URL")
                           or os.environ.get("QDRANT_URL")
                           or self.qdrant_url)
        self.qdrant_collection = (os.environ.get("QDRANT_COLLECTION")
                                   or self.qdrant_collection)
        self.descriptions = (os.environ.get("DATAGORA_DESCRIPTIONS")
                             or self.descriptions)
        self.vocabulary = (os.environ.get("DATAGORA_VOCABULARY")
                           or self.vocabulary)
        self.ollama_url = (os.environ.get("DATAGORA_OLLAMA_URL")
                           or os.environ.get("OLLAMA_URL")
                           or self.ollama_url)
        self.embed_model = (os.environ.get("EMBED_MODEL")
                            or self.embed_model)
        self.neo4j_user = (os.environ.get("NEO4J_USER")
                           or self.neo4j_user)
        self._rewrite_loopback_hosts(mysql=False)

    def _rewrite_loopback_hosts(self, mysql=True, services=True):
        """Loopback addresses sent to where the service really is, and
        nothing else touched. DATAGORA_MYSQL_HOST, DATAGORA_NEO4J_HOST and
        DATAGORA_QDRANT_HOST name them; compose sets them to the platform's
        service names, so a .env written for the laptop works unchanged in
        the container."""
        if mysql:
            host = os.environ.get("DATAGORA_MYSQL_HOST")
            if host and str(self.mysql.get("host", "")).lower() in self.LOOPBACK:
                self.mysql = dict(self.mysql, host=host)
            port = os.environ.get("DATAGORA_MYSQL_PORT")
            if port and host and str(self.mysql.get("host", "")) == host:
                # the port belongs to the address that was rewritten;
                # forcing it onto a foreign host would move a profile to a
                # port its own configuration never mentioned
                self.mysql = dict(self.mysql, port=int(port))
        if services:
            # The rule MySQL follows, for the two other services: an address
            # written for "this machine" is pointed at the service that
            # really answers, and an address naming a real server is left
            # alone. Inside a container bolt://127.0.0.1:7687 is the
            # container itself.
            self.neo4j_uri = _rewrite_loopback(
                self.neo4j_uri, os.environ.get("DATAGORA_NEO4J_HOST"))
            self.qdrant_url = _rewrite_loopback(
                self.qdrant_url, os.environ.get("DATAGORA_QDRANT_HOST"))
            # the embedding model is a model server like the others, on this
            # machine: left as 127.0.0.1, every question vector failed inside
            # the container, the corpus found nothing, and no line said so
            self.ollama_url = _rewrite_loopback(
                self.ollama_url, os.environ.get("DATAGORA_HOST_GATEWAY"))

    @classmethod
    def names(cls, path=None):
        """The databases on offer, in the order of profiles_source. Empty,
        not an error, when nothing is configured: a page lists nothing and
        says why, a command line says why when a name is asked for."""
        if path is None:
            saved = _saved_profiles()
            if saved is not None:
                return sorted(saved)
            listed = env_databases()
            if listed:
                return list(listed)
            single = env_profile()
            if single is not None:
                return [single["name"]]
            if not environment().get("DATAGORA_PROFILES"):
                return []
        path = Path(path) if path else profiles_path()
        data = json.loads(path.read_text(encoding="utf-8"))["profiles"]
        return sorted(data)

    # ------------------------------------------------------ connections
    def connect_mysql(self, user=None, password=None):
        import pymysql
        # no default credential of any kind. root/root belonged to a demo
        # that no longer exists, and on a host that refused it "Access
        # denied for user 'root'" read as a wrong password when the truth
        # was that none had been given.
        return pymysql.connect(
            host=self.mysql.get("host", "127.0.0.1"),
            port=self.mysql.get("port", 3306),
            user=(user or self.mysql.get("user") or _env("MYSQL_USER")),
            password=(password or self.mysql.get("password")
                      or _env("MYSQL_PASSWORD", "")),
            database=self.mysql["database"])

    def connect_neo4j(self, timeout=None):
        """A driver for the graph. `timeout`, in seconds, bounds reaching
        the server, for a caller that can do without the graph and should
        not wait the driver's own thirty seconds to find it is down."""
        if not self.neo4j_uri:
            raise RuntimeError("Neo4j is not configured for this database")
        from neo4j import GraphDatabase
        password = self.neo4j_password or _env("NEO4J_PASSWORD", "")
        extra = {"connection_timeout": timeout} if timeout else {}
        return GraphDatabase.driver(
            self.neo4j_uri,
            auth=(self.neo4j_user, password) if password else None, **extra)

    @property
    def schema(self):
        """The MySQL schema name, which is what information_schema keys on."""
        return self.mysql["database"]

    @property
    def graph_key(self):
        """What this database's join graph is filed under in Neo4j.

        The graph chosen for it on the settings page, or the database's own
        name: not the name it is shown by, so a database renamed on the
        page keeps its joins. "*" is the whole graph, unfiltered."""
        return (self.neo4j_graph or "").strip() or self.schema
