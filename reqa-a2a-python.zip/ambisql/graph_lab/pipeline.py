"""The whole journey, from a question in plain words to an answer in plain
words, with everything technical kept inside.

The user never sees a column name unless they ask for it, and the models
never see a vague sentence. Between the two ends the question is made
precise, the joins are imposed by the graph rather than guessed, the SQL
is judged before it runs, and it runs read-only.

    question
      1  clarify        reasoner, options checked against the live schema
      2  anchors        reasoner names tables, the schema confirms them
      3  imposed joins  Neo4j, shortest paths between the anchors
      4  generate       the SQL specialist, given the joins, nothing to invent
      5  dialect lint   SQLite habits that MariaDB would run silently wrong
      6  join audit     every pair must be an edge; fan and chasm rules
      7  EXPLAIN        cartesian products, before touching data
      8  execute        read-only, in a transaction that is rolled back
      9  answer         reasoner turns rows back into a sentence
    answer

Steps 5 to 7 reject rather than warn, and their verdict is handed back to
the SQL model as the next attempt's instruction. That loop is the reason
the generator never has to be trusted: it has to be checkable.

    .venv/Scripts/python src/graph_lab/pipeline.py \
        --profile datagora_lib --question "how many books per genre?"
"""

import threading
import argparse
import dataclasses
import os
import re
import time

from pydantic import BaseModel, ConfigDict, Field

if __package__:
    from .ambisql import Clarifier
    from .db_profile import DbProfile
    from .dialect_lint import repair_message
    from .context import describe as describe_context
    from .context import earlier_note
    from .context import moment as context_moment
    from .context import resolve as resolve_context
    from .context import today as context_today
    from .llm import LLM
    from .observability import Span, current_trace_id, flush, get_logger, prompt, trace_url
    from .recall import Recall
    from .reformulate import enabled as reformulate_enabled
    from .reformulate import headline, needs, suggest
    from .schema_graph import Graph, judge_sql
else:
    from ambisql import Clarifier
    from db_profile import DbProfile
    from dialect_lint import repair_message
    from context import describe as describe_context
    from context import earlier_note
    from context import moment as context_moment
    from context import resolve as resolve_context
    from context import today as context_today
    from llm import LLM
    from observability import Span, current_trace_id, flush, get_logger, prompt, trace_url
    from recall import Recall
    from reformulate import enabled as reformulate_enabled
    from reformulate import headline, needs, suggest
    from schema_graph import Graph, judge_sql

log = get_logger("pipeline")

MAX_ATTEMPTS = 3
MAX_ROWS = 50
# the agent on Ask answers one person waiting at a page: fewer turns, a
# shorter limit and thinking to plan and conclude only, each moved by its
# variable (DATAGORA_ASK_AGENT_MAX_TURNS, _MAX_SECONDS, _THINK)
ASK_AGENT = {"max_turns": 5, "max_seconds": 180.0, "think": "plan_conclude"}
# the agent's verdicts kept per question, so a choice is read off the very
# options the asker saw rather than a second exploration of minutes
KEPT_VERDICTS = 64
# and the last few of each: two people asking the same question at once
# may each be offered their own options
KEPT_PER_QUESTION = 4
_KEPT = threading.Lock()
# a graph that could not be reached is tried again after this long
GRAPH_RETRY_SECONDS = 60

# the prompts live in prompts.py, which imports nothing, so the light
# surfaces can use them without pulling the engine in. Re-exported
# here because this is where they used to be.
if __package__:
    from .prompts import ANCHOR_SYSTEM, ANSWER_SYSTEM, SQL_SYSTEM
else:
    from prompts import ANCHOR_SYSTEM, ANSWER_SYSTEM, SQL_SYSTEM


class _EmptyGraph:
    """Stands in for the join graph when Neo4j is not there.

    It answers every question with "I know of no edge", and the pipeline
    reads that as "joins were not verified" rather than "this join is
    wrong": an absent graph must never produce a rejection, only a
    stated gap. The interface matches Graph exactly so nothing
    downstream needs to know which one it holds."""

    edges = ()

    def edge_between(self, *_):
        return None

    def tables_linked(self, *_):
        return False

    def force_union_subschema(self, anchors):
        return sorted(anchors)

    def fine_side(self, *_):
        return set()


class Step(BaseModel):
    """One step of the journey, as the page and the trace see it."""

    model_config = ConfigDict(extra="forbid", arbitrary_types_allowed=True)

    name: str
    ok: bool
    detail: str = ""
    data: object = None


class Run(BaseModel):
    """Everything one question produced, including how it got there.

    `arbitrary_types_allowed` because two fields hold objects rather
    than data: the clarification comes from the clarifier and `on_step`
    is a callback. Both are deliberately opaque here."""

    model_config = ConfigDict(extra="forbid", arbitrary_types_allowed=True)

    question: str
    profile: str
    steps: list = Field(default_factory=list)
    technical_question: str = ""
    sql: str = ""
    rows: list = Field(default_factory=list)
    columns: list = Field(default_factory=list)
    answer: str = ""
    clarification: object = None
    # when the run stops for the asker (NEEDS A CHOICE, NEEDS MORE): the
    # clarifying sentence in plain words, and the questions they can pick
    # instead, as {"question", "choice", "note", "blank"}. Empty when the
    # switch is off or the run did not stop for them (reformulate.py).
    clarifying: str = ""
    suggestions: list = Field(default_factory=list)
    failed: str = ""
    trace_id: str = ""
    trace_url: str = ""
    # "corpus" when the anchors came from questions already
    # answered, "model" when none was close enough
    anchor_source: str = ""
    # who asked and when (context.resolve): what the models were told
    context: dict = Field(default_factory=dict)
    # what was decided before this question (context.earlier_note), and
    # the tables the judge found for it, for the question that follows
    earlier: str = ""
    judged_tables: list = Field(default_factory=list)
    # the verified questions and their SQL shown to the SQL generator,
    # as {"question", "sql", "score", "source"}
    examples: list = Field(default_factory=list)
    # the corpus point this answer was remembered as (Recall.remember), ""
    # when it was not: what deleting it from the history takes out
    remembered: str = ""
    # how many rows the query really matches, which is not len(rows)
    # once the ceiling has bitten. None when it could not be counted.
    total_rows: object = None
    # called with each Step as it happens, so a caller can show progress
    # while the journey is still running. A question takes tens of
    # seconds; a page that says nothing for that long looks broken.
    on_step: object = None

    def add(self, name, ok, detail="", data=None):
        step = Step(name=name, ok=ok, detail=detail, data=data)
        self.steps.append(step)
        if self.on_step is not None:
            try:
                self.on_step(step)
            except Exception:
                pass            # a watcher must never break the answer
        return self


def strip_sql(text):
    """The statement out of whatever the model wrapped it in."""
    if not text:
        return ""
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL | re.IGNORECASE)
    fences = re.findall(r"```(?:sql)?\s*(.*?)```", text, flags=re.DOTALL | re.IGNORECASE)
    if fences:
        text = fences[-1]
    m = re.search(r"\b(WITH|SELECT)\b", text, flags=re.IGNORECASE)
    text = text[m.start():] if m else text
    return text.strip().rstrip(";").strip()


class Pipeline:
    def __init__(self, profile, reasoner=None, sql_llm=None, reformulate=None, judge=None,
                 context=None):
        self.profile = profile
        self.reasoner = reasoner or LLM.role("reasoner")
        self.sql_llm = sql_llm or LLM.role("sql")
        self.clarifier = Clarifier(profile, self.reasoner)
        # whether a run that stops for the asker comes back with questions
        # they can pick: True or False forces it, None reads
        # DATAGORA_REFORMULATE at each question, which is what lets the
        # settings page switch it without rebuilding the pipeline
        self.reformulate = reformulate
        # who decides whether a question is clear: "single" (the one call
        # and its checks) or "agent" (the judge that explores the database,
        # verdict_agent); None reads DATAGORA_ASK_JUDGE at each question
        self.judge = judge
        # who asks and when (context.py): None, the machine's at each
        # question; a dict of static facts over it; a callable; False, none
        self.context = context
        self._agent = None
        self._verdicts = {}
        self._driver = None
        self._graph = None
        self._recall = None
        self._sql_prompt = None
        self._answer_prompt = None

    @property
    def graph(self):
        """The join graph, or an empty one when Neo4j is absent.

        Neo4j is required for the join guarantees and for nothing else:
        the clarifier reads information_schema and real column values, so
        it works on a MySQL connection alone. Rather than refuse to start,
        the pipeline degrades: without a graph it still clarifies,
        generates, lints the dialect, runs EXPLAIN and executes read-only,
        and every run says plainly that joins were not verified. That is
        what lets a team adopt this with one connection string and add
        the graph when they want the rest."""
        failed = getattr(self, "_graph_failed", None)
        if isinstance(self._graph, _EmptyGraph) and failed is not None \
                and time.monotonic() - failed > GRAPH_RETRY_SECONDS:
            # Neo4j still booting at the first question used to leave every
            # later one with joins not checked until a restart (review of
            # 26 October): it is tried again after a while
            self._graph = None
        if self._graph is None:
            if self._driver is not None:
                # the one that failed, closed before the next: one a minute
                # leaked while Neo4j was down (review of the fixes)
                try:
                    self._driver.close()
                except Exception:
                    pass
                self._driver = None
            try:
                self._driver = self.profile.connect_neo4j()
                self._graph = Graph.from_profile(self.profile, self._driver)
                self._graph_failed = None
            except Exception as e:
                self.graph_error = str(e)[:120]
                self._graph = _EmptyGraph()
                self._graph_failed = time.monotonic()
        return self._graph

    @property
    def has_graph(self):
        return bool(getattr(self.graph, "edges", None))

    def close(self):
        if self._driver:
            self._driver.close()
            self._driver = None
        # the graph holds that driver, so leaving it cached hands the
        # next caller an object whose every session call will raise
        self._graph = None

    def subschema(self, tables):
        """The tables the joins will be imposed over.

        The graph reads its edges once, but this opens a session every
        time, so a driver that went stale between two questions takes
        the question down with it: a run died on `ServiceUnavailable:
        Failed to read from defunct connection` after the pipeline had
        been idle. One reconnection is tried, and if that fails too the
        anchors stand on their own and the run says the joins were not
        verified. Losing the guarantee is bad; losing the answer over a
        socket is worse."""
        if len(tables) <= 1:
            return list(tables)
        try:
            return self.graph.force_union_subschema(tables)
        except Exception as e:
            log.info("graph session failed (%s), reconnecting once",
                     str(e)[:70])
            self.close()
            try:
                return self.graph.force_union_subschema(tables)
            except Exception as e2:
                self.graph_error = str(e2)[:120]
                self._graph = _EmptyGraph()
                self._graph_failed = time.monotonic()
                log.info("graph unreachable, joins will not be verified")
                return sorted(tables)

    @property
    def recall(self):
        """The corpus of answered questions, which is where anchors come
        from once there is one."""
        if self._recall is None:
            self._recall = Recall.from_profile(self.profile)
        return self._recall

    # ------------------------------------------------ 2. anchors
    def anchors(self, question):
        """Tables the question is about, from the corpus first.

        The corpus is the intended source: its neighbours are questions
        this team actually asked whose SQL a database certified, so it is
        cheaper than a model call, stable between runs, and it improves
        on its own as questions are answered. The model is the cold start,
        for the day the corpus is empty and for a question unlike anything
        in it. Either way the names are confirmed against the catalogue,
        so neither source can introduce a table that does not exist.

        Returns (tables, source), because a run should say where its
        anchors came from rather than leave it to be guessed."""
        real = {t.lower(): t for t in self.clarifier.columns}

        def confirmed(names):
            return list(dict.fromkeys(
                real[t.lower()] for t in names or []
                if isinstance(t, str) and t.lower() in real))

        remembered = confirmed(self.recall.anchors(question))
        if remembered:
            return remembered, "corpus"

        # cut to what fits the reasoner's window on a large database
        raw = self.clarifier.json_with_schema(
            question, ANCHOR_SYSTEM, self.reasoner,
            lambda schema: f"Schema:\n{schema}\n\nQuestion: {question}")
        return confirmed((raw or {}).get("tables")), "model"

    # ------------------------------------------------ 3. imposed joins
    def imposed_joins(self, tables):
        """Every edge of the graph whose two ends are in the sub-schema.
        The generator is given these and forbidden anything else, which
        is what removes the opportunity to invent a join."""
        wanted = {t.lower() for t in tables}
        # the type code a polymorphic edge holds under: without it the join
        # would match an order and a ticket that share an id
        conditions = getattr(self.graph, "conditions", None) or {}
        joins = []
        for f, lc, t, rc, _w, _inf, card, meaning in self.graph.edges:
            if f.lower() in wanted and t.lower() in wanted:
                joins.append({"left": f, "left_col": lc, "right": t,
                              "right_col": rc, "cardinality": card,
                              "meaning": meaning,
                              "condition": conditions.get((f, lc, t, rc))})
        return joins

    @property
    def sql_prompt(self):
        """Managed in Langfuse when it is there, the constant otherwise.
        The version travels with the generation, because attributing an
        answer to the prompt that produced it is the only reason to
        version prompts at all."""
        if self._sql_prompt is None:
            self._sql_prompt = prompt("datagora-sql-generator", SQL_SYSTEM)
        return self._sql_prompt

    @property
    def answer_prompt(self):
        if self._answer_prompt is None:
            self._answer_prompt = prompt("datagora-answer", ANSWER_SYSTEM)
        return self._answer_prompt

    def examples_for(self, question):
        """The verified examples for this question, or none: a corpus that
        is off, empty or failing never stops a question."""
        try:
            return list(self.recall.examples(question))
        except Exception:
            return []

    def prompt_for_sql(self, question, tables, joins, correction=None, examples=()):
        lines = ["Schema (only what you need):"]
        for t in tables:
            cols = self.clarifier.columns.get(t, [])
            lines.append(f"  {t}({', '.join(c for c, _ in cols)})")
        if joins:
            lines.append("\nUse exactly these joins, no others:")
            for j in joins:
                note = f"   -- {j['meaning']}" if j.get("meaning") else ""
                when = f" AND {j['condition']}" if j.get("condition") else ""
                lines.append(f"  {j['left']}.{j['left_col']} = "
                             f"{j['right']}.{j['right_col']}{when}{note}")
        else:
            lines.append("\nNo join is needed; a single table answers this.")
        lines.append("\nWrite WITH blocks, one per step, whenever the "
                     "question crosses tables.")
        if examples:
            # verified questions of this database and their SQL: the
            # largest single gain in every published ablation of a
            # production text-to-SQL system (recall.Recall.examples)
            lines.append("\nExamples of questions on this database and their SQL "
                         "(follow their conventions, not their tables if yours differ):")
            for ex in examples:
                lines.append(f"Q: {ex['question']}\nSQL: {ex['sql']}")
        said = str(getattr(self.clarifier, "context", "") or "")
        if said:
            lines.append(f"\n{said}")
        lines.append(f"\nQuestion: {question}")
        if correction:
            lines.append(f"\nYour previous attempt was rejected before it "
                         f"ran:\n{correction}\nWrite it again, corrected.")
        return "\n".join(lines)

    # ------------------------------------------------ 5-7. the checks
    def check(self, sql, con):
        """Every gate that runs before a single row is read.

        Returns (message_for_the_next_attempt_or_None, gates_that_ran).
        The sequence itself lives in schema_graph.judge_sql, so this and
        the two public judging surfaces cannot drift apart again. What
        stays here is the wording of the correction, which is addressed
        to a model and is not the same thing as a verdict addressed to a
        person.

        Without a graph the joins are simply unverified, which is a
        stated gap and never a rejection: an absent Neo4j must not turn
        correct SQL away. `ran` is what lets the run say which gates
        actually executed instead of claiming all of them did."""
        findings, ran = judge_sql(
            sql, columns=self.clarifier.columns,
            graph=self.graph if self.has_graph else None,
            con=con, stop_early=True)
        # a warning is said, never a rejection: "changes() does not exist on
        # MariaDB" for a CTE named changes cost three attempts and the
        # answer (review of 26 October)
        self._here().warnings = [why for verdict, why in findings
                                 if not verdict.startswith("REJECT")]
        findings = [f for f in findings if f[0].startswith("REJECT")]
        if not findings:
            return None, ran

        verdict, why = findings[0]
        if verdict == "REJECT" and "dialect" in why:
            return repair_message(sql), ran
        if verdict.startswith("REJECT literal-type"):
            return ("This filter cannot match anything:\n"
                    + "\n".join(f"  {v}: {w}" for v, w in findings)), ran
        if verdict.startswith(("REJECT no-edge", "REJECT wrong-keys")):
            return ("The join audit rejected this query before it ran:\n"
                    + "\n".join(f"  {v}: {w}" for v, w in findings)), ran
        if verdict.startswith(("REJECT fan", "REJECT chasm")):
            return f"The query multiplies rows. {verdict}: {why}", ran
        return f"{verdict}: {why}", ran

    # ------------------------------------------------ 8. execution
    def execute(self, sql, con):
        """Read-only by construction: everything happens inside a
        transaction that is rolled back, so a statement that slipped
        through and writes cannot leave a trace.

        Returns (columns, rows, total). `total` is how many rows the
        query really matches, which is not len(rows) whenever the ceiling
        bit. Asked which products are below their reorder level, the
        answer used to be "Fifty products", because fifty is what the
        fetch returned; the database holds 446. A transport limit was
        being reported as a fact about the data, which is the one thing
        this pipeline exists to prevent."""
        cur = con.cursor()
        con.begin()
        try:
            cur.execute(sql)
            rows = cur.fetchmany(MAX_ROWS)
            columns = [d[0] for d in (cur.description or [])]
            total = len(rows)
            if total == MAX_ROWS:
                total = self._count(cur, sql)
        finally:
            con.rollback()
        return columns, [list(r) for r in rows], total

    def _count(self, cur, sql):
        """How many rows `sql` returns past the fetch ceiling; None only
        when the database could count it no way, and never the ceiling.

        The driver's own count first: pymysql's cursor reads the whole
        result when the query runs, and its rowcount is that count, with
        no second query. Else the statements of count_statements in turn:
        COUNT(*) around the query, then the same with each column named
        apart, which a result with two columns of one name needs (review
        of 26 October: SELECT p.name, c.name could not be counted, and the
        answer said "at least 50 rows"), then with its columns replaced
        by 1."""
        read = getattr(cur, "rowcount", -1)
        if isinstance(read, int) and MAX_ROWS < read < 2 ** 63 - 1:
            return read
        if __package__:
            from .verdict_tools import count_statements
        else:
            from verdict_tools import count_statements
        catalogue = {str(t).lower(): cols for t, cols in
                     (getattr(self.clarifier, "columns", None) or {}).items()}
        for count in count_statements(sql, lambda t: catalogue.get(str(t).lower(), [])):
            try:
                cur.execute(count)
                got = cur.fetchone()
                if got and got[0] is not None:
                    return int(got[0])
            except Exception:
                continue
        return None

    # ------------------------------------------------ 9. the answer
    def say(self, question, columns, rows, total=None):
        if not rows:
            return "Nothing in the data matches that question."
        # `total` is how many rows the query really matches. When the
        # fetch was capped, len(rows) is the cap, and stating it reports
        # a transport limit as a figure read from the data: asked which
        # products are below their reorder level, the answer was "Fifty
        # products" when the database holds 446.
        # the count failed (two columns of one name, a timeout): never the
        # fetch ceiling said as the count (review of 26 October)
        counted = (f"{total} rows match" if total is not None else
                   f"At least {len(rows)} rows match (the total could not be counted)"
                   if len(rows) >= MAX_ROWS else f"{len(rows)} rows match")
        # A weak model told to summarise fifty rows recites them, and
        # garbles a few on the way. Asking it not to does not work; not
        # giving it the rows does. It sees the count and the first few,
        # so the most it can recite is the few, and the full figures are
        # shown beside its sentence where nothing can distort them.
        shown = 5
        preview = [", ".join(f"{c}={v}" for c, v in zip(columns, r))
                   for r in rows[:shown]]
        more = (f"\n...and {len(rows) - shown} more rows, which are "
                f"displayed to the user separately."
                if len(rows) > shown else "")
        text = self.reasoner.chat(
            self.answer_prompt.text,
            f"Question: {question}\n\n{counted}. "
            f"The first {min(shown, len(rows))} of them:\n"
            + "\n".join(preview) + more)
        # a model writing Markdown escapes its underscores (product\_id),
        # and the page shows the sentence as text: the escapes are dropped
        text = re.sub(r"\\([_*`#\[\]()<>~|])", r"\1", (text or "").strip())
        if not text:
            # an unreachable reasoner used to become "50 rows were
            # returned.", which reads like an answer, scores as answered
            # and is written into the corpus as certified. A silence has
            # to stay a silence all the way to the caller.
            raise RuntimeError(getattr(self.reasoner, "last_error", "")
                               or "the reasoner returned nothing")
        return text

    # ------------------------------------------------ the whole journey
    @property
    def judge_mode(self):
        """"agent" or "single", this pipeline's own choice first, then
        DATAGORA_ASK_JUDGE, then the agent. The agent since 1.2.0: measured
        on 29 questions on 27 October, 23 right against 19 for the single
        call, and its mistakes ask for more where the single call's offered
        a choice on data that is missing. Anything else is the agent."""
        value = str(getattr(self, "judge", None) or os.environ.get("DATAGORA_ASK_JUDGE")
                    or "agent").strip().lower()
        return value if value in ("single", "agent") else "agent"

    @property
    def verdict_agent(self):
        """The agent judge over this pipeline's clarifier, built once: its
        reading of the schema is the costly part, shared by every
        question (verdict_agent.VerdictAgent)."""
        if getattr(self, "_agent", None) is None:
            if __package__:
                from .coverage import _profile_path
                from .verdict_agent import VerdictAgent
                from .verdict_tools import SchemaView
            else:
                from coverage import _profile_path
                from verdict_agent import VerdictAgent
                from verdict_tools import SchemaView
            view = SchemaView(self.clarifier, profile_path=_profile_path(self.profile))
            self._agent = VerdictAgent(self.clarifier, view=view, settings=ask_settings())
        return self._agent

    def _clarify(self, question, again=False, choice=None):
        """The verdict on a question, by the Ask judge. The agent's verdict
        is kept for the question: `again`, the asker's choice coming back,
        reads the options they saw rather than exploring for minutes a
        second time and perhaps offering others.

        The last few verdicts of a question are kept, and a choice is read
        off the latest one that offered it: two people asking the same
        question at once may be offered different options (review of 26
        October: the second verdict replaced the first, and the first
        asker was told their reading was no longer offered)."""
        if self.judge_mode != "agent":
            out = self.clarifier.clarify(question)
            # read at once, on this thread: the clarifier is shared, and a
            # question asked meanwhile overwrote its last_shown (review of
            # 26 October: two questions recorded each other's tables)
            self._here().shown = list(getattr(self.clarifier, "last_shown", None) or [])
            return out
        kept = getattr(self, "_verdicts", None)
        if kept is None:
            kept = self._verdicts = {}
        key = " ".join(str(question).split()).lower()
        seen = kept.get(key) if again else None
        if seen:
            return next((out for out in reversed(seen)
                         if any(getattr(o, "label", None) == choice
                                for o in getattr(out, "options", None) or [])), seen[-1])
        base = agent = self.verdict_agent
        if hasattr(base, "_view") and hasattr(base, "_settings"):
            # one judge per question, its deadline, counters and trace its
            # own, so two people asking at once never share them; the schema
            # view, the costly part, is shared (review of 23 October)
            agent = type(base)(base.clar, view=base._view, settings=base._settings,
                               system=getattr(base, "_system", None))
        out = agent.clarify(question)
        self._here().shown = list(getattr(agent, "last_shown", None) or [])
        # the question's own judge: its trace is read here, never on the
        # shared one, which judges nothing since each question has its own
        self._here().trace = getattr(agent, "last_trace", None)
        if getattr(out, "action", "ERROR") != "ERROR":
            with _KEPT:
                # the question moves to the end, the oldest first out
                earlier = kept.pop(key, None) or []
                kept[key] = earlier[-(KEPT_PER_QUESTION - 1):] + [out]
                while len(kept) > KEPT_VERDICTS:
                    kept.pop(next(iter(kept)))
        return out

    def last_trace(self):
        """The agent judge's trace of this thread's last question, or None."""
        return getattr(self._here(), "trace", None) if self.judge_mode == "agent" else None

    def judge_said(self):
        """The agent judge's work on this thread's last question, in one
        line for the run's steps: how it stopped, its turns and seconds, the
        verdict it declared, the verifier's checks and what they changed,
        its reason. "" for the single judge."""
        t = self.last_trace() or {}
        if not t:
            return ""
        c = t.get("conclusion") or {}
        checks = ", ".join(f"{k.get('check')}:{k.get('status')}" for k in t.get("verifier") or []
                           if isinstance(k, dict))
        changed = "; ".join(f"{x.get('from')} -> {x.get('to')} ({x.get('why')})"
                            for x in t.get("coercions") or [] if isinstance(x, dict))
        entries = [x for x in t.get("turns") or [] if isinstance(x, dict)]
        tools = ", ".join(str(x.get("tool")) for x in entries if x.get("tool"))
        # the model's turns, not every entry: the tools and the two short
        # questions on the side have entries of their own
        turns = sum(1 for x in entries if x.get("kind") == "turn")
        parts = [f"agent: {t.get('stopped_by')} after {turns} turns, "
                 f"{t.get('seconds')} s; declared {c.get('verdict')}"]
        if tools:
            parts.append(f"tools: {tools}")
        if checks:
            parts.append(f"checks: {checks}")
        if changed:
            parts.append(f"changed: {changed}")
        if c.get("reason"):
            parts.append(f"reason: {c.get('reason')}")
        return " | ".join(parts)[:900]

    def _here(self):
        """What this thread's question left, apart from other threads'."""
        return self.__dict__.setdefault("_thread", threading.local())

    def _judged_tables(self):
        """The tables the judge looked at for this thread's last question,
        at most eight: the agent's described tables, else the single call's."""
        shown = getattr(self._here(), "shown", None) or []
        return [str(t) for t in shown][:8] if isinstance(shown, (list, tuple)) else []

    @property
    def reformulates(self):
        """Whether suggestions are made for the next question. getattr: a
        pipeline built with __new__, as some tests do, has no attribute."""
        return reformulate_enabled(getattr(self, "reformulate", None))

    def ask(self, question, choice=None, on_step=None, suggestion=None, context=None,
            earlier=None, remember=True):
        """One question, from words to an answer.

        `choice` answers a clarification by its option's label. With it,
        `suggestion` is the question the asker picked for that option
        (Run.suggestions): it is the precise question already, so it is
        answered as it is, without clarifying again or rewriting.
        `context` says who asks and when for this question (context.py),
        over the pipeline's own. `earlier` is what was decided before it:
        the Run it follows (the one whose suggestion was picked), or a note
        already written (context.earlier_note)."""
        run = self.prepare(question, choice, suggestion, context, earlier, on_step)
        # remember=False: a test asks, and nothing it gives goes into the
        # corpus the deployment draws on (review of the fixes: ui_e2e on
        # 8080 would have written its questions there)
        self._here().remember = bool(remember)
        # the span comes first so every line below carries its id: a log
        # written before the trace exists, or after it closes, is the one
        # line you cannot correlate, and it is always the interesting one
        # a span, as it always was, so Langfuse's aggregates (latency by
        # span name) keep counting it; the graph comes from the typed steps
        # inside it, the schema chosen and the guards (observability.step)
        trace = Span("datagora.ask", input={
            "question": question, "choice": choice, "suggestion": suggestion,
            "profile": self.profile.name, "judge": self.judge_mode,
            "graph": "yes" if self.has_graph else "no",
            "reasoner": self.reasoner.model, "sql_model": self.sql_llm.model,
            "sql_prompt_version": self.sql_prompt.version,
            "sql_prompt_source": self.sql_prompt.source})
        # carried on the run so a caller can hand the link to whoever
        # reports a problem, instead of searching a trace list by hand
        run.trace_id = current_trace_id()
        run.trace_url = trace_url() or ""
        log.info("ask [%s] %r%s", self.profile.name, question[:70],
                 f" choice={choice!r}" if choice else "")
        try:
            return self._ask(run, question, choice, trace, suggestion)
        finally:
            log.info("ask done: %s, %d rows, %d steps",
                     "answered" if run.answer else "no answer",
                     len(run.rows), len(run.steps))
            trace.end(output={"answer": run.answer, "sql": run.sql,
                              "rows": len(run.rows), "failed": run.failed})
            trace.score("answered", 1 if run.answer else 0)
            trace.score("attempts", sum(1 for s in run.steps
                                        if s.name.startswith("generate")))
            trace.score("rejected_by_checks",
                        sum(1 for s in run.steps
                            if not s.ok and "checks" in s.name))
            trace.score("joins_verified", 1 if self.has_graph else 0)
            flush()

    def _suggest(self, run, question, out):
        """The questions the asker can pick, when the run stops for them.

        Only for NEEDS A CHOICE and NEEDS MORE (reformulate.needs): NOT
        COVERED and NO DATA are answers, and nothing is offered for them.
        Never fatal: the clarification stands without suggestions, which
        is exactly what the page showed before they existed."""
        if not self.reformulates or not needs(out):
            return
        try:
            run.clarifying = headline(question, out, self.clarifier)
            run.suggestions = [s.model_dump() for s in
                               suggest(self.clarifier, question, out,
                                       today=context_today(run.context))]
        except Exception as e:
            log.info("no suggestions: %s", str(e)[:90])
            return
        if run.suggestions:
            run.add("suggest", True, f"{len(run.suggestions)} questions to pick from")

    def prepare(self, question, choice=None, suggestion=None, context=None, earlier=None,
                on_step=None):
        """The question made ready to judge, on this thread: who asks and
        when (this question's context over the pipeline's own), what was
        decided before (a follow-up's note; a choice keeps the note its
        options were judged with), told to the clarifier for this thread
        only. Pipeline.ask and the LangGraph clarify node both start here,
        so the two can never judge a question differently."""
        run = Run(question=question, profile=self.profile.name, on_step=on_step)
        run.context = self._context_of(context)
        earlier = getattr(earlier, "_run", earlier)        # an Answer, from the client
        if isinstance(earlier, Run):
            # a new question picked after a stop is told what was decided
            # there; a choice comes back to that very question, judged
            # with the note its options were judged with
            run.earlier = (earlier.earlier or "") if choice is not None \
                else earlier_of(earlier, suggestion or question)
        else:
            run.earlier = earlier if isinstance(earlier, str) else ""
        self.tell(run.context, run.earlier)
        return run

    def _context_of(self, context):
        """Who asks and when for one question: its own facts over the
        pipeline's, the machine's under both; False, none (review of 26
        October: a question's context replaced the client's)."""
        base = getattr(self, "context", None)
        if context is False or (context is None and base is False):
            return {}
        if context is None:
            return resolve_context(base)
        over = context() if callable(context) else context
        if isinstance(over, str):
            over = {"about": over} if over.strip() else {}
        under = base() if callable(base) else base
        if isinstance(under, str):
            under = {"about": under} if under.strip() else {}
        merged = dict(under) if isinstance(under, dict) else {}
        merged.update(over if isinstance(over, dict) else {})
        return resolve_context(merged)

    def tell(self, context, earlier=""):
        """The clarifier told who asks and when, and what was decided, for
        this thread only (Clarifier.for_question); a stand-in clarifier
        without it gets the attributes."""
        said = {"context": describe_context(context or {}), "earlier": earlier or "",
                "today": context_today(context or {}), "now": context_moment(context or {})}
        tell = getattr(self.clarifier, "for_question", None)
        if callable(tell):
            tell(**said)          # this thread's question only, reset at every one
            return
        for key, value in said.items():
            try:
                setattr(self.clarifier, key, value)
            except AttributeError:
                pass

    def judge_stage(self, run, question, choice=None, suggestion=None):
        """Step 1 of a question: the technical question to answer, or None
        when the run stops for the asker (a choice to make, a GUIDE, an
        error), with its clarification and suggestions on the run. Shared
        by Pipeline._ask and the LangGraph clarify node."""
        technical = question
        picked = (suggestion or "").strip()
        if choice is not None and picked:
            # the asker picked the question written for one reading: it
            # settles the ambiguity in their words, so it is answered as
            # it is. Clarifying again would cost a model call to find the
            # option it already names, and rewriting it would replace the
            # words they chose with the model's.
            technical = picked
            run.add("clarify", True, f"resolved as {choice}: the question picked")
        elif choice is None:
            out = self._clarify(question)
            run.clarification = out
            run.judged_tables = self._judged_tables()
            said = self.judge_said()
            if said:
                run.add("judge", out.action != "ERROR", said)
            if out.action == "ERROR":
                run.failed = out.reason
                run.add("clarify", False, out.reason)
                return None
            if out.action == "CLARIFY" and out.options:
                run.add("clarify", True, "CLARIFY: waiting for the user")
                self._suggest(run, question, out)
                return None                     # the user must pick first
            # a GUIDE stops the run whether or not it carries options,
            # because the explanation IS the outcome. Continuing past one
            # buried it: "products cheaper than a coffee" went on to
            # generate, matched nothing, and the user was told the data
            # held no such products rather than that the database holds
            # no price for a coffee.
            if out.action == "GUIDE":
                run.add("clarify", True, "GUIDE: " + (out.question
                                                      or out.reason))
                # NEEDS MORE only, inside: a picked suggestion comes back
                # as a new question and is clarified like any other
                self._suggest(run, question, out)
                return None
            run.add("clarify", True, out.reason or "nothing to settle")
        else:
            out = self._clarify(question, again=True, choice=choice)
            run.clarification = out
            if out.action == "ERROR":
                run.failed = out.reason
                run.add("clarify", False, out.reason)
                return None
            option = next((o for o in out.options if o.label == choice), None)
            if option is None and out.options:
                # the reading picked is not among those offered now: never
                # answer another one in its name (review of 23 October, the
                # first option was taken); the asker chooses again
                run.add("clarify", True, f"the reading {choice!r} is no longer offered: "
                                         "choose again")
                self._suggest(run, question, out)
                return None
            if option is None and out.action == "GUIDE":
                run.add("clarify", True, "GUIDE: " + (out.question or out.reason))
                self._suggest(run, question, out)
                return None
            if option is not None:
                technical = self.clarifier.rewrite(question, out, option)
                run.add("clarify", True, f"resolved as {choice}")
            else:
                run.add("clarify", True, "answered as asked: the judge sees one reading now")
        run.technical_question = technical
        return technical

    def _ask(self, run, question, choice, trace, suggestion=None):
        # 1. clarify, unless the caller already answered the question
        technical = self.judge_stage(run, question, choice, suggestion)
        if technical is None:
            return run

        # 2 and 3
        with Span("anchors", trace, input={"question": technical}) as sp:
            tables, source = self.anchors(technical)
            sp.end(output={"tables": tables, "source": source})
            sp.score("from_corpus", 1 if source == "corpus" else 0)
        if not tables:
            run.failed = "no table of this database matches the question"
            return run.add("anchors", False, run.failed)
        run.anchor_source = source
        sub = self.subschema(tables)
        joins = self.imposed_joins(sub)
        run.add("anchors", True, f"{', '.join(tables)}   (from the {source})")
        run.add("sub-schema", True,
                f"{' > '.join(sub)}   ({len(joins)} imposed joins)")

        run.examples = self.examples_for(technical)
        if run.examples:
            run.add("examples", True, "; ".join(
                f"{e['question']} ({e['source'] or 'seed'}, {e['score']:.2f})"
                for e in run.examples))

        # 4 to 8, with the verdicts fed back
        con = self.profile.connect_mysql()
        correction = None
        try:
            for attempt in range(1, MAX_ATTEMPTS + 1):
                gen = Span(f"generate.{attempt}", trace,
                           as_type="generation", prompt=self.sql_prompt,
                           model=self.sql_llm.model, input={
                               "prompt_version": self.sql_prompt.version,
                               "correction": correction,
                               "examples": [e["question"] for e in run.examples]})
                raw = self.sql_llm.chat(
                    self.sql_prompt.text,
                    self.prompt_for_sql(technical, sub, joins, correction,
                                        examples=run.examples))
                sql = strip_sql(raw)
                gen.end(output=sql)
                if not sql:
                    correction = "You returned no SQL. Return the query only."
                    run.add(f"generate (attempt {attempt})", False, "empty")
                    continue
                run.sql = sql
                run.add(f"generate (attempt {attempt})", True, sql)

                with Span(f"checks.{attempt}", trace,
                          input={"sql": sql}) as ck:
                    correction, ran = self.check(sql, con)
                    ck.end(output=correction or f"passed: {', '.join(ran)}")
                    ck.score("passed", 0 if correction else 1,
                             comment=correction)
                if correction:
                    log.info("attempt %d rejected: %s", attempt,
                             correction.splitlines()[0][:90])
                    run.add(f"checks (attempt {attempt})", False, correction)
                    continue
                # name the gates that ran rather than all of them. Without
                # a graph, two of the four are skipped, and claiming they
                # passed is the one misrepresentation this whole pipeline
                # exists to avoid.
                missing = [g for g in ("dialect", "literals", "joins",
                                       "traps", "EXPLAIN") if g not in ran]
                warned = getattr(self._here(), "warnings", None) or []
                run.add(f"checks (attempt {attempt})", True,
                        ", ".join(ran) + " pass"
                        + (f"   ({', '.join(missing)} NOT CHECKED: "
                           f"no schema graph)" if missing else "")
                        + (f"   (warning: {'; '.join(warned)[:200]})" if warned else ""))

                try:
                    (run.columns, run.rows,
                     run.total_rows) = self.execute(sql, con)
                except Exception as e:
                    correction = f"MariaDB refused it: {str(e)[:200]}"
                    run.add("execute", False, correction)
                    continue
                shown_n, real_n = len(run.rows), run.total_rows
                run.add("execute", True,
                        (f"{real_n} rows match, first {shown_n} read"
                         if real_n is not None and real_n > shown_n
                         else f"at least {shown_n} rows, the total could not be counted"
                         if real_n is None and shown_n >= MAX_ROWS
                         else f"{shown_n} rows")
                        + ", read-only, rolled back")
                with Span("answer", trace, as_type="generation",
                          prompt=self.answer_prompt,
                          model=self.reasoner.model, input={
                              "rows": len(run.rows),
                              "prompt_version": self.answer_prompt.version
                          }) as ans:
                    # say() raises when the reasoner is silent, rather
                    # than inventing a sentence. That is a failed run,
                    # not an answer, and it must be reported as one.
                    # `technical`, not `question`: after a CLARIFY the
                    # rows answer the rewritten question, and writing
                    # the sentence against the ambiguous one makes it
                    # describe a result it was not computed from
                    try:
                        run.answer = self.say(
                            technical, run.columns, run.rows,
                            run.total_rows)
                    except RuntimeError as e:
                        run.failed = f"the answer step failed: {e}"
                        ans.end(output=run.failed)
                        return run.add("answer", False, run.failed)
                    ans.end(output=run.answer)
                run.add("answer", True, run.answer)
                self._remember(run, technical, tables, sql, source)
                return run
            run.failed = correction or "no attempt survived the checks"
        finally:
            con.close()
        return run

    def _remember(self, run, technical, tables, sql, source):
        """Write an answered question into the corpus, when it may be.

        The corpus only ever grows with questions a database certified, so
        tomorrow's anchors are drawn from queries that ran rather than from
        queries a model liked; nor with an empty result, which no model
        wrote and no one checked, nor with joins no graph verified, which
        the checks then let through whatever they are (review of 26
        October). Nor with what the corpus gave, nor when the caller said
        not to."""
        if source != "corpus" and run.rows and remembers() \
                and getattr(self._here(), "remember", True) and self.has_graph:
            run.remembered = self.recall.remember(technical, tables, sql) or ""


def remembers(environ=None):
    """Whether an answered question is written into the corpus, from
    DATAGORA_REMEMBER (on unless off, 0, false or no). A test instance
    shares the production's Qdrant: its answers, from a small model or a
    test run, must not enter the corpus production draws its tables from."""
    if environ is None:
        # the .env and DATAGORA_ENV_FILE as every other setting reads them
        try:
            if __package__:
                from .db_profile import environment
            else:
                from db_profile import environment
            env = environment()
        except Exception:
            env = os.environ
    else:
        env = environ
    return str(env.get("DATAGORA_REMEMBER") or "on").strip().lower() not in (
        "off", "0", "false", "no")


def earlier_of(run, picked=""):
    """The note on a run that stopped, for the question picked after it."""
    if __package__:
        from .coverage import classify
    else:
        from coverage import classify
    c = getattr(run, "clarification", None)
    verdict = classify(c)[0] if c is not None and getattr(c, "action", "") else ""
    what = (getattr(c, "missing", "") or getattr(run, "clarifying", "")
            or getattr(c, "question", "") or "") if c is not None else ""
    offered = [s.get("question") if isinstance(s, dict) else getattr(s, "question", "")
               for s in getattr(run, "suggestions", None) or []]
    if not offered and c is not None:
        offered = [o.means or o.label for o in getattr(c, "options", None) or []]
    return earlier_note(run.question, verdict, what, offered, picked,
                        getattr(run, "judged_tables", None) or [],
                        before=getattr(run, "earlier", "") or "")


def ask_settings(environ=None):
    """The agent's settings for Ask: the coverage judge's (the engine
    settings and DATAGORA_AGENT_*), with fewer turns, a shorter limit and
    thinking to plan and conclude only, each moved by its
    DATAGORA_ASK_AGENT_* variable within the bounds Settings keeps."""
    if __package__:
        from .verdict_tools import BOUNDS, Settings
    else:
        from verdict_tools import BOUNDS, Settings
    env = os.environ if environ is None else environ
    s = Settings.from_environment(env)
    values = dict(ASK_AGENT)
    for key, cast in (("max_turns", int), ("max_seconds", float)):
        raw = str(env.get(f"DATAGORA_ASK_AGENT_{key.upper()}") or "").strip()
        try:
            v = cast(raw) if raw else None
        except ValueError:
            v = None
        low, high = BOUNDS[key]
        if v is not None and low <= v <= high:
            values[key] = v
    think = str(env.get("DATAGORA_ASK_AGENT_THINK") or "").strip().lower()
    if think in ("all", "plan_conclude", "none"):
        values["think"] = think
    return dataclasses.replace(s, **values)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--profile", default="datagora_generic")
    ap.add_argument("--question", required=True)
    ap.add_argument("--choice", default=None,
                    help="answer the clarification, by option label")
    ap.add_argument("--suggestion", default=None,
                    help="with --choice, the suggested question picked for it")
    args = ap.parse_args()

    profile = DbProfile.load(args.profile)
    pipe = Pipeline(profile)
    print(f"reasoner: {pipe.reasoner.name} -> {pipe.reasoner.model}")
    print(f"sql     : {pipe.sql_llm.name} -> {pipe.sql_llm.model}\n")
    try:
        run = pipe.ask(args.question, args.choice, suggestion=args.suggestion)
    finally:
        pipe.close()

    for s in run.steps:
        mark = "ok  " if s.ok else "FAIL"
        body = s.detail.replace("\n", "\n         ")
        print(f"  [{mark}] {s.name:24} {body}")

    c = run.clarification
    if c is not None and c.options and not run.answer:
        print(f"\n{c.question}")
        for o in c.options:
            print(f"   - {o.means or o.label}     (--choice \"{o.label}\")")
    if run.suggestions and not run.answer:
        print(f"\n{run.clarifying}")
        for s in run.suggestions:
            print(f"   - {s['question']}"
                  + (f"     (--choice \"{s['choice']}\" --suggestion \"...\")"
                     if s.get("choice") else ""))
    if run.answer:
        print(f"\nANSWER: {run.answer}")
    elif run.failed:
        print(f"\nno answer: {run.failed}")


if __name__ == "__main__":
    main()
