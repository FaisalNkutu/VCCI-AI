"""Can this database answer these questions? One verdict per question.

Hand it a list of questions and a connection, and it says of each one
whether the data can answer it, what would have to be settled first, or
what is missing and will not be found by asking again. That is the
question a team actually has before adopting anything: not "is the
system good" but "does it cover what we ask".

Six verdicts, and the difference between the middle four is the whole
point:

    ANSWERABLE      nothing to settle; the question can be answered
    NEEDS A CHOICE  the data supports multiple interpretations and
                    someone must pick. The choices are real columns.
    NEEDS MORE      the question is missing something the asker has and
                    the database does not: a price, a unit, a date. It
                    names what to add. Ask again and it works.
    NO DATA         the question can be asked of the data, and no row
                    matches it today: an empty answer, not a gap.
    NOT COVERED     the database holds nothing of the kind. Asking again
                    will not help; this is a gap in the data, not in the
                    question.
    UNKNOWN         the model did not answer. Not a verdict, kept apart
                    on purpose: "we could not tell" is not "no".

Read a CSV, write a CSV:

    python coverage.py --profile datagora_lib --questions theirs.csv \\
                       --out verdicts.csv

The input needs a `question` column; any other column is carried through
to the output untouched, so an id or a category survives the round trip.

As a library, on their connection and their model, with none of our
configuration:

    from graph_lab.coverage import assess
    for v in assess(questions, connect=pool.getconn, schema="sales",
                    llm=my_model):
        print(v.verdict, v.question, v.missing)
"""

import argparse
import csv
import hashlib
import io
import json
import os
import pathlib
import re
import sys
import tempfile
import uuid
from collections import Counter
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

if __package__:
    from .ambisql import Clarifier
    from .ambisql import Clarifier as _RealClarifier
else:
    from ambisql import Clarifier
    from ambisql import Clarifier as _RealClarifier

# the four types AmbiSQL calls level 2: the question needs something
# from outside the database. Those are answerable once the asker adds
# it, which is a different message from "we do not hold this".
NEEDS_CONTEXT = {"AmbiContext", "AmbiSource", "AmbiRef"}

ANSWERABLE = "ANSWERABLE"
NEEDS_CHOICE = "NEEDS A CHOICE"
NEEDS_MORE = "NEEDS MORE"
NOT_COVERED = "NOT COVERED"
# The columns that answer it are there and no row matches. An empty
# result is an ANSWER, not a gap: reporting it as NOT COVERED tells a
# team their database cannot do something it does in one query. It is
# also the verdict a benchmark needs isolated, because a question whose
# correct answer is the empty set cannot be scored like one the schema
# cannot reach, and a test set has to be able to leave it out on purpose.
NO_DATA = "NO DATA"
UNKNOWN = "UNKNOWN"

__all__ = [
    "ANSWERABLE", "NEEDS_CHOICE", "NEEDS_MORE", "NOT_COVERED", "NO_DATA",
    "UNKNOWN",
    "Verdict", "BatchReport", "assess", "assess_file", "classify",
    "read_questions", "read_questions_from_text", "write_verdicts",
]


class Verdict(BaseModel):
    """One question's outcome, validated on the way in.

    A verdict is the unit this whole file exists to produce and the one
    thing a caller reads, so it is worth refusing a malformed one at the
    point it is built rather than discovering it in a CSV column later.
    """

    model_config = ConfigDict(extra="forbid")

    question: str
    verdict: str
    kind: str = ""
    # what a person would have to supply, or choose between
    missing: str = ""
    choices: list[str] = Field(default_factory=list)
    # the row the question came from, carried through untouched
    extra: dict = Field(default_factory=dict)
    # how long it took and which model server judged it: for the page's
    # progress and its estimate of the time left, never written to the CSV
    seconds: float | None = Field(default=None, exclude=True)
    served_by: str = Field(default="", exclude=True)
    # where it stands in the questions judged, since verdicts are handed
    # back as they finish and not in the order asked
    position: int | None = Field(default=None, exclude=True)
    # how the verdict was reached: the model's reply as written, the tables
    # it was shown, the branch of the guards that decided. Kept beside the
    # run's CSV (Ledger), never in it
    trace: dict | None = Field(default=None, exclude=True)

    def sentence(self):
        """Return the user-facing explanation.

        `missing` is already a complete sentence produced by the
        clarifier. Return it unchanged to avoid duplicating or
        contradicting its wording."""
        if self.verdict == ANSWERABLE:
            # an answer carries a column only when a choice came down to
            # the one reading the database holds, and the reader is owed it
            if self.choices:
                return ("Yes, this can be answered, reading it as "
                        + ", ".join(self.choices) + ".")
            return "Yes, this can be answered as asked."
        if self.verdict == NEEDS_CHOICE:
            return ("Yes, but a choice is needed. Choose between: "
                    + ", ".join(self.choices))
        if self.verdict == NEEDS_MORE:
            return "I would need to know: " + self.missing
        if self.verdict in (NOT_COVERED, NO_DATA):
            # both are complete sentences from the clarifier, saying what
            # was checked: no column of the kind, or no row with the value
            return self.missing
        return "Could not tell: " + self.missing


class BatchReport(BaseModel):
    """What a batch run did, for a caller that scripted it."""

    model_config = ConfigDict(extra="forbid")

    output: str
    total: int
    already_done: int
    processed: int
    counts: dict = Field(default_factory=dict)
    # the questions' own fingerprint: the same list always gives the same
    # job, which is what a resume is keyed on
    job: str = ""
    # set when the requested output belonged to another job and this one
    # was written beside it instead of over it
    note: str | None = None
    # why the run ended early, when it did: an interruption, a database
    # that went away, or the first failure under stop_on_error. The rows
    # already flushed are still in `output` and still resumable
    stopped: str | None = None

    @property
    def remaining(self):
        return self.total - sum(self.counts.get(name, 0)
                                for name in FINAL_VERDICTS)

    @property
    def complete(self):
        return self.remaining == 0


def classify(out):
    """One Outcome from the clarifier, turned into a verdict.

    The mapping is the interesting part. A CLARIFY means the data can
    serve every reading, so it is answerable and only needs a choice. A
    GUIDE splits in two, and conflating them is what makes a coverage
    report useless: a question missing a unit is answerable tomorrow,
    a question about a column nobody stores is never answerable, and
    telling a team to rephrase the second wastes their afternoon."""
    if out.action == "ERROR":
        return UNKNOWN, out.reason or "the model did not answer"
    if out.action == "ANSWER":
        return ANSWERABLE, ""
    if out.action == "CLARIFY":
        return NEEDS_CHOICE, out.reason or ""
    # GUIDE, and the split between the two is the distinction a reader
    # is paying for. It rests on `checked`, which the clarifier sets only
    # when it swept the schema and found nothing of the kind, rather than
    # on the type the model assigned. Telling a team "your database
    # cannot do this" on the strength of one classification token from
    # the smallest model in the stack is exactly the claim that has to be
    # earned. Everything else is reported as a question that needs more
    # from the asker, which is the safer of the two to be wrong about:
    # they rephrase and find out.
    # getattr and not out.empty: this function is public and takes an
    # Outcome-shaped object, which a caller may build themselves and
    # which an older build had no `empty` on at all.
    if getattr(out, "empty", False):
        # the schema reaches it and the data holds no match. Kept ahead
        # of `checked` because it is the narrower, better-evidenced
        # claim: a column of the right kind was named, not merely absent.
        return NO_DATA, (out.question or out.reason or "").strip()
    if out.checked:
        return NOT_COVERED, (out.question or out.reason or "").strip()
    return NEEDS_MORE, (out.reason or out.question or "").strip()


def resolve_names(profile, llm):
    """A configured name turned into the object it names.

    Both spellings arrive at the public functions, because the command
    line holds names and an application holds objects. Accepting a name
    in one entry point and not the other meant the same argument worked
    through assess_file and came back as an AttributeError swallowed into
    UNKNOWN through assess, which reads like an unanswerable question
    rather than like a caller mistake."""
    if isinstance(profile, str):
        if __package__:
            from .db_profile import DbProfile
        else:
            from db_profile import DbProfile
        profile = DbProfile.load(profile)
    if isinstance(llm, str):
        if __package__:
            from .llm import LLM
        else:
            from llm import LLM
        llm = LLM.load(llm)
    return profile, llm


def assess(questions, *, profile=None, connect=None, schema=None, llm=None,
           on_each=None, skip=None, stop_on_error=False, workers=None,
           job=None, cancel=None, on_slots=None, session=None, think=None,
           on_thinking=None, judge=None, context=None):
    """A verdict per question, in order.

    Takes either one of our profiles or a plain connection factory and a
    schema name, so a team can point it at their own database without
    adopting any of our configuration. One model call per question, and
    no SQL is generated or executed: this answers whether a question is
    coverable, which is cheaper than answering the question.

    `skip` is a set of questions already done, which is how a run of five
    hundred resumes where it stopped. A question that raises is recorded
    as UNKNOWN and the run continues, because one unreachable model call
    in four hundred should not throw away the other three hundred and
    ninety-nine; `stop_on_error` reverses that when a caller would rather
    know at once.

    `cancel`, a threading.Event, stops the run when it is set: no question
    is started after it, the ones being judged finish and are handed to
    on_each as usual, so what was decided is kept and a resume starts at
    the first question not judged. A stop is a pause.

    `session` names the run in Langfuse, every question of it under one
    session; the job's fingerprint when not given.

    `think`, True or False, lets the model think before each verdict, or
    not, for this job whatever its endpoints say (llm.LLM.thinking): how
    two runs of the same questions show what thinking changes. None keeps
    each endpoint's own setting.

    `on_thinking(position, phase, text)`, when given, hears each question's
    reply as the model writes it: "thinking" or "answering" and the last
    characters of it, for a page that shows the run as it goes.

    `judge`, "single" or "agent", picks the judge: the single call and its
    checks, or the agent that explores the database (verdict_agent). None
    reads DATAGORA_JUDGE, and "agent" when that is unset (judge_mode).

    `context`, who asks and when (context.resolve): the date every judge
    counts "last year" or "this month" from. None is the machine's date
    and DATAGORA_CONTEXT."""
    profile, llm = resolve_names(profile, llm)
    done = skip or set()
    work = []
    for item in questions:
        text = item["question"] if isinstance(item, dict) else str(item)
        extra = {k: v for k, v in item.items() if k != "question"} \
            if isinstance(item, dict) else {}
        if text.strip() and text not in done:
            work.append((text, extra))

    slots = _slots(profile, connect, schema, llm, workers, think, judge, context)
    for clar in slots:
        # the agent checks the stop between its turns, so a stopped job
        # does not wait for a question's every turn to finish
        if hasattr(clar, "cancel_event"):
            clar.cancel_event = cancel
    if on_slots is not None:
        # one name per request in flight: "gpu0" four times for a server
        # taking four, which is what an estimate of the time left needs
        on_slots([str(getattr(getattr(c, "_llm", None), "name", "") or "model")
                  for c in slots[:max(1, len(work))]])
    # the job names the batch everywhere it is recorded: in the run's
    # manifest, and as the Langfuse session its questions are traced under
    job = job or job_id([{"question": q, **x} for q, x in work])
    if len(slots) <= 1 or len(work) <= 1:
        # one slot is the old path exactly, with no thread anywhere: a
        # caller's own model object, a single endpoint, Ctrl-C and
        # stop_on_error all behave as they always have
        clar = slots[0]
        out = []
        for text, extra in work:
            if cancel is not None and cancel.is_set():
                break
            try:
                v = _judge_one(clar, text, extra, stop_on_error,
                               job=job, position=len(out), session=session,
                               on_thinking=on_thinking)
            except Exception as e:
                if _stops_the_job(e):
                    break
                raise
            out.append(v)
            if on_each is not None:
                on_each(v)
        return out
    return _assess_in_parallel(slots, work, on_each, stop_on_error, job=job,
                               cancel=cancel, session=session, on_thinking=on_thinking)


def _judge_one(clar, text, extra, stop_on_error, job=None, position=None,
               session=None, on_thinking=None):
    """One verdict, traced as one question of its run when tracing is on.

    The trace is tagged with the endpoint the slot is bound to, which is
    how a batch spread over several GPUs is read back per GPU, and ends on
    the verdict, so a run's traces read as its results. The verdict
    carries its time and its server, which the page estimates from."""
    import time
    model = getattr(clar, "_llm", None)
    if model is not None and on_thinking is not None:
        # this slot's model tells the page what it writes, for this
        # question; each slot has its own model object, so two questions
        # in flight never speak for each other
        model.on_progress = lambda phase, said, p=position: on_thinking(p, phase, said)
    started = time.monotonic()
    obs = _observability()
    if obs is None:
        v = _judge_core(clar, text, extra, stop_on_error)
    else:
        profile = getattr(clar, "profile", None)
        with obs.question_span(job=job, position=position, question=text,
                               endpoint=getattr(model, "name", None),
                               model=getattr(model, "model", None),
                               session=session, think=getattr(model, "think", None),
                               database=getattr(profile, "name", None)) as handle:
            v = _judge_core(clar, text, extra, stop_on_error)
            if handle is not None:
                try:
                    handle.update(output={"verdict": v.verdict, "kind": v.kind,
                                          "answer_to_give": v.sentence(),
                                          "choices": v.choices})
                except Exception:
                    pass          # the verdict matters; its trace is a record
    v.seconds = round(time.monotonic() - started, 3)
    v.served_by = str(getattr(model, "name", "") or "")
    v.position = position
    return v


def _observability():
    try:
        if __package__:
            from . import observability as obs
        else:
            import observability as obs
        return obs if obs.client() is not None else None
    except Exception:
        return None


def _trace_of(clar, result=None, error=None):
    """What the clarifier kept of the question it just judged, for the
    run's trace file. A clarifier of another make keeps none of it, and
    that is a trace of Nones, never a failure. The agent keeps a trace of
    its own (its reading, plan, steps and checks), which is used whole."""
    try:
        agent = getattr(clar, "last_trace", None)
        if isinstance(agent, dict):
            out = dict(agent)
            if error is not None:
                out["error"] = error
            return out
        out = {"mode": "single", "reply": getattr(clar, "last_reply", None),
               "tables_shown": getattr(clar, "last_shown", None)}
        if result is not None:
            out.update(action=getattr(result, "action", None),
                       reason=getattr(result, "reason", None),
                       asks=getattr(result, "question", None),
                       checked=getattr(result, "checked", None),
                       empty=getattr(result, "empty", None))
        if error is not None:
            out["error"] = error
        return out
    except Exception:
        return None


def _judge_core(clar, text, extra, stop_on_error):
    try:
        result = clar.clarify(text)
        verdict, missing = classify(result)
        v = Verdict(question=text, verdict=verdict, kind=result.kind,
                    missing=missing,
                    choices=[o.label for o in result.options], extra=extra,
                    trace=_trace_of(clar, result))
        if stop_on_error and verdict == UNKNOWN:
            raise RuntimeError(f"{text}: {missing}")
        return v
    # Some configuration helpers use SystemExit for a missing model.
    # Treat that like any other failed question, while deliberately
    # letting Ctrl-C through so a person can stop a long batch.
    except (Exception, SystemExit) as e:
        if stop_on_error or _stops_the_job(e):
            raise
        said = f"{type(e).__name__}: {e}"[:160]
        return Verdict(question=text, verdict=UNKNOWN, missing=said,
                       extra=extra, trace=_trace_of(clar, error=said))


def _stops_the_job(e):
    """Whether a question failed because its job was stopped (the agent's
    AgentCancelled). Such a question has no verdict, not even UNKNOWN: it
    is left for the resume to judge (review of 26 October: a Stop wrote
    UNKNOWN rows, which the bench scored as wrong and judged_with counted
    as judged)."""
    return bool(getattr(e, "stops_the_job", False))


def judge_mode(judge=None):
    """The judge a run uses: "agent" (the default since 1.0.0) or "single".

    The agent judged 39 of the 40 Enterprise questions as intended on 20
    October where the single call judged 33; it takes two to three times
    as long, which a coverage run can afford and a person waiting on Ask
    cannot (Pipeline.judge_mode keeps the single call there). A value that
    is neither is the default."""
    mode = str(judge or os.environ.get("DATAGORA_JUDGE") or "agent").strip().lower()
    return mode if mode in ("agent", "single") else "agent"


def _slots(profile, connect, schema, llm, workers=None, think=None, judge=None,
           context=None):
    """One judge per request the model servers can take at once: the
    clarifiers below, as they are, or each wrapped in the agent judge.
    Each is told who asks and when (context.py): the machine's date when
    the run starts, unless `context` says otherwise."""
    if __package__:
        from .context import describe, resolve, today
    else:
        from context import describe, resolve, today
    clars = _clarifiers(profile, connect, schema, llm, workers, think)
    # the day, never the minute: a coverage run is a measure, and the same
    # question must send the same prompt whenever it is run (decided on 26
    # October; Ask keeps the minute, where "this hour" can count)
    ctx = {k: v for k, v in resolve(context).items() if k != "time"}
    said = describe(ctx)
    for c in clars:
        try:
            c.context, c.today = said, today(ctx)
        except AttributeError:
            pass
    return _as_judges(clars, judge)


def _as_judges(clars, judge=None):
    """The clarifiers as agent judges when the run asks for the agent.

    Only clarifiers of our own make are wrapped: a stand-in a caller or a
    test handed in stays exactly as it is. The schema is read once, on the
    first slot and before any thread starts, and shared by every slot."""
    if (judge_mode(judge) != "agent" or not clars
            or not all(isinstance(c, _RealClarifier) for c in clars)):
        return clars
    if __package__:
        from .verdict_agent import VerdictAgent, VotingAgent
        from .verdict_tools import SchemaView, Settings
    else:
        from verdict_agent import VerdictAgent, VotingAgent
        from verdict_tools import SchemaView, Settings
    view = SchemaView(clars[0], profile_path=_profile_path(getattr(clars[0], "profile", None)))
    settings = Settings.from_environment()
    # the vote of step 20, when the engine setting asks for it
    agent = VotingAgent if getattr(settings, "arbiter", "off") == "vote" else VerdictAgent
    return [agent(c, view=view, settings=settings) for c in clars]


def _profile_path(profile):
    """The column profile of a database (scripts/profile_columns.py), beside
    its descriptions and named after it, when there is one."""
    if profile is None or not getattr(profile, "name", None):
        return None
    data_dir = pathlib.Path(os.environ.get("DATAGORA_DATA_DIR")
                            or pathlib.Path(__file__).resolve().parents[2] / "data")
    desc = getattr(profile, "descriptions", None)
    folder = data_dir / "files"
    if desc:
        p = pathlib.Path(desc)
        folder = p.parent if p.is_absolute() else data_dir / p.parent
    path = folder / f"{profile.name}.profile.json"
    return str(path) if path.is_file() else None


def _clarifiers(profile, connect, schema, llm, workers=None, think=None):
    """One clarifier per request the model servers can take at once.

    A slot is one request in flight. An endpoint with `parallel` 2 gives two
    slots, and two endpoints on the reasoner role give the sum, which is how
    a batch spreads over two GPUs, on one machine or on two. Each slot has
    its own model object, so the error one request records cannot be read
    as another's, and its own clarifier, all sharing one read of the schema.

    A model object the caller handed in is theirs and may not be safe to
    share across threads, so it gets exactly one slot: parallelism is only
    ever switched on for endpoints this package built itself.
    """
    import copy as _copy

    def build(model):
        return (Clarifier(profile, model) if profile is not None
                else Clarifier.for_connection(connect, schema, model))

    if llm is not None and not isinstance(llm, (list, tuple)):
        return [build(llm)]
    try:
        if isinstance(llm, (list, tuple)):
            pool = list(llm)
        else:
            if __package__:
                from .llm import LLM
            else:
                from llm import LLM
            pool = LLM.pool("reasoner")
    except (Exception, SystemExit):
        # no pool to be had: fall back to the clarifier choosing its own
        # model, which is what it did before pools existed
        return [build(None)]

    models = []
    for endpoint in pool:
        for _ in range(max(1, int(getattr(endpoint, "parallel", 1) or 1))):
            # the job's thinking, when it sets it, over the endpoint's
            if think is not None and hasattr(endpoint, "thinking"):
                models.append(endpoint.thinking(think))
            else:
                models.append(_copy.copy(endpoint))
    if workers:
        models = models[:max(1, int(workers))]
    if not models:
        return [build(None)]

    first = build(models[0])
    clars = [first]
    if len(models) > 1:
        # read the schema once, then hand the same reading to every slot:
        # the catalogue, the sample values and the keys are the same for all
        # of them, and reading them per slot multiplies queries on the
        # customer's database for no gain
        for prop in ("columns", "views", "keys", "foreign_keys", "samples",
                     "meanings", "vocabulary", "graph_edges"):
            try:
                getattr(first, prop)
            except Exception:
                pass
        for model in models[1:]:
            c = build(model)
            for attr in ("_columns", "_views", "_keys", "_foreign_keys",
                         "_samples", "_meanings", "_vocabulary",
                         "_graph_edges"):
                if hasattr(first, attr):
                    setattr(c, attr, getattr(first, attr))
            clars.append(c)
    return clars


def _assess_in_parallel(slots, work, on_each, stop_on_error, job=None,
                        cancel=None, session=None, on_thinking=None):
    """Judge concurrently, and hand each verdict back as soon as it is ready.

    Verdicts used to be released in the order asked, so one slow first
    question held every other one back and a page showed nothing until
    the end. Each verdict now carries its `position`, which is what puts
    it on its row, on the screen as in the file (reordered when the run
    ends). on_each is still called one at a time, under the lock; the
    list returned is in the order asked.
    """
    import queue
    import threading

    tasks = queue.Queue()
    for position, (text, extra) in enumerate(work):
        tasks.put((position, text, extra))

    lock = threading.Lock()
    stop = threading.Event()
    failure = []
    out = []

    def release(v):
        # called with the lock held
        out.append(v)
        if on_each is not None:
            on_each(v)

    def worker(clar):
        # the questions are taken in order, so when a stop is asked the
        # ones taken form an unbroken run from the first: each finishes and
        # is released, and a resume starts at the first one not taken
        while not stop.is_set() and not (cancel is not None and cancel.is_set()):
            try:
                position, text, extra = tasks.get_nowait()
            except queue.Empty:
                return
            try:
                v = _judge_one(clar, text, extra, stop_on_error,
                               job=job, position=position, session=session,
                               on_thinking=on_thinking)
            except BaseException as e:           # stop_on_error, or Ctrl-C
                if _stops_the_job(e):
                    return
                with lock:
                    failure.append(e)
                stop.set()
                return
            v.position = position
            with lock:
                try:
                    release(v)
                except BaseException as e:       # the caller's own callback
                    failure.append(e)
                    stop.set()
                    return

    threads = [threading.Thread(target=worker, args=(c,), daemon=True)
               for c in slots[:len(work)]]
    for t in threads:
        t.start()
    try:
        for t in threads:
            while t.is_alive():
                t.join(0.2)
    except KeyboardInterrupt:
        stop.set()
        raise
    if failure:
        raise failure[0]
    out.sort(key=lambda v: v.position)
    return out


def read_questions_from_text(text):
    """Questions out of CSV text, or one per line.

    Split out from read_questions so the page can hand over what a
    browser read from the user's file without anything landing on the
    server. Both shapes happen, and refusing one of them for tidiness
    would only mean someone reformats a file by hand.

    The CSV is read whole, not line by line, so a quoted question that
    runs over two lines keeps them (review of 26 October: "line one" and
    "line two" became "line oneline two")."""
    lines = [l for l in text.splitlines() if l.strip()]
    if not lines:
        return []
    # from the first line that holds anything: a blank line before the
    # header would otherwise be read as the header
    body = text[text.index(lines[0]):]
    # A one-column CSV has no delimiter in its header, so Sniffer cannot
    # distinguish it from a plain line list. The explicit column name can.
    if lines[0].strip().strip('"').casefold() in ("question", "questions"):
        rows = [row for row in csv.reader(io.StringIO(body)) if row]
        # one column: cells past it are an unquoted comma in the question
        # (review of the fixes: "What is A, and B?" became "What is A")
        joined = [",".join(row).strip() for row in rows[1:]]
        return [{"question": q} for q in joined if q]
    if ("," in lines[0] or ";" in lines[0]) and _looks_like_header(lines[0]):
        try:
            delimiter = csv.Sniffer().sniff(lines[0] + "\n").delimiter
        except csv.Error:
            delimiter = ","
        # the delimiter alone from the sniffer: read on one line, it also
        # guessed doublequote False, and "He said ""hi""" broke the row
        # (review of the fixes); the rest is standard CSV
        reader = csv.DictReader(io.StringIO(body), delimiter=delimiter)
        key = _question_column(reader.fieldnames or [])
        if key is not None:
            rows = [_plain_row(r, key, reader.fieldnames, delimiter) for r in reader]
            # A row may carry metadata but no question. Keeping it in the
            # batch total while assess() silently skipped it shifted every
            # following SSE index, putting verdicts beside the wrong rows.
            return [dict(r, question=r[key].strip()) for r in rows if r[key].strip()]
    return [{"question": l.strip()} for l in lines
            if not l.startswith("#")]


def _question_column(names):
    """The column holding the questions: the one named "question", else
    one whose name says it holds the question's text (question_text,
    question_body), else one that says question and nothing about the
    question (an id, a number, a type, an index...), else any that says
    question; None when no column does. Review of 26 October: the first
    name holding "question" was taken, so a file headed
    question_id,question judged "Q1", "Q2"... instead of its questions;
    review of the fixes: question_type, question_index and "Question #"
    still were."""
    said = [n for n in names if n and "question" in n.casefold()]
    for n in said:
        if n.strip().casefold() in ("question", "questions"):
            return n
    for n in said:
        if re.search(r"(text|body|wording|phrase|content|asked)$", n.strip().casefold()):
            return n
    meta = r"(id|no|nr|num|number|#|key|ref|code|type|kind|index|idx|count|category|class" \
           r"|level|status|group|theme|topic|order|rank|date|lang|language)$"
    for n in said:
        if not re.search(meta, n.strip().casefold()):
            return n
    return said[0] if said else None


def _looks_like_header(line):
    """Whether a first line reads as column names: none ends a question
    and none is a sentence. A plain list whose first question holds
    "question" and a comma was read as a header and lost (review of the
    fixes: "Which question types, by month?")."""
    cells = [c.strip().strip('"') for c in re.split(r"[,;]", line)]
    return all(not c.endswith("?") and len(c.split()) <= 4 for c in cells)


def _plain_row(row, key, names, delimiter):
    """One row with a value of text under every column name: a short row
    leaves "" rather than None (a resume compared "None" with "" and
    refused the file for ever), and the cells past the last column, an
    unquoted comma in the text, go back into the question when it is the
    last column and under "_rest" otherwise, never under a None key,
    which sorted() could not order (review of 26 October)."""
    rest = [str(x) for x in (row.pop(None, None) or [])]
    # a delimiter that ends the line is no cell (review of the fixes:
    # "What is A?," was judged with its comma)
    while rest and not rest[-1].strip():
        rest.pop()
    out = {k: ("" if v is None else str(v)) for k, v in row.items() if k is not None}
    if rest:
        if names and names[-1] == key:
            out[key] = delimiter.join([out.get(key, "")] + rest)
        else:
            out["_rest"] = delimiter.join(rest)
    return out


def read_questions(path):
    """A CSV with a `question` column, or one question per line."""
    with open(path, encoding="utf-8-sig") as fh:
        return read_questions_from_text(fh.read())


def remaining_questions(questions, completed=()):
    """Input positions still to assess, preserving duplicate questions."""
    done = {i for i in completed if 0 <= i < len(questions)}
    return [(i, question) for i, question in enumerate(questions)
            if i not in done]


def remaining_by_text(questions, done=()):
    """Input positions still to assess, matched on the question itself.

    Positions move the moment a list is edited: insert one question at
    the top and every verdict after it would be credited to its
    neighbour. What a verdict belongs to is the question, so that is
    what it is matched on, and a multiset keeps two identical questions
    resuming independently rather than collapsing into one."""
    left = Counter(str(text).strip() for text in done)
    todo = []
    for index, question in enumerate(questions):
        text = (question["question"] if isinstance(question, dict)
                else str(question)).strip()
        if left.get(text):
            left[text] -= 1
        else:
            todo.append((index, question))
    return todo


def saved_todo(questions, ledger):
    """Use a persisted ledger, not browser memory, to resume a saved run.

    Browser state has positions and question text but not the complete
    verdict rows required to seed a newly named CSV.  Trusting it split a
    single job across output files.  The ledger can safely resume itself.
    """
    pending = {id(question) for question in ledger.pending(questions)}
    return [(index, question) for index, question in enumerate(questions)
            if id(question) in pending]


def row_for(v, extra_fields=None):
    extra_fields = extra_fields or {}
    row = {extra_fields.get(key, key): value
           for key, value in v.extra.items()}
    row.update({"question": v.question, "verdict": v.verdict,
                # the kind is a classification of an ambiguity, so it
                # means nothing next to a question that had none
                "kind": "" if v.verdict == ANSWERABLE else v.kind,
                "answer_to_give": v.sentence(),
                "choices": " | ".join(v.choices)})
    return row


RESULT_FIELDS = ["question", "verdict", "kind", "answer_to_give", "choices"]
FINAL_VERDICTS = {ANSWERABLE, NEEDS_CHOICE, NEEDS_MORE, NOT_COVERED,
                  NO_DATA}


def _field_layout(extra_keys):
    """Map input metadata to unique output columns.

    A customer CSV is allowed to carry metadata called ``kind`` or
    ``verdict``.  Those names are also coverage result columns.  Writing
    both under the same heading produced malformed CSVs that could neither
    resume nor preserve the input row.  Only colliding input fields are
    renamed, deterministically, and the result columns keep their public
    names.
    """
    extra_keys = list(extra_keys)
    unavailable = set(extra_keys) | set(RESULT_FIELDS)
    mapped = {}
    for key in extra_keys:
        candidate = key
        if key in RESULT_FIELDS:
            candidate = f"input_{key}"
            while candidate in unavailable:
                candidate = f"input_{candidate}"
            unavailable.add(candidate)
        mapped[key] = candidate
    return mapped, [mapped[key] for key in extra_keys] + RESULT_FIELDS


def _write_rows(path, fields, rows):
    """Replace a CSV atomically, so compaction cannot leave half a file."""
    path = pathlib.Path(path)
    tmp_name = None
    try:
        with tempfile.NamedTemporaryFile(
                "w", encoding="utf-8-sig", newline="", delete=False,
                dir=path.parent, prefix=f".{path.name}.", suffix=".tmp") as fh:
            tmp_name = fh.name
            writer = csv.DictWriter(fh, fieldnames=fields,
                                    extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp_name, path)
    except BaseException:
        if tmp_name:
            try:
                pathlib.Path(tmp_name).unlink(missing_ok=True)
            except OSError:
                pass
        raise


def _row_key(row, source_fields, aliases=None):
    """What makes two rows the same question.

    The whole input row, not just its text: the same question can appear
    twice for two teams, and a set of strings would lose one of them."""
    if isinstance(row, dict):
        aliases = aliases or {}
        return tuple(str(row.get(aliases.get(name, name), ""))
                     for name in source_fields)
    return tuple([""] * (len(source_fields) - 1) + [str(row)])


class Ledger:
    """The output file, written one verdict at a time.

    Five hundred questions take the best part of an hour, and a run that
    only writes at the end throws all of it away when the fifty-first
    call times out. Every verdict is appended and flushed as it is
    reached, so the file on disk is always the truth about what has been
    decided, and a second run reads it back and skips what is there.

    The header is fixed from the input columns, because a CSV cannot grow
    a column halfway down. Reusing an output with another input shape is
    rejected with a useful message instead of silently shifting values
    under the wrong headings."""

    def __init__(self, path, extra_keys):
        self.path = pathlib.Path(path)
        self.extra_keys = list(extra_keys)
        self.source_fields = self.extra_keys + ["question"]
        self.extra_fields, self.fields = _field_layout(self.extra_keys)
        existed = self.path.exists() and self.path.stat().st_size > 0
        self.rows = self._read_existing() if existed else []
        existed = self.path.exists() and self.path.stat().st_size > 0
        # held open for the life of the run and closed by close(); a
        # `with` block would close it after the first row
        self.fh = open(self.path, "a" if existed else "w",  # noqa: SIM115
                       encoding="utf-8-sig", newline="")
        self.writer = csv.DictWriter(self.fh, fieldnames=self.fields,
                                     extrasaction="ignore")
        if not existed:
            self.writer.writeheader()
            self.fh.flush()

    def _read_existing(self):
        """Read real verdicts and remove retryable UNKNOWN rows.

        An UNKNOWN is not a verdict, it is the record of a failure to
        judge, usually a model that did not answer. Skipping those on a
        resume would let one network blip poison a file permanently, so
        they are dropped and retried, and the file is compacted to what
        actually stands before anything is appended to it."""
        try:
            with open(self.path, encoding="utf-8-sig", newline="") as fh:
                reader = csv.DictReader(fh)
                if reader.fieldnames != self.fields:
                    raise ValueError(
                        f"{self.path} does not match this question file "
                        f"(columns are {reader.fieldnames}, expected "
                        f"{self.fields}); use --restart or another --out")
                rows = [r for r in reader if r.get("question")]
        except (OSError, csv.Error) as e:
            raise ValueError(f"cannot resume {self.path}: {e}") from e
        # A hard kill can leave the final CSV record half-written. Only a
        # complete, real verdict is safe to skip; UNKNOWN and truncated
        # records are both retried.
        good = [r for r in rows
                if r.get("verdict") in FINAL_VERDICTS
                and all(r.get(name) is not None for name in self.fields)]
        if len(good) != len(rows):
            _write_rows(self.path, self.fields, good)
        return good

    def pending(self, questions):
        """Return unfinished input rows, matching duplicate occurrences.

        A question can legitimately occur twice for two clients, or even
        twice with identical metadata. A set of question strings loses
        that distinction, so resume uses a multiset of the complete input
        row. It also detects an output left over from a different input."""
        available = Counter(self._key(q) for q in questions)
        completed = Counter(
            self._key(row) for row in self.rows)
        stale = completed - available
        if stale:
            raise ValueError(
                f"{self.path} contains verdicts from another question list; "
                "use --restart or another --out")

        todo = []
        remaining = completed.copy()
        for question in questions:
            identity = self._key(question)
            if remaining[identity]:
                remaining[identity] -= 1
            else:
                todo.append(question)
        return todo

    def _key(self, row):
        # Input rows use their original names; persisted verdict rows use
        # the collision-safe names chosen above.
        aliases = (self.extra_fields
                   if any(name in row for name in self.extra_fields.values()
                          if name not in self.extra_keys)
                   else None) if isinstance(row, dict) else None
        return _row_key(row, self.source_fields, aliases=aliases)

    def order_like(self, questions):
        """Put a completed/resumed output back in input order."""
        buckets = {}
        for row in self.rows:
            buckets.setdefault(self._key(row), []).append(row)
        ordered = []
        for question in questions:
            rows = buckets.get(self._key(question), [])
            if rows:
                ordered.append(rows.pop(0))
        if len(ordered) != len(self.rows):
            raise ValueError(f"cannot reconcile {self.path} with its input")
        _write_rows(self.path, self.fields, ordered)
        self.rows = ordered

    def add(self, verdict, index=None):
        row = row_for(verdict, self.extra_fields)
        self.writer.writerow(row)
        self.fh.flush()          # the file is the record, not the process
        os.fsync(self.fh.fileno())
        self.rows.append(row)
        self.keep_trace(verdict, index)

    def keep_trace(self, verdict, index=None):
        """One line of how the verdict was reached, beside the CSV.

        The CSV says what was decided and keeps no reply, no table shown,
        and blanks the kind of an answer; reading a wrong verdict back
        meant running the question again. trace_path(path) holds one JSON
        object per verdict, appended. A record, so a failure to write it
        never costs the verdict."""
        try:
            line = {"index": index, "position": verdict.position,
                    "question": verdict.question, "id": verdict.extra.get("id"),
                    "verdict": verdict.verdict, "kind": verdict.kind,
                    "choices": verdict.choices, "served_by": verdict.served_by,
                    "seconds": verdict.seconds, **(verdict.trace or {})}
            with open(trace_path(self.path), "a", encoding="utf-8") as fh:
                fh.write(json.dumps(line, default=str, ensure_ascii=False) + "\n")
        except Exception:
            pass

    def close(self):
        self.fh.close()


def write_verdicts(path, verdicts):
    """The whole list at once, for a caller holding it all in memory."""
    extra_keys = sorted({k for v in verdicts for k in v.extra})
    extra_fields, fields = _field_layout(extra_keys)
    _write_rows(path, fields, [row_for(v, extra_fields) for v in verdicts])


def job_id(questions):
    """A short name for one set of questions, derived from the questions.

    The same list always produces the same id, and any change to it
    produces a different one. That is what lets a resume be keyed on the
    input rather than on the name somebody gave the output: you point at
    the same question file and the run continues, whatever the output was
    called, and you point at a changed file and it does not silently
    continue into a different job.

    It hashes the whole input row, not the question text alone, because
    that is what a resume matches on. Hashing less would let an edited
    metadata column keep its old id, send the run back to a file whose
    rows no longer match it, and fail there with nothing the person
    could do about it but rename the output by hand."""
    fields = sorted({key for question in questions
                     if isinstance(question, dict)
                     for key in question if key != "question"}) + ["question"]
    payload = "\n".join("\x1f".join(_row_key(question, fields))
                        for question in questions)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:12]


def manifest_path(output):
    return pathlib.Path(str(output) + ".job.json")


def trace_path(output):
    """Where a run keeps how each verdict was reached (Ledger.keep_trace)."""
    return pathlib.Path(str(output) + ".trace.jsonl")


def read_manifest(output):
    try:
        return json.loads(manifest_path(output).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def judged_with(output):
    """The judge the verdicts already in this output were decided by:
    the last run that judged anything, "single" for runs written before
    the agent existed, None for a file no run has judged yet.

    A run is on record with its judge before its first question, and its
    count is brought up to date as each verdict lands. One cut short
    between a verdict written and its count recorded still says 0, so a
    run that named its judge decides as soon as the file holds a verdict;
    one that named it and wrote nothing decided nothing."""
    runs = (read_manifest(output) or {}).get("runs") or []
    for run in reversed(runs):
        if run.get("judged"):
            return run.get("judge") or "single"
    named = [run["judge"] for run in runs if run.get("judge")]
    if named and _holds_verdicts(output):
        return named[-1]
    return None


def _holds_verdicts(output):
    """Whether the file holds a real verdict. An UNKNOWN is not one: a
    resume drops it and judges the question again."""
    try:
        with open(output, encoding="utf-8-sig", newline="") as fh:
            return any(row.get("verdict") in FINAL_VERDICTS
                       for row in csv.DictReader(fh))
    except (OSError, csv.Error):
        return False


def record_run(output, run):
    """Add one run's timing and configuration to its manifest, or bring
    the entry with the same `id` up to date.

    A job may be run several times, stopped and resumed, or run again after
    a change of model: each run is kept, so configurations can be compared
    on the same questions. The entry is written as the run goes, so a run
    cut short, by a restart of the server, still says how long it ran."""
    manifest = read_manifest(output)
    if manifest is None:
        return
    runs = manifest.setdefault("runs", [])
    if run.get("id") and runs and runs[-1].get("id") == run["id"]:
        runs[-1] = run
    else:
        runs.append(run)
    path = manifest_path(output)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def run_date(context=None):
    """The date a run's judges count from, as an ISO string."""
    if __package__:
        from .context import resolve, today
    else:
        from context import resolve, today
    return today(resolve(context)).isoformat()


def judged_on(output):
    """The database the verdicts already in `output` were judged against,
    when it holds any and its manifest says; else None."""
    on = (read_manifest(output) or {}).get("profile")
    return on if on and _holds_verdicts(output) else None


def resume_context(output, context=None):
    """The context a run of `output` judges with: the one given, else the
    date its first run counted from. A run resumed days later judged the
    rest against a new today, so "last month" meant two months in one file,
    and nothing said which (review of 26 October)."""
    if context is not None:
        return context
    # a date set on purpose in DATAGORA_CONTEXT wins over the pinned one
    # (review of the fixes: it was silently overridden on resume)
    try:
        if __package__:
            from .context import static_context
        else:
            from context import static_context
        if static_context(os.environ).get("date"):
            return None
    except Exception:
        pass
    first = (read_manifest(output) or {}).get("asked_on")
    return {"date": first} if first else None


def prompt_versions():
    """Every prompt's version, or {} when they cannot be read."""
    try:
        if __package__:
            from .prompts import versions
        else:
            from prompts import versions
        return versions()
    except Exception:
        return {}


def write_manifest(output, job, questions_path, total, profile=None, asked_on=None):
    """What this file is, beside the file.

    `profile` is recorded because a verdict only means anything about the
    database it was judged against, and nothing in the CSV says which one
    that was. Reopening a run with another database selected used to
    present its verdicts as if they belonged to that one. Optional, so a
    manifest written by an older build still reads."""
    manifest = {
        "job": job,
        "questions": str(questions_path),
        "total": total,
        # with its zone, so a browser shows it in its own time
        "started": datetime.now().astimezone().isoformat(timespec="seconds"),
    }
    if profile:
        manifest["profile"] = str(profile)
    if asked_on:
        manifest["asked_on"] = str(asked_on)
    # the prompts this run was judged with. A verdict is the product of a
    # question, a database, a model and a prompt; the first three were
    # recorded and the fourth was not, so a run from last week could not
    # be told apart from one judged by a prompt rewritten since.
    prompts = prompt_versions()
    if prompts:
        manifest["prompts"] = prompts
    # a Resume writes the manifest again: the runs before it, their times
    # and configurations, stay, with the job's first start. Rewritten whole,
    # it lost them, and the elapsed time of a resumed job began at zero.
    earlier = read_manifest(output)
    if earlier and earlier.get("job") == job:
        if earlier.get("runs"):
            manifest["runs"] = earlier["runs"]
        manifest["started"] = earlier.get("started") or manifest["started"]
        if earlier.get("asked_on"):
            manifest["asked_on"] = earlier["asked_on"]
        # a resume after a prompt changed: the file now holds verdicts of
        # two versions, which the manifest says rather than claiming the
        # newest alone; each run keeps its own (review of 26 October)
        before = earlier.get("prompts") or {}
        if earlier.get("prompts_mixed") or (
                earlier.get("runs") and before and prompts and before != prompts):
            manifest["prompts_mixed"] = True
    manifest_path(output).write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8")


def versioned(output, job):
    """Where this job's verdicts belong, without overwriting another's.

    An output that already holds a different job is left exactly as it
    is and this one goes beside it, named after its job. Losing an
    afternoon of verdicts because two runs happened to share a filename
    is not a trade worth making, and neither is asking a person to
    invent a distinct name every time."""
    output = pathlib.Path(output)
    existing = read_manifest(output)
    if existing is None or existing.get("job") == job:
        return output, False
    return output.with_name(f"{output.stem}.{job}{output.suffix}"), True


def siblings(output, job):
    """Other versions of this output, newest first.

    A version is recognised by its manifest, not by its name, so a file
    that happens to look like one is not mistaken for it."""
    output = pathlib.Path(output)
    found = []
    for path in [output] + sorted(
            output.parent.glob(f"{output.stem}.*{output.suffix}")):
        if path == output.with_name(f"{output.stem}.{job}{output.suffix}"):
            continue
        manifest = read_manifest(path)
        if manifest and manifest.get("job") != job and path.exists():
            found.append(path)
    return sorted(set(found), key=lambda p: p.stat().st_mtime, reverse=True)


def carry_over(target, sources, questions, fields, extra_keys):
    """Seed a new version with verdicts already decided for its questions.

    Adding one question to a file of five hundred gives a new job, and
    re-judging the other four hundred and ninety-nine to learn nothing
    would cost an hour. A row is carried only when the entire input row
    matches, so an edited question is judged again and an untouched one
    is not. `--restart` is there for anyone who wants the lot redone."""
    target = pathlib.Path(target)
    if target.exists() and target.stat().st_size:
        return 0
    source_fields = list(extra_keys) + ["question"]
    extra_fields, expected_fields = _field_layout(extra_keys)
    if list(fields) != expected_fields:
        raise ValueError("coverage output fields do not match input metadata")
    wanted = Counter(_row_key(q, source_fields) for q in questions)
    taken, rows = Counter(), []
    for path in sources:
        try:
            with open(path, encoding="utf-8-sig", newline="") as fh:
                reader = csv.DictReader(fh)
                if reader.fieldnames != fields:
                    continue          # another question file's shape
                found = list(reader)
        except (OSError, csv.Error):
            continue
        for row in found:
            key = _row_key(row, source_fields, aliases=extra_fields)
            if (row.get("verdict") in FINAL_VERDICTS
                    and all(row.get(name) is not None for name in fields)
                    and taken[key] < wanted.get(key, 0)):
                taken[key] += 1
                rows.append(row)
    if rows:
        _write_rows(target, fields, rows)
    return len(rows)


def assess_file(questions_path, out, *, profile=None, connect=None,
                schema=None, llm=None, restart=False, stop_on_error=False,
                on_each=None, judge=None, context=None):
    """Assess a question file with incremental, resumable CSV output.

    This is the library equivalent of the command line. ``profile`` may
    be a :class:`DbProfile` or a configured profile name. Alternatively,
    pass a DB-API ``connect`` factory and its ``schema``. ``llm`` may be
    an LLM object, a compatible callable, or a configured endpoint name.

    ``on_each`` receives ``(verdict, completed, total)`` only after the
    verdict has been flushed and synchronised to ``out``. Reusing the
    same paths resumes; UNKNOWN and truncated rows are retried. A resume
    is refused when the file holds verdicts of another judge or another
    database, and judges with the date its first run counted from unless
    ``context`` says otherwise.
    """
    profile, llm = resolve_names(profile, llm)
    if profile is None and (connect is None or not schema):
        raise ValueError("pass profile, or both connect and schema")

    questions = read_questions(questions_path)
    if not questions:
        raise ValueError(f"no questions found in {questions_path}")
    # the job is named by the questions, so a resume needs only the
    # input: point at the same question file and the run continues,
    # whatever the output happened to be called
    job = job_id(questions)
    requested = pathlib.Path(out)
    output, moved = versioned(requested, job)
    if restart:
        # Restart the resolved job, not the requested base name. If the
        # base belongs to another question list, deleting it here destroys
        # that run and moves this one into its place. The neighbouring
        # version is the only target the caller asked to restart.
        for path in (output, manifest_path(output), trace_path(output)):
            if path.exists():
                path.unlink()
    extra_keys = sorted({key for question in questions for key in question
                         if key != "question"})
    mode = judge_mode(judge)
    # a connection given by hand is named by its schema, so a file of one
    # schema is never resumed against another (review of the fixes)
    database = (getattr(profile, "name", None) or (profile if isinstance(profile, str) else None)
                or (f"schema {schema}" if schema else None))
    log_line = None
    carried_date = None
    if moved:
        log_line = (f"{requested} belongs to another job; this one is "
                    f"{output.name}")
    if moved and not restart:
        # a restart redoes the lot: carried verdicts are exactly what it is
        # asked to drop (review of 26 October: a re-measurement after a
        # prompt fix silently kept the old verdicts)
        _extra_fields, output_fields = _field_layout(extra_keys)
        # only verdicts of this run's judge: another's would make the new
        # version a mix of two judges that no run of it ever recorded
        # and of this database: the same questions judged against another
        # are another database's verdicts
        # and of the same prompts: verdicts of another version would be
        # carried under this one's (review of the fixes)
        prompts = prompt_versions()
        same_judge = [path for path in siblings(requested, job)
                      if judged_with(path) == mode
                      and (read_manifest(path) or {}).get("profile") == database
                      and (read_manifest(path) or {}).get("prompts") == prompts]
        reused = carry_over(output, same_judge, questions,
                            output_fields, extra_keys)
        if reused:
            log_line += (f", carrying {reused} verdict"
                         f"{'s' if reused != 1 else ''} already decided "
                         f"for unchanged questions")
            # the carried verdicts counted from their run's date: the rest
            # of this version counts from it too
            carried_date = next((m.get("asked_on") for m in
                                 (read_manifest(path) or {} for path in same_judge)
                                 if m.get("asked_on")), None)

    before = judged_with(output)
    if before and before != mode:
        # resumed with the other judge, the file would hold verdicts of two
        # judges under one name, and an A/B comparison would compare a run
        # with itself
        raise ValueError(f"{output} was judged by the {before} judge: write the {mode} run "
                         f"to another file (--out), or restart it to replace those verdicts")
    on = judged_on(output)
    if on and on != database:
        # review of 26 October: the same questions run on dbB into dbA's
        # file resumed dbA's verdicts, and the manifest then named dbB
        raise ValueError(f"{output} holds verdicts judged against {on}: write the {database} "
                         f"run to another file (--out), or restart it to replace those verdicts")
    pinned = context is None
    context = resume_context(output, context) or (
        {"date": carried_date} if carried_date and context is None else context)
    if pinned and context and context.get("date"):
        # said, so a resume days later is never a surprise
        log_line = (log_line + "; " if log_line else "") + \
            f"counting from {context['date']}, the date its first run did"
    ledger = Ledger(output, extra_keys)
    matched = False
    processed = 0
    already_done = 0
    stopped = None
    try:
        # with each question's place in the file, which the trace records:
        # verdicts come back as they finish, not in the order asked
        placed = saved_todo(questions, ledger)
        todo = [question for _index, question in placed]
        indices = [index for index, _question in placed]
        matched = True
        # stamped only once the file has been accepted as this job's. Written
        # before, a run rejected for belonging to another question list left
        # a manifest behind claiming it did not.
        write_manifest(output, job, questions_path, len(questions),
                       profile=database, asked_on=run_date(context))
        already_done = len(questions) - len(todo)
        # the run and its judge are on record before its first question,
        # and brought up to date as each verdict lands: a run stopped by
        # hand, by stop_on_error or by a crash still says which judge wrote
        # what it wrote, and a resume with the other one is refused
        run = {"id": uuid.uuid4().hex[:12],
               "started": datetime.now().astimezone().isoformat(timespec="seconds"),
               "judged": 0, "judge": mode,
               "agent_version": _agent_version() if mode == "agent" else None,
               # the date its judges counted from, and the prompts they ran
               "asked_on": run_date(context), "prompts": prompt_versions()}
        record_run(output, run)

        def save(verdict):
            nonlocal processed
            at = verdict.position
            ledger.add(verdict, index=indices[at] if at is not None
                       and 0 <= at < len(indices) else None)
            processed += 1
            run["judged"] = processed
            try:
                record_run(output, dict(run))
            except OSError:
                pass      # the verdict is saved, and judged_with reads it as this judge's
            if on_each is not None:
                on_each(verdict, already_done + processed, len(questions))

        assess(todo, profile=profile, connect=connect, schema=schema, llm=llm,
               on_each=save, stop_on_error=stop_on_error, judge=mode, context=context)
    except KeyboardInterrupt:
        stopped = "stopped by hand"
    except (Exception, SystemExit) as e:
        # a run that dies halfway is the case the ledger exists for, so
        # the reason belongs in the report beside the rows that did
        # land, not in a traceback that takes the report with it
        stopped = f"{type(e).__name__}: {e}"[:160]
    finally:
        ledger.close()
        if matched:
            ledger.order_like(questions)

    counts = Counter(row.get("verdict", UNKNOWN) for row in ledger.rows)
    return BatchReport(output=str(output), total=len(questions),
                       already_done=already_done, processed=processed,
                       counts=dict(counts), job=job, note=log_line,
                       stopped=stopped)


def _agent_version():
    try:
        if __package__:
            from .prompts import version_of
        else:
            from prompts import version_of
        return version_of("agent")
    except Exception:
        return None


def main():
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--questions", required=True,
                    help="CSV with a `question` column, or one per line")
    ap.add_argument("--profile", default=None)
    ap.add_argument("--out", default=None,
                    help="written one verdict at a time; re-running with the "
                         "same question file resumes where it stopped. "
                         "Defaults to <questions>.verdicts.csv")
    ap.add_argument("--restart", action="store_true",
                    help="ignore what is already in --out and do it all again")
    ap.add_argument("--endpoint", default=None)
    ap.add_argument("--judge", choices=("single", "agent"), default=None,
                    help="the single call and its checks, or the agent that "
                         "explores the database; DATAGORA_JUDGE when omitted")
    ap.add_argument("--stop-on-error", action="store_true",
                    help="stop at the first failure instead of recording it "
                         "as UNKNOWN and carrying on")
    args = ap.parse_args()

    if __package__:
        from .db_profile import DbProfile
        from .llm import LLM
    else:
        from db_profile import DbProfile
        from llm import LLM
    if not args.profile:
        raise SystemExit("--profile is required from the command line; "
                         "use assess() directly for another connection")
    profile = DbProfile.load(args.profile)
    llm = LLM.load(args.endpoint) if args.endpoint else None

    # the run always lands on disk. A batch of five hundred questions
    # that only exists in a terminal buffer is a batch that has to be
    # done again, so an omitted --out is named after the input rather
    # than meaning "keep it in memory"
    out = args.out or f"{pathlib.Path(args.questions).stem}.verdicts.csv"

    questions = read_questions(args.questions)
    if not questions:
        raise SystemExit(f"no questions found in {args.questions}")
    # say where the verdicts are going before spending an hour writing
    # them there. `versioned` is the same decision assess_file makes, so
    # the header cannot promise one file and the run use another
    job = job_id(questions)
    # a restart redoes the version that holds this job, as assess_file
    # does, not the base name (review of 26 October)
    dest = versioned(out, job)[0]
    print(f"\n{len(questions)} questions against {profile.name}")
    print(f"  job {job}, written to {dest}")
    if str(dest) != str(pathlib.Path(out)):
        print(f"  ({out} holds another job and is left alone)")
    print()

    def show(v, done, total):
        # .get: a line of progress must never be what stops a batch. A
        # verdict missing here once did, on the first NO DATA of a real run
        mark = {ANSWERABLE: "yes ", NEEDS_CHOICE: "pick", NEEDS_MORE: "ask ",
                NOT_COVERED: "no  ", NO_DATA: "none",
                UNKNOWN: "??  "}.get(v.verdict, "    ")
        print(f"  [{done:4}/{total:4} {done / total:6.1%}] "
              f"{mark} {v.question[:52]:52} {v.sentence()[:58]}",
              flush=True)

    try:
        report = assess_file(args.questions, out, profile=profile, llm=llm,
                             restart=args.restart, on_each=show,
                             stop_on_error=args.stop_on_error, judge=args.judge)
    except ValueError as e:
        raise SystemExit(str(e))

    if report.note:
        print(f"\n  {report.note}")
    print("\n" + "=" * 62)
    counts = report.counts
    total = sum(counts.values())
    for name in (ANSWERABLE, NEEDS_CHOICE, NEEDS_MORE, NO_DATA, NOT_COVERED,
                 UNKNOWN):
        n = counts.get(name, 0)
        if n:
            print(f"  {name:16} {n:3}   {n / max(total, 1):.0%}")
    if report.already_done:
        print(f"\n  {report.already_done} of those were already decided "
              f"and were not asked again")
    if report.stopped:
        # the point of the ledger: say exactly where it stopped and how
        # to pick it up, rather than leaving a half-finished file to be
        # puzzled over
        print(f"\nSTOPPED after {report.processed} of "
              f"{report.total - report.already_done} remaining: "
              f"{report.stopped}")
        print(f"  {total} of {report.total} verdicts are in "
              f"{report.output}. To carry on, repeat the command; the "
              f"question file is what a resume is keyed on:")
        # with the judge and the endpoint it ran with: resumed without
        # --judge, a single-judge run was refused for the agent's default
        again = (f"--profile {args.profile} --questions {args.questions} --out {out} "
                 f"--judge {judge_mode(args.judge)}")
        if args.endpoint:
            again += f" --endpoint {args.endpoint}"
        print(f"      python coverage.py {again}")
        sys.exit(1)

    covered = counts.get(ANSWERABLE, 0) + counts.get(NEEDS_CHOICE, 0)
    print(f"\n  {covered} of {total} answerable today, "
          f"{counts.get(NEEDS_MORE, 0)} answerable once the question says "
          f"more,\n  {counts.get(NO_DATA, 0)} askable with an empty result, "
          f"{counts.get(NOT_COVERED, 0)} not held by this database.")
    if counts.get(UNKNOWN):
        print(f"  {counts[UNKNOWN]} could not be judged at all, which is "
              f"not the same as a no. Re-running retries those and leaves "
              f"the rest alone.")
    # nothing judged is a failed run, not a finding about the database,
    # and a script downstream has to be able to tell the two apart
    if total and counts.get(UNKNOWN, 0) == total:
        print("\n  NOTHING was judged: every call failed. This says "
              "nothing about the database.")
        print(f"  {report.output} holds the reasons. Re-running retries "
              f"them all.")
        sys.exit(1)
    if counts.get(UNKNOWN):
        print("\n  INCOMPLETE: at least one question was not judged.")
        print("  Re-run the same command to retry only those questions.")
        sys.exit(1)
    print(f"\n  written to {report.output}")
    print()


if __name__ == "__main__":
    main()
