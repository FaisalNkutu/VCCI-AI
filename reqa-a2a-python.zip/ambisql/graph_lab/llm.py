"""One tiny client for both APIs we serve models with.

Ollama in development, vLLM in production, and vLLM speaks the OpenAI
API. Naming the endpoint in models.json rather than in the code is what
lets the clarifier be written and tested on a laptop and then pointed at
the GPU server or JARVIS without a line changing.

    llm = LLM.load()                 # the default endpoint
    llm = LLM.load("server-gemma")   # a named one
    llm.json(system, user)           # a dict, or None if unusable
"""

import contextlib
import json
import os
import re
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

HERE = Path(__file__).parent
# What every lookup says when no model is configured; there is no
# packaged file to fall back on any more, see db_profile.NOTHING_CONFIGURED.
NO_MODEL_CONFIGURED = (
    "no model endpoint is configured. List them in .env with "
    "DATAGORA_ENDPOINTS and one block of DATAGORA_ENDPOINT_<NAME>_* "
    "variables each, and say which plays which part with "
    "DATAGORA_LLM_REASONER and DATAGORA_LLM_SQL (deploy/TESTING.md has a "
    "complete example), or add them on the settings page.")


def _environment():
    """The environment with the repository's .env under it, the one view
    db_profile reads too, so both sides agree on what is configured."""
    if __package__:
        from .db_profile import environment
    else:
        from db_profile import environment
    return environment()


def _block_key(name):
    return "".join(c if c.isalnum() else "_" for c in name).upper()


def _names(text):
    return [n.strip() for n in str(text or "").split(",") if n.strip()]


def env_endpoints(env=None):
    """The endpoints and roles the .env lists, or None when it lists none.

        DATAGORA_ENDPOINTS=gpu_a,gpu_b
        DATAGORA_ENDPOINT_GPU_A_URL=http://10.0.0.5:11434
        DATAGORA_ENDPOINT_GPU_A_MODEL=gemma4:31b
        DATAGORA_ENDPOINT_GPU_A_API=ollama          (the default)
        DATAGORA_ENDPOINT_GPU_A_NUM_CTX=16384
        DATAGORA_ENDPOINT_GPU_A_PARALLEL=2
        DATAGORA_ENDPOINT_GPU_A_KEEP_ALIVE=30m
        DATAGORA_ENDPOINT_GPU_A_TIMEOUT=600          (seconds a reply is waited for)
        DATAGORA_ENDPOINT_GPU_A_THINK=on             (or off: whether a model that can think does so first)
        DATAGORA_LLM_REASONER=gpu_a,gpu_b
        DATAGORA_LLM_SQL=gpu_a

    A role names one endpoint or several. Several is a pool: a coverage run
    spreads its questions over all of them, as many at a time on each as
    its PARALLEL says. Unset, both roles play on the first endpoint."""
    env = _environment() if env is None else env
    names = _names(env.get("DATAGORA_ENDPOINTS"))
    if not names:
        return None
    endpoints = {}
    for name in names:
        prefix = f"DATAGORA_ENDPOINT_{_block_key(name)}_"
        url, model = env.get(prefix + "URL"), env.get(prefix + "MODEL")
        if not url or not model:
            raise SystemExit(f"endpoint {name!r} is listed in "
                             f"DATAGORA_ENDPOINTS but {prefix}URL and "
                             f"{prefix}MODEL are not both set")
        cfg = {"api": env.get(prefix + "API") or "ollama", "url": url,
               "model": model}
        for field in ("NUM_CTX", "PARALLEL", "KEEP_ALIVE", "TIMEOUT", "THINK"):
            if env.get(prefix + field):
                cfg[field.lower()] = env[prefix + field]
        endpoints[name] = cfg
    pools = {}
    for role in ("reasoner", "sql"):
        chosen = _names(env.get(f"DATAGORA_LLM_{role.upper()}"))
        unknown = [n for n in chosen if n not in endpoints]
        if unknown:
            raise SystemExit(f"DATAGORA_LLM_{role.upper()} names {unknown}, "
                             f"which DATAGORA_ENDPOINTS does not list "
                             f"({names})")
        pools[role] = chosen or list(pools.get("reasoner") or names[:1])
    # DATAGORA_LLM_RERANKER, only when set: no reranker otherwise (rerank.py)
    reranker = _names(env.get("DATAGORA_LLM_RERANKER"))
    if reranker:
        unknown = [n for n in reranker if n not in endpoints]
        if unknown:
            raise SystemExit(f"DATAGORA_LLM_RERANKER names {unknown}, which "
                             f"DATAGORA_ENDPOINTS does not list ({names})")
        pools["reranker"] = reranker
    roles = {role: pool[0] for role, pool in pools.items()}
    return {"roles": roles, "pools": pools, "endpoints": endpoints,
            "default": roles["reasoner"]}

LOOPBACK = ("127.0.0.1", "localhost", "[::1]", "0.0.0.0")

# {(url, model): whether the model can think}, from Ollama's /api/show
_THINKERS = {}

# the watcher of the model calls made in this thread, see watching()
_WATCH = threading.local()


@contextlib.contextmanager
def watching(progress):
    """Every model call made in this thread meanwhile hands `progress` what
    it writes, as on_progress does for one model: an Ask followed on its
    page, whose models are shared with other requests and so cannot carry
    one Ask's watcher themselves."""
    before = getattr(_WATCH, "progress", None)
    _WATCH.progress = progress
    try:
        yield
    finally:
        _WATCH.progress = before


def host_gateway(url):
    """Loopback, rewritten to the machine hosting this container.

    Inside a container 127.0.0.1 is the container, so an endpoint written
    for a laptop silently points at nothing. Compose sets
    DATAGORA_HOST_GATEWAY and every loopback address is redirected to it,
    whichever endpoint it belongs to.

    Keyed on the address rather than on the endpoint's name, because the
    name-based version of this rule only covered the one endpoint the
    environment happened to mention: switching a role to any other local
    entry brought back `Connection refused` from inside the container.
    Addresses that are not loopback, a GPU server or JARVIS, are left
    exactly as written."""
    gateway = os.environ.get("DATAGORA_HOST_GATEWAY")
    if not gateway or not url:
        return url
    for host in LOOPBACK:
        if f"//{host}:" in url or url.endswith(f"//{host}"):
            return url.replace(f"//{host}", f"//{gateway}", 1)
    return url


def _tracing():
    """observability and the prompt lookup, or (None, None) when tracing
    is off or unavailable. Imported late so llm.py stays light and
    importable on its own."""
    try:
        if __package__:
            from . import observability as obs
            from .prompts import name_of
        else:
            import observability as obs
            from prompts import name_of
        return (obs, name_of) if obs.client() is not None else (None, None)
    except Exception:
        return None, None


def _settings_store():
    """The settings page's store, or None where it is not shipped.

    Imported the way every sibling is, as a package first. A bare
    `import settings_store` only worked when this folder was on sys.path,
    so an application importing graph_lab as a package silently ignored
    everything the settings page saved."""
    try:
        if __package__:
            from . import settings_store
        else:
            import settings_store
        return settings_store
    except ImportError:
        return None


def _saved_models():
    """The endpoints the settings page saved, or None when it saved none."""
    settings_store = _settings_store()
    if settings_store is None:
        return None
    try:
        return settings_store.models_document()
    except Exception:
        return None


def models_data(path=None):
    """The one reader behind every lookup of a model, in one order.

    The settings page first, as for the databases; then the .env's list,
    then a single model described by the environment, then a file. The same
    four lines used to be repeated in four methods, which is how an order
    of precedence drifts: change one copy and a role resolves differently
    from the endpoint list that is supposed to describe it."""
    if path is None:
        saved = _saved_models()
        if saved is not None:
            return saved
        listed = env_endpoints()
        if listed is not None:
            return listed
        data = env_models()
        if data is not None:
            return data
    path = Path(path) if path else models_path()
    return json.loads(path.read_text(encoding="utf-8"))


def models_source():
    """Where the model endpoints are actually being read from.

    Returns (description, missing): `missing` is True when nothing is
    configured, which a page shows as the thing to fix first."""
    if _saved_models() is not None:
        try:
            where = _settings_store().store_path()
        except Exception:
            where = "the settings file"
        return (f"the settings page ({where})", False)
    listed = env_endpoints()
    if listed is not None:
        return (f"the .env (DATAGORA_ENDPOINTS: {', '.join(listed['endpoints'])};"
                f" reasoner {', '.join(listed['pools']['reasoner'])}, sql "
                f"{', '.join(listed['pools']['sql'])}), since the settings "
                f"page has no model endpoint", False)
    env = _environment()
    print(f"========================================= models_source() =============================================================================")
    print(f"env={env}")
    print(f"======================================================================================================================================")
    named = env.get("DATAGORA_MODELS")
    endpoint = env.get("DATAGORA_LLM_ENDPOINT")
    described = env.get("DATAGORA_LLM_URL") and env.get("DATAGORA_LLM_MODEL")
    # DATAGORA_LLM_ENDPOINT names an entry of a file, so setting it sends
    # the whole resolution back to that file. A deployment that had also
    # described its model with DATAGORA_LLM_URL and DATAGORA_LLM_MODEL
    # then runs on neither, and on no model it chose.
    cancelled = (" DATAGORA_LLM_ENDPOINT is also set, which cancels them: "
                 "they are being ignored."
                 if endpoint and described else "")
    if named:
        return (f"the file named by DATAGORA_MODELS ({named})"
                + (f", at the endpoint named by DATAGORA_LLM_ENDPOINT "
                   f"({endpoint})" if endpoint else "") + cancelled, False)
    if described and not endpoint:
        return ("the environment (DATAGORA_LLM_URL and "
                "DATAGORA_LLM_MODEL)", False)
    return ("nothing: " + NO_MODEL_CONFIGURED, True)


def env_models():
    """The models the environment describes, or None.

    A deployment serving one model does not need a file to say so:
    DATAGORA_LLM_URL and DATAGORA_LLM_MODEL are enough, and every role
    plays on it. DATAGORA_LLM_SQL_URL and DATAGORA_LLM_SQL_MODEL split the
    SQL specialist out when there is one. A `models.json` is for what
    that cannot express: a shelf of endpoints to switch between.
    """
    env = _environment()
    if env.get("DATAGORA_MODELS") or env.get("DATAGORA_ENDPOINTS"):
        # same rule as profiles: a file or a list named explicitly wins,
        # because it is there to hold what one pair of variables cannot
        return None
    if env.get("DATAGORA_LLM_ENDPOINT"):
        # naming an endpoint is a request to use the FILE, since only the
        # file has endpoints to name. Answering it with a synthetic
        # "default" built from DATAGORA_LLM_URL ignored the request in
        # silence, which is how you measure one model believing you
        # measured another.
        return None
    url = env.get("DATAGORA_LLM_URL")
    model = env.get("DATAGORA_LLM_MODEL")
    if not url or not model:
        return None
    api = env.get("DATAGORA_LLM_API") or "ollama"
    endpoints = {"default": {"api": api, "url": url, "model": model}}
    roles = {"reasoner": "default", "sql": "default"}
    sql_url = env.get("DATAGORA_LLM_SQL_URL")
    sql_model = env.get("DATAGORA_LLM_SQL_MODEL")
    if sql_url and sql_model:
        endpoints["sql"] = {
            "api": env.get("DATAGORA_LLM_SQL_API") or api,
            "url": sql_url, "model": sql_model}
        roles["sql"] = "sql"
    return {"roles": roles, "endpoints": endpoints, "default": "default"}


def models_path():

    print(f"====================== models_path() ==============================")
    print(f"====================== {_environment()} ==============================")
    print(f"====================================================================")

    """The models file DATAGORA_MODELS names, or a SystemExit saying that
    nothing is configured. There is no packaged file to fall back on."""
    named = _environment().get("DATAGORA_MODELS")
    if not named:
        raise SystemExit(NO_MODEL_CONFIGURED)
    path = Path(named)
    if not path.is_file():
        raise SystemExit(f"DATAGORA_MODELS names {path}, which is not a "
                         f"readable file. Mount the file there, or list the "
                         f"endpoints in .env with DATAGORA_ENDPOINTS.")
    return path


def first_json_object(text):
    """The first balanced JSON object in a reply, or None.

    Small models wrap their JSON in prose, in ``` fences, or in both, so
    the whole string cannot be trusted to parse. This lives at module
    level rather than inside LLM because a team integrating one of our
    steps passes a plain function instead of an LLM, and their model
    fences its output exactly like ours does: two parsers would mean
    their callable failed on replies ours accepts."""
    if not text:
        return None
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError):
        pass
    if not isinstance(text, str):
        return None
    start = text.find("{")
    while start != -1:
        depth, in_str, esc = 0, False, False
        for i in range(start, len(text)):
            c = text[i]
            if in_str:
                if esc:
                    esc = False
                elif c == "\\":
                    esc = True
                elif c == '"':
                    in_str = False
            elif c == '"':
                in_str = True
            elif c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(text[start:i + 1])
                    except json.JSONDecodeError:
                        break
        start = text.find("{", start + 1)
    return None


def keep_alive(value):
    """What Ollama accepts for keep_alive: a number of seconds, or a
    duration with its unit.

    The settings page offers "always" as -1 and "unload" as 0, and both
    reached Ollama as the strings "-1" and "0". Ollama parses a string as a
    Go duration, refuses one without a unit with HTTP 400 ("time: missing
    unit in duration"), and so every chat on an endpoint set to "always"
    failed. Measured against a real 0.30.10 by the realistic fake's
    captures. A bare number is sent as a number; "30m" stays a string."""
    text = str(value).strip()
    if re.fullmatch(r"-?\d+", text):
        return int(text)
    return text


def model_name(name):
    """One spelling per model: Ollama lists "mistral" as "mistral:latest".

    Compared as typed, a model configured as "mistral" was reported as not
    served by a host that serves it, and got no weights size."""
    name = str(name or "").strip()
    return name if ":" in name else f"{name}:latest"


# What a text costs on Gemma's tokenizer, estimated from its characters: the
# server's own count comes with the reply, and a prompt has to be cut to the
# window before it is sent. Every ASCII digit is a token of its own, so a
# schema of dates and amounts costs far more than its length says. The rest
# of ASCII came to 2.7 to 3.2 characters a token, measured on prompts Ollama
# counted: 13 707 characters with 1 051 digits made 5 043 tokens, 34 511
# with 5 033 digits made 15 832. The lower figure is taken.
ASCII_CHARS_PER_TOKEN = 2.7
# An accented Latin letter, U+0080 to U+036F (é, ç, ß, Latin-1's own signs,
# the combining accents). Measured on gemma4:31b (Ollama 0.32.1) by
# docs/test_strategy/coverage_bench/token_calibration.py, French with its
# accents against the same text without them: 0.021 of a token less than a
# plain letter, so 0.35. Common words are tokens of their own accents and
# all, and cost less with them (-0.19 an accent on prose); people's and
# towns' names cost more (+0.23 on a schema of them). Only a run of accents
# costs a token each: "é" * 100 counts 100 where "e" * 100 counts 26.
LATIN = 0.35
# Greek, Cyrillic, Asian scripts, and everything else from U+0370 on: the
# ASCII rate counted them 1.5 times too low (October 9), so 1.5 / 2.7.
WIDE = 0.56

_DIGITS = "0123456789"
_LATIN_CHARS = re.compile("[\u0080-\u036f]")
_WIDE_CHARS = re.compile("[^\u0000-\u036f]")


def estimate_tokens(text):
    """The tokens `text` costs on Gemma's tokenizer, estimated from its
    characters, as a float the caller rounds as it needs: one an ASCII
    digit, 1/ASCII_CHARS_PER_TOKEN the rest of ASCII, LATIN an accented
    Latin letter, WIDE any character from U+0370 on.

    A plain function rather than a method, so that the cut of a schema
    (focus.tokens), the room an agent leaves its reply and the check of a
    reply that ran past the window all count the same way."""
    text = text if isinstance(text, str) else str(text or "")
    digits = sum(map(text.count, _DIGITS))
    if text.isascii():
        return digits + (len(text) - digits) / ASCII_CHARS_PER_TOKEN
    latin = len(_LATIN_CHARS.findall(text))
    wide = len(_WIDE_CHARS.findall(text))
    rest = len(text) - digits - latin - wide
    return digits + rest / ASCII_CHARS_PER_TOKEN + latin * LATIN + wide * WIDE


class LLM:
    # Ollama's own default context, measured on 0.30.10: a 6 000-token
    # prompt came back with prompt_eval_count 4095. It truncates in
    # silence, so a schema that does not fit is judged half-read. Every
    # request now names its window explicitly.
    DEFAULT_NUM_CTX = 16384
    DEFAULT_KEEP_ALIVE = "30m"
    # How long a reply is waited for, in seconds. It was 180, fixed in the
    # code, and that is what a batch on two GPUs taking four requests each
    # ran into: the requests share the GPU, a long prompt is read four
    # times at once, and a reply that was only slow came back as "did not
    # answer: timed out". A server that is down fails at once anyway; this
    # only bounds one that hangs. Set per endpoint on the settings page, or
    # DATAGORA_LLM_TIMEOUT for endpoints that do not say.
    DEFAULT_TIMEOUT = 600
    # How many tokens a reply may run to. Ollama's own limit is none: a
    # model that loops goes on until the window is full, which on a 31B
    # sharing its GPU is past any timeout. A verdict, a choice or a query
    # is a few hundred tokens; past this the reply is reported as running
    # on, at once, rather than waited for.
    MAX_REPLY_TOKENS = 4096
    # With thinking, the same cap has to hold the thinking as well, and a
    # reply takes longer to come: gemma4:31b thought 3.2 times as long as
    # it answered on the 25 Warehouse questions (352 s against 111 s, four
    # at once). A job that thinks waits at least THINK_TIMEOUT for a reply.
    MAX_THINKING_TOKENS = 8192
    # While someone watches (on_progress set: a coverage job or an Ask
    # followed on its page), Ollama's reply is read as it is written and
    # what it is thinking, or answering, is handed on: its last
    # PROGRESS_TAIL characters, every PROGRESS_EVERY seconds at most.
    PROGRESS_EVERY = 0.5
    PROGRESS_TAIL = 240
    THINK_TIMEOUT = 1800

    def __init__(self, name, cfg):
        self.name = name
        self.api = cfg["api"]
        self.url = cfg["url"].rstrip("/")
        self.model = cfg["model"]
        # The context window and how long the model stays loaded. Both
        # belong to the endpoint rather than to the code, because they are
        # a property of the GPU behind it: 16K is comfortable for a 31B on
        # 32 GB and a disaster on 8. keep_alive spares a batch the cold
        # start of a large model between two questions, which on a 31B is
        # the better part of a minute each time.
        try:
            self.num_ctx = int(cfg.get("num_ctx") or self.DEFAULT_NUM_CTX)
        except (TypeError, ValueError):
            self.num_ctx = self.DEFAULT_NUM_CTX
        self.keep_alive = keep_alive(cfg.get("keep_alive")
                                     or self.DEFAULT_KEEP_ALIVE)
        try:
            self.parallel = max(1, int(cfg.get("parallel") or 1))
        except (TypeError, ValueError):
            self.parallel = 1
        try:
            self.timeout = max(1.0, float(
                cfg.get("timeout") or os.environ.get("DATAGORA_LLM_TIMEOUT")
                or self.DEFAULT_TIMEOUT))
        except (TypeError, ValueError):
            self.timeout = float(self.DEFAULT_TIMEOUT)
        # Whether a model that can think first (gemma4, Ollama's
        # "thinking") does. On by default, by the user's choice: on the
        # Warehouse questions gemma4:31b judged better thinking (the five
        # verdicts it changed were all ANSWERABLE, as the schema bears
        # out, where without thinking it refused four), at three times
        # the time. What made the production run's questions UNKNOWN was
        # not the thinking but its room: no bound on its length, a 600 s
        # wait, and a schema that filled the window. A model that thinks
        # gets MAX_THINKING_TOKENS, THINK_TIMEOUT and, in ambisql, room in
        # the window. True or False here forces it; None (unset) lets a
        # model that can think do so (thinks()).
        raw = str(cfg.get("think") if cfg.get("think") is not None else "").strip().lower()
        self.think = (True if raw in ("1", "true", "on", "yes")
                      else False if raw in ("0", "false", "off", "no") else None)
        # what the last reply cost, read from the server rather than
        # guessed: a caller that wants to know whether the prompt fitted
        # has the exact count here.
        self.last_prompt_tokens = None
        # where the server says the last reply's time went, and how long
        # it ran (Ollama's durations and counts); {} when it did not say
        self.last_server = {}
        # what the last reply took of the window, for a trace or a caller
        # that budgets its next prompt: {"prompt", "reply", "window"} in
        # tokens; {} when the call failed before the server counted
        self.last_usage = {}
        # called with ("thinking" | "answering", the text's last characters)
        # while a reply is written, when a page follows it; None, and the
        # reply is waited for whole, as it always was
        self.on_progress = None
        # why the last call returned nothing. A host that is up and a
        # host that rejected the request fail the same way from the
        # caller's side, and "the reply could not be read as JSON" sends
        # someone looking at the wrong thing entirely.
        self.last_error = ""

    @classmethod
    def load(cls, name=None, path=None):
        """The endpoint named, or the one the environment asks for, or the
        default. DATAGORA_LLM_ENDPOINT picks a named entry and
        DATAGORA_LLM_URL rewrites its address, which is how a container
        reaches a model serving on its host without a second config file.
        """
        data = models_data(path)
        # with no name given, the reasoner is the sensible default: it is
        # the endpoint that talks to the user
        name = (name or os.environ.get("DATAGORA_LLM_ENDPOINT")
                or data.get("default")
                or data.get("roles", {}).get("reasoner"))
        if name not in data["endpoints"]:
            raise SystemExit(f"unknown endpoint {name!r}; "
                             f"known: {sorted(data['endpoints'])}")
        cfg = {k: v for k, v in data["endpoints"][name].items()
               if not k.startswith("_")}
        # The environment rewrites the endpoint it named, and only that
        # one. Applied to every endpoint they followed you onto a named
        # server: in the container, which pins local-small to the host
        # Ollama, switching roles.sql to server-arctic in models.json
        # still called gemma on the laptop, and the file looked inert.
        # Only the endpoint the environment names, which is what the
        # paragraph above says and what the condition did not do: with no
        # DATAGORA_LLM_ENDPOINT set it rewrote every endpoint it loaded.
        # Two consequences, both found by test rather than by reading. A
        # mounted models.json lost the model its own roles named. And a
        # SQL specialist on its own host was overwritten by the
        # reasoner's address, so splitting the roles quietly did nothing.
        # Describing a model entirely from the environment is env_models'
        # job now, and the container's loopback redirect is
        # host_gateway's, so neither needs this to be loose.
        pinned = os.environ.get("DATAGORA_LLM_ENDPOINT")
        if pinned and pinned == name:
            cfg["url"] = os.environ.get("DATAGORA_LLM_URL") or cfg["url"]
            cfg["model"] = os.environ.get("DATAGORA_LLM_MODEL") or cfg["model"]
        cfg["url"] = host_gateway(cfg["url"])
        return cls(name, cfg)

    @classmethod
    def names(cls, path=None):
        data = models_data(path)
        return sorted(data["endpoints"])

    @classmethod
    def role(cls, role, path=None):
        """The endpoint playing a part: `reasoner` talks to the user,
        `sql` writes the query. An environment variable wins over the
        file, so a container or a one-off run switches without editing
        anything: DATAGORA_LLM_REASONER, DATAGORA_LLM_SQL."""
        data = models_data(path)
        roles = data.get("roles", {})
        if role not in roles:
            raise SystemExit(f"unknown role {role!r}; known: {sorted(roles)}")
        # the environment may move a role only when the page has not set
        # one: a variable left in a compose file must not quietly override
        # the model somebody chose on the settings screen
        override = (None if path is None and (_saved_models() is not None
                                             or env_endpoints() is not None)
                    else (_names(os.environ.get(f"DATAGORA_LLM_{role.upper()}"))
                          or [None])[0])
        return cls.load(override or roles[role], path)

    @classmethod
    def pool(cls, role, path=None):
        """Every endpoint serving a role, for spreading a batch over them.

        The settings page may put several endpoints on one role, which is
        how a batch uses two GPUs, or two machines, at once. Without the
        page there is exactly one, the one role() returns, so a caller can
        always ask for the pool and never has to know which case it is in.
        """
        data = models_data(path)
        pools = data.get("pools") or {}
        ids = pools.get(role)
        if not ids:
            return [cls.role(role, path)]
        return [cls.load(i, path) for i in ids]

    @classmethod
    def roles(cls, path=None):
        data = models_data(path)
        return data.get("roles", {})

    @classmethod
    def set_roles(cls, assignments, path=None):
        """Rewrite roles in place, keeping comments and order."""
        if path is None and (env_models() is not None
                             or env_endpoints() is not None):
            raise SystemExit(
                "this process takes its models from the environment, so "
                "there is no roles block to rewrite. Change "
                "DATAGORA_LLM_MODEL, or set DATAGORA_MODELS to a "
                "models.json to manage roles in a file.")
        path = Path(path) if path else models_path()
        text = path.read_text(encoding="utf-8")
        data = json.loads(text)
        known = set(data["endpoints"])
        for role, endpoint in assignments.items():
            if role not in data["roles"]:
                raise SystemExit(f"unknown role {role!r}; "
                                 f"known: {sorted(data['roles'])}")
            if endpoint not in known:
                raise SystemExit(f"unknown endpoint {endpoint!r}; "
                                 f"known: {sorted(known)}")
            data["roles"][role] = endpoint
        path.write_text(json.dumps(data, indent=2) + "\n",
                              encoding="utf-8")
        return data["roles"]


    @classmethod
    def discover(cls, url, timeout=8):
        """What a host actually serves, and under exactly what name.

        The name a server answers to is rarely the name you expect: vLLM
        reports whatever --served-model-name was given, which may be a
        path, and Ollama reports a tag. Guessing it produces a 404 that
        looks like a network problem, so this asks instead. Returns
        (api, [model names])."""
        # Ollama answers /v1/models too, for compatibility, so its own
        # endpoint is tried first: a native Ollama should be driven
        # natively, where JSON mode is `format: json` rather than
        # `response_format`
        for api, path, pick in (
                ("ollama", "/api/tags",
                 lambda d: [m["name"] for m in d.get("models", [])]),
                ("openai", "/v1/models",
                 lambda d: [m["id"] for m in d.get("data", [])])):
            try:
                with urllib.request.urlopen(
                        url.rstrip("/") + path, timeout=timeout) as r:
                    return api, pick(json.loads(r.read()))
            except Exception:
                continue
        return None, []

    @classmethod
    def set_endpoint(cls, name, *, api, url, model, path=None):
        """Write an endpoint into models.json, creating or replacing it."""
        # a file, always: an endpoint cannot be persisted into the
        # environment, and silently writing the packaged file while the
        # process reads its models from DATAGORA_LLM_URL would produce an
        # edit that changes nothing anybody can see
        if path is None and (env_models() is not None
                             or env_endpoints() is not None):
            raise SystemExit(
                "this process takes its models from DATAGORA_LLM_URL and "
                "DATAGORA_LLM_MODEL, so there is no file to write. Set "
                "DATAGORA_MODELS to a models.json to manage endpoints in "
                "a file.")
        path = Path(path) if path else models_path()
        data = json.loads(path.read_text(encoding="utf-8"))
        entry = data["endpoints"].get(name, {})
        entry.update({"api": api, "url": url.rstrip("/"), "model": model})
        data["endpoints"][name] = entry
        path.write_text(json.dumps(data, indent=2) + "\n",
                              encoding="utf-8")
        return entry

    # ------------------------------------------------------------ calls
    def reachable(self, timeout=4):
        probe = "/api/tags" if self.api == "ollama" else "/v1/models"
        try:
            with urllib.request.urlopen(self.url + probe, timeout=timeout):
                return True
        except Exception:
            return False

    def chat(self, system, user, **kw):
        """One reply, traced as a generation when tracing is on.

        The trace carries the endpoint that served it, which is the GPU,
        and the prompt version it was sent, found from the text itself, so
        a batch spread over several servers can be read per GPU and per
        prompt in Langfuse. With tracing off this is a plain call."""
        obs, name_of = _tracing()
        if obs is None:
            return self._chat(system, user, **kw)
        with obs.generation(endpoint=self.name, model=self.model, url=self.url,
                            system=system, user=user, num_ctx=self.num_ctx,
                            prompt_version=name_of(system) if name_of else None
                            ) as record:
            out = self._chat(system, user, **kw)
            record(output=out, prompt_tokens=self.last_prompt_tokens,
                   reply_tokens=self.last_server.get("reply_tokens"),
                   server=self.last_server or None,
                   error=None if out is not None
                   else (self.last_error or "no reply"))
            return out

    def _chat(self, system, user, *, timeout=None, want_json=False,
             temperature=0.0, schema=None, num_predict=None):
        """The raw text of one reply, or None when the host is unusable.

        `schema`, when given, is a JSON Schema the reply must satisfy, and
        it is enforced by the server while decoding rather than checked
        afterwards: Ollama takes it as `format`, an OpenAI-shaped server as
        `response_format`. A plain "json" only promises some JSON; a schema
        makes an invented `kind` or a missing key impossible to produce,
        which is worth more than any sentence in the prompt asking for it.

        `num_predict`, when given, bounds the reply (its thinking included)
        on Ollama to fewer tokens than the cap, never to more: a caller
        that knows how much of the window its prompt leaves asks for that.
        """
        thinks = self.thinks()
        cap = self.MAX_THINKING_TOKENS if thinks else self.MAX_REPLY_TOKENS
        if num_predict is not None:
            # at least one token: Ollama reads -1 as no bound at all
            cap = max(1, min(cap, int(num_predict)))
        progress = getattr(self, "on_progress", None) or getattr(_WATCH, "progress", None)
        streaming = callable(progress) and self.api == "ollama"
        if self.api == "ollama":
            path, body = "/api/chat", {
                "model": self.model, "stream": streaming,
                "keep_alive": self.keep_alive,
                "options": {"temperature": temperature,
                            "num_ctx": self.num_ctx,
                            "num_predict": cap},
                "messages": [{"role": "system", "content": system},
                             {"role": "user", "content": user}]}
            # said only to a model that can think, or to stop one: a model
            # that cannot refuses `think: true` and accepts `false`. While
            # /api/show cannot say whether it can, an endpoint that did not
            # choose is not told either way: Ollama then lets a model that
            # can think do so, within the thinking's cap and wait (thinks())
            if thinks and (self.think is True
                           or _THINKERS.get((self.url, self.model)) is True):
                body["think"] = True
            elif self.think is False:
                body["think"] = False
            if schema is not None:
                body["format"] = schema
            elif want_json:
                body["format"] = "json"
        else:
            path, body = "/v1/chat/completions", {
                "model": self.model, "temperature": temperature,
                "messages": [{"role": "system", "content": system},
                             {"role": "user", "content": user}]}
            if schema is not None:
                body["response_format"] = {
                    "type": "json_schema",
                    "json_schema": {"name": "reply", "schema": schema}}
            elif want_json:
                body["response_format"] = {"type": "json_object"}

        req = urllib.request.Request(
            self.url + path, data=json.dumps(body).encode("utf-8"),
            headers={"Content-Type": "application/json"})
        self.last_error = ""
        self.last_server = {}
        self.last_usage = {}
        try:
            wait = timeout or (max(self.timeout, float(self.THINK_TIMEOUT)) if thinks
                               else self.timeout)
            with urllib.request.urlopen(req, timeout=wait) as r:
                data = (self._streamed(r, progress, wait) if streaming
                        else json.loads(r.read()))
        except urllib.error.HTTPError as e:
            # the host is up and said no. Almost always a model name that
            # is not the one this host serves, which --probe settles.
            body = ""
            try:
                body = e.read().decode("utf-8", "replace")[:200]
            except Exception:
                pass
            self.last_error = (f"{self.url} refused the request for model "
                               f"{self.model!r}: HTTP {e.code}"
                               + (f", {body}" if body else ""))
            return None
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            reason = getattr(e, "reason", None) or e
            self.last_error = f"{self.url} did not answer: {reason}"
            if "timed out" in str(reason):
                # the server took the request and was still working on it
                self.last_error += (
                    f" after {wait:.0f} s. Several requests at once "
                    "share the GPU, so each takes longer: raise the wait "
                    "for this endpoint on the settings page, or send it "
                    "fewer requests at once.")
            return None
        except json.JSONDecodeError:
            self.last_error = f"{self.url} answered something that is not JSON"
            return None
        if self.api == "ollama":
            # The server says how much of the prompt it actually read. Equal
            # to the window, less one, means it stopped reading: the prompt
            # was longer and the rest was thrown away. That is reported as a
            # failure, never passed on as a reply, because a model that saw
            # half a schema answers confidently about the half it saw.
            self.last_prompt_tokens = data.get("prompt_eval_count")
            msg = data.get("message") or {}
            ns = 1e9
            self.last_server = {k: v for k, v in {
                "load_seconds": round((data.get("load_duration") or 0) / ns, 1),
                "prompt_seconds": round((data.get("prompt_eval_duration") or 0) / ns, 1),
                "reply_seconds": round((data.get("eval_duration") or 0) / ns, 1),
                "server_seconds": round((data.get("total_duration") or 0) / ns, 1),
                "reply_tokens": data.get("eval_count"),
                "thinking_chars": len(msg.get("thinking") or "") or None,
                "done_reason": data.get("done_reason")}.items() if v not in (None, 0.0)}
            reply = data.get("eval_count")
            reply = reply if isinstance(reply, int) else None
            window = None
            if isinstance(self.last_prompt_tokens, int) or reply is not None:
                # The window the model really ran with, which is not always
                # the one asked for. Measured on 0.30.10: Gemma never runs
                # below 2048, so asking for 1024 flagged prompts that fit;
                # and a window above what a model was trained for is cut to
                # it, so a prompt truncated at the trained length went
                # unnoticed. /api/ps says which window is loaded.
                window = self.loaded_window() or self.num_ctx
            # What the prompt took of the window: the server's own count.
            # Measured on 0.32.1, a prefix kept from an earlier request is
            # still counted (the same text sent twice counted 920 both
            # times), while the estimate overshoots prose by up to 1.6
            # times; preferring it flagged replies that fit. The estimate
            # stands in only when the server gave no count.
            counted = self.last_prompt_tokens
            prompt = (counted if isinstance(counted, int) and counted > 0
                      else int(estimate_tokens(system) + estimate_tokens(user)))
            self.last_usage = {"prompt": prompt, "reply": reply, "window": window}
            if isinstance(self.last_prompt_tokens, int):
                if self.last_prompt_tokens >= window - 1:
                    self.last_server["overflow"] = True
                    # how much was sent, roughly: a schema rendered for the
                    # model measured 2.4 characters a token on Gemma's
                    # tokenizer, so the size says how far over it was
                    sent = int((len(system) + len(user)) / 2.4)
                    self.last_error = (
                        f"the prompt did not fit: about {sent} tokens were "
                        f"sent, {self.url} read {self.last_prompt_tokens}, "
                        f"the whole of the {window}-token window "
                        f"{self.model!r} is loaded with"
                        + (f" (asked for {self.num_ctx})"
                           if window != self.num_ctx else "")
                        + ", and dropped the rest. Raise num_ctx for this "
                        "endpoint, or send fewer sample values with "
                        "DATAGORA_SCHEMA_SAMPLES.")
                    return None
            if reply is not None and prompt + reply >= window - 1:
                # The prompt fitted, the reply did not: a long thinking
                # filled the window, and Ollama dropped the start of the
                # prompt to write on, the rules and the schema with it.
                # Measured at full load, about 7 500 tokens were left for a
                # thinking capped at 8 192. What was written past that point
                # answers a prompt the model no longer had whole, so it is
                # not passed on; "did not fit" is what has it asked again
                # with a smaller schema (ambisql's json_with_schema).
                self.last_server["overflow"] = True
                self.last_error = (
                    f"the reply did not fit: the prompt took about {prompt} "
                    f"tokens and the reply {reply}"
                    + (" (thinking included)" if thinks else "")
                    + f", past the {window}-token window; {self.url} dropped "
                    "the start of the prompt to go on.")
                return None
            self.last_server["overflow"] = False
            if data.get("done_reason") == "length":
                # the cap, not the end of an answer: a reply cut there is
                # half a verdict, never passed on as one. After the window
                # checks: Gemma also stops on "length" when the window is
                # full, which is that, not a loop
                self.last_error = (
                    f"{self.url} ran past {cap} tokens without "
                    f"finishing its reply: the model looped"
                    + (", or thought at length" if thinks else "") + ".")
                return None
            return (data.get("message") or {}).get("content")
        usage = data.get("usage") or {}
        self.last_prompt_tokens = usage.get("prompt_tokens")
        self.last_usage = {"prompt": usage.get("prompt_tokens"),
                           "reply": usage.get("completion_tokens"),
                           "window": None}
        return data["choices"][0]["message"]["content"]

    def _streamed(self, response, progress, wait):
        """Ollama's reply read as it is written (stream: true): the thinking,
        then the answer, handed to `progress` as they grow. Returned in the
        shape of a whole reply, the last chunk's counts and durations with
        the message put back together. The wait bounds the whole reply, as
        it does when the reply comes in one piece."""
        thinking, content, last = [], [], {}
        started = said = time.monotonic()
        for raw in response:
            raw = raw.strip()
            if not raw:
                continue
            chunk = json.loads(raw)
            if chunk.get("error"):
                raise OSError(str(chunk["error"])[:200])
            msg = chunk.get("message") or {}
            if msg.get("thinking"):
                thinking.append(msg["thinking"])
            if msg.get("content"):
                content.append(msg["content"])
            now = time.monotonic()
            if now - started > wait:
                raise TimeoutError("timed out")
            if now - said >= self.PROGRESS_EVERY or chunk.get("done"):
                said = now
                try:
                    if content:
                        progress("answering", "".join(content)[-self.PROGRESS_TAIL:])
                    elif thinking:
                        progress("thinking", "".join(thinking)[-self.PROGRESS_TAIL:])
                except Exception:
                    pass          # a watcher that fails never fails the reply
            if chunk.get("done"):
                last = chunk
                break
        last = dict(last)
        last["message"] = {"role": "assistant", "content": "".join(content),
                           "thinking": "".join(thinking)}
        return last

    def thinking(self, on):
        """A copy of this endpoint that thinks first, or does not, for one
        job: what a coverage run asks for when it sets thinking itself."""
        import copy as _copy
        other = _copy.copy(self)
        other.think = bool(on)
        return other

    def thinks(self):
        """Whether this model's replies may come with thinking, and so get
        the thinking's cap, wait and room in the window: never when the
        endpoint or the job turned it off; otherwise when the model can
        think, as Ollama lists it ("thinking" in /api/show), asked once a
        model and kept. An OpenAI-shaped server is not told: True only
        when the endpoint says so.

        A failed /api/show concludes nothing: it is asked again at the next
        call, and meanwhile the endpoint's `think` goes. Turned on, the
        model thinks. Left unset, which lets a model that can think do so,
        the reply gets the thinking's room and the request does not say
        `think` (_chat), so that Ollama lets the model think if it can.
        Taken as "cannot think", as it was, a failure sent the question
        without thinking and with more tables, and the verdict depended on
        a network call nobody saw."""
        if self.think is False:
            return False
        if self.api != "ollama":
            return self.think is True
        can = self._can_think()
        return True if can is None else can

    def _can_think(self):
        """Whether Ollama lists this model as able to think, True or False,
        kept per server and model once it answered; None while /api/show
        does not answer, or answers with an error, and so asked again."""
        key = (self.url, self.model)
        if key in _THINKERS:
            return _THINKERS[key]
        req = urllib.request.Request(
            self.url + "/api/show", data=json.dumps({"model": self.model}).encode("utf-8"),
            headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=10) as r:
                shown = json.loads(r.read())
        except Exception:
            return None
        if not isinstance(shown, dict) or shown.get("error"):
            return None
        _THINKERS[key] = "thinking" in (shown.get("capabilities") or [])
        return _THINKERS[key]

    def loaded_window(self):
        """The context window this model is loaded with, from /api/ps, or
        None when the server does not say. One local request, a few
        milliseconds against a model call of several seconds."""
        try:
            with urllib.request.urlopen(f"{self.url}/api/ps", timeout=3) as r:
                data = json.loads(r.read())
        except Exception:
            return None
        wanted = model_name(self.model)
        for m in data.get("models") or []:
            if model_name(m.get("name") or m.get("model")) == wanted:
                try:
                    return int(m.get("context_length") or 0) or None
                except (TypeError, ValueError):
                    return None
        return None

    def json(self, system, user, schema=None, **kw):
        """A dict, or None, however the model chose to wrap it."""
        return first_json_object(
            self.chat(system, user, want_json=True, schema=schema, **kw))


def _cli():
    """See and switch which model plays which part, in one command.

        python llm.py                                   show and probe
        python llm.py --set sql=jarvis-arctic
        python llm.py --set reasoner=server-gemma sql=server-arctic
    """
    import argparse
    ap = argparse.ArgumentParser(description=_cli.__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--set", nargs="+", metavar="ROLE=ENDPOINT", default=None)
    ap.add_argument("--probe", metavar="URL", default=None,
                    help="ask a host what it serves, and under what name")
    ap.add_argument("--save-as", metavar="NAME", default=None,
                    help="with --probe, write it into models.json")
    args = ap.parse_args()

    if args.probe:
        api, models = LLM.discover(args.probe)
        if api is None:
            raise SystemExit(f"nothing answered at {args.probe}. Check the "
                             f"host, the port, and that you are on its network.")
        print(f"\n  {args.probe}  speaks the {api} API and serves:")
        for m in models:
            print(f"    {m}")
        if args.save_as and models:
            # the newest model first, which may well be an embedding model
            # that cannot chat at all
            chat = [m for m in models if "embed" not in m.lower()] or models
            entry = LLM.set_endpoint(args.save_as, api=api,
                                     url=args.probe, model=chat[0])
            print(f"\n  saved as {args.save_as}: {entry}")
            print(f"  now:  python llm.py --set sql={args.save_as}")
        elif models:
            print(f"\n  save it with:  python llm.py --probe {args.probe} "
                  f"--save-as jarvis-arctic")
        return

    if args.set:
        pairs = {}
        for item in args.set:
            if "=" not in item:
                raise SystemExit(f"expected ROLE=ENDPOINT, got {item!r}")
            role, endpoint = item.split("=", 1)
            pairs[role.strip()] = endpoint.strip()
        LLM.set_roles(pairs)
        print("roles updated")

    print(f"\nendpoints: {', '.join(LLM.names())}\n")
    for role in LLM.roles():
        env = os.environ.get(f"DATAGORA_LLM_{role.upper()}")
        llm = LLM.role(role)
        source = f"env DATAGORA_LLM_{role.upper()}" if env else "models.json"
        print(f"  {role:9} -> {llm.name:14} {llm.model:34} "
              f"{'reachable' if llm.reachable() else 'UNREACHABLE'}  ({source})")
    print("\n  switch with:  python llm.py --set sql=jarvis-arctic")


if __name__ == "__main__":
    _cli()
