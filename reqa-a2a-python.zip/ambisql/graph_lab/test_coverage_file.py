"""A saved coverage run downloaded whole, or cut to one group of verdicts.

No database and no model: the run is written by the same ledger a real
run uses, then read back through the endpoint the pages link to."""

import os

# the column index is on by default; a test never builds one in a real
# Qdrant, and the tests that need one give it directly
os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

import pathlib
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "ui"))

from coverage import Ledger, Verdict

# one of each verdict, an input column named like a result column, and a
# question the ledger has to quote over two lines, so a row kept is
# visibly the row the ledger wrote
ROWS = [
    ("Q1", "NOT COVERED", "how many books"),
    ("Q2", "ANSWERABLE", 'loans "per" member,\nby month'),
    ("Q3", "NEEDS A CHOICE", "the best authors"),
    ("Q4", "NEEDS MORE", "members near me"),
    ("Q5", "ANSWERABLE", "open loans"),
    ("Q6", "NO DATA", "books from 1066"),
    ("Q7", "UNKNOWN", "the weather"),
]


class _RunFile(unittest.TestCase):
    """A run file the real Ledger wrote, served by the app."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        env = patch.dict("os.environ", {"DATAGORA_COVERAGE_DIR": self.tmp.name,
                                        "DATAGORA_DATA_DIR": self.tmp.name})
        env.start()
        self.addCleanup(env.stop)
        import app
        from fastapi.testclient import TestClient
        self.client = TestClient(app.app)
        self.path = pathlib.Path(self.tmp.name) / "lib run.csv"
        ledger = Ledger(self.path, ["id", "verdict"])
        for qid, verdict, question in ROWS:
            ledger.add(Verdict(question=question, verdict=verdict, kind="AmbiValue",
                               missing="something", choices=["a", "b"],
                               extra={"id": qid, "verdict": "input"}))
        ledger.close()
        self.raw = self.path.read_bytes()

    def get(self, verdicts=None):
        params = {} if verdicts is None else {"verdicts": verdicts}
        return self.client.get("/api/coverage/file/lib run", params=params)

    def records(self):
        """The file's header and rows, as the bytes the ledger wrote."""
        body = self.raw[3:].decode("utf-8")
        head, rest = body.split("\r\n", 1)
        rows, at = [], 0
        for qid, _verdict, question in ROWS:
            start = rest.index(qid + ",", at)
            at = rest.index("\r\n", start + len(question)) + 2
            rows.append(rest[start:at])
        return head + "\r\n", rows


class CoverageFileTests(_RunFile):

    def test_without_a_group_the_file_is_served_as_it_is(self):
        r = self.get()
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.content, self.raw)
        self.assertEqual(r.headers["content-disposition"],
                         "attachment; filename*=utf-8''lib%20run.csv")

    def test_one_verdict_keeps_its_rows_byte_for_byte(self):
        r = self.get("ANSWERABLE")
        self.assertEqual(r.status_code, 200)
        head, rows = self.records()
        expected = (b"\xef\xbb\xbf" + (head + rows[1] + rows[4]).encode("utf-8"))
        self.assertEqual(r.content, expected)
        self.assertTrue(r.headers["content-type"].startswith("text/csv"))
        self.assertEqual(r.headers["content-disposition"],
                         "attachment; filename*=utf-8''lib%20run_answerable.csv")

    def test_a_combination_is_named_in_the_engines_order(self):
        (pathlib.Path(self.tmp.name) / "plain.csv").write_bytes(self.raw)
        r = self.client.get("/api/coverage/file/plain",
                            params={"verdicts": "NEEDS A CHOICE, answerable"})
        self.assertEqual(r.status_code, 200)
        head, rows = self.records()
        self.assertEqual(r.content.decode("utf-8-sig"), head + rows[1] + rows[2] + rows[4])
        self.assertEqual(r.headers["content-disposition"],
                         'attachment; filename="plain_answerable_needs_a_choice.csv"')

    def test_the_input_column_called_verdict_does_not_decide(self):
        # every row carries "input" in its own verdict column; filtering on
        # that one instead would keep nothing
        r = self.get("NO DATA")
        head, rows = self.records()
        self.assertEqual(r.content.decode("utf-8-sig"), head + rows[5])

    def test_a_group_with_no_rows_is_the_header_alone(self):
        self.path.write_bytes(self.raw.replace(b"NEEDS MORE", b"NOT COVERED"))
        self.raw = self.path.read_bytes()
        head, _rows = self.records()
        self.assertEqual(self.get("NEEDS MORE").content, b"\xef\xbb\xbf" + head.encode("utf-8"))

    def test_an_unknown_or_empty_group_is_refused(self):
        for bad in ("ANSWERABLE,MAYBE", "", " , "):
            r = self.get(bad)
            self.assertEqual(r.status_code, 400, bad)
            self.assertIn("ANSWERABLE", r.json()["detail"])

    def test_a_missing_run_is_still_a_404(self):
        r = self.client.get("/api/coverage/file/nothing", params={"verdicts": "ANSWERABLE"})
        self.assertEqual(r.status_code, 404)


class OpenedRunThinkTests(_RunFile):
    """An opened run says whether its last part was judged thinking, so
    the page's box can follow it and a Resume can ask before going the
    other way."""

    def opened(self):
        return self.client.get("/api/coverage/run/lib run").json()["think"]

    def test_a_run_says_how_it_was_judged(self):
        from coverage import record_run, write_manifest
        write_manifest(self.path, "job", None, len(ROWS), profile="Library")
        record_run(self.path, {"id": "a", "think": False})
        self.assertIs(self.opened(), False)
        # resumed thinking: the last part is what the run is now
        record_run(self.path, {"id": "b", "think": True})
        self.assertIs(self.opened(), True)

    def test_a_run_saved_before_the_mode_was_recorded_does_not_say(self):
        from coverage import record_run, write_manifest
        write_manifest(self.path, "job", None, len(ROWS), profile="Library")
        record_run(self.path, {"id": "a", "seconds": 12})
        self.assertIsNone(self.opened())

    def test_a_run_with_no_record_does_not_say(self):
        self.assertIsNone(self.opened())


class LiveRunTests(unittest.TestCase):
    """A run going on is said with its database and its thinking from the
    start, saved or not, so a page following it from elsewhere shows both."""

    def test_the_live_list_says_the_database_and_the_thinking(self):
        import app
        self.addCleanup(app._RUNS.clear)
        with patch.object(app.threading, "Thread"):      # the run never starts
            app.coverage(app.Coverage(profile="Warehouse", csv="how many", think=False))
            app.coverage(app.Coverage(profile="Library", csv="how many"))
        runs = sorted(app.live_runs()["runs"], key=lambda x: x["profile"])
        self.assertEqual([(x["profile"], x["think"], x["stem"]) for x in runs],
                         [("Library", None, None), ("Warehouse", False, None)])


class PageJudgeTests(unittest.TestCase):
    """A saved run on the page reads its judge once, when it starts: a
    Settings save during the run changes DATAGORA_JUDGE, and must change
    neither the judge the run uses nor the one its manifest records."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        env = patch.dict("os.environ", {"DATAGORA_COVERAGE_DIR": self.tmp.name,
                                        "DATAGORA_DATA_DIR": self.tmp.name,
                                        "DATAGORA_JUDGE": "agent"})
        env.start()
        self.addCleanup(env.stop)

    def run_page(self, assess):
        import app
        import coverage
        self.addCleanup(app._RUNS.clear)
        started = []

        def thread(target=None, **_kw):
            started.append(target)
            return Mock()

        with patch.object(app.threading, "Thread", side_effect=thread), \
                patch.object(app.threading, "Timer"), \
                patch.object(app.DbProfile, "load", return_value=object()), \
                patch.object(coverage, "assess", side_effect=assess):
            app.coverage(app.Coverage(profile="lib", csv="question\nfirst\nsecond\n",
                                      save=True, name="judged"))
            started[0]()                 # the run, here rather than in a thread
        return next(iter(app._RUNS.values()))

    def test_a_settings_save_during_the_run_changes_neither_judge_nor_record(self):
        seen = {}

        def assess(questions, *, on_each=None, judge=None, **_kw):
            seen["judge"] = judge
            for n, question in enumerate(questions):
                if n == 1:
                    # the Settings page saved the single judge meanwhile
                    os.environ["DATAGORA_JUDGE"] = "single"
                on_each(Verdict(question=question["question"], verdict="ANSWERABLE",
                                position=n))

        live = self.run_page(assess)
        self.assertEqual([e["type"] for e in live.events][-1], "done")
        self.assertEqual(seen["judge"], "agent")
        import coverage
        run = coverage.read_manifest(pathlib.Path(self.tmp.name) / "judged.csv")["runs"][-1]
        self.assertEqual((run["judge"], run["judged"]), ("agent", 2))
        self.assertTrue(run["agent_version"])


if __name__ == "__main__":
    unittest.main()
