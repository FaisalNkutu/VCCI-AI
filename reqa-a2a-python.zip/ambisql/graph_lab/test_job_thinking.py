"""Thinking chosen for one coverage job: the request sent, how long it is
waited for, the room the schema leaves the thinking, the slots of a run
and the record of the run.

No model, no database: the model call is answered by a stand-in for
urlopen."""

import os

os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

import json
import pathlib
import sys
import unittest
import urllib.error
from unittest.mock import patch

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import coverage  # noqa: E402
import llm  # noqa: E402
from ambisql import Clarifier  # noqa: E402

ENDPOINT = {"api": "ollama", "url": "http://gpu:11434", "model": "gemma4:31b",
            "parallel": 2, "timeout": 600}


class _Reply:
    def __init__(self, data):
        self.data = data

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def read(self):
        return json.dumps(self.data).encode()


def sent(model, reply=None, can_think=False):
    """The body the model's request carried, the server answering `reply`
    and saying whether the model can think."""
    bodies = []
    llm._THINKERS.clear()

    def urlopen(req, timeout=None):
        if req.full_url.endswith("/api/show"):
            return _Reply({"capabilities": ["completion"] + (["thinking"] if can_think else [])})
        if req.full_url.endswith("/api/chat"):
            bodies.append((json.loads(req.data), timeout))
        return _Reply(reply or {"message": {"content": "{}"}, "done_reason": "stop"})

    with patch("urllib.request.urlopen", urlopen):
        model.chat("system", "user")
    return bodies[0]


class RequestTests(unittest.TestCase):
    def setUp(self):
        # what Ollama said a model can do is kept per server and model:
        # left behind, it would make other tests' gemma4 think
        self.addCleanup(llm._THINKERS.clear)

    def test_a_model_that_can_think_does_by_default(self):
        body, timeout = sent(llm.LLM("gpu", ENDPOINT), can_think=True)
        self.assertIs(body["think"], True)
        self.assertEqual(body["options"]["num_predict"], llm.LLM.MAX_THINKING_TOKENS)
        self.assertEqual(timeout, llm.LLM.THINK_TIMEOUT)

    def test_a_model_that_cannot_is_not_told_to(self):
        # `think: true` would be refused by it
        body, timeout = sent(llm.LLM("gpu", ENDPOINT), can_think=False)
        self.assertNotIn("think", body)
        self.assertEqual(body["options"]["num_predict"], llm.LLM.MAX_REPLY_TOKENS)
        self.assertEqual(timeout, 600)

    def test_a_job_without_thinking_says_so(self):
        body, timeout = sent(llm.LLM("gpu", ENDPOINT).thinking(False), can_think=True)
        self.assertIs(body["think"], False)
        self.assertEqual(body["options"]["num_predict"], llm.LLM.MAX_REPLY_TOKENS)
        self.assertEqual(timeout, 600)

    def test_an_endpoint_can_turn_it_off(self):
        body, _timeout = sent(llm.LLM("gpu", dict(ENDPOINT, think="false")), can_think=True)
        self.assertIs(body["think"], False)

    def test_a_longer_wait_set_on_the_endpoint_is_kept(self):
        _body, timeout = sent(llm.LLM("gpu", dict(ENDPOINT, timeout=3600)), can_think=True)
        self.assertEqual(timeout, 3600)

    def test_the_copy_leaves_the_endpoint_as_it_was(self):
        endpoint = llm.LLM("gpu", ENDPOINT)
        endpoint.thinking(False)
        self.assertIsNone(endpoint.think)

    def test_a_reply_cut_at_the_cap_is_no_reply(self):
        model = llm.LLM("gpu", ENDPOINT).thinking(True)
        llm._THINKERS[(model.url, model.model)] = True
        with patch("urllib.request.urlopen",
                   lambda req, timeout=None: _Reply({"message": {"content": "{\"verd"},
                                                     "done_reason": "length"})):
            self.assertIsNone(model.chat("system", "user"))
        self.assertIn(str(llm.LLM.MAX_THINKING_TOKENS), model.last_error)
        self.assertIn("thought at length", model.last_error)


class ShowDownTests(unittest.TestCase):
    """/api/show failing concludes nothing: it is asked again at the next
    call, and meanwhile the endpoint's `think` goes. Taken as "cannot
    think", a failure sent the question without thinking and with more
    tables, depending on a network call nobody saw."""

    def setUp(self):
        llm._THINKERS.clear()
        self.addCleanup(llm._THINKERS.clear)
        self.down = True
        self.caps = ["completion", "thinking"]
        self.shown = 0

    def urlopen(self, bodies):
        def urlopen(req, timeout=None):
            url = getattr(req, "full_url", req)
            if url.endswith("/api/show"):
                self.shown += 1
                if self.down:
                    raise urllib.error.URLError("[WinError 10061] connection refused")
                return _Reply({"capabilities": self.caps})
            if url.endswith("/api/chat"):
                bodies.append((json.loads(req.data), timeout))
            return _Reply({"message": {"content": "{}"}, "done_reason": "stop"})
        return urlopen

    def chats(self, model, *states):
        """The bodies and waits of one chat per state of /api/show
        (True: down)."""
        bodies = []
        with patch("urllib.request.urlopen", self.urlopen(bodies)):
            for down in states:
                self.down = down
                model.chat("system", "user")
        return bodies

    def test_down_then_back_it_is_asked_again(self):
        model = llm.LLM("gpu", ENDPOINT)
        (first, first_wait), (second, _w), (third, _w3) = self.chats(model, True, False, False)
        # down: the thinking's cap and wait, and Ollama left to let the
        # model think if it can, since nobody told it not to
        self.assertNotIn("think", first)
        self.assertEqual(first["options"]["num_predict"], llm.LLM.MAX_THINKING_TOKENS)
        self.assertEqual(first_wait, llm.LLM.THINK_TIMEOUT)
        # back: asked again, told to think, and the answer kept
        self.assertIs(second["think"], True)
        self.assertIs(third["think"], True)
        self.assertIs(llm._THINKERS[(model.url, model.model)], True)
        self.assertEqual(self.shown, 2)

    def test_while_it_is_down_nothing_is_kept(self):
        model = llm.LLM("gpu", ENDPOINT)
        self.chats(model, True, True)
        self.assertNotIn((model.url, model.model), llm._THINKERS)
        self.assertEqual(self.shown, 2)

    def test_while_it_is_down_the_endpoint_decides(self):
        (on, _w), = self.chats(llm.LLM("gpu", dict(ENDPOINT, think="on")), True)
        self.assertIs(on["think"], True)
        (off, wait), = self.chats(llm.LLM("gpu", dict(ENDPOINT, think="off")), True)
        self.assertIs(off["think"], False)
        self.assertEqual(off["options"]["num_predict"], llm.LLM.MAX_REPLY_TOKENS)
        self.assertEqual(wait, 600)

    def test_a_model_that_cannot_think_is_known_once_it_is_back(self):
        self.caps = ["completion"]
        (_down, _w), (back, wait) = self.chats(llm.LLM("gpu", ENDPOINT), True, False)
        self.assertNotIn("think", back)
        self.assertEqual(back["options"]["num_predict"], llm.LLM.MAX_REPLY_TOKENS)
        self.assertEqual(wait, 600)

    def test_an_error_answered_is_no_answer(self):
        model = llm.LLM("gpu", ENDPOINT)
        with patch("urllib.request.urlopen",
                   lambda req, timeout=None: _Reply({"error": "model 'gemma4:31b' not found"})):
            self.assertIs(model.thinks(), True)
        self.assertNotIn((model.url, model.model), llm._THINKERS)

    def test_the_schema_leaves_the_thinking_room_meanwhile(self):
        clar = Clarifier(connect=lambda: None, schema="test", llm=llm.LLM("gpu", ENDPOINT))
        with patch("urllib.request.urlopen", self.urlopen([])):
            down = clar.schema_room("q", llm=llm.LLM("gpu", ENDPOINT))
        llm._THINKERS[("http://gpu:11434", "gemma4:31b")] = True
        self.assertEqual(down, clar.schema_room("q", llm=llm.LLM("gpu", ENDPOINT)))


class RoomTests(unittest.TestCase):
    def test_the_schema_leaves_the_thinking_room(self):
        llm._THINKERS[("http://gpu:11434", "gemma4:31b")] = True
        self.addCleanup(llm._THINKERS.clear)
        clar = Clarifier(connect=lambda: None, schema="test", llm=llm.LLM("gpu", ENDPOINT))
        plain = clar.schema_room("q", llm=llm.LLM("gpu", ENDPOINT).thinking(False))
        thinking = clar.schema_room("q", llm=llm.LLM("gpu", ENDPOINT))
        self.assertAlmostEqual(plain - thinking, Clarifier.THINK_ROOM * 0.9, delta=2)


class SlotTests(unittest.TestCase):
    def slots(self, think):
        with patch.object(coverage, "Clarifier", lambda profile, model: model):
            return coverage._slots("profile", None, None, [llm.LLM("gpu", ENDPOINT)], think=think)

    def test_every_slot_of_the_job_thinks_as_the_job_says(self):
        self.assertEqual([m.think for m in self.slots(True)], [True, True])
        self.assertEqual([m.think for m in self.slots(False)], [False, False])

    def test_unset_each_endpoint_keeps_its_own(self):
        self.assertEqual([m.think for m in self.slots(None)], [None, None])


class PageDefaultTests(unittest.TestCase):
    """The coverage page's box starts as the settings say for the
    endpoints that judge: ticked unless every one of them is set not to
    think."""

    def default(self, *thinks):
        sys.path.insert(0, str(HERE / "ui"))
        import app
        pool = [llm.LLM(f"gpu{i}", dict(ENDPOINT, **({} if t is None else {"think": t})))
                for i, t in enumerate(thinks)]
        with patch.object(app.LLM, "pool", classmethod(lambda cls, role: pool)):
            return app._thinks_by_default()

    def test_ticked_unless_every_judge_is_set_not_to_think(self):
        self.assertIs(self.default(None), True)
        self.assertIs(self.default("false", None), True)
        self.assertIs(self.default("false", "off"), False)


if __name__ == "__main__":
    unittest.main()
