"""The verdict agent's tools, without a model and without a database.

The database is a double that answers by rules and records every SQL it
was sent, so a test states the data it assumes and checks what was asked.
The four example knowledge bases build a SchemaView each, with no
connection at all, so every database the bench uses is covered.

    .venv/Scripts/python src/graph_lab/test_verdict_tools.py
"""

import os

# the column index is on by default; a test never builds one in a real
# Qdrant, and the tests that need one give it directly
os.environ.setdefault("DATAGORA_COLUMN_INDEX", "off")
import datetime
import decimal
import json
import pathlib
import re
import sys
import tempfile
import unittest

# Tests never trace, never read the developer's .env, and never read the
# settings page's real file.
os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"
os.environ["DATAGORA_DATA_DIR"] = tempfile.mkdtemp(prefix="datagora-tests-")
from unittest.mock import patch

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import dictionary  # noqa: E402
import verdict_tools as vt  # noqa: E402
from ambisql import Clarifier  # noqa: E402

D = datetime.date
DT = datetime.datetime


# ------------------------------------------------------------ the double
class Data:
    """A database we state. `rules` are (regex, answer), tried in order on
    every statement; the first that matches answers. An answer is rows (a
    list of tuples), {"columns": [...], "rows": [...]}, a callable taking
    (sql, params) and returning either, or an exception, raised. Nothing
    matched: no rows. Every statement is recorded in `sql`."""

    VERSION = "10.11.6-MariaDB"

    def __init__(self, rules=(), version=VERSION):
        self.rules = [(re.compile(p, re.I | re.S), a) for p, a in rules]
        self.version = version
        self.sql, self.params = [], []
        self.opened = self.closed = self.rollbacks = self.begun = 0

    def answer(self, sql, params):
        for pattern, answer in self.rules:
            if pattern.search(sql):
                if callable(answer) and not isinstance(answer, type):
                    answer = answer(sql, params)
                if isinstance(answer, BaseException) or (
                        isinstance(answer, type)
                        and issubclass(answer, BaseException)):
                    raise answer
                if isinstance(answer, dict):
                    return answer
                return {"rows": list(answer)}
        if re.match(r"\s*SELECT VERSION\(\)", sql, re.I):
            return {"columns": ["VERSION()"], "rows": [(self.version,)]}
        if re.match(r"\s*EXPLAIN\b", sql, re.I):
            return {"columns": ["id", "select_type", "table", "type", "ref"],
                    "rows": [(1, "SIMPLE", "t", "ALL", None)]}
        return {"rows": []}

    def connect(self):
        self.opened += 1
        return _Connection(self)

    def ran(self, pattern):
        """The statements that match `pattern`."""
        found = re.compile(pattern, re.I | re.S)
        return [s for s in self.sql if found.search(s)]


class _Cursor:
    def __init__(self, data):
        self.data = data
        self.rows, self.pos, self.description = [], 0, None

    def execute(self, sql, params=None):
        self.data.sql.append(sql)
        self.data.params.append(params)
        got = self.data.answer(sql, params)
        self.rows, self.pos = list(got.get("rows") or []), 0
        columns = got.get("columns") or (
            [f"c{i}" for i in range(len(self.rows[0]))] if self.rows else [])
        self.description = ([(c, None, None, None, None, None, None)
                             for c in columns] or None)
        return len(self.rows)

    def fetchall(self):
        rows, self.pos = self.rows[self.pos:], len(self.rows)
        return rows

    def fetchmany(self, size=1):
        rows = self.rows[self.pos:self.pos + size]
        self.pos += len(rows)
        return rows

    def fetchone(self):
        if self.pos >= len(self.rows):
            return None
        self.pos += 1
        return self.rows[self.pos - 1]

    def close(self):
        return None

    def __enter__(self):
        return self

    def __exit__(self, *_exc):
        return False


class _Connection:
    def __init__(self, data):
        self.data = data

    def cursor(self):
        return _Cursor(self.data)

    def begin(self):
        self.data.begun += 1

    def rollback(self):
        self.data.rollbacks += 1

    def commit(self):
        raise AssertionError("a read-only tool committed")

    def close(self):
        self.data.closed += 1


class Model:
    """Stands in for an endpoint; the tools never call it."""
    num_ctx = 16384

    def json(self, system, user, schema=None):
        raise AssertionError("a tool called the model")


def limited(rows):
    """An answer that honours the LIMIT the clarifier passes as a param."""
    def answer(_sql, params):
        limit = params[-1] if params else None
        return rows[:limit] if isinstance(limit, int) else rows
    return answer


# ---------------------------------------------------------- the catalogue
COLUMNS = {
    "customers": [("customer_id", "int"), ("name", "varchar"),
                  ("city", "varchar"), ("segment", "varchar")],
    "sales_orders": [("order_id", "int"), ("customer_id", "int"),
                     ("order_date", "date"), ("promised_date", "date"),
                     ("status_code", "varchar"), ("net_amount", "decimal")],
    "sales_order_lines": [("order_line_id", "int"), ("order_id", "int"),
                          ("product_id", "int"), ("quantity", "decimal")],
    "products": [("product_id", "int"), ("name", "varchar"),
                 ("status_code", "varchar")],
    "shipments": [("shipment_id", "int"), ("shipment_number", "varchar"),
                  ("ship_date", "date"), ("delivered_date", "date"),
                  ("status_code", "varchar"), ("carrier_id", "int")],
    "shipment_lines": [("shipment_line_id", "int"), ("shipment_id", "int"),
                       ("order_line_id", "int"), ("quantity_shipped", "decimal")],
    "carriers": [("carrier_id", "int"), ("name", "varchar")],
    "employees": [("employee_id", "int"), ("manager_id", "int"),
                  ("name", "varchar"), ("hire_date", "date")],
    "salary_history": [("salary_id", "int"), ("employee_id", "int"),
                       ("effective_from", "date"), ("effective_to", "date"),
                       ("base_salary", "decimal"), ("created_at", "datetime")],
    "stock_movements": [("movement_id", "int"), ("product_id", "int"),
                        ("movement_type", "varchar"), ("moved_at", "datetime")],
    "exchange_rates": [("rate_id", "int"), ("from_currency_code", "varchar"),
                       ("to_currency_code", "varchar"), ("rate_date", "date"),
                       ("rate", "decimal")],
    "currencies": [("currency_code", "varchar"), ("name", "varchar")],
    "inventory": [("product_id", "int"), ("warehouse_id", "int"),
                  ("quantity_on_hand", "int")],
    "stock_counts": [("count_id", "int"), ("product_id", "int"),
                     ("warehouse_id", "int"), ("counted_qty", "int")],
    "attachments": [("attachment_id", "int"), ("object_type", "varchar"),
                    ("object_id", "int"), ("file_name", "varchar")],
    "audit_notes": [("note_id", "int"), ("note", "text")],
}
FKS = {
    ("sales_orders", "customer_id"): ("customers", "customer_id"),
    ("sales_order_lines", "order_id"): ("sales_orders", "order_id"),
    ("sales_order_lines", "product_id"): ("products", "product_id"),
    ("shipment_lines", "shipment_id"): ("shipments", "shipment_id"),
    ("shipment_lines", "order_line_id"): ("sales_order_lines", "order_line_id"),
    ("shipments", "carrier_id"): ("carriers", "carrier_id"),
    ("employees", "manager_id"): ("employees", "employee_id"),
    ("salary_history", "employee_id"): ("employees", "employee_id"),
    ("stock_movements", "product_id"): ("products", "product_id"),
    ("exchange_rates", "from_currency_code"): ("currencies", "currency_code"),
    ("exchange_rates", "to_currency_code"): ("currencies", "currency_code"),
}
# a composite link only the graph knows
EDGES = [
    ("stock_counts", "product_id,warehouse_id", "inventory",
     "product_id,warehouse_id"),
]
# a polymorphic one, with its condition as the fifth element (contract 1)
POLYMORPHIC = ("attachments", "object_id", "sales_orders", "order_id",
               "attachments.object_type = 'ORDER'")


def keys_of(columns):
    return {(t.lower(), c.lower()) for t, cols in columns.items()
            for c, _d in cols if c.endswith("_id")}


def clarifier(data, columns=None, fks=None, edges=None, meanings=None,
              samples=None, keys=None, llm=None):
    columns = COLUMNS if columns is None else columns
    clar = Clarifier.for_connection(data.connect, "theirs",
                                    llm=llm if llm is not None else Model())
    clar._columns = columns
    clar._views = {}
    clar._keys = keys_of(columns) if keys is None else keys
    clar._foreign_keys = dict(FKS if fks is None else fks)
    clar._samples = samples or {}
    clar._meanings = meanings or dictionary.empty()
    clar._graph_edges = list(EDGES if edges is None else edges)
    clar._index_checked = True
    clar._corpus_checked = True
    clar._reranker_checked = True
    return clar


def toolbox(data=None, settings=None, profile=None, **kw):
    data = data if data is not None else Data()
    clar = clarifier(data, **kw)
    view = vt.SchemaView(clar, profile)
    return vt.ToolBox(clar, view, settings or vt.Settings()), data


class EnvironmentKept(unittest.TestCase):
    """Every test leaves the DATAGORA_* environment as it found it."""

    def setUp(self):
        self._before = {k: v for k, v in os.environ.items()
                        if k.startswith("DATAGORA_")}
        self.addCleanup(self._unchanged)

    def _unchanged(self):
        after = {k: v for k, v in os.environ.items() if k.startswith("DATAGORA_")}
        self.assertEqual(after, self._before,
                         "this test left the DATAGORA_* environment changed")


# ---------------------------------------------------------------- tests
class SettingsTests(EnvironmentKept):
    def test_the_wording_check_is_on_unless_switched_off(self):
        self.assertIs(vt.Settings.from_environment({}).wording, True)
        self.assertIs(vt.Settings.from_environment(
            {"DATAGORA_AGENT_WORDING": "off"}).wording, False)
        self.assertIs(vt.Settings.from_environment(
            {"DATAGORA_AGENT_WORDING": "maybe"}).wording, True)

    def test_defaults(self):
        s = vt.Settings.from_environment({})
        self.assertEqual((s.judge_mode, s.max_turns, s.max_seconds, s.think,
                          s.sql_seconds, s.result_tokens, s.choice_tolerance,
                          s.same_result, s.arbiter),
                         ("agent", 8, 1200, "all", 5, 3000, 0.01, "answer", "off"))

    def test_read_from_the_environment(self):
        s = vt.Settings.from_environment({
            "DATAGORA_JUDGE": "Agent", "DATAGORA_AGENT_MAX_TURNS": "6",
            "DATAGORA_AGENT_MAX_SECONDS": "300", "DATAGORA_AGENT_THINK": "none",
            "DATAGORA_AGENT_SQL_SECONDS": "2.5",
            "DATAGORA_AGENT_RESULT_TOKENS": "1500",
            "DATAGORA_AGENT_CHOICE_TOLERANCE": "0",
            "DATAGORA_AGENT_SAME_RESULT": "choice",
            "DATAGORA_AGENT_ARBITER": "vote"})
        self.assertEqual((s.judge_mode, s.max_turns, s.max_seconds, s.think,
                          s.sql_seconds, s.result_tokens, s.choice_tolerance,
                          s.same_result, s.arbiter),
                         ("agent", 6, 300.0, "none", 2.5, 1500, 0.0, "choice",
                          "vote"))

    def test_bad_values_keep_the_defaults(self):
        s = vt.Settings.from_environment({
            "DATAGORA_JUDGE": "both", "DATAGORA_AGENT_MAX_TURNS": "-2",
            "DATAGORA_AGENT_MAX_SECONDS": "soon", "DATAGORA_AGENT_THINK": "",
            "DATAGORA_AGENT_CHOICE_TOLERANCE": "1.5",
            "DATAGORA_AGENT_RESULT_TOKENS": "0"})
        self.assertEqual(s, vt.Settings())

    def test_a_number_that_is_no_number_keeps_the_default(self):
        for raw in ("inf", "-inf", "nan", "Infinity", "1e999"):
            s = vt.Settings.from_environment({
                "DATAGORA_AGENT_MAX_SECONDS": raw,
                "DATAGORA_AGENT_SQL_SECONDS": raw,
                "DATAGORA_AGENT_CHOICE_TOLERANCE": raw})
            self.assertEqual(s, vt.Settings(), raw)

    def test_the_settings_page_bounds_hold_on_the_environment(self):
        import settings_store
        names = {"max_turns": "agent_max_turns",
                 "max_seconds": "agent_max_seconds",
                 "sql_seconds": "agent_sql_seconds",
                 "result_tokens": "agent_result_tokens"}
        self.assertEqual({names[k]: v for k, v in vt.BOUNDS.items()},
                         settings_store._AGENT_WHOLE)
        variables = {"max_turns": "DATAGORA_AGENT_MAX_TURNS",
                     "max_seconds": "DATAGORA_AGENT_MAX_SECONDS",
                     "sql_seconds": "DATAGORA_AGENT_SQL_SECONDS",
                     "result_tokens": "DATAGORA_AGENT_RESULT_TOKENS"}
        default = vt.Settings()
        for field_name, (low, high) in vt.BOUNDS.items():
            key = variables[field_name]
            for raw, kept in ((low, True), (high, True), (low - 1, False),
                              (high + 1, False)):
                got = getattr(vt.Settings.from_environment({key: str(raw)}),
                              field_name)
                self.assertEqual(got, raw if kept else getattr(default, field_name),
                                 f"{key}={raw}")

    def test_the_process_environment_is_read(self):
        with patch.dict(os.environ, {"DATAGORA_AGENT_MAX_TURNS": "5"}):
            self.assertEqual(vt.Settings.from_environment().max_turns, 5)


class KeyTests(EnvironmentKept):
    def test_sql_key_ignores_case_spacing_and_the_semicolon(self):
        self.assertEqual(vt.sql_key("SELECT  a\nFROM t;"),
                         vt.sql_key("select a from t"))
        self.assertNotEqual(vt.sql_key("select a from t"),
                            vt.sql_key("select b from t"))

    def test_pair_keys_are_unordered(self):
        self.assertEqual(vt.pair_key("A", "b"), vt.pair_key("B", "a"))
        self.assertEqual(vt.readings_key("select 1", "select 2"),
                         vt.readings_key("select 2", "select 1"))


class SchemaViewTests(EnvironmentKept):
    def setUp(self):
        super().setUp()
        self.box, self.data = toolbox()
        self.view = self.box.view

    def test_flavour_from_the_version(self):
        self.assertEqual(self.view.flavour, "mariadb")
        box, _data = toolbox(Data(version="8.0.36"))
        self.assertEqual(box.view.flavour, "mysql")
        box, _data = toolbox(Data([(r"VERSION", RuntimeError("down"))]))
        self.assertEqual(box.view.flavour, "unknown")

    def test_names(self):
        self.assertEqual(self.view.table("`Shipments`"), "shipments")
        self.assertEqual(self.view.table("theirs.shipments"), "shipments")
        self.assertIsNone(self.view.table("other.shipments"))
        self.assertIn("shipments", self.view.closest("shipmnts"))
        self.assertTrue(self.view.has("SHIPMENTS", "Delivered_Date"))
        self.assertEqual(self.view.columns_of("carriers"),
                         [("carrier_id", "int"), ("name", "varchar")])

    def test_edges_both_ways_and_by_source(self):
        out = [e for e in self.view.edges["shipments"] if e.b == "carriers"]
        back = [e for e in self.view.edges["carriers"] if e.b == "shipments"]
        self.assertEqual(out[0].via, "shipments.carrier_id = carriers.carrier_id")
        self.assertEqual(back[0].via, "carriers.carrier_id = shipments.carrier_id")
        self.assertEqual((out[0].source, out[0].weight), ("fk", 1.0))

    def test_connected(self):
        self.assertEqual(self.view.connected(["customers", "shipments"]),
                         (True, []))
        self.assertEqual(self.view.connected(["customers", "audit_notes"]),
                         (False, ["audit_notes"]))
        self.assertEqual(self.view.connected(["customers", "shipments"],
                                             max_hops=2),
                         (False, ["shipments"]))
        self.assertEqual(self.view.connected(["customers", "nowhere"]),
                         (False, ["nowhere"]))


class JoinPathTests(EnvironmentKept):
    def setUp(self):
        super().setUp()
        self.box, self.data = toolbox()

    def test_three_joins_through_tables_not_described(self):
        self.box.seen.update({"shipments", "sales_orders"})
        got = self.box.run("join_path", {"a": "shipments", "b": "sales_orders"})
        self.assertTrue(got.ok)
        first = got.data["paths"][0]
        self.assertEqual(first["tables"], ["shipments", "shipment_lines",
                                           "sales_order_lines", "sales_orders"])
        self.assertEqual(first["via"], [
            "shipments.shipment_id = shipment_lines.shipment_id",
            "shipment_lines.order_line_id = sales_order_lines.order_line_id",
            "sales_order_lines.order_id = sales_orders.order_id"])
        self.assertEqual(first["sources"], ["fk", "fk", "fk"])
        self.assertEqual(first["unseen"], ["shipment_lines", "sales_order_lines"])
        self.assertIn("shipment_lines", got.digest)
        fact = got.facts[0]
        self.assertEqual((fact.kind, fact.key),
                         ("join_path", vt.pair_key("sales_orders", "shipments")))

    def test_a_composite_link_joins_on_every_column(self):
        got = self.box.join_path("stock_counts", "inventory")
        self.assertEqual(got.data["paths"][0]["via"], [
            "stock_counts.product_id = inventory.product_id AND "
            "stock_counts.warehouse_id = inventory.warehouse_id"])
        self.assertEqual(got.data["paths"][0]["sources"], ["graph"])

    def test_a_polymorphic_link_carries_its_condition(self):
        data = Data()
        clar = clarifier(data, edges=EDGES + [POLYMORPHIC])
        # the schema text is the clarifier's business; what is checked
        # here is the view reading a link of five elements
        clar._graph_links = lambda: {}
        box = vt.ToolBox(clar, vt.SchemaView(clar))
        got = box.join_path("attachments", "sales_orders")
        self.assertEqual(got.data["paths"][0]["via"], [
            "attachments.object_id = sales_orders.order_id "
            "WHEN attachments.object_type = 'ORDER'"])

    def test_a_written_polymorphic_link_carries_its_condition(self):
        meanings = dictionary.empty()
        meanings["links"] = {("attachments", "object_id"): (
            "customers", "customer_id",
            {"when": {"column": "object_type", "value": "CUSTOMER"}})}
        box, _data = toolbox(meanings=meanings, edges=[])
        got = box.join_path("attachments", "customers")
        self.assertEqual(got.data["paths"][0]["via"], [
            "attachments.object_id = customers.customer_id "
            "WHEN attachments.object_type = 'CUSTOMER'"])
        self.assertEqual(got.data["paths"][0]["sources"], ["kb"])

    def test_a_polymorphic_link_with_no_condition_is_refused(self):
        with tempfile.TemporaryDirectory() as folder:
            path = pathlib.Path(folder) / "kb.json"
            loose = {"role": "child_of", "related_table": "sales_orders",
                     "own_column": "object_id", "related_column": "order_id",
                     "type": "Polymorphic"}
            empty = dict(loose, related_table="customers",
                         related_column="customer_id", when={"value": "C"})
            kept = dict(loose, related_table="carriers",
                        related_column="carrier_id",
                        when={"column": "object_type", "value": "CARRIER"})
            path.write_text(json.dumps({"attachments": {
                "columns": {"object_id": {}, "object_type": {}},
                "relationships": [loose, empty, kept]}}), encoding="utf-8")
            with self.assertLogs("datagora.dictionary", "WARNING") as said:
                meanings = dictionary.load(str(path))
        targets = meanings["polymorphic"][("attachments", "object_id")]
        self.assertEqual([(t, c) for t, c, _a in targets],
                         [("carriers", "carrier_id")])
        self.assertNotIn(("attachments", "object_id"), meanings["links"])
        self.assertEqual(len(said.records), 2)
        self.assertIn("no `when`", said.output[0])
        box, _data = toolbox(meanings=meanings, edges=[], fks={})
        self.assertFalse(box.join_path("attachments", "sales_orders").data["found"])
        self.assertEqual(box.join_path("attachments", "carriers").data["paths"][0]
                         ["via"], ["attachments.object_id = carriers.carrier_id "
                                   "WHEN attachments.object_type = 'CARRIER'"])

    def test_two_links_between_the_same_tables_are_two_paths(self):
        got = self.box.join_path("exchange_rates", "currencies")
        self.assertEqual(sorted(p["via"][0] for p in got.data["paths"]), [
            "exchange_rates.from_currency_code = currencies.currency_code",
            "exchange_rates.to_currency_code = currencies.currency_code"])

    def test_no_path(self):
        got = self.box.join_path("audit_notes", "customers")
        self.assertTrue(got.ok)
        self.assertEqual(got.data, {"found": False, "paths": [],
                                    "hops_searched": 5})
        self.assertIn("no path", got.digest)

    def test_an_unknown_table_comes_back_with_the_closest(self):
        got = self.box.run("join_path", {"a": "shipmnts", "b": "carriers"})
        self.assertFalse(got.ok)
        self.assertIn("closest: shipments", got.error)

    def test_a_cheaper_path_first_and_no_much_dearer_one(self):
        paths = self.box.view.paths("customers", "products")
        self.assertEqual(paths[0]["tables"], ["customers", "sales_orders",
                                              "sales_order_lines", "products"])
        best = paths[0]["cost"]
        self.assertTrue(all(p["cost"] <= best * vt.PATH_SLACK + 1e-9
                            for p in paths))

    @staticmethod
    def crowded():
        """a to b through seventy tables, each joined to b only by the
        graph (2.2), and once through zz by declared keys (2.0), zz last
        by name."""
        cols = {"a": [("a_id", "int")], "b": [("b_id", "int")],
                "zz": [("zz_id", "int"), ("a_id", "int"), ("b_id", "int")]}
        fks = {("zz", "a_id"): ("a", "a_id"), ("zz", "b_id"): ("b", "b_id")}
        edges = []
        for i in range(70):
            t = f"x{i:02d}"
            cols[t] = [(f"{t}_id", "int"), ("a_id", "int"), ("b_id", "int")]
            fks[(t, "a_id")] = ("a", "a_id")
            edges.append((t, "b_id", "b", "b_id"))
        return toolbox(columns=cols, fks=fks, edges=edges)[0]

    def test_the_cheapest_path_survives_a_crowded_graph(self):
        box = self.crowded()
        paths = box.view.paths("a", "b")
        self.assertEqual(paths[0]["tables"], ["a", "zz", "b"])
        self.assertEqual(paths[0]["cost"], 2.0)
        self.assertEqual([p["cost"] for p in paths], [2.0, 2.2, 2.2])
        got = box.join_path("a", "b")
        self.assertIn("the cheapest 2 joins: a.a_id = zz.a_id AND "
                      "zz.b_id = b.b_id", got.digest)

    def test_a_path_that_exists_is_never_no_path(self):
        box = self.crowded()
        with patch.object(vt, "PATH_EXPANSIONS", 1):
            paths = box.view.paths("a", "b")
            got = box.join_path("a", "b")
        self.assertEqual(paths[0]["tables"], ["a", "zz", "b"])
        self.assertTrue(got.data["found"])
        self.assertNotIn("no path", got.digest)


class DescribeTests(EnvironmentKept):
    def test_an_unknown_name_with_the_closest(self):
        box, _data = toolbox()
        got = box.run("describe_tables", {"names": ["shipments", "shipmnt"]})
        self.assertTrue(got.ok)
        self.assertEqual([t["table"] for t in got.data["tables"]], ["shipments"])
        self.assertEqual(got.data["unknown"][0]["name"], "shipmnt")
        self.assertIn("shipments", got.data["unknown"][0]["closest"])
        self.assertIn("shipments", box.seen)
        self.assertIn("TABLE shipments", got.render(2000)[0])
        kinds = {(f.kind, f.key) for f in got.facts}
        self.assertIn(("table_exists", "shipments"), kinds)
        self.assertIn(("column_exists", "shipments.delivered_date"), kinds)

    def test_only_unknown_names_fail(self):
        box, _data = toolbox()
        got = box.describe_tables(["nowhere"])
        self.assertFalse(got.ok)
        self.assertEqual(got.data["unknown"][0]["name"], "nowhere")

    def test_seen_before_and_four_at_a_time(self):
        box, _data = toolbox()
        box.describe_tables(["carriers"])
        got = box.describe_tables(["carriers", "customers", "products",
                                   "employees", "currencies"])
        self.assertTrue(got.data["tables"][0]["seen_before"])
        self.assertEqual(len(got.data["tables"]), 4)
        self.assertEqual(got.data["skipped"], ["currencies"])
        self.assertFalse(got.complete)

    def test_the_column_profile_is_shown_when_there_is_one(self):
        with tempfile.TemporaryDirectory() as folder:
            path = pathlib.Path(folder) / "Theirs.profile.json"
            path.write_text(json.dumps({"tables": {"shipments": {"columns": {
                "delivered_date": {"null_share": 0.12, "distinct": 300,
                                   "min": "2023-01-02", "max": "2026-09-30",
                                   "has_time": False}}}}}), encoding="utf-8")
            box, _data = toolbox(profile=str(path))
            got = box.describe_tables(["shipments"])
        profile = got.data["tables"][0]["profile"]
        self.assertEqual(len(profile), 1)
        self.assertIn("12% null", profile[0])
        self.assertIn("from 2023-01-02 to 2026-09-30", profile[0])

    def test_an_absent_profile_changes_nothing(self):
        plain, _data = toolbox()
        missing, _data = toolbox(profile="no/such/file.profile.json")
        self.assertEqual(missing.view.profile, {})
        self.assertEqual(missing.describe_tables(["shipments"]).render(4000),
                         plain.describe_tables(["shipments"]).render(4000))


class SearchAndColumnsTests(EnvironmentKept):
    def test_search_tables_ranks_and_shows_short_forms(self):
        box, _data = toolbox()
        got = box.run("search_tables", {"phrase": "shipments per carrier"})
        self.assertTrue(got.ok)
        top = [t["table"] for t in got.data["tables"][:3]]
        self.assertIn("shipments", top)
        self.assertIn("carriers", top)
        self.assertEqual(got.data["tables_total"], len(COLUMNS))
        self.assertIn("columns:", got.data["tables"][0]["short"])
        self.assertIn("words", got.data["tables"][0]["why"])

    def test_search_tables_pages_with_a_cursor(self):
        box, _data = toolbox()
        first = box.search_tables("shipments per carrier", n=1)
        self.assertEqual(len(first.data["tables"]), 1)
        self.assertEqual(first.data["cursor"], 1)
        self.assertFalse(first.complete)
        second = box.search_tables("shipments per carrier", n=1, cursor=1)
        self.assertNotEqual(first.data["tables"][0]["table"],
                            second.data["tables"][0]["table"])

    def test_search_tables_on_nothing(self):
        box, _data = toolbox()
        got = box.search_tables("zzqx")
        self.assertTrue(got.ok)
        self.assertEqual(got.data["tables"], [])
        self.assertIn("no table matches", got.digest)

    def test_find_columns_says_how(self):
        box, _data = toolbox()
        got = box.run("find_columns", {"phrase": "delivered date"})
        self.assertTrue(got.ok)
        first = got.data["columns"][0]
        self.assertEqual((first["table"], first["column"], first["how"]),
                         ("shipments", "delivered_date", "token"))
        self.assertTrue(first["direct"])
        # the other dates share a word and answer nothing on their own
        others = got.data["columns"][1:]
        self.assertIn(("sales_orders", "order_date"),
                      [(c["table"], c["column"]) for c in others])
        self.assertFalse(any(c["direct"] for c in others))

    def test_find_columns_within_tables(self):
        box, _data = toolbox()
        got = box.find_columns("name", tables=["carriers"])
        self.assertEqual({(c["table"], c["column"]) for c in got.data["columns"]},
                         {("carriers", "name")})


class SampleValuesTests(EnvironmentKept):
    def test_complete_when_there_are_no_more(self):
        data = Data([(r"SELECT DISTINCT `status_code` FROM `shipments`",
                      limited([("DLV",), ("TRN",), ("PLN",)]))])
        box, data = toolbox(data)
        got = box.run("sample_values", {"table": "shipments",
                                        "column": "status_code"})
        self.assertTrue(got.ok)
        self.assertEqual(got.data["values"], ["DLV", "TRN", "PLN"])
        self.assertTrue(got.complete)
        self.assertEqual(data.params[data.sql.index(
            data.ran("SELECT DISTINCT `status_code`")[0])], (21,))
        self.assertTrue(data.ran(r"SET SESSION max_statement_time=5"))
        self.assertEqual(got.facts[0].kind, "values_seen")

    def test_not_complete_past_n(self):
        data = Data([(r"SELECT DISTINCT `status_code` FROM `shipments`",
                      limited([("DLV",), ("TRN",), ("PLN",)]))])
        box, _data = toolbox(data)
        got = box.sample_values("shipments", "status_code", n=2)
        self.assertEqual(got.data["values"], ["DLV", "TRN"])
        self.assertFalse(got.complete)
        self.assertIn("more than 2", got.digest)

    def test_labels_key_and_a_failed_read(self):
        meanings = dictionary.empty()
        meanings["enums"] = {("shipments", "status_code"): {"DLV": "delivered"}}
        data = Data([(r"SELECT DISTINCT `status_code`", [("DLV",)]),
                     (r"SELECT DISTINCT `carrier_id`", RuntimeError("down"))])
        box, _data = toolbox(data, meanings=meanings)
        got = box.sample_values("shipments", "status_code")
        self.assertEqual(got.data["labels"], {"DLV": "delivered"})
        self.assertFalse(got.data["is_key"])
        self.assertFalse(box.sample_values("shipments", "carrier_id").ok)
        missing = box.sample_values("shipments", "delivered")
        self.assertFalse(missing.ok)
        self.assertIn("delivered_date", missing.error)


class FindValueTests(EnvironmentKept):
    def test_refuses_two_characters(self):
        box, data = toolbox()
        got = box.run("find_value", {"value": "SL"})
        self.assertFalse(got.ok)
        self.assertIn("shorter than 3", got.error)
        self.assertFalse(data.ran("LIKE"))

    def test_found_by_the_dictionary_labels(self):
        meanings = dictionary.empty()
        meanings["enums"] = {("shipments", "status_code"): {
            "DLV": "delivered", "TRN": "in transit"}}
        box, _data = toolbox(meanings=meanings)
        got = box.find_value("in transit")
        self.assertTrue(got.ok)
        self.assertEqual(got.data["hits"][0],
                         {"table": "shipments", "column": "status_code",
                          "matches": ["TRN"]})
        self.assertTrue(got.complete)
        self.assertEqual(got.facts[0].kind, "value_found")

    def test_absent_from_a_complete_sweep(self):
        box, data = toolbox()
        got = box.find_value("Zorglub")
        self.assertTrue(got.complete)
        self.assertEqual(got.data["hits"], [])
        self.assertEqual(got.data["checked"], got.data["eligible"])
        self.assertEqual([f.kind for f in got.facts], ["value_absent"])
        self.assertTrue(data.ran(r"SET SESSION max_statement_time=2"))

    def test_not_complete_when_a_lookup_fails(self):
        data = Data([(r"FROM `carriers` WHERE LOWER\(`name`\) LIKE", RuntimeError("x"))])
        box, _data = toolbox(data)
        got = box.find_value("Zorglub")
        self.assertFalse(got.complete)
        self.assertEqual(got.data["failed"], 1)
        self.assertEqual(got.facts, [])
        self.assertIn("1 lookups failed", got.digest)

    def test_stops_at_three_and_goes_on_from_the_cursor(self):
        data = Data([(r"LIKE", [("Lyon",)])])
        box, _data = toolbox(data)
        got = box.find_value("Lyon")
        self.assertEqual(len(got.data["hits"]), 3)
        self.assertTrue(got.complete)
        self.assertEqual(got.cursor, 3)

    def test_a_bounded_sweep_is_resumed(self):
        box, _data = toolbox()
        with patch.object(vt, "SWEEP_COLUMNS", 2):
            first = box.find_value("Zorglub")
            self.assertFalse(first.complete)
            self.assertEqual(first.cursor, 2)
            rest = first
            while rest.cursor is not None:
                rest = box.find_value("Zorglub", cursor=rest.cursor)
        self.assertTrue(rest.complete)
        self.assertEqual(rest.facts[-1].kind, "value_absent")

    def test_a_cursor_out_of_nowhere_proves_nothing(self):
        box, _data = toolbox()
        got = box.find_value("Zorglub", cursor=3)
        self.assertFalse(got.complete)

    def test_a_sweep_that_skipped_columns_is_never_complete(self):
        box, data = toolbox()
        with patch.object(vt, "SWEEP_COLUMNS", 3):
            first = box.find_value("Zorglub")
            self.assertEqual(first.cursor, 3)
            # columns 3 to 5 skipped, then a cursor where the skip stopped
            rest = box.find_value("Zorglub", cursor=6)
            self.assertEqual(rest.cursor, 9)
            while rest.cursor is not None:
                rest = box.find_value("Zorglub", cursor=rest.cursor)
        self.assertFalse(rest.complete)
        self.assertNotIn("value_absent", [f.kind for f in rest.facts])
        self.assertIn("not found", rest.digest)

    def test_within_tables(self):
        data = Data([(r"LIKE", [("Lyon",)])])
        box, _data = toolbox(data)
        got = box.find_value("Lyon", tables=["customers"])
        self.assertEqual({h["table"] for h in got.data["hits"]}, {"customers"})


class GuardTests(EnvironmentKept):
    def setUp(self):
        super().setUp()
        self.box, self.data = toolbox()

    def refused(self, sql, part):
        clean, why = self.box.guard(sql)
        self.assertIsNone(clean, sql)
        self.assertIn(part, why)

    def test_refused(self):
        self.refused("DELETE FROM customers", "only a SELECT")
        self.refused("SELECT 1; DROP TABLE customers", "no ';'")
        # a comment is taken out, and what is left is checked as any SQL
        self.refused("SELECT 1 /* x */; DROP TABLE customers", "no ';'")
        self.refused("SELECT name INTO OUTFILE '/tmp/x' FROM customers", "INTO")
        self.refused("SELECT SLEEP(5)", "SLEEP")
        self.refused("SELECT BENCHMARK(10, MD5('a'))", "BENCHMARK")
        self.refused("SELECT * FROM customers FOR UPDATE", "LOCK")
        self.refused("SELECT * FROM shipmnts", "unknown table shipmnts")
        self.refused("SELECT * FROM shipmnts", "closest: shipments")
        self.refused("SELECT * FROM information_schema.tables",
                     "only the tables of theirs")
        self.refused("SET @a = 1", "only a SELECT")
        self.refused("SELECT " + "1 + " * 2000 + "1", "at most")
        self.refused("", "no SQL")

    def test_comments_are_taken_out_quotes_kept(self):
        box, _data = toolbox()
        for sql, kept in (
                ("SELECT name FROM customers -- all", "SELECT name FROM customers"),
                ("SELECT /* x */ name FROM customers", "SELECT   name FROM customers"),
                ("SELECT name FROM customers # x", "SELECT name FROM customers"),
                ("SELECT '-- no  comment' AS a FROM customers /* y */",
                 "SELECT '-- no  comment' AS a FROM customers")):
            got, why = box.guard(sql)
            self.assertEqual(why, "", sql)
            self.assertEqual(" ".join(got.split()), " ".join(kept.split()))
        self.assertIn("'-- no  comment'", box.guard(
            "SELECT '-- no  comment' AS a FROM customers /* y */")[0])
        # MySQL runs what /*! ... */ holds: taking it out would change the
        # query, so it is refused
        got, why = box.guard("SELECT 1 /*!50000 , SLEEP(5) */ FROM customers")
        self.assertIsNone(got)
        self.assertIn("/*!", why)
        # a semicolon left before a comment is trimmed like any other
        got, why = box.guard("SELECT name FROM customers; -- note")
        self.assertEqual((" ".join(got.split()), why), ("SELECT name FROM customers", ""))

    def test_accepted(self):
        for sql in (
                "WITH late AS (SELECT shipment_id FROM shipments) "
                "SELECT COUNT(*) FROM late",
                "SELECT name FROM customers UNION SELECT name FROM carriers",
                "SELECT c.name FROM theirs.customers AS c",
                "SELECT d.n FROM (SELECT COUNT(*) AS n FROM shipments) AS d",
                "SELECT '--' AS dash FROM customers",
                "SELECT name FROM customers;"):
            clean, why = self.box.guard(sql)
            self.assertIsNotNone(clean, f"{sql}: {why}")
        self.assertEqual(self.box.guard("SELECT name FROM customers;")[0],
                         "SELECT name FROM customers")

    def test_functions_that_wait_lock_or_move_a_sequence(self):
        for call in ("NEXTVAL(customers)", "SETVAL(customers, 100)",
                     "LASTVAL(customers)", "MASTER_GTID_WAIT('0-1-100', 100)",
                     "WAIT_FOR_EXECUTED_GTID_SET('x', 10)",
                     "SOURCE_POS_WAIT('f', 4)", "RELEASE_ALL_LOCKS()",
                     "IS_USED_LOCK('x')", "`sleep`(5)"):
            self.refused(f"SELECT {call}", "is not allowed")

    def test_variables_and_functions_of_another_schema(self):
        self.refused("SELECT @@global.secure_file_priv", "server variable")
        self.refused("SELECT name FROM customers WHERE @@version LIKE '10%'",
                     "server variable")
        self.refused("SELECT @x := 1", "assigning a variable")
        self.refused("SELECT theirs.f(1)", "named with a schema")
        self.refused("SELECT `mysql`.`sys_exec`('id')", "named with a schema")
        self.refused("SELECT name FROM customers ORDER BY sys.format_bytes(1)",
                     "named with a schema")

    def test_only_known_functions(self):
        for call in ("sys_exec('id')", "UPDATEXML('<a/>', '/a', 'x')",
                     "EXTRACTVALUE('<a/>', '/a')", "DES_DECRYPT('x')",
                     "NAME_CONST('a', 1)", "CONNECTION_ID()", "my_udf(name)"):
            self.refused(f"SELECT {call} FROM customers",
                         "functions a query may call")

    def test_the_functions_analytics_need(self):
        sql = (
            "WITH o AS (SELECT customer_id, order_date, net_amount, "
            "ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY order_date) AS n, "
            "LAG(net_amount) OVER (ORDER BY order_date) AS before_it "
            "FROM sales_orders WHERE order_date >= NOW() - INTERVAL 1 YEAR) "
            "SELECT c.name, COUNT(DISTINCT o.customer_id), SUM(o.net_amount), "
            "ROUND(AVG(o.net_amount), 2), STD(o.net_amount), "
            "GROUP_CONCAT(DISTINCT c.city ORDER BY c.city SEPARATOR ', '), "
            "MAX(DATE_FORMAT(o.order_date, '%Y-%m')), MIN(YEARWEEK(o.order_date)), "
            "MAX(WEEKDAY(o.order_date)), MAX(TIMESTAMPDIFF(DAY, o.order_date, CURDATE())), "
            "MAX(DATEDIFF(CURDATE(), o.order_date)), MAX(TIMESTAMPADD(DAY, 1, o.order_date)), "
            "COALESCE(c.segment, 'none'), IFNULL(c.city, '?'), "
            "CASE WHEN SUM(o.net_amount) > 100 THEN 'big' ELSE 'small' END, "
            "IF(COUNT(*) > 1, 'many', 'one'), CONCAT_WS(' ', c.name, c.city), "
            "UPPER(LEFT(c.name, 1)), FIELD(c.segment, 'A', 'B'), "
            "MAX(UNIX_TIMESTAMP(o.order_date)), MAX(TIME_TO_SEC(TIMEDIFF(NOW(), "
            "o.order_date))), MAX(EXTRACT(MONTH FROM o.order_date)), "
            "MAX(FLOOR(o.net_amount)) DIV 2, MAX(o.n), MAX(o.before_it) "
            "FROM o JOIN customers c ON c.customer_id = o.customer_id "
            "GROUP BY c.name, c.segment, c.city")
        clean, why = self.box.guard(sql)
        self.assertIsNotNone(clean, why)


class ExecuteTests(EnvironmentKept):
    SQL = "SELECT shipment_id FROM shipments"

    def test_read_only_timed_rolled_back_and_counted(self):
        data = Data([(r"COUNT\(\*\) FROM \(", [(7,)]),
                     (r"FOR SELECT shipment_id FROM shipments LIMIT 6$",
                      {"columns": ["shipment_id"],
                       "rows": [(i,) for i in range(7)]})])
        box, data = toolbox(data)
        before = list(data.sql)
        got = box.execute(self.SQL, 5)
        sent = data.sql[len(before):]
        self.assertEqual(got["error"], "")
        self.assertEqual(got["columns"], ["shipment_id"])
        self.assertEqual(len(got["rows"]), 5)
        self.assertEqual(got["total"], 7)
        self.assertTrue(got["truncated"])
        # the whole session is bounded, the EXPLAIN included
        self.assertEqual(sent[0], "SET SESSION max_statement_time=5")
        self.assertEqual(sent[1], "START TRANSACTION READ ONLY")
        # the rows needed and one more, never the whole result
        self.assertEqual(sent[2], "EXPLAIN " + self.SQL + " LIMIT 6")
        self.assertEqual(sent[3], "SET STATEMENT max_statement_time=5 FOR "
                         + self.SQL + " LIMIT 6")
        self.assertEqual(sent[4], "SET STATEMENT max_statement_time=5 FOR "
                         "SELECT COUNT(*) FROM (" + self.SQL + ") AS _n")
        self.assertEqual(sent[-1], "SET SESSION max_statement_time=DEFAULT")
        self.assertEqual(data.rollbacks, 1)
        self.assertEqual(data.closed, data.opened)

    def test_no_time_limit_no_query(self):
        box, data = toolbox(Data([(r"VERSION", RuntimeError("down"))]))
        self.assertEqual(box.view.flavour, "unknown")
        got = box.execute(self.SQL, 5)
        self.assertIn("no time limit", got["error"])
        self.assertFalse(data.ran(r"SELECT shipment_id"))
        self.assertEqual(data.closed, data.opened)
        self.assertFalse(box.run_count(self.SQL).ok)
        self.assertFalse(box.find_value("Zorglub").ok)
        self.assertFalse(box.sample_values("shipments", "status_code").ok)
        self.assertFalse(data.ran(r"LIKE|SELECT DISTINCT"))
        self.assertEqual(box.absent_everywhere("Zorglub"), (True, False, []))

    def test_a_version_that_failed_once_is_asked_again(self):
        asked = []

        def version(_sql, _params):
            asked.append(1)
            if len(asked) == 1:
                raise RuntimeError("busy")
            return {"columns": ["VERSION()"], "rows": [("10.11.6-MariaDB",)]}
        box, data = toolbox(Data([(r"VERSION", version)]))
        self.assertEqual(box.view.flavour, "unknown")
        got = box.execute(self.SQL, 5)
        self.assertEqual(got["error"], "")
        self.assertEqual(box.view.flavour, "mariadb")
        self.assertTrue(data.ran(r"^SET SESSION max_statement_time=5$"))
        self.assertTrue(data.ran(r"^SET STATEMENT max_statement_time=5 FOR"))

    def test_never_below_a_millisecond(self):
        tiny = vt.Settings(sql_seconds=0.0004)
        box, data = toolbox(Data(version="8.0.36"), settings=tiny)
        box.execute(self.SQL, 5)
        self.assertTrue(data.ran(r"^SET SESSION max_execution_time=1$"))
        self.assertFalse(data.ran(r"max_execution_time=0$"))
        box, data = toolbox(settings=tiny)
        box.execute(self.SQL, 5)
        self.assertTrue(data.ran(r"^SET SESSION max_statement_time=0.001$"))
        self.assertTrue(data.ran(r"^SET STATEMENT max_statement_time=0.001 FOR"))

    def test_a_limit_only_where_there_is_none(self):
        limited = vt._with_limit
        self.assertEqual(limited("SELECT a FROM t", 6), "SELECT a FROM t LIMIT 6")
        for sql in ("SELECT a FROM t ORDER BY a LIMIT 3",
                    "SELECT a FROM t LIMIT 2, 3",
                    "SELECT a FROM t UNION SELECT b FROM u LIMIT 3"):
            self.assertEqual(limited(sql, 6), sql)
        self.assertEqual(limited("SELECT a FROM t UNION ALL SELECT b FROM u", 6),
                         "SELECT a FROM t UNION ALL SELECT b FROM u LIMIT 6")
        self.assertEqual(
            limited("WITH x AS (SELECT a FROM t LIMIT 9) SELECT a FROM x", 6),
            "WITH x AS (SELECT a FROM t LIMIT 9) SELECT a FROM x LIMIT 6")
        self.assertEqual(
            limited("SELECT a FROM (SELECT a FROM t LIMIT 9) d GROUP BY a", 6),
            "SELECT a FROM (SELECT a FROM t LIMIT 9) d GROUP BY a LIMIT 6")

    def test_readings_compared_are_read_to_their_bound_only(self):
        box, data = toolbox()
        box.compare_readings([self.SQL, self.SQL + " WHERE 1 = 1"])
        sent = data.ran(r"^SET STATEMENT .* FOR SELECT shipment_id")
        self.assertEqual(len(sent), 2)
        self.assertTrue(all(s.endswith(" LIMIT 1001") for s in sent), sent)

    def test_mysql_bounds_the_session(self):
        box, data = toolbox(Data(version="8.0.36"))
        box.execute(self.SQL, 5)
        self.assertTrue(data.ran(r"^SET SESSION max_execution_time=5000$"))
        self.assertFalse(data.ran("SET STATEMENT"))

    def test_too_slow(self):
        class Timeout(Exception):
            pass
        data = Data([(r"FOR SELECT", Timeout(1969, "Query execution was "
                                             "interrupted (max_statement_time "
                                             "exceeded)"))])
        box, data = toolbox(data)
        got = box.execute(self.SQL, 5)
        self.assertTrue(got["error"].startswith(vt.TOO_SLOW))
        self.assertEqual(data.rollbacks, 1)

    def test_a_cartesian_plan_is_refused_before_running(self):
        data = Data([(r"^EXPLAIN", {"columns": ["id", "table", "type", "ref"],
                                    "rows": [(1, "a", "ALL", None),
                                             (1, "b", "ALL", None)]})])
        box, data = toolbox(data)
        got = box.execute("SELECT * FROM customers, carriers", 5)
        self.assertIn("REJECT cartesian", got["error"])
        self.assertFalse(data.ran("FOR SELECT"))

    def test_a_join_on_columns_with_no_index_runs(self):
        sql = ("SELECT c.name FROM customers c JOIN sales_orders o "
               "ON o.customer_id = c.customer_id")
        data = Data([(r"^EXPLAIN", {
            "columns": ["id", "table", "type", "ref", "Extra"],
            "rows": [(1, "c", "ALL", None, ""),
                     (1, "o", "ALL", None,
                      "Using where; Using join buffer (flat, BNL join)")]}),
            (r"FOR SELECT c.name", [("Ann",)])])
        box, data = toolbox(data)
        got = box.execute(sql, 5)
        self.assertEqual(got["error"], "")
        self.assertTrue(data.ran(r"FOR SELECT c.name"))

    def test_a_failed_explain_is_skipped(self):
        data = Data([(r"^EXPLAIN", RuntimeError("no plan")),
                     (r"FOR SELECT", [(1,)])])
        box, _data = toolbox(data)
        got = box.execute(self.SQL, 5)
        self.assertEqual((got["error"], got["total"]), ("", 1))

    def test_a_refused_sql_never_reaches_the_database(self):
        box, data = toolbox()
        opened = data.opened
        got = box.execute("DELETE FROM customers", 5)
        self.assertIn("only a SELECT", got["error"])
        self.assertEqual(data.opened, opened)


class ExplainCheckTests(EnvironmentKept):
    """schema_graph.explain_check on plans we state."""

    def check(self, sql, *rows):
        from schema_graph import explain_check
        data = Data([(r"^EXPLAIN", {
            "columns": ["id", "select_type", "table", "type", "ref", "Extra"],
            "rows": [(r[0], "SIMPLE") + tuple(r[1:]) for r in rows]})])
        return explain_check(sql, data.connect())[0]

    def test_a_join_read_through_the_join_buffer(self):
        self.assertEqual(self.check(
            "SELECT * FROM customers c JOIN sales_orders o "
            "ON o.customer_id = c.customer_id",
            (1, "c", "ALL", None, ""),
            (1, "o", "ALL", None, "Using where; Using join buffer (flat, BNL join)")),
            "OK")
        # a comma join and its condition in WHERE, the plan naming tables
        self.assertEqual(self.check(
            "SELECT * FROM customers, sales_orders "
            "WHERE sales_orders.customer_id = customers.customer_id",
            (1, "customers", "ALL", None, ""),
            (1, "sales_orders", "ALL", None, "Using where; Using join buffer")),
            "OK")
        # a join condition under an OR still names both tables
        self.assertEqual(self.check(
            "SELECT * FROM customers c, carriers k WHERE k.name = 'x' "
            "AND c.city = k.name OR k.carrier_id > 3",
            (1, "c", "ALL", None, ""),
            (1, "k", "ALL", None, "Using where; Using join buffer")),
            "OK")

    def test_a_join_on_a_range(self):
        sql = ("SELECT * FROM salary_history s JOIN employees e "
               "ON e.hire_date BETWEEN s.effective_from AND s.effective_to")
        self.assertEqual(self.check(
            sql, (1, "s", "ALL", None, ""),
            (1, "e", "ALL", None, "Range checked for each record (index map: 0x2)")),
            "OK")
        self.assertEqual(self.check(
            sql, (1, "s", "ALL", None, ""), (1, "e", "range", None, "Using where")),
            "OK")

    def test_a_cartesian_product_is_still_refused(self):
        self.assertEqual(self.check(
            "SELECT * FROM customers, carriers",
            (1, "customers", "ALL", None, ""),
            (1, "carriers", "ALL", None, "Using join buffer (flat, BNL join)")),
            "REJECT cartesian")
        # a condition on one table joins it to nothing
        self.assertEqual(self.check(
            "SELECT * FROM customers c, carriers k WHERE k.name = 'x'",
            (1, "c", "ALL", None, ""),
            (1, "k", "ALL", None, "Using where; Using join buffer")),
            "REJECT cartesian")
        # a range read on its own key, a constant's, is no join either
        self.assertEqual(self.check(
            "SELECT * FROM customers c, carriers k WHERE k.carrier_id < 10",
            (1, "c", "ALL", None, ""), (1, "k", "range", None, "Using where")),
            "REJECT cartesian")

    def test_columns_with_no_table_before_them(self):
        sql = "SELECT * FROM customers, carriers WHERE city = carriers_name"
        self.assertEqual(self.check(
            sql, (1, "customers", "ALL", None, ""),
            (1, "carriers", "ALL", None, "Using where; Using join buffer")), "OK")
        self.assertEqual(self.check(
            sql, (1, "customers", "ALL", None, ""),
            (1, "carriers", "ALL", None, "")), "REJECT cartesian")

    def test_a_derived_table_joined(self):
        self.assertEqual(self.check(
            "SELECT * FROM (SELECT customer_id FROM sales_orders) d "
            "JOIN customers c ON c.customer_id = d.customer_id",
            (1, "<derived2>", "ALL", None, ""),
            (1, "c", "ALL", None, "Using where; Using join buffer"),
            (2, "sales_orders", "ALL", None, "")), "OK")


class RunCountTests(EnvironmentKept):
    def test_count_rows_and_fact(self):
        data = Data([(r"COUNT\(\*\) FROM \(", [(12,)]),
                     (r"FOR SELECT name FROM customers LIMIT 6$",
                      {"columns": ["name"], "rows": [(f"c{i}",) for i in range(12)]})])
        box, _data = toolbox(data)
        got = box.run("run_count", {"sql": "SELECT name FROM customers"})
        self.assertTrue(got.ok)
        self.assertEqual(got.data["count"], 12)
        self.assertEqual(len(got.data["rows"]), 5)
        self.assertEqual(got.facts[0].kind, "count")
        self.assertEqual(got.facts[0].key, vt.sql_key("select name from customers"))
        self.assertEqual(got.facts[0].value["count"], 12)

    def test_a_refusal_is_a_failed_result(self):
        box, _data = toolbox()
        got = box.run("run_count", {"sql": "DROP TABLE customers"})
        self.assertFalse(got.ok)

    JOINED = ("SELECT * FROM sales_orders o JOIN customers c "
              "ON c.customer_id = o.customer_id WHERE c.city = 'Lyon'")

    class Duplicate(Exception):
        pass

    def joined(self, light):
        """Forty rows with two columns of one name: MariaDB refuses the
        COUNT(*) around them (1060); `light` answers the count of the
        query with its columns replaced by 1."""
        return Data([
            (r"COUNT\(\*\) FROM \(SELECT 1 AS _x FROM", light),
            (r"COUNT\(\*\) FROM \(", self.Duplicate(
                1060, "Duplicate column name 'customer_id'")),
            (r"FOR SELECT \* FROM sales_orders",
             {"columns": ["order_id", "customer_id", "customer_id"],
              "rows": [(i, 1, 1) for i in range(40)]})])

    def test_select_star_over_a_join_is_counted_without_its_columns(self):
        box, data = toolbox(self.joined([(40,)]))
        got = box.run_count(self.JOINED)
        self.assertTrue(got.ok)
        self.assertEqual(got.data["count"], 40)
        self.assertTrue(got.complete)
        self.assertEqual(got.data["lower_bound"], 40)
        light = data.ran(r"SELECT 1 AS _x FROM")
        self.assertEqual(len(light), 1)
        self.assertIn("WHERE c.city = 'Lyon'", light[0])
        self.assertTrue(light[0].startswith(
            "SET STATEMENT max_statement_time=5 FOR SELECT COUNT(*) FROM ("))

    def test_two_columns_of_one_name_are_counted_with_their_names_apart(self):
        # review of 26 October: COUNT(*) around two columns named customer_id
        # failed (1060), and a DISTINCT cannot take the count with its
        # columns replaced by 1
        sql = ("SELECT DISTINCT o.customer_id, c.customer_id FROM sales_orders o "
               "JOIN customers c ON c.customer_id = o.customer_id")
        data = Data([
            (r"AS _c1 FROM sales_orders", [(37,)]),
            (r"COUNT\(\*\) FROM \(", self.Duplicate(1060, "Duplicate column name 'customer_id'")),
            (r"FOR SELECT DISTINCT",
             {"columns": ["customer_id", "customer_id"], "rows": [(i, i) for i in range(40)]})])
        box, data = toolbox(data)
        got = box.run_count(sql)
        self.assertEqual(got.data["count"], 37)
        self.assertTrue(got.complete)

    def test_the_names_apart_spell_out_a_star_from_the_catalogue(self):
        catalogue = {"products": [("product_id", "int"), ("name", "varchar")],
                     "categories": [("category_id", "int"), ("name", "varchar")]}
        named = vt._named_apart_sql(
            "SELECT * FROM products p JOIN categories c ON p.product_id = c.category_id "
            "ORDER BY p.name", lambda t: catalogue.get(t, []))
        self.assertIn("SELECT p.product_id, p.name, c.category_id, c.name AS _c3 FROM", named)
        self.assertNotIn("ORDER BY", named)        # the order changes no count
        # each branch of a UNION, and never a star over what it cannot see
        self.assertIn("SELECT name, name AS _c1 FROM categories", vt._named_apart_sql(
            "SELECT p.name, c.name FROM products p JOIN categories c ON 1 = 1 "
            "UNION SELECT name, name FROM categories", lambda t: catalogue.get(t, [])))
        self.assertIsNone(vt._named_apart_sql(
            "WITH x AS (SELECT 1 a) SELECT * FROM x JOIN products p ON 1 = 1",
            lambda t: catalogue.get(t, [])))

    def test_an_unknown_total_is_never_zero(self):
        box, _data = toolbox(self.joined(self.Duplicate(1060, "again")))
        got = box.run_count(self.JOINED)
        self.assertTrue(got.ok)
        self.assertIsNone(got.data["count"])
        self.assertFalse(got.data["complete"])
        self.assertFalse(got.complete)
        # the rows read: COUNT_ROWS shown and one more that said "more"
        self.assertEqual(got.data["lower_bound"], vt.COUNT_ROWS + 1)
        self.assertEqual(got.rows, vt.COUNT_ROWS + 1)
        self.assertIn("at least 6", got.digest)
        fact = got.facts[0].value
        self.assertEqual((fact["count"], fact["complete"], fact["lower_bound"]),
                         (None, False, 6))

    def test_a_count_out_of_time_is_not_tried_twice(self):
        class Timeout(Exception):
            pass
        data = self.joined([(40,)])
        data.rules.insert(0, (re.compile(r"COUNT\(\*\) FROM \(SELECT \*", re.I),
                              Timeout(1969, "max_statement_time exceeded")))
        box, data = toolbox(data)
        got = box.run_count(self.JOINED)
        self.assertIsNone(got.data["count"])
        self.assertFalse(data.ran(r"SELECT 1 AS _x"))

    def test_the_columns_that_decide_the_rows_are_kept(self):
        light = vt._count_sql
        self.assertEqual(
            light("SELECT a.x, b.y FROM a JOIN b ON a.id = b.id WHERE b.y > 2 "
                  "GROUP BY a.x, b.y HAVING COUNT(*) > 1 ORDER BY a.x LIMIT 10"),
            "SELECT COUNT(*) FROM (SELECT 1 AS _x FROM a JOIN b ON a.id = b.id "
            "WHERE b.y > 2 GROUP BY a.x, b.y HAVING COUNT(*) > 1 LIMIT 10) AS _n")
        self.assertIsNotNone(light("SELECT x, SUM(x) OVER () FROM a"))
        self.assertIsNotNone(light("SELECT x, (SELECT MAX(y) FROM b) FROM a"))
        for sql in ("SELECT DISTINCT x FROM a",
                    "SELECT COUNT(*) FROM a",
                    "SELECT x, COUNT(*) FROM a GROUP BY 1",
                    "SELECT x AS k, COUNT(*) FROM a GROUP BY k",
                    "SELECT x, COUNT(*) AS n FROM a GROUP BY x HAVING n > 1",
                    "SELECT x FROM a UNION SELECT y FROM b",
                    "not sql at all ((("):
            self.assertIsNone(light(sql), sql)


class CompareReadingsTests(EnvironmentKept):
    A = "SELECT customer_id, net_amount FROM sales_orders"
    B = "SELECT customer_id, net_amount FROM sales_orders WHERE 1 = 1"

    def compare(self, a_rows, b_rows, a=A, b=B, settings=None, rules=()):
        data = Data(list(rules) + [
            (re.escape(b) + r"( LIMIT \d+)?$", b_rows),
            (re.escape(a) + r"( LIMIT \d+)?$", a_rows)])
        box, _data = toolbox(data, settings=settings)
        return box.run("compare_readings", {"sqls": [a, b]})

    def test_the_same_rows_in_another_order(self):
        got = self.compare([(1, decimal.Decimal("2.50")), (2, 3)],
                           [(2, 3.0), (1, 2.5)])
        pair = got.data["pairs"][0]
        self.assertTrue(pair["same"])
        self.assertEqual((pair["only_a"], pair["only_b"], pair["share"]), (0, 0, 0))
        hashes = {r["hash"] for r in got.data["results"]}
        self.assertEqual(len(hashes), 1)
        self.assertIn("the same 2 rows", got.digest)

    def test_rows_that_differ(self):
        a = [(i, i * 10) for i in range(10)]
        b = [(i, i * 10) for i in range(8)] + [(20, 1), (21, 1)]
        got = self.compare(a, b)
        pair = got.data["pairs"][0]
        self.assertFalse(pair["same"])
        self.assertEqual((pair["only_a"], pair["only_b"]), (2, 2))
        self.assertAlmostEqual(pair["share"], 0.2)
        kinds = [f.kind for f in got.facts]
        self.assertEqual(kinds.count("compare"), 1)
        self.assertEqual(kinds.count("count"), 2)
        compare = next(f for f in got.facts if f.kind == "compare")
        self.assertEqual(compare.key, vt.readings_key(self.A, self.B))

    def test_the_same_rows_with_the_columns_swapped(self):
        a = "SELECT name, city FROM customers"
        b = "SELECT city, name FROM customers"
        rows = [("Ann", "Lyon"), ("Bob", "Paris")]
        got = self.compare({"columns": ["name", "city"], "rows": rows},
                           {"columns": ["city", "name"],
                            "rows": [(c, n) for n, c in rows]}, a=a, b=b)
        pair = got.data["pairs"][0]
        self.assertTrue(pair["same"])
        self.assertEqual(pair["reordered"], [1, 0])
        # unnamed alike, the values alone line the columns up
        got = self.compare({"columns": ["x", "y"], "rows": rows},
                           {"columns": ["p", "q"],
                            "rows": [(c, n) for n, c in rows]}, a=a, b=b)
        self.assertTrue(got.data["pairs"][0]["same"])
        # a swap that does not give the same rows is no excuse
        got = self.compare({"columns": ["name", "city"], "rows": rows},
                           {"columns": ["city", "name"],
                            "rows": [("Lyon", "Bob"), ("Paris", "Ann")]},
                           a=a, b=b)
        self.assertFalse(got.data["pairs"][0]["same"])
        self.assertNotIn("reordered", got.data["pairs"][0])

    def test_an_average_over_a_decimal_and_over_a_double(self):
        got = self.compare([(1, decimal.Decimal("312.4567")), (2, decimal.Decimal("0.0000"))],
                           [(1, 312.45666666666665), (2, -0.00001)])
        self.assertTrue(got.data["pairs"][0]["same"])
        got = self.compare([(1, decimal.Decimal("312.4567"))], [(1, 312.4568)])
        self.assertFalse(got.data["pairs"][0]["same"])

    def test_a_date_and_a_time_stamp_of_midnight(self):
        got = self.compare([(1, D(2026, 1, 2))], [(1, DT(2026, 1, 2))])
        self.assertTrue(got.data["pairs"][0]["same"])
        got = self.compare([(1, D(2026, 1, 2))], [(1, DT(2026, 1, 2, 0, 0, 1))])
        self.assertFalse(got.data["pairs"][0]["same"])

    def test_shapes_that_differ_compare_on_the_first_column(self):
        b = "SELECT customer_id FROM sales_orders"
        got = self.compare([(1, 5), (2, 6)], [(2,), (1,)], b=b)
        pair = got.data["pairs"][0]
        self.assertEqual(pair["compared_on"], "first column")
        self.assertTrue(pair["same"])

    def test_two_rankings_of_the_same_rows_are_said_ranked_otherwise(self):
        # review of 26 October: "the oldest products" by created_at and by
        # updated_at were the same rows, and Q10's choice was dropped. The
        # rows stay the same rows; the places that differ are said, and the
        # verifier decides whether the question asks for an order
        a = "SELECT product_id FROM products ORDER BY created_at"
        b = "SELECT product_id FROM products ORDER BY updated_at"
        got = self.compare([(1,), (2,), (3,), (4,)], [(3,), (1,), (2,), (4,)], a=a, b=b)
        pair = got.data["pairs"][0]
        self.assertTrue(pair["same"])
        self.assertEqual((pair["order_moved"], pair["order_share"]), (3, 0.75))
        self.assertIn("ranked otherwise", got.digest)
        # ordered by the same key, two shapes: ties and a column swap are
        # the same ranking (review of the fixes)
        a2 = "SELECT name, net_amount FROM sales_orders ORDER BY net_amount DESC"
        b2 = "SELECT net_amount, name FROM sales_orders ORDER BY o.net_amount DESC"
        got = self.compare({"columns": ["name", "net_amount"], "rows": [("x", 3), ("y", 3), ("z", 1)]},
                           {"columns": ["net_amount", "name"], "rows": [(3, "y"), (3, "x"), (1, "z")]},
                           a=a2, b=b2)
        self.assertNotIn("order_moved", got.data["pairs"][0])
        # the same ranking, one reading showing the measure it ranks by
        b2 = "SELECT product_id, created_at FROM products ORDER BY created_at"
        got = self.compare([(1,), (2,)], [(1, D(2020, 1, 1)), (2, D(2021, 1, 1))], a=a, b=b2)
        self.assertTrue(got.data["pairs"][0]["same"])
        # only one ordered: the order means nothing to the other
        got = self.compare([(1,), (2,)], [(2,), (1,)], a=a,
                           b="SELECT product_id FROM products")
        self.assertTrue(got.data["pairs"][0]["same"])

    def test_past_the_rows_compared_equal_counts_are_undetermined(self):
        rows = [(i, i) for i in range(5)]
        got = self.compare(rows, list(reversed(rows)),
                           settings=vt.Settings(compare_rows=3),
                           rules=[(r"COUNT\(\*\) FROM \(", [(5,)])])
        pair = got.data["pairs"][0]
        self.assertTrue(pair["undetermined"])
        self.assertIsNone(pair["same"])
        self.assertEqual(pair["compared_on"], "count")
        self.assertFalse(got.complete)
        self.assertTrue(all(r["truncated"] for r in got.data["results"]))

    def test_past_the_rows_compared_different_counts_differ(self):
        def counted(sql, _params):
            return [(9,)] if "WHERE 1 = 1" in sql else [(5,)]
        got = self.compare([(i, i) for i in range(5)], [(i, i) for i in range(9)],
                           settings=vt.Settings(compare_rows=3),
                           rules=[(r"COUNT\(\*\) FROM \(", counted)])
        pair = got.data["pairs"][0]
        self.assertFalse(pair["same"])
        self.assertFalse(pair["undetermined"])

    def test_four_readings_six_pairs_and_bounds(self):
        box, _data = toolbox()
        sqls = [f"SELECT name FROM customers WHERE customer_id > {i}"
                for i in range(4)]
        got = box.compare_readings(sqls)
        self.assertEqual(len(got.data["pairs"]), 6)
        self.assertFalse(box.compare_readings(sqls[:1]).ok)
        self.assertFalse(box.compare_readings(sqls + [sqls[0]]).ok)
        refused = box.compare_readings([sqls[0], "DELETE FROM customers"])
        self.assertFalse(refused.ok)
        self.assertIn("reading 1", refused.error)

    def test_a_reading_that_fails_leaves_its_pairs_undetermined(self):
        got = self.compare([(1, 1)], RuntimeError("boom"))
        self.assertFalse(got.ok)
        self.assertTrue(got.data["pairs"][0]["undetermined"])
        self.assertIn("reading 1", got.error)


class TimeColumnsTests(EnvironmentKept):
    def test_a_period_its_range_and_a_time_of_day(self):
        # per column: MIN, MAX, NULLs, values, values not at midnight
        row = (D(2023, 1, 1), D(2026, 9, 30), 0, 480, None,
               D(2023, 6, 30), D(2026, 9, 30), 120, 360, None,
               DT(2023, 1, 1, 9, 30), DT(2026, 9, 30, 17, 5), 0, 480, 37)
        data = Data([(r"MIN\(`effective_from`\)", [row])])
        box, data = toolbox(data)
        got = box.run("time_columns", {"table": "salary_history"})
        self.assertTrue(got.ok)
        moments = {m["column"]: m for m in got.data["moments"]}
        self.assertEqual(set(moments), {"effective_from", "effective_to",
                                        "created_at"})
        self.assertEqual(moments["effective_to"]["nulls"], 120)
        self.assertEqual(moments["effective_to"]["null_share"], 0.25)
        self.assertEqual(moments["effective_from"]["min"], "2023-01-01")
        self.assertIs(moments["created_at"]["has_time"], True)
        # a DATE has no time of day to look at: unknown, not midnight
        self.assertIsNone(moments["effective_to"]["has_time"])
        self.assertEqual(got.data["intervals"], [["effective_from", "effective_to"]])
        self.assertEqual(len(data.ran(r"FOR SELECT MIN\(`effective_from`\)")), 1)
        # read over the whole table: a sample's latest date is no latest
        self.assertFalse(data.ran(r"LIMIT 20000"))
        self.assertEqual(got.facts[0].kind, "time")

    def test_a_table_too_big_to_read_whole_is_read_on_its_first_rows(self):
        row = (D(2023, 1, 1), D(2026, 9, 30), 0, 480, None,
               D(2023, 6, 30), D(2026, 9, 30), 120, 360, None,
               DT(2023, 1, 1, 9, 30), DT(2026, 9, 30, 17, 5), 0, 480, 37)
        data = Data([(r"FROM `salary_history`( LIMIT \d+)?$", RuntimeError("1969 query execution was interrupted")),
                     (r"MIN\(`effective_from`\)", [row])])
        box, data = toolbox(data)
        got = box.run("time_columns", {"table": "salary_history"})
        self.assertTrue(got.ok)
        self.assertTrue(data.ran(r"LIMIT 20000"))
        self.assertEqual({m["column"]: m for m in got.data["moments"]}["effective_from"]["min"],
                         "2023-01-01")

    CLOCKS = {"clocks": [("clock_id", "int"), ("opens_at", "time"),
                         ("stamped_at", "datetime"), ("closed_at", "datetime"),
                         ("built_in", "year")]}

    def test_a_time_of_day_true_false_or_unknown(self):
        # a TIME holds one; a DATETIME all at midnight does not; a DATETIME
        # with no value says nothing; a YEAR has none to look at
        row = ("08:00:00", "18:00:00", 0, 40, None,
               DT(2026, 1, 1), DT(2026, 3, 1), 0, 40, 0,
               None, None, 40, 0, None,
               2001, 2020, 0, 40, None)
        box, _data = toolbox(Data([(r"MIN\(`opens_at`\)", [row])]),
                             columns=self.CLOCKS)
        got = box.time_columns("clocks")
        moments = {m["column"]: m["has_time"] for m in got.data["moments"]}
        self.assertEqual(moments, {"opens_at": True, "stamped_at": False,
                                   "closed_at": None, "built_in": None})
        text = got.render(4000)[0]
        self.assertIn("stamped_at (datetime): from 2026-01-01T00:00:00 to "
                      "2026-03-01T00:00:00, 0 NULL, midnight only", text)
        self.assertIn("closed_at (datetime): from None to None, 40 NULL "
                      "(100%), no value read", text)

    def test_an_empty_table_tells_no_time_of_day(self):
        row = (None, None, 0, 0, None) * 4
        box, _data = toolbox(Data([(r"MIN\(`opens_at`\)", [row])]),
                             columns=self.CLOCKS)
        got = box.time_columns("clocks")
        self.assertEqual({m["has_time"] for m in got.data["moments"]}, {None})
        self.assertEqual({m["null_share"] for m in got.data["moments"]}, {None})

    def test_the_profile_speaks_like_the_query(self):
        with tempfile.TemporaryDirectory() as folder:
            path = pathlib.Path(folder) / "p.json"
            path.write_text(json.dumps({"clocks": {
                "opens_at": {"min": "08:00:00", "max": "18:00:00",
                             "has_time": False, "rows": 200,
                             "null_share": 0.1},
                "stamped_at": {"min": "2026-01-01", "max": "2026-03-01",
                               "has_time": False, "rows": 200,
                               "null_share": 0.25},
                "closed_at": {"min": None, "max": None, "has_time": False,
                              "rows": 200, "null_share": 1.0},
                "built_in": {"min": 2001, "max": 2020, "has_time": False,
                             "nulls": 3, "rows": 200}}}), encoding="utf-8")
            box, data = toolbox(profile=str(path), columns=self.CLOCKS)
            got = box.time_columns("clocks")
        self.assertFalse(data.ran("MIN"))
        moments = {m["column"]: m for m in got.data["moments"]}
        # a share is not a count: the count is the rows read times it
        self.assertEqual((moments["stamped_at"]["nulls"],
                          moments["stamped_at"]["null_share"]), (50, 0.25))
        self.assertEqual((moments["built_in"]["nulls"],
                          moments["built_in"]["null_share"]), (3, 0.015))
        self.assertEqual({c: m["has_time"] for c, m in moments.items()},
                         {"opens_at": True, "stamped_at": False,
                          "closed_at": None, "built_in": None})

    def test_history_tables_and_a_link_to_itself(self):
        box, _data = toolbox()
        got = box.time_columns("employees")
        self.assertEqual(got.data["history_tables"], ["salary_history"])
        self.assertEqual(got.data["parent_links"],
                         ["employees.manager_id = employees.employee_id"])

    def test_the_kind_of_event(self):
        box, _data = toolbox()
        got = box.time_columns("stock_movements")
        self.assertEqual(got.data["event_type"], "movement_type")
        self.assertIsNone(box.time_columns("exchange_rates").data["event_type"])

    def test_a_table_with_no_moment(self):
        box, data = toolbox()
        got = box.time_columns("carriers")
        self.assertEqual(got.data["moments"], [])
        self.assertIn("no date or time column", got.digest)
        self.assertFalse(data.ran("MIN"))

    def test_the_profile_spares_the_query(self):
        with tempfile.TemporaryDirectory() as folder:
            path = pathlib.Path(folder) / "p.json"
            path.write_text(json.dumps({"employees": {"hire_date": {
                "min": "2001-03-01", "max": "2026-09-01", "has_time": False,
                "nulls": 0}}}), encoding="utf-8")
            box, data = toolbox(profile=str(path))
            got = box.time_columns("employees")
        self.assertEqual(got.data["moments"][0]["min"], "2001-03-01")
        self.assertFalse(data.ran("MIN"))


class RunAndRenderTests(EnvironmentKept):
    def test_run_never_raises(self):
        box, _data = toolbox()
        self.assertFalse(box.run("drop_everything", {}).ok)
        self.assertIn("unknown tool", box.run("drop_everything", {}).error)
        self.assertIn("needs `phrase`", box.run("search_tables", None).error)
        self.assertIn("whole number",
                      box.run("search_tables", {"phrase": "x", "n": "lots"}).error)
        self.assertFalse(box.run("compare_readings", {"sqls": "SELECT 1"}).ok)
        with patch.object(box.clar, "column_evidence",
                          side_effect=RuntimeError("broken")):
            got = box.run("find_columns", {"phrase": "name"})
        self.assertFalse(got.ok)
        self.assertIn("broken", got.error)
        self.assertLessEqual(len(got.error), vt.ERROR_WIDTH)

    def test_render_pages_to_the_cap(self):
        result = vt.ToolResult("x", True, {}, "a test", lines=[
            f"line {i} " + "word " * 20 for i in range(40)])
        text, size = result.render(200)
        self.assertTrue(size["truncated"])
        self.assertIsNotNone(size["more"])
        self.assertLessEqual(size["tokens"], 260)
        rest, size2 = result.render(10000, offset=size["more"])
        self.assertFalse(size2["truncated"])
        self.assertIn("line 39", rest)
        self.assertNotIn("line 0 ", rest)
        head, size3 = result.render(0)
        self.assertEqual(head, "x: a test")
        self.assertEqual(size3["more"], 0)

    def test_a_failed_result_renders_its_error(self):
        text, size = vt._failed("join_path", "unknown table q").render(100)
        self.assertEqual(text, "join_path failed: unknown table q")
        self.assertFalse(size["truncated"])


class AbsentEverywhereTests(EnvironmentKept):
    def test_a_column_named_for_it_is_not_absent(self):
        box, _data = toolbox()
        absent, complete, hits = box.absent_everywhere("delivered date")
        self.assertFalse(absent)
        self.assertIn({"table": "shipments", "column": "delivered_date",
                       "how": "token"}, hits)

    def test_a_literal_no_column_holds(self):
        box, _data = toolbox()
        self.assertEqual(box.absent_everywhere("Zorglub"), (True, True, []))

    def test_an_echo_of_the_kind_forbids_no_denial(self):
        # "score" echoes nps_score, "engagement" nothing: the old judge's
        # rule lets the rows be swept, and nothing holds the phrase (E40)
        box, _data = toolbox()
        box.clar.column_evidence = lambda text, semantic=False: [
            ("surveys", "nps_score", "token")]
        box.clar.withholds_denial = lambda text: False
        self.assertEqual(box.absent_everywhere("engagement score"), (True, True, []))
        self.assertEqual(box.last_echoes, [{"table": "surveys", "column": "nps_score",
                                            "how": "token"}])

    def test_evidence_that_withholds_a_denial_is_kept(self):
        box, _data = toolbox()
        box.clar.column_evidence = lambda text, semantic=False: [
            ("shipments", "delivered_date", "token")]
        box.clar.withholds_denial = lambda text: True
        absent, complete, hits = box.absent_everywhere("delivered date")
        self.assertFalse(absent)
        self.assertEqual(box.last_echoes, [])

    def test_a_failing_denial_rule_keeps_the_evidence(self):
        box, _data = toolbox()
        box.clar.column_evidence = lambda text, semantic=False: [("t", "c", "token")]

        def broken(text):
            raise RuntimeError("no")
        box.clar.withholds_denial = broken
        self.assertFalse(box.absent_everywhere("engagement score")[0])

    def test_a_literal_a_column_holds(self):
        box, _data = toolbox(Data([(r"`city`\) LIKE", [("Zorglub",)])]))
        absent, complete, hits = box.absent_everywhere("Zorglub")
        self.assertFalse(absent)
        self.assertEqual(hits, [{"table": "customers", "column": "city",
                                 "how": "value"}])

    def test_a_failed_lookup_proves_nothing(self):
        box, _data = toolbox(Data([(r"LIKE", RuntimeError("down"))]))
        self.assertEqual(box.absent_everywhere("Zorglub"), (True, False, []))

    def test_the_sweep_is_bounded(self):
        box, data = toolbox()
        self.assertEqual(box.absent_everywhere("Zorglub"), (True, True, []))
        self.assertTrue(data.ran(r"SET SESSION max_statement_time=2$"))
        self.assertEqual(data.opened, data.closed)
        with patch.object(vt, "SWEEP_COLUMNS", 2):
            self.assertEqual(box.absent_everywhere("Zorglub"), (True, False, []))
            self.assertEqual(box.absent_everywhere("100234"), (True, False, []))
        ticks = iter(range(0, 10000, 10))
        box.clock = lambda: float(next(ticks))
        self.assertEqual(box.absent_everywhere("Zorglub"), (True, False, []))

    def test_a_number_is_looked_for_in_the_numeric_columns(self):
        box, data = toolbox(Data([
            (r"FROM `sales_orders` WHERE `order_id` = %s", [(100234,)])]))
        absent, complete, hits = box.absent_everywhere("100234")
        self.assertEqual((absent, complete), (False, True))
        self.assertEqual(hits, [{"table": "sales_orders", "column": "order_id",
                                 "how": "value"}])
        at = data.sql.index(data.ran(r"WHERE `order_id` = %s")[0])
        self.assertEqual(data.params[at], (100234,))

    def test_a_number_no_column_holds(self):
        box, data = toolbox()
        self.assertEqual(box.absent_everywhere("100234"), (True, True, []))
        # the whole numbers by equality, the decimals as written, and the
        # text columns, where a legacy schema keeps numbers too
        self.assertTrue(data.ran(r"FROM `inventory` WHERE `quantity_on_hand` = %s"))
        self.assertTrue(data.ran(r"FROM `sales_orders` WHERE `net_amount` = %s"))
        like = data.sql.index(data.ran(r"FROM `customers` WHERE LOWER\(`name`\) LIKE")[0])
        self.assertEqual(data.params[like], ("%100234%",))
        # no date column for a number that is no year
        self.assertFalse(data.ran(r"`order_date` >="))
        self.assertFalse(data.ran(r"SOUNDEX"))

    def test_a_date_by_its_day(self):
        box, data = toolbox(Data([
            (r"FROM `shipments` WHERE `delivered_date` >=", [(D(2026, 10, 9),)])]))
        absent, complete, hits = box.absent_everywhere("2026-10-09")
        self.assertFalse(absent)
        self.assertEqual(hits[0]["column"], "delivered_date")
        sent = data.ran(r"WHERE `order_date` >= %s AND `order_date` < %s")
        self.assertEqual(data.params[data.sql.index(sent[0])],
                         ("2026-10-09", "2026-10-10"))
        self.assertFalse(data.ran(r"`order_id` ="))

    def test_a_year_by_its_span_and_a_time_stamp_by_equality(self):
        box, data = toolbox()
        self.assertEqual(box.absent_everywhere("2025"), (True, True, []))
        sent = data.ran(r"WHERE `hire_date` >= %s AND `hire_date` < %s")
        self.assertEqual(data.params[data.sql.index(sent[0])],
                         ("2025-01-01", "2026-01-01"))
        self.assertTrue(data.ran(r"WHERE `order_id` = %s"))
        box, data = toolbox()
        self.assertEqual(box.absent_everywhere("2026-01-02 10:30:00"),
                         (True, True, []))
        sent = data.ran(r"WHERE `moved_at` = %s")
        self.assertEqual(data.params[data.sql.index(sent[0])],
                         ("2026-01-02 10:30:00",))
        # a DATE never holds half past ten
        self.assertFalse(data.ran(r"`hire_date` ="))

    def test_a_failed_typed_lookup_proves_nothing(self):
        box, _data = toolbox(Data([(r"WHERE `order_id` = %s", RuntimeError("x"))]))
        self.assertEqual(box.absent_everywhere("100234"), (True, False, []))

    def test_a_lower_case_word_is_swept_too(self):
        def like(_sql, params):
            return [("cheap",)] if params and "cheap" in str(params[0]) else []
        box, data = toolbox(Data([(r"FROM `customers` WHERE LOWER\(`segment`\) LIKE", like)]))
        self.assertFalse(box.clar.a_literal("cheap"))
        absent, complete, hits = box.absent_everywhere("cheap")
        self.assertFalse(absent)
        self.assertEqual(hits, [{"table": "customers", "column": "segment",
                                 "how": "value"}])
        box, data = toolbox()
        self.assertEqual(box.absent_everywhere("latest"), (True, True, []))
        self.assertTrue(data.ran(r"LIKE"))

    def test_what_a_table_is_for_withholds_the_denial(self):
        meanings = dictionary.empty()
        meanings["tables"] = {"carriers": "Transport companies, the hauliers "
                                          "we ship with"}
        box, data = toolbox(meanings=meanings)
        absent, complete, hits = box.absent_everywhere("Hauliers")
        self.assertFalse(absent)
        self.assertEqual(hits, [{"table": "carriers", "column": "name",
                                 "how": "about"}])

    def test_closeness_in_meaning_withholds_the_denial(self):
        box, _data = toolbox()
        with patch.object(box.clar, "similar_columns",
                          return_value=[("carriers", "name", 0.91)]):
            absent, complete, hits = box.absent_everywhere("Zorglub")
        self.assertFalse(absent)
        self.assertEqual(hits, [{"table": "carriers", "column": "name",
                                 "how": "similar"}])


class CheckValueBoundsTests(EnvironmentKept):
    """Clarifier.check_value, bounded by its caller."""

    def test_unbounded_it_sweeps_every_text_column(self):
        box, data = toolbox()
        self.assertEqual(box.clar.check_value("Zorglub"), (None, True))
        self.assertEqual(data.opened, data.closed)

    def test_cut_by_columns_or_time_it_proves_nothing(self):
        box, data = toolbox()
        self.assertEqual(box.clar.check_value("Zorglub", max_columns=2),
                         (None, False))
        self.assertEqual(len(data.ran(r"LIKE")), 2)
        self.assertEqual(box.clar.check_value("Zorglub", until=-1.0,
                                              clock=lambda: 0.0),
                         (None, False))
        found = Data([(r"FROM `customers` WHERE LOWER\(`city`\) LIKE", [("Zorglub",)])])
        box, _data = toolbox(found)
        self.assertEqual(box.clar.check_value("Zorglub", max_columns=50),
                         (("customers", "city"), True))

    def test_a_value_is_looked_up_in_any_case(self):
        # review of 26 October: under a _bin collation "high" missed "HIGH"
        box, data = toolbox()
        box.clar.check_value("ZorGlub", max_columns=1)
        sent = data.ran(r"LIKE")
        self.assertIn("LOWER(", sent[0])
        self.assertEqual(data.params[data.sql.index(sent[0])][0], "%zorglub%")
        box, data = toolbox()
        box.absent_everywhere("ZorGlub")
        swept = data.ran(r"LIKE")
        self.assertTrue(swept)
        self.assertTrue(all("LOWER(" in s for s in swept))
        self.assertEqual({data.params[data.sql.index(s)][0] for s in swept}, {"%zorglub%"})

    def test_a_lent_connection_is_left_open(self):
        box, data = toolbox()
        con = data.connect()
        closed = data.closed
        self.assertEqual(box.clar.check_value("Zorglub", con=con), (None, True))
        self.assertEqual(data.closed, closed)
        self.assertEqual(data.opened, closed + 1)


# ------------------------------------------- the agent on the real tools
class ScriptedModel:
    """A model that replies from a script, one reply a call; `sent` keeps
    what it was sent."""

    def __init__(self, replies):
        self.replies = list(replies)
        self.sent = []
        self.think = None
        self.num_ctx = 16384
        self.name = self.model = "scripted"
        self.on_progress = None
        self.last_error = ""
        self.last_server = {}
        self.last_prompt_tokens = 0

    def thinks(self):
        return False

    def thinking(self, on):
        return self

    def loaded_window(self):
        return None

    def reachable(self):
        return True

    def json(self, system, user, schema=None, **kw):
        self.sent.append({"user": user, "schema": schema})
        if not self.replies:
            self.last_error = "script exhausted"
            return None
        self.last_error = ""
        return json.loads(json.dumps(self.replies.pop(0)))


def reading(tables, values=()):
    return {"measure": "", "entities": [], "filters": [], "values": list(values),
            "tables": list(tables), "period": "", "comparisons": [],
            "time": "none", "time_relations": []}


def planned(tables, call=None):
    reply = {"thought_summary": "read", "notes": [], "reading": reading(tables),
             "plan": [{"do": "look at the tables", "status": "todo"}],
             "action": "call" if call else "conclude"}
    if call:
        reply["call"] = call
    return reply


def concluded(verdict, tables, columns=(), issues=()):
    return {"thought_summary": "done", "notes": [],
            "plan": [{"do": "look at the tables", "status": "done"}],
            "action": "conclude",
            "conclusion": {"reason": "read off the tables", "verdict": verdict,
                           "tables": list(tables), "columns": list(columns),
                           "joins": [], "issues": list(issues)}}


class AgentOnTheRealToolsTests(EnvironmentKept):
    """verdict_agent.VerdictAgent with a scripted model, on this module's
    ToolBox and SchemaView and the rule-based database: the probes, the
    tools the agent calls and the verifier's checks all run real code."""

    def run_agent(self, data, replies, question):
        import verdict_agent

        model = ScriptedModel(replies)
        clar = clarifier(data, llm=model)
        view = vt.SchemaView(clar)
        agent = verdict_agent.VerdictAgent(
            clar, view=view, settings=vt.Settings(judge_mode="agent"),
            system="SYSTEM")
        return agent.clarify(question), agent, model

    def assert_read_only(self, data):
        writes = [s for s in data.sql if re.match(
            r"\s*(INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|REPLACE|TRUNCATE)\b",
            re.sub(r"^SET STATEMENT \S+ FOR ", "", s), re.I)]
        self.assertEqual(writes, [])
        self.assertEqual(data.opened, data.closed)

    def test_an_answer(self):
        import coverage

        count = "SELECT carrier_id, COUNT(*) FROM shipments GROUP BY carrier_id"
        data = Data([(r"FOR SELECT carrier_id, COUNT\(\*\) FROM shipments",
                      {"columns": ["carrier_id", "n"], "rows": [(1, 40), (2, 12)]})])
        out, agent, model = self.run_agent(data, [
            planned(["shipments", "carriers"],
                    call={"tool": "run_count", "args": {"sql": count}}),
            concluded("ANSWER", ["shipments", "carriers"], [
                {"table": "shipments", "column": "carrier_id", "role": "group"},
                {"table": "carriers", "column": "name", "role": "label"}])],
            "How many shipments has each carrier made?")
        self.assertEqual(coverage.classify(out)[0], coverage.ANSWERABLE)
        tools = [t.get("tool") for t in agent.last_trace["turns"]]
        self.assertIn("describe_tables", tools)
        self.assertIn("join_path", tools)
        self.assertIn("run_count", tools)
        self.assertEqual(agent.last_trace["mode"], "agent")
        # the probes described both tables, and the count really ran
        self.assertTrue({"shipments", "carriers"} <= set(agent.last_trace["tables_seen"]))
        self.assertTrue(data.ran(r"^SET STATEMENT max_statement_time=5 FOR "
                                 + re.escape(count)))
        self.assertIn("2 rows", "\n".join(m["user"] for m in model.sent))
        self.assert_read_only(data)

    def test_a_choice(self):
        import coverage

        by_amount = ("SELECT customer_id FROM sales_orders GROUP BY customer_id "
                     "ORDER BY SUM(net_amount) DESC LIMIT 3")
        by_orders = ("SELECT customer_id FROM sales_orders GROUP BY customer_id "
                     "ORDER BY COUNT(*) DESC LIMIT 3")
        data = Data([
            (r"FOR SELECT .*SUM\(net_amount\)",
             {"columns": ["customer_id"], "rows": [(1,), (2,), (3,)]}),
            (r"FOR SELECT .*ORDER BY COUNT\(\*\)",
             {"columns": ["customer_id"], "rows": [(4,), (2,), (5,)]})])
        choice = {"type": "choice", "phrase": "biggest", "kind": "AmbiSchema",
                  "what": "biggest by amount or by number of orders",
                  "readings": [
                      {"label": "by amount", "means": "the most net amount",
                       "table": "sales_orders", "column": "net_amount",
                       "sql": by_amount},
                      {"label": "by orders", "means": "the most orders",
                       "table": "sales_orders", "column": "order_id",
                       "sql": by_orders}],
                  "check_sql": "", "evidence": []}
        out, agent, _model = self.run_agent(data, [
            planned(["customers", "sales_orders"]),
            concluded("CHOICE", ["customers", "sales_orders"], issues=[choice])],
            "Who are our biggest customers?")
        self.assertEqual(coverage.classify(out)[0], coverage.NEEDS_CHOICE)
        self.assertEqual(out.phrase, "biggest")
        self.assertEqual([o.column for o in out.options], ["net_amount", "order_id"])
        self.assertEqual({o.via for o in out.options},
                         {"customers.customer_id = sales_orders.customer_id"})
        # the verifier ran both readings on the database and compared them
        compared = [c for c in agent.last_trace["verifier"]
                    if c.get("check") == "choice"]
        self.assertEqual(compared[0]["detail"],
                         "by amount vs by orders: differ on 4 rows (66.7%)")
        self.assertEqual(len(data.ran(r"FOR SELECT .*SUM\(net_amount\)")), 1)
        self.assertEqual(len(data.ran(r"FOR SELECT .*ORDER BY COUNT\(\*\)")), 1)
        self.assert_read_only(data)


# --------------------------------------------- the four example databases
EXAMPLES = HERE / "examples"


def from_knowledge_base(name):
    """A ToolBox on one of the example knowledge bases, with no database:
    the catalogue and the types from the file, the keys and the links from
    dictionary.load, and each coded column's values from its
    allowed_values. The connection answers nothing."""
    path = EXAMPLES / name
    raw = json.loads(path.read_text(encoding="utf-8"))
    meanings = dictionary.load(str(path))
    columns = {table: [(column, str((spec or {}).get("data_type") or "")
                        .lower()) for column, spec in entry["columns"].items()]
               for table, entry in raw.items()
               if isinstance(entry, dict) and isinstance(entry.get("columns"), dict)}
    samples = {pair: list(codes) for pair, codes in meanings["enums"].items()}
    box, data = toolbox(Data(), columns=columns, fks={}, edges=[],
                        meanings=meanings, samples=samples,
                        keys=set(meanings["keys"]))
    return box


class ExampleDatabaseTests(EnvironmentKept):
    def check(self, box, phrase, wanted, described, a, b, path):
        found = box.search_tables(phrase)
        self.assertTrue(found.ok, found.error)
        top = [t["table"] for t in found.data["tables"][:3]]
        self.assertIn(wanted, top, found.digest)
        shown = box.describe_tables(described)
        self.assertTrue(shown.ok, shown.error)
        self.assertEqual([t["table"] for t in shown.data["tables"]], described)
        joined = box.join_path(a, b)
        self.assertTrue(joined.data["found"], joined.digest)
        first = joined.data["paths"][0]
        self.assertEqual(first["tables"], path)
        self.assertEqual(set(first["sources"]), {"kb"})
        return first

    def test_library(self):
        box = from_knowledge_base("kb_library.json")
        first = self.check(box, "number of loans per member", "loans",
                           ["loans", "members"], "members", "genres",
                           ["members", "loans", "books", "genres"])
        self.assertEqual(first["via"], ["members.member_id = loans.member_id",
                                        "loans.book_id = books.book_id",
                                        "books.genre_id = genres.genre_id"])
        self.assertEqual(first["unseen"], ["books", "genres"])
        self.assertEqual(box.time_columns("genres").data["parent_links"],
                         ["genres.parent_genre_id = genres.genre_id"])

    def test_products(self):
        box = from_knowledge_base("kb_products.json")
        first = self.check(box, "average lead time in days per supplier",
                           "product_suppliers", ["product_suppliers"],
                           "suppliers", "warehouses",
                           ["suppliers", "product_suppliers", "products",
                            "inventory", "warehouses"])
        self.assertEqual(len(first["via"]), 4)
        self.assertEqual(box.time_columns("inventory_movements")
                         .data["event_type"], "movement_type")

    def test_enterprise(self):
        box = from_knowledge_base("kb_enterprise.json")
        box.describe_tables(["carriers", "products"])
        paths = box.join_path("carriers", "products").data["paths"]
        # the shortest paths go through tables never described, and say so;
        # which of several equally short ones come first depends on the
        # database's size, so the bridge through shipment_lines is looked for
        # among all of them
        self.assertTrue(paths)
        self.assertTrue(all(p["unseen"] == p["tables"][1:-1] for p in paths), paths)
        every = box.view.paths("carriers", "products", limit=20)
        through = [p for p in every if p["tables"] == [
            "carriers", "shipments", "shipment_lines", "products"]]
        self.assertEqual(len(through), 1, every)
        self.check(box, "shipments delivered late per carrier", "shipments",
                   ["shipments", "shipment_lines"], "shipments", "products",
                   ["shipments", "shipment_lines", "products"])
        unknown = box.describe_tables(["employes"]).data["unknown"][0]
        self.assertIn("employees", unknown["closest"])
        timed = box.time_columns("salary_history").data
        self.assertEqual(timed["intervals"], [["effective_from", "effective_to"]])
        people = box.time_columns("employees").data
        self.assertIn("salary_history", people["history_tables"])
        self.assertIn("position_history", people["history_tables"])
        self.assertIn("employees.manager_id = employees.employee_id",
                      people["parent_links"])

    def test_points(self):
        box = from_knowledge_base("kb_points.json")
        first = self.check(box, "geographic points elevation", "geo_point",
                           ["geo_point", "abs_point"], "point", "geo_point",
                           ["point", "abs_point", "geo_point"])
        self.assertEqual(first["via"], [
            "point.point_id = abs_point.abs_point_id",
            "abs_point.abs_point_id = geo_point.geo_point_id"])
        coded = box.find_value("geographic point")
        self.assertEqual(coded.data["hits"][0]["column"], "cat_code")
        self.assertEqual(coded.data["hits"][0]["matches"], ["GEOGPT"])


if __name__ == "__main__":
    unittest.main()
