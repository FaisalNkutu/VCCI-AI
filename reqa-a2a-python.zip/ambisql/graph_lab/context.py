"""Who asks, and when: the context that goes with every question.

A model does not know today's date. Asked "What was our revenue last
year?", the judge could not tell which year that was and stopped to ask
(E36, 23 October), and a database of dated events is only ever read
against a "now". So, as a chat assistant does, each question goes to the
models with what is known of the asker: the date and the time of the
question, the timezone, the language, and whatever static facts a
deployment adds (a location, a currency, the month the fiscal year
starts).

    from graph_lab.context import machine_context, describe
    ctx = machine_context(location="Montreal, Canada", currency="CAD")
    describe(ctx)
    # Asked on Friday 23 October 2026 at 12:31, UTC-04:00 (Eastern Daylight
    # Time). This year is 2026, last year was 2025: a relative period (last
    # year, this month, now) is counted from this date; a vague one
    # (recently, lately) gives no length, which only the asker knows.
    # Language: fr_CA. Location: Montreal, Canada. Currency: CAD.

Where it comes from, the latest winning:
  - the machine: date, time, weekday, UTC offset, timezone, language,
    read at each question, so the time is the time of the question;
  - DATAGORA_CONTEXT: static facts as JSON, or the path of a JSON file;
  - Datagora(context=...) or Pipeline(context=...): a dict of facts, a
    callable returning one, or False for no context at all;
  - ask(..., context=...): the same, for one question, as a server does
    for each of its users (their own timezone and local time).
"""

import datetime
import json
import locale
import logging
import os
import pathlib
import platform

log = logging.getLogger("datagora.context")

ENV = "DATAGORA_CONTEXT"
WEEKDAYS = ("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
MONTHS = ("January", "February", "March", "April", "May", "June", "July", "August",
          "September", "October", "November", "December")
# the keys describe() writes in its first sentences; any other is listed after
_TIME_KEYS = ("date", "time", "weekday", "utc_offset", "timezone")


def static_context(environ=None):
    """The facts DATAGORA_CONTEXT holds: JSON, or the path of a JSON file.
    Anything unreadable is no context, said once in the log."""
    raw = str((os.environ if environ is None else environ).get(ENV) or "").strip()
    if not raw:
        return {}
    try:
        text = raw if raw.startswith("{") else pathlib.Path(raw).read_text(encoding="utf-8")
        found = json.loads(text)
    except (OSError, ValueError) as e:
        log.info("%s unreadable: %s", ENV, str(e)[:80])
        return {}
    return {str(k): v for k, v in found.items() if v not in (None, "")} \
        if isinstance(found, dict) else {}


def _language():
    try:
        lang = locale.getlocale()[0]
    except ValueError:
        lang = None
    return lang or os.environ.get("LANG", "").split(".")[0]


def machine_context(now=None, environ=None, /, **extra):
    """The machine's date, time and language, then DATAGORA_CONTEXT, then
    `extra`, each over the one before. `now` and `environ` are positional
    only: a fact a page sends under either name is a fact, never a crash
    (review of 23 October)."""
    now = now or datetime.datetime.now().astimezone()
    if now.tzinfo is None:
        now = now.astimezone()
    minutes = int((now.utcoffset() or datetime.timedelta(0)).total_seconds() // 60)
    sign = "+" if minutes >= 0 else "-"
    minutes = abs(minutes)
    ctx = {"date": now.date().isoformat(), "time": now.strftime("%H:%M"),
           "weekday": WEEKDAYS[now.weekday()],
           "utc_offset": f"UTC{sign}{minutes // 60:02d}:{minutes % 60:02d}",
           "timezone": now.tzname() or "", "language": _language() or "",
           # the system the question is judged on, the server's; never the
           # machine's or the user's name, which have nothing to do in a prompt
           "server": f"{platform.system()} {platform.release()}".strip()}
    ctx.update(static_context(environ))
    ctx.update({str(k): v for k, v in extra.items() if v not in (None, "")})
    # the weekday follows the date in force, wherever it came from: the
    # asker's date with the server's weekday read "Saturday 23 October" for
    # a Friday, and a date pinned in DATAGORA_CONTEXT kept the machine's
    # (review of 26 October: "Monday 1 March 2025", a Saturday)
    try:
        ctx["weekday"] = WEEKDAYS[datetime.date.fromisoformat(str(ctx["date"])).weekday()]
    except ValueError:
        ctx.pop("weekday", None)
    return {k: v for k, v in ctx.items() if v not in (None, "")}


def resolve(context=None, now=None, environ=None):
    """The context of one question, as a dict.

    None: the machine's (and DATAGORA_CONTEXT). False: none. A dict: its
    facts over the machine's, so a server can send a user's own date and
    timezone. A callable: called, and its dict used the same way. A
    string: one free fact, kept under "about"."""
    if context is False:
        return {}
    if callable(context):
        context = context()
    if isinstance(context, str):
        context = {"about": context} if context.strip() else None
    if context is None:
        return machine_context(now, environ)
    if isinstance(context, dict):
        return machine_context(now, environ, **context)
    return machine_context(now, environ)


def moment(ctx):
    """The date and time of the question, from its context, or None."""
    try:
        day = datetime.date.fromisoformat(str((ctx or {}).get("date")))
    except ValueError:
        return None
    try:
        hour, minute = (int(x) for x in str(ctx.get("time") or "").split(":")[:2])
        return datetime.datetime(day.year, day.month, day.day, hour, minute)
    except (ValueError, TypeError):
        return datetime.datetime(day.year, day.month, day.day)


def today(ctx):
    """The date of the question, from its context, or the machine's."""
    try:
        return datetime.date.fromisoformat(str((ctx or {}).get("date")))
    except ValueError:
        return datetime.date.today()


EARLIER_CHARS = 900


def _clip(text, n):
    text = " ".join(str(text or "").split())
    return text if len(text) <= n else text[:n - 3].rstrip() + "..."


def earlier_note(question, verdict="", what="", offered=(), picked="", tables=(), before=""):
    """What was decided before this question, in a few lines: the question
    first asked, its verdict and what was open, what the asker was offered
    and picked, the tables found then. Asked again from zero, the follow-up
    of "What was our revenue last year?" explored for eight minutes what
    the first pass had found (E36, 23 October). The judge still checks the
    facts: the note says what was settled, never what to conclude."""
    if not str(question or "").strip():
        return ""
    # what must be said, then what may be, while it fits: cut at the end,
    # the pick and the rule went first (review of 23 October)
    head = [f"The asker first asked: \"{_clip(question, 180)}\"."]
    if verdict:
        what = str(what or "").strip().rstrip(".?!")
        head.append(f"It was judged {verdict}" + (f": {_clip(what, 150)}." if what else "."))
    tail = []
    if str(picked or "").strip():
        tail.append(f"They picked: \"{_clip(picked, 180)}\".")
    tail.append("What the asker settled is settled: judge what remains, from the facts, "
                "and do not ask again what they answered.")
    room = EARLIER_CHARS - len(" ".join(head + tail)) - 1
    extra = []
    shown = []
    for o in [_clip(o, 110) for o in offered or [] if str(o or "").strip()][:4]:
        said = "They were offered: " + "; ".join(f"\"{x}\"" for x in shown + [o]) + "."
        if len(said) + 1 > room:
            break
        shown.append(o)
    if shown:
        extra.append("They were offered: " + "; ".join(f"\"{x}\"" for x in shown) + ".")
        room -= len(extra[-1]) + 1
    # a stop that itself followed one: where the conversation began,
    # while it fits (review of 23 October: the first decision was lost)
    if str(before or "").strip():
        said = "Before that: " + _clip(before, 220)
        if len(said) + 1 <= room:
            extra.append(said)
            room -= len(said) + 1
    names = []
    for t in [_clip(t, 40) for t in tables or [] if t][:8]:
        if len("Tables found then: " + ", ".join(names + [t]) + ".") + 1 > room:
            break
        names.append(t)
    if names:
        extra.append("Tables found then: " + ", ".join(names) + ".")
    return _clip(" ".join(head + extra + tail), EARLIER_CHARS)


def describe(ctx):
    """The context as the sentences a model reads before the question, or
    "" when there is none."""
    if not ctx:
        return ""
    parts = []
    day = None
    try:
        day = datetime.date.fromisoformat(str(ctx.get("date")))
    except ValueError:
        pass
    if day:
        when = f"Asked on {ctx.get('weekday') or WEEKDAYS[day.weekday()]} {day.day} " \
               f"{MONTHS[day.month - 1]} {day.year}"
        if ctx.get("time"):
            when += f" at {ctx['time']}"
        zone = ", ".join(str(ctx[k]) for k in ("utc_offset",) if ctx.get(k))
        if ctx.get("timezone"):
            zone = f"{zone} ({ctx['timezone']})" if zone else str(ctx["timezone"])
        parts.append(when + (f", {zone}" if zone else "") + ".")
        # a vague period has no length to count: told it was counted from
        # today, the agent answered "recently" with a window of its own
        # (review of 26 October)
        parts.append(f"This year is {day.year}, last year was {day.year - 1}: a relative "
                     "period (last year, this month, now) is counted from this date; a "
                     "vague one (recently, lately) gives no length, which only the asker "
                     "knows.")
    for key, value in ctx.items():
        if key in _TIME_KEYS or value in (None, ""):
            continue
        name = key.replace("_", " ").strip().capitalize()
        parts.append(f"{name}: {value}.")
    return " ".join(parts)
