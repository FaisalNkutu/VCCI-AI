"""scripts/build_enterprise_questions.py and the answer key it writes.

No database: the committed key (scripts/enterprise_questions.json) holds
what the last run measured, so the generator can rebuild the file from it
and must give the same bytes. E01 to E40 must stay exactly as they were
verified on the 156 original tables (commit f193603); E41 to E70 must have
what their verdict needs; the question list for the coverage page must
say the same thing as the key. The checks that stop a write (a query
without rows, readings that coincide) run here on a fake connection."""

import os

os.environ["DATAGORA_TRACING"] = "off"
os.environ["DATAGORA_DOTENV"] = "off"

import csv
import hashlib
import importlib.util
import io
import json
import pathlib
import tempfile
import unittest
from unittest import mock

HERE = pathlib.Path(__file__).resolve().parent
REPO = HERE.parent.parent
SCRIPT = REPO / "scripts" / "build_enterprise_questions.py"
KEY = REPO / "scripts" / "enterprise_questions.json"
EXAMPLE_CSV = HERE / "examples" / "questions_enterprise.csv"
EXAMPLE_KB = HERE / "examples" / "kb_enterprise.json"

# sha256 of json.dumps({E01..E40}, indent=1, ensure_ascii=False) as committed at f193603
E01_E40_DIGEST = "3eeaa24cdc59821ddb6098e305509490733202f40eb823ff8071897ae8339320"
FRENCH = {"E48", "E58", "E61"}


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


gen = load(SCRIPT, "build_enterprise_questions_under_test")


def no_duplicate_keys(pairs):
    keys = [k for k, _ in pairs]
    dupes = sorted({k for k in keys if keys.count(k) > 1})
    if dupes:
        raise ValueError(f"duplicate keys: {dupes}")
    return dict(pairs)


class CommittedKey(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.text = KEY.read_text(encoding="utf-8")
        cls.doc = json.loads(cls.text, object_pairs_hook=no_duplicate_keys)
        cls.questions = cls.doc["questions"]
        cls.values = gen.recorded(cls.doc)

    def test_the_key_is_lf_and_ends_with_one_newline(self):
        raw = KEY.read_bytes()
        self.assertNotIn(b"\r", raw)
        self.assertTrue(raw.endswith(b"}\n") and not raw.endswith(b"\n\n"))

    def test_e01_to_e40_are_still_the_ones_verified_at_f193603(self):
        part = {k: v for k, v in self.questions.items() if int(k[1:]) <= 40}
        text = json.dumps(part, indent=1, ensure_ascii=False)
        self.assertEqual(hashlib.sha256(text.encode("utf-8")).hexdigest(), E01_E40_DIGEST)

    def test_the_generator_gives_e01_to_e40_byte_for_byte(self):
        for qid in [f"E{n:02d}" for n in range(1, 41)]:
            with self.subTest(qid):
                built = gen.fill(qid, gen.QUESTIONS[qid], self.values)
                self.assertEqual(json.dumps(built, indent=1, ensure_ascii=False),
                                 json.dumps(self.questions[qid], indent=1, ensure_ascii=False))

    def test_e19_keeps_its_credit_notes_and_e06_e29_e37_their_accepted_verdicts(self):
        self.assertIn("credit_notes", self.questions["E19"]["sql"])
        self.assertIn("credit_notes", self.questions["E19"]["needed_tables"])
        self.assertEqual(self.questions["E06"]["also_accepted"], ["NEEDS A CHOICE"])
        self.assertEqual(self.questions["E29"]["also_accepted"], ["NEEDS A CHOICE"])
        self.assertEqual(self.questions["E37"]["also_accepted"], ["ANSWERABLE"])

    def test_the_generator_renders_the_whole_file_byte_for_byte(self):
        document = gen.assemble(self.values, self.doc["verified_on"])
        self.assertEqual(gen.render(document), self.text)

    def test_ids_run_from_e01_to_e70_once_each(self):
        expected = [f"E{n:02d}" for n in range(1, 71)]
        self.assertEqual(list(self.questions), expected)
        self.assertEqual(list(gen.QUESTIONS), expected)

    def test_a_question_cannot_be_declared_twice(self):
        with mock.patch.dict(gen.QUESTIONS, {}, clear=True):
            gen.q("E99", theme="t")
            with self.assertRaises(ValueError):
                gen.q("E99", theme="t")

    def test_every_entry_has_what_its_verdict_needs(self):
        for qid, fields in self.questions.items():
            with self.subTest(qid):
                self.assertEqual(gen.problems_of_shape(qid, fields), [])
                self.assertEqual(gen.problems_of_shape(qid, gen.QUESTIONS[qid]), [])

    def test_every_count_was_measured(self):
        for qid, fields in self.questions.items():
            with self.subTest(qid):
                expected = fields["expected"]
                if "sql" in fields:
                    count = fields["verified_row_count"]
                    self.assertIsInstance(count, int)
                    if expected == "NO DATA":
                        self.assertEqual(count, 0)
                        self.assertTrue(fields["empty_ok"])
                    else:
                        self.assertGreater(count, 0)
                for name in ("readings", "coinciding_readings"):
                    for item in fields.get(name, []):
                        self.assertIsInstance(item["verified_row_count"], int)
                        self.assertGreater(item["verified_row_count"], 0)
                for item in fields.get("controls", []):
                    self.assertIsInstance(item["verified_result"], list)
                    self.assertTrue(item["verified_result"])
                    self.assertTrue(item["shows"])

    def test_the_new_questions_say_what_they_test(self):
        for qid in [f"E{n:02d}" for n in range(41, 71)]:
            with self.subTest(qid):
                fields = self.questions[qid]
                self.assertTrue(fields["grid"])
                self.assertTrue(fields["notes"])
                if fields["expected"] in ("NEEDS MORE", "NOT COVERED", "NO DATA"):
                    self.assertTrue(fields["controls"])

    def test_the_new_questions_cover_every_verdict(self):
        verdicts = {self.questions[f"E{n:02d}"]["expected"] for n in range(41, 71)}
        self.assertEqual(verdicts, set(gen.VERDICTS))

    def test_three_new_questions_are_in_french(self):
        for qid in FRENCH:
            self.assertIn("French", self.questions[qid]["grid"])
        self.assertEqual({qid for qid, x in self.questions.items() if "French" in x.get("grid", "")}, FRENCH)

    def test_needed_tables_are_in_the_example_dictionary(self):
        kb = json.loads(EXAMPLE_KB.read_text(encoding="utf-8"))
        for qid, fields in self.questions.items():
            with self.subTest(qid):
                for t in fields["needed_tables"] + fields.get("also_acceptable", []):
                    self.assertIn(t, kb)

    def test_periods_on_datetime_columns_are_closed_open(self):
        # E41 to E70 never bound a DATETIME with BETWEEN; the one BETWEEN is the control that shows the error
        for qid in [f"E{n:02d}" for n in range(41, 71)]:
            fields = self.questions[qid]
            sqls = [sql for _, sql in gen.slots(fields)]
            hits = [s for s in sqls if "BETWEEN" in s.upper()]
            self.assertEqual(hits, [] if qid != "E67" else [fields["controls"][0]["sql"]], qid)

    def test_the_conventions_give_the_reference_date(self):
        self.assertEqual(self.doc["reference_date"], "2026-09-30")
        self.assertIn("2026-09-30", self.doc["conventions"])
        self.assertEqual(self.doc["as_of"], "2026-10-09")


class QuestionList(unittest.TestCase):
    """src/graph_lab/examples/questions_enterprise.csv says what the key says."""

    @classmethod
    def setUpClass(cls):
        cls.doc = json.loads(KEY.read_text(encoding="utf-8"))
        cls.raw = EXAMPLE_CSV.read_bytes()

    def test_utf8_with_a_bom_and_crlf(self):
        self.assertTrue(self.raw.startswith(b"\xef\xbb\xbf"))
        self.assertEqual(self.raw.count(b"\n"), self.raw.count(b"\r\n"))

    def test_the_csv_matches_the_json(self):
        with io.StringIO(self.raw.decode("utf-8-sig"), newline="") as fh:
            rows = list(csv.DictReader(fh))
        self.assertEqual(list(rows[0]), gen.CSV_FIELDS)
        self.assertEqual([r["id"] for r in rows], list(self.doc["questions"]))
        for r in rows:
            q = self.doc["questions"][r["id"]]
            with self.subTest(r["id"]):
                self.assertEqual(r["question"], q["question"])
                self.assertEqual(r["difficulty"], q["difficulty"])
                self.assertEqual(r["real_verdict"], q["expected"])
                self.assertEqual(r["theme"], q["theme"])
                self.assertEqual([v.strip() for v in r["also_accepted"].split("|") if v.strip()],
                                 q.get("also_accepted", []))

    def test_the_generator_writes_these_bytes(self):
        self.assertEqual(gen.render_csv(self.doc).encode("utf-8"), self.raw)


class FakeConnection:
    """Answers the generator's queries from a function, no database."""

    def __init__(self, answer, tables):
        self.answer = answer
        self.tables = tables

    def cursor(self):
        return FakeCursor(self)

    def close(self):
        pass


class FakeCursor:
    def __init__(self, con):
        self.con = con
        self.rows = []

    def execute(self, sql, params=None):
        if sql == "SELECT DATABASE()":
            self.rows = [("fake_db",)]
        elif "information_schema.tables" in sql:
            self.rows = [(t,) for t in self.con.tables]
        else:
            self.rows = self.con.answer(sql)

    def fetchone(self):
        return self.rows[0]

    def fetchall(self):
        return list(self.rows)

    def close(self):
        pass


def one_choice(sql_a, sql_b):
    return {"E41": {"theme": "t", "difficulty": "simple", "expected": "NEEDS A CHOICE", "question": "q?",
                        "needed_tables": ["orders"],
                        "readings": [gen.reading("a", sql_a), gen.reading("b", sql_b)],
                        "grid": "g", "notes": "n"}}


class Refusals(unittest.TestCase):
    """What stops the generator from writing, checked on a fake connection."""

    def measure(self, questions, answer, tables=("orders",)):
        with mock.patch.object(gen, "QUESTIONS", questions):
            return gen.measure(FakeConnection(answer, tables), list(questions))

    def test_two_readings_with_the_same_rows_are_no_choice(self):
        questions = one_choice("SELECT 1 AS a", "SELECT 2 AS b")
        _, problems, _ = self.measure(questions, lambda sql: [("x", 1)])
        self.assertTrue(any("no choice" in p for p in problems), problems)
        values, problems, _ = self.measure(questions, lambda sql: [("x", 1)] if "1" in sql else [("x", 2)])
        self.assertEqual(problems, [])
        self.assertEqual(values[("E41", ("readings", 0))], 1)

    def test_e01_to_e40_keep_their_readings_and_only_get_a_note(self):
        questions = {"E37": dict(one_choice("SELECT 1 AS a", "SELECT 2 AS b")["E41"])}
        questions["E37"]["readings"].append(gen.reading("c", "SELECT 3 AS c"))
        _, problems, notes = self.measure(questions, lambda sql: [("x",)] if "3" not in sql else [("y",)])
        self.assertEqual(problems, [])
        self.assertEqual(notes, ["E37: readings 1 and 2 give the same rows"])

    def test_a_query_without_rows_stops_the_write_unless_empty_ok(self):
        questions = {"E41": {"theme": "t", "difficulty": "simple", "expected": "ANSWERABLE", "question": "q?",
                                 "needed_tables": ["orders"], "sql": "SELECT 1", "verified_row_count": gen.ROWS,
                                 "grid": "g", "notes": "n"}}
        _, problems, _ = self.measure(questions, lambda sql: [])
        self.assertEqual(problems, ["E41: no row"])
        questions["E41"].update(expected="NO DATA", empty_ok=True,
                                controls=[gen.control("the type exists", "SELECT COUNT(*) FROM orders")])
        values, problems, _ = self.measure(questions, lambda sql: [] if sql == "SELECT 1" else [(5,)])
        self.assertEqual(problems, [])
        self.assertEqual(values[("E41", ("sql",))], 0)
        self.assertEqual(values[("E41", ("controls", 0))], [["5"]])

    def test_a_coinciding_reading_must_give_the_rows_of_sql(self):
        questions = {"E41": {"theme": "t", "difficulty": "simple", "expected": "ANSWERABLE", "question": "q?",
                                 "needed_tables": ["orders"], "sql": "SELECT 1", "verified_row_count": gen.ROWS,
                                 "coinciding_readings": [gen.reading("other", "SELECT 2")], "grid": "g", "notes": "n"}}
        _, problems, _ = self.measure(questions, lambda sql: [(sql,)])
        self.assertEqual(problems, ["E41: coinciding reading 1 does not give the rows of sql"])

    def test_a_failing_query_and_an_unknown_table_stop_the_write(self):
        questions = {"E41": {"theme": "t", "difficulty": "simple", "expected": "ANSWERABLE", "question": "q?",
                                 "needed_tables": ["nowhere"], "sql": "SELECT 1", "verified_row_count": gen.ROWS,
                                 "grid": "g", "notes": "n"}}

        def fail(sql):
            raise RuntimeError("Unknown column")

        _, problems, _ = self.measure(questions, fail)
        self.assertIn("E41: table nowhere is not in fake_db", problems)
        self.assertIn("E41: RuntimeError: Unknown column", problems)

    def test_only_one_read_statement_is_run(self):
        for sql in ("DELETE FROM orders", "SELECT 1; DROP TABLE orders", "UPDATE orders SET a = 1"):
            with self.assertRaises(ValueError):
                gen.run(None, sql)

    def test_nothing_is_written_when_a_query_comes_back_empty(self):
        with tempfile.TemporaryDirectory() as tmp:
            key, example = pathlib.Path(tmp) / "key.json", pathlib.Path(tmp) / "list.csv"
            con = FakeConnection(lambda sql: [], set(json.loads(EXAMPLE_KB.read_text(encoding="utf-8"))))
            with mock.patch.object(gen, "KEY", key), mock.patch.object(gen, "EXAMPLE_CSV", example), \
                    mock.patch.object(gen, "connect", lambda database: con), \
                    mock.patch("sys.stdout", io.StringIO()):
                self.assertEqual(gen.main(["--database", "fake_db"]), 1)
            self.assertFalse(key.exists() or example.exists())

    def test_the_key_and_the_list_are_written_from_what_was_measured(self):
        # rows of the recorded sizes: readings of a choice differ, a coinciding
        # reading gives the rows of its sql, a control its recorded rows
        recorded = gen.recorded(json.loads(KEY.read_text(encoding="utf-8")))
        rows = {}
        for qid, fields in gen.QUESTIONS.items():
            for path, sql in gen.slots(fields):
                value = recorded[(qid, path)]
                if path[0] == "controls":
                    made = [tuple(r) for r in value]
                elif path[0] == "readings":
                    made = [(qid, path[1], n) for n in range(value)]
                else:
                    made = [(qid, n) for n in range(value)]
                self.assertEqual(rows.setdefault(sql, made), made, f"{qid} {path}: one sql, two results")
        with tempfile.TemporaryDirectory() as tmp:
            key, example, runs = (pathlib.Path(tmp) / n for n in ("key.json", "list.csv", "runs"))
            con = FakeConnection(lambda sql: rows[sql], set(json.loads(EXAMPLE_KB.read_text(encoding="utf-8"))))
            with mock.patch.object(gen, "KEY", key), mock.patch.object(gen, "EXAMPLE_CSV", example), \
                    mock.patch.object(gen, "connect", lambda database: con), \
                    mock.patch("sys.stdout", io.StringIO()):
                self.assertEqual(gen.main(["--database", "datagora_enterprise_next", "--runs-dir", str(runs)]), 0)
            self.assertEqual(key.read_bytes(), KEY.read_bytes())
            self.assertEqual(example.read_bytes(), EXAMPLE_CSV.read_bytes())
            self.assertEqual((runs / gen.RUNS_CSV).read_bytes(), EXAMPLE_CSV.read_bytes())

    def test_only_goes_with_check(self):
        with self.assertRaises(SystemExit):
            gen.main(["--only", "E01-E40"])

    def test_ids_are_selected_by_range_and_list(self):
        self.assertEqual(gen.select("E01-E03,E41"), ["E01", "E02", "E03", "E41"])
        self.assertEqual(gen.select(None), list(gen.QUESTIONS))
        with self.assertRaises(SystemExit):
            gen.select("E99")


if __name__ == "__main__":
    unittest.main()
