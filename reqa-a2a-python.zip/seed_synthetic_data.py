#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
seed_synthetic_data.py -- Generate FICTIONAL but integrity-preserving
seed data for a chosen set of tables (default: the Blue Entity tables
and their directly connected neighbours).

Why: several Blue/metrics tables are empty, so even a perfectly correct
SQL query returns 0 rows -- untestable end to end. Synthetic rows make
the pipeline's answers verifiable while remaining obviously fictional.

How integrity is preserved (all discovered live from information_schema,
nothing hard-coded):
  * ENUM columns   -> values picked from the column's DECLARED enum set;
  * FK columns     -> values sampled from EXISTING parent rows when the
                      parent table has data, else from rows this script
                      generated for the parent (parents are seeded first:
                      tables are topologically sorted by FK dependency);
  * NOT NULL       -> always filled; nullable non-FK columns sometimes
                      NULL for realism;
  * numeric PKs    -> allocated in a reserved high range (default
                      >= 900000) so they can never collide with real ids
                      and can be wiped with one DELETE per table;
  * self-referencing or unresolvable FKs -> NULL when nullable, row
                      skipped otherwise (reported, never guessed).

SAFETY MODEL -- review first, apply second:
  default        : writes seed_data.sql (INSERTs, FK order) and
                   seed_cleanup.sql (DELETEs, reverse order) for review
                   in SQLTools. Nothing touches the database.
  --apply        : executes the INSERTs in one transaction.
  Run against a COPY of the database if one is available.

Usage:
  python seed_synthetic_data.py --db root:pass@localhost:3306/calian
  python seed_synthetic_data.py --db ... --tables act,act_event,conn --rows 20
  python seed_synthetic_data.py --db ... --apply
Requires: pymysql (pip install pymysql).
"""

from __future__ import annotations

import argparse
import random
import re
import sys
from collections import defaultdict

# Blue Entities + their directly connected non-Blue tables
# (Blue_Entity_Connections.md, 2026-07-31).
DEFAULT_TABLES = [
    "act", "act_event", "act_loc_assoc", "act_oi_assoc", "act_ot_assoc",
    "act_stat", "act_task", "action_group", "blob_obj", "callsign",
    "comms_event", "comms_event_msg_type_assoc", "conn",
    "conn_mapper_assoc", "conn_param_assoc", "contxt_act_assoc",
    "data_flow_spec", "fire_event", "move_act_task", "msg_type",
    "rx_event", "scenario", "simulator_task", "simulator_task_event",
    "simulator_task_trigger", "tx_event",
]

ID_BASE = 900000          # reserved fictional-id range
FICTION_TAG = "SEED"      # every generated text value carries this marker

_NUM_TYPES = {"int", "integer", "bigint", "smallint", "mediumint",
              "tinyint", "decimal", "double", "float"}
_TEXT_TYPES = {"char", "varchar", "text", "tinytext", "mediumtext",
               "longtext"}
_TIME_TYPES = {"datetime", "timestamp", "date", "time"}


# ---------------------------------------------------------------------------
# JC3IEDM semantic overlay (Edition 3.1a; Annex C Attributes 3.1b,
# Annex E Domain Values 3.1b)
#
# Each rule constrains what the generic generator would produce, so the
# fictional data is DOCTRINALLY plausible, not just structurally valid.
# SAFETY PRINCIPLE: enum preferences are applied as an INTERSECTION with
# the column's DECLARED enum set -- if this overlay and the actual schema
# disagree, the schema wins and the rule silently degrades. The overlay
# can therefore never produce a value the database would reject.
#
# Rule forms (matched on column-name substring, then table when given):
#   {"prefer": [codes...]}          enum bias (Annex E domain values)
#   {"range": (lo, hi)}             numeric range (Annex C semantics)
#   {"pattern": "..."}              text pattern; {i}=row, {cs}=callsign
#   {"timeline": step_seconds}      monotonically increasing sim time
# ---------------------------------------------------------------------------

SEMANTICS = [
    # -- Hostility: Blue Entity seeds are FRIEND-side actors.
    #    Annex E: object-item-hostility-status-code (FR=Friend,
    #    AFR=Assumed Friend; HO=Hostile reserved for targets).
    {"column": "hostility", "prefer": ["FR", "AFR", "FRIEND"]},

    # -- ACTION category: seeded acts are ORDERS or EVENTS of an
    #    operation (Annex E: action-category-code).
    {"table": "act", "column": "cat_code",
     "prefer": ["ORD", "ORDER", "EVT", "ACTEV", "TASK", "ACTTA"]},

    # -- ACTION-RESOURCE association: 'RES' = resource employed by the
    #    action (Annex D: ACTION-RESOURCE relationship). Positive qty.
    {"table": "act_ot_assoc", "column": "cat_code", "prefer": ["RES"]},
    {"table": "act_ot_assoc", "column": "qty", "range": (1, 400)},
    {"table": "act_oi_assoc", "column": "cat_code", "prefer": ["RES"]},

    # -- ACTION-EVENT category: the operation's event mix
    #    (fire support + communications dominate a contact phase).
    {"table": "act_event", "column": "cat_code",
     "prefer": ["FIREEV", "COMMSEV", "SIMTASKEV", "OTHER"]},

    # -- ACTION-TASK progress (Annex C: completion-ratio 0..100,
    #    activity progresses through the timeline).
    {"column": "compl_rat", "range": (0, 100)},
    {"column": "progress_code", "prefer": ["NKN", "PLANND", "PREPAR",
                                           "EXECTG", "COMPLT"]},

    # -- Movement (Annex C: speed-rate in km/h for ground movement;
    #    dismounted 0-8, mounted up to ~60).
    {"column": "speed_rate", "range": (0, 60)},
    {"column": "brng_angle", "range": (0, 359)},
    {"column": "incl_angle", "range": (-10, 10)},

    # -- Geography: a compact fictional operations box (keeps every
    #    seeded position inside one plausible play area).
    {"column": "lat_coord", "range": (50.10, 50.45)},
    {"column": "long_coord", "range": (-4.60, -4.10)},
    {"column": "rep_lat", "range": (50.10, 50.45)},
    {"column": "rep_lon", "range": (-4.60, -4.10)},

    # -- Simulation timeline: sim offsets advance monotonically per
    #    table (10-minute steps), anchoring every seeded fact on ONE
    #    shared fictional operation window.
    {"column": "sim_offset_time", "timeline": 600},
    {"column": "sim_start_time", "timeline": 600},
    {"table": "act_stat", "column": "time", "timeline": 600},
    {"table": "obj_item_loc", "column": "time", "timeline": 600},

    # -- Reporting metadata (Annex E: reporting-data-category-code
    #    REP=reported; credibility RPTFCT=reported as fact).
    {"column": "credibility", "prefer": ["RPTFCT", "RPTPLA", "INDCTD"]},
    {"column": "source_type", "prefer": ["HUMINT", "OBSRVR", "SENSOR"]},

    # -- Communications naming (military callsign convention).
    {"table": "callsign", "column": "name", "pattern": "{cs}"},
    {"column": "callsign", "pattern": "{cs}"},

    # -- ACTION names: MIP/JC3IEDM exercise-scenario convention --
    #    task verb (Annex E: action-task-activity-code) + named
    #    objective / control measure, e.g. "SEIZE OBJECTIVE GOLD".
    {"table": "act", "column": "name_txt", "pattern": "SEED {task} {obj}"},
    {"table": "act_task", "column": "name_txt",
     "pattern": "SEED {task} {obj}"},

    # -- Names: keep the SEED marker but read like an exercise artifact.
    {"table": "scenario", "column": "name", "pattern": "SEED EX ABACUS {i}"},
    {"column": "descr_txt",
     "pattern": "SEED exercise record {i} (fictional, JC3IEDM 3.1 seed)"},
]

_CALLSIGNS = ["ALPHA 1-1", "ALPHA 1-2", "BRAVO 2-1", "BRAVO 2-2",
              "CHARLIE 3-1", "HAWK 6", "SABRE 1", "VIKING 2"]

# Task verbs drawn from the Annex E action-task-activity-code domain
# (ADVANC, ATTACK, DEFEND, DELAY, MOVE, OCCUPY, RECCE, RESUPL, SEIZE...),
# spelled out as scenario names are in MIP exercises.
_TASK_VERBS = ["ADVANCE TO", "ATTACK", "DEFEND", "DELAY AT", "MOVE TO",
               "OCCUPY", "RECCE", "RESUPPLY", "SEIZE", "SECURE",
               "PATROL", "SCREEN"]

# Named objectives / control measures, exercise-style (objectives,
# phase lines, assembly areas, engagement areas).
_OBJECTIVES = ["OBJECTIVE GOLD", "OBJECTIVE STEEL", "OBJECTIVE COPPER",
               "PL AMBER", "PL CRIMSON", "AA HAWK", "AA FALCON",
               "EA VIPER", "LOD RED", "CHECKPOINT 4"]


def _match_rule(table: str, col_name: str):
    """First overlay rule whose column substring (and table, if set)
    matches -- table-specific rules take precedence over generic ones."""
    hits = [r for r in SEMANTICS
            if r["column"] in col_name.lower()
            and (not r.get("table") or r["table"] == table.lower())]
    if not hits:
        return None
    hits.sort(key=lambda r: 0 if r.get("table") else 1)
    return hits[0]


def semantic_value(col: dict, table: str, rng, row_ix: int,
                   timeline_state: dict):
    """JC3IEDM-guided value, or None to fall back to the generic
    generator. Enum preferences intersect with the DECLARED enum set."""
    rule = _match_rule(table, col["name"])
    if rule is None:
        return None
    if "prefer" in rule:
        declared = enum_values(col["column_type"]) if col["data_type"] in (
            "enum", "set") else None
        if declared is not None:
            usable = [v for v in rule["prefer"] if v in declared]
            return rng.choice(usable) if usable else None  # schema wins
        if col["data_type"] in _TEXT_TYPES:
            return rng.choice(rule["prefer"])
        return None
    if "range" in rule and col["data_type"] in _NUM_TYPES:
        lo, hi = rule["range"]
        if col["data_type"] in ("decimal", "double", "float"):
            return round(rng.uniform(lo, hi), 4)
        return rng.randint(int(lo), int(hi))
    if "timeline" in rule and col["data_type"] in _NUM_TYPES:
        key = (table, col["name"])
        timeline_state[key] = timeline_state.get(key, 0) + rule["timeline"]
        return timeline_state[key]
    if "pattern" in rule and col["data_type"] in _TEXT_TYPES:
        text = rule["pattern"].format(
            i=row_ix, cs=rng.choice(_CALLSIGNS),
            task=rng.choice(_TASK_VERBS), obj=rng.choice(_OBJECTIVES))
        maxlen_m = re.search(r"\((\d+)\)", col["column_type"])
        return text[:int(maxlen_m.group(1))] if maxlen_m else text
    return None


# ---------------------------------------------------------------------------
# Introspection (pure read of information_schema)
# ---------------------------------------------------------------------------

def introspect(conn, db: str, tables: list) -> dict:
    """{table: {"columns": [colinfo...], "fks": {col: (ptable, pcol)}}}
    colinfo = {name, data_type, column_type, nullable, is_auto, key}."""
    cur = conn.cursor()
    schema: dict = {}
    fmt = ",".join(["%s"] * len(tables))
    cur.execute(
        f"SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, COLUMN_TYPE,"
        f" IS_NULLABLE, EXTRA, COLUMN_KEY"
        f" FROM information_schema.COLUMNS"
        f" WHERE TABLE_SCHEMA=%s AND TABLE_NAME IN ({fmt})"
        f" ORDER BY TABLE_NAME, ORDINAL_POSITION",
        [db] + tables)
    for t, c, dt, ct, nullable, extra, key in cur.fetchall():
        schema.setdefault(t, {"columns": [], "fks": {}})
        schema[t]["columns"].append({
            "name": c, "data_type": dt.lower(),
            "column_type": ct if isinstance(ct, str) else ct.decode(),
            "nullable": nullable == "YES",
            "is_auto": "auto_increment" in (extra or "").lower(),
            "key": key or ""})
    cur.execute(
        f"SELECT TABLE_NAME, COLUMN_NAME, REFERENCED_TABLE_NAME,"
        f" REFERENCED_COLUMN_NAME"
        f" FROM information_schema.KEY_COLUMN_USAGE"
        f" WHERE TABLE_SCHEMA=%s AND TABLE_NAME IN ({fmt})"
        f" AND REFERENCED_TABLE_NAME IS NOT NULL",
        [db] + tables)
    for t, c, pt, pc in cur.fetchall():
        if t in schema:
            schema[t]["fks"][c] = (pt, pc)
    return schema


def topo_order(schema: dict) -> list:
    """Tables sorted so that every FK parent (inside the set) comes first.
    Cycles/self-references break arbitrarily (handled via NULL later)."""
    deps = {t: {pt for (pt, _pc) in info["fks"].values()
                if pt in schema and pt != t}
            for t, info in schema.items()}
    order, placed = [], set()
    while len(order) < len(schema):
        progress = False
        for t in sorted(deps):
            if t not in placed and deps[t] <= placed:
                order.append(t); placed.add(t); progress = True
        if not progress:                      # cycle: place remaining as-is
            for t in sorted(deps):
                if t not in placed:
                    order.append(t); placed.add(t)
    return order


def sample_existing(conn, table: str, col: str, limit: int = 200) -> list:
    try:
        cur = conn.cursor()
        cur.execute(f"SELECT DISTINCT `{col}` FROM `{table}`"
                    f" WHERE `{col}` IS NOT NULL LIMIT {limit}")
        return [r[0] for r in cur.fetchall()]
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Value generation (deterministic: --seed)
# ---------------------------------------------------------------------------

def enum_values(column_type: str) -> list:
    return re.findall(r"'((?:[^'\\]|\\.)*)'", column_type)


def gen_value(col: dict, table: str, rng, row_ix: int):
    dt, ct = col["data_type"], col["column_type"]
    if dt == "enum" or dt == "set":
        vals = enum_values(ct)
        return rng.choice(vals) if vals else None
    if dt in _NUM_TYPES:
        if dt in ("decimal", "double", "float"):
            return round(rng.uniform(0, 500), 2)
        if "unsigned" in ct and dt == "tinyint":
            return rng.randint(0, 9)
        # plausible simulation quantities / offsets
        return rng.choice([0, rng.randint(1, 900), rng.randint(1000, 90000)])
    if dt in _TIME_TYPES:
        if dt == "date":
            return f"2026-07-{rng.randint(1, 28):02d}"
        if dt == "time":
            return f"{rng.randint(0, 23):02d}:{rng.randint(0, 59):02d}:00"
        return (f"2026-07-{rng.randint(1, 28):02d} "
                f"{rng.randint(0, 23):02d}:{rng.randint(0, 59):02d}:00")
    if dt in _TEXT_TYPES:
        maxlen = 60
        m = re.search(r"\((\d+)\)", ct)
        if m:
            maxlen = max(4, min(60, int(m.group(1))))
        base = f"{FICTION_TAG} {table} {row_ix}"
        return base[:maxlen]
    if dt == "blob" or "blob" in dt or dt == "binary" or "binary" in dt:
        return f"{FICTION_TAG}-BLOB"
    return None


def sql_literal(v) -> str:
    if v is None:
        return "NULL"
    if isinstance(v, (int, float)):
        return str(v)
    return "'" + str(v).replace("\\", "\\\\").replace("'", "''") + "'"


# ---------------------------------------------------------------------------
# Row generation with FK integrity
# ---------------------------------------------------------------------------

def generate(schema: dict, order: list, existing: dict, n_rows: int,
             rng) -> tuple:
    """Returns (inserts: [sql], cleanup: [sql], report: [str]).
    existing: {(table, col): [values]} sampled from the live DB."""
    made: dict = defaultdict(list)      # (table, col) -> generated values
    inserts, cleanup, report = [], [], []
    next_id = defaultdict(lambda: ID_BASE)
    timeline: dict = {}                 # shared fictional operation clock

    for t in order:
        info = schema[t]
        t_inserts = 0
        for i in range(1, n_rows + 1):
            row, ok = {}, True
            for col in info["columns"]:
                name = col["name"]
                fk = info["fks"].get(name)
                if fk:
                    pt, pc = fk
                    pool = (made.get((pt, pc))
                            or existing.get((pt, pc)) or [])
                    if pool:
                        row[name] = rng.choice(pool)
                    elif col["nullable"]:
                        row[name] = None
                    else:
                        report.append(
                            f"{t}: skipped (NOT NULL FK {name} -> "
                            f"{pt}.{pc} has no rows to reference)")
                        ok = False
                        break
                elif col["key"] == "PRI" and col["data_type"] in _NUM_TYPES:
                    next_id[t] += 1
                    row[name] = next_id[t]
                else:
                    # JC3IEDM overlay first (doctrine-guided); generic
                    # generator as fallback; occasional NULL only when
                    # no semantic rule claims the column.
                    sem = semantic_value(col, t, rng, i, timeline)
                    if sem is not None:
                        row[name] = sem
                    elif col["nullable"] and rng.random() < 0.15:
                        row[name] = None
                    else:
                        row[name] = gen_value(col, t, rng, i)
            if not ok:
                break                     # same cause for every row: stop
            cols = ", ".join(f"`{c}`" for c in row)
            vals = ", ".join(sql_literal(v) for v in row.values())
            inserts.append(f"INSERT INTO `{t}` ({cols}) VALUES ({vals});")
            t_inserts += 1
            for c, v in row.items():
                if v is not None:
                    made[(t, c)].append(v)
        if t_inserts:
            report.append(f"{t}: {t_inserts} row(s)")

    # cleanup: reverse FK order; fictional ids and the SEED text marker
    for t in reversed(order):
        pk = next((c["name"] for c in schema[t]["columns"]
                   if c["key"] == "PRI" and c["data_type"] in _NUM_TYPES),
                  None)
        if pk:
            cleanup.append(f"DELETE FROM `{t}` WHERE `{pk}` > {ID_BASE};")
        else:
            tcol = next((c["name"] for c in schema[t]["columns"]
                         if c["data_type"] in _TEXT_TYPES), None)
            if tcol:
                cleanup.append(f"DELETE FROM `{t}` WHERE `{tcol}` LIKE "
                               f"'{FICTION_TAG} %';")
    return inserts, cleanup, report


# ---------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(
        description="Schema-driven synthetic data generator "
                    "(review-first; --apply to execute).")
    ap.add_argument("--db", required=True,
                    help="user:password@host:port/database")
    ap.add_argument("--tables", default=",".join(DEFAULT_TABLES),
                    help="comma-separated table list (default: Blue set)")
    ap.add_argument("--rows", type=int, default=15,
                    help="rows to generate per table (default 15)")
    ap.add_argument("--seed", type=int, default=42,
                    help="random seed (reproducible output)")
    ap.add_argument("--apply", action="store_true",
                    help="execute the INSERTs (default: only write files)")
    args = ap.parse_args()

    m = re.match(r"([^:]+):([^@]*)@([^:/]+):?(\d+)?/(.+)", args.db)
    if not m:
        print("--db format: user:password@host:port/database",
              file=sys.stderr)
        return 2
    user, pwd, host, port, db = m.groups()
    import pymysql
    conn = pymysql.connect(host=host, port=int(port or 3306), user=user,
                           password=pwd, database=db)

    tables = [t.strip() for t in args.tables.split(",") if t.strip()]
    schema = introspect(conn, db, tables)
    missing = [t for t in tables if t not in schema]
    if missing:
        print(f"Not found in {db} (skipped): {', '.join(missing)}")
    order = topo_order(schema)
    print(f"FK-dependency order: {' -> '.join(order)}")

    # Sample existing parent values (covers FKs pointing OUTSIDE the set,
    # e.g. obj_item / obj_type parents that are already populated).
    existing: dict = {}
    for t, info in schema.items():
        for c, (pt, pc) in info["fks"].items():
            key = (pt, pc)
            if key not in existing:
                existing[key] = sample_existing(conn, pt, pc)

    rng = random.Random(args.seed)
    inserts, cleanup, report = generate(schema, order, existing,
                                        args.rows, rng)

    with open("seed_data.sql", "w", encoding="utf-8") as fh:
        fh.write("-- FICTIONAL seed data (marker: SEED / ids >= 900001)\n"
                 "-- Review before applying. Generated deterministically"
                 f" (seed={args.seed}).\nSTART TRANSACTION;\n")
        fh.write("\n".join(inserts))
        fh.write("\nCOMMIT;\n")
    with open("seed_cleanup.sql", "w", encoding="utf-8") as fh:
        fh.write("-- Removes ONLY the fictional rows (reverse FK order)\n"
                 "START TRANSACTION;\n" + "\n".join(cleanup) + "\nCOMMIT;\n")

    print("\n".join(report))
    print(f"\nWritten: seed_data.sql ({len(inserts)} INSERTs), "
          f"seed_cleanup.sql ({len(cleanup)} DELETEs)")

    if args.apply:
        cur = conn.cursor()
        try:
            for stmt in inserts:
                cur.execute(stmt)
            conn.commit()
            print(f"APPLIED: {len(inserts)} rows inserted.")
        except Exception as e:
            conn.rollback()
            print(f"ROLLED BACK on error: {e}", file=sys.stderr)
            return 1
    else:
        print("Nothing applied (review seed_data.sql, then re-run with "
              "--apply).")
    return 0


if __name__ == "__main__":
    sys.exit(main())