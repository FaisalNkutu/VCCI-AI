import sys
sys.path.insert(0, "/home/ali/Transfer/pipeline-reqa-sql-mcp")

from qdrant_client import QdrantClient
from agent.embedder import Embedder
from agent.schema_rag import SchemaRAG

client   = QdrantClient(host="localhost", port=6333)
embedder = Embedder()
rag      = SchemaRAG(client, embedder, "schema", top_k=2)

question = sys.argv[1] if len(sys.argv) > 1 else "Show the category code list of action"

# Tables retournées
payloads = rag.retrieve(question)
print(f"\n=== Tables retournées pour : '{question}' ===")
for i, p in enumerate(payloads, 1):
    print(f"  {i}. {p.get('table')} [{p.get('domain')}]")

# Contexte envoyé au LLM
print("\n=== Contexte KB envoyé au LLM ===")
print(rag.build_schema_context(payloads))