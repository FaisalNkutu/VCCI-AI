"""
Cross-encoder reranker nomic-ai/nomic-embed-text-v1.5.

Takes (question, list[RelevantTable]) and returns tables sorted by
cross-encoder score descending. The cross-encoder evaluates each
(question, table_text) pair jointly — more accurate than bi-encoder
cosine similarity for final ranking.
"""
from __future__ import annotations

import logging
from functools import lru_cache

from config.settings import get_settings

logger = logging.getLogger("RERANKER")

import os
os.environ["HF_HUB_OFFLINE"] = "1"

@lru_cache(maxsize=1)
def _get_reranker():
    from sentence_transformers import CrossEncoder
    settings = get_settings()
    return CrossEncoder(settings.reranker_model, local_files_only=True )


def _format_allowed_values(allowed, limit: int = 5) -> str:
    """
    allowed_values is a dict {code: meaning} in this project's KB schema
    (not a flat list). Handles both shapes defensively -- the previous
    version assumed a list and did `allowed[:5]`, which raises TypeError/
    KeyError on a dict (dicts don't support slicing). Since that call sits
    inside rerank_tables()'s broad try/except, the crash was silently
    swallowed on EVERY table with a populated allowed_values (i.e. most
    ENUM/category columns across the schema) -- the reranker fell back to
    "no reranking" permanently, with zero logging, despite USE_RERANKER
    appearing enabled. Verified end-to-end: this exact shape reproduces
    the crash and the silent fallback.
    """
    if isinstance(allowed, dict):
        items = list(allowed.items())[:limit]
        return ", ".join(f"{k}={v}" for k, v in items)
    if isinstance(allowed, (list, tuple)):
        return ", ".join(str(v) for v in list(allowed)[:limit])
    return ""


def _format_domain(domain) -> str:
    """domain is a list of tags in this project's KB schema, not a single
    string -- join it instead of interpolating the raw Python list repr
    (which used to literally send "Domain: ['Operations']" to the model)."""
    if isinstance(domain, list):
        return ", ".join(domain)
    return str(domain or "")


def _table_to_rerank_text(table) -> str:
    """
    Build a rich text representation of a table for the cross-encoder.
    Reads from table.payload (RetrievedTable dataclass).
    """
    payload = table.payload
    col_knowledge = payload.get("column_knowledge", {})

    parts = [
        f"Table: {table.table_name}",
        f"Domain: {_format_domain(payload.get('domain', ''))}",
        f"Description: {payload.get('description', '')}",
    ]

    # keywords (synonyms/alternate names for the table) is now a genuine
    # payload field (ingest.py). Previously absent from the payload
    # entirely -- the embedding step got it via a separate path
    # (kb_entry passed directly in ingest.py), but the reranker, which
    # only ever sees `payload`, had no way to know a table is "also known
    # as" something closer to the user's actual wording.
    keywords = payload.get("keywords", [])
    if keywords:
        parts.append("Also known as: " + ", ".join(keywords))

    for col in payload.get("columns", [])[:10]:
        col_name = col.get("name", "")
        col_kb = col_knowledge.get(col_name, {})
        desc = col_kb.get("description", "")
        allowed = col_kb.get("allowed_values", {})
        col_str = col_name
        if desc:
            col_str += f": {desc}"
        allowed_str = _format_allowed_values(allowed)
        if allowed_str:
            col_str += f" [{allowed_str}]"
        parts.append(col_str)

    # Related tables (from relationships) were never part of the rerank
    # text at all -- the cross-encoder judged a table purely on its own
    # columns/description/keywords, with no awareness of what it connects
    # to. This matters for relational questions like "What Porter Route
    # Porter Filter Association details are linked to each Porter Route?"
    # (a real stored sample_query), where knowing porter_route connects to
    # porter_route_porter_filter_assoc is itself a relevance signal.
    related = sorted({
        r["related_table"] for r in payload.get("relationships", [])
        if isinstance(r, dict) and r.get("related_table")
    })
    if related:
        parts.append("Related tables: " + ", ".join(related))

    # sample_queries is now a genuine payload field (ingest.py includes it
    # directly: doc["sample_queries"] = kbfull_entry.get("sample_queries",
    # [])) -- previously this looked for a "__sample_queries__" key inside
    # column_knowledge, which never existed anywhere in the pipeline and
    # was dead code (always empty). Read straight from `payload` now.
    kb_queries = payload.get("sample_queries", [])
    sample_questions = [
        q["question"] for q in kb_queries
        if isinstance(q, dict) and q.get("question")
    ]
    if sample_questions:
        parts.append("Sample questions: " + " | ".join(sample_questions[:3]))

    return ". ".join(parts)


def rerank_tables(
    question: str,
    tables: list,
    top_k: int,
) -> list:
    """
    Rerank tables using the cross-encoder and return top_k.
    Falls back to original order if the reranker is unavailable.
    """
    if not tables:
        return tables

    try:
        reranker = _get_reranker()
        texts    = [_table_to_rerank_text(t) for t in tables]
        pairs    = [(question, txt) for txt in texts]
        scores   = reranker.predict(pairs)

        ranked = sorted(
            zip(tables, scores),
            key=lambda x: x[1],
            reverse=True,
        )
        return [t for t, _ in ranked[:top_k]]

    except Exception as e:
        # Previously silent: a broken reranker (e.g. a payload shape
        # mismatch) looked identical to "reranker not installed" or
        # "USE_RERANKER=false", with no way to tell them apart from logs.
        # Now logged at warning level so a permanently-broken reranker is
        # actually discoverable, while still failing safe (falls back to
        # the pre-reranking candidate order rather than crashing the
        # request).
        logger.warning(f"rerank_tables() failed, falling back to original order: {e}")
        return tables[:top_k]
