

from enum import Enum


class AnswerabilityStatus(str, Enum):

    FULL = "FULL"

    PARTIAL_SCHEMA_LIMITATION = (
        "PARTIAL_SCHEMA_LIMITATION"
    )

    IMPOSSIBLE_SCHEMA_LIMITATION = (
        "IMPOSSIBLE_SCHEMA_LIMITATION"
    )



class SchemaLimitation(Exception):

    def __init__(
        self,
        message: str,
        missing_attributes=None,
    ):
        super().__init__(message)

        self.missing_attributes = (
            missing_attributes or []
        )


class GroundingViolation(Exception):
    pass




class PartialAnswerability(Exception):
    pass



class AnswerabilityIssue(Exception):
    pass