import threading

import pymysql
import pymysql.err


class DatabaseConnectionError(Exception):
    """
    Raised by explain() when EXPLAIN fails due to a genuine connection-
    level issue (server down, connection dropped, ...), as opposed to a
    content/schema error in the SQL itself (unknown column/table, syntax
    mistake -- the routine, expected outcome of validating LLM-generated
    SQL). Lets the caller (pipeline.py) distinguish "the LLM guessed a
    wrong column name, self-correctable via retry with error feedback"
    from "the database itself is unreachable, worth tripping the circuit
    breaker over" -- mirroring the same validation-vs-infrastructure
    distinction already made for SQL generation (see
    sql_generator.SQLValidationError).

    Previously, EVERY explain() failure -- including a plain "Unknown
    column" error, the single most common outcome when checking freshly
    LLM-generated SQL -- called self.cb.record_failure() in pipeline.py.
    A real deployment hit this directly: the circuit breaker opened after
    a single content error, short-circuiting the retry loop to just 1
    attempt instead of the intended 3, before the LLM ever got a chance
    to self-correct using the error feedback.
    """
    pass


# Error codes that genuinely indicate the connection itself is broken
# (dropped, timed out, server restarted mid-session, ...). Only these
# warrant discarding the cached connection and forcing a fresh reconnect
# on the next call. A syntax error or unknown-table/column error
# (ProgrammingError) says nothing about connection health and must NOT
# trigger a reconnect -- and unlike executor.py, THIS is the expected,
# common case here: EXPLAIN exists specifically to catch bad SQL from the
# LLM before real execution, so it will legitimately hit ProgrammingError
# on a large fraction of retries by design, not as a rare edge case.
_CONNECTION_LOST_CODES = {
    2002,  # Can't connect through socket
    2003,  # Can't connect to server
    2006,  # MySQL server has gone away
    2013,  # Lost connection to MySQL server during query
}


def _is_connection_lost(exc: Exception) -> bool:
    if not isinstance(exc, (pymysql.err.OperationalError, pymysql.err.InterfaceError)):
        return False
    code = exc.args[0] if exc.args else None
    return code in _CONNECTION_LOST_CODES


class DryRunner:
    """
    Step 5 — EXPLAIN dry-run against MariaDB.
    Validates query plan without reading or writing any data.
    Uses a thread-local persistent connection with auto-reconnect.
    """

    def __init__(self, db_params: dict):
        self._params = db_params
        # Per-instance threading.local(), not a shared module-level one
        # keyed by id(self). id() is the object's memory address in
        # CPython, which CAN be reused by a later, unrelated DryRunner
        # instance once the original is garbage-collected -- risking a
        # stale/foreign connection being picked up under a stale key. A
        # per-instance local avoids that class of bug entirely and is
        # simpler.
        self._local = threading.local()

    def _get_conn(self) -> pymysql.connections.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = pymysql.connect(**self._params)
            self._local.conn = conn
        else:
            try:
                conn.ping(reconnect=True)
            except Exception:
                conn = pymysql.connect(**self._params)
                self._local.conn = conn
        return conn

    def explain(self, sql: str) -> tuple[bool, str]:
        try:
            conn = self._get_conn()
            with conn.cursor() as cur:
                cur.execute(f"EXPLAIN {sql}")
                cur.fetchall()
            return True, ""
        except pymysql.Error as e:
            # Only drop the cached connection for genuine connection-loss
            # errors. A bad-SQL error (the expected, common outcome of an
            # EXPLAIN on LLM-generated SQL) leaves the connection perfectly
            # usable -- _get_conn()'s own ping(reconnect=True) check on the
            # *next* call already handles real connection health, making an
            # unconditional invalidation here both redundant (for real
            # drops) and actively harmful (wastes a full reconnect on
            # nearly every retry-due-to-bad-SQL cycle).
            if _is_connection_lost(e):
                self._local.conn = None
                raise DatabaseConnectionError(str(e)) from e
            # Content/schema error (unknown column, syntax mistake, ...) --
            # NOT raised, just returned as (False, msg), same as before.
            # This is the expected, self-correctable outcome most of the
            # time; it must never look like an infrastructure failure to
            # the caller.
            return False, str(e)
        except Exception as e:
            # Anything else unexpected here genuinely is an infra-level
            # surprise (not a pymysql.Error at all) -- raise, don't return
            # a silent (False, msg) for it.
            self._local.conn = None
            raise DatabaseConnectionError(str(e)) from e