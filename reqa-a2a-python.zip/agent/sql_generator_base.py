from agent.llm.base import BaseLLM

import json
import logging
import os
import re
import time

import logging
logging.basicConfig(level=logging.DEBUG,format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("SQL GEN BASE") 
from agent.llm.base import BaseLLM


class SQLValidationError(ValueError):
    """
    Raised by _validate_sql() when the LLM's output fails safety/format
    checks (forbidden keyword, not a SELECT, ...). Deliberately a distinct
    type from a generic Exception: this is a content-safety problem with
    what the LLM wrote, not an infrastructure failure (LLM API down,
    timeout, ...). The caller (pipeline.py) treats the two very
    differently -- a validation failure is expected, self-correctable
    behavior (like a static_check failure) and must NOT trip the circuit
    breaker, whereas a genuine API/infra exception should.
    """
    pass


class SQLGeneratorBase:
    def __init__(self, llm: BaseLLM = None, max_rows: int = 100):
        self.llm = llm
        self.max_rows = max_rows        
        self._system = "You are a SQL Generator"
        self.parent_pipeline = None

        logger.info(
            f"__init__() llm={llm}, "
            f"llm_class={llm.__class__.__name__}, "
            f"max_rows={max_rows}"
        )

    #
    #   set_parent_pipeline()
    #
    #   Sometimes it is useful to have access to the parent. 
    #   Use wisely. Currently for looking options in the request that influence the RAG
    #   
    #
    def set_parent_pipeline(self, pipe):
        self.parent_pipeline = pipe

    def _post_process_sql(
        self,
        generated_sql,
        validated_context,
    ):
        return generated_sql
       
 
    
    def generate(
        self,
        question: str,
        schema_context: str,
        all_tables: list[str],
        error_feedback: str = "",
        previous_sql: str = "",
        mandatory_tables=None,
        validated_context=None,
    ) -> str:
        
        generated_sql = "SELECT * from act LIMIT 20;"
        
        generated_sql = self._post_process_sql(generated_sql, validated_context)

        return generated_sql
    
    