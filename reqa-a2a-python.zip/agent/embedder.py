from fastembed import TextEmbedding
from pathlib import Path

import onnxruntime as ort
import os


def _lookup_model_dimension(model: str, fallback: int = 768) -> int:
    """
    Looks up the real embedding dimension for `model` from fastembed's own
    supported-models registry (list_supported_models() is a static lookup,
    no download required). Falls back to `fallback` only if the model
    isn't found there -- which will also fail loudly a moment later when
    TextEmbedding(model_name=...) itself rejects an unsupported name, so
    this is a safety net, not a silent guess.
    """
    for entry in TextEmbedding.list_supported_models():
        if entry.get("model") == model:
            dim = entry.get("dim")
            if isinstance(dim, int):
                return dim
    return fallback


class Embedder:
    """
    Local embedding model via fastembed (bundled with qdrant-client[fastembed]).
    No external API — uses GPU if CUDA is available, falls back to CPU otherwise.

    Default model: nomic-ai/nomic-embed-text-v1.5 (768 dims, ~130 MB)

    """

    # Class-level constant kept ONLY as the fallback for the default model,
    # so existing code referencing Embedder.DIMENSION before any instance
    # is constructed keeps working. Prefer instance.DIMENSION (set in
    # __init__ from the actual loaded model) wherever an instance exists.
    DIMENSION = 768

    def __init__(self, model: str = "nomic-ai/nomic-embed-text-v1.5"):
        available = ort.get_available_providers()
        providers = (
            ["CUDAExecutionProvider", "CPUExecutionProvider"]
            if "CUDAExecutionProvider" in available
            else ["CPUExecutionProvider"]
        )

        print(f"Embedder init model={model}" )
        print(f"Embedder init providers={providers}")
        hf_off = os.environ.get("HF_HUB_OFFLINE")
        print( f"HF_HUB_OFFLINE={hf_off}" )
        print(f"CWD={Path.cwd()}")

        self._model = TextEmbedding( model_name=model, providers=providers, cache_dir="./local_fastembed_cache" )


        # Resolve the REAL dimension for whatever model was actually
        # requested, rather than trusting the class-level default. Without
        # this, swapping to e.g. "nomic-ai/nomic-embed-text-v1.5" (768 dims) while
        # code elsewhere still reads the class constant Embedder.DIMENSION
  
        self.DIMENSION = _lookup_model_dimension(model, fallback=Embedder.DIMENSION)


    def embed(self, text: str) -> list[float]:
        return next(self._model.embed([text])).tolist()

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        return [v.tolist() for v in self._model.embed(texts)]
