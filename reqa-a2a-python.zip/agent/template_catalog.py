"""
Parametric (template) catalog (v1.0) -- generalizes the gold-query
catalog beyond exact phrasings: a question that matches a gold question's
STRUCTURE but differs in its ENTITIES (ids, names, quoted strings,
numbers) is answered by the gold SQL with the user's parameter values
substituted in -- still without any LLM call.

Why: the exact catalog (Jaccard >= 0.98 + identical numeric literals)
only fires on near-verbatim re-asks. Yet real question streams are full
of parameter variants -- "combat power of unit 1 IG BG HQ (ID: 1457)"
vs "... of unit 4 BDE 2 MERCIAN A COY 2 PL (ID: 1488)" -- same template,
different entities. Memorizing one gold query per template makes ALL its
variants deterministic: an LLM-free path is hallucination-free by
definition.

How (all deterministic, reusing agent/entity_extractor):
  1. SKELETONIZE both questions: extracted entities are replaced by
     typed slots ("<id>", "<name>", "<quoted>", "<num>");
  2. match skeletons (token Jaccard >= REQA_TEMPLATE_MIN_OVERLAP,
     default 0.90) AND require identical entity-type signatures
     (same count of ids, names, quoted strings, numbers);
  3. SUBSTITUTE the user's entity values into the gold SQL, by type, in
     order of appearance (longest values first; numbers replaced on word
     boundaries only);
  4. VERIFY the substitution: no gold-only entity value may survive in
     the produced SQL -- otherwise the match is abandoned.

The produced SQL then flows through the SAME downstream safety net as
any generated SQL (static check, guess/enum/contradiction guards,
EXPLAIN) -- the template path is a shortcut, never a bypass.

Fail-safe: any exception returns None and the pipeline generates
normally. Place this file at agent/template_catalog.py.
"""

from __future__ import annotations

import os
import re

try:
    from agent.entity_extractor import extract_entities
except Exception:                                   # standalone / test usage
    from entity_extractor import extract_entities


def _skeleton(question: str) -> tuple:
    """(skeleton_token_set, signature, entities) for a question.
    signature = (n_ids, n_designations, n_quoted, n_numbers)."""
    e = extract_entities(question)
    q = question or ""
    # Replace longest strings first so nested values cannot corrupt spans.
    repl = ([(v, " <id> ") for _l, v in e["ids"]]
            + [(d, " <name> ") for d in e["designations"]]
            + [(s, " <quoted> ") for s in e["quoted"]])
    for value, slot in sorted(repl, key=lambda x: -len(x[0])):
        q = q.replace(value, slot)
    # Any remaining standalone number is a generic numeric parameter
    # (thresholds, simulation times, limits) -- collected IN ORDER so it
    # can be substituted positionally.
    e["generic_nums"] = re.findall(r"\b\d+(?:\.\d+)?\b", q)
    q, n_num = re.subn(r"\b\d+(?:\.\d+)?\b", " <num> ", q)
    tokens = frozenset(re.findall(r"[a-z<>]+", q.lower())) - {""}
    sig = (len(e["ids"]), len(e["designations"]), len(e["quoted"]), n_num)
    return tokens, sig, e


def _jaccard(a: frozenset, b: frozenset) -> float:
    return len(a & b) / len(a | b) if (a or b) else 0.0


def _substitute(gold_sql: str, gold_e: dict, user_e: dict):
    """Gold SQL with user's entity values swapped in, or None when the
    substitution cannot be established safely (count mismatch, residue)."""
    sql = gold_sql
    pairs = []
    # ids and generic numbers (thresholds, times, limits): numeric
    # substitutions on word boundaries, paired in order of appearance.
    # generic_nums already contains simulation times (they are unmasked
    # numbers at skeleton time), so 'times' is NOT added separately.
    gold_nums = [v for _l, v in gold_e["ids"]] + gold_e.get("generic_nums", [])
    user_nums = [v for _l, v in user_e["ids"]] + user_e.get("generic_nums", [])
    if len(gold_nums) != len(user_nums):
        return None
    pairs += [(g, u, "num") for g, u in zip(gold_nums, user_nums)]
    # quoted strings and designations: string-literal substitutions.
    for key in ("quoted", "designations"):
        if len(gold_e[key]) != len(user_e[key]):
            return None
        pairs += [(g, u, "str") for g, u in zip(gold_e[key], user_e[key])]

    for g, u, kind in sorted(pairs, key=lambda p: -len(p[0])):
        if g == u:
            continue
        if kind == "num":
            sql, n = re.subn(rf"\b{re.escape(g)}\b", u, sql)
        else:
            sql, n = re.subn(re.escape(g), u.replace("\\", ""), sql)
        if n == 0:
            # The gold SQL never used this parameter (e.g. it filtered on
            # the id only, not the name): acceptable, keep going.
            continue
    # Verification: a DIFFERING gold value must not survive substitution.
    for g, u, kind in pairs:
        if g != u:
            pattern = rf"\b{re.escape(g)}\b" if kind == "num" else re.escape(g)
            if re.search(pattern, sql):
                return None
    return sql


def parametric_match(question: str, candidates: list) -> dict | None:
    """Best template match for `question` among gold candidates
    [{question, sql, table?}, ...]. Returns {sql, matched_question,
    overlap, table, substitutions} or None.

    Only candidates with a real SQL are considered; class/readonly
    filtering is the CALLER's responsibility (pipeline reuses the same
    POSITIVE + SELECT-only gate as the exact catalog)."""
    try:
        min_overlap = float(os.getenv("REQA_TEMPLATE_MIN_OVERLAP", "0.90"))
        u_tokens, u_sig, u_ents = _skeleton(question)
        if not u_tokens:
            return None
        best = None
        for cand in candidates or []:
            gq, gsql = cand.get("question") or "", cand.get("sql") or ""
            if not gq or not gsql:
                continue
            g_tokens, g_sig, g_ents = _skeleton(gq)
            if g_sig != u_sig:
                continue                    # different entity signature
            ov = _jaccard(u_tokens, g_tokens)
            if ov < min_overlap or (best and ov <= best["overlap"]):
                continue
            sql = _substitute(gsql, g_ents, u_ents)
            if sql is None:
                continue
            subs = {g: u for g, u in
                    list(zip([v for _l, v in g_ents["ids"]]
                             + g_ents.get("generic_nums", []),
                             [v for _l, v in u_ents["ids"]]
                             + u_ents.get("generic_nums", [])))
                    + list(zip(g_ents["quoted"], u_ents["quoted"]))
                    + list(zip(g_ents["designations"], u_ents["designations"]))
                    if g != u}
            best = {"sql": sql, "matched_question": gq, "overlap": ov,
                    "table": cand.get("table", ""), "substitutions": subs}
        return best
    except Exception:
        return None