import os
from fastembed import TextEmbedding

# 1. Force Hugging Face Hub to run in offline mode
os.environ["HF_HUB_OFFLINE"] = "1"

# 2. Specify the directory containing your pre-downloaded model files
cache_path = "./local_fastembed_cache"

# 3. Instantiate with local_files_only=True to prevent network checks
embedding_model = TextEmbedding(
    model_name="nomic-ai/nomic-embed-text-v1.5",
    cache_dir=cache_path,
    local_files_only=True
)

# 4. Generate embeddings completely offline
documents = ["search_document: Hello world, this is offline!"]
embeddings = list(embedding_model.embed(documents))