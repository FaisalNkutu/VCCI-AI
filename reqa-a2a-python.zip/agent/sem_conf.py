"""
Semantic-consistency confidence (sem_conf): does the generated SQL actually
answer the natural-language question?

Synonym-aware version: each aggregation intent is detected through a FAMILY
of phrasings (regex alternations), not a single hard-coded keyword -- so
"how many", "number of", "count of", "total number" all map to the same
COUNT intent; "most recent", "latest", "newest", "last recorded" all map to
the same recency intent; etc. Multiple intents in one question (e.g.
"average AND highest duration") are ALL checked, not just the first match.
"""
import re

# ---------------------------------------------------------------------------
# Intent families: (question-side synonym pattern, SQL-side satisfaction test)
#
# Question patterns are matched on the lowercased question; each entry lists
# the synonym phrasings observed in real sample_queries plus common natural
# variants. SQL tests receive the raw sql and its uppercased form.
# ---------------------------------------------------------------------------

_INTENT_FAMILIES = [
    # COUNT -- "how many", "number of", "count (of)", "total number".
    # NOTE: "total number of X" is a COUNT, but "total <quantity>" (total
    # duration, total qty) is a SUM -- the two patterns are kept mutually
    # exclusive: this one only fires on "total NUMBER", the SUM family
    # below fires on "total <anything-not-number>".
    (
        "count",
        r"\bhow\s+many\b|\bnumber\s+of\b|\bcount\s+(?:of|the)\b|\btotal\s+number\b|\bhow\s+much\b",
        lambda sql, s: "COUNT(" in s,
    ),
    # SUM -- fires ONLY on clearly measurable quantities ("total duration",
    # "sum of quantities", "cumulative time"), where SUM( is unambiguously
    # required. Deliberately NOT firing on "total <plural noun>" ("total
    # activities" -- that's a COUNT) nor on vague phrasings: a case left
    # neutral is safer than a case judged wrong.
    (
        "sum",
        r"\btotal\s+(?:duration|time|qty|quantity|quantities|amount|distance|length|weight|size)\b"
        r"|\bsum\s+of\b|\bcumulative\s+\w+\b|\bcombined\s+(?:duration|time|quantity|amount)\b",
        lambda sql, s: "SUM(" in s,
    ),
    # AVERAGE -- "average", "mean", "avg", "on average", "typical"
    (
        "average",
        r"\baverage\b|\bmean\b|\bavg\b|\bon\s+average\b|\btypical(?:ly)?\b",
        lambda sql, s: "AVG(" in s,
    ),
    # MAXIMUM -- "highest", "maximum", "max", "largest", "greatest", "biggest", "top", "longest"
    (
        "maximum",
        r"\bhighest\b|\bmaximum\b|\bmax\b|\blargest\b|\bgreatest\b|\bbiggest\b|\btop\b|\blongest\b|\bmost\s+(?!recent)\w+\b",
        lambda sql, s: "MAX(" in s or ("ORDER BY" in s and "DESC" in s and "LIMIT" in s),
    ),
    # MINIMUM -- "lowest", "minimum", "min", "smallest", "least", "shortest", "fewest"
    (
        "minimum",
        r"\blowest\b|\bminimum\b|\bmin\b|\bsmallest\b|\bleast\b|\bshortest\b|\bfewest\b",
        lambda sql, s: "MIN(" in s or ("ORDER BY" in s and "DESC" not in s and "LIMIT" in s),
    ),
    # RECENCY -- "most recent", "latest", "newest", "last (recorded/one)", "when did the last"
    (
        "recency",
        r"\bmost\s+recent(?:ly)?\b|\blatest\b|\bnewest\b|\blast\s+(?:recorded|one|entry|event|time)\b|\bwhen\s+did\s+the\s+(?:most\s+recent|last)\b",
        lambda sql, s: "MAX(" in s or ("ORDER BY" in s and "DESC" in s),
    ),
    # DURATION -- "how long", "duration", "lasted", "time taken/spent", "elapsed"
    (
        "duration",
        r"\bhow\s+long\b|\bduration\b|\blast(?:ed)?\b(?!\s+(?:recorded|one|entry|event|time))|\btime\s+(?:taken|spent)\b|\belapsed\b|\blength\s+of\s+time\b",
        lambda sql, s: (
            "DURATION" in s or "TIMEDIFF" in s or "DATEDIFF" in s or "TIMESTAMPDIFF" in s
            # arithmetic between two columns (end - start pattern): a minus
            # sign that isn't part of a comment "--"
            or bool(re.search(r"[\w)`]\s*-\s*[\w(`]", sql))
        ),
    ),
    # DISTINCT -- "different", "distinct", "unique", "how many kinds/types of"
    (
        "distinct",
        r"\bdistinct\b|\bdifferent\s+\w+s\b|\bunique\b|\bhow\s+many\s+(?:kinds|types)\b",
        lambda sql, s: "DISTINCT" in s or "GROUP BY" in s,
    ),
    # GROUPING -- "for each", "per", "by each", "grouped by". A plain
    # per-row SELECT already returns one row per entity, so "for each X"
    # is only BETRAYED when the SQL aggregates (AVG/MAX/MIN/SUM/COUNT)
    # WITHOUT a GROUP BY -- collapsing everything into a single row.
    (
        "grouping",
        r"\bfor\s+each\b|\bper\s+\w+\b|\bby\s+each\b|\bgrouped\s+by\b|\bbreak(?:down)?\s+by\b",
        lambda sql, s: not (
            re.search(r"\b(AVG|SUM|MAX|MIN|COUNT)\s*\(", s)
            and "GROUP BY" not in s
            and "PARTITION BY" not in s
        ),
    ),
]


def _compute_sem_conf(question: str, sql: str, target_tables) -> float:
    """
    Composite deterministic semantic score in [0, 1]:

      check 0        : the question's target table(s) actually appear in the
                       SQL (FROM/JOIN) -- word-boundary match, so `act` never
                       falsely matches inside `act_task`.
      checks 1..n    : ONE check per intent family DETECTED in the question
                       (synonym-aware regex), satisfied iff the SQL contains
                       the corresponding construct.

    All detected intents are checked (a question can carry several); the
    score is the fraction of satisfied checks. If no intent family matches
    and no target table is provided, returns 1.0 (neutral: nothing to
    verify deterministically).
    """
    checks: list[bool] = []
    q = (question or "").lower()
    s = (sql or "").upper()

    # -- check 0: target table presence (word-boundary, case-insensitive) --
    tables = [t for t in (target_tables or []) if t]
    if tables:
        checks.append(
            any(re.search(rf"\b{re.escape(t)}\b", sql or "", re.IGNORECASE) for t in tables)
        )

    # -- intent-family checks: every DETECTED intent must be satisfied --
    for _name, q_pattern, sql_test in _INTENT_FAMILIES:
        if re.search(q_pattern, q):
            checks.append(bool(sql_test(sql or "", s)))

    return round(sum(checks) / len(checks), 4) if checks else 1.0
