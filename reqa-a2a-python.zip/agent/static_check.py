import difflib
import re

import sqlglot
from sqlglot import exp


class StaticChecker:
    """
    Step 4 — Static syntax validation via sqlglot (no DB connection needed).
    Also enforces SELECT-only policy.
    """

    def check(
        self,
        sql: str,
        known_tables: set[str] | None = None,
        known_columns: dict[str, set[str]] | None = None,
    ) -> tuple[bool, str]:
        """
        known_tables: optional set of LOWERCASED existing table names. When
        provided, any table referenced in the SQL that isn't in this set
        fails validation immediately with an actionable message -- instead
        of waiting for MariaDB's EXPLAIN to reject it one step later.

        known_columns: optional mapping {lowercased table name -> set of
        lowercased column names}. When provided, qualified columns
        (t.col / alias.col) are validated against their table's real
        columns, and unqualified columns against the union of all queried
        tables' columns -- catching hallucinated column names (the
        dominant failure mode once table names are validated) before the
        EXPLAIN round-trip, with a feedback message that lists the REAL
        available columns.

        Backward compatible: without the arguments, behaviour is unchanged.

        Side outputs (reset on every call): when every unknown column had an
        unambiguous near-match, the corrected SQL is exposed in
        self.fixed_sql and the substitutions in self.autofix_notes.
        """
        self.fixed_sql = None
        self.autofix_notes = []
        if sql.upper().startswith("IMPOSSIBLE:"):
            return False, sql

        # Strip accidental markdown fences (```sql ... ``` or bare ```)
        # that some LLMs add. This specifically targets TRIPLE-backtick
        # fences, not a blind strip of any leading/trailing backtick --
        # a single/double backtick at the start or end of otherwise valid
        # SQL is very likely a legitimate MySQL identifier quote (e.g. a
        # query ending in "FROM `act`"), and blindly stripping it (the
        # previous .strip("`") did exactly that) corrupts the query and
        # makes it fail to parse. Verified: "SELECT * FROM `act`" used to
        # come out as "SELECT * FROM `act" (mismatched backtick) and fail
        # with a confusing parse error, even though the original SQL was
        # perfectly valid.
        cleaned = re.sub(r"```(?:sql)?\s*", "", sql.strip(), flags=re.IGNORECASE)
        cleaned = re.sub(r"```\s*$", "", cleaned).strip()

        try:
            stmts = sqlglot.parse(cleaned, dialect="mysql")
        except Exception as e:
            # sqlglot decorates its error messages with ANSI underline codes
            # (\x1b[4m ... \x1b[0m); left as-is they leak into the retry
            # feedback (confusing the LLM) and render as garbage in the UI.
            clean = re.sub(r"\x1b\[[0-9;]*m", "", str(e))
            return False, f"Parse error: {clean}"

        if not stmts or stmts[0] is None:
            return False, "Empty or unparseable SQL"

        # Reject anything that parses into more than one statement outright,
        # BEFORE checking the type of stmts[0]. This pipeline only ever
        # wants a single SELECT query -- a legitimate one should never
        # produce more than one parsed statement in the first place. Without
        # this check, a semicolon-separated payload like
        # "SELECT act_id FROM act; DROP TABLE act;" used to pass validation
        # entirely: stmts[0] is a harmless Select, so the old code returned
        # (True, "") without ever looking at stmts[1:] -- silently letting
        # a smuggled destructive statement through the one gate whose whole
        # job is to enforce "SELECT only". Verified with sqlglot: this
        # exact string parses into [Select, Drop], confirming the gap was
        # real, not theoretical.
        if len(stmts) > 1:
            return False, (
                f"Multiple SQL statements are not allowed "
                f"(found {len(stmts)}); only a single SELECT is permitted"
            )

        stmt = stmts[0]

        if not isinstance(stmt, exp.Select):
            kind = type(stmt).__name__
            return False, f"Only SELECT is allowed — got {kind}"

        # Validate table names against the known schema BEFORE the EXPLAIN
        # round-trip. Previously, a hallucinated placeholder like "table1"
        # was only caught by MariaDB itself ((1146, "Table 'calian.table1'
        # doesn't exist")) -- a wasted DB round-trip AND a vague feedback
        # message the LLM demonstrably fails to self-correct from (12 of
        # 21 quality failures in the blue-tables run were exactly this).
        # Catching it here fails faster and produces an actionable message
        # that names the offending table AND reminds the model where the
        # real table list lives.
        if known_tables:
            # CTE names are not physical tables -- exclude them from the
            # unknown-table check (and from column validation below) so a
            # legitimate WITH query isn't falsely rejected.
            cte_aliases = {
                c.alias.lower() for c in stmt.find_all(exp.CTE) if c.alias
            }
            used_tables = {
                t.name.strip() for t in stmt.find_all(exp.Table)  # [=JP=] strip spaces from table names
                if t.name and t.name.lower() not in cte_aliases 
            }
            unknown = sorted(
                t for t in used_tables
                if t.lower() not in known_tables and not "fire_event" in t.lower()  # [=JP=] TEMP FIX False negative on `fire_event` table
            )
            if unknown:
                return False, (
                    f"Unknown table(s): {', '.join(unknown)}. "
                    f"These do not exist in the database. Use ONLY table "
                    f"names from the AVAILABLE TABLES list (e.g. "
                    f"{', '.join(sorted(known_tables)[:5])}, ...). Never "
                    f"use placeholder names like table1 or main_table."
                )

        # Validate COLUMN names against the known schema, same rationale as
        # the table check above -- after eliminating hallucinated tables,
        # hallucinated columns became the dominant failure (42 of 60
        # quality failures in the follow-up run: plausible-but-wrong names
        # like "effective_time" instead of "effctv_time", "fe.latitude"
        # instead of "target_lat", "act.act_category" instead of
        # "cat_code"). MariaDB's (1054, "Unknown column ...") feedback
        # demonstrably doesn't help the model self-correct; naming the
        # REAL available columns of the exact table does.
        if known_columns:
            cte_aliases = {
                c.alias.lower() for c in stmt.find_all(exp.CTE) if c.alias
            }
            # alias -> physical table (skip CTE aliases: their columns are
            # derived, not physical, so we can't validate them here)
            alias_map = {}
            for t in stmt.find_all(exp.Table):
                if not t.name or t.name.lower() in cte_aliases:
                    continue
                alias_map[(t.alias or t.name).lower()] = t.name.lower()

            # SELECT ... AS x aliases are legal to reference in ORDER BY /
            # GROUP BY / HAVING -- they are not physical columns and must
            # never be flagged.
            select_aliases = {
                a.alias.lower() for a in stmt.find_all(exp.Alias) if a.alias
            }

            used_physical = set(alias_map.values())
            problems: list[tuple[str, str | None]] = []
            seen: set[tuple[str, str | None]] = set()

            for col in stmt.find_all(exp.Column):
                col_name = col.name
                # `alias.*` / `table.*` parses as an exp.Column wrapping a
                # Star (name '*') -- it selects ALL columns and is always
                # valid; flagging it as an unknown column '*' wrongly
                # rejected perfectly good JOIN queries in production (and
                # the UI's markdown even swallowed the asterisks, showing
                # a baffling "Column ''").
                if not col_name or col_name == "*" or isinstance(col.this, exp.Star):
                    continue
                cn = col_name.lower()
                qualifier = (col.table or "").lower()

                if qualifier:
                    phys = alias_map.get(qualifier)
                    # Unresolvable qualifier (e.g. CTE or subquery alias):
                    # skip -- we can only validate physical tables.
                    if phys and phys in known_columns and cn not in known_columns[phys]:
                        key = (col_name, phys)
                        if key not in seen:
                            seen.add(key)
                            problems.append(key)
                else:
                    if cn in select_aliases:
                        continue
                    # Unqualified column: only flag it when we know the
                    # column set of EVERY table in the query (otherwise we
                    # can't be sure it doesn't belong to the one we don't
                    # know) and it appears in none of them.
                    if used_physical and all(t in known_columns for t in used_physical):
                        if all(cn not in known_columns[t] for t in used_physical):
                            key = (col_name, None)
                            if key not in seen:
                                seen.add(key)
                                problems.append(key)

            if problems:
                # ── Auto-fix attempt ─────────────────────────────────────
                # A hallucinated column is usually a near-miss of a REAL
                # one (effective_time → effctv_time, both observed in
                # production). Instead of burning a whole retry on it,
                # rewrite the SQL in place when -- and only when -- the
                # match is unambiguous:
                #   * similarity to the best candidate >= 0.75, AND
                #   * the runner-up (if any) is clearly behind (>= 0.1 gap)
                # If EVERY unknown column has such a confident fix, the
                # corrected SQL is exposed via self.fixed_sql (with notes
                # in self.autofix_notes for XAI/logging) and validation
                # PASSES. Otherwise we still fail, but the message now
                # carries "did you mean ...?" hints per column -- much
                # stronger retry feedback than a bare list.
                def _candidates(cn: str, pool) -> list:
                    def _score(cand: str) -> float:
                        s = difflib.SequenceMatcher(None, cn, cand).ratio()
                        # Domain abbreviations defeat character-level ratios
                        # ('latitude' scores higher against 'duration' than
                        # against 'target_lat'!). Shared meaningful token
                        # fragment (>= 3 chars, e.g. 'lat') lifts the score
                        # to hint level (0.6) -- deliberately BELOW the 0.75
                        # auto-fix bar, since a token match alone is too
                        # ambiguous to rewrite silently.
                        for tok in cand.split("_"):
                            if len(tok) >= 3 and tok in cn:
                                s = max(s, 0.6)
                        return s
                    scored = sorted(((_score(k), k) for k in pool), reverse=True)
                    return scored[:2]

                fixes: dict[tuple, str] = {}
                hints: dict[tuple, str] = {}
                for col_name, phys in problems:
                    cn = col_name.lower()
                    pool = (known_columns.get(phys, set()) if phys
                            else set().union(*(known_columns[t] for t in used_physical
                                               if t in known_columns)) if used_physical else set())
                    if not pool:
                        continue
                    top = _candidates(cn, pool)
                    if top and top[0][0] >= 0.75 and (len(top) < 2 or top[0][0] - top[1][0] >= 0.1):
                        fixes[(col_name, phys)] = top[0][1]
                    elif top and top[0][0] >= 0.5:
                        hints[(col_name, phys)] = top[0][1]

                if len(fixes) == len(problems):
                    # every problem confidently fixable -> rewrite in place
                    rename = {cn.lower(): new for (cn, _), new in fixes.items()}
                    for col in stmt.find_all(exp.Column):
                        if col.name and col.name.lower() in rename:
                            col.set("this", exp.to_identifier(rename[col.name.lower()]))
                    self.fixed_sql = stmt.sql(dialect="mysql")
                    self.autofix_notes = [
                        f"'{cn}' → '{new}' (closest real column"
                        + (f" of {phys}" if phys else "") + ")"
                        for (cn, phys), new in fixes.items()
                    ]
                    return True, ""

                parts = []
                for col_name, phys in problems:
                    suggestion = fixes.get((col_name, phys)) or hints.get((col_name, phys))
                    did_you_mean = f" Did you mean '{suggestion}'?" if suggestion else ""
                    if phys:
                        avail = ", ".join(sorted(known_columns.get(phys, set()))[:12])
                        parts.append(
                            f"Column '{col_name}' does not exist on table "
                            f"'{phys}'.{did_you_mean} Available columns of {phys}: {avail}"
                        )
                    else:
                        tables_str = ", ".join(sorted(used_physical))
                        parts.append(
                            f"Column '{col_name}' does not exist on any of "
                            f"the queried tables ({tables_str}).{did_you_mean}"
                        )
                return False, (
                    "Unknown column(s). " + " | ".join(parts) +
                    " Use ONLY column names exactly as they appear in the "
                    "schema context (names are often abbreviated, e.g. "
                    "effctv_time not effective_time, cat_code not category)."
                )

        return True, ""
