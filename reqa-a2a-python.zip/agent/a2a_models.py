from __future__ import annotations
from enum import Enum
from typing import Any, Literal
from pydantic import BaseModel


class TaskState(str, Enum):
    SUBMITTED = "submitted"
    WORKING = "working"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELED = "canceled"


class TextPart(BaseModel):
    type: Literal["text"] = "text"
    text: str


class Message(BaseModel):
    role: Literal["user", "agent"]
    parts: list[TextPart]


class TaskStatus(BaseModel):
    state: TaskState


class Artifact(BaseModel):
    name: str | None = None
    parts: list[TextPart]
    metadata: dict[str, Any] | None = None


class Task(BaseModel):
    id: str
    status: TaskStatus
    artifacts: list[Artifact] | None = None
    metadata: dict[str, Any] | None = None


class TaskSendRequest(BaseModel):
    id: str
    message: Message
    metadata: dict[str, Any] | None = None


class AgentCapabilities(BaseModel):
    streaming: bool = False
    pushNotifications: bool = False


class AgentSkill(BaseModel):
    id: str
    name: str
    description: str | None = None
    tags: list[str] | None = None
    examples: list[str] | None = None
    inputModes: list[str] = ["text"]
    outputModes: list[str] = ["text"]


class AgentCard(BaseModel):
    name: str
    description: str | None = None
    url: str
    version: str
    capabilities: AgentCapabilities
    skills: list[AgentSkill]
