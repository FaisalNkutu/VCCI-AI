"""
Join-path discovery over the Neo4j schema graph (:Table / :FK layer built
by RAG/ingest_graph.py).

Purpose: the vector RAG finds the right TABLES but never the PATH between
them -- and multi-hop joins with invented join columns are the pipeline's
main remaining semantic failure (e.g. a real run joined act x fire_event
ON cat_code, two unrelated tables sharing a column name). This module
answers "how do these tables actually connect?" with the exact verified
join conditions, so the prompt can carry them.

Everything is FAIL-SAFE by design: Neo4j down, driver missing, env
disabled, table absent from the graph -- all degrade to "no hints"
(empty results), never to an error. The pipeline must work identically
with or without the graph.

Env:
    REQA_GRAPH=1                        enable/disable (default: enabled)
    NEO4J_URI=bolt://neo4j-server:7687  (container hostname on shared_network)
    NEO4J_USER=neo4j
    NEO4J_PASSWORD=secretpassword
"""
import logging
import os
from itertools import combinations

logger = logging.getLogger("GRAPH")

_driver = None
_driver_failed = False   # remember a failed connection: don't retry per question
_pair_cache: dict = {}


def _get_driver():
    global _driver, _driver_failed
    if _driver is not None or _driver_failed:
        return _driver
    if os.getenv("REQA_GRAPH", "1") != "1":
        _driver_failed = True
        return None
    try:
        from neo4j import GraphDatabase
        logger.warning(
            f"GRAPH_NEO4J_URI={os.getenv('NEO4J_URI')}"
        )
        
        logger.warning(
            f"GRAPH_NEO4J_URI={os.getenv('NEO4J_URI')}"
        )

        logger.warning(
            f"GRAPH_NEO4J_USER={os.getenv('NEO4J_USER')}"
        )
        
        _driver = GraphDatabase.driver(
            os.getenv("NEO4J_URI", "bolt://neo4j-server:7687"),
            auth=(os.getenv("NEO4J_USER", "neo4j"),
                  os.getenv("NEO4J_PASSWORD", "secretpassword")),
            connection_timeout=3,
        )
        _driver.verify_connectivity()
        logger.info("Neo4j schema graph connected")
    except Exception as e:
        logger.warning(f"Neo4j unavailable, join-path hints disabled: {str(e)[:120]}")
        _driver = None
        _driver_failed = True
    return _driver


def shortest_join_path(t1: str, t2: str, max_hops: int = 3) -> list:
    """
    Shortest FK path between two tables, as a list of hop dicts:
    [{"from": ..., "to": ..., "join_on": ...}, ...]. Empty list when no
    path within max_hops, table unknown, or graph unavailable.
    """
    key = (min(t1, t2), max(t1, t2), max_hops)
    if key in _pair_cache:
        return _pair_cache[key]

    driver = _get_driver()
    if driver is None or not t1 or not t2 or t1 == t2:
        return []

    result = []
    try:
        with driver.session() as session:
            rec = session.run(
                f"""
                MATCH p = shortestPath(
                    (a:Table {{name: $t1}})-[:FK*..{int(max_hops)}]-(b:Table {{name: $t2}})
                )
                RETURN [n IN nodes(p) | n.name] AS tables,
                       [r IN relationships(p) | r.join_sql] AS joins
                LIMIT 1
                """,
                t1=t1, t2=t2,
            ).single()
            if rec:
                tables, joins = rec["tables"], rec["joins"]
                result = [
                    {"from": tables[i], "to": tables[i + 1], "join_on": joins[i] or ""}
                    for i in range(len(joins))
                ]
    except Exception as e:
        logger.warning(f"join path query failed ({t1}<->{t2}): {str(e)[:100]}")
        result = []

    _pair_cache[key] = result
    return result


def join_path_hints(tables: list, max_hops: int = 3, max_pairs: int = 6) -> list:
    """
    Human/LLM-readable join hints for every pair of the given tables that
    is actually connected in the schema graph. Returns lines like:

        act -> act_loc_assoc -> loc:
            act_loc_assoc.act_id = act.act_id; loc.loc_id = act_loc_assoc.loc_id

    Capped at max_pairs pairs to keep the prompt lean.
    """
    names = [t for t in dict.fromkeys(tables or []) if t]  # dedupe, keep order
    hints = []
    for t1, t2 in combinations(names, 2):
        if len(hints) >= max_pairs:
            break
        path = shortest_join_path(t1, t2, max_hops=max_hops)
        if not path:
            continue
        chain = " -> ".join([path[0]["from"]] + [hop["to"] for hop in path])
        conds = "; ".join(hop["join_on"] for hop in path if hop["join_on"])
        hints.append(f"{chain}: {conds}" if conds else chain)
    return hints


def are_related(t1: str, t2: str, max_hops: int = 3) -> bool | None:
    """
    True/False when the graph could answer; None when the graph is
    unavailable (callers must treat None as 'unknown', NOT as False --
    a validation layer must never punish a query because the graph is
    down).
    """
    if _get_driver() is None:
        return None
    return bool(shortest_join_path(t1, t2, max_hops=max_hops))
