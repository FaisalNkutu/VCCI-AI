from __future__ import annotations

import json
import re

from agent.llm.base import BaseLLM

import json
from pathlib import Path

import json
import re
from functools import lru_cache
import json
import re
import logging
from pathlib import Path
from functools import lru_cache
from RAG.knowledge_base import load_kb
from datetime import UTC, datetime

logger = logging.getLogger(__name__)



_SYSTEM_PROMPT = """
You are a military intelligence data analyst assistant.

You will receive:
1. A user question
2. The SQL query that was executed
3. Query results

Your task:
- Write EXACTLY ONE concise sentence answering the user's question.
- Use ONLY information explicitly present in the provided results.
- Never invent entities, categories, statuses, locations, products, units, or values.
- Do not guess the meaning of columns.
- Do not mention information that does not appear in the results.
- Do not output bullet points.
- Do not output markdown.
- Do not output a table.
- If the results are empty, state that no results were found.
- Keep the answer under 30 words whenever possible.
"""



def _get_duration_unit(milliseconds):

    try:
        milliseconds = int(milliseconds)
    except (TypeError, ValueError):
        return "ms"

    total_seconds = milliseconds // 1000

    if total_seconds < 60:
        return "s"

    total_minutes = total_seconds // 60

    if total_minutes < 60:
        return "min"

    total_hours = total_minutes // 60

    if total_hours < 24:
        return "h"

    return "d"




def _format_duration(milliseconds):

    if milliseconds is None:
        return milliseconds

    try:
        milliseconds = int(milliseconds)
    except (TypeError, ValueError):
        return milliseconds

    total_seconds = milliseconds // 1000

    if total_seconds < 60:
        return f"{total_seconds}s"

    total_minutes = total_seconds // 60

    if total_minutes < 60:
        return f"{total_minutes}m"

    total_hours = total_minutes // 60

    if total_hours < 24:
        remaining_minutes = total_minutes % 60

        if remaining_minutes == 0:
            return f"{total_hours}h"

        return f"{total_hours}h {remaining_minutes}m"

    total_days = total_hours // 24
    remaining_hours = total_hours % 24

    if remaining_hours == 0:
        return f"{total_days}d"

    return f"{total_days}d {remaining_hours}h"



def _format_timestamp(milliseconds):

    if milliseconds is None:
        return milliseconds

    try:
        return datetime.fromtimestamp(
            int(milliseconds) / 1000,
            UTC
        ).strftime("%Y-%m-%d %H:%M:%S")
    except (TypeError, ValueError, OSError):
        return milliseconds
    

def _format_time_column(column_name,value):

    if value is None:
        return value

    column_name = column_name.lower()

    if "offset_time" in column_name  or "offset" in column_name:
        return _format_duration(value)

    if "time" in column_name:
        return _format_timestamp(value)

    return value


def apply_time_formatting(df):

    df = df.copy()

    renamed_columns = {}

    for column in df.columns:

        column_name = str(column).lower()

        if "time" not in column_name:
            continue

        df[column] = df[column].apply(
            lambda value: _format_time_column(
                column_name,
                value
            )
        )

        #
        # rename column to include unit
        #
        if "offset" in column_name:

            first_value = next(
                (
                    value
                    for value in df[column]
                    if value is not None
                ),
                None
            )

            unit = "ms"

            if first_value is not None:
                unit = _get_duration_unit(first_value)

            renamed_columns[column] = (
                f"{column} ({unit})"
            )

        else:

            renamed_columns[column] = (
                f"{column} (datetime)"
            )

    if renamed_columns:
        df = df.rename(
            columns=renamed_columns
        )

    return df


@lru_cache(maxsize=1)
def _load_kb():
    return load_kb()



def build_column_metadata(
    used_tables: list[str]
):

    kb = _load_kb()

    column_metadata = {}

    for table_name in used_tables:

        table_columns = (
            kb.get(table_name, {})
              .get("columns", {})
        )

        for column_name, metadata in table_columns.items():

            if column_name not in column_metadata:

                column_metadata[column_name] = {
                    "table": table_name,
                    **metadata
                }

    return column_metadata



@lru_cache(maxsize=1)
def _load_display_names():

    display_names_file = (
        Path(__file__).parent
        / "display_names.json"
    )

    if not display_names_file.exists():

        logger.warning(
            f"display_names.json not found: {display_names_file}"
        )

        return {}

    display_names = json.loads(
        display_names_file.read_text(
            encoding="utf-8"
        )
    )

    logger.info(
        f"display_names loaded: {len(display_names)} entries"
    )

    return display_names

def _humanize_header(
    header: str,
    column_metadata: dict | None = None
) -> str:
   

    # Fallback si aucune métadonnée disponible
    if not column_metadata:
        return (
            header
            .replace("_", " ")
            .title()
        )

    metadata = column_metadata.get(
        header,
        {}
    )

    description = metadata.get(
        "description",
        ""
    )

    if description:

        logger.info(
            f"MAPPED {header} -> "
            f"{description}"
        )

        return description

    logger.info(
        f"NO_MAPPING {header}"
    )

    return (
        header
        .replace("_", " ")
        .title()
    )

    
def apply_display_names(df):

    df = df.copy()

    df.columns = [
        _humanize_header(c)
        for c in df.columns
    ]

    return df

    
    
def _escape_markdown_cell(value: str) -> str:
    """
    Escape characters that would corrupt the markdown table structure if
    left as-is:
      - a literal "|" creates a phantom extra cell, misaligning the row
      - a literal newline splits one row into two raw lines of text,
        breaking the table structure entirely
    Both are realistic in this schema's free-text columns (e.g. descr_txt,
    det_txt), so this isn't a theoretical edge case.
    """
    return (
        value.replace("|", "/")
        .replace("\r\n", " ")
        .replace("\n", " ")
        .replace("\r", " ")
    )


def _to_markdown_table(rows: list[dict]) -> str:
   
    if not rows:
        return ""

    raw_headers = list(rows[0].keys())
    display_headers = [_humanize_header(h) for h in raw_headers]

    lines = [
        "| " + " | ".join(display_headers) + " |",
        "| " + " | ".join("---" for _ in display_headers) + " |",
    ]

    for row in rows:
        lines.append(
            "| "
            + " | ".join(
                _escape_markdown_cell(str(row.get(col, "")))
                for col in raw_headers
            )
            + " |"
        )

    return "\n".join(lines)


class Renderer:
   
    MAX_ROWS_FOR_LLM = 50

    def __init__(self, llm: BaseLLM):
        self.llm = llm
        self.parent_pipeline = None


    #
    #   set_parent_pipeline()
    #
    #   Sometimes it is useful to have access to the parent. 
    #   Use wisely. Currently for looking options in the request that influence the RAG
    #   
    #
    def set_parent_pipeline(self, pipe):
        self.parent_pipeline = pipe


    def _build_prompt(
        self,
        question: str,
        sql: str,
        rows: list[dict],
    ) -> str:
        """
        Build compact context for the LLM.
        """

        sample_rows = rows[: self.MAX_ROWS_FOR_LLM]

        rows_json = json.dumps(
            sample_rows,
            ensure_ascii=False,
            default=str,
            indent=2,
        )

        truncation_note = ""

        if len(rows) > self.MAX_ROWS_FOR_LLM:
            truncation_note = (
                f"\nOnly the first {self.MAX_ROWS_FOR_LLM} rows "
                f"out of {len(rows)} are shown.\n"
            )

        return (
            f"Question:\n{question}\n\n"
            f"SQL:\n{sql}\n\n"
            f"Returned rows: {len(rows)}\n"
            f"{truncation_note}\n"
            f"Data:\n{rows_json}"
        )

    @staticmethod
    def _sanitize_summary(text: str) -> str:
        """
        Force a single clean sentence.

        Finds the EARLIEST sentence-ending punctuation in the (whitespace-
        normalized) text, regardless of which mark it is (., !, ?), and
        cuts there. The previous version checked separators in a fixed
        priority order ([". ", "!\\n", "?\\n", "\\n"]) and used whichever
        matched first in that list -- not whichever occurred earliest in
        the actual text -- so a "!" or "?" ending sentence followed later
        by a "." would get silently stitched onto the kept text. It also
        normalized whitespace (collapsing newlines to spaces) BEFORE
        checking for "!\\n"/"?\\n"/"\\n", which meant those three checks
        could never actually match anything; only ". " ever did.
        """

        if not text:
            return "Results returned successfully."

        text = text.strip()

        # Remove line breaks
        text = " ".join(text.split())

        cut_at = len(text)
        for separator in (". ", "! ", "? "):
            idx = text.find(separator)
            if idx != -1:
                cut_at = min(cut_at, idx + 1)  # keep the punctuation mark itself
        text = text[:cut_at].strip()

        if not text or text[-1] not in ".!?":
            text += "."

        return text

    def render(
        self,
        question: str,
        sql: str,
        rows: list[dict],
    ) -> str:
        """
        Generate final user-facing output.
        """

        if not rows:
            return "No results found."

        table = _to_markdown_table(rows)

        prompt = self._build_prompt(
            question=question,
            sql=sql,
            rows=rows,
        )

        try:
            self.parent_pipeline.set_langfuse_trace_step("RENDER")
            summary = self.llm.complete(
                system_prompt=_SYSTEM_PROMPT,
                messages=[
                    {
                        "role": "user",
                        "content": prompt,
                    }
                ],
                max_tokens=512,
            )

            summary = self._sanitize_summary(summary)

        except Exception:
            summary = f"The query returned {len(rows)} row(s)."

        return f"{summary}\n\n{table}"