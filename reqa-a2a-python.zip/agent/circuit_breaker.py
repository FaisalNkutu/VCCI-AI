import threading
import time


class CircuitBreaker:
    """
    Thread-safe counter-based circuit breaker with automatic recovery
    (classic Closed / Open / Half-Open state machine).

    - CLOSED (normal): failures are tracked; is_open() returns False,
      callers proceed normally.
    - OPEN: `threshold` consecutive failures were reached. is_open()
      returns True and callers should skip the operation entirely --
      UNTIL `recovery_timeout` seconds have elapsed since the breaker
      tripped.
    - HALF-OPEN: once the cooldown has elapsed, the NEXT call to
      is_open() returns False exactly once, letting a single "trial"
      request through to test whether the underlying problem has
      resolved:
        * record_success() on that trial fully closes the breaker
          (failure count reset to 0).
        * record_failure() re-opens it and restarts the cooldown timer,
          so it waits another `recovery_timeout` before trying again.

    Without this, a purely counter-based breaker that never times out
    turns any transient outage (a brief LLM API blip, a momentary DB
    restart) into a PERMANENT one: once tripped, callers typically
    short-circuit at the very top of their request-handling code before
    ever reaching the call that could record a success again -- so
    nothing would ever un-trip it without a manual `.reset()` or a full
    process restart. Verified end-to-end against this codebase's actual
    usage (pipeline.py checks `cb.is_open()` as the very first thing in
    `run()` and returns immediately if True): once open, record_success()
    was provably unreachable ever again.
    """

    def __init__(self, threshold: int = 3, recovery_timeout: float = 30.0):
        if threshold < 1:
            raise ValueError("threshold must be >= 1")
        if recovery_timeout < 0:
            raise ValueError("recovery_timeout must be >= 0")

        self.threshold = threshold
        self.recovery_timeout = recovery_timeout
        self._failures = 0
        self._opened_at: float | None = None
        self._trial_in_flight = False
        self._lock = threading.Lock()

    def record_failure(self) -> None:
        with self._lock:
            self._failures += 1
            self._trial_in_flight = False
            if self._failures >= self.threshold:
                # Trips the breaker (first time reaching threshold), or
                # -- if this failure came from a half-open trial request --
                # re-opens it and restarts the cooldown from now.
                self._opened_at = time.monotonic()

    def record_success(self) -> None:
        with self._lock:
            self._failures = 0
            self._opened_at = None
            self._trial_in_flight = False

    def is_open(self) -> bool:
        with self._lock:
            if self._failures < self.threshold:
                return False

            elapsed = time.monotonic() - self._opened_at if self._opened_at is not None else 0.0

            if elapsed >= self.recovery_timeout and not self._trial_in_flight:
                # Cooldown has elapsed: let exactly one trial request
                # through (report "not open" once) to test recovery.
                # Other concurrent callers keep seeing it as open until
                # this trial resolves via record_success()/record_failure().
                self._trial_in_flight = True
                return False

            return True

    def reset(self) -> None:
        with self._lock:
            self._failures = 0
            self._opened_at = None
            self._trial_in_flight = False