
import sys
import argparse
import uuid
from pathlib import Path
from datetime import datetime
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct, PointIdsList, PayloadSchemaType
from qdrant_client.models import Filter, FieldCondition, MatchValue, Range
from config.settings import get_settings

settings = get_settings()
from agent.embedder import Embedder
import json

import traceback
from sqlglot import parse_one, exp, ErrorLevel 
from RAG.knowledge_base import get_all_table_names
from RAG.knowledge_base import is_excluded_table






class RatedRulesRAG():
    CATEGORY_FILTER = "rated_rules"
    QUESTIONS_EXCELL_FILE_SOURCE= "RAG/rated_rules.csv"
    
    def __init__(self, client, embedder):
        # life long members
        self.client = client
        self.embedder = embedder

        # members that must be reset between queries
        self.result_hits = []
     

    #
    #   for every new query, this must be reset
    #
    def reset(self):
        self.result_hits = []

    @staticmethod
    def _point_id(table_name: str) -> str:
        return str(uuid.uuid5(uuid.NAMESPACE_DNS, f"rated_rules-node:{table_name}"))
    
                

    def query(self, query, min_rating = 1,  limit = 5):

        print("\n\n=*=*=*=*=*=*=*=*=*=*=*=  RR QUERY n=*=*=*=*=*=*=*=*=*=*=*= \n")
        print(f"{query}")

        vector = self.embedder.embed(query)
        results = self.client.query_points(
                collection_name=settings.QDRANT_COLLECTION,
                query=vector,
                query_filter=Filter(
                    must=[
                    FieldCondition(
                        key="category",
                        match=MatchValue(value=RatedRulesRAG.CATEGORY_FILTER)
                    ),
                    FieldCondition(
                            key="rating",
                            range=Range(gt=min_rating),  # Use gte=100 for greater than or equal to
                        )
                ]
            ),
                limit=limit,
                with_payload=True,
            )

        print(f"{results}")
        hits = []
        for rank, point in enumerate(results.points, start=1):
            payload = point.payload    
            hits.append(
                    (                   
                        payload,
                        rank,
                        float(point.score),
                    )
                )

        self.result_hits = hits
        return self.result_hits


    def get_result_hits(self):        
        return self.result_hits
   

    @staticmethod
    def delete_all( client : QdrantClient):
      
        client.delete(
            collection_name=settings.QDRANT_COLLECTION,
            points_selector=Filter(
                must=[
                    FieldCondition(
                        key="category",
                        match=MatchValue(value=RatedRulesRAG.CATEGORY_FILTER)
                    )   
                ]
            ),
            # Optional: wait=True blocks until the delete operation is written to the WAL
            wait=True   )
    

    @staticmethod
    def ingest_rule( client : QdrantClient, entry : dict ):

        print("\n\n=*=*=*=*=*=*=*=*=*=*=*=  RR INGEST RULE =*=*=*=*=*=*=*=*=*=*=*= \n")
        print(f"{entry}")
        stats={}
        embedder = Embedder()    
        points = []                    
      
        stats["messages"] = []

        
        try:
            grembed = entry["Q"]
            print(f"Adding Rule: {grembed}")
            grpayload = entry
                        
            print(f"[ingest rule] EMBED= {grembed}" )
            print(f"[ingest rule] PAYLOAD={grpayload}" )
            vector = embedder.embed(grembed)    
            point_id = RatedRulesRAG._point_id(grpayload)
            grpayload["category"] = RatedRulesRAG.CATEGORY_FILTER
            points.append(PointStruct(id=point_id, vector=vector, payload=grpayload))            
        except:
            print(f"Warning: Skip Embedding {grembed}");
            traceback.print_exc()
        
        if len(points) > 0:
            client.upsert(collection_name=settings.QDRANT_COLLECTION, points=points)                    
            #   Export the list of all the questions of all rated_rules                        
        else:
            print("Nothing to upsert for rated_rules.")

        return stats
        
      
        

       
