from agent.llm.base import BaseLLM

import json
import logging
import os
import re
import time


class SQLValidationError(ValueError):
    """
    Raised by _validate_sql() when the LLM's output fails safety/format
    checks (forbidden keyword, not a SELECT, ...). Deliberately a distinct
    type from a generic Exception: this is a content-safety problem with
    what the LLM wrote, not an infrastructure failure (LLM API down,
    timeout, ...). The caller (pipeline.py) treats the two very
    differently -- a validation failure is expected, self-correctable
    behavior (like a static_check failure) and must NOT trip the circuit
    breaker, whereas a genuine API/infra exception should.
    """
    pass

# ---------------------------------------------------------------------------
# Domain glossary — maps terms users are likely to type to the canonical
# term actually used in the schema/data. Extend this dict as needed.
# Key = term the user may use, Value = canonical schema term.
# ---------------------------------------------------------------------------

def _load_domain_synonyms() -> "dict[str, str]":
    """v3.3 -- the glossary is now EXTENSIBLE without a code change.

    Merge order: built-in defaults, then domain_synonyms.json (first path
    found wins). Add domain terms your users actually type ("platoon",
    "material expenditure", ...) mapped to the canonical schema token, and
    the rewrite happens BEFORE retrieval -- the single highest-leverage
    way to make a recurring question unambiguous. Keys starting with "_"
    are ignored (usable as comments). Import-safe: a missing or invalid
    file leaves the defaults untouched.
    """
    synonyms = {
        "action": "activity",
        "actions": "activities",
    }
    candidates = [
        os.getenv("REQA_DOMAIN_SYNONYMS", ""),
        os.path.join(os.path.dirname(__file__), "domain_synonyms.json"),
        os.path.join(os.path.dirname(__file__), "..", "RAG", "domain_synonyms.json"),
        "RAG/domain_synonyms.json",
        "domain_synonyms.json",
    ]
    for path in candidates:
        if not path:
            continue
        try:
            with open(path, encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, dict) and data:
                synonyms.update({
                    str(k).lower(): str(v)
                    for k, v in data.items() if not str(k).startswith("_")
                })
                break
        except Exception:
            continue
    return synonyms


DOMAIN_SYNONYMS: dict[str, str] = _load_domain_synonyms()

# ---------------------------------------------------------------------------
# Entity → real table name map (KB v2 naturalised display names).
#
# The v2 KB renamed sample questions to natural language ("Absolute Point",
# "Aircraft Type", "Organisation" ...) instead of raw identifiers
# (abs_point, acft_type, org). Because _apply_domain_synonyms() runs BEFORE
# schema retrieval in pipeline.run(), a naturalised entity name that never
# maps back to its table means the RAG step searches with "Absolute Point",
# fails to retrieve abs_point, and the LLM then answers over a DIFFERENT
# table that merely happens to share a column (cat_code) -- the observed
# "How many Absolute Point records per category?" -> "FROM fac GROUP BY
# cat_code" wrong-table failure.
#
# Loaded import-safe from entity_table_map.json (generated from the schema's
# table names). If the file is absent or unreadable, the map is simply empty
# and behaviour is identical to before -- this must NEVER break the import.
# Override the path with REQA_ENTITY_TABLE_MAP.
# ---------------------------------------------------------------------------

def _load_entity_table_map() -> "dict[str, str]":
    candidates = [
        os.getenv("REQA_ENTITY_TABLE_MAP", ""),
        os.path.join(os.path.dirname(__file__), "entity_table_map.json"),
        os.path.join(os.path.dirname(__file__), "..", "RAG", "entity_table_map.json"),
        "RAG/entity_table_map.json",
        "entity_table_map.json",
    ]
    for path in candidates:
        if not path:
            continue
        try:
            with open(path, encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, dict) and data:
                return {str(k).lower(): str(v) for k, v in data.items()}
        except Exception:
            continue
    return {}


ENTITY_TABLE_MAP: dict[str, str] = _load_entity_table_map()
# Longest display names first so "Activity Location Association" is rewritten
# before the shorter "Activity" it contains.
_ENTITY_KEYS_SORTED = sorted(ENTITY_TABLE_MAP, key=len, reverse=True)

# ---------------------------------------------------------------------------
# SQL generation system prompt (unchanged rules, kept as the final guardrail)
# ---------------------------------------------------------------------------

_SYSTEM = """
You are an expert SQL engineer specialized in MariaDB and military/defence databases.

The schema context you receive contains:
  • Annotated DDL
  • Column descriptions
  • Foreign key relationships
  • Business rules
  • Suggested JOIN paths

STRICT RULES:
1. Output ONLY the raw SQL query.
2. Never output markdown fences.
3. Never output explanations.
4. READ ONLY: only SELECT statements.
5. Never use INSERT, UPDATE, DELETE, DROP, CREATE, ALTER, TRUNCATE.
6. Use only tables and columns present in the schema context.
7. Always qualify every column with its table alias.
8. Use explicit JOIN ... ON syntax.
9. Derive JOIN conditions from FK relationships.
10. If a column description references another table, join it to retrieve human-readable values.
11. Use proper MariaDB 11.4 syntax:
    - IFNULL
    - COALESCE
    - DATE_FORMAT
    - GROUP_CONCAT
    - DATEDIFF
    Avoid WITH (CTE) clauses entirely: use simple SELECT with JOINs
    and, when unavoidable, plain subqueries instead.
12. Use exact values from business rules when filtering.
12b. ENUM columns: filter ONLY with values that appear in the column's
    "Allowed:" list in the schema context. NEVER invent a category value
    (e.g. do not write cat_code = 'MAT' unless 'MAT' is explicitly
    listed). If no allowed value matches the question's intent, omit the
    filter or reply IMPOSSIBLE.
13. Never invent table names.
14. Never invent column names.
15. Add LIMIT {max_rows} unless:
    - the user explicitly asks for all rows
    - the query is purely aggregate (COUNT, SUM, AVG, MIN, MAX)
16. Prefer JOINs over nested subqueries whenever possible.
17. Do not add JOINs for simple show/list/display rows from one table.
18. Before creating a JOIN, verify that both join columns exist inside the CREATE TABLE blocks in the schema context.
19. Ignore columns mentioned only in comments, referenced-by notes, business rules, enum values, or error feedback.
20. If impossible, output exactly:
21. If the question is impossible to answer with the available schema, reply EXACTLY:
   IMPOSSIBLE: <one-line reason>

NAMED DESIGNATIONS vs EXPLICIT IDs (critical):
- Designations that mix digits and words ("1 IG BG HQ", "2 RCR", "3rd
  Battalion", "Checkpoint 4") are NAME strings. Match them against a name
  column (e.g. name_txt) with the FULL string. NEVER extract a leading or
  embedded number from a name and use it as a numeric id (e.g. never turn
  "1 IG BG HQ" into unit_id = 1).
- When the question supplies an explicit identifier for an entity (e.g.
  "obj_item ID: 1457", "id 42", "reporting_data_id = 7"), filter DIRECTLY
  on that id column with that number, and add NO other identity filter for
  the same entity — the id alone is sufficient and authoritative. The name
  is then descriptive context only; do not also filter on it.
- Never apply two different equality filters that identify the SAME entity
  through different columns joined by equality: if a JOIN says
  a.x = b.y, then filters a.x = 1 AND b.y = 1457 contradict each other and
  guarantee an empty result.

TARGET TABLE ANCHORING (critical):
- The QUESTION refers to a specific entity, and that entity's table is named
  in the AVAILABLE TABLES / SCHEMA CONTEXT. Use THAT table as the primary
  table in FROM.
- Do NOT substitute a different table merely because it also contains a
  column mentioned in the question. Many tables share a column such as
  cat_code; picking the wrong one returns a WRONG answer even though the
  query executes without error.
- If the exact entity's table is present, never answer over a sibling table
  instead.

You may also receive a short PLAN SUMMARY line. If present:
- Follow it strictly.
- Do not add joins, tables or filters that are not mentioned in it.
- If it says "no joins needed", you MUST NOT add any JOIN.
- Output ONLY the SQL query — never repeat or quote the plan summary.
"""

# ---------------------------------------------------------------------------
# Question normalization — absorbs lexical variation ("record" vs "row", etc.)
# without changing the meaning of the question. Fully domain/table agnostic.
# ---------------------------------------------------------------------------

_NORMALIZE_SYSTEM = """
You are a query normalization assistant.

Rewrite the user's question in a clear, unambiguous, canonical form,
WITHOUT changing its meaning and WITHOUT adding any requirement that was
not present in the original question.

Normalization rules:
- If the question is not in English, translate it to English first.
- Make exclusions EXPLICIT: rewrite "ignoring X", "except X", "without X",
  "not counting X" as "excluding rows related to X". Never drop the
  exclusion silently.
- If a phrase is ambiguous between two readings, choose the most literal
  reading of the words actually written; never add an interpretation.
- Use "rows" instead of synonyms like "records", "entries", "items".
- Use "filter by" instead of vague phrasing like "for the case of", "regarding".
- Keep numeric limits exactly as given (e.g. "10 rows" stays "10 rows").
- Treat designations mixing digits and words ("1 IG BG HQ", "2 RCR") as
  indivisible name strings: keep them verbatim, never split off the number.
- Keep explicit identifiers verbatim and attached to their entity
  (e.g. "obj_item ID: 1457" stays exactly as written).
- Do not introduce joins, relations, or comparisons that the user did not ask for.
- Do not mention any specific table or column name unless the user already did.
- Output ONLY the rewritten question, nothing else.
"""

# ---------------------------------------------------------------------------
# Query planning — forces the model to externalize its intent (tables, joins,
# filters, aggregation) as structured JSON BEFORE writing SQL. This makes
# join hallucination detectable by code, for ANY table/domain.
# ---------------------------------------------------------------------------

_PLANNING_SYSTEM = """
You are a query planning assistant.

Given a natural language question and a database schema context, output a
JSON plan describing how to answer it. Do not write SQL.

Output strictly valid JSON with this shape:
{
  "tables_needed": ["table1", "table2"],
  "joins_needed": [
    {"from": "table1.column", "to": "table2.column", "reason": "..."}
  ],
  "filters": ["..."],
  "aggregation": "none | count | sum | avg | min | max | group_by",
  "columns_to_select": ["..."],
  "is_simple_listing": true/false
}

Rules:
- "is_simple_listing" must be true if the question only asks to show/list/
  display/get rows from a single table, with no requirement to combine or
  enrich data from another table.
- Only include "joins_needed" if the question explicitly or unambiguously
  requires combining data from multiple tables.
- Never invent a relationship that is not present in the schema context.
- If "is_simple_listing" is true, "joins_needed" MUST be an empty list.
- Output ONLY the JSON object, nothing else.
"""

# ---------------------------------------------------------------------------
# Intent classification — distinguishes "I want actual data" from "I want
# to know what data/tables exist" so that schema-exploration questions
# never reach the SQL generator (and therefore can never hallucinate
# columns/joins). Fully domain/table agnostic.
# ---------------------------------------------------------------------------

_INTENT_SYSTEM = """
You classify a user's natural language question into ONE category:

- "data_query": the user wants to see, filter, count, or aggregate actual
  data — rows, column values, or lists of VALUES (e.g. "show me the
  activities", "how many tasks per activity", "list the first 10 rows
  from X", "show the category code list of action" — this asks for the
  actual cat_code VALUES, not table names). Questions that ask for records
  and their RELATED records from another entity ("for each X, the related
  Y", "X with its parent Y") are ALSO data_query.
- "schema_exploration": the user wants to know what TABLES, COLUMNS, or
  topics exist or are related to something, WITHOUT asking for actual
  data values (e.g. "what tables are related to activity", "show all
  activity tables", "list all the action tables", "what columns does
  table X have").
- "unclear": the question is too vague, off-topic, or ambiguous to
  classify confidently.

CRITICAL DISTINCTION — read carefully:
- "show the [category/status/type] code LIST of X" → data_query (the user
  wants the actual VALUES that appear in that column, e.g. ATTACK, COMMS).
- "for each X record, what related Y details can be found" → data_query
  (the user wants actual joined rows, not table names).
- "show all X TABLES" / "list all TABLES related to X" → schema_exploration
  (the user wants database TABLE NAMES, not column values).
The word "list" alone does NOT imply schema_exploration. Only an explicit
reference to "tables" (plural, as database objects) does.

Output ONLY one word, exactly: data_query, schema_exploration, or unclear.
Do not add any explanation, punctuation, or extra text.
"""

FORBIDDEN_KEYWORDS = [
    "INSERT",
    "UPDATE",
    "DELETE",
    "DROP",
    "ALTER",
    "CREATE",
    "TRUNCATE",
]

_VALID_INTENTS = ("schema_exploration", "data_query", "unclear")

# Generic, table-agnostic lexical signals (used as a cheap pre-check /
# fallback if planning JSON parsing fails).
_SIMPLE_INTENT_PATTERNS = [
    r"\bshow\b", r"\blist\b", r"\bdisplay\b", r"\bget\b",
    r"\brows?\b", r"\brecords?\b", r"\bentries\b",
]

_RELATIONAL_INTENT_PATTERNS = [
    r"\bwith\b", r"\band their\b", r"\balong with\b",
    r"\bassociated\b", r"\brelated to\b", r"\bby\b.*\bcategory\b",
    r"\bjoined\b", r"\bcombined\b", r"\bcorrespond(ing)?\b",
    r"\bmapped\b", r"\blinked\b",
]

# ---------------------------------------------------------------------------
# Exhaustive table listing detection (used by answer_schema_exploration)
#
# A "schema_exploration" question splits into two very different needs:
#   - topic-scoped: "what tables relate to X", "show all activity tables"
#     -> a similarity search (RAG) is the right tool; "all" here means
#        "all matches for this topic", still bounded/ranked by relevance.
#   - exhaustive: "list all tables in the database", "what tables are there"
#     -> there is no topic at all; the person wants the TRUE complete list,
#        which a similarity search can never guarantee (it's bounded by
#        top_k and ranked by relevance, not designed to be exhaustive).
# The heuristic below strips generic/filler words and checks whether any
# topic word remains: if nothing does, it's an exhaustive request.
# ---------------------------------------------------------------------------

_GENERIC_LISTING_WORDS = {
    "list", "show", "display", "get", "give", "all", "the", "in", "of",
    "me", "please", "tables", "table", "database", "db", "what", "are",
    "there", "is", "a", "an", "and", "to", "for",
}


def _is_exhaustive_table_listing(question: str) -> bool:
    words = re.findall(r"[a-zA-Z]+", question.lower())
    remaining = [w for w in words if w not in _GENERIC_LISTING_WORDS]
    return len(remaining) == 0

logging.basicConfig(level=logging.INFO)

logger = logging.getLogger("BASE SQL GENERATOR")
logger.setLevel(logging.INFO)
logger.disabled = False


def _finalize_sql(raw: str) -> str:
    """Shared tail of clean_sql: comment-line filter, newline join, cut at
    the first statement-terminating semicolon, whitespace normalisation."""
    raw = raw.strip()
    lines = [ln for ln in raw.splitlines() if not ln.strip().startswith("--")]
    raw = "\n".join(lines)
    first_semicolon = raw.find(";")
    if first_semicolon != -1:
        raw = raw[:first_semicolon]
    raw = raw.strip().rstrip(";").rstrip()
    raw = re.sub(r"[ \t]+", " ", raw)
    return raw.strip()


def clean_sql(raw: str) -> str:
    # Extract the actual SQL from conversational wrapper text, instead
    # of assuming the model followed "output ONLY the raw SQL query"
    # strictly. Verified against a real deployment: for a specific
    # class of prompts (e.g. "Can you show me some examples of X?"),
    # the local LLM reliably produces perfectly valid SQL but wraps it
    # in prose ("Sure, I'd be happy to help... Here it is:\n```sql\n
    # SELECT ...\n```\nThis query will return..."), which used to fail
    # _validate_sql()'s startswith("SELECT") check even though the SQL
    # itself was entirely correct -- discarding a good answer over a
    # formatting technicality, and then cascading into the garbled
    # "table1"/"foreign_key"/"primary_key" placeholder retries seen
    # repeatedly throughout this project's debugging, which turned out
    # to be the MODEL REACTING to that self-inflicted parsing failure,
    # not an independent capability problem.
    #
    # Two-tier strategy:
    #   1. Prefer content inside a ```sql ... ``` / ``` ... ``` fence,
    #      if one exists -- the model consistently puts the REAL query
    #      there even when surrounding prose also happens to mention
    #      the word "SELECT" (e.g. "Here is a simple SELECT query...")
    #      which would otherwise be mismatched by a naive keyword
    #      search.
    #   2. If no fence is present, try EVERY SELECT/WITH position in
    #      order and keep the FIRST candidate that actually parses
    #      (sqlglot). This solves both real failure modes at once:
    #        * prose mentioning the word "SELECT" before the query
    #          ("Here is a simple SELECT query: SELECT * FROM t") -- the
    #          prose-anchored candidate doesn't parse, the real one does;
    #        * SUBQUERIES ("... WHERE id IN (SELECT ... ) LIMIT 10") --
    #          the old "take the LAST SELECT" rule grabbed the INNER
    #          subquery, leaving an orphan closing paren ("...'CASRPT')
    #          LIMIT 10", observed in production); the first-parsing rule
    #          keeps the OUTER statement intact.
    # Reasoning-model output strip (Arctic-Text2SQL-R1 & co): these
    # models think aloud inside <think>/<thinking>/<reasoning> blocks
    # BEFORE the SQL. Without this strip, the reasoning prose reaches
    # the extraction below and either shadows the real query or leaves
    # nothing extractable at all -- the ~8s "flash failures" (1 attempt,
    # no SQL) observed on q4/q7/q8/q10/q11/q13/q19 in the 2026-08-06
    # Arctic run. Closed tags are removed pairwise; a dangling closing
    # tag (opening tag cut by the token limit) drops everything before it.
    raw = re.sub(r"<(think|thinking|reasoning)>.*?</\1>", "", raw,
                 flags=re.IGNORECASE | re.DOTALL)
    raw = re.sub(r"^.*?</(think|thinking|reasoning)>", "", raw,
                 flags=re.IGNORECASE | re.DOTALL)

    fence_match = re.search(r"```(?:sql)?\s*(.*?)```", raw, re.IGNORECASE | re.DOTALL)
    if fence_match:
        raw = fence_match.group(1)
    else:
        matches = list(re.finditer(r"\b(SELECT|WITH)\b", raw, re.IGNORECASE))
        if matches:
            try:
                import sqlglot as _sqlglot
            except ImportError:
                _sqlglot = None
            chosen = None
            for m in matches:
                candidate = _finalize_sql(raw[m.start():])
                if not candidate:
                    continue
                if _sqlglot is None:
                    chosen = raw[m.start():]  # no parser available: first match
                    break
                try:
                    _sqlglot.parse_one(candidate, dialect="mysql")
                    chosen = raw[m.start():]
                    break
                except Exception:
                    continue
            # none parses: keep the last-match behaviour so downstream
            # validation reports a meaningful error on SOMETHING
            raw = chosen if chosen is not None else raw[matches[-1].start():]

    raw = raw.strip()

    lines = [
        ln for ln in raw.splitlines()
        if not ln.strip().startswith("--")
    ]

    # Join with newlines, NOT spaces. A line can carry a trailing
    # inline "-- comment" that isn't caught by the full-line filter
    # above (only lines that START with "--" are dropped). Joining
    # such lines with a single space used to merge everything after
    # that "--" into one unbroken line -- and since "--" comments run
    # to the end of the (now single) line, the rest of the query
    # (e.g. "FROM ... WHERE ...") silently vanished into the comment.
    # Verified with sqlglot: "SELECT x -- note\nFROM t" joined with a
    # space parses as "SELECT x" with the FROM/WHERE swallowed as a
    # comment; joined with "\n" it parses correctly. Newlines are safe
    # here -- sqlglot/pymysql/MariaDB all handle multi-line SQL fine.
    raw = "\n".join(lines)

    # If any trailing prose survived after the statement (e.g. "...
    # LIMIT 5;\nThis query will return the first 5 rows..." when no
    # fence was present to bound it), cut at the first statement-
    # terminating semicolon -- anything after it is not part of THIS
    # query. Only the first semicolon is treated as authoritative here;
    # a semicolon inside a quoted string literal earlier in the query
    # would be unusual for the simple single-statement SELECTs this
    # pipeline generates, and static_check's multi-statement guard
    # still catches any genuine multi-statement attempt regardless.
    first_semicolon = raw.find(";")
    if first_semicolon != -1:
        raw = raw[:first_semicolon]

    # Only strip a trailing statement-terminator semicolon, not every
    # semicolon in the string -- a blind raw.replace(";", " ") would
    # also corrupt any semicolon that happens to appear inside a
    # quoted string literal (e.g. a filter value like 'Alpha; Bravo').
    raw = raw.strip()
    raw = raw.rstrip(";").rstrip()

    raw = re.sub(r"[ \t]+", " ", raw)

    return raw.strip()


from agent.sql_generator_base import SQLValidationError
from agent.sql_generator_base import SQLGeneratorBase

class GroundingViolation(Exception):
    def __init__(self, message: str, sql: str = ""):
        super().__init__(message)
        self.sql = sql




class SQLGenerator(SQLGeneratorBase):
    def __init__(self, llm: BaseLLM, max_rows: int = 100):
        super().__init__(llm, max_rows)
        self._system = _SYSTEM.format(max_rows=max_rows)
        self.parent_pipeline = None

        
        logger.info(
            f"SQLGenerator __init__() llm={llm}, "
            f"SQLGenerator llm_class={llm.__class__.__name__}, "
            f"SQLGenerator max_rows={max_rows}"
        )

        

    #
    #   set_parent_pipeline()
    #
    #   Sometimes it is useful to have access to the parent. 
    #   Use wisely. Currently for looking options in the request that influence the RAG
    #   
    #
    def set_parent_pipeline(self, pipe):
        self.parent_pipeline = pipe

    # ------------------------------------------------------------------
    # Cleaning / validation
    # ------------------------------------------------------------------

    def _clean_sql(self, raw: str) -> str:
        # Delegates to the module-level canonical implementation so
        # every consumer (this class, codestral_client, offline
        # scripts) shares ONE cleaning logic -- no more divergent
        # copies like the legacy client-side _clean_sql that kept the
        # old replace-semicolons/join-with-spaces bugs alive.
        return clean_sql(raw)

    def _validate_sql(self, sql: str) -> None:
        upper_sql = sql.upper()

        if upper_sql.startswith("IMPOSSIBLE:"):
            return

        for keyword in FORBIDDEN_KEYWORDS:
            if re.search(rf"\b{keyword}\b", upper_sql):
                raise SQLValidationError(
                    f"Unsafe SQL generated: detected forbidden keyword '{keyword}'"
                )

        if not upper_sql.startswith("SELECT") and not upper_sql.startswith("WITH"):
            raise SQLValidationError("Generated query is not a SELECT statement")

    def _post_process_sql(
        self,
        generated_sql,
        validated_context,
    ):
        generated_sql = self._validate_or_impossible(
            generated_sql
        )

        generated_sql = self._enforce_logical_and(
            generated_sql,
            validated_context,
        )

        return generated_sql
    
    def _validate_or_impossible(self, sql: str) -> str:
        """Validate; but when the output is PROSE rather than SQL (a
        refusal or explanation the model wrote instead of the taught
        "IMPOSSIBLE:" prefix), hand it to the pipeline as an IMPOSSIBLE
        answer instead of raising -- pipeline.py's IMPOSSIBLE path then
        auto-reformulates / declines honestly with the model's own
        reason, rather than burning the attempt on "not a SELECT
        statement". Forbidden-keyword violations still raise."""
        try:
            self._validate_sql(sql)
            return sql
        except SQLValidationError as ve:
            if "not a SELECT statement" not in str(ve):
                raise
            reason = " ".join(sql.split())[:300]
            logger.info("PROSE OUTPUT: converted to IMPOSSIBLE "
                        f"({reason[:80]!r})")
            return "IMPOSSIBLE: " + (reason
                                     or "the model returned no SQL statement")

    # ------------------------------------------------------------------
    # Step A0 — Apply domain glossary (deterministic, runs before the LLM)
    # ------------------------------------------------------------------

    @staticmethod
    def _apply_domain_synonyms(question: str) -> str:
        result = question

        # 1) Free-text domain glossary (action -> activity, ...).
        #    v3.3: longest-first, so a multi-word synonym from
        #    domain_synonyms.json ("material expenditure") is rewritten
        #    before a shorter one it contains ("material").
        for synonym in sorted(DOMAIN_SYNONYMS, key=len, reverse=True):
            result = re.sub(
                rf"\b{re.escape(synonym)}\b",
                DOMAIN_SYNONYMS[synonym],
                result,
                flags=re.IGNORECASE,
            )

        # 2) Naturalised entity display name -> real table name
        #    ("Absolute Point" -> "abs_point"). Applied longest-first so a
        #    multi-word entity is rewritten before a shorter entity it
        #    contains. Runs BEFORE RAG retrieval (see pipeline.run()), so
        #    the vector search keys on the real table token and actually
        #    retrieves it -- the fix for the wrong-table answers where the
        #    LLM never saw the correct table in its schema context.
        for display in _ENTITY_KEYS_SORTED:
            result = re.sub(
                rf"\b{re.escape(display)}\b",
                ENTITY_TABLE_MAP[display],
                result,
                flags=re.IGNORECASE,
            )

        return result

    # ------------------------------------------------------------------
    # Step A — Normalize the natural language question
    # ------------------------------------------------------------------

    def _normalize_question(self, question: str) -> str:
        question = self._apply_domain_synonyms(question)

        try:
            self.parent_pipeline.set_langfuse_trace_step("NORMALIZE")
            normalized = self.llm.complete(
                _NORMALIZE_SYSTEM,
                [{"role": "user", "content": question}],
                max_tokens=1024,
            )

            normalized = normalized.strip().strip('"')

            if not normalized:
                return question


            # Deterministic anti-chatter guard. Chat-tuned models (observed
            # with mistral) sometimes wrap the rewrite in conversational
            # padding ("Sure, I'd be happy to help... Here's a rewritten
            # version of your question: ...") -- and that ENTIRE message,
            # preamble included, then became the question sent to generate()
            # (seen in production logs 2026-07-24). A prompt instruction
            # alone is not a guarantee; this rule is. Each check targets an
            # observed symptom: the Sure/Here's opener, the blank line
            # between preamble and question, the inflated length.
            _low = normalized.lower()
            _chatter = (
                _low.startswith(("sure", "certainly", "of course", "here's", "here is"))
                or "rewritten version" in _low[:120]
                or "\n" in normalized
                or len(normalized) > 2.5 * max(len(question), 1)
            )
            if _chatter:
                logger.warning(
                    "_normalize_question() LLM chattered instead of rewriting; "
                    "keeping original. raw=" + repr(normalized[:120])
                )
                return question

            logger.info(
                f"_normalize_question() original={question!r} "
                f"normalized={normalized!r}"
            )

            return normalized

        except Exception as exc:
            logger.warning(
                f"_normalize_question() failed, using original question: {exc}"
            )
            return question
        
        
        
    def _build_resolved_question(
        self,
        question: str,
        validated_context,
    ) -> str:

        if not validated_context:
            return question

        if not validated_context.entity_filters:
            return question

        resolved_parts = []

        for filt in validated_context.entity_filters:

            resolved_parts.append(filt)

        resolved_values = "\n".join(resolved_parts)

        return (
            "RESOLVED QUESTION\n"
            "-----------------\n\n"
            "The original user question contained "
            "entities that have already been resolved.\n\n"
            "Resolved entities:\n"
            f"{resolved_values}\n\n"
            "Generate SQL using the resolved values above.\n\n"
            f"Original question:\n{question}"
        )

    # --------------------------------------s----------------------------
    # Step B — Build a structured plan before writing SQL
    # ------------------------------------------------------------------

    def _build_plan(self, question: str, schema_context: str) -> dict | None:
        user_msg = f"""
            SCHEMA CONTEXT
            --------------
            {schema_context}

            QUESTION
            --------
            {question}
            """

        try:
            self.parent_pipeline.set_langfuse_trace_step("PLAN")
            raw_plan = self.llm.complete(
                _PLANNING_SYSTEM,
                [{"role": "user", "content": user_msg}],
                max_tokens=8192,
            )

            cleaned = re.sub(r"```(?:json)?\s*", "", raw_plan, flags=re.IGNORECASE)
            cleaned = re.sub(r"```", "", cleaned).strip()

            plan = json.loads(cleaned)

            logger.info(f"_build_plan() plan={plan}")

            return plan

        except Exception as exc:
            logger.warning(f"_build_plan() failed to produce a usable plan: {exc}")
            return None

    @staticmethod
    def _plan_has_contradiction(plan: dict) -> bool:
        if not plan:
            return False

        is_simple = bool(plan.get("is_simple_listing"))
        joins = plan.get("joins_needed") or []

        return is_simple and len(joins) > 0

    @staticmethod
    def _plan_to_summary_line(plan: dict) -> str:
        """
        Convert the JSON plan into a short, single-line natural language
        summary. This is injected into the SQL-generation prompt instead
        of the raw JSON, to avoid confusing smaller/local LLMs that may
        otherwise echo, quote, or get distracted by a JSON block sitting
        next to a "write only SQL" instruction.
        """

        tables = plan.get("tables_needed") or []
        joins = plan.get("joins_needed") or []
        aggregation = plan.get("aggregation") or "none"
        is_simple = bool(plan.get("is_simple_listing"))

        if is_simple or not joins:
            joins_part = "no joins needed"
        else:
            joins_part = "joins needed: " + "; ".join(
                f"{j.get('from')} -> {j.get('to')}" for j in joins
            )

        return (
            f"PLAN SUMMARY: tables={tables or 'n/a'}; {joins_part}; "
            f"aggregation={aggregation}"
        )

    # ------------------------------------------------------------------
    # Step C — Lexical fallback heuristic (used if no plan is available)
    # ------------------------------------------------------------------

    @staticmethod
    def _question_is_simple(question: str) -> bool:
        q = question.lower()
        has_simple = any(re.search(p, q) for p in _SIMPLE_INTENT_PATTERNS)
        has_relational = any(re.search(p, q) for p in _RELATIONAL_INTENT_PATTERNS)
        return has_simple and not has_relational

    @staticmethod
    def _count_joins(sql: str) -> int:
        return len(re.findall(r"\bJOIN\b", sql.upper()))
    
    
    
    @staticmethod
    def _join_justified_by_where(sql: str) -> bool:

        sql = sql or ""

        alias_to_table = {}

        for match in re.finditer(
            r"\b(FROM|JOIN)\s+([A-Za-z_][A-Za-z0-9_]*)\s+([A-Za-z_][A-Za-z0-9_]*)",
            sql,
            re.IGNORECASE,
        ):
            table = match.group(2)
            alias = match.group(3)

            alias_to_table[alias.lower()] = table.lower()

        from_match = re.search(
            r"\bFROM\s+([A-Za-z_][A-Za-z0-9_]*)",
            sql,
            re.IGNORECASE,
        )

        if not from_match:
            return False

        main_table = from_match.group(1).lower()

        where_match = re.search(
            r"\bWHERE\b(.*)",
            sql,
            re.IGNORECASE | re.DOTALL,
        )

        if not where_match:
            return False

        where_clause = where_match.group(1)

        aliases_used = set(
            a.lower()
            for a in re.findall(
                r"([A-Za-z_][A-Za-z0-9_]*)\.",
                where_clause,
            )
        )

        for alias in aliases_used:

            table = alias_to_table.get(alias)

            if table and table != main_table:

                logger.info(
                    f"JOIN_JUSTIFIED alias={alias} "
                    f"table={table} "
                    f"main_table={main_table}"
                )

                return True

        return False
        
    

    def _needs_simplification_retry(
        self,
        question: str,
        sql: str,
        plan: dict | None,
    ) -> bool:
        if plan is not None:
            if self._plan_has_contradiction(plan):
                return True
            if not (plan.get("joins_needed") or []) and self._count_joins(sql) > 0:

                if self._join_justified_by_where(sql):

                    logger.info(
                        "JOIN justified by WHERE clause, skipping simplification retry."
                    )

                    return False

                return True
            return False

        if (
            self._question_is_simple(question)
            and self._count_joins(sql) > 0
        ):

            if self._join_justified_by_where(sql):

                logger.info(
                    "JOIN justified by WHERE clause, skipping simplification retry."
                )

                return False

            return True

        return False

    # ------------------------------------------------------------------
    # Step D — Intent classification (runs BEFORE schema/SQL generation)
    # ------------------------------------------------------------------

    def classify_intent(self, question: str) -> str:

        question = self._apply_domain_synonyms(question)

        q = question.lower()

        # Analytical / trend queries are always data queries
        analytical_patterns = [
            "how did",
            "change over time",
            "over time",
            "trend",
            "trends",
            "evolution",
            "evolve",
            "history",
            "changed"
        ]

        if any(p in q for p in analytical_patterns):
            logger.info(
                f"classify_intent() analytical override "
                f"question={question!r} intent='data_query'"
            )
            return "data_query"

        try:
            self.parent_pipeline.set_langfuse_trace_step("CLASSIFY_INTENT")
            result = self.llm.complete(
                _INTENT_SYSTEM,
                [{"role": "user", "content": question}],
                max_tokens=1024,
            )

            result_lower = result.strip().lower()

            for intent in _VALID_INTENTS:
                if intent in result_lower:
                    logger.info(
                        f"classify_intent() question={question!r} "
                        f"intent={intent!r} raw={result!r}"
                    )
                    return intent

            logger.warning(
                f"classify_intent() unrecognized output={result!r}, "
                "defaulting to data_query"
            )

        except Exception as exc:
            logger.warning(
                f"classify_intent() failed: {exc}, defaulting to data_query"
            )

        return "data_query"

    # ------------------------------------------------------------------
    # Step E — Answer schema-exploration questions directly from retrieval
    # (no SQL generated, no execution, no chance of column hallucination)
    # ------------------------------------------------------------------

    def answer_schema_exploration(self, question: str, schema_rag) -> dict:
        """
        Answer 'what tables/columns relate to X' questions directly from
        the schema RAG retrieval, without generating or executing SQL.

        Exhaustive requests ("list all tables in the database", "what
        tables are there") are detected separately and answered from
        schema_rag.all_table_names() -- the TRUE complete list -- instead
        of the topic-scoped RAG retrieval below. A similarity search is
        bounded by top_k and ranked by relevance; it can never reliably
        answer "how many tables total" or "list every table", regardless
        of how top_k is tuned. Verified against a real deployment: "List
        all tables in the database" was answered with "Found 20 table(s)"
        out of a genuine 254-table schema, silently under-reporting by
        over 90% because the question was (correctly) classified as
        schema_exploration but then (incorrectly) routed through the
        bounded RAG path regardless of whether the question was topic-
        scoped or exhaustive.

        Uses schema_rag.retrieve_for_exploration() — a wider, more
        permissive retrieval (vector search + lexical fallback) than the
        one used for SQL generation, since missing a relevant table here
        is worse than including a few extra ones — for topic-scoped
        exploration questions only.

        Returns a dict with:
          - "summary": short natural language summary
          - "table_markdown": markdown table of matched tables + descriptions
          - "illustrative_sql": a non-executed, illustrative SQL snippet
            (e.g. SHOW TABLES LIKE ...) shown to the user as reference,
            consistent with the "Generated SQL" panel used elsewhere.
        """

        if _is_exhaustive_table_listing(question):
            try:
                all_names = sorted(schema_rag.all_table_names())
            except Exception as exc:
                logger.warning(f"answer_schema_exploration() all_table_names() failed: {exc}")
                return {
                    "summary": "I couldn't retrieve the full table list right now — please try again.",
                    "table_markdown": "",
                    "illustrative_sql": "",
                }

            if not all_names:
                return {
                    "summary": "I couldn't find any tables in the database.",
                    "table_markdown": "",
                    "illustrative_sql": "",
                }

            # Best-effort per-table description via the knowledge base;
            # falls back to a plain name-only list if unavailable, rather
            # than failing the whole request over a missing/optional import.
            try:
                from RAG.knowledge_base import get_table_kb
                rows = ["| Table | Description |", "| --- | --- |"]
                for name in all_names:
                    desc = (get_table_kb(name).get("description", "") or "").split("\n")[0]
                    desc = desc.replace("|", "/")  # avoid breaking markdown
                    rows.append(f"| {name} | {desc} |")
                table_markdown = "\n".join(rows)
            except Exception as exc:
                logger.warning(f"answer_schema_exploration() KB lookup failed, listing names only: {exc}")
                table_markdown = "\n".join(f"- {name}" for name in all_names)

            return {
                "summary": f"The database contains {len(all_names)} table(s) in total.",
                "table_markdown": table_markdown,
                "illustrative_sql": "SHOW TABLES;",
            }

        try:
            if hasattr(schema_rag, "retrieve_for_exploration"):
                retrieved = schema_rag.retrieve_for_exploration(question)
            else:
                # Backward-compatible fallback if schema_rag hasn't been
                # updated yet.
                retrieved = schema_rag.retrieve(question)
        except Exception as exc:
            logger.warning(f"answer_schema_exploration() retrieval failed: {exc}")
            return {
                "summary": "I couldn't search the schema right now — please try again.",
                "table_markdown": "",
                "illustrative_sql": "",
            }

        if not retrieved:
            return {
                "summary": "I couldn't find any tables related to that topic.",
                "table_markdown": "",
                "illustrative_sql": "",
            }

        table_names = [t.table_name for t in retrieved]

        rows = ["| Table | Description |", "| --- | --- |"]
        for t in retrieved:
            payload = t.payload
            name = payload.get("table") or payload.get("table_name") or "unknown"
            description = (payload.get("description", "") or "").split("\n")[0]
            description = description.replace("|", "/")  # avoid breaking markdown
            rows.append(f"| {name} | {description} |")

        table_markdown = "\n".join(rows)

        # Note: MariaDB's SHOW TABLES LIKE accepts a single pattern only --
        # there's no valid "LIKE 'x' OR LIKE 'y'" multi-pattern syntax for
        # it. Since this snippet is explicitly illustrative/non-executed,
        # keep it honest by only showing a real, valid single-pattern form
        # (first table), rather than presenting invalid syntax as if it
        # were runnable.
        illustrative_sql = (
            f"SHOW TABLES LIKE '%{table_names[0]}%';"
            if table_names else ""
        )

        summary = (
            f"Found {len(table_names)} table(s) related to your question: "
            f"{', '.join(table_names)}.\n\n"
            f"You can ask me to show data from any of these, e.g. "
            f"\"show me 10 rows from {table_names[0]}\"."
        )

        return {
            "summary": summary,
            "table_markdown": table_markdown,
            "illustrative_sql": illustrative_sql,
        }

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    
    def _validate_entity_filters(
        self,
        generated_sql,
        validated_context,
    ):

        if (
            not validated_context
            or not validated_context.entity_filters
        ):
            return generated_sql

        sql_lower = generated_sql.lower()

        missing_filters = []

        logger.warning(
            "ENTITY_FILTER_VALIDATION_SQL=%s",
            generated_sql,
        )

        for entity_filter in validated_context.entity_filters:

            try:

                column, value = entity_filter.split("=", 1)

                column = column.strip().lower()
                value = value.strip().lower()

                logger.warning(
                    "CHECKING_ENTITY_FILTER column=%s value=%s",
                    column,
                    value,
                )

                #
                # Entity filter satisfied if the resolved value
                # appears anywhere in the generated SQL.
                #
                if value not in sql_lower:

                    missing_filters.append(
                        entity_filter
                    )

                    logger.warning(
                        "FILTER_NOT_FOUND=%s",
                        entity_filter,
                    )

            except Exception:

                logger.exception(
                    "ENTITY_FILTER_PARSE_ERROR=%s",
                    entity_filter,
                )

                missing_filters.append(
                    entity_filter
                )

        if missing_filters:

            logger.error(
                "MISSING_ENTITY_FILTERS=%s",
                missing_filters,
            )

            raise GroundingViolation(
                f"Missing entity filters: {missing_filters}"
            )

        return generated_sql
    
    
    import re
    
    
    def _normalize_join_expression(
        self,
        expr: str,
        alias_map=None,
    ):
        
        logger.warning(
            "NORMALIZE_FUNCTION_V2_LOADED"
            )

        alias_map = alias_map or {}
        
        logger.warning(
            "RAW_NORMALIZE_EXPR=%s",
            expr,
        )

        parts = expr.split("=")

        if len(parts) != 2:

            logger.warning(
                "INVALID_JOIN_EXPRESSION=%s",
                expr,
            )

            return expr.strip().lower()

        left, right = parts

        left = left.strip().lower()
        right = right.strip().lower()

        for alias, table in alias_map.items():

            left = re.sub(
                rf"\b{re.escape(alias)}\.",
                f"{table}.",
                left,
            )

            right = re.sub(
                rf"\b{re.escape(alias)}\.",
                f"{table}.",
                right,
            )

        return "=".join(
            sorted([left, right])
        )
        
            

           


    def _validate_sql_joins_against_fk_paths(
        self,
        generated_sql,
        validated_context,
    ):

        if (
            not validated_context
            or not validated_context.fk_paths
        ):
            return generated_sql

        allowed_joins = {
            self._normalize_join_expression(
                fk.join_on
            )
            for fk in validated_context.fk_paths
        }
        
        alias_map = {}

        for table, alias in re.findall(
            r"(?:from|join)\s+(\w+)\s+(\w+)",
            generated_sql,
            flags=re.IGNORECASE,
        ):
            alias_map[alias.lower()] = table.lower()

        logger.warning(
            "ALIAS_MAP=%s",
            alias_map,
        )


        join_patterns = re.findall(
            r"\bON\b\s+(.*?)\s*(?:\bJOIN\b|\bWHERE\b|\bGROUP\b|\bORDER\b|;|$)",
            generated_sql,
            flags=re.IGNORECASE,
        )
        
        logger.warning(
            "JOIN_PATTERNS=%s",
            join_patterns,
        )

        invalid_joins = []

        for join_condition in join_patterns:
            
            logger.warning(
                "NORMALIZE_FUNCTION=%s",
                self._normalize_join_expression,
            )

            logger.warning(
                "NORMALIZE_CODE_ARGCOUNT=%s",
                self._normalize_join_expression.__code__.co_argcount,
            )

            normalized = self._normalize_join_expression(
                join_condition,
                alias_map,
            )
            
            
            logger.warning(
                "ALLOWED_JOINS=%s",
                allowed_joins,
            )

            logger.warning(
                "NORMALIZED_JOIN=%s",
                normalized,
            )
            
            logger.warning(
                "CHECKING_JOIN=%s",
                join_condition,
            )

            logger.warning(
                "CHECKING_NORMALIZED=%s",
                normalized,
            )

            if normalized not in allowed_joins:

                invalid_joins.append(
                    join_condition
                )

        #  not self.parent_pipeline.force and
        if invalid_joins:

            logger.error(
                "INVALID_FK_JOINS=%s",
                invalid_joins,
            )

            raise GroundingViolation(
                f"Invalid joins detected: {invalid_joins}",
                sql=generated_sql,
            )

        return generated_sql
    
    
    def _validate_sql_tables_against_reachable_tables(
    self,
    generated_sql,
    validated_context,
    ):

        if (
            not validated_context
            or not validated_context.fk_paths
        ):
            return generated_sql

        reachable_tables = set()

        for fk in validated_context.fk_paths:

            reachable_tables.add(
                fk.table.lower()
            )

            reachable_tables.add(
                fk.related_table.lower()
            )

        sql_tables = set()

        for match in re.finditer(
            r"\b(?:from|join)\s+([a-zA-Z_][a-zA-Z0-9_]*)",
            generated_sql,
            re.IGNORECASE,
        ):
            sql_tables.add(
                match.group(1).lower()
            )
            
        
        logger.warning(
            "TABLE_VALIDATION_GENERATED_SQL=\n%s",
            generated_sql,
        )

        logger.warning(
            "TABLE_VALIDATION_SQL_TABLES=%s",
            sorted(sql_tables),
        )

        logger.warning(
            "TABLE_VALIDATION_REACHABLE_TABLES=%s",
            sorted(reachable_tables),
        )    
        

        invalid_tables = sorted(
            sql_tables - reachable_tables
        )

        if invalid_tables:

            logger.error(
                "INVALID_TABLES=%s",
                invalid_tables,
            )

            raise GroundingViolation(
                f"Invalid tables detected: {invalid_tables}"
            )

        return generated_sql
    
    
    def generate(
        self,
        question: str,
        schema_context: str,
        all_tables: list[str],
        error_feedback: str = "",
        previous_sql: str = "",
        mandatory_tables=None,
        validated_context=None,
    ) -> str:
        
        logger.warning(
            "VALIDATED_CONTEXT_IN_GENERATOR=%s",
            validated_context
        )
        
        if (
            validated_context
            and
            str(validated_context.relationship_status)
            ==
            "RelationshipStatus.UNSATISFIABLE_CORRELATION"
        ):

            logger.warning(
                "EARLY_EXIT_UNSATISFIABLE_CORRELATION"
            )

            return (
                "IMPOSSIBLE: "
                "Question requires correlation between "
                "disconnected table groups."
            )

        

        if not error_feedback:
            question = self._normalize_question(question)
        
        question = self._build_resolved_question(
            question,
            validated_context,
        )

        #plan = self._build_plan(question, schema_context) if not error_feedback else None
        plan = None
        
        reachable_tables = None

        if (
            validated_context
            and validated_context.fk_paths
        ):

            reachable_tables = set()

            for fk in validated_context.fk_paths:

                reachable_tables.add(
                    fk.table
                )

                reachable_tables.add(
                    fk.related_table
                )

            logger.warning(
                "REACHABLE_TABLES=%s",
                sorted(reachable_tables)
            )
        
        _MAX_TABLES_IN_PROMPT = 80

        #
        # Use reachable tables when FK graph exists
        #
        if reachable_tables:

            tables_line = ", ".join(
                sorted(reachable_tables)
            )

            logger.warning(
                "USING_REACHABLE_TABLES_ONLY"
            )

        #
        # Fallback
        #
        elif not all_tables:

            tables_line = "(see schema below)"

        elif len(all_tables) <= _MAX_TABLES_IN_PROMPT:

            tables_line = ", ".join(all_tables)

        else:

            tables_line = (
                ", ".join(all_tables[:_MAX_TABLES_IN_PROMPT])
                + f" ... (+{len(all_tables) - _MAX_TABLES_IN_PROMPT} more — use schema context)"
            )

        plan_block = ""
        if plan is not None:
            plan_block = f"\n{self._plan_to_summary_line(plan)}\n"

        grounding_block = ""
        
        effective_tables = []

        if reachable_tables:
            effective_tables = sorted(reachable_tables)
        elif mandatory_tables:
            effective_tables = sorted(mandatory_tables)

        if effective_tables:
            
            logger.warning(
                "EFFECTIVE_TABLES_FOR_PROMPT=%s",
                effective_tables,
            )

            grounding_block = f"""
            VERIFIED GROUNDING TABLES
            -------------------------
            {", ".join(effective_tables)}

            GROUNDING IS AUTHORITATIVE.

            The grounding process already identified the most relevant entities.

            You MUST prefer these tables.

            You MUST NOT replace these tables with semantically similar tables.

            You MUST use only columns explicitly present in the schema context.

            You MUST NEVER invent columns.

            You MUST NEVER invent foreign keys.

            You MUST NEVER invent joins.

            You MUST NEVER invent table relationships.

            If a required join column is not present in the schema context,
            return IMPOSSIBLE.

            Inventing foreign keys is forbidden.

            Inventing relationships is forbidden.

            A column exists ONLY if it appears in the schema context.
            """
            
            grounded_tables = (
                sorted(reachable_tables)
                if reachable_tables
                else sorted(mandatory_tables)
            )

            grounding_block = f"""
            MANDATORY TABLE RULES
            ---------------------

            The following tables were selected by grounding:

            {chr(10).join(grounded_tables)}

            These tables are authoritative.
            """
     
        
        ### ### ###
        validated_context_block = ""

        if validated_context:

            logger.warning(
                "VALIDATED_CONTEXT_RECEIVED"
            )

            logger.warning(
                "RELATIONSHIP_STATUS=%s",
                validated_context.relationship_status
            )

            logger.warning(
                "ENTITY_FILTERS=%s",
                validated_context.entity_filters
            )

            logger.warning(
                "FK_PATHS=%s",
                validated_context.fk_paths
            )

            logger.warning(
                "PREDICATE_GROUPS=%s",
                validated_context.predicate_groups
            )

            validated_context_block += (
                "\n\n"
                "RELATIONSHIP STRATEGY\n"
                "---------------------\n"
            )

            validated_context_block += (
                f"Status: "
                f"{validated_context.relationship_status}\n\n"
            )

            #
            # FULLY CONNECTED
            #
            if (
                str(validated_context.relationship_status)
                == "RelationshipStatus.FULLY_CONNECTED"
            ):

                validated_context_block += (
                    "FULLY CONNECTED GRAPH\n"
                    "---------------------\n"
                    "\n"
                    "All grounded tables belong to the same "
                    "validated relationship graph.\n"
                    "\n"
                    "MANDATORY JOIN RULES\n"
                    "--------------------\n"
                    "\n"
                    "Every JOIN in the final SQL MUST come "
                    "from the VALIDATED FK PATHS section.\n"
                    "\n"
                    "If a JOIN condition does not appear in "
                    "VALIDATED FK PATHS, it is forbidden.\n"
                    "\n"
                    "Do NOT infer shortcut joins.\n"
                    "\n"
                    "Do NOT infer semantic relationships.\n"
                    "\n"
                    "Do NOT invent foreign keys.\n"
                    "\n"
                    "Do NOT invent JOIN conditions.\n"
                    "\n"
                    "Use only the exact validated FK path.\n"
                    
                    "\n"
                    "JOIN VALIDATION RULE\n"
                    "\n"
                    "Before generating SQL, verify every JOIN.\n"
                    "\n"
                    "A JOIN is valid ONLY if its exact join condition appears "
                    "in VALIDATED FK PATHS.\n"
                    "\n"
                    "If any required JOIN is missing from VALIDATED FK PATHS, "
                    "return IMPOSSIBLE.\n"
                    "\n"
                    "Do NOT substitute another table.\n"
                    "\n"
                    "Do NOT use semantically similar tables.\n"
                    "\n"
                    "Do NOT introduce unit_type unless it appears in "
                    "VALIDATED FK PATHS.\n"
                    "\n"
                    "Do NOT introduce weapon_type through a direct join.\n"
                    "\n"
                    "Every table in the final SQL must be reachable through "
                    "the validated path.\n"
                    
                    "\n"
                    "If the validated FK path is insufficient "
                    "to answer the question, return IMPOSSIBLE.\n"
                    "\n"
                    "Use only columns that exist in the "
                    "schema context.\n\n"
                )
                
                validated_context_block += (
                    "\n"
                    "FORBIDDEN TABLE RULE\n"
                    "--------------------\n"
                    "\n"
                    "Any table not listed in REACHABLE TABLES "
                    "is forbidden.\n"
                    "\n"
                    "Any table not listed in AVAILABLE TABLES "
                    "is forbidden.\n"
                    "\n"
                    "Do NOT introduce additional tables.\n"
                    "\n"
                    "Do NOT use semantically similar tables.\n"
                    "\n"
                    "Do NOT replace grounded tables with other tables.\n"
                    "\n"
                    "If a required table is not reachable through "
                    "the validated FK paths, return IMPOSSIBLE.\n"
                    "\n"
                    "Examples of forbidden behavior:\n"
                    "- introducing unit_type when it does not appear in REACHABLE TABLES\n"
                    "- introducing org_type when it does not appear in REACHABLE TABLES\n"
                    "- introducing unit when it does not appear in REACHABLE TABLES\n"
                    "- replacing obj_item with unit_type\n"
                    "\n"
                )
            #
            # PARTIALLY CONNECTED
            #
            elif (
                str(validated_context.relationship_status)
                == "RelationshipStatus.PARTIALLY_CONNECTED"
            ):

                validated_context_block += (
                    "VALIDATED COMPONENTS\n"
                    "--------------------\n"
                )

                if hasattr(
                    validated_context,
                    "connected_components"
                ):

                    for idx, component in enumerate(
                        validated_context.connected_components,
                        start=1
                    ):

                        validated_context_block += (
                            f"Component {idx}\n"
                            f"Tables: "
                            f"{', '.join(sorted(component.tables))}\n\n"
                        )

                validated_context_block += (
                    "IMPORTANT\n"
                    "\n"
                    "JOINs are allowed only inside "
                    "the same validated component.\n"
                    "\n"
                    "Do NOT create JOINs across components.\n"
                    "\n"
                    "Do NOT invent foreign keys.\n"
                    "\n"
                    "Use only validated FK paths.\n"
                    "\n"
                    "Answer using the validated component "
                    "whenever possible.\n\n"
                )

            #
            # LOGICAL_AND
            #
            elif (
                str(validated_context.relationship_status)
                == "RelationshipStatus.LOGICAL_AND"
            ):

                validated_context_block += (
                    "DISCONNECTED GROUPS\n"
                    "-------------------\n"
                )

                for idx, group in enumerate(
                    validated_context.predicate_groups,
                    start=1
                ):

                    validated_context_block += (
                        f"Group {idx}\n"
                        f"Tables: "
                        f"{', '.join(group)}\n\n"
                    )

                validated_context_block += (
                    "IMPORTANT\n"
                    "\n"
                    "No validated FK path exists "
                    "between these groups.\n"
                    "\n"
                    "Do NOT invent foreign keys.\n"
                    "\n"
                    "Do NOT invent relationships.\n"
                    "\n"
                    "Do NOT create JOINs across groups.\n"
                    "\n"
                    "Generate SQL only if the answer can be "
                    "produced using a single group.\n"
                    "\n"
                    "If answering the question requires "
                    "combining data across groups, "
                    "return IMPOSSIBLE.\n\n"
                )

            #
            # VALIDATED FK PATHS
            #
            if validated_context.fk_paths:

                validated_context_block += (
                    "VALIDATED FK PATHS\n"
                    "------------------\n"
                )

                for path in validated_context.fk_paths:

                    try:

                        validated_context_block += (
                            f"{path.join_on}\n"
                        )

                    except Exception:

                        validated_context_block += (
                            f"{path}\n"
                        )

                validated_context_block += "\n"

                #
                # REACHABLE TABLES
                #
                validated_context_block += (
                    "REACHABLE TABLES\n"
                    "----------------\n"
                )

                reachable_tables = set()

                for fk in validated_context.fk_paths:

                    reachable_tables.add(fk.table)
                    reachable_tables.add(fk.related_table)

                for table in sorted(reachable_tables):

                    validated_context_block += (
                        f"{table}\n"
                    )

                validated_context_block += "\n"
                
                
            #
            # AUTHORITATIVE JOIN CHAIN
            #
            if (
                hasattr(
                    validated_context,
                    "recommended_join_chain"
                )
                and
                validated_context.recommended_join_chain
            ):

                validated_context_block += (
                    "\n"
                    "AUTHORITATIVE JOIN CHAIN\n"
                    "========================\n"
                    "\n"
                    "The validator has already identified\n"
                    "the allowed join routes.\n"
                    "\n"
                    "You MUST use these joins.\n"
                    "\n"
                    "Do NOT introduce alternative joins.\n"
                    "\n"
                    "Do NOT introduce alternative tables.\n"
                    "\n"
                    "Do NOT skip intermediate tables.\n"
                    "\n"
                    "Do NOT invent shortcuts.\n"
                    "\n"
                )

                for step in validated_context.recommended_join_chain:

                    validated_context_block += (
                        f"{step['from']}\n"
                        f" -> {step['to']}\n"
                        f"JOIN: {step['join']}\n\n"
                    )
                
           
                
           
                
            # VALIDATED TABLE PATH   
                
                
            if validated_context.fk_paths:

                validated_context_block += (
                    "\n"
                    "VALIDATED TABLE PATH\n"
                    "--------------------\n"
                )

                for path in validated_context.fk_paths:

                    try:

                        validated_context_block += (
                            f"{path.table} -> {path.related_table}\n"
                        )

                    except Exception:
                        pass

                validated_context_block += "\n"

            #
            # ENTITY FILTERS
            #
            if validated_context.entity_filters:

                validated_context_block += (
                    "\n"
                    "VERIFIED ENTITY FILTERS\n"
                    "-----------------------\n"
                )

                for filt in validated_context.entity_filters:

                    validated_context_block += (
                        f"{filt}\n"
                    )

                validated_context_block += (
                    "\n"
                    "IMPORTANT\n"
                    "\n"
                    "These filters are authoritative.\n"
                    "\n"
                    "These filters must appear in the final SQL.\n"
                    "\n"
                    "Do NOT remove them.\n"
                    "\n"
                    "Do NOT replace them.\n"
                    "\n"
                    "Do NOT reinterpret them.\n"
                    "\n"
                    "Do NOT convert them into LIKE clauses.\n"
                )
        
        
        ### ### ### 
        
        resolved_entities_block = ""

        if (
            validated_context
            and
            validated_context.entity_filters
        ):

            resolved_entities_block += (
                "\n"
                "ENTITY RESOLUTION RESULTS\n"
                "-------------------------\n"
            )

            for filt in validated_context.entity_filters:

                resolved_entities_block += (
                    f"{filt}\n"
                )

            validated_context_block += """
                ENTITY RESOLUTION IS AUTHORITATIVE
                ==================================

                Entity resolution has already been performed.

                The original entity names, labels, aliases, and user-supplied text
                have already been resolved into authoritative database values.

                The resolved values below are final.

                You MUST use the resolved database values.

                You MUST NOT re-resolve entities.

                You MUST NOT search again for the original entity text.

                You MUST NOT generate new filters from the original entity text.

                You MUST NOT use LIKE, MATCH, CONTAINS, REGEXP, or fuzzy matching
                against an entity that has already been resolved.

                You MUST NOT reintroduce original entity names into SQL predicates.

                The resolved filters are authoritative.

                Use the resolved filters exactly as provided.

                If a resolved filter exists, it takes precedence over any original
                entity text appearing in the question.

                Examples
                --------

                If entity resolution produced:

                    obj_item.obj_item_id = 2284

                then valid:

                    WHERE obj_item.obj_item_id = 2284

                invalid:

                    WHERE name_txt LIKE '%M777%'
                    WHERE name_txt = 'M777 Group'

                If entity resolution produced:

                    unit_id = 17

                then valid:

                    WHERE unit_id = 17

                invalid:

                    WHERE unit_name LIKE '%Alpha%'
                    WHERE unit_name = 'Alpha Battery'

                """

            
        
        logger.warning(
            "AUTHORITATIVE_JOIN_CHAIN=%s",
            validated_context.recommended_join_chain
        )
        
        if (
            validated_context.connected_graph
            and validated_context.connected_graph.edges
        ):
            validated_context_block += "\n\n"
            validated_context_block += (
                validated_context
                .connected_graph
                .to_prompt_block()
            )
        
        
        logger.warning(
            "VALIDATED_CONTEXT_BLOCK=%s",
            validated_context_block
        )
        
        required_path_block = ""

        if validated_context.required_join_path:

            required_path_block = (
                "\n\n"
                "QUESTION SPECIFIC JOIN PATH\n"
                "===========================\n\n"
                "The validator has already computed\n"
                "the exact path required for this question.\n\n"
                "Required path:\n\n"
                + "\n -> ".join(
                    validated_context.required_join_path
                )
                + "\n\n"
                "You MUST use every table in this path.\n"
                "You MUST NOT skip intermediate tables.\n"
                "You MUST NOT use shortcuts.\n"
                "You MUST NOT invent alternative joins.\n"
            )

            logger.warning(
                "REQUIRED_JOIN_PATH_BLOCK=\n%s",
                required_path_block
            )

            validated_context_block += required_path_block
            
           # logger.warning(
           #     "VALIDATED_CONTEXT_BLOCK=%s",
           #     validated_context_block
          #  )                   


        user_msg = f"""
            {grounding_block}

            AVAILABLE TABLES
            ----------------
            {tables_line}                        
            
            {validated_context_block}

            {resolved_entities_block}


            SCHEMA CONTEXT
            --------------

            IMPORTANT

            The schema context below is exhaustive.

            If a column is not present in the schema context,
            it does not exist.

            Do not invent:
            - columns
            - foreign keys
            - IDs
            - relationships
            - join paths

            Return IMPOSSIBLE rather than inventing schema elements.

            {schema_context}

            TASK
            ----
            Generate a single MariaDB SELECT query.

            QUESTION
            --------
            {question}
            """


        messages = [{"role": "user", "content": user_msg}]

        if error_feedback:
            # Show the model its OWN previous SQL, not just a placeholder
            # comment. Verified against real logs: with the previous
            # "-- previous SQL failed" stub, the model literally replied
            # "Without seeing the previous SQL query or the schema
            # context..." and then fell back to a generic hallucinated
            # template (SELECT t1.column1 FROM table1 JOIN table2 ON
            # t1.foreign_key = t2.primary_key) -- the single most common
            # quality-failure category in the blue-tables evaluation run
            # (12 of 21 quality failures). The retry turn must be
            # self-sufficient: previous SQL + exact error + an explicit
            # reminder that only the AVAILABLE TABLES above may be used.
                      
            
            previous_block = (
                f"YOUR PREVIOUS SQL\n-----------------\n{previous_sql}\n\n"
                if previous_sql else ""
            )
            messages.append({
                "role": "assistant",
                "content": previous_sql if previous_sql else "-- previous SQL failed",
            })
            messages.append({
                "role": "user",
                "content": f"""
        Your previous SQL failed.

        {previous_block}DATABASE ERROR
        --------------
        {error_feedback}

        Analyse the error carefully, then correct YOUR PREVIOUS SQL above.

        STRICT CONSTRAINTS for the correction:
        - Use ONLY table names from the AVAILABLE TABLES list in the first message.
        - NEVER use placeholder names such as table1, table2, main_table,
        your_table_name -- these do not exist in the database.
        - Keep the same intent as the original QUESTION; fix only what the
        error message indicates is wrong.

        Verify:
        - table names (must appear in AVAILABLE TABLES)
        - column names (must appear in the SCHEMA CONTEXT)
        - aliases
        - joins
        - foreign keys
        - MariaDB syntax

        Return ONLY the corrected SQL query.
        """,
                    })

        logger.info(f"generate() using LLM={self.llm.__class__.__name__}")
        logger.info(f"generate() question={question}")
        logger.info(f"generate() schema_length={len(schema_context)}")
        
        

        start = time.time()
        
        logger.warning(
            "\n========== PROMPT ==========\n"
            f"{user_msg[:4000]}"
            "\n============================"
        )
        
       
        logger.warning(
            "AUTHORITATIVE_CHAIN_PRESENT=%s",
            "AUTHORITATIVE JOIN CHAIN" in user_msg
        )



        self.parent_pipeline.set_langfuse_trace_step("NORMALIZE")
        raw_sql = self.llm.complete(self._system, messages, max_tokens=1024)

        elapsed = time.time() - start
        logger.info(f"LLM generation completed in {elapsed:.2f}s")
        
        logger.warning(
            "\n========== RAW SQL ==========\n"
            f"{raw_sql}\n"
            "============================="
        )
        
        logger.warning(
            "RAW_SQL_LENGTH=%s",
            len(raw_sql)
        )
        
        logger.warning(
            "RAW_SQL_FIRST_100=%s",
            raw_sql[:100]
        )
        
        

        generated_sql = self._clean_sql(raw_sql)
        
        generated_sql = self._validate_sql_joins_against_fk_paths(
            generated_sql,
            validated_context,
        )
        
        logger.warning("BEFORE_TABLE_VALIDATION")
        
        generated_sql = self._validate_sql_tables_against_reachable_tables(
            generated_sql,
            validated_context,
        )
        
        logger.warning(
            "AFTER_TABLE_VALIDATION sql=%r type=%s",
            generated_sql,
            type(generated_sql).__name__,
            )
        
        generated_sql = self._validate_entity_filters(
            generated_sql,
            validated_context,
        )
        
        logger.warning(
            "AFTER_ENTITY_FILTER_VALIDATION sql=%r type=%s",
            generated_sql,
            type(generated_sql).__name__,
            )
        
        
        if (
            validated_context
            and
            validated_context.relationship_status
                == "RelationshipStatus.LOGICAL_AND"
        ):
            logger.warning(
                "LOGICAL_AND_SQL=%s",
                generated_sql
            )
        
        

        logger.warning(
            "\n========== GENERATED SQL ==========\n"
            f"{generated_sql}\n"
            "=================================="
        )

        generated_sql = self._post_process_sql(
            generated_sql,
            validated_context,
        )

        logger.warning(
            "\n========== GENERATED SQL ==========\n"
            f"{generated_sql}\n"
            "=================================="
        )

        #not self.parent_pipeline.force and 
        if not error_feedback and self._needs_simplification_retry(
            question, generated_sql, plan
        ):
            logger.info(
                "Detected unjustified JOIN for a simple listing question — "
                "retrying with a simplification instruction."
            )

            messages.append({"role": "assistant", "content": raw_sql})
            messages.append({
                "role": "user",
                "content": (
                    "Your query added a JOIN, but the question only asks to "
                    "list/show/display rows from a single table without "
                    "requesting related data from another table. "
                    "Regenerate the SIMPLEST possible query: SELECT directly "
                    "from the single most relevant table, with NO JOIN, "
                    "unless the question explicitly requires combining data "
                    "from multiple sources. Return ONLY the corrected SQL."
                ),
            })

            self.parent_pipeline.set_langfuse_trace_step("GENERATE")
            raw_sql = self.llm.complete(self._system, messages, max_tokens=1024)
            generated_sql = self._clean_sql(raw_sql)

            logger.info(f"RAW_SQL_DEBUG_retry={raw_sql!r}")
            logger.info(f"CLEANED_SQL_DEBUG_retry={generated_sql!r}")

            generated_sql = self._post_process_sql(
                generated_sql,
                validated_context,
            )
            
            logger.warning(
                "AFTER_ENFORCE_LOGICAL_AND=%s",
                generated_sql,
            )
            
            logger.info(f"generated_sql_after_simplification_retry={generated_sql}")

        return generated_sql
    
    
    def _enforce_logical_and(
                self,
                sql: str,
                validated_context,
            ) -> str:

        logger.warning(
            "ENTERING_ENFORCE_LOGICAL_AND"
        )

        if (
            validated_context
            and
            str(validated_context.relationship_status)
            == "RelationshipStatus.LOGICAL_AND"
        ):

            sql_lower = sql.lower()

            blocked_patterns = [
                " join ",
                " exists ",
                " in (select ",
                " from (select ",
            ]

            for pattern in blocked_patterns:

                if pattern in sql_lower:

                    logger.warning(
                        "LOGICAL_AND_BLOCKED_PATTERN=%s",
                        pattern,
                    )

                    tables = sorted(
                        set(
                            t
                            for group in validated_context.predicate_groups
                            for t in group
                        )
                    )

                    return (
                        "IMPOSSIBLE: "
                        "No validated relationship exists between "
                        f"{', '.join(tables)}."
                    )

            return sql

        # IMPORTANT
        return sql