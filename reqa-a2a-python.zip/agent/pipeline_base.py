from dataclasses import dataclass, field
import traceback

from agent.grounding_context import GroundingContext, GroundingResult

from query_analysis.relationship_validator import (
    RelationshipValidator
)
from query_analysis.validated_query_context_builder import (
    build_validated_query_context
)

# https://www.canada.ca/en/library-archives/collection/research-help/military-history/military-abbreviations.html

from agent.sql_generator import SQLValidationError
# v3.0 (enriched KB): the catalog short-circuit executes a KB query
# verbatim, and the KB now contains queries that are invalid or destructive
# BY DESIGN (evaluation set). Both guards below are applied before any
# catalog SQL is trusted.
from RAG.knowledge_base import query_class, is_readonly_select, POSITIVE
# v3.1: the negative families of the enriched KB are turned into two
# capabilities -- refuse instantly what the schema provably cannot answer,
# and repair a failed attempt with the KB's documented guidance.
from RAG.knowledge_base import best_negative_match, repair_hint
from agent.dry_run import DatabaseConnectionError as DryRunConnectionError
from agent.executor import DatabaseConnectionError as ExecutorConnectionError

# Semantic-consistency scorer (3rd confidence component). Fail-safe import:
# if agent/sem_conf.py is missing from a deployment, confidence degrades
# gracefully to a neutral sem_conf=1.0 instead of crashing the pipeline.
try:
    from agent.sem_conf import _compute_sem_conf
except ImportError:
    def _compute_sem_conf(question, sql, target_tables):
        return 1.0

import logging
import os
import re
import time
from functools import lru_cache
from typing import Optional
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("PIPELINE")
logger.setLevel(logging.INFO)
logger.disabled = False

#=======================   config.json  ====================================================
from config.settings import get_settings
#===========================================================================================

from query_analysis.relationship_validator import (
    RelationshipStatus,
    RelationshipValidator
)

settings = get_settings()

from agent.exceptions import (
    SchemaLimitation,
    AnswerabilityStatus,
)

@dataclass
class PipelineResult:
    success: bool
    answer: str

    answerability_status: (
        AnswerabilityStatus
    ) = AnswerabilityStatus.FULL

    sql: str = ""

    rows: list = field(
        default_factory=list
    )

    row_count: int = 0

    attempts: int = 0

    error: str = ""

    explanation: dict = field(
        default_factory=dict
    )

    debug: dict = field(
        default_factory=dict
    ) 




class PipelineBase:
    """
    End-to-end agentic pipeline (faithful to the architecture diagram):

    User Query
      → [0] Intent Classification  (data_query vs schema_exploration vs unclear)
           ↺ schema_exploration / unclear → answered directly, no SQL generated
      → [1] Embedding + Schema RAG  (retrieve relevant table schemas from Qdrant)
      → [2] SQL Generator  (LLM generates SQL with schema context + all table names)
      → [3] Static Check   (sqlglot — syntax + SELECT-only enforcement)
           ↺ retry with error feedback up to max_retries
      → [4] EXPLAIN dry-run  (MariaDB EXPLAIN — no data touched)
           ↓ failure → Circuit Breaker → Graceful Failure
      → [5] DB Execution
           ↓ failure → Circuit Breaker → Graceful Failure
      → [6] Renderer  (LLM formats results as natural language)
      → Final Answer
    """

    def __init__( self, schema_rag, sql_generator, allow_reformulation = False  ):            
        self.schema_rag = schema_rag
        self.sql_generator = sql_generator
        self.allow_reformulation = False
        logger.info( "agent/pipeline_base.py.__init__()" )


    #
    #   Langfuse trace utilities. Use these to help read the LangFuse traces in http page
    #
    #       Set the query for this whole request.
    #       Then at each step, set the step name ex: Plan
    #       Also mark the retries.
    #      
    #

    #
    #   set_langfuse_trace_query()
    #           
    def set_langfuse_trace_query(self, name ):
        self.sql_generator.llm.set_langfuse_trace_query(name)

    #
    #
    #
    def set_langfuse_trace_tag(self, tag ):
        self.sql_generator.llm.set_langfuse_trace_tag(tag)

    #
    #   langfuse_trace_step()
    #  
    def set_langfuse_trace_step(self, step ):
        self.sql_generator.llm.set_langfuse_trace_step(step)
        

    #
    #   set_langfuse_trace_attempt()
    #  
    def set_langfuse_trace_attempt(self,  attempt = 1 ):        
        self.sql_generator.llm.set_langfuse_trace_attempt(attempt)


    #
    #   Set the complete current request before use 
    #   There are many possible options
    #   for example: { "num_rated_rules" : 3 } to switch opn / off the rated rules per request
    #
    def set_current_request(self, req):
        self.current_request = req


    #
    #   overridable function called at the beginning of run()
    #
    def pre_run(self, question: str, progress_callback=None, allow_reformulation: bool = True, **kwargs):
        
        options = kwargs.get( "options", {} )
        debug = options.get( "debug", False )
        force = options.get( "force", False )
        pass
        


    def run(self, question: str, progress_callback=None,
            allow_reformulation: bool = True, **kwargs) -> PipelineResult:
        """
        progress_callback: optional callable(dict) -> None, invoked at each
        key stage (schema_rag, intent_classification, sql_generation,
        static_check, explain, execution, rendering) with a small dict
        {"stage": ..., "attempt": ..., "of": ...}. Used by api.py's
        background-job endpoints to expose live progress to the UI via
        polling. Entirely optional and side-effect-free when omitted --
        existing callers (e.g. /tasks/send) are unaffected. Never allowed
        to crash the pipeline: any exception raised by the callback itself
        is swallowed (a broken progress reporter must not break the actual
        query).        
        """
    
        self.pre_run(question, None, allow_reformulation, **kwargs)
   
     
        debug_rval = {} # Returned value of debug
        options = kwargs.get( "options", {} )
        debug = options.get( "debug", False )
        force = options.get( "force", False )
        langfuse_tag = options.get( "langfuse_tag", "test" )
        logger.info( f"agent/pipeline run({question}, {kwargs})" )
  
        sql = self.sql_generator.generate(
                        question, "", [], None,
                        previous_sql=None,
                    )


        answer = sql
        rows = []


        logger.info("SUCCESS")
        return PipelineResult(
            success=True,
            answer=answer,
            sql=sql,
            rows=rows,
            row_count=len(rows),
            attempts=attempt,
            explanation=explanation,
            debug=debug_rval
        )

        logger.info("MAX RETRIES")    

        return PipelineResult(
            success=False,
            answer="Could not generate a valid query after multiple attempts.",
            error=error_feedback,
            attempts=self.max_retries,
            explanation=explanation,
            debug=debug_rval
        )



