from dataclasses import dataclass, field
from typing import List, Dict, Any, Set




@dataclass
class GroundingContext:

    original_question: str

    resolved_terms: List[str] = field(default_factory=list)

    resolved_entities: List[Dict[str, Any]] = field(default_factory=list)

    grounded_tables: Set[str] = field(default_factory=set)

    grounded_columns: List[str] = field(default_factory=list)

    grounded_values: List[str] = field(default_factory=list)

    metadata: Dict[str, Any] = field(default_factory=dict)
    
    resolved_tables: Set[str] = field(default_factory=set)

    mandatory_tables: Set[str] = field(default_factory=set)


  
  
    def add_grounded_tables(
        self,
        tables: set[str]
        ):
        
        self.grounded_tables.update(tables)

    
    def add_resolved_tables(
        self,
        tables: set[str]
    ):
        self.resolved_tables.update(tables)


    def refresh_mandatory_tables(
        self
    ):
        self.mandatory_tables = (
            self.grounded_tables
            | self.resolved_tables
        )

        
    def has_table(
        self,
        table_name: str
    ) -> bool:

        return (
            table_name
            in self.mandatory_tables
        )

        
    def is_grounded_table(
        self,
        table_name: str
    ) -> bool:

        return (
            table_name
            in self.grounded_tables
        )
        
        
    def audit(self):

        return {
            "grounded_tables":
                sorted(self.grounded_tables),

            "resolved_tables":
                sorted(self.resolved_tables),

            "mandatory_tables":
                sorted(self.mandatory_tables),
        }
        
    def build_prompt_block(self):

        parts = []

        if self.mandatory_tables:

            parts.append(
                "-- MANDATORY TABLES --\n"
                + "\n".join(
                    f"-- {t}"
                    for t in sorted(self.mandatory_tables)
                )
            )

        return "\n\n".join(parts)
            
    
    
        
        
    

    def summary(self):

        return (
            f"entities={len(self.resolved_entities)} "
            f"tables={self.grounded_tables} "
            f"columns={self.grounded_columns}"
        )
        
    def dump(self):

        return {
            "resolved_terms": self.resolved_terms,
            "resolved_entities": self.resolved_entities,
            "grounded_tables": self.grounded_tables,
            "grounded_columns": self.grounded_columns,
            "grounded_values": self.grounded_values,
            "metadata": self.metadata,
        }
        
        
@dataclass
class GroundingResult:

    grounded_tables: Set[str] = field(
        default_factory=set
    )

    resolved_tables: Set[str] = field(
        default_factory=set
    )

    mandatory_tables: Set[str] = field(
        default_factory=set
    )

    term_mapping_block: str = ""

    entity_reference_block: str = ""

    entity_resolution_block: str = ""

    graph_context: str = ""
    

from enum import Enum


class QueryType(str, Enum):
    SINGLE_ENTITY = "SINGLE_ENTITY"

    MULTI_ENTITY_DESCRIPTIVE = (
        "MULTI_ENTITY_DESCRIPTIVE"
    )

    RELATIONSHIP = "RELATIONSHIP"

    UNKNOWN = "UNKNOWN"
 

@dataclass
class QueryAnalysisResult:

    original_query: str

    literals: list[str]

    noun_chunks: list[str]

    business_concepts: list[str]

    relationship_verbs: list[str]

    query_type: QueryType

    confidence: float
    
    