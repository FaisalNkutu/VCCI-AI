
from __future__ import annotations

import difflib
import re
from functools import lru_cache

from RAG.knowledge_base import load_kb
import logging

logger = logging.getLogger(__name__)


_STOP = {
    "the", "a", "an", "of", "for", "in", "on", "to", "and", "or", "is",
    "are", "was", "were", "what", "which", "who", "when", "where", "why",
    "show", "list", "display", "give", "get", "me", "please", "all",
    "every", "each", "per", "how", "many", "much", "with", "without",
    "from", "by", "their", "its", "that", "this", "these", "those",
    "breakdown", "total", "count", "number", "average", "sum", "min",
    "max", "top", "most", "least", "highest", "lowest", "first", "last",
    "ignoring", "excluding", "except", "including", "only",
    "rows", "row", "records", "record", "data", "values", "value",
    "table", "tables", "database", "can", "you", "do", "does", "did",
    "have", "has", "had", "more", "less", "than", "between", "group",
    "grouped", "sorted", "order", "ordered", "distinct", "different",
    "new", "old", "recent", "latest",
}


_MAX_REFS_PER_TERM = 10


# ---------------------------------------------------------------------------
# WordNet synonym bridge (v3.4, optional)
# ---------------------------------------------------------------------------


def _ref_priority(ref: str) -> tuple:

    if re.match(r"table `[^`]+`$", ref):
        return (0, len(ref))

    if "(label)" in ref:
        return (1, len(ref))

    if "(keyword)" in ref:
        return (2, len(ref))

    if ref.startswith("column "):
        return (3, len(ref))

    return (4, len(ref))


@lru_cache(maxsize=1)
def _spacy_nlp():

    try:
        import spacy

        print("SPACY LOADED")

        return spacy.load(
            "en_core_web_sm",
            disable=["parser", "ner", "tok2vec"]
        )

    except Exception as e:

        print(f"SPACY FAILED: {e}")

        return None


@lru_cache(maxsize=4096)
def _lemma(term: str) -> str:

    nlp = _spacy_nlp()

    if nlp is None:

        logger.info(
            f"LEMMA DISABLED for {term}"
        )

        return ""

    try:
        print(f"SPACY LEMMATIZING: {term}")


        doc = nlp(term)

        lem = (
            doc[0].lemma_.lower()
            if len(doc)
            else ""
        )

        logger.info(
            f"LEMMA: {term} -> {lem}"
        )

        return (
            lem
            if lem and lem != term
            else ""
        )

    except Exception:

        return ""


@lru_cache(maxsize=1)
def _local_synonyms() -> dict:
    """Optional OFFLINE synonym map {term: [synonyms...]} -- e.g. the
    military subset extracted from WordNet (military_synonyms.json).
    Path: REQA_LOCAL_SYNONYMS env var, else military_synonyms.json next
    to this module, else RAG/military_synonyms.json. Works WITHOUT nltk:
    on an air-gapped deployment this layer alone provides the domain
    synonyms. Missing/invalid file -> empty map (fail-safe)."""
    import json
    import os
    from pathlib import Path
    candidates = [os.getenv("REQA_LOCAL_SYNONYMS", "")]
    here = Path(__file__).resolve().parent
    candidates += [str(here / "military_synonyms.json"),
                   str(here.parent / "RAG" / "military_synonyms.json")]
    for cand in candidates:
        try:
            if cand and Path(cand).is_file():
                data = json.loads(Path(cand).read_text(encoding="utf-8"))
                return {str(k).lower(): [str(v).lower() for v in vals]
                        for k, vals in data.items() if vals}
        except Exception:
            continue
    return {}


@lru_cache(maxsize=1)
def _wordnet():
    """The NLTK wordnet corpus, or None when nltk/corpus is unavailable.
    Never raises: the bridge is an enhancement, not a dependency."""
    try:
        from nltk.corpus import wordnet as wn
        wn.synsets("test")          # force-load; raises if corpus missing
        return wn
    except Exception:
        return None


@lru_cache(maxsize=2048)
def _synonyms_of(term: str) -> tuple:
    """Synonyms of a term from BOTH sources, lowercased, multiword lemmas
    normalized ('armed_forces' -> 'armed forces'):
      1. the local offline map (military_synonyms.json) -- domain terms,
         available even without nltk;
      2. full WordNet (when installed) -- general English + derivations.
    Empty tuple when neither source knows the term."""
    out: set = set(_local_synonyms().get(term, ()))
    wn = _wordnet()
    if wn is None:
        out.discard(term)
        return tuple(sorted(out))
    try:
        for syn in wn.synsets(term):
            for lemma in syn.lemmas():
                out.add(lemma.name().replace("_", " ").lower())
                # Derivationally related forms: "expend" -> "expenditure"
                for rel in lemma.derivationally_related_forms():
                    out.add(rel.name().replace("_", " ").lower())
        # The base lemma of an inflected form ("spent" -> "spend")
        base = wn.morphy(term)
        if base and base != term:
            out.add(base)
            out.update(_synonyms_of(base))
    except Exception:
        return ()
    out.discard(term)
    return tuple(sorted(out))


def _content_terms(question: str) -> list[str]:
    words = [
        w for w in re.findall(r"[a-zA-Z][a-zA-Z_]+", (question or "").lower())
        if w not in _STOP and len(w) >= 3
    ]
    return list(dict.fromkeys(words))  # dedup, keep order


@lru_cache(maxsize=1)
def _schema_vocab() -> dict[str, frozenset]:
    """{lowercased term -> schema element references}, built once from the KB."""
    kb = load_kb()
    vocab: dict[str, set] = {}

    def add(key, ref: str) -> None:
        key = str(key or "").strip().lower()
        if len(key) >= 3:
            vocab.setdefault(key, set()).add(ref)

    for table, entry in kb.items():
        add(table, f"table `{table}`")
        add(entry.get("label", ""), f"table `{table}` (label)")
        for kw in entry.get("keywords") or []:
            add(kw, f"table `{table}` (keyword)")
        for col, cd in (entry.get("columns") or {}).items():
            add(col, f"column {table}.{col}")
            allowed = (cd or {}).get("allowed_values") or {}
            if isinstance(allowed, dict):
                for code, meaning in allowed.items():
                    # decoded meaning ("resupply event") AND raw code
                    # ("RESUPPLY") both resolve to the executable filter.
                    add(meaning, f"{table}.{col} = '{code}'  ({meaning})")
                    add(code, f"{table}.{col} = '{code}'")

    return {k: frozenset(v) for k, v in vocab.items()}


def ground_terms(question: str, max_matches: int = 6) -> dict:
    """
    Resolve the question's content words against the schema vocabulary.

    Returns:
    {
        "mapped": {term: [refs]},
        "quoted_entities": [entity_names],
        "unresolved": [terms]
    }

    mapped           -> inject into schema context as explicit guidance
    quoted_entities  -> literal entities explicitly mentioned in quotes
    unresolved       -> terms not mapped to the schema vocabulary
    """

    result = {
        "mapped": {},
        "quoted_entities": [],
        "unresolved": []
    }

    try:
        vocab = _schema_vocab()

        logger.info(
            f"activity in vocab={'activity' in vocab}"
        )

        logger.info(
            f"objective in vocab={'objective' in vocab}"
        )

        logger.info(
            f"action in vocab={'action' in vocab}"
        )

    except Exception:
        return result

    keys = list(vocab.keys())
    q_lower = (question or "").lower()

    # ======================================================
    # QUOTED ENTITY EXTRACTION
    # ======================================================

    quoted_entities = re.findall(
        r'"([^"]+)"',
        question or ""
    )

    result["quoted_entities"] = quoted_entities

    logger.info(
        f"QUOTED_ENTITIES={quoted_entities}"
    )

    # Optional:
    # expose quoted entities to the prompt so the LLM knows
    # they are literal values and must not be modified.
    for entity in quoted_entities:

        result["mapped"][entity] = [
            f'literal entity name "{entity}"'
        ]

    # ======================================================
    # MULTI-WORD VOCAB MATCHING
    # ======================================================

    for key in keys:

        if (" " in key or "_" in key):

            if (
                key in q_lower
                or key.replace("_", " ") in q_lower
            ):

                refs = vocab[key]

                if len(refs) <= _MAX_REFS_PER_TERM:

                    result["mapped"][key] = (
                        sorted(refs)[:max_matches]
                    )

    # ======================================================
    # SINGLE TERM GROUNDING
    # ======================================================
    
   
    

    terms = list(_content_terms(question))

    logger.warning(
        f"CONTENT_TERMS={terms}"
    )

    for term in terms:

        if any(term in k for k in result["mapped"]):
            continue

        refs: set = set()
        via = ""
        candidates = set()

        if term in vocab:

            refs |= vocab[term]

        else:

            lem = _lemma(term)

            candidates = {
                term,
                lem,
            }

            if term.endswith("ies"):
                candidates.add(term[:-3] + "y")

            elif term.endswith("s"):
                candidates.add(term[:-1])
                
            logger.warning(
                f"TERM={term} "
                f"LEMMA={lem} "
                f"CANDIDATES={sorted(c for c in candidates if c)}"
            )

            logger.info(
                f"TERM={term} "
                f"CANDIDATES={sorted(c for c in candidates if c)}"
            )

            for cand in candidates:

                if cand and cand in vocab:
                    
                    logger.warning(
                        f"TERM_MATCH "
                        f"TERM={term} "
                        f"MATCHED={cand}"
                    )
                    

                    refs |= vocab[cand]

                    if cand == lem:
                        via = lem

                    break

            if not refs:

                syn_candidates = list(
                    _synonyms_of(term)
                )

                if lem:

                    syn_candidates += [
                        s
                        for s in _synonyms_of(lem)
                        if s not in syn_candidates
                    ]

                for syn in syn_candidates:

                    hit = (
                        syn if syn in vocab
                        else syn.rstrip("s")
                        if syn.rstrip("s") in vocab
                        else syn + "s"
                        if syn + "s" in vocab
                        else None
                    )

                    if (
                        hit
                        and len(vocab[hit])
                        <= _MAX_REFS_PER_TERM
                    ):
                        refs |= vocab[hit]
                        via = hit
                        break

            if not refs:

                for close in difflib.get_close_matches(
                    term,
                    keys,
                    n=3,
                    cutoff=0.84
                ):
                    refs |= vocab[close]

        if refs and len(refs) <= _MAX_REFS_PER_TERM:

            logger.info(
                f"TERM={term} REFS={sorted(refs)}"
            )

            logger.info(
                f"BEFORE_TRUNCATION={sorted(refs)}"
            )

            mapped = sorted(
                refs,
                key=_ref_priority
            )[:max_matches]

            logger.info(
                f"AFTER_TRUNCATION={mapped}"
            )

            if via:

                mapped = [
                    f"{r}  (via synonym '{via}')"
                    for r in mapped
                ]

            result["mapped"][term] = mapped

        elif not refs:

            result["unresolved"].append(term)

    return result



import spacy

nlp = spacy.load("en_core_web_sm")

def generate_forms(term: str) -> list[str]:
    """
    Return linguistic variants used by term grounding.
    """

    forms = []

    original = term.strip()
    forms.append(original)

    doc = nlp(original)

    for token in doc:

        lemma = token.lemma_.strip()

        if lemma and lemma not in forms:
            forms.append(lemma)

    return forms

