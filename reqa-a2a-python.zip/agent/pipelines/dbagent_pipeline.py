
import sys

from dataclasses import dataclass, field
import traceback

sys.path.insert(0,"../../")
sys.path.insert(0,"../")
sys.path.insert(0,"./")

from pydantic import BaseModel
from qdrant_client import QdrantClient


from agent.embedder import Embedder
from agent.pipeline import Pipeline, _build_llm
from agent.pipelines.dbagent_sql_generator import SQLValidationError

# v3.0 (enriched KB): the catalog short-circuit executes a KB query
# verbatim, and the KB now contains queries that are invalid or destructive
# BY DESIGN (evaluation set). Both guards below are applied before any
# catalog SQL is trusted.
from RAG.knowledge_base import query_class, is_readonly_select, POSITIVE
# v3.1: the negative families of the enriched KB are turned into two
# capabilities -- refuse instantly what the schema provably cannot answer,
# and repair a failed attempt with the KB's documented guidance.
from RAG.knowledge_base import best_negative_match, repair_hint
from agent.dry_run import DatabaseConnectionError as DryRunConnectionError
from agent.executor import DatabaseConnectionError as ExecutorConnectionError
from agent.pipelines.dbagent_schema_rag import DBAgentSchemaRag
from agent.pipelines.dbagent_sql_generator import DBAgentSQLGenerator
from agent.static_check import StaticChecker
from agent.dry_run import DryRunner
from agent.executor import Executor
from agent.renderer import Renderer
from agent.circuit_breaker import CircuitBreaker

# Semantic-consistency scorer (3rd confidence component). Fail-safe import:
# if agent/sem_conf.py is missing from a deployment, confidence degrades
# gracefully to a neutral sem_conf=1.0 instead of crashing the pipeline.
try:
    from agent.sem_conf import _compute_sem_conf
except ImportError:
    def _compute_sem_conf(question, sql, target_tables):
        return 1.0

import logging
import os
import re
from typing import Optional
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("PIPELINE")
logger.setLevel(logging.INFO)
logger.disabled = False
from dotenv import load_dotenv

#=======================   config.json  ====================================================
from config.settings import get_settings
#===========================================================================================



def _compute_confidence(schema_chunks, attempt: int, max_retries: int, success: bool,
                        question: str = "", sql: str = "") -> dict:
    """
    Confidence = 0.3 × rag_conf + 0.4 × gen_conf + 0.3 × sem_conf

    rag_conf : mean cosine similarity of RAG-retrieved tables (fastembed, 0-1).
               Measures whether the right schema was found.

    gen_conf : linear decay per retry — (max_retries - (attempt-1)) / max_retries.
               1st attempt = 1.00, 2nd = 0.67, 3rd = 0.33. 0.0 on failure.
               Measures whether the LLM generated correct SQL immediately.

    sem_conf : deterministic semantic-consistency score (agent/sem_conf.py).
               Synonym-aware intent checks (COUNT/AVG/MAX/MIN/SUM/recency/
               duration/DISTINCT/grouping) + target-table presence.
               Measures whether the SQL plausibly ANSWERS the question --
               catches silent wrong-answer cases that execute fine (e.g.
               "How long did each task last?" answered by a bare
               SELECT act_task_id, observed in real runs). A 1.0 means
               "nothing manifestly inconsistent", not "proven correct";
               below 1.0 is a reliable inconsistency signal.
    """
    if not success:
        return {"score": 0.0, "score_strict": 0.0, "rag_conf": 0.0, "gen_conf": 0.0,
                "sem_conf": 0.0, "target_table": ""}

    rag_scores = [t.cosine_score for t in schema_chunks if t.score > 0]
    rag_conf   = round(sum(rag_scores) / len(rag_scores), 4) if rag_scores else 0.5
    gen_conf   = round((max_retries - (attempt - 1)) / max_retries, 4)

    # FP-minimisation (target-table selection).
    #
    # The semantic target-table check must key on the SINGLE most-relevant
    # table, NOT the whole retrieved set. Previously target_tables held every
    # RAG-retrieved table (up to ~25), so sem_conf's "target present in the
    # SQL" test was trivially satisfied by ANY of them: a query over
    # act/fac/org/capab scored high even though the real target abs_point was
    # absent from the SQL entirely (observed in real runs). Passing only the
    # top-scored table makes a wrong-table answer actually collapse sem_conf.
    try:
        ranked = [t for t in schema_chunks if getattr(t, "score", 0) > 0]
        target_tables = [max(ranked, key=lambda t: t.score).table_name] if ranked else []
        sem_conf = _compute_sem_conf(question, sql, target_tables)
    except Exception:
        target_tables = []
        sem_conf = 1.0  # neutral on any unexpected failure

    # Deterministic veto: a data query answered by a metadata statement
    # (SHOW / DESCRIBE / EXPLAIN) never returns the requested rows, so it
    # cannot be a correct answer regardless of what sem_conf computed. This
    # catches the "intent leak" false positives where a data question is
    # answered by SHOW TABLES and still reported as a confident success.
    if re.match(r"^\s*(show|describe|desc|explain)\b", sql or "", re.IGNORECASE):
        sem_conf = min(sem_conf, 0.2)

    # Two complementary aggregations, both reported:
    #
    #   score        (additive)       : 0.3·rag + 0.4·gen + 0.3·sem
    #     -- each component is one vote among three; a wrong semantic
    #        penalty costs at most 0.3. Drives the UI banner. Safe while
    #        the semantic heuristics are still young.
    #
    #   score_strict (multiplicative) : (0.4·rag + 0.6·gen) × sem
    #     -- sem_conf acts as a proportional veto: a technically perfect
    #        answer that doesn't address the question collapses toward 0.
    #        Reported alongside so eval runs can compare the two
    #        distributions on real data before deciding whether to
    #        promote it to the main score.
    score        = round(0.3 * rag_conf + 0.4 * gen_conf + 0.3 * sem_conf, 4)
    score_strict = round((0.4 * rag_conf + 0.6 * gen_conf) * sem_conf, 4)

    return {
        "score": score,
        "score_strict": score_strict,
        "rag_conf": rag_conf,
        "gen_conf": gen_conf,
        "sem_conf": sem_conf,
        "target_table": target_tables[0] if target_tables else "",
    }

def _build_xai(question: str, sql: str, schema_chunks, attempt: int,
               attempts_detail: list, llm=None) -> dict:
    """
    Post-hoc explainability block attached to explanation["xai"]:

      table_usage     : for every RAG-retrieved table -- was it actually used
                        in the SQL, its raw cosine similarity, and HOW it got
                        retrieved (vector similarity vs boost/rescue vs
                        fk-expansion/lexical). Deterministic, zero cost.
      counterfactuals : plain-language "this answer depended on X" /
                        "Y was retrieved but unused" notes, derived from
                        table_usage + the retry history. Deterministic.
      sql_rationale   : optional LLM self-explanation of WHY the SQL uses
                        these tables/joins/filters. Costs one extra LLM
                        call, so it is OFF by default -- enable with env
                        REQA_XAI_RATIONALE=1. Never blocks the answer:
                        any failure degrades to None.
    """
    xai = {"table_usage": [], "counterfactuals": [], "sql_rationale": None}

    try:
        for t in schema_chunks or []:
            name = getattr(t, "table_name", "") or ""
            if not name:
                continue
            used = bool(re.search(rf"\b{re.escape(name)}\b", sql or "", re.IGNORECASE))
            score = float(getattr(t, "score", 0) or 0)
            cosine = float(getattr(t, "cosine_score", 0) or 0)
            if score <= 0:
                origin = "fk-expansion/lexical"
            elif score - cosine > 0.3:
                origin = "boost/rescue"       # score inflated far above raw similarity
            else:
                origin = "vector"
            xai["table_usage"].append({
                "name": name, "used_in_sql": used,
                "cosine": round(cosine, 4), "score": round(score, 4),
                "origin": origin,
            })

        for u in xai["table_usage"]:
            if u["used_in_sql"] and u["origin"] == "boost/rescue":
                xai["counterfactuals"].append(
                    f"The SQL relies on table '{u['name']}', whose raw similarity was only "
                    f"{u['cosine']*100:.0f}% -- it was retrieved thanks to the sample-query "
                    f"boost/rescue. Without that mechanism, this answer would likely have failed."
                )
            if u["used_in_sql"] and u["origin"] == "fk-expansion/lexical":
                xai["counterfactuals"].append(
                    f"Table '{u['name']}' was injected by FK-expansion/lexical fallback "
                    f"(no measured similarity) and the SQL uses it."
                )
        unused = [u["name"] for u in xai["table_usage"] if not u["used_in_sql"]]
        if unused:
            xai["counterfactuals"].append(
                "Retrieved but not used in the SQL: " + ", ".join(unused) + "."
            )
        if attempt > 1 and attempts_detail:
            failed_stages = [a.get("failed_at") for a in attempts_detail if a.get("failed_at")]
            if failed_stages:
                xai["counterfactuals"].append(
                    f"The accepted SQL only emerged at attempt {attempt}, after "
                    f"{attempt - 1} rejected attempt(s) (failed at: {', '.join(failed_stages)}). "
                    f"The error feedback loop was decisive for this answer."
                )
    except Exception:
        pass  # deterministic XAI must never break the pipeline

    if os.getenv("REQA_XAI_RATIONALE", "0") == "1" and llm is not None:
        try:
            rationale = llm.complete(
                "You explain SQL queries. In at most 3 short bullet points, explain WHY "
                "the query uses these tables, joins and filters to answer the question. "
                "Be factual and concise. No preamble.",
                [{"role": "user", "content": f"Question: {question}\n\nSQL:\n{sql}"}],
                max_tokens=200,
            )
            xai["sql_rationale"] = (rationale or "").strip() or None
        except Exception:
            xai["sql_rationale"] = None

    return xai


def _llm_reformulations(question: str, schema_chunks, llm, error_feedback: str = "",
                        max_n: int = 3) -> list:
    """
    Ask the LLM to rewrite an unclear/failed user question into up to
    `max_n` clearer variants, grounded in the retrieved tables' actual
    vocabulary (table + column names) so the rewrites are likely
    answerable -- unlike the user's original phrasing.

    Complements (does not replace) the catalog suggestions from
    sample_queries: catalog items are GUARANTEED answerable but may drift
    from what the user meant; LLM rewrites stay close to the user's intent
    but are NOT guaranteed to succeed. The UI labels them accordingly.

    Cost: one extra LLM call, on FAILURE paths only (which already burned
    up to 3 calls). Disable with REQA_LLM_REFORMULATE=0. Skipped when the
    failure looks like an infrastructure outage (the LLM is unreachable
    anyway -- no point adding a hanging call on top).
    """
    if os.getenv("REQA_LLM_REFORMULATE", "1") != "1" or llm is None:
        return []
    err = (error_feedback or "").lower()
    if "connection" in err or "circuit breaker" in err or "max retries exceeded" in err:
        return []

    try:
        # Light schema vocabulary: top tables + a handful of real columns
        vocab_lines = []
        for t in (schema_chunks or [])[:3]:
            name = getattr(t, "table_name", "") or ""
            cols = [c.get("name") for c in (getattr(t, "payload", {}) or {}).get("columns", [])
                    if isinstance(c, dict) and c.get("name")][:8]
            if name:
                vocab_lines.append(f"- {name}: {', '.join(cols) if cols else '(columns unknown)'}")
        vocab = "\n".join(vocab_lines) or "(no table context available)"

        raw = llm.complete(
            "A user asked a database question that could not be answered as phrased. "
            "Rewrite it as up to {n} clearer, more specific questions that are likely "
            "answerable over the tables below. Stay faithful to the user's intent. "
            "Use the exact table/column vocabulary provided. "
            "Output ONLY the questions, one per line, no numbering, no commentary.".format(n=max_n),
            [{"role": "user", "content": f"Original question: {question}\n\nAvailable tables and key columns:\n{vocab}"}],
            max_tokens=180,
        )

        seen, out = set(), []
        for line in (raw or "").splitlines():
            q = re.sub(r"^\s*(?:[-*•]|\d+[.)])\s*", "", line).strip().strip('"')
            if not q or "?" not in q:
                continue
            key = q.lower()
            if key == (question or "").strip().lower() or key in seen:
                continue
            seen.add(key)
            out.append(q)
            if len(out) >= max_n:
                break
        return out
    except Exception:
        return []  # reformulation is an enrichment, never a failure cause


def _combine_suggestions(catalog: list, reformulations: list, max_total: int = 6) -> list:
    """
    Merge the two alternative-question sources into ONE unified, deduplicated
    list for the UI:

      catalog        -- curated sample_queries of the RAG-matched tables:
                        GUARANTEED answerable, shown first, tagged "catalog";
      reformulations -- LLM rewrites of the user's own question: closest to
                        the user's actual intent but not execution-verified,
                        tagged "reformulation", appended after.

    Dedup is done on a normalized form (lowercase, alphanumerics only) so
    that an LLM rewrite that lands on an existing catalog question -- which
    happens often, and is actually a GOOD sign -- doesn't show up twice.
    """
    seen = set()
    combined = []

    def _norm(q: str) -> str:
        return re.sub(r"[^a-z0-9 ]", "", (q or "").lower()).strip()

    for s in catalog or []:
        q = s.get("question", "") if isinstance(s, dict) else str(s)
        key = _norm(q)
        if q and key and key not in seen:
            seen.add(key)
            combined.append({
                "question": q,
                "source": "catalog",
                "table": s.get("table", "") if isinstance(s, dict) else "",
            })
        if len(combined) >= max_total:
            return combined

    for q in reformulations or []:
        key = _norm(q if isinstance(q, str) else "")
        if q and key and key not in seen:
            seen.add(key)
            combined.append({"question": q, "source": "reformulation", "table": ""})
        if len(combined) >= max_total:
            break

    return combined


def _is_ambiguous_retrieval(schema_chunks) -> bool:
    """
    Vague-question detector based on the retrieval signature observed in
    production: an ambiguous question ("show me the stuff") embeds
    moderately close to EVERYTHING and strongly close to NOTHING -- the
    top-k cosine similarities form a flat plateau (e.g. 0.68-0.72, spread
    0.04) instead of showing a clear winner. A real question about a
    specific table shows either a detached leader or a boost/rescue hit.

    Returns True (route to the "unclear" flow: suggestions +
    reformulations instead of answering on a near-arbitrary table) when:
      * at least 3 tables carry a positive cosine score, AND
      * no table was pulled up by boost/rescue (score >> cosine means the
        question closely matched a curated sample question -- a strong
        signal the question IS clear), AND
      * the cosine spread across candidates is below the threshold, AND
      * even the best cosine is unremarkable (< 0.85).

    Tunables via env: REQA_AMBIGUITY_DETECT (default "1"),
    REQA_AMBIGUITY_SPREAD (default "0.06").
    """
    if os.getenv("REQA_AMBIGUITY_DETECT", "1") != "1":
        return False
    try:
        cosines = [float(t.cosine_score) for t in (schema_chunks or [])
                   if getattr(t, "cosine_score", None) and t.cosine_score > 0]
        if len(cosines) < 3:
            return False
        boosted = any(
            (float(getattr(t, "score", 0) or 0) - float(getattr(t, "cosine_score", 0) or 0)) > 0.3
            for t in schema_chunks
        )
        if boosted:
            return False
        spread = max(cosines) - min(cosines)
        threshold = float(os.getenv("REQA_AMBIGUITY_SPREAD", "0.06"))
        return spread < threshold and max(cosines) < 0.85
    except Exception:
        return False


# human-readable stage labels for XAI
_STAGE_LABELS = {
    "llm":          "LLM generation",
    "static_check": "Static check (sqlglot)",
    "explain":      "EXPLAIN dry-run (MariaDB)",
    "execution":    "SQL execution",
    "impossible":   "LLM declared impossible",
}


from agent.pipeline import PipelineResult


def _domain_str(v) -> str:
    if isinstance(v, list):
        return v[0] if v else ""
    return str(v) if v else ""


class DBAgentPipeline(Pipeline):
    """
    End-to-end agentic pipeline (faithful to the architecture diagram):

    User Query
      → [0] Intent Classification  (data_query vs schema_exploration vs unclear)
           ↺ schema_exploration / unclear → answered directly, no SQL generated
      → [1] Embedding + Schema RAG  (retrieve relevant table schemas from Qdrant)
      → [2] SQL Generator  (LLM generates SQL with schema context + all table names)
      → [3] Static Check   (sqlglot — syntax + SELECT-only enforcement)
           ↺ retry with error feedback up to max_retries
      → [4] EXPLAIN dry-run  (MariaDB EXPLAIN — no data touched)
           ↓ failure → Circuit Breaker → Graceful Failure
      → [5] DB Execution
           ↓ failure → Circuit Breaker → Graceful Failure
      → [6] Renderer  (LLM formats results as natural language)
      → Final Answer
    """
    PIPELINE_INSTANCE = None
    def __init__(
        self,
        schema_rag,
        sql_generator,
        static_checker,
        dry_runner,
        executor,
        renderer,
        circuit_breaker,
        max_retries: int = 3,
        allow_reformulation = True
    ):
        super().__init__( schema_rag,
            sql_generator,
            static_checker,
            dry_runner,
            executor,
            renderer,
            circuit_breaker,
            max_retries,
            allow_reformulation )     # reformulate
        logger.info( "agent/pipeline.py.__init__()" )



    @staticmethod    
    def get_pipeline_instance():
       
        logger.info(f"DBAGENT PIPELINE INSTANCE")

        if DBAgentPipeline.PIPELINE_INSTANCE == None:
            load_dotenv()
            settings = get_settings()
            
            _db_params = dict(
                host=settings.DB_HOST,
                port=settings.DB_PORT,
                database=settings.DB_NAME,
                user=settings.DB_USER,
                password=settings.DB_PASSWORD,
            )

            # codestral → SQL generation (specialized)
            # mistral   → natural language rendering (general purpose)
            sql_llm    = _build_llm(settings.ollama_sql_model)
            render_llm = _build_llm(settings.ollama_render_model)

            qdrant     = QdrantClient(host=settings.QDRANT_HOST, port=settings.QDRANT_PORT)
            embedder   = Embedder()

            #
            #   Use a different SchemaRag than the base here:
            #
            schema_rag = DBAgentSchemaRag(qdrant, embedder, settings.QDRANT_COLLECTION, settings.top_k_tables)

            DBAgentPipeline.PIPELINE_INSTANCE = DBAgentPipeline(
                schema_rag     = schema_rag,
                sql_generator  = DBAgentSQLGenerator(sql_llm, settings.max_rows),
                static_checker = StaticChecker(),
                dry_runner     = DryRunner(_db_params),
                executor       = Executor(_db_params),
                renderer       = Renderer(render_llm),
                circuit_breaker= CircuitBreaker(settings.circuit_breaker_threshold),
                max_retries    = settings.max_sql_retries,
            )

        
        return DBAgentPipeline.PIPELINE_INSTANCE


    #
    #   overridable function called at the beginning of run()
    #
    def pre_run(self, question: str, progress_callback=None,allow_reformulation: bool = True, **kwargs):
        options = kwargs.get( "options", {} )
        debug = options.get( "debug", False )
        force = options.get( "force", False )
        langfuse_tag = options.get( "langfuse_tag", "test" )

        self.sql_generator.llm.set_langfuse_trace_step("DBAGENT PIPELINE RUN")
        self.sql_generator.llm.set_langfuse_trace_query( f"{question}" )
        self.sql_generator.llm.set_langfuse_trace_tag( f"{langfuse_tag}" )

    def _try_auto_answer(self, original_question: str, schema_chunks,
                         error_feedback: str = "") -> Optional[PipelineResult]:
        """
        Silent background auto-answer: instead of returning a failure with a
        list of suggestions for the user to pick from, pick the best
        equivalent question ourselves, answer it, and return that answer.

        For each LLM reformulation of the failed question, we re-run the FULL
        pipeline (with allow_reformulation=False so it can't recurse) -- so
        every candidate automatically benefits from the catalog short-circuit
        and the entity-name anchor. The FIRST candidate that both executes
        successfully AND clears the confidence gate is returned, annotated
        with which reformulation actually answered it (explanation
        ["answered_reformulation"]) so the UI can show a light, honest note
        rather than a suggestion list.

        v2.2 efficiency pass:
          - candidates are SORTED by embedding cosine to the ORIGINAL
            question (closest first), so the most faithful rewrite is tried
            first and a drifted one can no longer win by output-order luck;
          - attempts are capped (REQA_AUTO_ANSWER_MAX_TRIES, default 2) to
            bound worst-case latency on failures.

        The confidence gate (REQA_AUTO_ANSWER_MIN_CONF, default 0.6) is what
        keeps this from silently serving a drifted/wrong answer -- if even the
        best reformulation is doubtful, we fall back to the normal suggestion
        behaviour instead of guessing. Returns None if nothing qualifies.
        """
        min_conf = float(os.getenv("REQA_AUTO_ANSWER_MIN_CONF", "0.6"))
        max_tries = int(os.getenv("REQA_AUTO_ANSWER_MAX_TRIES", "2"))
        try:
            candidates = _llm_reformulations(
                original_question, schema_chunks,
                getattr(self.sql_generator, "llm", None),
                error_feedback=error_feedback,
            )
        except Exception as exc:
            logger.warning(f"_try_auto_answer: reformulation failed: {exc}")
            return None

        # Deduplicate, drop the original question itself
        seen, cleaned = set(), []
        for cand in candidates or []:
            cand = (cand or "").strip()
            key = cand.lower()
            if not cand or key in seen or key == (original_question or "").strip().lower():
                continue
            seen.add(key)
            cleaned.append(cand)
        if not cleaned:
            return None

        # v2.2: sort candidates by embedding cosine to the ORIGINAL question,
        # closest first -- the most faithful rewrite is tried before any
        # drifted one can consume a full pipeline run (or win by output-order
        # luck). Fail-safe: if the embedder is unavailable or errors, keep
        # the LLM's output order (previous behaviour) rather than aborting.
        embedder = getattr(self.schema_rag, "embedder", None)
        if embedder is not None and len(cleaned) > 1:
            try:
                import numpy as np
                q_vec = np.asarray(embedder.embed(original_question), dtype=float)
                q_norm = float(np.linalg.norm(q_vec)) or 1.0

                def _sim(c: str) -> float:
                    v = np.asarray(embedder.embed(c), dtype=float)
                    return float(q_vec @ v / (q_norm * (float(np.linalg.norm(v)) or 1.0)))

                sims = {c: _sim(c) for c in cleaned}
                cleaned.sort(key=lambda c: sims[c], reverse=True)
                logger.info("AUTO-ANSWER candidate order: "
                            + " | ".join(f"{sims[c]:.2f} {c[:60]!r}" for c in cleaned))
            except Exception as exc:
                logger.warning(f"_try_auto_answer: similarity ranking failed, "
                               f"keeping LLM order: {exc}")

        # v2.2: hard cap on attempts -- bounds worst-case latency on failures.
        for cand in cleaned[:max_tries]:
            try:
                res = self.run(cand, allow_reformulation=False)
            except Exception as exc:
                logger.warning(f"_try_auto_answer: candidate run failed ({cand!r}): {exc}")
                continue
            conf = ((res.explanation or {}).get("confidence") or {}).get("score")
            if res.success and (conf is None or conf >= min_conf):
                res.explanation = res.explanation or {}
                res.explanation["answered_reformulation"] = cand
                res.explanation["original_question"] = original_question
                logger.info(f"AUTO-ANSWER via reformulation={cand!r} conf={conf}")
                return res
        return None

    def run(self, question: str, progress_callback=None,
            allow_reformulation: bool = True, **kwargs) -> PipelineResult:
        """
        progress_callback: optional callable(dict) -> None, invoked at each
        key stage (schema_rag, intent_classification, sql_generation,
        static_check, explain, execution, rendering) with a small dict
        {"stage": ..., "attempt": ..., "of": ...}. Used by api.py's
        background-job endpoints to expose live progress to the UI via
        polling. Entirely optional and side-effect-free when omitted --
        existing callers (e.g. /tasks/send) are unaffected. Never allowed
        to crash the pipeline: any exception raised by the callback itself
        is swallowed (a broken progress reporter must not break the actual
        query).        
        """

        self.pre_run(question, None, allow_reformulation, **kwargs)
       
        debug_rval = {} # Returned value of debug
        options = kwargs.get( "options", {} )
        debug = options.get( "debug", False )
        force = options.get( "force", False )
        neo4j_in = options.get( "neo4j_in", {} )

        logger.info( f"agent/pipeline run({question}, {kwargs})" )


        def _report(stage: dict) -> None:
            if progress_callback is None:
                return
            try:
                progress_callback(stage)
            except Exception as cb_exc:
                logger.warning(f"progress_callback raised, ignoring: {cb_exc}")

        if self.cb.is_open():
            return PipelineResult(
                success=False,
                answer="Service temporarily unavailable — too many consecutive failures.",
                error="Circuit breaker open",
                debug=debug_rval
            )

        logger.info(f"run question={question}")

        # Apply the domain glossary (e.g. "action" -> "activity") BEFORE
        # schema retrieval, not just later inside classify_intent()/
        # generate() as before. Previously the RAG step searched with the
        # user's raw wording, so a question using a domain synonym for a
        # table that doesn't share that literal wording in its embedding
        # text could fail to retrieve that table into the schema context
        # at all -- the LLM then has no real schema for it and invents a
        # plausible-looking but nonexistent table name instead. Verified
        # against a real failure: "Show the category code list of action"
        # generated "FROM action" (no such table; the real table is "act"),
        # because "act"/"activity" was never actually retrieved into
        # context for that query. classify_intent()/generate() already
        # re-apply this substitution themselves -- harmless and idempotent
        # on an already-canonical question, so no behavior changes there.
        # Keep the ORIGINAL (pre-rewrite) wording for the catalog short-circuit
        # below: the curated sample_queries are stored in naturalised form
        # ("Absolute Point"), so matching must use the user's original words,
        # not the entity-rewritten token ("abs_point"). The rewrite is still
        # applied for RETRIEVAL, where the real table token is what helps.
        original_question = question
        question = self.sql_generator._apply_domain_synonyms(question)

        # ── Schema RAG ────────────────────────────────────────────────────────
        _report({"stage": "schema_rag"})
        try:
            schema_chunks  = self.schema_rag.retrieve(question, debug=debug, debug_rval=debug_rval)
            # v3.1: pass the user's ORIGINAL wording so build_ddl_with_kb
            # can pick the few-shot examples matching the question's shape.
            # original_question (pre entity-rewrite) is the right one: the
            # shape cues are lexical ("per", "share of", "no linked"), and
            # the synonym rewrite only touches entity words.
            schema_context = self.schema_rag.build_schema_context(
                schema_chunks, question=original_question)
            all_tables     = self.schema_rag.all_table_names()
        except Exception as e:
            strace = traceback.format_exc()
            logger.error(f"Schema RAG error: {e} - {strace}")
            return PipelineResult(
                success=False,
                answer="Schema retrieval failed. Ensure Qdrant is running and the schema has been indexed.",
                error=f"{e} - {strace}",
                debug=debug_rval
            )
        
        # ── Graph join-path hints (Neo4j :FK layer) ──────────────────────────
        # The vector RAG finds the right TABLES but never the PATH between
        # them; multi-hop joins with invented join columns are the main
        # remaining semantic failure (real run: act x fire_event ON cat_code).
        # Append the graph's VERIFIED join conditions to the schema context so
        # the LLM copies real paths instead of inventing them. Fail-safe by
        # construction (graph_paths degrades to [] when Neo4j is down/absent):
        # the pipeline behaves identically without the graph.
        try:
            from agent.graph_paths import join_path_hints
            _hint_tables = [t.table_name for t in schema_chunks[:8]
                            if getattr(t, "table_name", "")]
            _join_hints = join_path_hints(_hint_tables)
            if _join_hints:
                schema_context += (
                    "\n\n-- VERIFIED JOIN PATHS (schema graph) --\n"
                    "-- When joining these tables, use EXACTLY these conditions:\n"
                    + "\n".join(f"--   {h}" for h in _join_hints)
                )
                logger.info(f"GRAPH: injected {len(_join_hints)} verified join-path hint(s)")
        except Exception as _ge:
            logger.warning(f"GRAPH: join-path hints unavailable: {_ge}")

        logger.info(f"================= SCHEMA CONTEXT ({len(schema_context)} chars, {len(schema_chunks)} tables): ==================")
        logger.info(f"{schema_context}")
        logger.info("========================================================================================================")
        if debug:
            debug_rval["schema_context"] = schema_context


        #logger.info(f"SCHEMA CONTEXT ({len(schema_context)} chars, {len(schema_chunks)} tables): "
         #           f"{schema_context[:300]}...")

        # ── Catalog short-circuit (BEFORE intent classification) ──────────────
        # A strong match to a curated sample question is a STRONGER signal than
        # the intent classifier: answer with the vetted gold SQL and skip
        # intent routing entirely. Previously placed AFTER intent, so a data
        # question that the classifier/ambiguity-detector misrouted to
        # schema_exploration/unclear returned before the catalog was ever
        # consulted -- verified: "Show the Absolute Point records classified
        # as either cartesian point or geographic point" (an exact catalog
        # question) was answered as "unclear" instead of by its gold SQL.
        # Matched on original_question (naturalised wording, pre entity-rewrite).
        catalog_sql = None
        try:
            _match = self.schema_rag.best_sample_query(original_question, min_overlap=0.8)
            if _match:
                # v3.0 gate. The enriched KB carries, per table, questions
                # phrased exactly like a user's ("Show the customer email
                # address recorded on each Absolute Point") whose SQL is
                # invalid on purpose, plus "Delete all X records added last
                # month" whose SQL is a real DELETE. A 0.8 lexical overlap
                # is easy to hit on those. Executing the match verbatim
                # without this check would surface an SQL error to the user
                # at best, and hit the database with a write at worst.
                _cls = query_class(_match)
                _cand = _match.get("sql")
                if _cls == POSITIVE and is_readonly_select(_cand):
                    catalog_sql = _cand
                    logger.info(
                        f"CATALOG SHORT-CIRCUIT: table={_match['table']} "
                        f"overlap={_match['overlap']:.2f} sql={_cand}"
                    )
                else:
                    logger.warning(
                        f"CATALOG MATCH REJECTED (class={_cls}, readonly="
                        f"{is_readonly_select(_cand)}): table={_match.get('table')} "
                        f"overlap={_match.get('overlap', 0):.2f} -- "
                        f"generating normally instead"
                    )
        except Exception as e:
            logger.warning(f"catalog short-circuit unavailable, generating normally: {e}")

        # ── Negative pre-flight (v3.1) ───────────────────────────────────────
        # Mirror image of the catalog short-circuit above. The enriched KB
        # records, per table, the questions this schema CANNOT answer and
        # why ("no audit or user-attribution columns", "no financial
        # attribute on this table"). When the user's question is one of
        # them, three LLM calls and two DB round-trips are guaranteed to
        # end in "Could not generate a valid query" WITHOUT ever telling
        # the user why. Answering the diagnosis directly is both faster and
        # more useful. Threshold is deliberately strict and restricted to
        # the UNANSWERABLE class (see best_negative_match docstring): a
        # false refusal costs far more than a wasted retry.
        # Behaviour-changing, therefore OPT-IN: this is the only place where
        # the agent can now answer WITHOUT generating any SQL. Enable with
        # REQA_NEGATIVE_PREFLIGHT=1 once you have watched the logs and are
        # satisfied with the false-refusal rate (the log line below fires
        # whether or not the flag is on, so you can measure it first).
        if not catalog_sql:
            try:
                _neg = best_negative_match(
                    original_question,
                    [t.table_name for t in schema_chunks[:5] if getattr(t, "table_name", "")],
                )
            except Exception as e:
                _neg = None
                logger.warning(f"negative pre-flight unavailable: {e}")
            if _neg and os.getenv("REQA_NEGATIVE_PREFLIGHT", "0") != "1":
                logger.info(
                    f"NEGATIVE PRE-FLIGHT (dry-run, flag off): would decline -- "
                    f"table={_neg['table']} kind={_neg['kind']} "
                    f"overlap={_neg['overlap']:.2f}"
                )
                _neg = None
            if _neg:
                logger.info(
                    f"NEGATIVE PRE-FLIGHT: table={_neg['table']} kind={_neg['kind']} "
                    f"overlap={_neg['overlap']:.2f} -- declining without generation"
                )
                # NOTE: `explanation` is only built further down (XAI skeleton),
                # AFTER intent classification -- this path returns BEFORE that
                # point, so it must build its own dict. Referencing the outer
                # name here raised NameError the moment the flag was enabled.
                _expl = {
                    "intent": "not_answerable",
                    "not_answerable": {
                        "matched_question": _neg["question"],
                        "reason": _neg["why"],
                        "table": _neg["table"],
                    },
                    "retrieved_tables": [
                        {"name": t.table_name, "score": round(t.score, 4)}
                        for t in schema_chunks
                    ],
                }
                try:
                    _expl["question_suggestions"] = _combine_suggestions(
                        self.schema_rag.suggest_questions(
                            [t.table_name for t in schema_chunks[:3]],
                            per_table=2, exclude=question),
                        [],
                    )
                except Exception:
                    pass
                _why = _neg["why"] or "the schema does not hold this information"
                return PipelineResult(
                    success=False,
                    answer=("This cannot be answered from the available data: "
                            f"{_why}"),
                    error="not_answerable_from_schema",
                    attempts=0,
                    explanation=_expl,
                    debug=debug_rval,
                )

        # ── Intent classification ────────────────────────────────────────────
        # Distinguishes "I want actual data" from "I want to know what data/
        # tables exist" so that schema-exploration questions never reach the
        # SQL generator (and therefore can never hallucinate columns/joins).
        # Skipped entirely when a catalog gold SQL is already in hand.
        if catalog_sql:
            intent = "data_query"
        else:
            _report({"stage": "intent_classification"})
            try:
                intent = self.sql_generator.classify_intent(question)
            except Exception as e:
                logger.warning(f"Intent classification failed, defaulting to data_query: {e}")
                intent = "data_query"

        logger.info(f"INTENT={intent}")

        if not catalog_sql and intent == "schema_exploration":
            result = self.sql_generator.answer_schema_exploration(question, self.schema_rag)
            answer = result["summary"]
            if result.get("table_markdown"):
                answer += f"\n\n{result['table_markdown']}"

            # No SQL is generated for this intent, so gen_conf (which
            # measures "did the LLM write correct SQL immediately") isn't
            # applicable -- treated as 1.0 (no generation risk incurred).
            # rag_conf still reflects retrieval quality, same formula as
            # _compute_confidence(), so "confidence" has a consistent shape
            # across every branch of the pipeline rather than being absent
            # here (which could KeyError any caller assuming it always exists).
            rag_scores = [t.cosine_score for t in schema_chunks if t.score > 0]
            rag_conf = round(sum(rag_scores) / len(rag_scores), 4) if rag_scores else 0.5

            return PipelineResult(
                success=True,
                answer=answer,
                sql=result.get("illustrative_sql", ""),
                rows=[],
                row_count=0,
                attempts=1,
                explanation={
                    "intent": intent,
                    "retrieved_tables": [
                        {"name": t.table_name, "score": round(t.score, 4)}
                        for t in schema_chunks
                    ],
                    "confidence": {
                        "score": round(0.4 * rag_conf + 0.6 * 1.0, 4),
                        "rag_conf": rag_conf,
                        "gen_conf": 1.0,
                    },
                },
                debug=debug_rval
            )

        # v2.4: deterministic override -- when the question literally names a
        # real retrieved table ("...from mat_stat..."), the user's intent is
        # not ambiguous by definition. Neither the LLM intent classifier
        # (non-deterministic: same question observed flip-flopping between
        # data_query and unclear across runs) nor the ambiguity detector
        # (spread of near-identical _stat cosines dances around the 0.06
        # threshold) may veto an explicitly named table.
        _q_lower = (original_question or "").lower()
        _names_table = any(
            t.table_name and t.table_name.lower() in _q_lower
            for t in (schema_chunks or [])
        )
        if _names_table and intent == "unclear":
            logger.info("INTENT OVERRIDE: question names a retrieved table -> data_query")
            intent = "data_query"

        if force == False and ( not _names_table and not catalog_sql and (intent == "unclear" or _is_ambiguous_retrieval(schema_chunks)) ):
            # v2.3: silent auto-answer on the UNCLEAR path too -- in practice
            # the most frequent failure exit, yet the only one that never
            # tried reformulating. Same guarantees as elsewhere: confidence
            # gate, no recursion, falls through to the normal unclear result
            # when nothing qualifies.
            if allow_reformulation:
                auto = self._try_auto_answer(original_question, schema_chunks)
                if auto is not None:
                    return auto
            # Suggest REAL, guaranteed-answerable questions from the top RAG
            # candidates' curated sample_queries -- far more actionable than
            # just listing table names.
            top_tables = [t.table_name for t in schema_chunks[:3]]
            try:
                suggested = self.schema_rag.suggest_questions(top_tables, per_table=2, exclude=question)
            except Exception:
                logger.warning("suggest_questions unavailable; continuing without catalog suggestions")
                suggested = []
            reformulations = _llm_reformulations(
                question, schema_chunks, getattr(self.sql_generator, "llm", None))
            hint = (
                f" Did you mean something related to: {', '.join(top_tables)}?"
                if top_tables else ""
            )
            return PipelineResult(
                success=False,
                answer=(
                    "I'm not sure what data you're looking for."
                    + hint
                    + " Try rephrasing, e.g. 'show me data from <table>' "
                    "or 'how many rows are in <table>'."
                ),
                attempts=1,
                explanation={"intent": intent,
                             "question_suggestions": _combine_suggestions(suggested, reformulations)},
                debug=debug_rval
            )

        # intent == "data_query" (or catalog short-circuit) → continue below.
        # The catalog gold SQL (catalog_sql), if any, is applied on attempt 1
        # of the generation loop and still validated via static_check /
        # EXPLAIN / execution, so a (very unlikely) bad gold SQL falls back to
        # normal generation on retry.

        # ── XAI skeleton ─────────────────────────────────────────────────────
        explanation = {
            "intent": intent,
            "retrieved_tables": [
                {
                    "name":         t.table_name,
                    "score":        round(t.score, 4),
                    "cosine_score": round(t.cosine_score, 4),
                    "domain":       _domain_str(t.payload.get("domain", "")),
                    # FK-expanded tables get score=0 from _fk_expand
                    "source": "rag" if t.score > 0 else "fk_expansion",
                }
                for t in schema_chunks
            ],
            "total_tables_in_db": len(all_tables),
            "schema_preview":     schema_context[:900],
            "attempts":           [],
            "confidence":         {"score": 0.0, "rag_conf": 0.0, "gen_conf": 0.0},
        }

        error_feedback = ""
        previous_sql = ""

        # Lowercased set of every real table name, used by static_check to
        # reject hallucinated table names (table1, main_table, ...) BEFORE
        # the EXPLAIN round-trip, with actionable feedback. Computed once
        # per run -- all_tables is already in hand at this point.
        known_tables = {t.lower() for t in all_tables} if all_tables else None

        # Same idea one level deeper: {table -> real column names}, used by
        # static_check to reject hallucinated COLUMN names (the dominant
        # failure once tables are validated) with a message listing the
        # REAL columns of the exact table. Fail-safe: validation is an
        # optimization, never a reason to break the run.
        try:
            known_columns = self.schema_rag.all_table_columns() or None
        except Exception:
            logger.warning("Could not build known_columns map; column validation disabled for this run")
            known_columns = None

        for attempt in range(1, self.max_retries + 1):
            attempt_info = {
                "n":         attempt,
                "sql":       "",
                "failed_at": None,   # None = success
                "error":     "",
            }

            # ── SQL Generation ────────────────────────────────────────────────
            _report({"stage": "sql_generation", "attempt": attempt, "of": self.max_retries})
            try:
                if attempt == 1 and catalog_sql:
                    # Use the curated gold SQL verbatim on the first attempt.
                    sql = catalog_sql
                    logger.info("RUN[1] using catalog gold SQL (short-circuit)")
                else:
                    sql = self.sql_generator.generate(
                        question, schema_context, all_tables, error_feedback,
                        previous_sql=previous_sql,
                    )
                    if debug:
                        debug_rval["planner"] = getattr(
                            self.sql_generator, "last_plan", None
                        )
                        debug_rval["planner_error"] = getattr(
                            self.sql_generator, "last_plan_error", ""
                        )
                        debug_rval["planner_raw_preview"] = getattr(
                            self.sql_generator, "last_plan_raw", ""
                        )[:1000]
                        debug_rval["completion_check"] = getattr(
                            self.sql_generator, "last_completion_check", {}
                        )
            except SQLValidationError as e:
                # The LLM responded, but wrote something unsafe/malformed
                # (forbidden keyword, not a SELECT, ...). This is a content
                # problem the LLM can self-correct on retry given the error
                # message — exactly like a static_check failure — NOT an
                # infrastructure problem. It must NOT count toward the
                # circuit breaker (which exists to detect the LLM API/DB
                # being down, not the LLM occasionally proposing invalid
                # SQL), and the error message IS useful feedback for the
                # next attempt, unlike a genuine API exception.
                error_feedback = f"Validation error: {e}"
                attempt_info.update(failed_at="static_check", error=str(e))
                explanation["attempts"].append(attempt_info)
                logger.info(f"RUN[{attempt}] SQL validation failed: {e}")
                continue
            except Exception as e:
                # This is a genuine infrastructure/API-level failure (LLM
                # timeout, rate limit, connection error, ...), not a
                # problem with the SQL content itself. Two things follow:
                #
                # 1. The circuit breaker must learn about it. It previously
                #    only recorded failures from EXPLAIN/execution, so a
                #    fully-down LLM would silently retry 3x on EVERY single
                #    user request forever, never tripping the breaker —
                #    exactly the failure mode it exists to catch.
                #
                # 2. error_feedback must NOT be set to this exception text.
                #    SQLGenerator.generate() treats a non-empty error_feedback
                #    as "the previous SQL was wrong, here's why" — it skips
                #    question normalization/planning and asks the LLM to
                #    "verify table names, column names, joins..." against a
                #    message like "DATABASE ERROR: LLM error: <exception>",
                #    which is nonsensical guidance for an infra failure and
                #    silently degrades the next attempt's quality. A clean
                #    retry (empty error_feedback) is the correct behavior.
                error_feedback = ""
                attempt_info.update(failed_at="llm", error=str(e))
                explanation["attempts"].append(attempt_info)
                etrace = traceback.format_exc()
                logger.warning(f"RUN[{attempt}] LLM generation failed: {e}\n{etrace}")

                self.cb.record_failure()
                if self.cb.is_open():
                    logger.error("CIRCUIT BREAKER: LLM generation repeatedly failing")
                    return PipelineResult(
                        success=False,
                        answer="The SQL generation service is currently unavailable — too many consecutive failures.",
                        error=str(e),
                        attempts=attempt,
                        explanation=explanation,
                        debug=debug_rval
                    )
                continue

            attempt_info["sql"] = sql
            previous_sql = sql
            logger.info(f"RUN[{attempt}] QUESTION-{question} SQL={sql}")

            if sql.upper().startswith("IMPOSSIBLE:"):
                reason = sql[11:].strip()
                attempt_info.update(failed_at="impossible", error=reason)
                explanation["attempts"].append(attempt_info)
                logger.info(f"\tIMPOSSIBLE Reason={reason}")
                # Silent background auto-answer before giving up: the question
                # may be answerable once reformulated into the schema's own
                # vocabulary. Only returns if a reformulation clears the
                # confidence gate; otherwise we fall through to suggestions.
                if allow_reformulation:
                    auto = self._try_auto_answer(
                        original_question, schema_chunks, error_feedback=reason)
                    if auto is not None:
                        return auto
                try:
                    _cat = self.schema_rag.suggest_questions(
                        [t.table_name for t in schema_chunks[:3]], per_table=2, exclude=question,
                    )
                    _ref = _llm_reformulations(
                        question, schema_chunks, getattr(self.sql_generator, "llm", None))
                    explanation["question_suggestions"] = _combine_suggestions(_cat, _ref)
                except Exception:
                    pass
                return PipelineResult(
                    success=False,
                    answer=f"This question cannot be answered with the available schema: {reason}",
                    error=sql,
                    attempts=attempt,
                    explanation=explanation,
                    debug=debug_rval
                )

            # ── Static Check ──────────────────────────────────────────────────
            _report({"stage": "static_check", "attempt": attempt, "of": self.max_retries})
            valid, static_err = self.static_checker.check(
                sql, known_tables=known_tables, known_columns=known_columns,
            )
            # Column auto-fix: when every unknown column had ONE unambiguous
            # near-match (effective_time → effctv_time), the checker rewrote
            # the SQL instead of failing -- adopt it, and keep the
            # substitutions visible in the attempt record (XAI/logs).
            _fixed = getattr(self.static_checker, "fixed_sql", None)
            if valid and _fixed and _fixed != sql:
                notes = list(getattr(self.static_checker, "autofix_notes", []) or [])
                logger.info(f"\tColumn auto-fix applied: {'; '.join(notes)}")
                attempt_info["column_autofix"] = notes
                sql = _fixed
                attempt_info["sql"] = sql
            if not valid:
                error_feedback = f"Syntax/policy error: {static_err}"
                attempt_info.update(failed_at="static_check", error=static_err)
                explanation["attempts"].append(attempt_info)
                logger.info(f"\tSTATIC CHECK: not valid={error_feedback}")
                continue

            # ── EXPLAIN dry-run ───────────────────────────────────────────────
            _report({"stage": "explain", "attempt": attempt, "of": self.max_retries})
            try:
                plan_ok, plan_err = self.dry_runner.explain(sql)
            except DryRunConnectionError as e:
                # Genuine DB connection failure -- worth tripping the
                # circuit breaker over, unlike a plain content/schema
                # error (handled below via the normal (ok, err) path,
                # which never reaches this branch).
                attempt_info.update(failed_at="explain", error=str(e))
                explanation["attempts"].append(attempt_info)
                logger.warning(f"RUN[{attempt}] EXPLAIN connection failure: {e}")
                self.cb.record_failure()
                if self.cb.is_open():
                    logger.error("CIRCUIT BREAKER: EXPLAIN connection repeatedly failing")
                    return PipelineResult(
                        success=False,
                        answer="Query planning failed too many times — graceful failure.",
                        sql=sql,
                        error=str(e),
                        attempts=attempt,
                        explanation=explanation,
                        debug=debug_rval
                    )
                error_feedback = ""
                continue

            if not plan_ok:
                # Content/schema error (e.g. "Unknown column") -- the
                # expected, common, self-correctable outcome of validating
                # freshly LLM-generated SQL. Previously this ALSO called
                # self.cb.record_failure(), meaning a single wrong column
                # name could trip the circuit breaker and cut the retry
                # loop short after just 1 attempt instead of the intended
                # max_retries -- verified against a real deployment. Must
                # NOT touch the circuit breaker; just retry with feedback.
                attempt_info.update(failed_at="explain", error=plan_err)
                explanation["attempts"].append(attempt_info)
                logger.info(f"\tEXPLAIN content error (not a circuit-breaker event): {plan_err}")
                # v3.1: append the KB's documented corrective instruction for
                # this error class, plus the closest REAL identifiers when the
                # error names an unknown column/table. A bare "Unknown column
                # 'x'" makes the model guess again; naming the real candidates
                # is what makes the next attempt land.
                _hint = repair_hint(plan_err, [t.table_name for t in schema_chunks[:5]
                                               if getattr(t, "table_name", "")])
                error_feedback = f"EXPLAIN failed: {plan_err}"
                if _hint:
                    error_feedback += f"\nHOW TO FIX: {_hint}"
                    logger.info(f"\tREPAIR HINT: {_hint}")
                continue

            # ── Execution ─────────────────────────────────────────────────────
            _report({"stage": "execution", "attempt": attempt, "of": self.max_retries})
            try:
                rows, exec_err = self.executor.execute(sql)
            except ExecutorConnectionError as e:
                attempt_info.update(failed_at="execution", error=str(e))
                explanation["attempts"].append(attempt_info)
                logger.warning(f"RUN[{attempt}] Execution connection failure: {e}")
                self.cb.record_failure()
                if self.cb.is_open():
                    logger.error("CIRCUIT BREAKER: execution connection repeatedly failing")
                    return PipelineResult(
                        success=False,
                        answer="Query execution failed too many times — graceful failure.",
                        sql=sql,
                        error=str(e),
                        attempts=attempt,
                        explanation=explanation,
                        debug=debug_rval
                    )
                error_feedback = ""
                continue

            if exec_err:
                # Same reasoning as the EXPLAIN content-error case above:
                # a query-level error (bad column, constraint, ...) is
                # self-correctable, not an infrastructure failure -- does
                # not touch the circuit breaker.
                attempt_info.update(failed_at="execution", error=exec_err)
                explanation["attempts"].append(attempt_info)
                logger.info(f"\tExecution content error (not a circuit-breaker event): {exec_err}")
                _hint = repair_hint(exec_err, [t.table_name for t in schema_chunks[:5]
                                               if getattr(t, "table_name", "")])
                error_feedback = f"Execution error: {exec_err}"
                if _hint:
                    error_feedback += f"\nHOW TO FIX: {_hint}"
                    logger.info(f"\tREPAIR HINT: {_hint}")
                continue

            # ── Render ────────────────────────────────────────────────────────
            _report({"stage": "rendering", "attempt": attempt, "of": self.max_retries})
            self.cb.record_success()
            answer = self.renderer.render(question, sql, rows)

            explanation["attempts"].append(attempt_info)   # failed_at=None → success
    
            

            #if force:
            #    explanation["confidence"] = {"score": 1.0, "score_strict": 1.0, "rag_conf": 1.0, "gen_conf": 1.0, "sem_conf": 1.0}
            #else:
            explanation["confidence"] = _compute_confidence(
                schema_chunks, attempt, self.max_retries, success=True,
                question=question, sql=sql,    )

            explanation["xai"] = _build_xai(
                question, sql, schema_chunks, attempt,
                explanation.get("attempts") or [],
                llm=getattr(self.sql_generator, "llm", None),
            )

            logger.info("SUCCESS")
            return PipelineResult(
                success=True,
                answer=answer,
                sql=sql,
                rows=rows,
                row_count=len(rows),
                attempts=attempt,
                explanation=explanation,
                debug=debug_rval
            )

        logger.info("MAX RETRIES")
        # Silent background auto-answer before surfacing a failure: all
        # max_retries attempts on the original wording failed, but a
        # reformulation grounded in the schema vocabulary may still succeed
        # (and benefit from the catalog short-circuit). Returns only if a
        # candidate clears the confidence gate; else fall through to the
        # normal suggestion list.
        if allow_reformulation:
            auto = self._try_auto_answer(
                original_question, schema_chunks, error_feedback=error_feedback)
            if auto is not None:
                return auto
        # After exhausting all attempts, offer the user guaranteed-answerable
        # alternatives drawn from the top RAG candidates' sample_queries --
        # turning a dead-end into a redirection.
        try:
            _cat = self.schema_rag.suggest_questions(
                [t.table_name for t in schema_chunks[:3]], per_table=2, exclude=question,
            )
            _ref = _llm_reformulations(
                question, schema_chunks, getattr(self.sql_generator, "llm", None),
                error_feedback=error_feedback,
            )
            explanation["question_suggestions"] = _combine_suggestions(_cat, _ref)
        except Exception:
            pass
        return PipelineResult(
            success=False,
            answer="Could not generate a valid query after multiple attempts.",
            error=error_feedback,
            attempts=self.max_retries,
            explanation=explanation,
            debug=debug_rval
        )   
