﻿"""
Inherit SchemaRAG to make it better at using rated responses when we have near certitude
that this is the best strategy.

Make it reterieve only what is specified into the choosen rated response


"""

from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass
from typing import Optional

from qdrant_client import QdrantClient
from qdrant_client.models import Filter, FieldCondition, MatchValue

# python 3.12 and above only:
#from typing import override 

from config.settings import get_settings
settings = get_settings()



from agent.embedder import Embedder
from RAG.knowledge_base import (
    build_ddl_with_kb,
    extract_business_rules,
)
# v3 (enriched KB). Two distinct needs:
#  - SAFETY: the payload may be STALE (a Qdrant collection indexed before
#    ingest.py was updated still carries the negative families, DELETE
#    statements included). Every read of payload["sample_queries"] is
#    therefore re-filtered here, not only at ingestion time.
#  - RELEVANCE: rank_kinds/get_business_examples let the context builder
#    and the suggestion list use the question's shape.
from RAG.knowledge_base import (
    POSITIVE,
    is_readonly_select,
    query_class,
    get_business_examples,
    get_sample_queries,
)




import traceback
import sys

sys.path.insert(0, "../")
sys.path.insert(0, "../../") # add this path to get the config in root dir
sys.path.insert(0, "../../neo4j") # add this path to get the config in root dir
sys.path.insert(0, "../neo4j") # add this path to get the config in root dir


from agent.schema_rag import SchemaRAG
from agent.pipelines.dbagent_schema_rag import DBAgentSchemaRag
from agent.schema_rag import _validate_join_on


logger = logging.getLogger("RR SCHEMA RAG")

_RRF_K = 60


class RatedResponseSchemaRag(DBAgentSchemaRag):



    def __init__(
        self,
        client: QdrantClient,
        embedder: Embedder,
        collection: str,
        top_k: int = 7,
        candidate_limit: int = 15,
        enable_query_expansion: bool = True,
    ):
        super().__init__(client, embedder, collection, top_k, candidate_limit, enable_query_expansion)



    # @ofverride is available in python 3.12 and above only:
    #@override
    def pre_retrieve_step(
        self,
        query: str,        
        **kwargs
        ) -> list[RetrievedTable]:

        # if debug was specified, we return a list of messages
        # todo: Return these messages in streaming 
        schema_rag_retrieve_debug_msg = []
        debug =  kwargs.get("debug", False)
        debug_rval = kwargs.get("debug_rval", {} )
                       
        # reset the results of the last query        
        self.rated_rules.reset()

        searches = []



        #
        # Rated Rules
        #
        rag_num_rated_rules = 0
        rag_min_rating = 3
        options = self.parent_pipeline.current_request["options"]
        if "rag_num_rated_rules" in options:
            rag_num_rated_rules = int(options["rag_num_rated_rules"])

        if "rag_min_rating" in options:
            rag_min_rating = int(options["rag_min_rating"])

        try:                        
            if rag_num_rated_rules > 0:
                rules_hits = self.rated_rules.query( query, rag_min_rating, rag_num_rated_rules )                
                                
                logger.warning(
                    f"RATED_RULES_HITS={rules_hits}"
                )                                                                               
            else:
                rules_hits = []                
        except Exception as e:
            traceback.print_exc()
            rules_hits = []

        #   
        # Adding tables from rated responses is no longer there
        #   Todo: Reimplement from rated rule
        #

        #if graphrag_hits and graphrag_hits[0][2] > 0.7: 
        #    searches.extend( [
        #        self._search(q, self.candidate_limit)
        #        for q in gr_tables
        #    ])

       
        debug_rval["rated_rules"] = {}
        debug_rval["rated_rules"]["hits"] = rules_hits

        return searches

        

    # @ofverride is available in python 3.12 and above only:
    #@override
    def post_build_schema_step(
        self,
        tables: list[RetrievedTable],
        question: str = "",
        **kwargs
    ) -> List[str]:

        result = []    

        #
        #   graph_rag samples
        #       These are retrieved from qdrant from the natural language question
        #       They are not by table, they are by question This is like a reverse lookup. 
        #                               


        if len( self.rated_rules.get_result_hits() ) > 0:
            result.append("\n\n-- VERIFIED rules that are related to the question --" )            
            for hit in self.rated_rules.get_result_hits():                
                # ({'Q': 'Where is the 3R22R 19B1 2IC currently located?', 
                # 'A': {'tables': ['callsign', 'geo_point', 'obj_item', 'point'], 
                # 'sql': "SELECT\n            T1.lat_coord,\n            T1.long_coord\n            FROM obj_item_point_loc AS T1\n            INNER JOIN obj_item AS T2\n        ...            );\n            
                # "},
                # 'category': 'question'}, 1, 0.47899014)
                hit_dict = hit[0]
                hit_index = hit[1]
                hit_score = hit[2]
                hit_question = hit_dict["Q"]
                hit_answer_sql = hit_dict["Rule"]
                result.append(f"-- Q : {hit_question}")
                #hit_answer_sql = hit_answer_sql.replace("\n", "")
                result.append(f"-- Rule : {hit_answer_sql}")
                result.append("\n")
   
        return result

    # ----------------------------------------
