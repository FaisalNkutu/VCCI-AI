

import sys 


sys.path.insert(0,"../../")
sys.path.insert(0,"../")
sys.path.insert(0,"./")

from pydantic import BaseModel
from qdrant_client import QdrantClient


from agent.embedder import Embedder
from agent.schema_rag import SchemaRAG
from agent.sql_generator import SQLGenerator
from agent.static_check import StaticChecker
from agent.dry_run import DryRunner
from agent.executor import Executor
from agent.renderer import Renderer
from agent.circuit_breaker import CircuitBreaker
from agent.pipeline import Pipeline, _build_llm

import sys
#=======================   config.json  ====================================================
from config.settings import get_settings
#===========================================================================================



from a2a_base_agent_setup import A2AAgentBaseSetup, init_asyncio
from dotenv import load_dotenv

from agent.pipelines.rr_schema_rag import RatedResponseSchemaRag
from agent.pipelines.dbagent_pipeline import DBAgentPipeline
from agent.pipelines.dbagent_sql_generator import DBAgentSQLGenerator



VERBOSE_DEBUG = True
import logging
logging.basicConfig(level=logging.DEBUG,format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("RATED PIPELINE") 




#
#       RatedRulesPipeline
#
#           Pipeline that is better specialized for rated responses
#           - reduce the RAG size by using a custom SchemaRag "RatedResponseSchemaRag"
#               it inherits SchemaRag, and it will exclude tables that are not in rated responses,
#               because if we end up in this pipeline we are already betting that we have a very close example 
#               rated response to follow, and the tables involved are known.
#           
#
class RatedRulesPipeline(DBAgentPipeline):


    PIPELINE_INSTANCE = None

    
    def __init__(
        self,
        schema_rag,
        sql_generator,
        static_checker,
        dry_runner,
        executor,
        renderer,
        circuit_breaker,
        max_retries: int = 3,
        allow_reformulation = False
    ):
        super().__init__( schema_rag,
            sql_generator,
            static_checker,
            dry_runner,
            executor,
            renderer,
            circuit_breaker,
            max_retries,
            allow_reformulation )     # Fratricide Pipeline does not reformulate
        

    
    #
    #   overridable function called at the beginning of run()
    #
    def pre_run(self, question: str, progress_callback=None, allow_reformulation: bool = True, **kwargs):

        options = kwargs.get( "options", {} )
        debug = options.get( "debug", False )
        force = options.get( "force", False )        
        langfuse_tag = options.get( "langfuse_tag", "test" )

        self.sql_generator.llm.set_langfuse_trace_step("RATED PIPELINE RUN")
        self.sql_generator.llm.set_langfuse_trace_query( f"{question}" )
        self.sql_generator.llm.set_langfuse_trace_tag( f"{langfuse_tag}" )


    @staticmethod    
    def get_pipeline_instance():
       
        logger.info(f"RATED RULES PIPELINE INSTANCE")

        if RatedRulesPipeline.PIPELINE_INSTANCE == None:
            load_dotenv()
            settings = get_settings()
            
            _db_params = dict(
                host=settings.DB_HOST,
                port=settings.DB_PORT,
                database=settings.DB_NAME,
                user=settings.DB_USER,
                password=settings.DB_PASSWORD,
            )

            # codestral → SQL generation (specialized)
            # mistral   → natural language rendering (general purpose)
            sql_llm    = _build_llm(settings.ollama_sql_model)
            render_llm = _build_llm(settings.ollama_render_model)

            qdrant     = QdrantClient(host=settings.QDRANT_HOST, port=settings.QDRANT_PORT)
            embedder   = Embedder()

            #
            #   Use a different SchemaRag than the base here:
            #
            schema_rag = RatedResponseSchemaRag(qdrant, embedder, settings.QDRANT_COLLECTION, settings.top_k_tables)

            RatedRulesPipeline.PIPELINE_INSTANCE = RatedRulesPipeline(
                schema_rag     = schema_rag,
                sql_generator  = DBAgentSQLGenerator(sql_llm, settings.max_rows),
                static_checker = StaticChecker(),
                dry_runner     = DryRunner(_db_params),
                executor       = Executor(_db_params),
                renderer       = Renderer(render_llm),
                circuit_breaker= CircuitBreaker(settings.circuit_breaker_threshold),
                max_retries    = settings.max_sql_retries,
            )

        
        return RatedRulesPipeline.PIPELINE_INSTANCE






