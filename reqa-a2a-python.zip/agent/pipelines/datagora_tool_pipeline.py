


import os
from ambisql.graph_lab import Datagora, LLM
from config.settings import get_settings
settings = get_settings()
import sys 


sys.path.insert(0,"../../")
sys.path.insert(0,"../")
sys.path.insert(0,"./")

from pydantic import BaseModel
from qdrant_client import QdrantClient


from agent.embedder import Embedder
from agent.schema_rag import SchemaRAG
from agent.sql_generator import SQLGenerator
from agent.static_check import StaticChecker
from agent.dry_run import DryRunner
from agent.executor import Executor
from agent.renderer import Renderer
from agent.circuit_breaker import CircuitBreaker
from agent.pipeline_base import PipelineBase
from agent.pipeline import Pipeline, _build_llm

import sys
#=======================   config.json  ====================================================
from config.settings import get_settings
#===========================================================================================
settings = get_settings()


from a2a_base_agent_setup import A2AAgentBaseSetup, init_asyncio
from dotenv import load_dotenv
from agent.pipelines.rr_schema_rag import RatedResponseSchemaRag

from agent.sql_generator_base import SQLGeneratorBase
from agent.pipeline_base import PipelineResult

VERBOSE_DEBUG = True
import logging
logging.basicConfig(level=logging.DEBUG,format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("DATAGORA TOOL PIPELINE") 
from agent.llm.base import BaseLLM

import traceback

def mysql_of( database):
    """The connection to the database the question is asked of."""
    return {
        "host": settings.DB_HOST,
        "port": settings.DB_PORT,
        "database": database,
        "user": settings.DB_USER,
        "password": settings.DB_PASSWORD
    }


def model( name, url=settings.ollama_base_url , model_name=settings.ollama_model):
    """A model served by Ollama, without any settings file."""
    return LLM(name, {"api": "ollama", "url": url, "model": model_name,
                    "num_ctx": 16384, "timeout": 600})


class DatagoraSQLGenerator(SQLGeneratorBase):


    def __init__(self, llm: BaseLLM = None, max_rows: int = 100):
        super().__init__(llm, max_rows)
        self._system = "You are a SQL Generator"
        self.parent_pipeline = None
        self.out = None


    def reset(self):        
        self.ambi_choice = None
        self.ambi_rating = 0

    def set_choice(self, choice):    
        try:
            self.ambi_choice = str(choice)
        except:
            traceback.print_exc()
                        

    def generate(
        self,
        question: str,
        schema_context: str,
        all_tables: list[str],
        error_feedback: str = "",
        previous_sql: str = "",
        mandatory_tables=None,
        validated_context=None,
     ) -> str:
        

                            
        database = "calian_more_tables"

        dg =Datagora(
                mysql=mysql_of(settings.DB_NAME),
                name=settings.DB_NAME,
                reasoner=model("reasoner"),
                sql=model("sql", settings.ollama_base_url, settings.ollama_sql_model),
                neo4j_uri= settings.NEO4J_HOST ,
                neo4j_user=settings.NEO4J_USER,
                neo4j_password=settings.NEO4J_PASSWORD,
                qdrant_url= f"{settings.QDRANT_HOST}:{settings.QDRANT_PORT}",
                # None is the default, <database>_corpus
                qdrant_collection=database + "_corpus",
                embed_url=settings.ollama_embed_url,
                embed_model=settings.ollama_embed_model,
                descriptions=str(dictionary) if database == "datagora_lib" and dictionary.exists() else None,
                reformulate=True,
                judge="single",
                context={"location": "Montreal", "timezone": "America/Toronto"},
            )

        self.out = dg.ask(question)
        
        
        if self.out.waiting:                  
            print( f"Question was Ambiguous. Choices={self.out.options}" )                          # the question was ambiguous
            if self.ambi_choice != None:
                self.out = dg.ask(question, choice=self.ambi_choice)

        if self.out.failed:
            print(f"FAILED: {self.out.failed}")
        

        if self.out.waiting or self.out.suggestions:
            print(f"Clarification needed: {self.out.clarifying or self.out.clarification}")
            for option in self.out.options:
                print(f"  option {option.label}: {getattr(option, 'means', '')}")
            for s in self.out.suggestions:
                print(f"  suggestion: {s.question}")
            print("Ask a suggestion as a new question, or run again with --choice and a label.")        

        if not self.out.answer:
            print(self.out.clarification or "The pipeline returned no answer.")            

        print(f"SQL: {self.out.sql}")
        print(f"Rows returned: {len(self.out.rows)}")
        print(f"Answer: {self.out.answer}")

        return self.out.sql


    def get_explanation(self):
        
        explain = ""

        if self.out.waiting:                  
            explain +=  f"Question was Ambiguous. Choices={self.out.options}\n"                           # the question was ambiguou


        if self.out.failed:
             explain +=f"FAILED: {self.out.failed}\n"
        

        if self.out.waiting or self.out.suggestions:
            explain +=f"Clarification needed: {self.out.clarifying or self.out.clarification}\n"
            for option in self.out.options:
                explain += f"  option {option.label}: {getattr(option, 'means', '')}\n"
            for s in self.out.suggestions:
                explain += f"  suggestion: {s.question}\n"
            explain += "Ask a suggestion as a new question, or run again with --choice and a label.\n"

        if not self.out.answer:
            explain += self.out.clarification or "The pipeline returned no answer\n."

        explain +=f"SQL: {self.out.sql}\n"
        explain +=f"Rows returned: {len(self.out.rows)}\n"
        explain +=f"Answer: {self.out.answer}\n"


        return explain

    def get_answer(self):        

        if self.out.waiting:                  
            return   f"AMBIGUOUS. Choices={self.out.options}\n"                           # the question was ambiguou

        if self.out.failed:
            return f"FAILED: {self.out.failed}\n"
        
        if self.out.suggestions:
            return f"NEED_MORE_INFO. Suggestions={self.out.suggestions}\n"
        
        return self.out.answer








#
#       DatagoraToolPipeline
#
#           Pipeline for the datagora tool
#           Datagora tool is a tool that you can recognize from its Gray and Red UI
#           This tool was used to generate several rated responses during the project.
#           It can be used by the end user to customize behavior and patch for 
#           jargon that is specific to them that we could not anticipate.
#           
#
class DatagoraToolPipeline(PipelineBase):


    PIPELINE_INSTANCE = None

    
    def __init__(
        self,
        schema_rag,
        sql_generator,
        allow_reformulation = False       
    ):
        super().__init__( schema_rag,
            sql_generator,
            allow_reformulation )


    
    def run(self, question: str, progress_callback=None,
            allow_reformulation: bool = True, **kwargs) -> PipelineResult:
        """
        progress_callback: optional callable(dict) -> None, invoked at each
        key stage (schema_rag, intent_classification, sql_generation,
        static_check, explain, execution, rendering) with a small dict
        {"stage": ..., "attempt": ..., "of": ...}. Used by api.py's
        background-job endpoints to expose live progress to the UI via
        polling. Entirely optional and side-effect-free when omitted --
        existing callers (e.g. /tasks/send) are unaffected. Never allowed
        to crash the pipeline: any exception raised by the callback itself
        is swallowed (a broken progress reporter must not break the actual
        query).        
        """
    
        self.pre_run(question, None, allow_reformulation, **kwargs)   



        print("\n\n==========================================================================")  
     
        debug_rval = {} # Returned value of debug
        options = kwargs.get( "options", {} )
        debug = options.get( "debug", False )
        force = options.get( "force", False )
        langfuse_tag = options.get( "langfuse_tag", "test" )
        logger.info( f"agent/pipeline run({question}, {kwargs})" )
  
        self.sql_generator.reset()
        ambi_choice = options.get( "ambi_choice", None )
        if ambi_choice != None:
            self.sql_generator.set_choice( ambi_choice )

        sql = self.sql_generator.generate(
                        question, "", [], None,
                        previous_sql=None,
                    )


        rows = self.sql_generator.out.rows
        explanation = self.sql_generator.get_explanation()
        answer = self.sql_generator.get_answer()
        

        print("==========================================================================\n\n")  

        row_count = len(rows)

        return PipelineResult(
            success=True,
            answer=f"{answer}\nrows={rows}",
            sql=sql,
            rows=[],
            row_count=row_count,
            attempts=1,
            explanation=explanation,
            debug=debug_rval
        )


    @staticmethod    
    def get_pipeline_instance():
       
        logger.info(f"DATAGORA TOOL PIPELINE INSTANCE")

        if DatagoraToolPipeline.PIPELINE_INSTANCE == None:
            load_dotenv()
            settings = get_settings()
            
            _db_params = dict(
                host=settings.DB_HOST,
                port=settings.DB_PORT,
                database=settings.DB_NAME,
                user=settings.DB_USER,
                password=settings.DB_PASSWORD,
            )


            qdrant     = QdrantClient(host=settings.QDRANT_HOST, port=settings.QDRANT_PORT)
            embedder   = Embedder()

            #
            #   Use a different SchemaRag than the base here:
            #
            schema_rag = SchemaRAG(qdrant, embedder, settings.QDRANT_COLLECTION, settings.top_k_tables)

            DatagoraToolPipeline.PIPELINE_INSTANCE = DatagoraToolPipeline(
                schema_rag     = schema_rag,
                sql_generator  = DatagoraSQLGenerator()              
            )

        
        return DatagoraToolPipeline.PIPELINE_INSTANCE


