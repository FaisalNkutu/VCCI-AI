from agent.llm.base import BaseLLM

import json
import logging
import os
import re
import time


from agent.sql_generator import SQLGenerator
from agent.sql_generator import SQLValidationError
from agent.sql_generator import _load_domain_synonyms, _load_entity_table_map
from agent.sql_generator import ENTITY_TABLE_MAP, _ENTITY_KEYS_SORTED, FORBIDDEN_KEYWORDS, _VALID_INTENTS 
from agent.sql_generator import _SIMPLE_INTENT_PATTERNS, _RELATIONAL_INTENT_PATTERNS, _GENERIC_LISTING_WORDS


logging.basicConfig(level=logging.INFO)

logger = logging.getLogger("DBAGENT SQL GENERATOR")
logger.setLevel(logging.INFO)
logger.disabled = False

# ---------------------------------------------------------------------------
# SQL generation system prompt (unchanged rules, kept as the final guardrail)
# ---------------------------------------------------------------------------

_SYSTEM = """
You are an expert SQL engineer specialized in MariaDB and military/defence databases.

The schema context you receive contains:
  • Annotated DDL
  • Column descriptions
  • Foreign key relationships
  • Business rules
  • Suggested JOIN paths

STRICT RULES:
1. Output ONLY the raw SQL query.
2. Never output markdown fences.
3. Never output explanations.
4. READ ONLY: only SELECT statements.
5. Never use INSERT, UPDATE, DELETE, DROP, CREATE, ALTER, TRUNCATE.
6. Use only tables and columns present in the schema context.
7. Always qualify every column with its table alias.
8. Use explicit JOIN ... ON syntax.
9. Derive JOIN conditions from FK relationships.
10. If a column description references another table, join it to retrieve human-readable values.
11. Use proper MariaDB 11.4 syntax:
    - IFNULL
    - COALESCE
    - DATE_FORMAT
    - GROUP_CONCAT
    - DATEDIFF
    Avoid WITH (CTE) clauses entirely: use simple SELECT with JOINs
    and, when unavoidable, plain subqueries instead.
12. Use exact values from business rules when filtering.
12b. ENUM columns: filter ONLY with values that appear in the column's
    "Allowed:" list in the schema context. NEVER invent a category value
    (e.g. do not write cat_code = 'MAT' unless 'MAT' is explicitly
    listed). If no allowed value matches the question's intent, omit the
    filter or reply IMPOSSIBLE.
13. Never invent table names.
13b. Never invent helper or CTE table names (for example
    latest_holdings, current_holdings, ranked_holdings, or
    starting_holdings). Use only physical tables listed in the schema
    context; use ordinary subqueries only when necessary.
14. Never invent column names.
15. Add LIMIT {max_rows} unless:
    - the user explicitly asks for all rows
    - the query is purely aggregate (COUNT, SUM, AVG, MIN, MAX)
16. Prefer JOINs over nested subqueries whenever possible.
17. Do not add JOINs for a genuinely single-table request. However, if the
    question asks for attributes belonging to another entity, or asks to
    match/link/associate/correspond records, include every necessary
    relationship and bridge/association table from the schema context.
18. Before creating a JOIN, verify that both join columns exist inside the CREATE TABLE blocks in the schema context.
19. Ignore columns mentioned only in comments, referenced-by notes, business rules, enum values, or error feedback.
20. Before returning SQL, perform this checklist silently:
    - every requested output item has a source column in the schema context;
    - every source table is present in the schema context;
    - every relationship/bridge table needed to connect requested entities is
      included;
    - every JOIN uses columns and FK relationships shown in the schema;
    - no table or column name was invented or substituted with a similarly
      named table.
21. If the question is impossible to answer with the available schema, reply EXACTLY:
   IMPOSSIBLE: <one-line reason>

NAMED DESIGNATIONS vs EXPLICIT IDs (critical):
- Designations that mix digits and words ("1 IG BG HQ", "2 RCR", "3rd
  Battalion", "Checkpoint 4") are NAME strings. Match them against a name
  column (e.g. name_txt) with the FULL string. NEVER extract a leading or
  embedded number from a name and use it as a numeric id (e.g. never turn
  "1 IG BG HQ" into unit_id = 1).
- When the question supplies an explicit identifier for an entity (e.g.
  "obj_item ID: 1457", "id 42", "reporting_data_id = 7"), filter DIRECTLY
  on that id column with that number, and add NO other identity filter for
  the same entity — the id alone is sufficient and authoritative. The name
  is then descriptive context only; do not also filter on it.
- Never apply two different equality filters that identify the SAME entity
  through different columns joined by equality: if a JOIN says
  a.x = b.y, then filters a.x = 1 AND b.y = 1457 contradict each other and
  guarantee an empty result.

TARGET TABLE ANCHORING (critical):
- The QUESTION refers to a specific entity, and that entity's table is named
  in the AVAILABLE TABLES / SCHEMA CONTEXT. Use THAT table as the primary
  table in FROM.
- Do NOT substitute a different table merely because it also contains a
  column mentioned in the question. Many tables share a column such as
  cat_code; picking the wrong one returns a WRONG answer even though the
  query executes without error.
- If the exact entity's table is present, never answer over a sibling table
  instead.

You may also receive a short PLAN SUMMARY line. If present:
- Use it as a planning aid, but verify it against the original QUESTION and
  the schema context. The question and schema are authoritative if the plan
  is incomplete.
- Do not add tables or filters that are unsupported by the schema context.
- If the plan says "no joins needed" but the requested fields or relationship
  require a join, add the schema-supported join.
- Output ONLY the SQL query — never repeat or quote the plan summary.
"""



# ---------------------------------------------------------------------------
# Query planning — forces the model to externalize its intent (tables, joins,
# filters, aggregation) as structured JSON BEFORE writing SQL. This makes
# join hallucination detectable by code, for ANY table/domain.
# ---------------------------------------------------------------------------

_PLANNING_SYSTEM = """
You are a database query planning assistant for a MariaDB schema.

Given a natural language question and schema context, output ONLY a valid JSON
planning object. Do not write SQL. Do not explain the plan. Do not use
Markdown or prose before or after the JSON.

Output strictly valid JSON with this shape:
{
  "tables_needed": ["table1", "table2"],
  "joins_needed": [
    {"from": "table1.column", "to": "table2.column", "reason": "..."}
  ],
  "filters": ["..."],
  "aggregation": "none | count | sum | avg | min | max | group_by",
  "columns_to_select": ["..."],
  "is_simple_listing": true/false
}

Rules:
- Use only tables, columns, and foreign-key relationships explicitly present
  in the schema context.
- `columns_to_select` must contain the actual table.column sources needed for
  every requested output concept.
- `joins_needed` must contain every relationship required to connect those
  tables, including bridge/association tables.
- "is_simple_listing" must be true if the question only asks to show/list/
  display/get rows from a single table, with no requirement to combine or
  enrich data from another table.
- Include every schema-supported join required to answer the question,
  including bridge/association tables needed to connect requested entities.
  A join is required when a requested output field belongs to another table,
  or when the question asks to match, link, associate, compare, or correlate
  records. Do not omit a required join merely because the question does not
  name the table explicitly.
- Never invent a relationship that is not present in the schema context.
- Set "is_simple_listing" to false whenever the requested fields or intent
  require a related entity or relationship table.
- Output ONLY the JSON object, nothing else.
"""

_LN25_FIRE_RULES = """
LN25 FIRE-EVENT DOMAIN RULES (apply only when the question concerns fire,
fratricide, or firing):
- Use raw tables act and fire_event; never use metrics_results or
  fratricide_metrics_results for raw-event or fratricide answers.
- Join fire_event.fire_event_id = act.act_id. The firing entity is
  act.rep_org_id and the declared target is fire_event.target_oi_id.
- LN25 labels are exactly 'Direct Fire' and 'InDirect Fire'.
- Map event wording to the exact labels: direct fire -> 'Direct Fire';
  indirect fire -> 'InDirect Fire'; both -> IN ('Direct Fire', 'InDirect Fire').
- Friendly-at-event status is the latest obj_item_stat row with time <= act.time;
  hostility_code 'FR' means friendly.
- For a question about a hostile firing organization, use the same historical
  status lookup but require hostility_code = 'HO'. Do not substitute a current
  status for the status at event time.
- For "friendly firing" questions, require FR only for act.rep_org_id.
- For "hostile firing" questions, require HO only for act.rep_org_id.
- For "possible fratricide" questions, require FR for both act.rep_org_id
  and fire_event.target_oi_id at that event time. Do not use the current
  status if it is later than the event.
- Historical position is the latest obj_item_point_loc row with time <= act.time.
- Use the approximate 10 m x 10 m footprint only when requested, and label it
  'Approximate 10m x 10m footprint'; never claim exact MIDAS geometry.
- act.sim_offset_time is milliseconds from exercise start; do not confuse it
  with act.time.
"""

_LN25_HOLDING_RULES = """
LN25 HOLDINGS / COMBAT-POWER RULES (apply when the question concerns holdings,
combat power, or stock over time):
- Resolve a named unit through obj_item.name_txt; do not hardcode an
  obj_item_id copied from an example query.
- For "current holdings", select the latest holding row for each
  (obj_item_id, obj_type_id), using ROW_NUMBER() ordered by
  holding.time DESC, holding.holding_ix DESC. Join obj_type to return the
  equipment/item type name and include the quantities requested.
- For "which units are using" an equipment/platform, join holding to unit,
  obj_item, and obj_type; keep only the latest holding row and require a
  positive operational/on-hand quantity. Resolve the requested platform from
  obj_type.name_txt rather than inventing a separate equipment table.
- For material-platform comparisons, use mat_type.mcapab_cat_code for the
  capability class and cons_mat_type.cat_code to exclude ammunition when the
  question asks about weapon/platform holders. Match the requested platform
  name against obj_type.name_txt.
- Holdings are historical. For each object type and requested time, use the
  latest holding row where holding.time <= that time, ordered by time DESC and
  holding_ix DESC.
- Exclude non-material capability types when calculating combat power:
  join mat_type and exclude mcapab_cat_code = 'NOS'.
- Combat power percentage is:
  ROUND(100.0 * SUM(operat_cnt) / NULLIF(SUM(total_qty), 0), 2).
- For a time-series answer, use the distinct holding timestamps as the time
  axis, calculate the latest state at each timestamp, group by timestamp, and
  convert holding.time from milliseconds with FROM_UNIXTIME(time / 1000).
- Report the result as a percentage and return the time/unit label requested
  by the question.
"""

# ---------------------------------------------------------------------------
# Intent classification — distinguishes "I want actual data" from "I want
# to know what data/tables exist" so that schema-exploration questions
# never reach the SQL generator (and therefore can never hallucinate
# columns/joins). Fully domain/table agnostic.
# ---------------------------------------------------------------------------

_INTENT_SYSTEM = """
You classify a user's natural language question into ONE category:

- "data_query": the user wants to see, filter, count, or aggregate actual
  data — rows, column values, or lists of VALUES (e.g. "show me the
  activities", "how many tasks per activity", "list the first 10 rows
  from X", "show the category code list of action" — this asks for the
  actual cat_code VALUES, not table names). Questions that ask for records
  and their RELATED records from another entity ("for each X, the related
  Y", "X with its parent Y") are ALSO data_query.
- "schema_exploration": the user wants to know what TABLES, COLUMNS, or
  topics exist or are related to something, WITHOUT asking for actual
  data values (e.g. "what tables are related to activity", "show all
  activity tables", "list all the action tables", "what columns does
  table X have").
- "unclear": the question is too vague, off-topic, or ambiguous to
  classify confidently.

CRITICAL DISTINCTION — read carefully:
- "show the [category/status/type] code LIST of X" → data_query (the user
  wants the actual VALUES that appear in that column, e.g. ATTACK, COMMS).
- "for each X record, what related Y details can be found" → data_query
  (the user wants actual joined rows, not table names).
- "show all X TABLES" / "list all TABLES related to X" → schema_exploration
  (the user wants database TABLE NAMES, not column values).
The word "list" alone does NOT imply schema_exploration. Only an explicit
reference to "tables" (plural, as database objects) does.

Output ONLY one word, exactly: data_query, schema_exploration, or unclear.
Do not add any explanation, punctuation, or extra text.
"""


from agent.sql_generator import _is_exhaustive_table_listing, _finalize_sql, clean_sql





class DBAgentSQLGenerator(SQLGenerator):
    def __init__(self, llm: BaseLLM, max_rows: int = 100):
        self.llm = llm
        self.max_rows = max_rows
        self.last_plan: dict | None = None
        self.last_plan_error: str = ""
        self.last_plan_raw: str = ""
        self.last_completion_check: dict = {}
        self._system = _SYSTEM.format(max_rows=max_rows)

        self.enable_normalize = False

        logger.info(
            f"__init__() llm={llm}, "
            f"llm_class={llm.__class__.__name__}, "
            f"max_rows={max_rows}"
        )




    # ------------------------------------------------------------------
    # Step B — Build a structured plan before writing SQL
    # ------------------------------------------------------------------
    def _build_plan(self, question: str, schema_context: str) -> dict | None:
        user_msg = f"""
SCHEMA CONTEXT
--------------
{schema_context}

QUESTION
--------
{question}
"""

        try:
            self.parent_pipeline.set_langfuse_trace_step("DBAGENT_PLAN")
            raw_plan = self.llm.complete(
                _PLANNING_SYSTEM,
                [{"role": "user", "content": user_msg}],
                max_tokens=2048,
                json_mode=True,
            )

            self.last_plan_raw = raw_plan or ""
            cleaned = re.sub(r"```(?:json)?\s*", "", raw_plan or "", flags=re.IGNORECASE)
            cleaned = re.sub(r"```", "", cleaned).strip()

            # Local models sometimes wrap valid JSON in a short sentence.
            # Extract the JSON object instead of failing the whole planning
            # step on harmless formatting.
            if not cleaned.startswith("{"):
                match = re.search(r"\{.*\}", cleaned, flags=re.DOTALL)
                if match:
                    cleaned = match.group(0)

            if not cleaned:
                raise ValueError("planner returned empty output")

            plan = json.loads(cleaned)

            logger.info(f"_build_plan() plan={plan}")

            return plan

        except Exception as exc:
            self.last_plan_error = str(exc)
            # Fallback for models that understand the planning task but ignore
            # the JSON-only instruction.  Recover only table names that are
            # explicitly present in the retrieved schema; never invent names
            # from arbitrary prose.  The full structured plan remains
            # unavailable, so joins are intentionally left empty.
            raw_lower = (self.last_plan_raw or "").lower()
            schema_tables = set(re.findall(
                r"CREATE TABLE\s+([A-Za-z0-9_]+)",
                schema_context,
                flags=re.IGNORECASE,
            ))
            mentioned = sorted(
                table for table in schema_tables
                if re.search(rf"\b{re.escape(table.lower())}\b", raw_lower)
            )
            if mentioned:
                joins = []
                # Recover an explicitly stated table path from prose, but
                # keep only names validated against the retrieved schema.
                valid_tables = {t.lower() for t in schema_tables}
                # Some JSON-serializing model clients leave the Unicode arrow
                # escaped in the returned text (literal ``\\u003e``).
                raw_lower = raw_lower.replace("\\u003e", "->")
                path_pairs = re.findall(
                    r"\b([a-z][a-z0-9_]*)\s*(?:->|→)\s*([a-z][a-z0-9_]*)\b",
                    raw_lower,
                )
                for left, right in path_pairs:
                    if left in valid_tables and right in valid_tables:
                        joins.append({
                            "from": left,
                            "to": right,
                            "reason": "explicit relationship path in planner output; verify FK columns",
                        })
                logger.warning(
                    "_build_plan() JSON parse failed; using prose table fallback: %s",
                    mentioned,
                )
                self.last_plan_error += "; using schema-validated prose table fallback"
                return {
                    "tables_needed": mentioned,
                    "joins_needed": joins,
                    "columns_to_select": [],
                    "is_simple_listing": len(mentioned) <= 1,
                }
            logger.warning(f"_build_plan() failed to produce a usable plan: {exc}")
            return None



    #
    #  _needs_simplification_retry()
    #   see base functin in sql_generator.py
    #
    def _needs_simplification_retry(
        self,
        question: str,
        sql: str,
        plan: dict | None,
    ) -> bool:
        if plan is not None:
            if self._plan_has_contradiction(plan):
                return True
            # A planner can under-specify a relationship.  The SQL prompt
            # is allowed to add a schema-supported join when the question
            # requires related fields, so do not simplify solely because the
            # plan omitted joins.  Only an explicit simple-listing plan is a
            # reliable signal that joins are unnecessary.
            if plan.get("is_simple_listing") and self._count_joins(sql) > 0:
                return True
            return False

        return self._question_is_simple(question) and self._count_joins(sql) > 0




    @staticmethod
    def _sql_tables(sql: str) -> set[str]:
        return {
            name.split(".")[-1].strip(" `\"[]").lower()
            for name in re.findall(r"\b(?:FROM|JOIN)\s+([\w.`\[\]-]+)", sql, re.IGNORECASE)
        }

    def _unknown_sql_tables(self, sql: str, all_tables: list[str]) -> set[str]:
        """Return physical tables referenced by SQL that are not in the schema.

        CTE names are ignored because they are local query aliases, not database
        tables.  This catches model-invented bridge tables before execution.
        """
        known = {str(t).split(".")[-1].lower() for t in (all_tables or [])}
        ctes = {
            name.lower()
            for name in re.findall(r"\b(?:WITH(?:\s+RECURSIVE)?|,)\s*([A-Za-z_]\w*)\s+AS\s*\(", sql, re.IGNORECASE)
        }
        return {
            table for table in self._sql_tables(sql)
            if table not in known and table not in ctes
        }

    @staticmethod
    def _needs_fire_rule_retry(question: str, sql: str) -> bool:
        """Require schema-correct event/status context for fire queries."""
        q = (question or '').lower()
        if not re.search(r"\b(fire|firing|fratricide)\b", q):
            return False
        tables = DBAgentSQLGenerator._sql_tables(sql)
        # Event time and the initiating organization belong to act; fire
        # attributes belong to fire_event.  A raw fire-event answer that asks
        # who initiated/reported/fired must include both tables.
        origin_question = bool(re.search(
            r"\b(initiated|initiator|firing organization|firing organisation|"
            r"firing entity|reported by|who fired|friendly|hostile|fratricide)\b",
            q,
        ))
        if 'fire_event' not in tables or (origin_question and 'act' not in tables):
            return True
        status_question = bool(re.search(r"\b(friendly|hostile|fratricide)\b", q))
        if status_question:
            if 'obj_item_stat' not in tables:
                return True
            # The firing entity is act.rep_org_id.  Do not accept a status
            # lookup that is unrelated to the initiating organization.
            if not re.search(r"\brep_org_id\b", sql, re.IGNORECASE):
                return True
            if not re.search(r"\bhostility_code\b", sql, re.IGNORECASE):
                return True
            if not re.search(r"\btime\b\s*<=\s*\w+\.time|\btime\b\s*<=\s*act\.time", sql, re.IGNORECASE):
                return True
        # A fire-event identifier is not an object-item identifier.  This
        # catches the common invalid join produced by the model.
        if re.search(
            r"(?:obj_item_id\s*=\s*(?:\w+\.)?fire_event_id|"
            r"(?:\w+\.)?fire_event_id\s*=\s*obj_item_id)",
            sql,
            re.IGNORECASE,
        ):
            return True
        return False

    def _needs_completion_retry(self, plan: dict | None, sql: str) -> bool:
        """Detect an under-complete query using the model's own schema plan.

        This is intentionally generic: it does not name domain tables or test
        questions.  If the planner identified a multi-table path but the SQL
        omitted all joins, or omitted a planned table, give the model one
        schema-grounded correction opportunity.
        """
        if not plan:
            return False
        joins = plan.get("joins_needed") or []
        planned = {
            str(t).split(".")[0].lower()
            for t in (plan.get("tables_needed") or [])
            if t
        }
        actual = self._sql_tables(sql)
        if joins and self._count_joins(sql) == 0:
            return True
        return bool(planned and actual and not planned.issubset(actual))

    # ------------------------------------------------------------------
    # Step D — Intent classification (runs BEFORE schema/SQL generation)
    # ------------------------------------------------------------------

    def classify_intent(self, question: str) -> str:
        """
        Classify the question as 'data_query', 'schema_exploration', or
        'unclear'. Falls back to 'data_query' on any failure, so existing
        behavior is fully preserved if classification is unavailable.

        Parsing looks for the keyword anywhere in the model's response
        rather than requiring an exact match — local LLMs frequently wrap
        the answer in a short sentence despite single-word instructions
        (e.g. 'the category is "data_query"' instead of just 'data_query').
        """

        question = self._apply_domain_synonyms(question)

        try:
            self.parent_pipeline.set_langfuse_trace_step("DBAGENT_CLASSIFY_INTENT") 
            result = self.llm.complete(
                _INTENT_SYSTEM,
                [{"role": "user", "content": question}],
                max_tokens=1024,
            )

            result_lower = result.strip().lower()

            for intent in _VALID_INTENTS:
                if intent in result_lower:
                    logger.info(
                        f"classify_intent() question={question!r} "
                        f"intent={intent!r} raw={result!r}"
                    )
                    return intent

            logger.warning(
                f"classify_intent() unrecognized output={result!r}, "
                "defaulting to data_query"
            )

        except Exception as exc:
            logger.warning(f"classify_intent() failed: {exc}, defaulting to data_query")

        return "data_query"

    
    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    def generate(
        self,
        question: str,
        schema_context: str,
        all_tables: list[str],
        error_feedback: str = "",
        previous_sql: str = "",
    ) -> str:

        if self.enable_normalize and not error_feedback:
            question = self._normalize_question(question)

        self.last_plan_error = ""
        self.last_plan_raw = ""
        plan = self._build_plan(question, schema_context) if not error_feedback else None
        self.last_plan = plan
        self.last_completion_check = {
            "triggered": False,
            "missing_tables": [],
            "missing_joins": False,
        }

        _MAX_TABLES_IN_PROMPT = 80
        if not all_tables:
            tables_line = "(see schema below)"
        elif len(all_tables) <= _MAX_TABLES_IN_PROMPT:
            tables_line = ", ".join(all_tables)
        else:
            tables_line = (
                ", ".join(all_tables[:_MAX_TABLES_IN_PROMPT])
                + f" ... (+{len(all_tables) - _MAX_TABLES_IN_PROMPT} more — use schema context)"
            )

        plan_block = ""
        if plan is not None:
            plan_block = f"\n{self._plan_to_summary_line(plan)}\n"

        domain_block = ""
        if re.search(r"\b(fire|firing|fratricide|friendly fire|direct-fire|indirect-fire)\b", question, re.IGNORECASE):
            domain_block = f"\n{_LN25_FIRE_RULES}\n"
        if re.search(r"\b(holding|holdings|combat power|stock|inventory|ammunition|fuel|platform|platform holder|platform holders|artillery|weapon system|equipment)\b", question, re.IGNORECASE):
            domain_block += f"\n{_LN25_HOLDING_RULES}\n"

        user_msg = f"""
AVAILABLE TABLES
----------------
{tables_line}

SCHEMA CONTEXT
--------------
{schema_context}
{plan_block}
{domain_block}
TASK
----
Generate a single MariaDB SELECT query.

QUESTION
--------
{question}
"""

        messages = [{"role": "user", "content": user_msg}]

        if error_feedback:
            # Show the model its OWN previous SQL, not just a placeholder
            # comment. Verified against real logs: with the previous
            # "-- previous SQL failed" stub, the model literally replied
            # "Without seeing the previous SQL query or the schema
            # context..." and then fell back to a generic hallucinated
            # template (SELECT t1.column1 FROM table1 JOIN table2 ON
            # t1.foreign_key = t2.primary_key) -- the single most common
            # quality-failure category in the blue-tables evaluation run
            # (12 of 21 quality failures). The retry turn must be
            # self-sufficient: previous SQL + exact error + an explicit
            # reminder that only the AVAILABLE TABLES above may be used.
            previous_block = (
                f"YOUR PREVIOUS SQL\n-----------------\n{previous_sql}\n\n"
                if previous_sql else ""
            )
            messages.append({
                "role": "assistant",
                "content": previous_sql if previous_sql else "-- previous SQL failed",
            })
            messages.append({
                "role": "user",
                "content": f"""
Your previous SQL failed.

{previous_block}DATABASE ERROR
--------------
{error_feedback}

Analyse the error carefully, then correct YOUR PREVIOUS SQL above.

STRICT CONSTRAINTS for the correction:
- Use ONLY table names from the AVAILABLE TABLES list in the first message.
- NEVER use placeholder names such as table1, table2, main_table,
  your_table_name -- these do not exist in the database.
- Keep the same intent as the original QUESTION; fix only what the
  error message indicates is wrong.

Verify:
- table names (must appear in AVAILABLE TABLES)
- column names (must appear in the SCHEMA CONTEXT)
- aliases
- joins
- foreign keys
- MariaDB syntax

Return ONLY the corrected SQL query.
""",
            })

        logger.info(f"generate() using LLM={self.llm.__class__.__name__}")
        logger.info(f"generate() question={question}")
        logger.info(f"generate() schema_length={len(schema_context)}")

        start = time.time()

        self.parent_pipeline.set_langfuse_trace_step("DBAGENT_GENERATE_1")
        raw_sql = self.llm.complete(self._system, messages, max_tokens=1024)

        elapsed = time.time() - start
        logger.info(f"LLM generation completed in {elapsed:.2f}s")

        generated_sql = self._clean_sql(raw_sql)

        logger.info(f"RAW_SQL_DEBUG={raw_sql!r}")
        logger.info(f"CLEANED_SQL_DEBUG={generated_sql!r}")

        generated_sql = self._validate_or_impossible(generated_sql)

        logger.info(f"generated_sql={generated_sql}")

        unknown_tables = self._unknown_sql_tables(generated_sql, all_tables)
        fire_rule_retry = self._needs_fire_rule_retry(question, generated_sql)
        if unknown_tables or fire_rule_retry:
            self.last_completion_check = {
                "triggered": True,
                "missing_tables": [],
                "unknown_tables": sorted(unknown_tables),
                "missing_joins": False,
            }
            logger.info("Generated SQL referenced unknown tables %s; retrying.", unknown_tables)
            messages.append({"role": "assistant", "content": raw_sql})
            messages.append({
                "role": "user",
                "content": (
                    ("Your SQL contains table names that do not exist: "
                       f"{', '.join(sorted(unknown_tables))}. " if unknown_tables else "")
                    + "Regenerate using act joined to fire_event. For friendly, "
                    "hostile, or fratricide wording, use the latest obj_item_stat "
                    "row at or before act.time for act.rep_org_id (the firing "
                    "organization), not the target. Never join fire_event_id to "
                    "obj_item_id. Use only physical tables and foreign-key "
                    "relationships shown in SCHEMA CONTEXT. Return ONLY SQL."
                ),
            })
            self.parent_pipeline.set_langfuse_trace_step("DBAGENT_GENERATE_2")
            raw_sql = self.llm.complete(self._system, messages, max_tokens=1024)
            generated_sql = self._validate_or_impossible(self._clean_sql(raw_sql))
            logger.info("generated_sql_after_schema_retry=%s", generated_sql)

        elif not error_feedback and self._needs_completion_retry(plan, generated_sql):
            actual_tables = self._sql_tables(generated_sql)
            planned_tables = {
                str(t).split(".")[0].lower()
                for t in (plan or {}).get("tables_needed", []) if t
            }
            self.last_completion_check = {
                "triggered": True,
                "missing_tables": sorted(planned_tables - actual_tables),
                "missing_joins": bool((plan or {}).get("joins_needed")) and self._count_joins(generated_sql) == 0,
            }
            logger.info("Generated SQL omitted planned tables/joins; retrying completion.")
            messages.append({"role": "assistant", "content": raw_sql})
            messages.append({
                "role": "user",
                "content": (
                    "Your SQL is incomplete compared with the schema plan. "
                    "Regenerate it using every required table and JOIN from "
                    "the plan, while preserving all requested output fields. "
                    "Use only schema-supported tables, columns, and foreign-key "
                    "relationships. Return ONLY the corrected SQL."
                ),
            })
            self.parent_pipeline.set_langfuse_trace_step("DBAGENT_GENERATE_3")
            raw_sql = self.llm.complete(self._system, messages, max_tokens=1024)
            generated_sql = self._validate_or_impossible(self._clean_sql(raw_sql))
            logger.info(f"generated_sql_after_completion_retry={generated_sql}")

        if not error_feedback and self._needs_simplification_retry(
            question, generated_sql, plan
        ):
            logger.info(
                "Detected unjustified JOIN for a simple listing question — "
                "retrying with a simplification instruction."
            )

            messages.append({"role": "assistant", "content": raw_sql})
            messages.append({
                "role": "user",
                "content": (
                    "Your query added a JOIN, but the question only asks to "
                    "list/show/display rows from a single table without "
                    "requesting related data from another table. "
                    "Regenerate the SIMPLEST possible query: SELECT directly "
                    "from the single most relevant table, with NO JOIN, "
                    "unless the question explicitly requires combining data "
                    "from multiple sources. Return ONLY the corrected SQL."
                ),
            })
            
            self.parent_pipeline.set_langfuse_trace_step("DBAGENT_GENERATE_4")
            raw_sql = self.llm.complete(self._system, messages, max_tokens=1024)
            generated_sql = self._clean_sql(raw_sql)

            logger.info(f"RAW_SQL_DEBUG_retry={raw_sql!r}")
            logger.info(f"CLEANED_SQL_DEBUG_retry={generated_sql!r}")

            generated_sql = self._validate_or_impossible(generated_sql)

            logger.info(f"generated_sql_after_simplification_retry={generated_sql}")

        return generated_sql
