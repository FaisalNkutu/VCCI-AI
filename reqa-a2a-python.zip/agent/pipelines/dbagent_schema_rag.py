﻿"""
Enhanced SchemaRAG

Features:
- Query expansion (optional)
- Multi-query retrieval
- Reciprocal Rank Fusion (RRF)
- FK-neighbour expansion
- Relevance scoring
- Deduplicated business rules
- JOIN hints generation
- Cached table names
- Lexical fallback retrieval for schema-exploration questions
- Few-shot sample queries injected per table (text-to-SQL quality boost)
- Exact table-name anchor (leverages sql_generator's entity-name rewrite)
- Catalog short-circuit match (best_sample_query)
"""

from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass
from typing import Optional

from qdrant_client import QdrantClient
from qdrant_client.models import Filter, FieldCondition, MatchValue

from agent.embedder import Embedder
from RAG.knowledge_base import (
    build_ddl_with_kb,
    extract_business_rules,
)
# v3 (enriched KB). Two distinct needs:
#  - SAFETY: the payload may be STALE (a Qdrant collection indexed before
#    ingest.py was updated still carries the negative families, DELETE
#    statements included). Every read of payload["sample_queries"] is
#    therefore re-filtered here, not only at ingestion time.
#  - RELEVANCE: rank_kinds/get_business_examples let the context builder
#    and the suggestion list use the question's shape.
from RAG.knowledge_base import (
    POSITIVE,
    is_readonly_select,
    query_class,
    get_business_examples,
    get_sample_queries,
)

import traceback
import sys

sys.path.insert(0, "../")
sys.path.insert(0, "../../") # add this path to get the config in root dir
sys.path.insert(0, "../") # add this path to get the config in root dir
sys.path.insert(0, "../neo4j") # add this path to get the config in root dir
sys.path.insert(0, "neo4j") # add this path to get the config in root dir
from neo4j_functions import find_info_by_cat_codes as neo4j_find_info_by_cat_codes
from neo4j_functions import find_info_by_table_names as neo4j_find_info_by_table_names

from agent.schema_rag import SchemaRAG

logger = logging.getLogger("SCHEMA RAG")

_RRF_K = 60


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

from agent.schema_rag import RetrievedTable,_STOPWORDS, _CATALOG_STOP

from agent.schema_rag import _validate_join_on, _content_words, _catalog_words, _best_sample_query_overlap

# ---------------------------------------------------------------------------
# SchemaRAG
# ---------------------------------------------------------------------------


class DBAgentSchemaRag(SchemaRAG):
    """
    Retrieves the most relevant schemas from Qdrant.

    Pipeline:
        query
          â†“
        expansion
          â†“
        multi-search
          â†“
        RRF fusion
          â†“
        FK expansion
          â†“
        schema context
    """

    def __init__(
        self,
        client: QdrantClient,
        embedder: Embedder,
        collection: str,
        top_k: int = 7,
        candidate_limit: int = 15,
        enable_query_expansion: bool = True,
    ):

        super().__init__(client, embedder, collection, top_k, candidate_limit, enable_query_expansion)

        self._table_cache: Optional[list[str]] = None
        self._payload_cache: Optional[dict[str, dict]] = None

       






    def retrieve(
        self,
        query: str,        
        **kwargs
        ) -> list[RetrievedTable]:



        logger.warning("DBAgent Retrieve()")



        # if debug was specified, we return a list of messages
        # todo: Return these messages in streaming 
        schema_rag_retrieve_debug_msg = []
        debug =  kwargs.get("debug", False)
        debug_rval = kwargs.get("debug_rval", {} )
      
      
        #
        #   Overridable function
        #
        self.pre_retrieve_step( query, **kwargs )
        
        

        # ── Layer 1: query expansion ──────────────────────────────────────────────
        expanded_queries = self._expand_query( query  )

        # â”€â”€ Layer 2: vector search (multi-query) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        searches = [
            self._search(q, self.candidate_limit)
            for q in expanded_queries
        ]


        # â”€â”€ Layer 3: RRF merge â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        merged = self._rrf_merge(searches)

        # Sample-query grounding boost, before the top_k cut.
        merged = self._sample_query_boost(query, merged)


        # Rescue tables the vector search missed ENTIRELY.
        existing_names = {t.table_name for t in merged}
        rescued = self._sample_query_rescue(query, existing_names)
        if rescued:
            merged = merged + rescued
            merged.sort(key=lambda t: t.score, reverse=True)

        # â”€â”€ Table-name anchor â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        # After _apply_domain_synonyms rewrites a naturalised entity name to
        # its real table token ("Absolute Point" -> "abs_point"), the query
        # literally names the target table. Match it deterministically and pin.
        existing_names = {t.table_name for t in merged}
        anchored = self._table_name_anchor(query, existing_names)
        if anchored:
            merged = merged + anchored
            merged.sort(key=lambda t: t.score, reverse=True)
        anchored_names = {t.table_name for t in anchored}

        semantic = self._semantic_anchor(query, existing_names | anchored_names)
        if semantic:
            merged = merged + semantic
            merged.sort(key=lambda t: t.score, reverse=True)
        semantic_names = {t.table_name for t in semantic}

        # Pin near-exact sample_query matches (top 2) BEFORE any truncation.
        pinned_candidates = sorted(
            (t for t in merged if t.score >= 0.9),
            key=lambda t: t.score,
            reverse=True,
        )
        pinned = {t.table_name: t for t in pinned_candidates[:2]}

        # Exact table-name anchors are the strongest signal -- always pin them,
        # bypassing the top-2 cap, so top_k / FK / reranker can never drop the
        # table the user literally named.
        for t in merged:
            if t.table_name in anchored_names:
                pinned[t.table_name] = t
            if t.table_name in semantic_names:
                pinned[t.table_name] = t

        # initial pruning before graph expansion
        merged = merged[: self.top_k]

        # â”€â”€ Layer 4: FK graph expansion â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        # FK expansion is performed after reranking below.  Expanding before
        # the reranker allowed its top_k cut to discard the related tables.

        # â”€â”€ Layer 5: cross-encoder reranking â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        try:
             # Do we absulutely need to local import like this?
            from config.settings import get_settings
            settings = get_settings()

            if settings.use_reranker:
                from    RAG.reranker import rerank_tables

                merged = rerank_tables(
                    query,
                    merged,
                    top_k=self.top_k,
                )
            else:
                merged = merged[: self.top_k]

        except Exception:
            # fail-safe fallback (never break retrieval)
            merged = merged[: self.top_k]

        # Re-inject any pinned (near-exact sample match OR exact table-name
        # anchor) the reranker/top_k dropped.
        missing_pinned = [t for name, t in pinned.items() if name not in {m.table_name for m in merged}]
        if missing_pinned:
            merged = merged + missing_pinned

        # Preserve schema-supported relationship/bridge tables in the final
        # context after all top_k/reranker pruning has completed.
        merged = self._fk_expand(merged)


        self.post_retrieve_step( query, **kwargs )

        return merged







    # ---------------------------------------------------------------------
    # Context Builder
    # ---------------------------------------------------------------------

    def build_schema_context(
        self,
        tables: list[RetrievedTable],
        question: str = "",
        **kwargs
    ) -> str:
        """Build the DDL context sent to the LLM.

        v3: `question` is optional and threaded down to build_ddl_with_kb(),
        which uses it to pick the few-shot examples whose KIND answers that
        shape ("how many X per Y" -> group_by_enum / having / share_of_total)
        instead of a fixed level-balanced sample. Same prompt budget, far
        higher relevance. Omitting it reproduces the previous behaviour
        exactly, so existing callers are unaffected.
        """

        #
        #   overridable function 
        #
        self.pre_build_schema_step( tables, question, **kwargs )

        ddl_sections = []

        all_rules = set()

        join_hints = []
        seen_join_on: set[str] = set()

        for table in tables:

            payload = table.payload

            table_name = (
                payload.get("table")
                or payload.get("table_name")
                or ""
            )

            columns = payload.get(
                "columns",
                [],
            )

            relationships = payload.get(
                "relationships",
                [],
            )

            ddl = build_ddl_with_kb(
                table_name,
                columns,
                question=question,
            )

            ddl_sections.append(
                (
                    f"-- Relevance: "
                    f"{table.score:.4f}\n"
                    f"{ddl}"
                )
            )

            all_rules.update(
                extract_business_rules(
                    table_name
                )
            )

            # Include curated production-KB guidance in the runtime context,
            # not only in the vector payload. This lets SQL generation use
            # semantic rules and query patterns after retrieval.
            for rule in payload.get("reasoning_rules", []) or []:
                if isinstance(rule, dict) and rule.get("guidance"):
                    all_rules.add(str(rule["guidance"]))
            semantic = payload.get("semantic") or {}
            if isinstance(semantic, dict) and semantic.get("purpose"):
                all_rules.add(f"Semantic purpose of {table_name}: {semantic['purpose']}")
            for pattern in payload.get("query_patterns", []) or []:
                if not isinstance(pattern, dict):
                    continue
                intent = pattern.get("intent")
                tables_needed = pattern.get("required_tables") or []
                notes = pattern.get("notes")
                if intent:
                    line = f"Query pattern {intent}: required tables {', '.join(map(str, tables_needed))}."
                    if notes:
                        line += f" {notes}"
                    all_rules.add(line)

            for rel in relationships:
                remote_table = rel.get("related_table")
                join_on = rel.get("join_on")
                if not remote_table or not join_on or join_on in seen_join_on:
                    continue

                if not _validate_join_on(table_name, rel):
                    logger.warning(
                        f"join_on mismatch for {table_name} relationship "
                        f"{rel.get('name', '?')!r}: stored join_on={join_on!r} "
                        f"does not match own_column={rel.get('own_column')!r}/"
                        f"related_column={rel.get('related_column')!r} -- "
                        f"KB data may need regenerating for this relationship."
                    )

                seen_join_on.add(join_on)
                hint = f"JOIN {remote_table} ON {join_on}"
                rel_type = rel.get("type", "")
                cardinality = rel.get("cardinality", "")
                if rel_type or cardinality:
                    hint += f"  -- {rel_type}, {cardinality}"
                join_hints.append(hint)

        result = [
            "-- =====================================================",
            "-- Retrieved Schema Context",
            "-- =====================================================",
            "",
            *ddl_sections,
        ]

        if all_rules:

            result.append("")
            result.append(
                "-- Business Rules"
            )

            for rule in sorted(all_rules):
                result.append(
                    f"-- {rule}"
                )

        if join_hints:

            result.append("")
            result.append(
                "-- Suggested JOINs"
            )

            for hint in sorted(
                set(join_hints)
            ):
                result.append(
                    f"-- {hint}"
                )

        # 
        #  overridable function
        #
        result.extend( self.post_build_schema_step( tables, question, **kwargs ) )


        rendered = "\n".join(result)

        # Codestral is configured with a 32K-token context window.  Keep a
        # conservative character budget for the complete schema block so the
        # system prompt, plan, question, and generated response still fit.
        # The limit is configurable for larger models and prevents Ollama
        # HTTP 400 errors caused by oversized requests.
        # 45k characters leaves headroom for the system prompt, planning
        # summary, question, and generated response within a 32k-token model
        # context.  Override with RAG_MAX_SCHEMA_CONTEXT_CHARS when using a
        # model with a larger context window.
        max_context_chars = int(os.getenv("RAG_MAX_SCHEMA_CONTEXT_CHARS", "45000"))
        if len(rendered) > max_context_chars:
            logger.warning(
                "Schema context truncated from %d to %d characters",
                len(rendered), max_context_chars,
            )
            rendered = (
                rendered[:max_context_chars]
                + "\n-- Schema context truncated to fit the model context window."
            )

        return rendered

    # ---------------------------------------------------------------------

   