



import csv
import re


import datetime
import json
import sys
import traceback

#
#   Sample of rules format
#
test_rules =[ { "Q" : "What are the scheduled dispatch timestamps and bulk commodity quantities allocated in resupply transactions originating from source supply point [x] for brigade sustainment?",
                "AI_response" : "The schema contains tables for Actions (act) and stock levels (holding), but there is no table or column that records the specific quantity of commodities allocated or transferred as part of a resupply transaction.",
        #    "Rule": "check data rows; name_txt for the RESUPPLY activities and descr_txt for the info regarding the exact items and quantities"
            "Rule": "find entries in 'act_event' table where column 'subcat_code' value is 'RESPLN'; JOIN with 'act' table and select all columns of 'act' ",
            "rating" : 5

 }]



#rules_csv_pattern = re.compile( '\"([\\W\\w.]*)\",\"([\\W\\w.]*)\",\"([\\W\\w.]*)\"')
def load_rules_file( fname, min_rating = 1 ):

    rules_rval = []

    # Open your CSV file
    with open(fname, mode='r', newline='', encoding='utf-8') as file:
        # Explicitly setting quotechar ensures fields in double quotes are kept together
        reader = csv.reader(file, delimiter=',', quotechar='"')
    
        for row in reader:           
            Q = row[0]
            AIResp = row[1]
            Rule = row[2]
            rating = 0
            try:
                rating = int(row[3])
            except:
                pass


            if len(Q) > 8 and len( Rule )  > 10 and rating >= min_rating:
                rule =  { "Q" : Q, "Rule": Rule , "AI_response" : AIResp, "rating" : rating  } 
                print( rule )
                rules_rval.append(rule)


    return rules_rval
