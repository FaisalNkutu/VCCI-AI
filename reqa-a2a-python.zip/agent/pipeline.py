from dataclasses import dataclass, field
import traceback

from agent.grounding_context import GroundingContext, GroundingResult

from query_analysis.relationship_validator import (
    RelationshipValidator
)
from query_analysis.validated_query_context_builder import (
    build_validated_query_context
)

# https://www.canada.ca/en/library-archives/collection/research-help/military-history/military-abbreviations.html

from agent.sql_generator import SQLValidationError
# v3.0 (enriched KB): the catalog short-circuit executes a KB query
# verbatim, and the KB now contains queries that are invalid or destructive
# BY DESIGN (evaluation set). Both guards below are applied before any
# catalog SQL is trusted.
from RAG.knowledge_base import query_class, is_readonly_select, POSITIVE
# v3.1: the negative families of the enriched KB are turned into two
# capabilities -- refuse instantly what the schema provably cannot answer,
# and repair a failed attempt with the KB's documented guidance.
from RAG.knowledge_base import best_negative_match, repair_hint
from agent.dry_run import DatabaseConnectionError as DryRunConnectionError
from agent.executor import DatabaseConnectionError as ExecutorConnectionError

# Semantic-consistency scorer (3rd confidence component). Fail-safe import:
# if agent/sem_conf.py is missing from a deployment, confidence degrades
# gracefully to a neutral sem_conf=1.0 instead of crashing the pipeline.
try:
    from agent.sem_conf import _compute_sem_conf
except ImportError:
    def _compute_sem_conf(question, sql, target_tables):
        return 1.0

import logging
import os
import re
import time
from functools import lru_cache
from typing import Optional
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("PIPELINE")
logger.setLevel(logging.INFO)
logger.disabled = False

#=======================   config.json  ====================================================
from config.settings import get_settings
#===========================================================================================

from query_analysis.relationship_validator import (
    RelationshipStatus,
    RelationshipValidator
)

settings = get_settings()

def _build_llm(model: str):
    logger.info(f" BUILD LLM {settings.LLM_PROVIDER} {settings.ollama_base_url} {model}")
    if settings.LLM_PROVIDER == "ollama":
        logger.info("LLM_PROVIDER OLLAMA")
        from agent.llm.ollama_llm import OllamaLLM
        return OllamaLLM(model=model, base_url=settings.ollama_base_url)
    elif settings.LLM_PROVIDER == "openai_compat":
        from agent.llm.openai_compat import OpenAICompatLLM
        logger.info("LLM_PROVIDER OPENAI_COMPAT")
        return OpenAICompatLLM(
            model=settings.OPENAI_COMPAT_MODEL,
            base_url=settings.OPENAI_COMPAT_BASE_URL,
            api_key=settings.OPENAI_COMPAT_API_KEY,
        )
    else:
        raise ValueError(f"Unknown LLM_PROVIDER: {settings.LLM_PROVIDER!r}. Use 'ollama' or 'openai_compat'.")





from agent.sql_generator import GroundingViolation

from agent.exceptions import SchemaLimitation

import re




def extract_tables_from_sql(sql: str) -> set[str]:

    tables = set()

    from_matches = re.findall(
        r"\bFROM\s+([A-Za-z_][A-Za-z0-9_]*)",
        sql,
        flags=re.IGNORECASE,
    )

    join_matches = re.findall(
        r"\bJOIN\s+([A-Za-z_][A-Za-z0-9_]*)",
        sql,
        flags=re.IGNORECASE,
    )

    tables.update(
        table.lower()
        for table in from_matches
    )

    tables.update(
        table.lower()
        for table in join_matches
    )

    return tables




  
    
def build_grounding_result(
    grounded_tables,
    resolved_tables,
    term_mapping_block,
    entity_reference_block,
    entity_resolution_block,
    graph_context,
):

    return GroundingResult(
        grounded_tables=grounded_tables,
        resolved_tables=resolved_tables,
        mandatory_tables=build_mandatory_tables(
            grounded_tables,
            resolved_tables,
        ),
        term_mapping_block=term_mapping_block,
        entity_reference_block=entity_reference_block,
        entity_resolution_block=entity_resolution_block,
        graph_context=graph_context,
    )








def build_mandatory_tables_block(
    mandatory_tables,
) -> str:

    if not mandatory_tables:
        return ""

    return (
    "\n\n"
    "-- MANDATORY TABLES --\n"
    "-- VERIFIED GROUNDING RESULT.\n"
    "-- These tables were selected using schema grounding "
    "and entity grounding.\n"
    "-- The SQL query MUST use these tables whenever "
    "they are relevant to the question.\n"
    "-- Do NOT replace them with semantically similar tables.\n"
    "-- If these tables cannot be connected through verified "
    "join paths, answer IMPOSSIBLE instead of inventing joins.\n"
    + "\n".join(
        f"--   {t}"
        for t in sorted(mandatory_tables)
    )
    )




def build_grounding_context(
    term_mapping_block: str,
    entity_reference_block: str,
    entity_resolution_block: str,
    mandatory_tables_block: str,
    graph_context: str,
) -> str:

    blocks = [
        term_mapping_block,
        entity_reference_block,
        entity_resolution_block,
        mandatory_tables_block,
        graph_context,
    ]

    return "".join(
        block
        for block in blocks
        if block
    )



def build_graph_context(
    schema_chunks,
    mandatory_tables,
):
    """
    Build Neo4j join-path context.
    """

    try:

        from agent.graph_paths import (
            join_path_hints
        )

        rag_tables = {
            c.table_name
            for c in schema_chunks
        }

        logger.warning(
            f"RAG_TABLES={sorted(rag_tables)}"
        )

        graph_tables = (
            rag_tables
            | mandatory_tables
        )

        logger.warning(
            f"GRAPH_SEED_TABLES={sorted(graph_tables)}"
        )

        logger.warning(
            f"GRAPH_SEED_TABLES="
            f"{sorted(graph_tables)}"
        )

        join_hints = join_path_hints(
            graph_tables
        )

        logger.warning(
            f"GRAPH_RETURNED="
            f"{len(join_hints)}"
        )

        if not join_hints:
            return ""

        return (
            "\n\n"
            "-- VERIFIED JOIN PATHS "
            "(schema graph) --\n"
            "-- When joining these tables, use "
            "EXACTLY these conditions:\n"
            + "\n".join(
                f"--   {h}"
                for h in join_hints
            )
        )

    except Exception as exc:

        logger.warning(
            f"GRAPH_CONTEXT_ERROR={exc}"
        )

        return ""



def inject_mandatory_tables(
    schema_rag,
    schema_chunks,
    mandatory_tables,
):
    """
    Ensure all mandatory tables are
    present in schema_chunks.
    """

    present_tables = {
        c.table_name
        for c in schema_chunks
    }

    missing_tables = (
        set(mandatory_tables)
        - present_tables
    )

    logger.error(
        f"PRESENT_TABLES={sorted(present_tables)}"
    )

    logger.error(
        f"MANDATORY_TABLES={sorted(mandatory_tables)}"
    )

    logger.error(
        f"MISSING_TABLES={sorted(missing_tables)}"
    )

    logger.warning(
        f"MISSING_MANDATORY_TABLES="
        f"{sorted(missing_tables)}"
    )

    for table_name in missing_tables:

        try:

            injected_chunks = schema_rag.retrieve(
                table_name,
                top_k=1
            )

            injected = next(
                (
                    c
                    for c in injected_chunks
                    if c.table_name == table_name
                ),
                None,
            )

            if injected:

                injected.score = max(
                    injected.score,
                    3.0
                )

                schema_chunks.append(
                    injected
                )

                logger.warning(
                    f"MANDATORY_TABLE_INJECTED="
                    f"{table_name}"
                )

        except Exception as exc:

            logger.warning(
                f"MANDATORY_TABLE_INJECTION_ERROR "
                f"{table_name}: {exc}"
            )

    schema_chunks.sort(
        key=lambda t: t.score,
        reverse=True
    )
    
    logger.warning(
            "TOP_RERANKED_TABLES=\n"
            + "\n".join(
                f"{i+1:02d}. "
                f"{c.table_name:<30} "
                f"score={c.score:.4f}"
                for i, c in enumerate(schema_chunks[:20])
            )
        )
    
    
    final_tables = {
        c.table_name
        for c in schema_chunks
    }

    dropped_tables = (
        set(mandatory_tables)
        - final_tables
    )

    if dropped_tables:

        logger.error(
            "GROUNDING_AUDIT_FAILED="
            f"{sorted(dropped_tables)}"
        )

    else:

        logger.info(
            "GROUNDING_AUDIT_OK"
        )

    return schema_chunks



def build_entity_reference_block(
    quoted_entities
) -> str:

    if not quoted_entities:
        return ""

    return (
        "\n\n"
        "-- ENTITY REFERENCES --\n"
        "-- These values appear verbatim "
        "in the user question.\n"
        "-- Preserve them exactly when "
        "generating SQL.\n"
        + "\n".join(
            f'--   "{e}"'
            for e in quoted_entities
        )
    )




def build_entity_resolution_block(
    resolved_entities
) -> str:

    if not resolved_entities:
        return ""

    block = (
        "\n\n"
        "-- ENTITY RESOLUTION --\n"
        "-- These entities were resolved "
        "against the database.\n"
    )

    for r in resolved_entities:

        for candidate in r.candidates:

            block += (
                f'\n--   "{r.entity}"'
                f'\n--      -> '
                f'{candidate.table}.'
                f'{candidate.column}'
                f' = {candidate.value}'
            )

    return block




def build_mandatory_tables(
    grounded_tables: set[str],
    resolved_tables: set[str],
) -> set[str]:

    return (
        set(grounded_tables)
        | set(resolved_tables)
    )
    

def extract_resolved_tables(
    resolved_entities
) -> set[str]:

    tables = set()

    for r in resolved_entities:

        for candidate in r.candidates:

            tables.add(
                candidate.table
            )

    return tables


# for grounding and rag fusion
def extract_grounded_tables(term_grounding: dict) -> set[str]:

    tables = set()

    logger.warning(
        f"EXTRACT_INPUT={term_grounding}"
    )
    
    logger.info(
            f"EXTRACT_INPUT={term_grounding}"
        )
    
    print(
            f"EXTRACT_INPUT={term_grounding}"
        )

    for refs in term_grounding.get("mapped", {}).values():

        for ref in refs:

            logger.warning(
                f"CHECK_REF={ref}"
            )

            m = re.search(
                r"table `([^`]+)`",
                ref
            )

            logger.warning(
                f"REGEX_MATCH={m}"
            )

            if m:

                logger.warning(
                    f"ADDING_TABLE={m.group(1)}"
                )

                tables.add(
                    m.group(1)
                )

    logger.warning(
        f"EXTRACT_OUTPUT={tables}"
    )

    return tables

@lru_cache(maxsize=1)
def _kb_allowed_codes() -> frozenset:
    """Every enum code declared anywhere in the KB (uppercased). A literal
    from this set is a DOCUMENTED value, not a hallucination -- the enum
    guard already validates it against the right column."""
    codes: set = set()
    try:
        from RAG.knowledge_base import load_kb
        for entry in load_kb().values():
            for cd in (entry.get("columns") or {}).values():
                av = (cd or {}).get("allowed_values")
                if isinstance(av, dict):
                    codes |= {str(k).upper() for k in av}
                elif isinstance(av, list):
                    codes |= {str(v).upper() for v in av}
    except Exception:
        pass
    return frozenset(codes)


def _grounding_conf(question: str, sql: str) -> float:
    """ANTI-HALLUCINATION component (v3.7, 0..1): the share of the SQL's
    filter literals that are PROVABLE -- present in the question, or
    declared in the KB's enum allowed_values. Each "Assuming"-style guess
    comment counts as one extra unproven unit. 1.0 when there is nothing
    to hallucinate. Deterministic and fail-safe (any error -> neutral 1.0).

    This is the in-pipeline mirror of run_eval's grounding metric: the
    evaluation showed hallucinated-filter answers scoring up to 0.97 with
    the retrieval/generation/semantic components alone, because none of
    them looks at WHERE the literal values come from.
    """
    try:
        if not (sql or "").strip():
            return 1.0
        ql = (question or "").lower()
        allowed = _kb_allowed_codes()
        total = grounded = 0
        # Guess comments: the model documenting its own invention.
        for m in re.finditer(r"--[^\n]*", sql):
            if re.search(r"assum|guess|placeholder|add condition", m.group(0), re.I):
                total += 1
        # String literals: grounded if quoted from the question or
        # declared as an enum code in the KB.
        for lit in dict.fromkeys(re.findall(r"'([^']+)'", sql)):
            total += 1
            if lit.lower() in ql or lit.upper() in allowed:
                grounded += 1
        # Numeric comparison literals (LIMIT excluded; 0/1 tolerated).
        nums_q = set(re.findall(r"\d+", question or ""))
        sql_wo_limit = re.sub(r"\bLIMIT\s+\d+", "", sql, flags=re.I)
        for n in dict.fromkeys(re.findall(r"(?:=|<>|!=|>=|<=|>|<)\s*(\d+)",
                                          sql_wo_limit)):
            total += 1
            if n in nums_q or n in ("0", "1"):
                grounded += 1
        return round(grounded / total, 4) if total else 1.0
    except Exception:
        return 1.0


def _compute_confidence(schema_chunks, attempt: int, max_retries: int, success: bool,
                        question: str = "", sql: str = "") -> dict:
    """
    Confidence = 0.3 × rag_conf + 0.4 × gen_conf + 0.3 × sem_conf
    (unchanged historical formula; ground_conf is computed and REPORTED
    alongside for observability, but does NOT enter the score)

    ground_conf : anti-hallucination (deterministic). Share of filter
               literals provable from the question or the KB's enum
               allowed_values; "Assuming" guess comments penalize.
               Evaluation (2026-07-28) showed hallucinated answers at
               0.91-0.97 under the old formula -- this component is the
               fix.

    sem_conf : deterministic semantic-consistency score (agent/sem_conf.py).
               Synonym-aware intent checks (COUNT/AVG/MAX/MIN/SUM/recency/
               duration/DISTINCT/grouping) + target-table presence.
               Measures whether the SQL plausibly ANSWERS the question --
               catches silent wrong-answer cases that execute fine. A 1.0
               means "nothing manifestly inconsistent", not "proven
               correct"; below 1.0 is a reliable inconsistency signal.

    The two SECONDARY components describe the path taken, not the answer:

    rag_conf : mean cosine similarity of RAG-retrieved tables (0-1).
    gen_conf : linear retry decay — (max_retries - (attempt-1)) / max_retries.
    """
    if not success:
        return {"score": 0.0, "score_strict": 0.0, "rag_conf": 0.0, "gen_conf": 0.0,
                "sem_conf": 0.0, "ground_conf": 0.0, "target_table": ""}

    rag_scores = [t.cosine_score for t in schema_chunks if t.score > 0]
    rag_conf   = round(sum(rag_scores) / len(rag_scores), 4) if rag_scores else 0.5
    gen_conf   = round((max_retries - (attempt - 1)) / max_retries, 4)

    # FP-minimisation (target-table selection).
    #
    # The semantic target-table check must key on the SINGLE most-relevant
    # table, NOT the whole retrieved set. Previously target_tables held every
    # RAG-retrieved table (up to ~25), so sem_conf's "target present in the
    # SQL" test was trivially satisfied by ANY of them: a query over
    # act/fac/org/capab scored high even though the real target abs_point was
    # absent from the SQL entirely (observed in real runs). Passing only the
    # top-scored table makes a wrong-table answer actually collapse sem_conf.
    try:
        ranked = [t for t in schema_chunks if getattr(t, "score", 0) > 0]
        target_tables = [max(ranked, key=lambda t: t.score).table_name] if ranked else []
        sem_conf = _compute_sem_conf(question, sql, target_tables)
    except Exception:
        target_tables = []
        sem_conf = 1.0  # neutral on any unexpected failure

    # Deterministic veto: a data query answered by a metadata statement
    # (SHOW / DESCRIBE / EXPLAIN) never returns the requested rows, so it
    # cannot be a correct answer regardless of what sem_conf computed. This
    # catches the "intent leak" false positives where a data question is
    # answered by SHOW TABLES and still reported as a confident success.
    if re.match(r"^\s*(show|describe|desc|explain)\b", sql or "", re.IGNORECASE):
        sem_conf = min(sem_conf, 0.2)

    ground_conf = _grounding_conf(question, sql)

    # Two complementary aggregations, both reported (HISTORICAL formulas,
    # kept unchanged on purpose):
    #
    #   score        (additive)       : 0.3·rag + 0.4·gen + 0.3·sem
    #     -- each component is one vote among three; a wrong semantic
    #        penalty costs at most 0.3. Drives the UI banner.
    #
    #   score_strict (multiplicative) : (0.4·rag + 0.6·gen) × sem
    #     -- sem_conf acts as a proportional veto: a technically perfect
    #        answer that doesn't address the question collapses toward 0.
    #
    # ground_conf (anti-hallucination) is reported ALONGSIDE for
    # observability -- visible in XAI and evaluation reports -- but does
    # NOT enter either score.
    score        = round(0.3 * rag_conf + 0.4 * gen_conf + 0.3 * sem_conf, 4)
    score_strict = round((0.4 * rag_conf + 0.6 * gen_conf) * sem_conf, 4)

    return {
        "score": score,
        "score_strict": score_strict,
        "rag_conf": rag_conf,
        "gen_conf": gen_conf,
        "sem_conf": sem_conf,
        "ground_conf": ground_conf,
        "target_table": target_tables[0] if target_tables else "",
    }

def _build_xai(question: str, sql: str, schema_chunks, attempt: int,
               attempts_detail: list, llm=None) -> dict:
    """
    Post-hoc explainability block attached to explanation["xai"]:

      table_usage     : for every RAG-retrieved table -- was it actually used
                        in the SQL, its raw cosine similarity, and HOW it got
                        retrieved (vector similarity vs boost/rescue vs
                        fk-expansion/lexical). Deterministic, zero cost.
      counterfactuals : plain-language "this answer depended on X" /
                        "Y was retrieved but unused" notes, derived from
                        table_usage + the retry history. Deterministic.
      sql_rationale   : optional LLM self-explanation of WHY the SQL uses
                        these tables/joins/filters. Costs one extra LLM
                        call, so it is OFF by default -- enable with env
                        REQA_XAI_RATIONALE=1. Never blocks the answer:
                        any failure degrades to None.
    """
    xai = {"table_usage": [], "counterfactuals": [], "sql_rationale": None}

    try:
        for t in schema_chunks or []:
            name = getattr(t, "table_name", "") or ""
            if not name:
                continue
            used = bool(re.search(rf"\b{re.escape(name)}\b", sql or "", re.IGNORECASE))
            score = float(getattr(t, "score", 0) or 0)
            cosine = float(getattr(t, "cosine_score", 0) or 0)
            if score <= 0:
                origin = "fk-expansion/lexical"
            elif score - cosine > 0.3:
                origin = "boost/rescue"       # score inflated far above raw similarity
            else:
                origin = "vector"
            xai["table_usage"].append({
                "name": name, "used_in_sql": used,
                "cosine": round(cosine, 4), "score": round(score, 4),
                "origin": origin,
            })

        for u in xai["table_usage"]:
            if u["used_in_sql"] and u["origin"] == "boost/rescue":
                xai["counterfactuals"].append(
                    f"The SQL relies on table '{u['name']}', whose raw similarity was only "
                    f"{u['cosine']*100:.0f}% -- it was retrieved thanks to the sample-query "
                    f"boost/rescue. Without that mechanism, this answer would likely have failed."
                )
            if u["used_in_sql"] and u["origin"] == "fk-expansion/lexical":
                xai["counterfactuals"].append(
                    f"Table '{u['name']}' was injected by FK-expansion/lexical fallback "
                    f"(no measured similarity) and the SQL uses it."
                )
        unused = [u["name"] for u in xai["table_usage"] if not u["used_in_sql"]]
        if unused:
            xai["counterfactuals"].append(
                "Retrieved but not used in the SQL: " + ", ".join(unused) + "."
            )
        if attempt > 1 and attempts_detail:
            failed_stages = [a.get("failed_at") for a in attempts_detail if a.get("failed_at")]
            if failed_stages:
                xai["counterfactuals"].append(
                    f"The accepted SQL only emerged at attempt {attempt}, after "
                    f"{attempt - 1} rejected attempt(s) (failed at: {', '.join(failed_stages)}). "
                    f"The error feedback loop was decisive for this answer."
                )
    except Exception:
        pass  # deterministic XAI must never break the pipeline

    if os.getenv("REQA_XAI_RATIONALE", "0") == "1" and llm is not None:
        try:
            self.llm.set_langfuse_trace_step("XAI")
            rationale = llm.complete(
                "You explain SQL queries. In at most 3 short bullet points, explain WHY "
                "the query uses these tables, joins and filters to answer the question. "
                "Be factual and concise. No preamble.",
                [{"role": "user", "content": f"Question: {question}\n\nSQL:\n{sql}"}],
                max_tokens=200,
            )
            xai["sql_rationale"] = (rationale or "").strip() or None
        except Exception:
            xai["sql_rationale"] = None

    return xai


def _llm_reformulations(question: str, schema_chunks, llm, error_feedback: str = "",
                        max_n: int = 3) -> list:
    """
    Ask the LLM to rewrite an unclear/failed user question into up to
    `max_n` clearer variants, grounded in the retrieved tables' actual
    vocabulary (table + column names) so the rewrites are likely
    answerable -- unlike the user's original phrasing.

    Complements (does not replace) the catalog suggestions from
    sample_queries: catalog items are GUARANTEED answerable but may drift
    from what the user meant; LLM rewrites stay close to the user's intent
    but are NOT guaranteed to succeed. The UI labels them accordingly.

    Cost: one extra LLM call, on FAILURE paths only (which already burned
    up to 3 calls). Disable with REQA_LLM_REFORMULATE=0. Skipped when the
    failure looks like an infrastructure outage (the LLM is unreachable
    anyway -- no point adding a hanging call on top).
    """
    if os.getenv("REQA_LLM_REFORMULATE", "1") != "1" or llm is None:
        return []
    err = (error_feedback or "").lower()
    if "connection" in err or "circuit breaker" in err or "max retries exceeded" in err:
        return []

    try:
        # Light schema vocabulary: top tables + a handful of real columns
        vocab_lines = []
        for t in (schema_chunks or [])[:3]:
            name = getattr(t, "table_name", "") or ""
            cols = [c.get("name") for c in (getattr(t, "payload", {}) or {}).get("columns", [])
                    if isinstance(c, dict) and c.get("name")][:8]
            if name:
                vocab_lines.append(f"- {name}: {', '.join(cols) if cols else '(columns unknown)'}")
        vocab = "\n".join(vocab_lines) or "(no table context available)"
        
        self.llm.set_langfuse_trace_step("REFORMULATION")
        raw = llm.complete(
            "A user asked a database question that could not be answered as phrased. "
            "Rewrite it as up to {n} clearer, more specific questions that are likely "
            "answerable over the tables below. Stay faithful to the user's intent. "
            "Use the exact table/column vocabulary provided. "
            "Output ONLY the questions, one per line, no numbering, no commentary.".format(n=max_n),
            [{"role": "user", "content": f"Original question: {question}\n\nAvailable tables and key columns:\n{vocab}"}],
            max_tokens=180,
        )

        seen, out = set(), []
        for line in (raw or "").splitlines():
            q = re.sub(r"^\s*(?:[-*•]|\d+[.)])\s*", "", line).strip().strip('"')
            if not q or "?" not in q:
                continue
            key = q.lower()
            if key == (question or "").strip().lower() or key in seen:
                continue
            seen.add(key)
            out.append(q)
            if len(out) >= max_n:
                break
        return out
    except Exception:
        return []  # reformulation is an enrichment, never a failure cause


def _combine_suggestions(catalog: list, reformulations: list, max_total: int = 6) -> list:
    """
    Merge the two alternative-question sources into ONE unified, deduplicated
    list for the UI:

      catalog        -- curated sample_queries of the RAG-matched tables:
                        GUARANTEED answerable, shown first, tagged "catalog";
      reformulations -- LLM rewrites of the user's own question: closest to
                        the user's actual intent but not execution-verified,
                        tagged "reformulation", appended after.

    Dedup is done on a normalized form (lowercase, alphanumerics only) so
    that an LLM rewrite that lands on an existing catalog question -- which
    happens often, and is actually a GOOD sign -- doesn't show up twice.
    """
    seen = set()
    combined = []

    def _norm(q: str) -> str:
        return re.sub(r"[^a-z0-9 ]", "", (q or "").lower()).strip()

    for s in catalog or []:
        q = s.get("question", "") if isinstance(s, dict) else str(s)
        key = _norm(q)
        if q and key and key not in seen:
            seen.add(key)
            combined.append({
                "question": q,
                "source": "catalog",
                "table": s.get("table", "") if isinstance(s, dict) else "",
            })
        if len(combined) >= max_total:
            return combined

    for q in reformulations or []:
        key = _norm(q if isinstance(q, str) else "")
        if q and key and key not in seen:
            seen.add(key)
            combined.append({"question": q, "source": "reformulation", "table": ""})
        if len(combined) >= max_total:
            break

    return combined


def _is_ambiguous_retrieval(schema_chunks) -> bool:
    """
    Vague-question detector based on the retrieval signature observed in
    production: an ambiguous question ("show me the stuff") embeds
    moderately close to EVERYTHING and strongly close to NOTHING -- the
    top-k cosine similarities form a flat plateau (e.g. 0.68-0.72, spread
    0.04) instead of showing a clear winner. A real question about a
    specific table shows either a detached leader or a boost/rescue hit.

    Returns True (route to the "unclear" flow: suggestions +
    reformulations instead of answering on a near-arbitrary table) when:
      * at least 3 tables carry a positive cosine score, AND
      * no table was pulled up by boost/rescue (score >> cosine means the
        question closely matched a curated sample question -- a strong
        signal the question IS clear), AND
      * the cosine spread across candidates is below the threshold, AND
      * even the best cosine is unremarkable (< 0.85).

    Tunables via env: REQA_AMBIGUITY_DETECT (default "1"),
    REQA_AMBIGUITY_SPREAD (default "0.06").
    """
    
    
    
    
    if os.getenv("REQA_AMBIGUITY_DETECT", "1") != "1":
        return False
    try:
        cosines = [float(t.cosine_score) for t in (schema_chunks or [])
                   if getattr(t, "cosine_score", None) and t.cosine_score > 0]
        logger.warning(
                f"AMBIGUITY_CHECK "
                f"spread={spread:.4f} "
                f"max={max(cosines):.4f}"
            )
        if len(cosines) < 3:
            return False
        boosted = any(
            (float(getattr(t, "score", 0) or 0) - float(getattr(t, "cosine_score", 0) or 0)) > 0.3
            for t in schema_chunks
        )
        if boosted:
            return False
        # v2.5 (2026-08-06 false negative): a flat plateau is only
        # VAGUENESS when it spans UNRELATED tables. "Equipment types by
        # category" matches eqpt_type / misc_eqpt_type / weapon_type with
        # near-identical cosines -- an UMBRELLA question about ONE family
        # (they are subtypes of the same parent), not an unclear one; the
        # generator can answer over the parent table or a union, and
        # declining it is a false refusal (observed in production). The
        # plateau is treated as COHERENT (not ambiguous) when the top
        # candidates share a table-name token ("..._type", "act_...") or
        # all belong to the same KB domain -- a genuinely vague question
        # ("show me the stuff") plateaus ACROSS families and domains.
        _tops = [t for t in schema_chunks
                 if getattr(t, "cosine_score", 0) and t.cosine_score > 0][:4]
        if len(_tops) >= 2:
            _GENERIC = {"", "id", "assoc"}
            _token_sets = [set((t.table_name or "").lower().split("_"))
                           - _GENERIC for t in _tops]
            _shared = set.intersection(*_token_sets) if _token_sets else set()
            _domains = set()
            for t in _tops:
                try:
                    _domains.add(_domain_str(t.payload.get("domain", "")))
                except Exception:
                    _domains.add("")
            _same_domain = len(_domains) == 1 and "" not in _domains
            if _shared or _same_domain:
                logger.info(
                    "AMBIGUITY DETECT: flat plateau but candidates are "
                    f"RELATED (shared token(s) {sorted(_shared) or 'none'}, "
                    f"same domain={_same_domain}) -- treating as a family "
                    "umbrella question, proceeding")
                return False
        spread = max(cosines) - min(cosines)
        threshold = float(os.getenv("REQA_AMBIGUITY_SPREAD", "0.06"))
        return spread < threshold and max(cosines) < 0.85
    except Exception:
        return False


# human-readable stage labels for XAI
_STAGE_LABELS = {
    "llm":          "LLM generation",
    "static_check": "Static check (sqlglot)",
    "explain":      "EXPLAIN dry-run (MariaDB)",
    "execution":    "SQL execution",
    "impossible":   "LLM declared impossible",
}

from agent.exceptions import (
    SchemaLimitation,
    AnswerabilityStatus,
)

from agent.pipeline_base import PipelineResult, PipelineBase


def _numbers_match(question_a: str, question_b: str) -> bool:
    """True when both texts carry the same set of numeric literals.

    Second layer of the numeric-literal gate (the first lives in
    schema_rag.best_sample_query): whatever a lexical matcher decides, a
    catalog gold SQL must never be executed for a question whose numbers
    differ from the catalog question's -- ">10" is not an answer to
    "more than 20". Redundant on purpose, like the POSITIVE/readonly
    double-guard above it: the cost of a miss is a silently WRONG answer.
    """
    _nums = lambda s: set(re.findall(r"\d+(?:\.\d+)?", s or ""))
    return _nums(question_a) == _nums(question_b)


def _domain_str(v) -> str:
    if isinstance(v, list):
        return v[0] if v else ""
    return str(v) if v else ""


class Pipeline(PipelineBase):
    """
    End-to-end agentic pipeline (faithful to the architecture diagram):

    User Query
      → [0] Intent Classification  (data_query vs schema_exploration vs unclear)
           ↺ schema_exploration / unclear → answered directly, no SQL generated
      → [1] Embedding + Schema RAG  (retrieve relevant table schemas from Qdrant)
      → [2] SQL Generator  (LLM generates SQL with schema context + all table names)
      → [3] Static Check   (sqlglot — syntax + SELECT-only enforcement)
           ↺ retry with error feedback up to max_retries
      → [4] EXPLAIN dry-run  (MariaDB EXPLAIN — no data touched)
           ↓ failure → Circuit Breaker → Graceful Failure
      → [5] DB Execution
           ↓ failure → Circuit Breaker → Graceful Failure
      → [6] Renderer  (LLM formats results as natural language)
      → Final Answer
    """



    def __init__(
        self,
        schema_rag,
        sql_generator,
        static_checker,
        dry_runner,
        executor,
        renderer,
        circuit_breaker,
        max_retries: int = 3,
        allow_reformulation = True    # if self.allow_reformulation is False, pipeline will never _try_auto_answer()
    ):
        super().__init__( schema_rag, sql_generator,  allow_reformulation)
        self.static_checker = static_checker
        self.dry_runner = dry_runner
        self.executor = executor
        self.renderer = renderer
        self.cb = circuit_breaker
        self.max_retries = max_retries
        self.relationship_validator = (RelationshipValidator())        

        # this is used to retrieve settings override in the request]
        self.schema_rag.set_parent_pipeline(self)
        self.sql_generator.set_parent_pipeline(self)
        self.renderer.set_parent_pipeline(self)
        
        logger.warning(
            "RELATIONSHIP_VALIDATOR_INITIALIZED"
        )
        
        logger.info( "agent/pipeline.py.__init__()" )


    #
    #   Langfuse trace utilities. Use these to help read the LangFuse traces in http page
    #
    #       Set the query for this whole request.
    #       Then at each step, set the step name ex: Plan
    #       Also mark the retries.
    #      
    #

    #
    #   set_langfuse_trace_query()
    #           
    def set_langfuse_trace_query(self, name ):
        self.sql_generator.llm.set_langfuse_trace_query(name)

    #
    #
    #
    def set_langfuse_trace_tag(self, tag ):
        self.sql_generator.llm.set_langfuse_trace_tag(tag)

    #
    #   langfuse_trace_step()
    #  
    def set_langfuse_trace_step(self, step ):
        self.sql_generator.llm.set_langfuse_trace_step(step)
        

    #
    #   set_langfuse_trace_attempt()
    #  
    def set_langfuse_trace_attempt(self,  attempt = 1 ):        
        self.sql_generator.llm.set_langfuse_trace_attempt(attempt)


    #
    #   Set the complete current request before use 
    #   There are many possible options
    #   for example: { "num_rated_rules" : 3 } to switch opn / off the rated rules per request
    #
    def set_current_request(self, req):
        self.current_request = req


    def _try_auto_answer(self, original_question: str, schema_chunks,
                         error_feedback: str = "") -> Optional[PipelineResult]:
        """
        Silent background auto-answer: instead of returning a failure with a
        list of suggestions for the user to pick from, pick the best
        equivalent question ourselves, answer it, and return that answer.

        For each LLM reformulation of the failed question, we re-run the FULL
        pipeline (with allow_reformulation=False so it can't recurse) -- so
        every candidate automatically benefits from the catalog short-circuit
        and the entity-name anchor. The FIRST candidate that both executes
        successfully AND clears the confidence gate is returned, annotated
        with which reformulation actually answered it (explanation
        ["answered_reformulation"]) so the UI can show a light, honest note
        rather than a suggestion list.

        v2.2 efficiency pass:
          - candidates are SORTED by embedding cosine to the ORIGINAL
            question (closest first), so the most faithful rewrite is tried
            first and a drifted one can no longer win by output-order luck;
          - attempts are capped (REQA_AUTO_ANSWER_MAX_TRIES, default 2) to
            bound worst-case latency on failures.

        The confidence gate (REQA_AUTO_ANSWER_MIN_CONF, default 0.6) is what
        keeps this from silently serving a drifted/wrong answer -- if even the
        best reformulation is doubtful, we fall back to the normal suggestion
        behaviour instead of guessing. Returns None if nothing qualifies.
        """
        min_conf = float(os.getenv("REQA_AUTO_ANSWER_MIN_CONF", "0.6"))
        max_tries = int(os.getenv("REQA_AUTO_ANSWER_MAX_TRIES", "2"))
        try:
            candidates = _llm_reformulations(
                original_question, schema_chunks,
                getattr(self.sql_generator, "llm", None),
                error_feedback=error_feedback,
            )
        except Exception as exc:
            logger.warning(f"_try_auto_answer: reformulation failed: {exc}")
            return None

        # Deduplicate, drop the original question itself
        seen, cleaned = set(), []
        for cand in candidates or []:
            cand = (cand or "").strip()
            key = cand.lower()
            if not cand or key in seen or key == (original_question or "").strip().lower():
                continue
            seen.add(key)
            cleaned.append(cand)
        if not cleaned:
            return None

        # v2.2: sort candidates by embedding cosine to the ORIGINAL question,
        # closest first -- the most faithful rewrite is tried before any
        # drifted one can consume a full pipeline run (or win by output-order
        # luck). Fail-safe: if the embedder is unavailable or errors, keep
        # the LLM's output order (previous behaviour) rather than aborting.
        embedder = getattr(self.schema_rag, "embedder", None)
        if embedder is not None and len(cleaned) > 1:
            try:
                import numpy as np
                q_vec = np.asarray(embedder.embed(original_question), dtype=float)
                q_norm = float(np.linalg.norm(q_vec)) or 1.0

                def _sim(c: str) -> float:
                    v = np.asarray(embedder.embed(c), dtype=float)
                    return float(q_vec @ v / (q_norm * (float(np.linalg.norm(v)) or 1.0)))

                sims = {c: _sim(c) for c in cleaned}
                cleaned.sort(key=lambda c: sims[c], reverse=True)
                logger.info("AUTO-ANSWER candidate order: "
                            + " | ".join(f"{sims[c]:.2f} {c[:60]!r}" for c in cleaned))
            except Exception as exc:
                logger.warning(f"_try_auto_answer: similarity ranking failed, "
                               f"keeping LLM order: {exc}")

        # v2.2: hard cap on attempts -- bounds worst-case latency on failures.
        for cand in cleaned[:max_tries]:
            try:
                res = self.run(cand, allow_reformulation=False)
            except Exception as exc:
                logger.warning(f"_try_auto_answer: candidate run failed ({cand!r}): {exc}")
                continue
            conf = ((res.explanation or {}).get("confidence") or {}).get("score")
            if res.success and (conf is None or conf >= min_conf):
                res.explanation = res.explanation or {}
                res.explanation["answered_reformulation"] = cand
                res.explanation["original_question"] = original_question
                logger.info(f"AUTO-ANSWER via reformulation={cand!r} conf={conf}")
                return res
        return None



    #
    #   overridable function called at the beginning of run()
    #
    def pre_run(self, question: str, progress_callback=None, allow_reformulation: bool = True, **kwargs):
        
        options = kwargs.get( "options", {} )
        debug = options.get( "debug", False )
        force = options.get( "force", False )
        langfuse_tag = options.get( "langfuse_tag", "test" )

        self.sql_generator.llm.set_langfuse_trace_step("BASE PIPELINE RUN")
        self.sql_generator.llm.set_langfuse_trace_query( f"{question}" )
        self.sql_generator.llm.set_langfuse_trace_tag( f"{langfuse_tag}" )
        


    def run(self, question: str, progress_callback=None,
            allow_reformulation: bool = True, **kwargs) -> PipelineResult:
        """
        progress_callback: optional callable(dict) -> None, invoked at each
        key stage (schema_rag, intent_classification, sql_generation,
        static_check, explain, execution, rendering) with a small dict
        {"stage": ..., "attempt": ..., "of": ...}. Used by api.py's
        background-job endpoints to expose live progress to the UI via
        polling. Entirely optional and side-effect-free when omitted --
        existing callers (e.g. /tasks/send) are unaffected. Never allowed
        to crash the pipeline: any exception raised by the callback itself
        is swallowed (a broken progress reporter must not break the actual
        query).        
        """
    
        self.pre_run(question, None, allow_reformulation, **kwargs)
   
     
        debug_rval = {} # Returned value of debug
        options = kwargs.get( "options", {} )
        debug = options.get( "debug", False )
        force = options.get( "force", False )
        langfuse_tag = options.get( "langfuse_tag", "test" )
        logger.info( f"agent/pipeline run({question}, {kwargs})" )

  


        def _report(stage: dict) -> None:
            if progress_callback is None:
                return
            try:
                progress_callback(stage)
            except Exception as cb_exc:
                logger.warning(f"progress_callback raised, ignoring: {cb_exc}")

        if self.cb.is_open():
            return PipelineResult(
                success=False,
                answer="Service temporarily unavailable — too many consecutive failures.",
                error="Circuit breaker open",
                debug=debug_rval
            )

        logger.info(f"run question={question}")

        # Overall wall-clock budget for one run(). The UI/API layer times out
        # at ~400s; without a budget here, a failing question can burn
        # max_retries LLM calls PLUS auto-answer reformulation re-runs (each
        # up to a FULL pipeline pass) and exceed that limit, so the user sees
        # a raw "API request timeout" instead of a graceful failure with
        # suggestions. Default 340s keeps headroom below the 400s timeout.
        # Set REQA_TIME_BUDGET_S=0 to disable.
        _time_budget = float(os.getenv("REQA_TIME_BUDGET_S", "340"))
        _started_at = time.monotonic()

        def _out_of_time() -> bool:
            return _time_budget > 0 and (time.monotonic() - _started_at) > _time_budget

        # Apply the domain glossary (e.g. "action" -> "activity") BEFORE
        # schema retrieval, not just later inside classify_intent()/
        # generate() as before. Previously the RAG step searched with the
        # user's raw wording, so a question using a domain synonym for a
        # table that doesn't share that literal wording in its embedding
        # text could fail to retrieve that table into the schema context
        # at all -- the LLM then has no real schema for it and invents a
        # plausible-looking but nonexistent table name instead. Verified
        # against a real failure: "Show the category code list of action"
        # generated "FROM action" (no such table; the real table is "act"),
        # because "act"/"activity" was never actually retrieved into
        # context for that query. classify_intent()/generate() already
        # re-apply this substitution themselves -- harmless and idempotent
        # on an already-canonical question, so no behavior changes there.
        # Keep the ORIGINAL (pre-rewrite) wording for the catalog short-circuit
        # below: the curated sample_queries are stored in naturalised form
        # ("Absolute Point"), so matching must use the user's original words,
        # not the entity-rewritten token ("abs_point"). The rewrite is still
        # applied for RETRIEVAL, where the real table token is what helps.
        original_question = question
        question = self.sql_generator._apply_domain_synonyms(question)
        
        ctx = GroundingContext(
            original_question=original_question
        )
        
        logger.info(
            f"[GROUNDING_CONTEXT_INIT] "
            f"{ctx.summary()}"
        )
            
        
        
        
        # ======================================================
        # STEP 1 - TERM GROUNDING
        # ======================================================

        try:

            from agent.term_grounding import ground_terms

            _tg = ground_terms(original_question)

            logger.error(
                "GROUND_TERMS_RESULT=%s",
                _tg
            )

            logger.error(
                "GROUND_TERMS_MAPPED_KEYS=%s",
                sorted(_tg.get("mapped", {}).keys())
            )

            logger.error(
                "GROUND_TERMS_UNRESOLVED=%s",
                sorted(_tg.get("unresolved", []))
            )

            grounded_tables = extract_grounded_tables(_tg)

            logger.error(
                "EXTRACTED_GROUNDED_TABLES=%s",
                sorted(grounded_tables)
            )

            logger.info(
                f"TERM_GROUNDING_RAW={_tg}"
            )
            
            


            grounded_tables = extract_grounded_tables(_tg)
            
            logger.error(
                
                "EXTRACTED_GROUNDED_TABLES=%s",
                
                sorted(grounded_tables)
                
                )
            
            #logger.error(
             #   "EXTRACTED_GROUNDED_TABLES=%s",
              #  sorted(grounded_tables)
            #)
            
            
            ctx.add_grounded_tables(
                grounded_tables
            )
            
            logger.error(
                "CTX_GROUNDED_TABLES=%s",
                sorted(ctx.grounded_tables)
            )
                        
            #logger.error(
            #    "CTX_GROUNDED_TABLES=%s",
             #   sorted(ctx.grounded_tables)
            #)
            

            ctx.refresh_mandatory_tables()
            
            logger.error(
                "CTX_MANDATORY_TABLES=%s",
                sorted(ctx.mandatory_tables)
            )
            
            #logger.error(
            #    "CTX_MANDATORY_TABLES=%s",
            #    sorted(ctx.mandatory_tables)
            #)
                        
            logger.warning(
                "CTX_MANDATORY_AFTER_REFRESH=%s",
                sorted(ctx.mandatory_tables)
            )

            logger.warning(
                f"CTX_AFTER_TERM_GROUNDING="
                f"{ctx.dump()}"
            )
            
            
            
            ctx.grounded_tables.update(
                grounded_tables
            )

            #logger.error(
            #    f"GROUNDING_AFTER_EXTRACT={sorted(grounded_tables)}"
            #)

            #
            # Single source of truth for mandatory schema tables.
            # Initially populated by term grounding.
            #
            mandatory_tables = ctx.mandatory_tables

            logger.warning(
                f"INITIAL_MANDATORY_TABLES="
                f"{sorted(mandatory_tables)}"
)

        except Exception as e:

            logger.warning(
                f"TERM GROUNDING unavailable: {e}"
            )

            _tg = {
                "mapped": {},
                "unresolved": []
            }

            grounded_tables = set()
            
            mandatory_tables = set()
            
            logger.exception(
                "TERM_GROUNDING_FAILED"
            )
            
        # ======================================================
        # STEP 1.5 - DATA GROUNDING (TRACE ONLY)
        # ======================================================

        logger.info(
            f"UNRESOLVED_TERMS={_tg.get('unresolved', [])}"
            )

        logger.info(
            f"QUOTED_ENTITIES={_tg.get('quoted_entities', [])}"
            )
        
        
        logger.info("=" * 80)
        
        logger.info("DATA GROUNDING TRACE")

        logger.info(
            f"MAPPED_TERMS={_tg.get('mapped', {})}"
        )

        logger.info(
            f"UNRESOLVED_TERMS={_tg.get('unresolved', [])}"
        )

        #logger.error(
        #    f"TERM_GROUNDING_RAW={_tg}"
        #)

        logger.info("=" * 80)
                        
        
        # ======================================================
        # STEP 2 - RAG RETRIEVAL
        # ======================================================

        _report({"stage": "schema_rag"})

        try:

            schema_chunks = self.schema_rag.retrieve(
                question,
                debug=debug,
                debug_rval=debug_rval
            )
            
            #logger.error(
            #   f"FIRST_CALL_MANDATORY={sorted(ctx.mandatory_tables)}"
            #)
            
            schema_chunks = inject_mandatory_tables(
                self.schema_rag,
                schema_chunks,
                ctx.mandatory_tables
            )
            
            logger.error("BBBB_FINAL_RAG_DEBUG")
            
            logger.warning(
                "FINAL_RAG_TABLES="
                + str(sorted({
                    c.table_name
                    for c in schema_chunks
                }))
            )

            all_tables = self.schema_rag.all_table_names()

            logger.info(
                f"RAG RETRIEVED {len(schema_chunks)} TABLE(S)"
            )

            logger.info(
                "INITIAL_RANKING="
                + str([
                    f"{c.table_name}:{c.score:.4f}"
                    for c in schema_chunks
                ])
            )

        except Exception as e:

            strace = traceback.format_exc()

            logger.error(
                f"Schema RAG error: {e} - {strace}"
            )

            return PipelineResult(
                success=False,
                answer=(
                    "Schema retrieval failed. "
                    "Ensure Qdrant is running and the schema "
                    "has been indexed."
                ),
                error=f"{e} - {strace}",
                debug=debug_rval
            )
            
            
        # ======================================================
        # STEP 3 - GROUNDING RE-RANKING
        # ======================================================
        
        logger.info(
            f"MANDATORY_TABLES={sorted(ctx.mandatory_tables)}"
        )
        logger.warning(
            f"MANDATORY_TABLES_BEFORE_BOOST="
            f"{sorted(ctx.mandatory_tables)}"
        )
        
        logger.warning(
            f"SCHEMA_TABLES={[c.table_name for c in schema_chunks]}"
        )
        

        logger.warning(
            f"MISSING_GROUNDED_TABLES="
            f"{sorted(set(grounded_tables) - set(c.table_name for c in schema_chunks))}"
        )
        
        
        logger.error(
            f"DEBUG mandatory_tables exists? {'mandatory_tables' in locals()}"
        )
        
        
        logger.error(
            f"DEBUG grounded_tables={grounded_tables}"
        )
                

        MANDATORY_BOOST = 100.0

        
        

        for chunk in schema_chunks:
            
            logger.warning(
                f"BOOST_CHECK table={chunk.table_name} "
                f"grounded={chunk.table_name in grounded_tables}"
                )

            logger.info(
                f"CHECK_GROUNDING "
                f"table={chunk.table_name} "
                f"score={chunk.score:.4f}"
            )

            if chunk.table_name in mandatory_tables:

                old_score = chunk.score

                chunk.score += MANDATORY_BOOST

                logger.info(
                    f"MANDATORY BOOST "
                    f"{chunk.table_name}: "
                    f"{old_score:.4f} -> "
                    f"{chunk.score:.4f}"
                )
                
        # <----- ICI EXACTEMENT
        logger.warning(
            f"TABLES_AFTER_BOOST="
            f"{[c.table_name for c in schema_chunks]}"
        )
        
        logger.warning(
            f"MANDATORY_MISSING="
            f"{sorted(set(ctx.mandatory_tables) - set(c.table_name for c in schema_chunks))}"
        )


        
        logger.warning(
            f"MANDATORY_TABLES={sorted(ctx.mandatory_tables)}"
        )

        logger.warning(
            f"TABLES_PRESENT_IN_RAG="
            f"{sorted(set(c.table_name for c in schema_chunks))}"
        )
        
        logger.warning(
            f"MANDATORY_TABLES="
            f"{sorted(ctx.mandatory_tables)}"
        )

        logger.warning(
            f"MISSING_MANDATORY_TABLES="
            f"{sorted(set(ctx.mandatory_tables) - set(c.table_name for c in schema_chunks))}"
        )
        

        logger.warning(
        f"RAG_AFTER_GROUNDING_BOOST="
        f"{[(c.table_name, round(c.score,4)) for c in schema_chunks]}"
        )

        schema_chunks.sort(
            key=lambda t: t.score,
            reverse=True
        )
        
        logger.warning(
            "TOP_RERANKED_TABLES="
            + str([
                (
                    c.table_name,
                    round(c.score, 2)
                )
                for c in schema_chunks[:20]
            ])
        )
        
        logger.error("BBBB_RERANK_DEBUG")

        for c in schema_chunks[:20]:
            logger.warning(
                f"FINAL_CHUNK "
                f"table={c.table_name} "
                f"score={c.score:.4f}"
            )

        logger.warning(
            "OBJ_ITEM_PRESENT="
            + str(
                any(
                    c.table_name == "obj_item"
                    for c in schema_chunks
                )
            )
        )

        
        

        logger.info(
            "POST_GROUNDING_RANKING="
            + str([
                f"{c.table_name}:{c.score:.4f}"
                for c in schema_chunks
            ])
        )
        
        
        #==========================
        # STEP 3.5
        #==========================
        
        logger.error(
            f"SECOND_CALL_MANDATORY={sorted(ctx.mandatory_tables)}"
        )
        
        schema_chunks = inject_mandatory_tables(
            self.schema_rag,
            schema_chunks,
            ctx.mandatory_tables
        )

        logger.warning(
            "TABLES_AFTER_MANDATORY_INJECTION="
            + str(
                [
                    c.table_name
                    for c in schema_chunks
                ]
            )
        )
        
        
        logger.warning(
            f"GROUNDING_AUDIT={ctx.audit()}"
        )
        
        
        
       
        
        # ======================================================
        # STEP 4 - BUILD CONTEXT
        # ======================================================

        schema_context = self.schema_rag.build_schema_context(
            schema_chunks,
            question=original_question
        )
        
        context_blocks = []
        
        
        # ======================================================
        # STEP 5 - TERM MAPPING
        # ======================================================
        
        logger.warning(
            f"MANDATORY_TABLES_AT_STEP5="
            f"{sorted(ctx.mandatory_tables)}"
        )
        
        term_mapping_block = ""

        if _tg.get("mapped"):

            term_mapping_block = (
                "\n\n"
                "-- QUESTION TERM MAPPING (verified against the KB) --\n"
                "-- Authoritative grounding results.\n"
                "-- SQL generation must preserve grounded mappings.\n"
                "-- Grounded mappings take precedence over model assumptions.\n"
                "-- If a grounded mapping conflicts with an inferred mapping, "
                "use the grounded mapping.\n"
                + "\n".join(
                    f"--   '{term}' -> {' | '.join(refs)}"
                    for term, refs in _tg["mapped"].items()
                )
            )

            logger.info(
                f"TERM_GROUNDING_MAPPED={_tg['mapped']}"
            )

            logger.info(
                f"TERM GROUNDING mapped: "
                f"{_tg['mapped']}"
            )
            
        resolved_entities = []
        resolved_tables = set()
            
        if _tg.get("quoted_entities"):

            from agent.entity_resolution import (
                resolve_entity,
                ResolutionCandidate,
                add_lookup_candidate,
            )

            entity_resolutions = []
            
           

            for entity in _tg["quoted_entities"]:

                resolution = resolve_entity(
                    entity
                )

                entity_resolutions.append(
                    resolution
                )

            logger.info(
                f"ENTITY_RESOLUTIONS={entity_resolutions}"
            )
            
            for resolution in entity_resolutions:

                if not resolution.lookup_required:
                    continue

                lookup_sql = f"""
                    SELECT
                        obj_item_id,
                        name_txt
                    FROM obj_item
                    WHERE name_txt = '{resolution.entity}'
                    LIMIT 1
                """

                rows, err = self.executor.execute(
                    lookup_sql,
                    max_rows=1
                )

                #
                # Enrichir la résolution si on a trouvé un match
                #
                if rows:

                    row = rows[0]
                    
                    logger.warning(
                                    f"ENTITY_RESOLVED "
                                    f"ENTITY='{resolution.entity}' "
                                    f"TABLE=obj_item "
                                    f"COLUMN=obj_item_id "
                                    f"VALUE={row['obj_item_id']}"
                                )
                    
                    entity_context = {
                        "entity": resolution.entity,
                        "table": "obj_item",
                        "column": "obj_item_id",
                        "value": str(row["obj_item_id"]),
                        "display_name": row["name_txt"],
                    }
                    
                    add_lookup_candidate(
                        resolution=resolution,
                        table="obj_item",
                        column="obj_item_id",
                        value=str(row["obj_item_id"]),
                        )

                    

                logger.info(
                    f"ENTITY_LOOKUP_ROWS={rows}"
                )

                logger.info(
                    f"ENTITY_LOOKUP_ERROR={err}"
                )

                logger.info(
                    f"ENTITY_RESOLUTION_UPDATED={resolution}"
                )


            
            
            resolved_entities = [
                r
                for r in entity_resolutions
                if r.candidates
            ]
            
            logger.warning(
                f"RESOLVED_ENTITIES_COUNT={len(resolved_entities)}"
            )
            
            
            for r in resolved_entities:

                logger.warning(
                    f"ENTITY={r.entity}"
                )

                for c in r.candidates:

                    logger.warning(
                        f"MATCH="
                        f"{c.table}."
                        f"{c.column}="
                        f"{c.value}"
                    )
                        
            
            
            resolved_tables = extract_resolved_tables(
                resolved_entities
            )
            
            logger.warning(
                "EXTRACTED_RESOLVED_TABLES=%s",
                sorted(resolved_tables)
            )

            
            
            
            ctx.add_resolved_tables(
                resolved_tables
            )
            
            logger.warning(
                            "CTX_RESOLVED_TABLES=%s",
                            sorted(ctx.resolved_tables)
                        )

            ctx.refresh_mandatory_tables()

            logger.warning(
                f"CTX_AFTER_ENTITY_RESOLUTION="
                f"{ctx.dump()}"
            )
            
            
            
            entity_resolution_block = (
                            build_entity_resolution_block(
                                resolved_entities
                            )
                        )
            
            logger.warning(
                            "ENTITY_RESOLUTION_BLOCK=\n"
                            + entity_resolution_block
                        )
            
            context_blocks.append(
                            entity_resolution_block
                        )
                    
                    

        logger.info(
            f"ENTITY_RESOLVED_TABLES={sorted(resolved_tables)}"
        )
        
        
        mandatory_tables = ctx.mandatory_tables
        
        
        relationship_result = (
            self.relationship_validator.validate(
                mandatory_tables
            )
        )
        
        logger.warning(
            "RELATIONSHIP_RESULT=%s",
            relationship_result
        )
                
        
        logger.warning(
            "RELATIONSHIP_STATUS=%s",
            relationship_result.status
        )
        
        
        if (
            relationship_result.status
            == RelationshipStatus.IMPOSSIBLE
        ):

            logger.warning(
                "QUERY_REJECTED_BY_RELATIONSHIP_VALIDATOR"
            )

            return PipelineResult(
                success=False,
                answer=(
                    "The requested information cannot be "
                    "retrieved from the validated schema. "
                    "No verified relationship path exists."
                )
            )
        
        
        
        
        relationship_context = (
            self.relationship_validator
            .build_relationship_context(
                relationship_result
            )
        )

        logger.warning(
            "RELATIONSHIP_CONTEXT=\n%s",
            relationship_context
        )

        
        
        

        logger.warning(
            f"MANDATORY_TABLES_AFTER_ENTITY_RESOLUTION="
            f"{sorted(mandatory_tables)}"
        )
        
        
        relationship_result = (
            self.relationship_validator.validate(
                mandatory_tables
            )
        )
        
        
        validated_context = (
            build_validated_query_context(
                question,
                relationship_result,
                resolved_entities,
                mandatory_tables
            )
        )
        
        from query_analysis.path_builder import (
            build_required_join_path,            
        )

        validated_context.required_join_path = (
            build_required_join_path(
                validated_context.connected_graph,
                validated_context.mandatory_tables,
            )
        )
               

        
        logger.warning(
            "CONNECTED_GRAPH_NODES=%s",
            sorted(
                validated_context.connected_graph.nodes
            )
        )
        
        logger.warning(
            "CONNECTED_GRAPH_EDGES=%s",
            [
                (
                    e.from_table,
                    e.to_table,
                    e.join_condition
                )
                for e in validated_context.connected_graph.edges
            ]
        )
        
        logger.warning(
            "REQUIRED_JOIN_PATH=%s",
            validated_context.required_join_path
        )
        
        
        
        validated_context.recommended_join_chain = (
            RelationshipValidator.build_recommended_join_chain(
                validated_context
            )
        )
        
        logger.warning(
            "RECOMMENDED_JOIN_CHAIN=%s",
            validated_context.recommended_join_chain
        )

        
        
        if (
            validated_context.relationship_status
            ==
            RelationshipStatus.UNSATISFIABLE_CORRELATION
        ):

            logger.warning(
                "PIPELINE_SHORT_CIRCUIT_UNSATISFIABLE_CORRELATION"
            )

            return PipelineResult(
                success=False,
                answer=(
                    "This question cannot be answered from the "
                    "available schema because it requires correlating "
                    "disconnected table groups."
                ),
                error="UNSATISFIABLE_CORRELATION",
                attempts=0,
                explanation={
                    "relationship_status":
                        "UNSATISFIABLE_CORRELATION",
                    "predicate_groups":
                        validated_context.predicate_groups,
                },
                debug=debug_rval,
            )
        
        
        
        logger.warning(
            "VALIDATED_CONTEXT=%s",
            validated_context
        )
        
        

        logger.warning(
            "RELATIONSHIP_STATUS=%s",
            relationship_result.status
        )
        
        
        if (
            relationship_result.status
            == RelationshipStatus.IMPOSSIBLE
        ):

            logger.warning(
                "QUERY_REJECTED_BY_RELATIONSHIP_VALIDATOR"
            )

            raise ValueError(
                "IMPOSSIBLE: no validated relationship path"
            )
        
       
            
        # ======================================================
        # ENTITY RESOLUTION BOOST
        # ======================================================
        
        for c in schema_chunks:

            logger.warning(
                "GROUNDING_CANDIDATE table=%s score=%s",
                c.table_name,
                c.score,
            )
            
            if c.table_name == "entitytypes_filter":

                logger.warning(
                    "ENTITYTYPES_FILTER_CHOSEN score=%s",
                    c.score,
                )

                logger.warning(
                    "ENTITYTYPES_FILTER_DESCRIPTION=%s",
                    getattr(c, "description", None)
                )
            
            
        
        logger.warning(
            "POST_MANDATORY_BOOST="
            + str([
                f"{c.table_name}:{c.score:.4f}"
                for c in schema_chunks
            ])
        )
        
        logger.error(
            "BBBBB_ENTITY_RESOLUTION_DEBUG"
        )
                
        logger.warning(
            f"RESOLVED_ENTITIES="
            f"{resolved_entities}"
        )

        logger.warning(
            f"RESOLVED_ENTITIES_COUNT="
            f"{len(resolved_entities) if resolved_entities else 0}"
        )

        
        
        logger.warning(
            f"QUOTED_ENTITIES={_tg.get('quoted_entities')}"
        )
        
        
        logger.warning(
            f"RESOLVED_ENTITIES_COUNT="
            f"{len(resolved_entities) if resolved_entities else 0}"
        )

                
        if resolved_entities:

            for resolution in resolved_entities:

                if resolution.entity in _tg["mapped"]:
                    del _tg["mapped"][
                        resolution.entity
                    ]

            entity_resolution_block = (
                build_entity_resolution_block(
                    resolved_entities
                )
            )

            logger.warning(
                "ENTITY_RESOLUTION_BLOCK=\n"
                + entity_resolution_block
            )

            context_blocks.append(
                entity_resolution_block
            )
                      
                                        
            logger.info(
                f"ENTITY_REFERENCES={_tg['quoted_entities']}"
            )
            
            logger.warning(
                f"MANDATORY_TABLES_AFTER_STEP5="
                f"{sorted(mandatory_tables)}"
            )
            
            schema_context += (
                "\n\n"
                "-- MANDATORY TABLES --\n"
                "-- These tables were identified by verified grounding.\n"
                "-- SQL generation should strongly prefer these tables.\n"
                "-- If a mandatory table is relevant to the question, "
                "it should not be ignored.\n"
                "-- Grounded tables take precedence over semantically similar tables.\n"
                + "\n".join(
                    f"--   {t}"
                    for t in sorted(mandatory_tables)
                )
            )
                                
            
            # ======================================================
            # STEP 6 - NEO4J JOIN ENRICHMENT
            # ======================================================
            
            logger.warning(
                f"FINAL_MANDATORY_TABLES="
                f"{sorted(ctx.mandatory_tables)}"
            )
            
            
            logger.warning(
                f"GROUNDING_TABLES={sorted(grounded_tables)}"
            )

            logger.warning(
                f"RESOLVED_TABLES={sorted(resolved_tables)}"
            )

            logger.warning(
                f"FINAL_MANDATORY_TABLES={sorted(ctx.mandatory_tables)}"
            )
            

            graph_context = build_graph_context(
                schema_chunks,
                ctx.mandatory_tables
            )

            if graph_context:

                context_blocks.append(
                    graph_context
                )
                
            logger.warning(
                f"GRAPH_CONTEXT_ADDED="
                f"{bool(graph_context)}"
            )

        # ── Catalog short-circuit (BEFORE intent classification) ──────────────
        # A strong match to a curated sample question is a STRONGER signal than
        # the intent classifier: answer with the vetted gold SQL and skip
        # intent routing entirely. Previously placed AFTER intent, so a data
        # question that the classifier/ambiguity-detector misrouted to
        # schema_exploration/unclear returned before the catalog was ever
        # consulted -- verified: "Show the Absolute Point records classified
        # as either cartesian point or geographic point" (an exact catalog
        # question) was answered as "unclear" instead of by its gold SQL.
        # Matched on original_question (naturalised wording, pre entity-rewrite).
        catalog_sql = None
        try:
            # v3.2: threshold configurable via env. Default 0.98 = the
            # short-circuit only fires on (near-)verbatim catalog questions
            # (Quick Examples, exact re-asks); any paraphrase goes through
            # normal LLM generation. Lower it (e.g. 0.85) to trade a little
            # correctness risk for more fast-path hits -- the
            # CATALOG SHORT-CIRCUIT / MATCH REJECTED log lines give the
            # observed overlap distribution to tune against.
            _catalog_min_overlap = float(os.getenv("REQA_CATALOG_MIN_OVERLAP", "0.98"))
            _match = self.schema_rag.best_sample_query(
                original_question, min_overlap=_catalog_min_overlap)
            if _match and not _numbers_match(original_question, _match.get("question", "")):
                logger.warning(
                    f"CATALOG MATCH REJECTED (numeric literals differ): "
                    f"user question vs catalog {_match.get('question')!r} -- "
                    f"the gold SQL would run with the wrong threshold; "
                    f"generating normally instead"
                )
                _match = None
            catalog_match_table = None
            catalog_short_circuit = False
            catalog_question = ""

            if _match:
                # v3.0 gate. The enriched KB carries, per table, questions
                # phrased exactly like a user's ("Show the customer email
                # address recorded on each Absolute Point") whose SQL is
                # invalid on purpose, plus "Delete all X records added last
                # month" whose SQL is a real DELETE. A 0.8 lexical overlap
                # is easy to hit on those. Executing the match verbatim
                # without this check would surface an SQL error to the user
                # at best, and hit the database with a write at worst.
                _cls = query_class(_match)
                _cand = _match.get("sql")
                if _cls == POSITIVE and is_readonly_select(_cand):
                    catalog_sql = _cand
                    catalog_match_table = None
                    catalog_short_circuit = False
                    catalog_question = ""

                    logger.info(
                        f"CATALOG SHORT-CIRCUIT: table={_match['table']} "
                        f"overlap={_match['overlap']:.2f} sql={_cand}"
                    )

            # ── Parametric (template) catalog (v3.8) ──────────────────────
            # Exact catalog missed: try a STRUCTURAL match -- same question
            # template, different entities (ids, names, quoted strings,
            # numbers). The gold SQL is reused with the user's parameter
            # values substituted deterministically, still without any LLM
            # call -- an LLM-free path is hallucination-free by definition.
            # Same POSITIVE + SELECT-only gate as the exact catalog; the
            # produced SQL still flows through every downstream guard and
            # EXPLAIN. Disable with REQA_TEMPLATE_CATALOG=0.
            if catalog_sql is None and os.getenv(
                    "REQA_TEMPLATE_CATALOG", "1") == "1":
                try:
                    from agent.template_catalog import parametric_match
                    from RAG.knowledge_base import (
                        get_table_kb, retrieval_safe_sample_queries)
                    _cands = []
                    for _tc in schema_chunks[:8]:
                        _tn = getattr(_tc, "table_name", "")
                        if not _tn:
                            continue
                        for _sq in retrieval_safe_sample_queries(
                                get_table_kb(_tn)) or []:
                            if (query_class(_sq) == POSITIVE
                                    and is_readonly_select(_sq.get("sql"))):
                                _cands.append({**_sq, "table": _tn})
                    _pm = parametric_match(original_question, _cands)
                    if _pm:
                        catalog_sql = _pm["sql"]
                        logger.info(
                            f"PARAMETRIC CATALOG: template="
                            f"{_pm['matched_question']!r} overlap="
                            f"{_pm['overlap']:.2f} substitutions="
                            f"{_pm['substitutions']} sql={catalog_sql}")
                except Exception as _pme:
                    logger.warning(f"Parametric catalog unavailable: {_pme}")
                else:
                    logger.warning(
                        f"CATALOG MATCH REJECTED (class={_cls}, readonly="
                        f"{is_readonly_select(_cand)}): table={_match.get('table')} "
                        f"overlap={_match.get('overlap', 0):.2f} -- "
                        f"generating normally instead"
                    )
        except Exception as e:
            logger.warning(f"catalog short-circuit unavailable, generating normally: {e}")

        # ── Negative pre-flight (v3.1) ───────────────────────────────────────
        # Mirror image of the catalog short-circuit above. The enriched KB
        # records, per table, the questions this schema CANNOT answer and
        # why ("no audit or user-attribution columns", "no financial
        # attribute on this table"). When the user's question is one of
        # them, three LLM calls and two DB round-trips are guaranteed to
        # end in "Could not generate a valid query" WITHOUT ever telling
        # the user why. Answering the diagnosis directly is both faster and
        # more useful. Threshold is deliberately strict and restricted to
        # the UNANSWERABLE class (see best_negative_match docstring): a
        # false refusal costs far more than a wasted retry.
        # Behaviour-changing, therefore OPT-IN: this is the only place where
        # the agent can now answer WITHOUT generating any SQL. Enable with
        # REQA_NEGATIVE_PREFLIGHT=1 once you have watched the logs and are
        # satisfied with the false-refusal rate (the log line below fires
        # whether or not the flag is on, so you can measure it first).
        if not catalog_sql:
            try:
                # Top-8 (was top-5): after KB re-ingestion the ranking moved
                # ("events" now pulls act_event ahead), and the tables carrying
                # the negative entries can sit at rank 6-7. The check is a few
                # dict lookups per table -- widening it costs nothing.
                _neg = best_negative_match(
                    original_question,
                    [t.table_name for t in schema_chunks[:8] if getattr(t, "table_name", "")],
                )
            except Exception as e:
                _neg = None
                logger.warning(f"negative pre-flight unavailable: {e}")
            if _neg and os.getenv("REQA_NEGATIVE_PREFLIGHT", "0") != "1":
                logger.info(
                    f"NEGATIVE PRE-FLIGHT (dry-run, flag off): would decline -- "
                    f"table={_neg['table']} kind={_neg['kind']} "
                    f"overlap={_neg['overlap']:.2f}"
                )
                _neg = None
            if _neg:
                logger.info(
                    f"NEGATIVE PRE-FLIGHT: table={_neg['table']} kind={_neg['kind']} "
                    f"overlap={_neg['overlap']:.2f} -- declining without generation"
                )
                # BUGFIX: `explanation` was referenced here before being
                # defined (the XAI skeleton is only built further down in
                # run()), so this branch raised NameError whenever
                # REQA_NEGATIVE_PREFLIGHT=1 and a negative match fired.
                # Build a local explanation dict for this early-return path.
                
                logger.warning("BEFORE_XAI_SKELETON")
                
                explanation = {
                    "intent": "not_answerable",
                    "not_answerable": {
                        "matched_question": _neg["question"],
                        "reason": _neg["why"],
                        "table": _neg["table"],
                    },
                }
                
                logger.warning("AFTER_XAI_SKELETON")
                
                try:
                    explanation["question_suggestions"] = _combine_suggestions(
                        self.schema_rag.suggest_questions(
                            [t.table_name for t in schema_chunks[:3]],
                            per_table=2, exclude=question),
                        [],
                    )
                except Exception:
                    pass
                _why = _neg["why"] or "the schema does not hold this information"
                return PipelineResult(
                    success=False,
                    answer=("This cannot be answered from the available data: "
                            f"{_why}"),
                    error="not_answerable_from_schema",
                    attempts=0,
                    explanation=explanation,
                    debug=debug_rval,
                )

        # ── Intent classification ────────────────────────────────────────────
        # Distinguishes "I want actual data" from "I want to know what data/
        # tables exist" so that schema-exploration questions never reach the
        # SQL generator (and therefore can never hallucinate columns/joins).
        # Skipped entirely when a catalog gold SQL is already in hand.
        if catalog_sql:
            intent = "data_query"
        else:
            _report({"stage": "intent_classification"})
            try:
                intent = self.sql_generator.classify_intent(question)
            except Exception as e:
                logger.warning(f"Intent classification failed, defaulting to data_query: {e}")
                intent = "data_query"

        logger.info(f"INTENT={intent}")
        
        logger.warning("AFTER_INTENT_CLASSIFICATION")
        
        logger.error("AAAA_DEBUG_PIPELINE_12345")


        if not catalog_sql and intent == "schema_exploration":
            result = self.sql_generator.answer_schema_exploration(question, self.schema_rag)
            answer = result["summary"]
            if result.get("table_markdown"):
                answer += f"\n\n{result['table_markdown']}"

            # No SQL is generated for this intent, so gen_conf (which
            # measures "did the LLM write correct SQL immediately") isn't
            # applicable -- treated as 1.0 (no generation risk incurred).
            # rag_conf still reflects retrieval quality, same formula as
            # _compute_confidence(), so "confidence" has a consistent shape
            # across every branch of the pipeline rather than being absent
            # here (which could KeyError any caller assuming it always exists).
            rag_scores = [t.cosine_score for t in schema_chunks if t.score > 0]
            rag_conf = round(sum(rag_scores) / len(rag_scores), 4) if rag_scores else 0.5

            return PipelineResult(
                success=True,
                answer=answer,
                sql=result.get("illustrative_sql", ""),
                rows=[],
                row_count=0,
                attempts=1,
                explanation={
                    "intent": intent,
                    "retrieved_tables": [
                        {"name": t.table_name, "score": round(t.score, 4)}
                        for t in schema_chunks
                    ],
                    "confidence": {
                        "score": round(0.4 * rag_conf + 0.6 * 1.0, 4),
                        "rag_conf": rag_conf,
                        "gen_conf": 1.0,
                    },
                },
                debug=debug_rval
            )

        # v2.4: deterministic override -- when the question literally names a
        # real retrieved table ("...from mat_stat..."), the user's intent is
        # not ambiguous by definition. Neither the LLM intent classifier
        # (non-deterministic: same question observed flip-flopping between
        # data_query and unclear across runs) nor the ambiguity detector
        # (spread of near-identical _stat cosines dances around the 0.06
        # threshold) may veto an explicitly named table.
        _q_lower = (original_question or "").lower()
        _names_table = any(
            t.table_name and t.table_name.lower() in _q_lower
            for t in (schema_chunks or [])
        )
        if _names_table and intent == "unclear":
            logger.info("INTENT OVERRIDE: question names a retrieved table -> data_query")
            intent = "data_query"
        
        logger.warning(
            f"DEBUG_BRANCH "
            f"force={force} "
            f"_names_table={_names_table} "
            f"catalog_sql={catalog_sql is not None}"
        )

        logger.warning(
            f"DEBUG_AMBIGUOUS={_is_ambiguous_retrieval(schema_chunks)}"
        )   
        
        ambiguous = _is_ambiguous_retrieval(schema_chunks)

        logger.warning(
            f"DEBUG_BRANCH "
            f"force={force} "
            f"_names_table={_names_table} "
            f"catalog_sql={catalog_sql is not None} "
            f"intent={intent} "
            f"ambiguous={ambiguous}"
        )

        if not force and not _names_table and not catalog_sql and (
            intent == "unclear"
        ):
            logger.error("ENTERED_UNCLEAR_BRANCH")

            # code existant 
            

        if not force and not _names_table and not catalog_sql and (intent == "unclear" or _is_ambiguous_retrieval(schema_chunks)):
            # v2.3: silent auto-answer on the UNCLEAR path too -- in practice
            # the most frequent failure exit, yet the only one that never
            # tried reformulating. Same guarantees as elsewhere: confidence
            # gate, no recursion, falls through to the normal unclear result
            # when nothing qualifies.
            if self.allow_reformulation and allow_reformulation and not _out_of_time():   # do not try to auto answer if self.allow_reformulation is false
                auto = self._try_auto_answer(original_question, schema_chunks)
                if auto is not None:
                    return auto
            # Suggest REAL, guaranteed-answerable questions from the top RAG
            # candidates' curated sample_queries -- far more actionable than
            # just listing table names.
            top_tables = [t.table_name for t in schema_chunks[:3]]
            try:
                suggested = self.schema_rag.suggest_questions(top_tables, per_table=2, exclude=question)
            except Exception:
                logger.warning("suggest_questions unavailable; continuing without catalog suggestions")
                suggested = []
            reformulations = _llm_reformulations(
                question, schema_chunks, getattr(self.sql_generator, "llm", None))
            hint = (
                f" Did you mean something related to: {', '.join(top_tables)}?"
                if top_tables else ""
            )
            return PipelineResult(
                success=False,
                answer=(
                    "I'm not sure what data you're looking for."
                    + hint
                    + " Try rephrasing, e.g. 'show me data from <table>' "
                    "or 'how many rows are in <table>'."
                ),
                attempts=1,
                explanation={"intent": intent,
                             "question_suggestions": _combine_suggestions(suggested, reformulations)},
                debug=debug_rval
            )

        # intent == "data_query" (or catalog short-circuit) → continue below.
        # The catalog gold SQL (catalog_sql), if any, is applied on attempt 1
        # of the generation loop and still validated via static_check /
        # EXPLAIN / execution, so a (very unlikely) bad gold SQL falls back to
        # normal generation on retry.
        
        logger.warning("CHECKPOINT_A")

        # premier bloc après l'intent
        
        logger.warning("CHECKPOINT_B")
    
        # deuxième bloc après l'intent
        
        logger.warning("CHECKPOINT_C")
        
        

        # ── XAI skeleton ─────────────────────────────────────────────────────
        
        logger.warning("BUILDING_XAI_SKELETON")
        
        explanation = {
            "intent": intent,
            "retrieved_tables": (
                [
                    {
                        "name": catalog_match_table,
                        "score": 1.0,
                        "cosine_score": 1.0,
                        "domain": "Catalog Match",
                        "source": "catalog_short_circuit",
                    }
                ]
                if catalog_short_circuit
                else
                [
                    {
                        "name":         t.table_name,
                        "score":        round(t.score, 4),
                        "cosine_score": round(t.cosine_score, 4),
                        "domain":       _domain_str(t.payload.get("domain", "")),
                        "source": "rag" if t.score > 0 else "fk_expansion",
                    }
                    for t in schema_chunks
                ]
            ),
            "total_tables_in_db": len(all_tables),
            "schema_preview":     schema_context[:900],
            "attempts":           [],
            "confidence":         {"score": 0.0, "rag_conf": 0.0, "gen_conf": 0.0},
        }
        
        logger.warning("XAI_SKELETON_BUILT")

        error_feedback = ""
        previous_sql = ""
        # One guarded retry for empty results per run (v3.7): see the
        # empty-result transparency block after execution.
        _empty_retry_done = False

        # Lowercased set of every real table name, used by static_check to
        # reject hallucinated table names (table1, main_table, ...) BEFORE
        # the EXPLAIN round-trip, with actionable feedback. Computed once
        # per run -- all_tables is already in hand at this point.
        known_tables = {t.lower() for t in all_tables} if all_tables else None

        # Same idea one level deeper: {table -> real column names}, used by
        # static_check to reject hallucinated COLUMN names (the dominant
        # failure once tables are validated) with a message listing the
        # REAL columns of the exact table. Fail-safe: validation is an
        # optimization, never a reason to break the run.
        try:
            known_columns = self.schema_rag.all_table_columns() or None
        except Exception:
            logger.warning("Could not build known_columns map; column validation disabled for this run")
            known_columns = None
            
        logger.warning("ENTERING_GENERATION_LOOP")
        
        
        
        
        logger.warning("BEFORE_GENERATION_LOOP")
    
        
        for attempt in range(1, self.max_retries + 1):
            
            try:
            
                logger.warning(
                f"ABOUT_TO_GENERATE_SQL attempt={attempt}"
                )
                
                logger.warning(f"ATTEMPT={attempt}")
                if attempt > 1 and _out_of_time():
                    logger.warning(
                        f"TIME BUDGET exceeded ({_time_budget:.0f}s) -- "
                        f"stopping retries before attempt {attempt}")
                    break
                attempt_info = {
                    "n":         attempt,
                    "sql":       "",
                    "failed_at": None,   # None = success
                    "error":     "",
                }
                
                logger.warning(
                    f"ATTEMPT={attempt} "
                    f"catalog_sql={catalog_sql is not None} "
                    f"intent={intent}"
                )
                
                logger.warning(
                    f"MANDATORY_TABLES_FOR_GENERATION="
                    f"{sorted(ctx.mandatory_tables)}"
                )
                
            
                
                logger.warning(
                    f"MANDATORY_TABLES_IN_CONTEXT="
                    f"{[t for t in ctx.mandatory_tables if t in schema_context]}"
                )
                
                
                
                
                

                # ── SQL Generation ────────────────────────────────────────────────
                _report({"stage": "sql_generation", "attempt": attempt, "of": self.max_retries})
                try:
                    if attempt == 1 and catalog_sql:
                        # Use the curated gold SQL verbatim on the first attempt.
                        sql = catalog_sql
                        logger.info("RUN[1] using catalog gold SQL (short-circuit)")
                    else:
                        
                        
                        #<temporaire
                        
                        #if (
                        #    question.lower().startswith(
                        #        "which simulated entities are involved in each act"
                        #    )
                        #):
                        mandatory_tables = [
                            t
                            for t in mandatory_tables
                            if t != "entitytypes_filter"
                        ]

                        logger.warning(
                            "TEST_REMOVED_ENTITYTYPES_FILTER=%s",
                            mandatory_tables,
                        )
                        
                        
                        #>temporaire
                        
                        
                        
                        
                        sql = self.sql_generator.generate(
                            question,
                            schema_context,
                            all_tables,
                            error_feedback,
                            previous_sql=previous_sql,
                            mandatory_tables=ctx.mandatory_tables,
                            validated_context=validated_context,
                        )
                        
                        
                        
                except SQLValidationError as e:
                    
                    logger.exception("SQL_VALIDATION_TRACEBACK")

                    error_feedback = f"Validation error: {e}"
                    attempt_info.update(failed_at="static_check", error=str(e))
                    explanation["attempts"].append(attempt_info)

                    logger.info(
                        f"RUN[{attempt}] SQL validation failed: {e}"
                    )

                    continue


                except GroundingViolation as e:
                   

                    attempt_info.update(
                        failed_at="grounding",
                        error=str(e),
                    )

                    explanation["attempts"].append(
                        attempt_info
                    )

                    logger.warning(
                        f"RUN[{attempt}] GROUNDING VIOLATION: {e}"
                    )

                    error_feedback = (
                        f"GROUNDING VIOLATION:\n{e}\n\n"
                        "Use ONLY the validated FK paths.\n"
                        "Do NOT invent joins.\n"
                        "Do NOT invent shortcut relationships.\n"
                        "All joins MUST appear in VALIDATED FK PATHS."
                    )

                    continue
                
            
                    

                    
                except Exception as e:
                    # The LLM responded, but wrote something unsafe/malformed
                    # (forbidden keyword, not a SELECT, ...). This is a content
                    # problem the LLM can self-correct on retry given the error
                    # message — exactly like a static_check failure — NOT an
                    # infrastructure problem. It must NOT count toward the
                    # circuit breaker (which exists to detect the LLM API/DB
                    # being down, not the LLM occasionally proposing invalid
                    # SQL), and the error message IS useful feedback for the
                    # next attempt, unlike a genuine API exception.
                    error_feedback = f"Validation error: {e}"
                    attempt_info.update(failed_at="static_check", error=str(e))
                    explanation["attempts"].append(attempt_info)
                    logger.info(f"RUN[{attempt}] SQL validation failed: {e}")
                    continue
                except GroundingViolation as e:

                    logger.warning(
                        f"RUN[{attempt}] GROUNDING VIOLATION: {e}"
                    )

                    error_feedback = (
                        "The previous SQL violated validated FK paths.\n\n"
                        f"{e}\n\n"
                        "Use ONLY the validated FK paths."
                    )

                    continue
                
                except Exception as e:
                    # This is a genuine infrastructure/API-level failure (LLM
                    # timeout, rate limit, connection error, ...), not a
                    # problem with the SQL content itself. Two things follow:
                    #
                    # 1. The circuit breaker must learn about it. It previously
                    #    only recorded failures from EXPLAIN/execution, so a
                    #    fully-down LLM would silently retry 3x on EVERY single
                    #    user request forever, never tripping the breaker —
                    #    exactly the failure mode it exists to catch.
                    #
                    # 2. error_feedback must NOT be set to this exception text.
                    #    SQLGenerator.generate() treats a non-empty error_feedback
                    #    as "the previous SQL was wrong, here's why" — it skips
                    #    question normalization/planning and asks the LLM to
                    #    "verify table names, column names, joins..." against a
                    #    message like "DATABASE ERROR: LLM error: <exception>",
                    #    which is nonsensical guidance for an infra failure and
                    #    silently degrades the next attempt's quality. A clean
                    #    retry (empty error_feedback) is the correct behavior.
                    error_feedback = ""
                    attempt_info.update(failed_at="llm", error=str(e))
                    explanation["attempts"].append(attempt_info)
                    etrace = traceback.format_exc()
                    logger.warning(f"RUN[{attempt}] LLM generation failed: {e}\n{etrace}")
                    
                    

                    self.cb.record_failure()
                    if self.cb.is_open():
                        logger.error("CIRCUIT BREAKER: LLM generation repeatedly failing")
                        #traceback.format_exc()

                        return PipelineResult(
                            success=False,
                            answer="The SQL generation service is currently unavailable — too many consecutive failures.",
                            error=str(e),
                            attempts=attempt,
                            explanation=explanation,
                            debug=debug_rval
                        )
                    continue
            
            
            # schemalimitation exception
                
            except SchemaLimitation as e:
                                
                logger.warning(
                    "SCHEMA_LIMITATION=%s",
                    e,
                    )
                
                explanation = {
                    "overall_score": 100,
                    "schema_limitation": str(e),
                    "confidence": {
                        "score": 1.0,
                        "score_strict": 1.0,
                        "rag_conf": 1.0,
                        "gen_conf": 1.0,
                        "sem_conf": 1.0,
                        "ground_conf": 1.0,
                    },
                }
                
                return PipelineResult(
                    success=True,   
                    answer=(
                        "The requested information cannot be fully "
                        "retrieved because part of the requested data "
                        "is not available in the current database schema."
                    ),
                
                    answerability_status=AnswerabilityStatus.PARTIAL_SCHEMA_LIMITATION,
                
                    attempts=attempt,
                
                    explanation=explanation,
                    debug=debug_rval,
                )
                

            attempt_info["sql"] = sql
            previous_sql = sql

            logger.info(
                f"RUN[{attempt}] QUESTION-{question} SQL={sql}"
            )
            
            logger.warning(
                "REQUIRED_JOIN_PATH=%s",
                validated_context.required_join_path
            )

            logger.warning(
                "MANDATORY_TABLES=%s",
                validated_context.mandatory_tables
            )

            # =====================================================
            # MANDATORY TABLE COVERAGE VALIDATION
            # =====================================================

            used_tables = extract_tables_from_sql(sql)
            
            logger.warning(
                "QUESTION=%s",
                question
            )

            logger.warning(
                "ENTITY_FILTERS=%s",
                validated_context.entity_filters
            )

            logger.warning(
                "MANDATORY_TABLES=%s",
                validated_context.mandatory_tables
            )

            logger.warning(
                "REQUIRED_JOIN_PATH=%s",
                validated_context.required_join_path
            )
            
            logger.warning(
                "QUESTION=%s",
                question,
            )

            #logger.warning(
             #   "SELECT_CLAUSE=%s",
             #   extract_select_clause(sql),
            #)

            missing_tables = (
                set(validated_context.mandatory_tables)
                - set(used_tables)
            )

            logger.warning(
                "USED_TABLES=%s",
                sorted(used_tables),
            )

            logger.warning(
                "MANDATORY_TABLES=%s",
                sorted(validated_context.mandatory_tables),
            )

            logger.warning(
                "MISSING_MANDATORY_TABLES=%s",
                sorted(missing_tables),
            )

            if missing_tables:
                """  
                raise GroundingViolation(
                    f"Mandatory tables missing: "
                    f"{sorted(missing_tables)}"
                )
                """
                logger.warning(
                    "MISSING_MANDATORY_TABLES=%s",
                    sorted(missing_tables)
                )
                
                logger.warning(
                    "REQUIRED_JOIN_PATH=%s",
                    validated_context.required_join_path
                )

            # continue vers static check
            
            

            # ── Prose-refusal normalizer (v3.10) ──────────────────────────────
            # Arctic eval (2026-08-06): instead of the taught "IMPOSSIBLE:"
            # prefix, the model sometimes refuses or hedges in FREE PROSE
            # ("...but it does not provide any additional filtering
            # criteria...", "cannot be answered with the given schema") --
            # or returns prose with no SQL statement at all. That text then
            # reaches the SQL tokenizer and dies as a nonsensical parse
            # error ("Expecting (. Line 1, Col 12"), or as an instant
            # give-up when the whole output is prose (the ~8s flash
            # failures). Normalize such outputs INTO the IMPOSSIBLE path
            # right below, which already knows how to auto-reformulate,
            # suggest alternatives, and decline honestly.
            if not sql.upper().lstrip().startswith("IMPOSSIBLE:"):
                _stripped = sql.strip()
                # A real statement starts with SELECT, or with a genuine
                # CTE header "WITH <name> AS (" -- NOT with the English
                # preposition "with ..." that prose fragments often open
                # with ("with ID 1488, but it does not provide...").
                _starts_sql = re.match(
                    r"(?i)\s*(SELECT\b|WITH\s+\w+\s+AS\s*\()", _stripped)
                _has_stmt = re.search(
                    r"(?i)(\bSELECT\b|\bWITH\s+\w+\s+AS\s*\()", _stripped)
                _refusal = re.search(
                    r"(?i)cannot be answered|can'?t be answered|"
                    r"not possible to (?:answer|determine)|"
                    r"does not provide|do(?:es)? not contain|"
                    r"insufficient (?:information|criteria|data)|"
                    r"unable to (?:answer|generate|determine)|"
                    r"no way to (?:determine|answer)|"
                    r"no (?:table|column) (?:exists|is available)",
                    _stripped)
                if (not _has_stmt) or (_refusal and not _starts_sql):
                    _reason = " ".join(_stripped.split())[:300]
                    sql = "IMPOSSIBLE: " + (
                        _reason or "the model returned no SQL statement")
                    logger.info("\tPROSE REFUSAL: normalized to IMPOSSIBLE "
                                f"({_reason[:80]!r})")

            if sql.upper().startswith("IMPOSSIBLE:"):
                reason = sql[11:].strip()
                attempt_info.update(failed_at="impossible", error=reason)
                explanation["attempts"].append(attempt_info)
                logger.info(f"\tIMPOSSIBLE Reason={reason}")
                # Silent background auto-answer before giving up: the question
                # may be answerable once reformulated into the schema's own
                # vocabulary. Only returns if a reformulation clears the
                # confidence gate; otherwise we fall through to suggestions.
                if self.allow_reformulation and allow_reformulation and not _out_of_time():
                    auto = self._try_auto_answer(
                        original_question, schema_chunks, error_feedback=reason)
                    if auto is not None:
                        return auto
                try:
                    _cat = self.schema_rag.suggest_questions(
                        [t.table_name for t in schema_chunks[:3]], per_table=2, exclude=question,
                    )
                    _ref = _llm_reformulations(
                        question, schema_chunks, getattr(self.sql_generator, "llm", None))
                    explanation["question_suggestions"] = _combine_suggestions(_cat, _ref)
                except Exception:
                    pass
                return PipelineResult(
                    success=False,
                    answer=f"This question cannot be answered with the available schema: {reason}",
                    error=sql,
                    attempts=attempt,
                    explanation=explanation,
                    debug=debug_rval
                )

            # ── Static Check ──────────────────────────────────────────────────
            _report({"stage": "static_check", "attempt": attempt, "of": self.max_retries})
            valid, static_err = self.static_checker.check(
                sql, known_tables=known_tables, known_columns=known_columns,
            )
            # Column auto-fix: when every unknown column had ONE unambiguous
            # near-match (effective_time → effctv_time), the checker rewrote
            # the SQL instead of failing -- adopt it, and keep the
            # substitutions visible in the attempt record (XAI/logs).
            _fixed = getattr(self.static_checker, "fixed_sql", None)
            if valid and _fixed and _fixed != sql:
                notes = list(getattr(self.static_checker, "autofix_notes", []) or [])
                logger.info(f"\tColumn auto-fix applied: {'; '.join(notes)}")
                attempt_info["column_autofix"] = notes
                sql = _fixed
                attempt_info["sql"] = sql
            if not valid:
                error_feedback = f"Syntax/policy error: {static_err}"
                attempt_info.update(failed_at="static_check", error=static_err)
                explanation["attempts"].append(attempt_info)
                logger.info(f"\tSTATIC CHECK: not valid={error_feedback}")
                continue

            # ── Guess guard (v3.7) ────────────────────────────────────────────
            # Evaluation (2026-07-28) showed the most reliable hallucination
            # tell is the model DOCUMENTING its own guess in a comment:
            # "-- Assuming '1' is the ID for '1 IG BG HQ'", "-- Assuming
            # NRD12H represents LoD Red", or leaving a placeholder
            # ("-- Add condition ... here") that then fails to parse. Such
            # SQL is never trustworthy: reject it with feedback demanding
            # verified identifiers or an IMPOSSIBLE answer.
            _guess_marks = [
                m.group(0).strip()[:90]
                for m in re.finditer(r"--[^\n]*", sql)
                if re.search(r"assum|guess|placeholder|add condition|"
                             r"replace (?:this|with)", m.group(0), re.I)
            ]
            if _guess_marks:
                _msg = " ; ".join(_guess_marks[:3])
                error_feedback = (
                    "Your SQL contains guessed values or placeholders: "
                    f"{_msg}. Do NOT guess identifiers, codes or "
                    "conditions. Use ONLY identifiers explicitly given in "
                    "the question or values from the Allowed lists; if the "
                    "needed condition cannot be established from the "
                    "schema, answer IMPOSSIBLE instead of guessing.")
                attempt_info.update(failed_at="static_check", error=_msg)
                explanation["attempts"].append(attempt_info)
                logger.info(f"\tGUESS GUARD: {_msg}")
                continue

            # ── Enum-literal guard (v3.5) ─────────────────────────────────────
            # A filter on an ENUM column with a value that does not exist
            # ("cat_code = 'MAT'") raises NO error in MariaDB -- it just
            # matches nothing, and an empty result is served as a confident
            # SUCCESS (observed in production). Validate every string
            # literal compared to a known enum column against the KB's
            # allowed_values, and feed the REAL values back on violation --
            # same philosophy as the column check above. Fail-safe: guard
            # unavailable => behave exactly as before.
            try:
                from agent.enum_guard import check_enum_literals
                _enum_errs = check_enum_literals(sql)
            except Exception as _ee:
                _enum_errs = []
                logger.warning(f"enum guard unavailable: {_ee}")
            if _enum_errs:
                _msg = " ; ".join(_enum_errs)
                error_feedback = f"Invalid enum value(s): {_msg}"
                attempt_info.update(failed_at="static_check", error=_msg)
                explanation["attempts"].append(attempt_info)
                logger.info(f"\tENUM GUARD: {_msg}")
                continue

            # ── Contradiction guard (v3.6) ────────────────────────────────────
            # Equality filters that are mutually exclusive through the
            # query's own join conditions (u.unit_id = 1 AND o.org_id =
            # 1457 with JOIN ON u.unit_id = o.org_id) raise NO error in
            # MariaDB -- the query executes and a guaranteed-empty result
            # is served as a confident SUCCESS (observed in production:
            # unit designation "1 IG BG HQ" misparsed as unit_id = 1).
            # Detect the conflict deterministically via equality-class
            # propagation and feed an actionable message back to the LLM.
            # Fail-safe: guard unavailable => behave exactly as before.
            try:
                from agent.contradiction_guard import check_contradictions
                _contra_errs = check_contradictions(sql)
            except Exception as _ce:
                _contra_errs = []
                logger.warning(f"contradiction guard unavailable: {_ce}")
            if _contra_errs:
                _msg = " ; ".join(_contra_errs)
                error_feedback = f"Contradictory filters: {_msg}"
                attempt_info.update(failed_at="static_check", error=_msg)
                explanation["attempts"].append(attempt_info)
                logger.info(f"\tCONTRADICTION GUARD: {_msg}")
                continue

            # ── Constraint-coverage guard (v3.9) ──────────────────────────────
            # Observed in production (2026-08-05): asked "records where the
            # number of records is above 15" (an aggregate-in-WHERE trap),
            # the model silently DROPPED the impossible condition and served
            # "SELECT * FROM act_event" as a confident success -- the
            # INVERSE of hallucination: nothing invented, but the answer is
            # to a different, easier question than the one asked. The same
            # failure produced Arctic's q24 "WHERE 1=1" at the benchmark.
            # Deterministic check: every number the user wrote in the
            # question must reappear in the SQL (filter, HAVING or LIMIT);
            # a missing number means a constraint was dropped. On violation
            # the attempt is rejected with feedback that names the dropped
            # constraint and explicitly allows an IMPOSSIBLE answer.
            # Opt-out: REQA_COVERAGE_GUARD=0. Fail-safe: pure regex.
            if os.environ.get("REQA_COVERAGE_GUARD", "1") != "0":
                _q_text = original_question or ""
                # Numbers that are FRAGMENTS OF A NAMED DESIGNATION
                # ("1 IG BG HQ", "3rd BN") are part of a name, not a
                # numeric constraint: requiring them verbatim would
                # wrongly reject a correct id-based resolution
                # (obj_item_id = 1457 for "unit 1 IG BG HQ"). A number
                # immediately followed by an uppercase token is treated
                # as designation, not constraint.
                _desig_nums = set(
                    re.findall(
                        r"\b(\d+)(?=\s+[A-Za-z])",
                        _q_text,
                    )
                )
                
                _q_nums = set(re.findall(r"\b\d+(?:\.\d+)?\b",
                                         _q_text)) - _desig_nums
                _sql_no_comments = re.sub(r"--[^\n]*", "", sql)
                
                # temp
                
                logger.warning(
                    "COVERAGE_DESIG_NUMS=%s",
                    _desig_nums,
                )

                logger.warning(
                    "COVERAGE_Q_NUMS=%s",
                    _q_nums,
                )
                
                
                # temp
                
                logger.warning(
                    "ORIGINAL_QUESTION=%s",
                    _q_text,
                )
                
                _dropped = [
                    n for n in _q_nums
                    if not re.search(
                        rf"(?<![\w.]){re.escape(n)}(?:\.0+)?(?![\w])",
                        _sql_no_comments)
                ]
                if _dropped:
                    _msg = ", ".join(sorted(_dropped))
                    error_feedback = (
                        "Your SQL DROPPED numeric constraint(s) from the "
                        f"question: {_msg}. Every number the user wrote "
                        "must be reflected in the SQL (as a WHERE filter, "
                        "a HAVING condition after GROUP BY, or a LIMIT). "
                        "If the condition cannot be expressed against this "
                        "schema (e.g. an aggregate condition used as a row "
                        "filter), answer IMPOSSIBLE and explain why -- do "
                        "NOT silently answer a simpler question instead.")
                    attempt_info.update(
                        failed_at="static_check",
                        error=f"dropped numeric constraint(s): {_msg}")
                    explanation["attempts"].append(attempt_info)
                    logger.info(f"\tCOVERAGE GUARD: dropped {_msg}")
                    continue

                # Structural variant of the same dodge (2026-08-05): asked
                # "...together with its identifier, GROUPED BY category
                # code" (a group_by_violation trap, expected error 1055),
                # the model dropped the GROUP BY entirely and served a
                # plain SELECT as success. No number involved, so the
                # numeric check above cannot see it. When the user EXPLICITLY
                # says "group(ed) by", the SQL must contain a GROUP BY --
                # producing it may legitimately end in error 1055, which the
                # pipeline then surfaces honestly (the expected outcome for
                # that trap). Deliberately narrow: only the literal
                # "group(ed) by" phrasing triggers it, not fuzzy cues like
                # "per category" (handled by sem_conf scoring instead).
                if (re.search(r"\bgroup(?:ed)?\s+by\b",
                              original_question or "", re.I)
                        and not re.search(r"\bGROUP\s+BY\b",
                                          _sql_no_comments, re.I)):
                    error_feedback = (
                        "The question explicitly asks for results GROUPED "
                        "BY a column, but your SQL has no GROUP BY clause "
                        "-- you answered a simpler question instead. Write "
                        "the GROUP BY the user asked for (aggregating the "
                        "other selected columns, e.g. COUNT or "
                        "GROUP_CONCAT, as required by ONLY_FULL_GROUP_BY); "
                        "if the requested combination is invalid, let it "
                        "fail or answer IMPOSSIBLE and explain why.")
                    attempt_info.update(
                        failed_at="static_check",
                        error="dropped GROUP BY requested by the question")
                    explanation["attempts"].append(attempt_info)
                    logger.info("\tCOVERAGE GUARD: dropped GROUP BY")
                    continue

            # ── EXPLAIN dry-run ───────────────────────────────────────────────
            _report({"stage": "explain", "attempt": attempt, "of": self.max_retries})
            try:
                plan_ok, plan_err = self.dry_runner.explain(sql)
            except DryRunConnectionError as e:
                # Genuine DB connection failure -- worth tripping the
                # circuit breaker over, unlike a plain content/schema
                # error (handled below via the normal (ok, err) path,
                # which never reaches this branch).
                attempt_info.update(failed_at="explain", error=str(e))
                explanation["attempts"].append(attempt_info)
                logger.warning(f"RUN[{attempt}] EXPLAIN connection failure: {e}")
                self.cb.record_failure()
                if self.cb.is_open():
                    logger.error("CIRCUIT BREAKER: EXPLAIN connection repeatedly failing")
                    return PipelineResult(
                        success=False,
                        answer="Query planning failed too many times — graceful failure.",
                        sql=sql,
                        error=str(e),
                        attempts=attempt,
                        explanation=explanation,
                        debug=debug_rval
                    )
                error_feedback = ""
                continue

            if not plan_ok:

                if "Unknown column" in str(plan_err):

                    logger.warning(
                        "SCHEMA_LIMITATION_DETECTED=%s",
                        plan_err,
                    )

                    return PipelineResult(
                        success=True,

                        answer=(
                            f"Schema limitation detected: {plan_err}. "
                            "The requested information is not available "
                            "in the current database schema. "
                            "The system refused to invent data."
                        ),

                        answerability_status=
                            AnswerabilityStatus.PARTIAL_SCHEMA_LIMITATION,

                        attempts=attempt,

                        explanation={
                            "overall_score": 100,
                            "schema_limitation": str(plan_err),
                            "confidence": {
                                "score": 1.0,
                                "score_strict": 1.0,
                                "rag_conf": 1.0,
                                "gen_conf": 1.0,
                                "sem_conf": 1.0,
                                "ground_conf": 1.0,
                            },
                        },

                        debug=debug_rval,
                    )

   
                # Content/schema error (e.g. "Unknown column") -- the
                # expected, common, self-correctable outcome of validating
                # freshly LLM-generated SQL. Previously this ALSO called
                # self.cb.record_failure(), meaning a single wrong column
                # name could trip the circuit breaker and cut the retry
                # loop short after just 1 attempt instead of the intended
                # max_retries -- verified against a real deployment. Must
                # NOT touch the circuit breaker; just retry with feedback.
                attempt_info.update(failed_at="explain", error=plan_err)
                explanation["attempts"].append(attempt_info)
                logger.info(f"\tEXPLAIN content error (not a circuit-breaker event): {plan_err}")
                # v3.1: append the KB's documented corrective instruction for
                # this error class, plus the closest REAL identifiers when the
                # error names an unknown column/table. A bare "Unknown column
                # 'x'" makes the model guess again; naming the real candidates
                # is what makes the next attempt land.
                _hint = repair_hint(plan_err, [t.table_name for t in schema_chunks[:5]
                                               if getattr(t, "table_name", "")])
                error_feedback = f"EXPLAIN failed: {plan_err}"
                if _hint:
                    error_feedback += f"\nHOW TO FIX: {_hint}"
                    logger.info(f"\tREPAIR HINT: {_hint}")
                
                
                   
                    
                
                continue

            # ── Execution ─────────────────────────────────────────────────────
            _report({"stage": "execution", "attempt": attempt, "of": self.max_retries})
            try:
                rows, exec_err = self.executor.execute(sql)
            except ExecutorConnectionError as e:
                attempt_info.update(failed_at="execution", error=str(e))
                explanation["attempts"].append(attempt_info)
                logger.warning(f"RUN[{attempt}] Execution connection failure: {e}")
                self.cb.record_failure()
                if self.cb.is_open():
                    logger.error("CIRCUIT BREAKER: execution connection repeatedly failing")
                    return PipelineResult(
                        success=False,
                        answer="Query execution failed too many times — graceful failure.",
                        sql=sql,
                        error=str(e),
                        attempts=attempt,
                        explanation=explanation,
                        debug=debug_rval
                    )
                error_feedback = ""
                continue

            if exec_err:
                # Same reasoning as the EXPLAIN content-error case above:
                # a query-level error (bad column, constraint, ...) is
                # self-correctable, not an infrastructure failure -- does
                # not touch the circuit breaker.
                attempt_info.update(failed_at="execution", error=exec_err)
                explanation["attempts"].append(attempt_info)
                logger.info(f"\tExecution content error (not a circuit-breaker event): {exec_err}")
                _hint = repair_hint(exec_err, [t.table_name for t in schema_chunks[:5]
                                               if getattr(t, "table_name", "")])
                error_feedback = f"Execution error: {exec_err}"
                if _hint:
                    error_feedback += f"\nHOW TO FIX: {_hint}"
                    logger.info(f"\tREPAIR HINT: {_hint}")
                continue

            # ── Empty-result transparency (v3.7) ──────────────────────────────
            # A SUCCESS that carries no data (0 rows, or a single all-NULL
            # row from an aggregate over an empty set) was the dominant
            # silent failure observed in evaluation (16/24 runs,
            # 2026-07-28): filters that can never match execute fine and
            # return nothing. First occurrence: ONE guarded retry with
            # explicit feedback so the LLM re-checks values and joins. If
            # it still comes back empty (or no attempt remains), the result
            # is served but SAYS SO, and the confidence is capped -- never
            # again a confident empty answer.
            def _result_is_empty(_rows) -> bool:
                if not _rows:
                    return True
                if len(_rows) == 1:
                    first = _rows[0]
                    vals = (first.values() if isinstance(first, dict)
                            else first if isinstance(first, (list, tuple))
                            else [first])
                    try:
                        return all(v is None for v in vals)
                    except TypeError:
                        return False
                return False
            ###########################
            logger.info("=" * 80)
            logger.info(f"ROWS_TYPE={type(rows)}")
            logger.info(f"ROWS_LEN={len(rows) if rows is not None else 'None'}")

            if rows:
                logger.info(f"FIRST_ROW={rows[0]}")
                logger.info(f"ROWS_PREVIEW={rows[:3]}")

            logger.info("=" * 80)

            empty_result = _result_is_empty(rows)
            
            ############################

            empty_result = _result_is_empty(rows)
            if (empty_result and not _empty_retry_done
                    and attempt < self.max_retries and not _out_of_time()):
                _empty_retry_done = True
                attempt_info.update(failed_at="empty_result",
                                    error="query executed but returned no data")
                explanation["attempts"].append(attempt_info)
                logger.info("\tEMPTY RESULT: retrying once with feedback")
                error_feedback = (
                    "The previous query executed WITHOUT error but returned "
                    "NO data (0 rows or only NULL values). Its filters "
                    "probably never match anything. Re-check EVERY literal "
                    "value against the Allowed lists and the question's "
                    "exact wording, re-check the join path, and REMOVE any "
                    "filter the question does not explicitly require. If "
                    "the schema genuinely cannot answer the question, "
                    "answer IMPOSSIBLE instead.")
                continue

            # ── Render ────────────────────────────────────────────────────────
            _report({"stage": "rendering", "attempt": attempt, "of": self.max_retries})
            self.cb.record_success()
            # BUGFIX: a renderer exception previously propagated out of
            # run() as an unhandled crash AFTER the query had already
            # executed successfully -- losing the results. Degrade to a
            # plain-text fallback instead.
            try:
                answer = self.renderer.render(question, sql, rows)
            except Exception as render_exc:
                logger.warning(f"Renderer failed, using raw-results fallback: {render_exc}")
                _preview = rows[:20]
                answer = (f"The query executed successfully and returned "
                          f"{len(rows)} row(s). Raw results (first {len(_preview)}): {_preview}")

            explanation["attempts"].append(attempt_info)   # failed_at=None → success
    
            

            #if force:
            #    explanation["confidence"] = {"score": 1.0, "score_strict": 1.0, "rag_conf": 1.0, "gen_conf": 1.0, "sem_conf": 1.0}
            #else:
            explanation["confidence"] = _compute_confidence(
                schema_chunks, attempt, self.max_retries, success=True,
                question=question, sql=sql,    )

            # Empty result served anyway: be transparent in the answer and
            # cap the confidence -- rag/gen/sem cannot see emptiness, and
            # evaluation showed empty answers scoring up to 0.97 without
            # this cap.
            if empty_result:
                answer = (answer or "").strip() + (
                    "\n\nNote: this query executed without error but "
                    "matched NO data. Either the database genuinely holds "
                    "nothing for these filters, or a filter value/join does "
                    "not correspond to how the data is stored.")
                _c = explanation["confidence"]
                _c["empty_result"] = True
                _c["score"] = min(_c.get("score", 0.0), 0.5)
                _c["score_strict"] = min(_c.get("score_strict", 0.0), 0.3)

            explanation["xai"] = _build_xai(
                question, sql, schema_chunks, attempt,
                explanation.get("attempts") or [],
                llm=getattr(self.sql_generator, "llm", None),
            )

            logger.info("SUCCESS")
            return PipelineResult(
                success=True,
                answer=answer,
                sql=sql,
                rows=rows,
                row_count=len(rows),
                attempts=attempt,
                explanation=explanation,
                debug=debug_rval
            )

        logger.info("MAX RETRIES")
    


        # Silent background auto-answer before surfacing a failure: all
        # max_retries attempts on the original wording failed, but a
        # reformulation grounded in the schema vocabulary may still succeed
        # (and benefit from the catalog short-circuit). Returns only if a
        # candidate clears the confidence gate; else fall through to the
        # normal suggestion list.
        if self.allow_reformulation and allow_reformulation and not _out_of_time():
            auto = self._try_auto_answer(
                original_question, schema_chunks, error_feedback=error_feedback)
            if auto is not None:
                return auto
        # After exhausting all attempts, offer the user guaranteed-answerable
        # alternatives drawn from the top RAG candidates' sample_queries --
        # turning a dead-end into a redirection.
        try:
            _cat = self.schema_rag.suggest_questions(
                [t.table_name for t in schema_chunks[:3]], per_table=2, exclude=question,
            )
            _ref = _llm_reformulations(
                question, schema_chunks, getattr(self.sql_generator, "llm", None),
                error_feedback=error_feedback,
            )
            explanation["question_suggestions"] = _combine_suggestions(_cat, _ref)
        except Exception:
            pass
        return PipelineResult(
            success=False,
            answer="Could not generate a valid query after multiple attempts.",
            error=error_feedback,
            attempts=self.max_retries,
            explanation=explanation,
            debug=debug_rval
        )
