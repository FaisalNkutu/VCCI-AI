from abc import ABC, abstractmethod





class BaseLLM(ABC):
    """
    Swap any LLM by subclassing this and implementing `complete`.
    Both the SQL generator and the renderer use this interface.
    """

    @abstractmethod
    def complete(self, system: str, messages: list[dict], max_tokens: int = 1024,
                json_mode: bool = False) -> str:
        """
        Args:
            system:     System prompt string.
            messages:   List of {"role": "user"|"assistant", "content": str}.
            max_tokens: Maximum tokens to generate.
        Returns:
            Generated text (stripped).
        """


    #
    #   Langfuse trace utilities. Use these to help read the LangFuse traces in http page
    #
    #       Set the query for this whole request.
    #       Then at each step, set the step name ex: Plan
    #       Also mark the retries.
    #      
    #

    #
    #   set_langfuse_trace_query()
    #           
    def set_langfuse_trace_query(self, name ):
        self.langfuse_trace_query = name

    #
    #
    #
    def set_langfuse_trace_tag(self, tag ):
        self.langfuse_trace_tag = tag

    #
    #   langfuse_trace_step()
    #  
    def set_langfuse_trace_step(self, step ):
        self.langfuse_trace_step = step
        

    #
    #   set_langfuse_trace_attempt()
    #  
    def set_langfuse_trace_attempt(self,  attempt = 1 ):        
        self.langfuse_trace_attempt = 1
