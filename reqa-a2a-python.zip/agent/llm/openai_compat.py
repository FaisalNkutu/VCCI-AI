from openai import OpenAI
from .base import BaseLLM


class OpenAICompatLLM(BaseLLM):
    """
    Any OpenAI-compatible REST API:
      - Mistral API  (https://api.mistral.ai/v1)
      - LM Studio    (http://localhost:1234/v1)
      - Groq         (https://api.groq.com/openai/v1)
      - Together.ai  (https://api.together.xyz/v1)
      - vLLM / TGI   (http://localhost:8000/v1)
      - Ollama /v1   (http://ollama:11434/v1)

    Set LLM_PROVIDER=openai_compat in .env and configure the three vars below.
    """

    def __init__(self, model: str, base_url: str, api_key: str = "local"):
        self.model = model
        self._client = OpenAI(base_url=base_url, api_key=api_key)

    def complete(self, system: str, messages: list[dict], max_tokens: int = 1024,
                 json_mode: bool = False) -> str:
        all_messages = []
        if system:
            all_messages.append({"role": "system", "content": system})
        all_messages.extend(messages)

        resp = self._client.chat.completions.create(
            model=self.model,
            messages=all_messages,
            max_tokens=max_tokens,
        )
        return resp.choices[0].message.content.strip()
