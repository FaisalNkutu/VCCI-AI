
import os
import sys
import time
import requests
import logging
from .base import BaseLLM

logger = logging.getLogger("OLLAMA LLM")


from langfuse import get_client, propagate_attributes

#=======================   config.json  ====================================================
sys.path.insert(0, "../../") # add this path to get the config in root dir
from config.settings import get_settings
#===========================================================================================

from a2a_common.a2a_base_agent_setup import A2AAgentBaseSetup, init_asyncio
from dotenv import load_dotenv
import json


#
# 1. Configure your Langfuse credentials
#   These variables should be defined in .env

#os.environ["LANGFUSE_PUBLIC_KEY"] = "pk-lf-62cc52f7-b1f8-4297-800e-e1ef9b30096c"
#os.environ["LANGFUSE_SECRET_KEY"] = "sk-lf-cfae3a1f-7bf3-4126-ad7d-86c48b4f4e23"
#os.environ["LANGFUSE_BASE_URL"] = "http://192.168.2.129:3000"  # Or your Cloud URL (e.g., https://cloud.langfuse.com)



import traceback


# 2. Use the modern client initialization method
langfuse = get_client()

class OllamaLLM(BaseLLM):
    """
    Local Ollama backend — 100% local, no data leaves the machine.
    Recommended models: mistral, codestral, phi4, codellama:7b, llama3.1:8b
    """

    def __init__(self, model: str = "mistral", base_url: str = "http://ollama:11434"):
        self.model = model
        self._url = base_url.rstrip("/") + "/api/chat"

        self.set_langfuse_trace_tag( "test" )
        self.set_langfuse_trace_query( "not set" )
        self.set_langfuse_trace_step( "not set" )
        self.set_langfuse_trace_attempt( 0 )

        settings = get_settings()
        self.LANGFUSE_ENABLED = settings.LANGFUSE_ENABLED

    def complete(self, system: str, messages: list[dict], max_tokens: int = 1024,
                 json_mode: bool = False, **kwargs) -> str:

        if self.LANGFUSE_ENABLED == True:
            return self.complete_with_langfuse( system, messages, max_tokens, json_mode)
        else:
            return self._complete( system, messages, max_tokens, json_mode)


    #
    #   complete_priv
    #
    def _complete(self, system: str, messages: list[dict], max_tokens: int = 1024,
                 json_mode: bool = False, **kwargs) -> str:
   
        payload_messages = []
        if system:
            payload_messages.append({"role": "system", "content": system})
            payload_messages.extend(messages)
            
        logger.warning(
            "OLLAMA_MODEL=%s",
            self.model,
        )

        logger.warning(
            "OLLAMA_URL=%s",
            self._url,
        )

        logger.warning("OLLAMA_MESSAGE_COUNT=%s", len(messages))

        logger.warning(
            "OLLAMA_MESSAGE_ROLES=%s",
            [m.get("role") for m in messages],
        )

        for i, message in enumerate(messages):
            logger.warning(
                "OLLAMA_MESSAGE[%s] role=%s content=%r",
                i,
                message.get("role"),
                message.get("content"),
            )

        logger.warning(
            "OLLAMA_HAS_UNIT_DETAILS=%s",
            
        )

        logger.warning(
                "OLLAMA_HAS_UNIT_DETAILS=%s",
                any(
                    "unit_details"
                    in str(message.get("content", "")).lower()
                    for message in payload_messages
                ),
            )

        logger.warning(
                "OLLAMA_HAS_REFERENCE_SOLUTION=%s",
                any(
                    "reference solution"
                    in str(message.get("content", "")).lower()
                    for message in payload_messages
                ),
            )

        request_body = {
            "model": self.model,
            "messages": payload_messages,
            "stream": False,
            "options": {"num_predict": max_tokens, "temperature": 0 },
            }
        if json_mode:
            request_body["format"] = "json"


        langfuse_gen = kwargs.get("langfuse_gen", None)
        if langfuse_gen != None:
            langfuse_gen.update(
                        model=self.model,
                        input=payload_messages
                    )


        response = requests.post(
                        self._url,
                        json=request_body,
                        timeout=400,  # was 120: codestral on 40-60K-char prompts via the shared remote Ollama server (queued requests) routinely exceeds 2 min; 400s matches what the eval scripts already learned the hard way
                    )      
        try:                   
                                                                
            response_data = response.json()
            if "message" in response_data:
                output_content = response_data["message"]["content"]
            else:
                output_content = "ERROR: No message returned"
                logger.warning( f"{response_data}" )


            # 8. Update generation tracking with output data and specific usage schemas
            if langfuse_gen != None:
                
                prompt_tokens = response_data.get("prompt_eval_count", 0)
                completion_tokens = response_data.get("eval_count", 0)
                total_tokens = prompt_tokens + completion_tokens

                langfuse_gen.update(
                    #input = self.langfuse_trace_query
                    output = output_content,
                    usage_details={
                        "input_tokens": prompt_tokens,
                        "output_tokens": completion_tokens,
                        "total_tokens": total_tokens
                    },
                    metadata={"debug": "value"}
                )

            response.raise_for_status()

        except requests.HTTPError:
            print( f"RESPONSE_DATA={response_data}")
            traceback.print_exc()
            # Ollama's status code alone is not actionable (400 can mean
            # context overflow, invalid model/options, or a malformed
            # request). Preserve the server-provided reason in the A2A log.
            logger.error(
                "Ollama request failed status=%s model=%s response=%s",
                resp.status_code,
                self.model,
                resp.text[:1000],
            )
            raise
                        
        except Exception as e:
            print( f"RESPONSE_DATA={response_data}")
            traceback.print_exc()
            # 9. Handle exceptions cleanly within the telemetry span      
            if langfuse_gen != None:
                langfuse_gen.update(
                                level="ERROR",
                                status_message=str(e)
                            )     
            raise e
                    
        return output_content.strip()



    #
    #   Langfuse version of complete
    #
    #
    #-----------------------------------------------------------------------------
    #   Todo: try to use the decorator @observe()  instead ?    
    #     
    #--------------------------------------------------------------------------------
    #
    def complete_with_langfuse(self, system: str, messages: list[dict], max_tokens: int = 1024,  json_mode: bool = False) -> str:

        with langfuse.start_as_current_observation(as_type="span", name="NL2SQL") as trace_span:        
            # 4. Propagate common metadata across all inner observations
            with propagate_attributes(tags=[ self.langfuse_trace_tag],  user_id="user", 
                metadata={"environment": "production", "query" : self.langfuse_trace_query, "method" : "ollama_llm.complete" }):

                  # 5. Nest a specialized generation observation for the LLM execution
                with langfuse.start_as_current_observation(as_type="generation", name=f"{self.langfuse_trace_query} {self.langfuse_trace_step} (retry {self.langfuse_trace_attempt})") as langfuse_gen:
                    try:                         
                        response = self._complete( system, messages, max_tokens, json_mode, langfuse_gen = langfuse_gen )
                    except Exception as e:
                    # 9. Handle exceptions cleanly within the telemetry span           
                        raise e


        return response

