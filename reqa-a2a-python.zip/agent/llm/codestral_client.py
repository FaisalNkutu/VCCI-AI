"""
LLM #1 — SQL generation via Codestral (Ollama).

TRANSPORT-ONLY adapter. All prompting logic and SQL-cleaning logic are
imported from agent.sql_generator — the single source of truth — instead
of being duplicated here.

Why this matters (learned the hard way in this project): this file used to
carry its OWN system prompt and its OWN _clean_sql(), which silently
diverged from the pipeline's:
  * its rule 5 ALLOWED "WITH (CTE)" while the canonical prompt says
    "Avoid WITH (CTE) clauses entirely" (local models reliably fumble
    CTE syntax — "Expected CTE to have alias" failures observed in evals);
  * its _clean_sql kept the legacy bugs long since fixed in the pipeline:
    raw.replace(";", " ") corrupting string literals, joining lines with
    spaces (swallowing everything after an inline "--" comment), and no
    extraction of SQL from conversational replies (the fix that took the
    smoke-test pass rate from 65% to 90%);
  * its retry suffix did not re-include the previous SQL, which is the
    exact trigger of the "table1"/"foreign_key" placeholder cascade seen
    in server logs ("Without seeing the previous SQL query...").

Exposes BOTH call shapes:
  * generate_sql(...)          — function, backward compatible;
  * class CodestralClient      — thin wrapper, matching the import in
    RAG/generate_sql_for_sample_questions.py
    (`from agent.llm.codestral_client import CodestralClient`), which was
    broken against the previous function-only version of this module.
"""
import ollama

from config.settings import get_settings

# Single source of truth: the pipeline's canonical system prompt (with the
# CTE ban, placeholder ban and column-exactness rules) and the corrected
# SQL cleaner (fence extraction, last-SELECT fallback, comment-safe line
# joining, literal-safe semicolon handling).
from agent.sql_generator import _SYSTEM as _CANONICAL_SYSTEM
from agent.sql_generator import clean_sql

_DEFAULT_MAX_ROWS = 100

_RETRY_BLOCK = """

⚠ Your previous attempt FAILED.

YOUR PREVIOUS SQL:
{previous_sql}

ERROR:
{error}

Diagnose the error using the schema context above, then output ONLY the
corrected SQL query. Use ONLY table and column names present in the schema
context — never placeholder names like table1 or main_table.
"""


def generate_sql(
    question: str,
    schema_context: str,
    error_feedback: str = "",
    previous_sql: str = "",
) -> str:
    """
    One-shot SQL generation through Ollama/Codestral, using the canonical
    system prompt and cleaner from agent.sql_generator.

    previous_sql: pass the SQL of the failed attempt when retrying —
    without it the model cannot diagnose its own error and tends to fall
    back to generic placeholder templates (observed repeatedly in logs).
    """
    settings = get_settings()

    user_content = (
        f"Schema context:\n{schema_context}\n\n"
        f"Question: {question}"
    )
    if error_feedback:
        user_content += _RETRY_BLOCK.format(
            previous_sql=previous_sql or "(not available)",
            error=error_feedback,
        )

    response = ollama.chat(
        model=settings.ollama_sql_model,
        messages=[
            {"role": "system", "content": _CANONICAL_SYSTEM.format(max_rows=_DEFAULT_MAX_ROWS)},
            {"role": "user",   "content": user_content},
        ],
        options={"temperature": 0.0, "num_predict": 1024},
    )
    raw = response["message"]["content"].strip()
    return clean_sql(raw)


class CodestralClient:
    """
    Thin class wrapper over generate_sql(), matching the import shape used
    by RAG/generate_sql_for_sample_questions.py. Stateless besides an
    optional max_rows override.
    """

    def __init__(self, max_rows: int = _DEFAULT_MAX_ROWS):
        self.max_rows = max_rows

    def generate_sql(
        self,
        question: str,
        schema_context: str,
        error_feedback: str = "",
        previous_sql: str = "",
    ) -> str:
        return generate_sql(question, schema_context, error_feedback, previous_sql)
