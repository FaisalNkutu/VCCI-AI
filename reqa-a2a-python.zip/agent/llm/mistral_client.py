"""
LLM #2 — Natural language rendering via Mistral 7B (Ollama).
"""
import json

import ollama

from config.settings import get_settings

_RENDER_SYSTEM_PROMPT = """\
You are a NATO military intelligence analyst assistant.
You will receive a question, the SQL query that was executed, and the raw query results.
Your task: write a clear, concise, professional answer in natural language.

Guidelines:
- Lead with a direct answer to the question.
- List EVERY row returned — do not skip, merge, or summarise individual records.
  For each row include all meaningful fields (name, code, location, etc.).
- For large result sets (>20 rows), group by a relevant field instead of listing one-by-one.
- Mention any important caveats (e.g., data may be fictional/training data).
- Keep the tone formal and concise.
- Do NOT reproduce the raw SQL or JSON in your response.
"""


def render_results(
    question: str,
    sql: str,
    rows: list[dict],
) -> str:
    settings = get_settings()

    truncated = rows[:50]
    rows_json = json.dumps(truncated, default=str, ensure_ascii=False, indent=2)
    row_note = f"({len(rows)} total rows returned)" if len(rows) > 50 else ""

    user_content = (
        f"Question: {question}\n\n"
        f"SQL executed:\n{sql}\n\n"
        f"Results {row_note}:\n{rows_json}"
    )

    response = ollama.chat(
        model=settings.ollama_render_model,
        messages=[
            {"role": "system", "content": _RENDER_SYSTEM_PROMPT},
            {"role": "user",   "content": user_content},
        ],
        options={"temperature": 0.3, "num_predict": 1024},
    )
    return response["message"]["content"].strip()
