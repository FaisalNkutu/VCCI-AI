import os
import requests
from langfuse import get_client, propagate_attributes


# 1. Configure your Langfuse credentials
# Replace with your actual credentials or set them via environment variables
os.environ["LANGFUSE_PUBLIC_KEY"] = "pk-lf-62cc52f7-b1f8-4297-800e-e1ef9b30096c"
os.environ["LANGFUSE_SECRET_KEY"] = "sk-lf-cfae3a1f-7bf3-4126-ad7d-86c48b4f4e23"
os.environ["LANGFUSE_BASE_URL"] = "http://192.168.2.129:3000"  # Or your Cloud URL (e.g., https://cloud.langfuse.com)


# 2. Use the modern client initialization method
langfuse = get_client()

def generate_with_ollama_and_trace(prompt: str, model_name: str = "Gemma4:latest"):
    # 3. Create the parent span (this defines the overall request trace)
    with langfuse.start_as_current_observation(as_type="span", name="ollama-generation") as trace_span:
        
        # 4. Propagate common metadata across all inner observations
        with propagate_attributes(user_id="user_123", metadata={"environment": "production"}):
            
            # 5. Nest a specialized generation observation for the LLM execution
            with langfuse.start_as_current_observation(as_type="generation", name="ollama-chat-completion") as generation:
                # Set the input and model name directly onto the active generation context
                generation.update(
                    model=model_name,
                    input=[{"role": "user", "content": prompt}]
                )
                
                # Prepare Ollama request details
                ollama_url = "http://ollama:11434/api/chat"
                payload = {
                    "model": model_name,
                    "messages": [{"role": "user", "content": prompt}],
                    "stream": False
                }
                
                try:
                    # 6. Make the raw HTTP request to Ollama
                    response = requests.post(ollama_url, json=payload, timeout=30)
                    response.raise_for_status()
                    
                    response_data = response.json()
                    output_content = response_data["message"]["content"]
                    
                    # 7. Extract token usage from Ollama's response metrics
                    prompt_tokens = response_data.get("prompt_eval_count", 0)
                    completion_tokens = response_data.get("eval_count", 0)
                    total_tokens = prompt_tokens + completion_tokens
                    
                    # 8. Update generation tracking with output data and specific usage schemas
                    generation.update(
                        output=[{"role": "assistant", "content": output_content}],
                        usage_details={
                            "input_tokens": prompt_tokens,
                            "output_tokens": completion_tokens,
                            "total_tokens": total_tokens
                        }
                    )
                    
                    # Optional: Set the final output at the root trace level
                    trace_span.update(output=output_content)
                    return output_content

                except Exception as e:
                    # 9. Handle exceptions cleanly within the telemetry span
                    generation.update(
                        level="ERROR",
                        status_message=str(e)
                    )
                    raise e
                finally:
                    # 10. Ensure background threads push analytics immediately
                    langfuse.flush()


# Execute the updated workflow
if __name__ == "__main__":
    prompt_text = "Why is the sky blue? Answer in one short sentence."
    print("Sending prompt to Ollama...")
    
    reply = generate_with_ollama_and_trace(prompt=prompt_text, model_name="Gemma4:latest")
    print(f"\nOllama Reply: {reply}")