# agent/entity_resolution.py

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from agent.term_grounding import _schema_vocab


@dataclass
class ResolutionCandidate:

    table: Optional[str] = None

    column: Optional[str] = None

    value: Optional[str] = None

    source: str = ""


@dataclass
class EntityResolution:

    entity: str

    resolution_type: str

    candidates: list[ResolutionCandidate] = field(
        default_factory=list
    )

    confidence: float = 0.0

    lookup_required: bool = False


def _parse_reference(ref: str):

    #
    # Example:
    # ctrl_feat_type.echln_code = 'SECT'
    #

    if "=" in ref:

        left = ref.split("=", 1)[0].strip()

        if "." in left:

            table, column = left.split(".", 1)

            return table, column

    #
    # Example:
    # column metrics_results.cat_code
    #

    if ref.startswith("column "):

        txt = ref.replace(
            "column ",
            ""
        )

        if "." in txt:

            table, column = txt.split(".", 1)

            return table, column

    #
    # Example:
    # table `scenario`
    #

    if ref.startswith("table `"):

        table = (
            ref.replace("table `", "")
               .split("`")[0]
               .strip()
        )

        return table, None

    return None, None


def resolve_entity(
    entity: str
) -> EntityResolution:

    entity = (
        entity or ""
    ).strip()

    if not entity:

        return EntityResolution(
            entity="",
            resolution_type="invalid",
            confidence=0.0,
            lookup_required=False,
        )

    vocab = _schema_vocab()

    refs = vocab.get(
        entity.lower()
    )

    #
    # STEP 1
    # KB / ENUM RESOLUTION
    #

    if refs:

        candidates = []

        for ref in sorted(refs):

            table, column = _parse_reference(ref)

            candidates.append(
                ResolutionCandidate(
                    table=table,
                    column=column,
                    value=entity,
                    source=ref,
                )
            )

        return EntityResolution(
            entity=entity,
            resolution_type="kb",
            candidates=candidates,
            confidence=1.0,
            lookup_required=False,
        )

    #
    # STEP 2
    # NO KB MATCH
    #
    # Future:
    # Targeted DB Lookup
    #

    return EntityResolution(
        entity=entity,
        resolution_type="unresolved",
        candidates=[],
        confidence=0.0,
        lookup_required=True,
    )
    
    
from dataclasses import dataclass
from typing import Optional


@dataclass
class LookupResult:

    found: bool

    table: Optional[str] = None

    column: Optional[str] = None

    value: Optional[str] = None

    confidence: float = 0.0

    lookup_sql: str = ""
    

def resolve_entity_lookup(
    entity: str,
    candidate_tables: list[str]
) -> LookupResult:

    entity = (entity or "").strip()

    if not entity:

        return LookupResult(
            found=False
        )

    #
    # Future implementation:
    #
    # Use candidate_tables from
    # Schema RAG / GraphRAG
    #
    # Build targeted SQL lookups
    #
    # Example:
    #
    # SELECT obj_item_id
    # FROM obj_item
    # WHERE name_txt = ?
    #
    # LIMIT 1
    #

    return LookupResult(
        found=False,
        confidence=0.0
    )
    
    
def add_lookup_candidate(
    resolution: EntityResolution,
    table: str,
    column: str,
    value: str,
):
    resolution.candidates.append(
        ResolutionCandidate(
            table=table,
            column=column,
            value=value,
            source="database_lookup",
        )
    )

    resolution.resolution_type = "database_lookup"
    resolution.lookup_required = False
    resolution.confidence = 1.0