﻿"""
Enhanced SchemaRAG

Features:
- Query expansion (optional)
- Multi-query retrieval
- Reciprocal Rank Fusion (RRF)
- FK-neighbour expansion
- Relevance scoring
- Deduplicated business rules
- JOIN hints generation
- Cached table names
- Lexical fallback retrieval for schema-exploration questions
- Few-shot sample queries injected per table (text-to-SQL quality boost)
- Exact table-name anchor (leverages sql_generator's entity-name rewrite)
- Catalog short-circuit match (best_sample_query)
"""

from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass
from typing import Optional

from qdrant_client import QdrantClient
from qdrant_client.models import Filter, FieldCondition, MatchValue


from config.settings import get_settings
settings = get_settings()

from agent.embedder import Embedder
from RAG.knowledge_base import (
    build_ddl_with_kb,
    extract_business_rules,
)
# v3 (enriched KB). Two distinct needs:
#  - SAFETY: the payload may be STALE (a Qdrant collection indexed before
#    ingest.py was updated still carries the negative families, DELETE
#    statements included). Every read of payload["sample_queries"] is
#    therefore re-filtered here, not only at ingestion time.
#  - RELEVANCE: rank_kinds/get_business_examples let the context builder
#    and the suggestion list use the question's shape.
from RAG.knowledge_base import (
    POSITIVE,
    is_readonly_select,
    query_class,
    get_business_examples,
    get_sample_queries,
)

import traceback
import sys
sys.path.insert(0, "../") # add this path to get the config in root dir
sys.path.insert(0, "../neo4j") # add this path to get the config in root dir
sys.path.insert(0, "neo4j") # add this path to get the config in root dir
from neo4j_functions import find_info_by_cat_codes as neo4j_find_info_by_cat_codes
from neo4j_functions import find_info_by_table_names as neo4j_find_info_by_table_names

from agent.rated_rules import RatedRulesRAG as RatedRulesRAG

logger = logging.getLogger("SCHEMA RAG")

_RRF_K = 60


def _validate_join_on(table_name: str, rel: dict) -> bool:
    """
    Cross-checks a relationship's pre-formatted `join_on` string against
    its own_column/related_column fields -- present in the KB from the
    very start of this project, but never actually read anywhere in the
    pipeline until now. join_on is generated FROM those same fields at KB
    build time; if they ever drift out of sync (a manual KB edit, a bug in
    an older generation script, ...), the join_on text could silently be
    wrong while looking perfectly well-formed -- there was previously no
    way to catch that. Returns True if consistent (or nothing to check),
    False if a genuine mismatch is detected.
    """
    own_col = rel.get("own_column")
    rel_col = rel.get("related_column")
    rel_table = rel.get("related_table")
    join_on = (rel.get("join_on") or "").strip()
    role = rel.get("role")

    if not (own_col and rel_col and rel_table and join_on):
        return True  # nothing to cross-check against

    if role == "child_of":
        expected = f"{rel_table}.{rel_col} = {table_name}.{own_col}"
    elif role == "parent_of":
        expected = f"{table_name}.{own_col} = {rel_table}.{rel_col}"
    else:
        return True

    return join_on == expected

# Generic stopwords to ignore when extracting keywords from a question for
# the lexical fallback â€” not table/domain specific.
_STOPWORDS = {
    "the", "a", "an", "all", "any", "show", "list", "display", "get",
    "tables", "table", "related", "relate", "relates", "about", "with",
    "for", "of", "in", "on", "to", "and", "or", "is", "are", "what",
    "which", "me", "please", "data", "rows", "row", "records", "record",
    # Added after a real production bug: these words dominate the
    # sample_query GENERATION templates ("How many X records are there?",
    # "Can you show me some examples of X?"), so without excluding them,
    # _sample_query_boost()'s word-overlap check matched on the TEMPLATE
    # phrasing shared by every table's generic sample questions rather
    # than the table-specific content word -- multiple unrelated tables
    # (whichever else also has a "How many ... records are there?" sample
    # query) got boosted to ~95%+ confidence for ANY question following
    # that template, drowning out the one genuinely relevant table.
    # Verified: "How many Absolute Point records are there?" scored
    # "runway"/"holding"/"disroute" all at 95.6% (pure template overlap)
    # while abs_point itself never made the top-5 at all.
    "how", "many", "there", "can", "you", "some", "examples", "example",
    "does", "do", "did", "has", "have", "had",
    # Second wave of template filler, from the v2 naturalised KB's
    # group_by_enum / distinct / aggregate templates ("... for each
    # category code", "What distinct ... values appear in ...", ...).
    # Without these, every table carrying a group_by_enum sample query
    # shares {each, category, code} with any such question and lands at
    # ~0.5 overlap, so the genuinely-relevant table's single distinctive
    # word can no longer stand out. Verified: "How many abs_point records
    # for each category code" tied abs_point with every other *_point
    # table. NOTE: these are stripped for RANKING only; the catalog
    # short-circuit (best_sample_query) deliberately KEEPS them via the
    # separate _catalog_words() below.
    "each", "category", "code", "values", "value", "appear", "across",
    "average", "maximum", "minimum", "highest", "lowest", "distinct",
    "count", "number", "per", "group",
    # v3 NOTE (no change made here on purpose): the enriched KB adds
    # business templates instantiated on most tables ("...what share of the
    # total does each represent?", "What proportion of X records are missing
    # their Y?"). Measured on the enriched KB, the contamination is small --
    # 24 tables above 0.5 overlap on the worst shape, 0 on the others --
    # because the Jaccard union still carries each table's own label words.
    # This set is the result of two production incidents and is left
    # UNTOUCHED. If a drowning case does appear, add the offending word
    # here, but check it first against table labels/keywords: "activity",
    # "performance" and "total" are frequent template words AND the labels
    # of 13 real tables (act_event, act_task, metrics, ...).
}

# Minimal stopword set used ONLY by the catalog short-circuit
# (best_sample_query). The retrieval-side _content_words() strips a lot of
# template words (each/category/code/...) so that group_by_enum questions
# don't all look alike for RANKING -- but the short-circuit needs the exact
# opposite: it must DISTINGUISH "How many X records are there?" (count)
# from "How many X records are there for each category code?" (group_by),
# which differ ONLY by those very words. So it keeps them, stripping only
# true filler, and (in pipeline.py) matches on the ORIGINAL question so it
# lines up with the naturalised sample_query text ("Absolute Point").
_CATALOG_STOP = {
    "the", "a", "an", "is", "are", "me", "you", "please",
    "of", "to", "in", "on", "do", "does", "did",
}


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class RetrievedTable:
    payload: dict
    score: float           # composite: 0.7Ã—RRF + 0.3Ã—cosine
    cosine_score: float = 0.0  # raw cosine similarity (fastembed) â€” used for XAI confidence

    @property
    def table_name(self) -> str:
        return self.payload.get("table", "")


# ---------------------------------------------------------------------------
# SchemaRAG
# ---------------------------------------------------------------------------

def _content_words(text: str) -> set[str]:
    """
    Shared by _sample_query_boost() (re-ranks candidates already found by
    vector search) and _sample_query_rescue() (finds tables vector search
    missed entirely). Aggressive template-word stripping for RANKING.
    """
    words = re.findall(r"[a-z0-9]+", text.lower())
    return {w for w in words if w not in _STOPWORDS}


def _catalog_words(text: str) -> set[str]:
    """
    Tokeniser for the catalog short-circuit (best_sample_query). Keeps the
    template words _content_words() strips, because those are exactly what
    distinguish one sample-query TYPE from another for the SAME table
    (count vs group_by vs distinct ...). Strips only true filler.
    """
    return {w for w in re.findall(r"[a-z0-9]+", (text or "").lower()) if w not in _CATALOG_STOP}


def _best_sample_query_overlap(query_words: set[str], sample_queries: list) -> float:
    """Shared scoring logic: highest Jaccard overlap between query_words
    and any of a table's stored sample_queries' question text."""
    best = 0.0
    for sq in sample_queries or []:
        if not isinstance(sq, dict) or not sq.get("question"):
            continue
        # v3: a stale collection can still hold the negative families.
        # Their questions ("Delete all X records added last month", "Who
        # last modified each X?") must never boost or rescue a table:
        # they describe what the table CANNOT answer.
        if query_class(sq) != POSITIVE:
            continue
        sq_words = _content_words(sq["question"])
        if not sq_words:
            continue
        overlap = len(query_words & sq_words) / len(query_words | sq_words)
        best = max(best, overlap)
    return best


class SchemaRAG:
    """
    Retrieves the most relevant schemas from Qdrant.

    Pipeline:
        query
          â†“
        expansion
          â†“
        multi-search
          â†“
        RRF fusion
          â†“
        FK expansion
          â†“
        schema context
    """

    def __init__(
        self,
        client: QdrantClient,
        embedder: Embedder,
        collection: str,
        top_k: int = 7,
        candidate_limit: int = 15,
        enable_query_expansion: bool = True,
    ):
        self.client = client
        self.embedder = embedder
        self.collection = collection
        self.top_k = top_k
        self.candidate_limit = candidate_limit
        self.enable_query_expansion = enable_query_expansion

        self._table_cache: Optional[list[str]] = None
        self._payload_cache: Optional[dict[str, dict]] = None
        
        self.rated_rules = RatedRulesRAG(client, embedder)
        self.parent_pipeline = None


    #
    #
    #   Base function to optionally override to get more tables 
    #   at the beginning of retrieve().
    #       see retrieve()
    #
    def pre_retrieve_step(
        self,
        query: str,        
        **kwargs
        ) -> list[RetrievedTable]:
        return []


    #
    #
    #   Base function to optionally override to get more tables 
    #   at the end of retrieve().
    #       see retrieve()
    #
    def post_retrieve_step(
        self,
        query: str,        
        **kwargs
        ) -> list[RetrievedTable]:
        return []



    #
    #   Base function to optionally override to get more text 
    #   at the beginning of the context
    #   see build_schema()
    def pre_build_schema_step(
        self,
        tables: list[RetrievedTable],
        question: str = "",
        **kwargs
    ) -> List[str]:
        return []


    #
    #   Base function to optionally override to get more text
    #   at the end of the context
    #   see build_schema()
    def post_build_schema_step(
        self,
        tables: list[RetrievedTable],
        question: str = "",
        **kwargs
    ) -> List[str]:
        return []



    #
    #   set_parent_pipeline()
    #
    #   Sometimes it is useful to have access to the parent. 
    #   Use wisely. Currently for looking options in the request that influence the RAG
    #   
    #
    def set_parent_pipeline(self, pipe):
        self.parent_pipeline = pipe

    # ---------------------------------------------------------------------
    # Retrieval
    # ---------------------------------------------------------------------

    def _search(
        self,
        query: str,
        limit: int,
    ) -> list[tuple[str, dict, int, float]]:
        """
        Returns:
            [
                (table_name, payload, rank, score)
            ]
        """

        vector = self.embedder.embed(query)

        results = self.client.query_points(
            collection_name=self.collection,
            query=vector,
            query_filter=Filter(
                must=[
                FieldCondition(
                    key="category",
                    match=MatchValue(value="table")
                )   
            ]
        ),
            limit=limit,
            with_payload=True,
        )
        
        logger.warning(
            f"QDRANT_QUERY={query}"
            )
           
        logger.warning(
            f"QDRANT_HITS={[(p.payload.get('table'), round(float(p.score),4)) for p in results.points]}"
            )

        hits = []

        for rank, point in enumerate(results.points, start=1):
            payload = point.payload

            table_name = (
                payload.get("table")
                or payload.get("table_name")
                or ""
            )

            hits.append(
                (
                    table_name,
                    payload,
                    rank,
                    float(point.score),
                )
            )

        return hits

    # ---------------------------------------------------------------------

    def _expand_query(
        self,
        query: str,
    ) -> list[str]:
        """
        Optional query expansion.
        """

        if not self.enable_query_expansion:
            return [query]

        queries = [query]

        try:
            words = query.split()

            if len(words) > 1:
                queries.append(" ".join(reversed(words)))

            queries.append(
                query + " database schema"
            )

        except Exception:
            pass

        return list(dict.fromkeys(queries))

    # ---------------------------------------------------------------------

    def _rrf_merge(
        self,
        searches: list[list[tuple[str, dict, int, float]]],
    ) -> list[RetrievedTable]:
        """
        Reciprocal Rank Fusion.
        """

        rrf_scores = {}
        best_cosine = {}
        payloads = {}

        for result_set in searches:
            for table_name, payload, rank, cosine in result_set:

                rrf_scores[table_name] = (
                    rrf_scores.get(table_name, 0.0)
                    + (1.0 / (_RRF_K + rank))
                )

                best_cosine[table_name] = max(
                    best_cosine.get(table_name, 0.0),
                    cosine,
                )

                payloads[table_name] = payload

        merged = []

        for table_name, rrf_score in rrf_scores.items():

            cosine = best_cosine.get(table_name, 0.0)

            final_score = (
                0.7 * rrf_score
                + 0.3 * cosine
            )

            merged.append(
                RetrievedTable(
                    payload=payloads[table_name],
                    score=final_score,
                    cosine_score=cosine,
                )
            )

        merged.sort(
            key=lambda x: x.score,
            reverse=True,
        )

        return merged

    # ---------------------------------------------------------------------

    def _fk_expand(
        self,
        tables: list[RetrievedTable],
    ) -> list[RetrievedTable]:

        # Keep relationship expansion bounded.  A highly connected schema
        # can otherwise add hundreds of neighbours and create an oversized
        # LLM prompt, causing request timeouts.  Direct retrieval results
        # remain governed by self.top_k; this cap applies only to the extra
        # FK-related context.
        max_related_tables = max(20, self.top_k * 3)

        existing = {
            t.table_name
            for t in tables
        }

        neighbours = set()

        for table in tables:

            payload = table.payload

            for rel in payload.get(
                "relationships",
                [],
            ):
                target = rel.get("related_table")
                if target and target not in existing:
                    neighbours.add(target)

        if not neighbours:
            return tables

        neighbours = set(sorted(neighbours)[:max_related_tables])

        try:
            from qdrant_client.models import Filter, FieldCondition, MatchAny

            records, _ = self.client.scroll(
                collection_name=self.collection,
                scroll_filter=Filter(
                    must=[
                        FieldCondition(
                            key="table",
                            match=MatchAny(any=list(neighbours)),
                        )
                    ]
                ),
                limit=len(neighbours) + 5,
                with_payload=True,
            )

            existing = {t.table_name for t in tables}

            for record in records:
                payload = record.payload
                table_name = payload.get("table") or payload.get("table_name")
                if table_name and table_name not in existing:
                    tables.append(RetrievedTable(payload=payload, score=0.0))
                    existing.add(table_name)

        except Exception:
            pass

        return tables

    # ---------------------------------------------------------------------
    # Sample-query grounding boost (re-ranks vector-search candidates).
    # ---------------------------------------------------------------------
    @staticmethod
    def _sample_query_boost(query: str, tables: list[RetrievedTable]) -> list[RetrievedTable]:
        query_words = _content_words(query)
        if not query_words:
            return tables

        for t in tables:
            best_overlap = _best_sample_query_overlap(query_words, t.payload.get("sample_queries", []))
            if best_overlap >= 0.5:
                boosted = max(t.score, 0.90 + best_overlap * 0.09)
                t.score = boosted
                t.cosine_score = max(t.cosine_score, boosted)

        tables.sort(key=lambda t: t.score, reverse=True)
        return tables

    def _sample_query_rescue(self, query: str, exclude: set[str]) -> list[RetrievedTable]:
        """
        Pulls in tables the vector search missed ENTIRELY but that have a
        strong sample_query match (see original docstring history).
        """
        query_words = _content_words(query)
        if not query_words:
            return []

        payload_by_table = self._payload_by_table()
        rescued: list[RetrievedTable] = []

        for table_name, payload in payload_by_table.items():
            if table_name in exclude:
                continue
            best_overlap = _best_sample_query_overlap(query_words, payload.get("sample_queries", []))
            if best_overlap >= 0.5:
                score = 0.90 + best_overlap * 0.09
                rescued.append(RetrievedTable(payload=payload, score=score, cosine_score=score))

        return rescued

    def _table_name_anchor(self, query: str, exclude: set[str]) -> list[RetrievedTable]:
        """
        Tables whose EXACT name appears as a whole-word token in the query.

        sql_generator._apply_domain_synonyms() rewrites naturalised entity
        names to their real table token BEFORE retrieval ("Absolute Point"
        -> "abs_point"), so the query literally contains the target table
        name. Vector similarity on such a short token is unreliable and the
        sample_query boost drowns in shared template words, so match it
        deterministically and let retrieve() pin it. Word-boundary match,
        so 'act' does not fire inside 'activity'.
        """
        q = (query or "").lower()
        anchored: list[RetrievedTable] = []
        for table_name, payload in self._payload_by_table().items():
            if not table_name or table_name in exclude:
                continue
            if re.search(rf"\b{re.escape(table_name.lower())}\b", q):
                anchored.append(
                    RetrievedTable(payload=payload, score=0.99, cosine_score=0.99)
                )
        return anchored

    def _semantic_anchor(self, query: str, exclude: set[str]) -> list[RetrievedTable]:
        """Pin schema tables for high-signal domain intents.

        Vector similarity often ranks metric-definition tables above the raw
        holdings tables for questions such as "combat power of a unit over
        time".  These anchors are generic intent cues, not test-question
        names, and only add tables already present in the KB.
        """
        q = (query or "").lower()
        is_holdings = bool(re.search(r"\b(holding|holdings|combat power|stock|inventory|platform|platform holder|platform holders|artillery|weapon system|equipment)\b", q))
        is_fire = bool(re.search(r"\b(fire|firing|fratricide|direct-fire|indirect-fire)\b", q))
        if not (is_holdings or is_fire):
            return []
        # Explicit metric-result questions should keep their metric tables.
        if re.search(r"\b(metric results?|metrics results?)\b", q):
            return []
        wanted = set()
        if is_fire:
            wanted.update({"act", "act_event", "fire_event", "obj_item", "obj_item_stat", "obj_item_point_loc"})
        if is_holdings:
            wanted.update({"holding", "mat_type", "obj_item", "obj_type", "unit"})
        payloads = self._payload_by_table()
        return [
            RetrievedTable(payload=payloads[name], score=0.995, cosine_score=0.995)
            for name in wanted
            if name in payloads and name not in exclude
        ]

    def retrieve(
        self,
        query: str,        
        **kwargs
        ) -> list[RetrievedTable]:

        # if debug was specified, we return a list of messages
        # todo: Return these messages in streaming 
        schema_rag_retrieve_debug_msg = []
        debug =  kwargs.get("debug", False)
        debug_rval = kwargs.get("debug_rval", {} )


        #
        #   Overridable function
        #
        self.pre_retrieve_step( query, **kwargs )
        
                       
        # ── Layer 1: query expansion ──────────────────────────────────────────────
        expanded_queries = self._expand_query( query  )

        # â”€â”€ Layer 2: vector search (multi-query) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        searches = [
            self._search(q, self.candidate_limit)
            for q in expanded_queries
        ]


        # Responsable du bug        
        logger.warning(
            f"EXPANDED_QUERIES={expanded_queries}"
        )
        
        merged = self._rrf_merge(searches)
        
        logger.warning(
            f"AFTER_RRF={[t.table_name for t in merged[:15]]}"
            )
        
        for i, search in enumerate(searches):
            logger.warning(
                f"SEARCH_{i}={[r[0] for r in search[:10]]}"
            )
        

        # Sample-query grounding boost, before the top_k cut.
        merged = self._sample_query_boost(query, merged)
        
        logger.warning(
        f"AFTER_SAMPLE_BOOST={[t.table_name for t in merged[:15]]}"
        )


        # Rescue tables the vector search missed ENTIRELY.
        existing_names = {t.table_name for t in merged}
        rescued = self._sample_query_rescue(query, existing_names)
        
        logger.warning(
            f"AFTER_RESCUE={[t.table_name for t in merged[:15]]}"
            )
        
        if rescued:
            merged = merged + rescued
            merged.sort(key=lambda t: t.score, reverse=True)

        # After _apply_domain_synonyms rewrites a naturalised entity name to
        # its real table token ("Absolute Point" -> "abs_point"), the query
        # literally names the target table. Match it deterministically and pin.
        existing_names = {t.table_name for t in merged}
        anchored = self._table_name_anchor(query, existing_names)
        if anchored:
            merged = merged + anchored
            merged.sort(key=lambda t: t.score, reverse=True)
            
        logger.warning(f"AFTER_ANCHOR={[t.table_name for t in merged[:15]]}"
        )
        anchored_names = {t.table_name for t in anchored}

        semantic = self._semantic_anchor(query, existing_names | anchored_names)
        if semantic:
            merged = merged + semantic
            merged.sort(key=lambda t: t.score, reverse=True)
        semantic_names = {t.table_name for t in semantic}

        # Pin near-exact sample_query matches (top 2) BEFORE any truncation.
        pinned_candidates = sorted(
            (t for t in merged if t.score >= 0.9),
            key=lambda t: t.score,
            reverse=True,
        )
        pinned = {t.table_name: t for t in pinned_candidates[:2]}

        # Exact table-name anchors are the strongest signal -- always pin them,
        # bypassing the top-2 cap, so top_k / FK / reranker can never drop the
        # table the user literally named.
        for t in merged:
            if t.table_name in anchored_names:
                pinned[t.table_name] = t
            if t.table_name in semantic_names:
                pinned[t.table_name] = t

        # initial pruning before graph expansion
        merged = merged[: self.top_k]
        
        logger.warning(
            f"AFTER_TOPK={[t.table_name for t in merged]}"
            )

        merged = self._fk_expand(merged)
        
        logger.warning(
            f"AFTER_FK_EXPAND={[t.table_name for t in merged[:20]]}"
            )

        try:
            if settings.use_reranker:
                from    RAG.reranker import rerank_tables
                
                logger.warning(
                    f"BEFORE_RERANK={[t.table_name for t in merged[:20]]}"
                )

                merged = rerank_tables(
                    query,
                    merged,
                    top_k=self.top_k,
                )
                
                logger.warning(f"AFTER_RERANK={[t.table_name for t in merged]}")
                
            else:
                merged = merged[: self.top_k]

        except Exception:
            # fail-safe fallback (never break retrieval)
            merged = merged[: self.top_k]

        # Re-inject any pinned (near-exact sample match OR exact table-name
        # anchor) the reranker/top_k dropped.
        missing_pinned = [t for name, t in pinned.items() if name not in {m.table_name for m in merged}]
        if missing_pinned:
            merged = merged + missing_pinned

        # Preserve schema-supported relationship/bridge tables in the final
        # context after all top_k/reranker pruning has completed.
        merged = self._fk_expand(merged)


        self.post_retrieve_step( query, **kwargs )

        return merged

    # ---------------------------------------------------------------------
    # Catalog short-circuit helper
    #
    # Returns the single strongest sample_query match for `query` across
    # EVERY table (table, question, sql, overlap), or None. Lets the
    # pipeline answer a known catalog question with its curated gold SQL
    # instead of regenerating it. Uses _catalog_words() (keeps the template
    # words that distinguish count vs group_by vs distinct for the SAME
    # table). Deterministic, one cached scroll.
    # ---------------------------------------------------------------------

    def best_sample_query(self, query: str, min_overlap: float = 0.7) -> Optional[dict]:
        query_words = _catalog_words(query)
        if not query_words:
            return None

        best = None
        for table_name, payload in self._payload_by_table().items():
            for sq in payload.get("sample_queries", []) or []:
                if not isinstance(sq, dict) or not sq.get("question") or not sq.get("sql"):
                    continue
                # v3 HARD GATE. Whatever this function returns is executed
                # verbatim by the pipeline. The enriched KB contains, per
                # table, a question phrased exactly like a user's whose SQL
                # is invalid on purpose, and one whose SQL is a real DELETE.
                # pipeline.py checks this again on its side; the two guards
                # are deliberately redundant because the cost of a miss is
                # a write against production data.
                if query_class(sq) != POSITIVE or not is_readonly_select(sq["sql"]):
                    continue
                sq_words = _catalog_words(sq["question"])
                if not sq_words:
                    continue
                overlap = len(query_words & sq_words) / len(query_words | sq_words)
                if best is None or overlap > best["overlap"]:
                    best = {
                        "table": table_name,
                        "question": sq["question"],
                        "sql": sq["sql"],
                        "kind": sq.get("kind", ""),
                        "level": sq.get("level", ""),
                        "expected_outcome": sq.get("expected_outcome", "rows"),
                        "overlap": overlap,
                    }
        if best and best["overlap"] >= min_overlap:
            return best
        return None

    # ---------------------------------------------------------------------
    # Answerable-question suggestions (NEW in v3)
    #
    # pipeline.py has been calling self.schema_rag.suggest_questions(...)
    # on its failure path since the "turn a dead-end into a redirection"
    # feature was added -- but the method never existed on this class, so
    # the call raised AttributeError inside a bare `except Exception: pass`
    # and the user got an empty suggestion list every single time. It is
    # implemented here, and the enriched KB is what makes it worth having:
    # the business queries carry a `business_need`, so the suggestions are
    # decision-oriented rather than a list of SELECT * variants.
    # ---------------------------------------------------------------------

    def suggest_questions(
        self,
        tables: list[str],
        per_table: int = 2,
        exclude: str = "",
        prefer_business: bool = True,
    ) -> list[dict]:
        """Questions these tables are GUARANTEED to be able to answer.

        Only POSITIVE queries are ever proposed: an "empty result" or
        "invalid" entry would make the promise false. Business examples
        come first when available -- a user who just failed to get an
        answer is better served by "What proportion of X records are
        missing their Y?" than by "Show me some examples of X".
        """
        excl = re.sub(r"[^a-z0-9 ]", "", (exclude or "").lower()).strip()
        out: list[dict] = []
        seen: set[str] = set()

        for table in tables or []:
            if not table:
                continue
            picked: list[dict] = []
            try:
                if prefer_business:
                    picked.extend(get_business_examples(table, limit=per_table))
                if len(picked) < per_table:
                    picked.extend(get_sample_queries(table, max_pairs=per_table * 2))
            except Exception as e:
                print(f"suggest_questions({table}) failed: {e}")
                continue

            kept = 0
            for item in picked:
                q = (item.get("question") or "").strip()
                key = re.sub(r"[^a-z0-9 ]", "", q.lower()).strip()
                if not q or not key or key in seen or key == excl:
                    continue
                seen.add(key)
                out.append({
                    "question": q,
                    "table": table,
                    "why": item.get("business_need", ""),
                    "kind": item.get("kind", ""),
                })
                kept += 1
                if kept >= per_table:
                    break
        return out

    # ---------------------------------------------------------------------
    # Lexical fallback â€” for schema-exploration questions.
    # ---------------------------------------------------------------------

    def _extract_keywords(self, query: str) -> list[str]:
        words = re.findall(r"[a-zA-Z]{3,}", query.lower())
        return [w for w in words if w not in _STOPWORDS]

    def _payload_by_table(self) -> dict[str, dict]:
        """
        Cached lookup of table_name -> payload, built from a full scroll.
        """

        if self._payload_cache is not None:
            return self._payload_cache

        records, _ = self.client.scroll(
            collection_name=self.collection,
            limit=500,
            with_payload=True,
        )

        cache: dict[str, dict] = {}
        for r in records:
            if not r.payload:
                continue
            name = r.payload.get("table") or r.payload.get("table_name") or ""
            if name:
                cache[name] = r.payload

        self._payload_cache = cache
        return cache

    def all_table_columns(self) -> dict[str, set[str]]:
        """
        {lowercased table name -> set of lowercased column names}, from the
        same cached full scroll as _payload_by_table(). Used by static_check
        to reject hallucinated COLUMN names before the EXPLAIN round-trip.
        """
        result: dict[str, set[str]] = {}
        for name, payload in self._payload_by_table().items():
            cols = payload.get("columns") or []
            col_names = set()
            for c in cols:
                if isinstance(c, dict) and c.get("name"):
                    col_names.add(str(c["name"]).lower())
                elif isinstance(c, str):
                    col_names.add(c.lower())
            if col_names:
                result[name.lower()] = col_names
        return result

    def _lexical_matches(
        self,
        query: str,
        exclude: set[str],
    ) -> list[RetrievedTable]:
        """
        Find tables whose name contains a keyword extracted from the
        question, as a substring. Pure string matching, fixed low score.
        """

        keywords = self._extract_keywords(query)
        if not keywords:
            return []

        payload_by_table = self._payload_by_table()

        matches = []
        for table_name, payload in payload_by_table.items():
            if table_name in exclude:
                continue
            name_lower = table_name.lower()
            if any(kw in name_lower for kw in keywords):
                matches.append(
                    RetrievedTable(payload=payload, score=0.01, cosine_score=0.0)
                )

        return matches

    def retrieve_for_exploration(
        self,
        query: str,
        top_k: int = 20,
        min_cosine_score: float = 0.25,
    ) -> list[RetrievedTable]:
        """
        Wider, more permissive retrieval for "what tables relate to X"
        questions. Vector pipeline (wider top_k, cosine-filtered) + lexical
        fallback. Not used for SQL generation.
        """

        original_top_k = self.top_k
        try:
            self.top_k = max(top_k, original_top_k)
            vector_results = self.retrieve(query)
        finally:
            self.top_k = original_top_k

        vector_results = [
            t for t in vector_results
            if t.cosine_score >= min_cosine_score or t.score == 0.0
        ]

        existing_names = {t.table_name for t in vector_results}
        lexical_results = self._lexical_matches(query, exclude=existing_names)

        return vector_results + lexical_results

    # ---------------------------------------------------------------------
    # Context Builder
    # ---------------------------------------------------------------------

    def build_schema_context(
        self,
        tables: list[RetrievedTable],
        question: str = "",
        **kwargs
    ) -> str:
        """Build the DDL context sent to the LLM.

        v3: `question` is optional and threaded down to build_ddl_with_kb(),
        which uses it to pick the few-shot examples whose KIND answers that
        shape ("how many X per Y" -> group_by_enum / having / share_of_total)
        instead of a fixed level-balanced sample. Same prompt budget, far
        higher relevance. Omitting it reproduces the previous behaviour
        exactly, so existing callers are unaffected.
        """

        #
        #   overridable function 
        #
        self.pre_build_schema_step( tables, question, **kwargs )

        ddl_sections = []

        all_rules = set()

        join_hints = []
        seen_join_on: set[str] = set()
        
        logger.info(
            f"BUILD_SCHEMA_CONTEXT: received {len(tables)} tables"
        )
        

        for table in tables[:10]:

            logger.info(
                "BUILD_SCHEMA_CONTEXT: "
                f"{table.table_name} "
                f"score={table.score:.4f}"
            )


        for table in tables:

            payload = table.payload

            table_name = (
                payload.get("table")
                or payload.get("table_name")
                or ""
            )

            columns = payload.get(
                "columns",
                [],
            )

            relationships = payload.get(
                "relationships",
                [],
            )

            ddl = build_ddl_with_kb(
                table_name,
                columns,
                question=question,
            )

            ddl_sections.append(
                (
                    f"-- Relevance: "
                    f"{table.score:.4f}\n"
                    f"{ddl}"
                )
            )

            all_rules.update(
                extract_business_rules(
                    table_name
                )
            )

            # Include curated production-KB guidance in the runtime context,
            # not only in the vector payload. This lets SQL generation use
            # semantic rules and query patterns after retrieval.
            for rule in payload.get("reasoning_rules", []) or []:
                if isinstance(rule, dict) and rule.get("guidance"):
                    all_rules.add(str(rule["guidance"]))
            semantic = payload.get("semantic") or {}
            if isinstance(semantic, dict) and semantic.get("purpose"):
                all_rules.add(f"Semantic purpose of {table_name}: {semantic['purpose']}")
            for pattern in payload.get("query_patterns", []) or []:
                if not isinstance(pattern, dict):
                    continue
                intent = pattern.get("intent")
                tables_needed = pattern.get("required_tables") or []
                notes = pattern.get("notes")
                if intent:
                    line = f"Query pattern {intent}: required tables {', '.join(map(str, tables_needed))}."
                    if notes:
                        line += f" {notes}"
                    all_rules.add(line)

            for rel in relationships:
                remote_table = rel.get("related_table")
                join_on = rel.get("join_on")
                if not remote_table or not join_on or join_on in seen_join_on:
                    continue

                if not _validate_join_on(table_name, rel):
                    logger.warning(
                        f"join_on mismatch for {table_name} relationship "
                        f"{rel.get('name', '?')!r}: stored join_on={join_on!r} "
                        f"does not match own_column={rel.get('own_column')!r}/"
                        f"related_column={rel.get('related_column')!r} -- "
                        f"KB data may need regenerating for this relationship."
                    )

                seen_join_on.add(join_on)
                hint = f"JOIN {remote_table} ON {join_on}"
                rel_type = rel.get("type", "")
                cardinality = rel.get("cardinality", "")
                if rel_type or cardinality:
                    hint += f"  -- {rel_type}, {cardinality}"
                join_hints.append(hint)

        result = [
            "-- =====================================================",
            "-- Retrieved Schema Context",
            "-- =====================================================",
            "",
            *ddl_sections,
        ]

        if all_rules:

            result.append("")
            result.append(
                "-- Business Rules"
            )

            for rule in sorted(all_rules):
                result.append(
                    f"-- {rule}"
                )

        if join_hints:

            result.append("")
            result.append(
                "-- Suggested JOINs"
            )

            for hint in sorted(
                set(join_hints)
            ):
                result.append(
                    f"-- {hint}"
                )


        # 
        #  overridable function
        #
        result.extend( self.post_build_schema_step( tables, question, **kwargs ) )


        rendered = "\n".join(result)

        # Codestral is configured with a 32K-token context window.  Keep a
        # conservative character budget for the complete schema block so the
        # system prompt, plan, question, and generated response still fit.
        # The limit is configurable for larger models and prevents Ollama
        # HTTP 400 errors caused by oversized requests.
        # 45k characters leaves headroom for the system prompt, planning
        # summary, question, and generated response within a 32k-token model
        # context.  Override with RAG_MAX_SCHEMA_CONTEXT_CHARS when using a
        # model with a larger context window.
        max_context_chars = int(os.getenv("RAG_MAX_SCHEMA_CONTEXT_CHARS", "45000"))
        if len(rendered) > max_context_chars:
            logger.warning(
                "Schema context truncated from %d to %d characters",
                len(rendered), max_context_chars,
            )
            rendered = (
                rendered[:max_context_chars]
                + "\n-- Schema context truncated to fit the model context window."
            )

        return rendered

    # ---------------------------------------------------------------------

    def all_table_names(
        self,
    ) -> list[str]:

        if self._table_cache is not None:
            return self._table_cache

        records, _ = self.client.scroll(
            collection_name=self.collection,
            limit=500,
            with_payload=True,
        )

        self._table_cache = sorted(
            {
                (
                    r.payload.get("table")
                    or r.payload.get(
                        "table_name",
                        "",
                    )
                ).strip()
                for r in records
                if r.payload
            }
        )

        return self._table_cache
