"""
Enum-literal guard (v3.5) -- rejects SQL that filters an ENUM column with
a value that does not exist, BEFORE it reaches the database.

Why: observed in production (2026-07-28) -- the LLM generated
`WHERE mat_stat.cat_code = 'MAT'` although mat_stat.cat_code's enum is
('COMMEQST','MNESTA','NOS','UXOSTA','RADST'). MariaDB does NOT raise an
error for that comparison: it simply matches nothing. The query passed
static check, EXPLAIN and execution, and an EMPTY result was served as a
confident SUCCESS -- the worst failure class, invisible to every existing
guardrail (which validate tables and columns, never VALUES).

This module closes the gap symmetrically to the column check: parse the
SQL (sqlglot), find every comparison of a column against string
literal(s) (=, !=, <>, IN), resolve the column to its table (aliases
included), and verify the literal against the KB's allowed_values. A
violation produces an actionable message listing the REAL values (plus
closest matches), which the pipeline feeds back to the LLM for the next
attempt -- turning a silent wrong answer into a guided retry.

Fail-safe by construction: any parse/KB failure returns [] (no
violations) and the pipeline behaves exactly as before.

Place this file at agent/enum_guard.py.
"""

from __future__ import annotations

import difflib
from functools import lru_cache

import sqlglot
from sqlglot import exp

from RAG.knowledge_base import load_kb


@lru_cache(maxsize=1)
def _allowed_map() -> dict:
    """{(table, column) -> frozenset of allowed codes (uppercased)}."""
    out = {}
    try:
        kb = load_kb()
    except Exception:
        return out
    for table, entry in kb.items():
        for col, cd in (entry.get("columns") or {}).items():
            av = (cd or {}).get("allowed_values")
            if isinstance(av, dict) and av:
                codes = {str(k) for k in av}
            elif isinstance(av, list) and av:
                codes = {str(v) for v in av}
            else:
                continue
            out[(table.lower(), col.lower())] = frozenset(c.upper() for c in codes)
    return out


def _display_values(table: str, column: str, limit: int = 12) -> str:
    """'CODE=meaning' list for the feedback message (original casing)."""
    try:
        av = (load_kb().get(table, {}).get("columns", {})
              .get(column, {}) or {}).get("allowed_values") or {}
    except Exception:
        return ""
    if isinstance(av, dict):
        items = [f"{k}={v}" for k, v in list(av.items())[:limit]]
    else:
        items = [str(v) for v in list(av)[:limit]]
    more = ""
    try:
        n = len(av)
        if n > limit:
            more = f" (+{n - limit} more)"
    except Exception:
        pass
    return ", ".join(items) + more


def check_enum_literals(sql: str) -> list[str]:
    """Return violation messages for enum columns compared to non-values.

    Empty list = nothing wrong (or guard unavailable -- fail-safe).
    """
    amap = _allowed_map()
    if not amap or not (sql or "").strip():
        return []

    try:
        tree = sqlglot.parse_one(sql, dialect="mysql")
    except Exception:
        return []  # unparseable SQL is static_check's problem, not ours

    # alias -> real table name (alias defaults to the table name itself)
    aliases: dict[str, str] = {}
    for t in tree.find_all(exp.Table):
        real = (t.name or "").lower()
        if real:
            aliases[(t.alias or t.name).lower()] = real
    if not aliases:
        return []

    def candidate_tables(col: exp.Column) -> list[str]:
        qual = (col.table or "").lower()
        if qual:
            return [aliases.get(qual, qual)]
        return list(dict.fromkeys(aliases.values()))  # unqualified: any table in query

    def literals_of(node) -> list[str]:
        if isinstance(node, exp.Literal) and node.is_string:
            return [node.this]
        return []

    checks: list[tuple[exp.Column, list[str]]] = []

    for cmp_cls in (exp.EQ, exp.NEQ):
        for node in tree.find_all(cmp_cls):
            col = node.this if isinstance(node.this, exp.Column) else (
                node.expression if isinstance(node.expression, exp.Column) else None)
            other = node.expression if col is node.this else node.this
            lits = literals_of(other)
            if col is not None and lits:
                checks.append((col, lits))

    for node in tree.find_all(exp.In):
        if isinstance(node.this, exp.Column):
            lits = [l for e in (node.expressions or []) for l in literals_of(e)]
            if lits:
                checks.append((node.this, lits))

    errors: list[str] = []
    seen: set[tuple] = set()
    for col, lits in checks:
        col_name = (col.name or "").lower()
        tables = candidate_tables(col)
        enum_hits = [(t, amap[(t, col_name)]) for t in tables if (t, col_name) in amap]
        if not enum_hits:
            continue  # not an enum column we know about
        for lit in lits:
            up = str(lit).upper()
            # valid if the literal exists in ANY candidate table's enum
            # (unqualified columns can belong to several joined tables)
            if any(up in allowed for _t, allowed in enum_hits):
                continue
            t = enum_hits[0][0]
            key = (t, col_name, up)
            if key in seen:
                continue
            seen.add(key)
            near = difflib.get_close_matches(
                up, list(enum_hits[0][1]), n=3, cutoff=0.5)
            msg = (f"'{lit}' is not a valid value for {t}.{col_name}. "
                   f"Valid values: {_display_values(t, col_name)}.")
            if near:
                msg += f" Closest: {', '.join(near)}."
            msg += (" Use ONLY a listed value; if none matches the question's "
                    "intent, remove this filter or answer IMPOSSIBLE.")
            errors.append(msg)
    return errors