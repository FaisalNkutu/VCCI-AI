# agent/term_resolution.py

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass(slots=True)
class ResolutionCandidate:
    """
    A single schema or data match for a term.
    """

    table: str
    column: str

    value: Optional[str] = None

    source: str = ""

    confidence: float = 1.0


@dataclass(slots=True)
class TermResolution:
    """
    Unified resolution information for one important term.
    """

    term: str

    resolution_type: str

    candidates: list[ResolutionCandidate] = field(
        default_factory=list
    )

    confidence: float = 0.0

    lookup_required: bool = False


@dataclass(slots=True)
class TemporalResolution:
    """
    Temporal meaning extracted from the query.
    """

    phrase: str

    category: str

    confidence: float = 1.0


@dataclass(slots=True)
class ResolutionBundle:
    """
    Final merged grounding output.
    """

    term_resolutions: list[TermResolution] = field(
        default_factory=list
    )

    temporal_resolutions: list[TemporalResolution] = field(
        default_factory=list
    )

    grounded_tables: set[str] = field(
        default_factory=set
    )

    grounded_columns: set[str] = field(
        default_factory=set
    )

    grounded_values: set[str] = field(
        default_factory=set
    )

    unresolved_terms: set[str] = field(
        default_factory=set
    )
    
    
def merge_resolution_candidate(
    bundle: ResolutionBundle,
    candidate: ResolutionCandidate
) -> None:

    bundle.grounded_tables.add(
        candidate.table
    )

    bundle.grounded_columns.add(
        f"{candidate.table}.{candidate.column}"
    )

    if candidate.value:

        bundle.grounded_values.add(
            candidate.value
        )
        
        
def build_resolution_bundle(
    resolutions: list[TermResolution]
) -> ResolutionBundle:

    bundle = ResolutionBundle(
        term_resolutions=resolutions
    )

    for resolution in resolutions:

        for candidate in resolution.candidates:

            merge_resolution_candidate(
                bundle,
                candidate
            )

    return bundle