import threading

import pymysql
import pymysql.cursors
import pymysql.err


class DatabaseConnectionError(Exception):
    """
    Raised by execute() when it fails due to a genuine connection-level
    issue (server down, connection dropped, ...), as opposed to a
    content/schema error in the SQL itself (unknown column/table,
    constraint violation, ...). Mirrors dry_run.DatabaseConnectionError --
    lets pipeline.py distinguish a self-correctable content problem from a
    genuine infrastructure failure worth tripping the circuit breaker
    over, instead of treating every execution error identically.
    """
    pass


# Error codes that genuinely indicate the connection itself is broken
# (dropped, timed out, server restarted mid-session, ...). Only these
# warrant discarding the cached connection and forcing a fresh reconnect
# on the next call. A syntax error or unknown-column error (ProgrammingError)
# says nothing about connection health and must NOT trigger a reconnect --
# doing so wastes a full TCP + MySQL auth handshake on the most common path
# in this pipeline: the LLM writes invalid SQL, gets error feedback, and
# retries (up to max_retries times per request, by design).
_CONNECTION_LOST_CODES = {
    2002,  # Can't connect through socket
    2003,  # Can't connect to server
    2006,  # MySQL server has gone away
    2013,  # Lost connection to MySQL server during query
}


def _is_connection_lost(exc: Exception) -> bool:
    if not isinstance(exc, (pymysql.err.OperationalError, pymysql.err.InterfaceError)):
        return False
    code = exc.args[0] if exc.args else None
    return code in _CONNECTION_LOST_CODES


class Executor:
    """
    Step 6 — Real query execution against MariaDB.
    Returns rows as list[dict] and caps at max_rows.
    Uses a thread-local persistent connection with auto-reconnect to avoid
    opening a new TCP connection on every request.
    """

    def __init__(self, db_params: dict):
        self._params = db_params
        # Per-instance threading.local(), not a shared module-level one
        # keyed by id(self). id() is the object's memory address in
        # CPython, which CAN be reused by a later, unrelated Executor
        # instance once the original is garbage-collected -- risking a
        # stale/foreign connection being picked up under a stale key. A
        # per-instance local avoids that class of bug entirely and is
        # simpler.
        self._local = threading.local()

    def _get_conn(self) -> pymysql.connections.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = pymysql.connect(**self._params, cursorclass=pymysql.cursors.DictCursor)
            self._local.conn = conn
        else:
            try:
                conn.ping(reconnect=True)
            except Exception:
                conn = pymysql.connect(**self._params, cursorclass=pymysql.cursors.DictCursor)
                self._local.conn = conn
        return conn

    def execute(self, sql: str, max_rows: int = 100) -> tuple[list[dict], str]:
        try:
            conn = self._get_conn()
            with conn.cursor() as cur:
                cur.execute(sql)
                rows = cur.fetchmany(max_rows)
            return [dict(r) for r in rows], ""
        except pymysql.Error as e:
            return [], f"Database execution failed: {e}"
        
    
       
