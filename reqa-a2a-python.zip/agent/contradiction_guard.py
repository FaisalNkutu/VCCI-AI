"""
Contradiction guard (v3.6) -- rejects SQL whose equality filters are
mutually exclusive, BEFORE it reaches the database.

Why: observed in production (2026-07-28) -- for the question "How did the
combat power of unit 1 IG BG HQ (obj_item ID: 1457) change...", the LLM
misparsed the unit designation "1 IG BG HQ" (leading digit extracted as a
numeric id) and generated:

    ... JOIN org o ON u.unit_id = o.org_id ...
    WHERE u.unit_id = 1 AND o.org_id = 1457 ...

The join makes unit_id and org_id EQUAL, so the two filters require
1 = 1457 -- impossible. MariaDB raises no error: the query executes and
returns 0 rows, served as a confident SUCCESS. Like the enum-guard case,
this failure class is invisible to every structural check (tables,
columns, syntax all valid).

This module detects it deterministically and GENERALLY:

  1. parse the SQL with sqlglot;
  2. per SELECT scope, collect every equality that is unconditionally
     required (i.e. reachable from WHERE / JOIN ON through AND only --
     equalities under OR are alternatives, not requirements);
  3. build equivalence classes of columns with union-find over
     column = column equalities (JOIN ON and WHERE alike);
  4. bind constants to classes from column = literal equalities;
  5. two DIFFERENT constants bound to the same class -> contradiction,
     with an actionable message naming both filters and the join chain
     that links them. Also caught: col = X together with col <> X.

The pipeline feeds the message back to the LLM for the next attempt --
turning a silent empty answer into a guided retry.

Fail-safe by construction: any parse/analysis failure returns [] and the
pipeline behaves exactly as before.

Place this file at agent/contradiction_guard.py.
"""

from __future__ import annotations

from decimal import Decimal, InvalidOperation

import sqlglot
from sqlglot import exp


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _norm_const(node: exp.Expression):
    """Normalized comparable value for a literal, or None if not a constant.

    Numbers compare numerically (1 == 1.0); strings compare
    case-insensitively (MariaDB's default collation is case-insensitive,
    so 'res' = 'RES' is NOT a contradiction).
    Returns (kind, value) so numbers never collide with strings.
    """
    if isinstance(node, exp.Neg) and isinstance(node.this, exp.Literal):
        inner = _norm_const(node.this)
        if inner and inner[0] == "num":
            return ("num", -inner[1])
        return None
    if not isinstance(node, exp.Literal):
        return None
    if node.is_string:
        return ("str", str(node.this).upper())
    try:
        return ("num", Decimal(str(node.this)))
    except (InvalidOperation, ValueError):
        return None


class _UnionFind:
    """Union-find with a remembered 'reason' edge list per merge (for messages)."""

    def __init__(self):
        self.parent: dict = {}
        self.edges: list[tuple] = []  # (key_a, key_b, "a.x = b.y")

    def find(self, k):
        self.parent.setdefault(k, k)
        while self.parent[k] != k:
            self.parent[k] = self.parent[self.parent[k]]  # path halving
            k = self.parent[k]
        return k

    def union(self, a, b, reason: str):
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.parent[ra] = rb
        self.edges.append((a, b, reason))

    def class_edges(self, k) -> list[str]:
        root = self.find(k)
        return [r for a, b, r in self.edges
                if self.find(a) == root and self.find(b) == root]


def _conjuncts(condition):
    """Yield the equality/inequality nodes that are UNCONDITIONALLY
    required by `condition`: descend through AND and parentheses only.

    Anything under OR / NOT / CASE / a nested SELECT is an alternative or
    has inverted semantics -- ignored (conservative: no false positives).
    """
    stack = [condition]
    while stack:
        node = stack.pop()
        if node is None:
            continue
        if isinstance(node, exp.And):
            stack.extend([node.this, node.expression])
        elif isinstance(node, exp.Paren):
            stack.append(node.this)
        elif isinstance(node, (exp.EQ, exp.NEQ)):
            yield node
        # OR, NOT, CASE, subqueries, other operators: stop descending.


def _analyze_select(select: exp.Select) -> list[str]:
    """Detect contradictory equality filters within ONE select scope."""
    # alias -> real table name (alias defaults to the table name itself)
    aliases: dict[str, str] = {}
    for t in select.find_all(exp.Table):
        real = (t.name or "").lower()
        if real:
            aliases[(t.alias or t.name).lower()] = real

    def col_key(col: exp.Column):
        """Stable identity for a column: (resolved_table, column_name)."""
        name = (col.name or "").lower()
        if not name:
            return None
        qual = (col.table or "").lower()
        return (aliases.get(qual, qual), name)

    def col_display(col: exp.Column) -> str:
        key = col_key(col)
        return f"{key[0]}.{key[1]}" if key and key[0] else (col.name or "?")

    # Collect the required conditions of THIS scope: its WHERE plus every
    # JOIN ... ON. Conditions inside nested subqueries belong to their own
    # scope and are analyzed separately by check_contradictions().
    conditions = []
    where = select.args.get("where")
    if where is not None:
        conditions.append(where.this)
    for join in select.args.get("joins") or []:
        on = join.args.get("on")
        if on is not None:
            conditions.append(on)

    uf = _UnionFind()
    # class root -> list of (display, normalized_value, raw_sql) for '=' bindings
    eq_bindings: dict = {}
    # class root -> list of (display, normalized_value, raw_sql) for '<>' bindings
    neq_bindings: dict = {}

    def classify(node):
        """Return ('cc', colA, colB) | ('cl', col, const_node) | None."""
        left, right = node.this, node.expression
        if isinstance(left, exp.Column) and isinstance(right, exp.Column):
            return ("cc", left, right)
        if isinstance(left, exp.Column) and _norm_const(right) is not None:
            return ("cl", left, right)
        if isinstance(right, exp.Column) and _norm_const(left) is not None:
            return ("cl", right, left)
        return None

    pairs = []   # deferred column=literal bindings (bind AFTER all unions)
    for cond in conditions:
        for node in _conjuncts(cond):
            kind = classify(node)
            if kind is None:
                continue
            if kind[0] == "cc":
                _, a, b = kind
                ka, kb = col_key(a), col_key(b)
                if ka and kb and isinstance(node, exp.EQ):
                    uf.union(ka, kb, f"{col_display(a)} = {col_display(b)}")
            else:
                _, col, const = kind
                key = col_key(col)
                if key is None:
                    continue
                pairs.append((isinstance(node, exp.EQ), key,
                              col_display(col), _norm_const(const),
                              const.sql(dialect="mysql")))

    for is_eq, key, display, value, raw in pairs:
        root = uf.find(key)
        target = eq_bindings if is_eq else neq_bindings
        target.setdefault(root, []).append((display, value, raw))

    errors: list[str] = []
    for root, bindings in eq_bindings.items():
        distinct = {}
        for display, value, raw in bindings:
            distinct.setdefault(value, (display, raw))
        if len(distinct) > 1:
            parts = [f"{d} = {r}" for d, r in distinct.values()]
            chain = uf.class_edges(root)
            msg = ("Mutually exclusive filters: " + " AND ".join(parts) +
                   " can never hold at the same time")
            if chain:
                msg += (" because the join condition(s) " +
                        " and ".join(sorted(set(chain))) +
                        " force these columns to be equal")
            msg += (". The query is guaranteed to return 0 rows. Keep ONLY "
                    "the filter the question actually specifies (an explicit "
                    "ID takes priority; a designation like '1 IG BG HQ' is a "
                    "NAME, never a numeric id) and remove the other.")
            errors.append(msg)
            continue
        # col = X together with col <> X in the same class.
        the_value = bindings[0][1]
        for display, value, raw in neq_bindings.get(root, []):
            if value == the_value:
                errors.append(
                    f"Mutually exclusive filters: {bindings[0][0]} = "
                    f"{bindings[0][2]} together with {display} <> {raw} can "
                    "never hold at the same time. The query is guaranteed to "
                    "return 0 rows. Remove one of the two filters.")
                break
    return errors


def check_contradictions(sql: str) -> list[str]:
    """Return messages for guaranteed-empty equality contradictions.

    Empty list = nothing wrong (or guard unavailable -- fail-safe).
    """
    if not (sql or "").strip():
        return []
    try:
        tree = sqlglot.parse_one(sql, dialect="mysql")
        errors: list[str] = []
        for select in tree.find_all(exp.Select):
            errors.extend(_analyze_select(select))
        # dedup, keep order
        return list(dict.fromkeys(errors))
    except Exception:
        return []  # unparseable SQL is static_check's problem, not ours