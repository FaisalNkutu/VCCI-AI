RELATIONSHIP_VERBS = {

    "use",
    "uses",
    "used",

    "contain",
    "contains",
    "contained",

    "belong",
    "belongs",

    "assign",
    "assigned",

    "participate",
    "participates",

    "locate",
    "located",

    "own",
    "owns",

    "support",
    "supports",

    "associate",
    "associated",

    "link",
    "linked",

    "attach",
    "attached"
}