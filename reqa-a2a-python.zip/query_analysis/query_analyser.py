from query_analysis.query_types import QueryType
from query_analysis.relationship_verbs import (
    RELATIONSHIP_VERBS
)
import re
import spacy
from .literal_resolver import (
    LiteralResolutionResult,
    LiteralResolver
)
from query_analysis.query_models import (
    QueryAnalysisResult
)
from query_analysis.entity_resolver import EntityResolver


class QueryAnalyzer:
    
    
    def __init__(self):

        self.nlp = spacy.load("en_core_web_sm")
        self.literal_resolver = LiteralResolver()
        self.entity_resolver = EntityResolver()
        

        
    def classify_query(self, doc) -> QueryType:

        relationship_verbs = [
            token.lemma_.lower()
            for token in doc
            if token.pos_ == "VERB"
            and token.lemma_.lower() in RELATIONSHIP_VERBS
        ]

        if relationship_verbs:
            return QueryType.RELATIONSHIP

        return QueryType.UNKNOWN
 

    def analyze(
        self,
        query: str
    ) -> QueryAnalysisResult:

        doc = self.nlp(query)

        literals = self.extract_literals(query)

        noun_chunks = self.extract_noun_chunks(doc)
        
        entity_resolutions = []

        for chunk in noun_chunks:

            resolution = self.entity_resolver.resolve(
                chunk
            )

            if resolution:
                entity_resolutions.append(
                    resolution
                )


        relationship_verbs = \
            self.extract_relationship_verbs(doc)

        query_type = self.classify_query(doc)

        literal_resolutions = []

        for literal in literals:

            literal_resolutions.append(
                self.literal_resolver.resolve(
                    literal
                )
            )

        return QueryAnalysisResult(
            original_query=query,

            query_type=query_type,

            confidence=1.0,

            literals=literals,

            literal_resolutions=literal_resolutions,

            noun_chunks=noun_chunks,

            business_concepts=noun_chunks,
            
            entity_resolutions=entity_resolutions,

            relationship_verbs=relationship_verbs
        )

    def extract_literals(self, query: str):
        
        literals = []

        patterns = [
            r'"([^"]+)"',
            r"'([^']+)'"
        ]

        for pattern in patterns:
            matches = re.findall(pattern, query)
            literals.extend(matches)

        return list(set(literals))

    def extract_noun_chunks(self, doc):
       
        chunks = []

        for chunk in doc.noun_chunks:
            text = chunk.text.strip()

            if text:
                chunks.append(text)

        return chunks

    def extract_relationship_verbs(self, doc):
      
        relationship_verbs = []

        for token in doc:

            if (
                token.pos_ == "VERB"
                and token.lemma_.lower()
                in RELATIONSHIP_VERBS
            ):
                relationship_verbs.append(
                    token.lemma_.lower()
                )

        return list(set(relationship_verbs))
            