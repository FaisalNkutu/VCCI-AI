# agent/relationship_validator.py

from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict
import logging
from RAG.knowledge_base import (
    load_kb,
    get_relationships
)

from RAG.knowledge_base import get_table_kb


logger = logging.getLogger(__name__)

CORRELATION_KEYWORDS = [
    "using",
    "uses",
    "used by",
    "belongs to",
    "assigned to",
    "equipped with",
    "located in",
    "participating in",
    "part of",
    "owned by",
    "within",
]



class RelationshipStatus(str, Enum):

    FULLY_CONNECTED = "FULLY_CONNECTED"

    PARTIALLY_CONNECTED = "PARTIALLY_CONNECTED"

    LOGICAL_AND = "LOGICAL_AND"

    IMPOSSIBLE = "IMPOSSIBLE"

    LOGICAL_INDEPENDENT = "LOGICAL_INDEPENDENT"

    UNSATISFIABLE_CORRELATION = "UNSATISFIABLE_CORRELATION"
    
    


"""
class RelationshipStatus(str, Enum):
    
    FULLY_CONNECTED = "FULLY_CONNECTED"

    PARTIALLY_CONNECTED = "PARTIALLY_CONNECTED"

    LOGICAL_INDEPENDENT = "LOGICAL_INDEPENDENT"

    UNSATISFIABLE_CORRELATION = "UNSATISFIABLE_CORRELATION"
    
    LOGICAL_AND = "LOGICAL_AND"
    
    IMPOSSIBLE = "IMPOSSIBLE"
    
    """



    

from dataclasses import dataclass


@dataclass(frozen=True)
class FKPath:

    table: str

    related_table: str

    own_column: str

    related_column: str

    role: str

    relationship_name: str

    cardinality: str

    join_on: str

    source: str = "RAG"
    

from collections import defaultdict


class FKGraph:

    def __init__(self):

        self.paths = []

        self.adj = defaultdict(set)

    def add_path(self, fk):

        self.paths.append(fk)

        self.adj[fk.table].add(
            fk.related_table
        )

        self.adj[fk.related_table].add(
            fk.table
        )
        
        
from RAG.knowledge_base import load_kb


def build_fk_graph():

    kb = load_kb()

    graph = FKGraph()

    for table_name, entry in kb.items():

        for rel in entry.get(
            "relationships",
            []
        ):

            fk = FKPath(

                table=table_name,

                related_table=
                    rel["related_table"],

                own_column=
                    rel["own_column"],

                related_column=
                    rel["related_column"],

                role=
                    rel["role"],

                relationship_name=
                    rel["name"],

                cardinality=
                    rel["cardinality"],

                join_on=
                    rel.get("join_on", ""),

                source="RAG"
            )

            graph.add_path(fk)

    return graph

@dataclass
class ConnectedComponent:

    tables: set[str]

    fk_paths: list[FKPath] = field(
        default_factory=list
    )
    
    
@dataclass
class RelationshipValidationResult:

    status: RelationshipStatus

    connected_components: list[
        ConnectedComponent
    ] = field(
        default_factory=list
    )

    logical_groups: list[
        ConnectedComponent
    ] = field(
        default_factory=list
    )

    reason: str = ""
    

    
    
class RelationshipValidator:

    def __init__(self):

        self.fk_graph = build_fk_graph()
        
    

    def validate(
        self,
        mandatory_tables: set[str]
    ) -> RelationshipValidationResult:
        
        logger.warning(
            "BREAKPOINT_REACHED_VALIDATE"
        )
                
        
        logger.warning("==================================================")
        
        logger.warning(
            "RELATIONSHIP_VALIDATOR_CALLED"
        )

        logger.warning(
            "VALIDATOR_INPUT=%s",
            sorted(mandatory_tables)
        )
        
        logger.warning(
            "RELATIONSHIP_VALIDATOR_CALLED"
        )
        
        logger.warning(
            "MANDATORY_TABLES=%s",
            sorted(mandatory_tables)
        )

        
        
        logger.warning(
            "MANDATORY_TABLES=%s",
            sorted(mandatory_tables)
        )
        
        logger.warning(
            "BREAKPOINT_TEST_VALIDATE"
        )

        components = self.find_connected_components(
            mandatory_tables
        )
        
        print("BREAKPOINT_TEST")
        
        for comp in components:
            logger.warning(
                "COMPONENT_TABLES=%s",
                sorted(comp.tables)
            )

            logger.warning(
                "COMPONENT_FK_COUNT=%s",
                len(comp.fk_paths)
            )

        logger.warning(
            "CONNECTED_COMPONENTS=%s",
            [
                sorted(c.tables)
                for c in components
            ]
        )

        if len(components) == 1:

            total_fk_paths = sum(
                len(c.fk_paths)
                for c in components
            )

            logger.warning(
                "TOTAL_COMPONENT_FK_PATHS=%s",
                total_fk_paths
            )

            if total_fk_paths == 0:

                logger.warning(
                    "INVALID_FULLY_CONNECTED_NO_FK"
                )

                return RelationshipValidationResult(
                    status=RelationshipStatus.IMPOSSIBLE,
                    connected_components=components,
                    reason="Connected graph without validated FK path."
                )

            result = RelationshipValidationResult(
                status=RelationshipStatus.FULLY_CONNECTED,
                connected_components=components
            )

            return result
        
        
        if any(
            len(c.tables) > 1
                    for c in components
            ):
        
            result = RelationshipValidationResult(
                    status=RelationshipStatus.PARTIALLY_CONNECTED,
                    connected_components=components
                )
        
            logger.warning(
                "PARTIAL_COMPONENTS=%s",
                    [
                        sorted(c.tables)
                        for c in components
                        ]
                    )
        
            logger.warning(
                "RELATIONSHIP_STATUS=%s",
                result.status
                )
        
            return result
        
        

        if self._validate_logical_and(
            components
        ):

            result = RelationshipValidationResult(
                status=RelationshipStatus.LOGICAL_AND,
                connected_components=components,
                logical_groups=components
            )

            logger.warning(
                "LOGICAL_GROUPS=%s",
                [
                    sorted(c.tables)
                    for c in components
                ]
            )

            logger.warning(
                "RELATIONSHIP_STATUS=%s",
                result.status
            )

            return result
        
        
        

        

        result = RelationshipValidationResult(
            status=RelationshipStatus.IMPOSSIBLE,
            connected_components=components,
            reason=(
                "No FK path and no logical decomposition."
            )
        )

        logger.warning(
            "RELATIONSHIP_STATUS=%s",
            result.status
        )

        return result

        
    
    def find_connected_components(
        self,
        required_tables: set[str]
    ):

        visited = set()
        components = []

        for start_table in required_tables:

            if start_table in visited:
                continue

            stack = [start_table]

            reachable_required_tables = set()

            traversed_tables = set()

            component_fk_paths = []

            local_seen_fk = set()

            while stack:

                current = stack.pop()

                if current in traversed_tables:
                    continue

                traversed_tables.add(current)

                if current in required_tables:
                    reachable_required_tables.add(current)

                for fk in self.fk_graph.paths:

                    if fk.table == current:
                        neighbour = fk.related_table

                    elif fk.related_table == current:
                        neighbour = fk.table

                    else:
                        continue

                    fk_key = (
                        fk.table,
                        fk.related_table,
                        fk.join_on
                    )

                    #
                    # Explorer le graphe complet
                    #
                    if neighbour not in traversed_tables:

                        stack.append(neighbour)

                        #
                        # Conserver uniquement
                        # les FK réellement utilisés
                        # pour la traversée
                        #
                        if fk_key not in local_seen_fk:

                            component_fk_paths.append(fk)

                            local_seen_fk.add(fk_key)

            visited.update(reachable_required_tables)

            if reachable_required_tables:

                components.append(
                    ConnectedComponent(
                        tables=reachable_required_tables,
                        fk_paths=component_fk_paths
                    )
                )

        return components
    
    
    def _validate_logical_and(
        self,
        components
    ):

        if len(components) < 2:
            return False

        for i in range(len(components)):

            for j in range(
                i + 1,
                len(components)
            ):

                overlap = self._logical_overlap(
                    components[i],
                    components[j]
                )

                if overlap > 0:

                    logger.warning(
                        "LOGICAL_AND_ACCEPTED"
                    )

                    return True

        logger.warning(
            "LOGICAL_AND_REJECTED"
        )

        return False
    
    
    def build_verified_fk_graph(self):

        kb = load_kb()

        graph = FKGraph()

        for table_name in kb:

            for rel in get_relationships(table_name):

                fk = FKPath(

                    table=table_name,

                    related_table=rel["related_table"],

                    own_column=rel["own_column"],

                    related_column=rel["related_column"],

                    role=rel["role"],

                    relationship_name=rel["name"],

                    cardinality=rel["cardinality"],

                    join_on=rel["join_on"],

                    source="RAG"
                )

                graph.add_path(fk)

        return graph
    
    
    def _component_business_signature(
        self,
        component: ConnectedComponent
    ) -> set[str]:
        
        signature = set()

        for table in component.tables:

            kb = get_table_kb(table)

            signature.add(table.lower())

            label = kb.get(
                "label",
                ""
            )

            if label:
                signature.update(
                    label.lower().split()
                )

            description = kb.get(
                "description",
                ""
            )

            if description:
                signature.update(
                    description.lower().split()
                )

            for keyword in kb.get(
                "keywords",
                []
            ):
                signature.add(
                    keyword.lower()
                )

            domain = kb.get(
                "domain",
                []
            )

            if isinstance(domain, list):

                for item in domain:

                    signature.update(
                        str(item).lower().split()
                    )
                    
        logger.warning(
            "COMPONENT_SIGNATURE=%s",
            sorted(signature)
        )

        return signature
    
    
    def _logical_overlap(
        self,
        component_a,
        component_b
    ):

        sig_a = self._component_business_signature(
            component_a
        )

        sig_b = self._component_business_signature(
            component_b
        )

        overlap = len(
            sig_a.intersection(
                sig_b
            )
        )

        logger.warning(
            "OVERLAP_BETWEEN=%s <-> %s = %s",
            sorted(component_a.tables),
            sorted(component_b.tables),
            overlap
        )

        return overlap
    
    def build_relationship_context(
        self,
        result: RelationshipValidationResult
    ) -> str:

        lines = []

        lines.append("=" * 50)
        lines.append("RELATIONSHIP VALIDATION")
        lines.append("=" * 50)

        lines.append("")
        lines.append(f"Status: {result.status}")

        lines.append("")
        lines.append("Connected Components:")

        for idx, component in enumerate(
            result.connected_components,
            start=1
        ):

            lines.append("")
            lines.append(
                f"Component {idx}:"
            )

            for table in sorted(
                component.tables
            ):
                lines.append(
                    f"    {table}"
                )

        lines.append("")
        lines.append(
            "IMPORTANT:"
        )

        lines.append(
            "Only use validated tables."
        )

        lines.append(
            "Do not invent joins."
        )

        lines.append(
            "Do not invent foreign keys."
        )

        return "\n".join(lines)
    
    
    
    def _requires_correlation(
        self,
        question: str,
    ) -> bool:

        q = question.lower()

        return any(
            keyword in q
            for keyword in CORRELATION_KEYWORDS
        )
            
            
    