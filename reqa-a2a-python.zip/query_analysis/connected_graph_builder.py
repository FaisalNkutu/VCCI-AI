from __future__ import annotations

from collections import defaultdict, deque
from typing import Dict, List, Tuple

from query_analysis.connected_graph import (
    ConnectedGraph,
)


def _find_shortest_path(
    start_table: str,
    target_table: str,
    graph: Dict[str, List[Tuple[str, object]]],
):
    

    if start_table == target_table:
        return []

    queue = deque()
    queue.append((start_table, []))

    visited = {start_table}

    while queue:

        current_table, current_path = queue.popleft()

        for neighbour, fk_path in graph.get(current_table, []):

            if neighbour in visited:
                continue

            new_path = current_path + [fk_path]

            if neighbour == target_table:
                return new_path

            visited.add(neighbour)

            queue.append(
                (
                    neighbour,
                    new_path,
                )
            )

    return []


def build_query_specific_connected_graph(
    mandatory_tables,
    fk_paths,
) -> ConnectedGraph:
    

    connected_graph = ConnectedGraph()

    if not mandatory_tables:
        return connected_graph

    if len(mandatory_tables) == 1:
        connected_graph.nodes.add(
            mandatory_tables[0]
        )
        return connected_graph

    #
    # Construction du graphe FK
    #
    graph = defaultdict(list)

    for fk in fk_paths:

        graph[fk.table].append(
            (
                fk.related_table,
                fk,
            )
        )

        graph[fk.related_table].append(
            (
                fk.table,
                fk,
            )
        )

    
    anchor = mandatory_tables[0]

   
    for target_table in mandatory_tables[1:]:

        path = _find_shortest_path(
            start_table=anchor,
            target_table=target_table,
            graph=graph,
        )

        for fk in path:

            connected_graph.add_edge(
                from_table=fk.table,
               to_table=fk.related_table,
                join_condition=fk.join_on,
            )

    return connected_graph