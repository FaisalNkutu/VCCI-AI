# query_analysis/connected_graph.py

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Set


@dataclass(frozen=True)
class GraphEdge:
    

    from_table: str
    to_table: str
    join_condition: str


@dataclass
class ConnectedGraph:
   

    nodes: Set[str] = field(default_factory=set)
    edges: List[GraphEdge] = field(default_factory=list)

    def add_edge(
        self,
        from_table: str,
        to_table: str,
        join_condition: str,
    ) -> None:
        

        self.nodes.add(from_table)
        self.nodes.add(to_table)

        edge = GraphEdge(
            from_table=from_table,
            to_table=to_table,
            join_condition=join_condition,
        )

        if edge not in self.edges:
            self.edges.append(edge)

    def has_table(
        self,
        table_name: str,
    ) -> bool:
        return table_name in self.nodes

    def get_tables(self) -> List[str]:
        return sorted(self.nodes)

    def get_edges(self) -> List[GraphEdge]:
        return list(self.edges)

    def to_prompt_block(self) -> str:
        

        if not self.edges:
            return (
                "QUERY-SPECIFIC CONNECTED GRAPH\n"
                "==============================\n\n"
                "No connected graph available.\n"
            )

        lines = [
            "QUERY-SPECIFIC CONNECTED GRAPH",
            "==============================",
            "",
            "The validator has already computed",
            "the required connected graph.",
            "",
            "You MUST use only these joins.",
            "You MUST NOT skip intermediate tables.",
            "You MUST NOT directly join non-adjacent tables.",
            "",
            "Required joins:",
            "",
        ]

        for edge in self.edges:

            lines.extend(
                [
                    f"{edge.from_table}",
                    f"  -> {edge.to_table}",
                    f"     JOIN: {edge.join_condition}",
                    "",
                ]
            )

        return "\n".join(lines)

    def __len__(self) -> int:
        return len(self.nodes)
    
    def __bool__(self) -> bool:
        return bool(self.edges)
        
 