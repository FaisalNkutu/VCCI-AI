from agent.term_grounding import ground_terms

import re

from query_analysis.relationship_validator import (
    RelationshipValidator
)

from query_analysis.query_models import (
    QueryAnalysisResult,
    GroundingContext,
    EntityResolutionResult
)

import logging

logger = logging.getLogger(__name__)



class GroundingBuilder:

    def __init__(
        self,
        schema_rag=None
    ):

        self.schema_rag = schema_rag

        self.relationship_validator = (
            RelationshipValidator()
        )

   

    def build(
        self,
        analysis: QueryAnalysisResult
    ) -> GroundingContext:

        term_grounding = ground_terms(
            analysis.original_query
        )
        
       

        logger.info(
            f"TERM_GROUNDING={term_grounding}"
        )

        #
        # Temporary entity resolution
        #
        entity_resolutions = []

        for entity in term_grounding.get(
            "quoted_entities",
            []
        ):

            entity_resolutions.append(
                EntityResolutionResult(
                    term=entity,
                    matched_table="obj_item",
                    confidence=1.0,
                )
            )

        mandatory_tables = (
            self.derive_mandatory_tables(
                analysis,
                term_grounding
            )
        )

        #
        # Add entity tables
        #
        for resolution in entity_resolutions:

            if resolution.matched_table:
                
                #logger.warning(
                   # "MANDATORY_SOURCE table=%s",
                   # candidate.table_name
                #)

                mandatory_tables.append(
                    resolution.matched_table
                )

        mandatory_tables = sorted(
            set(mandatory_tables)
        )

        grounding = GroundingContext(
            query_type=analysis.query_type,

            literals=analysis.literals,

            literal_resolutions=
                analysis.literal_resolutions,

            entity_resolutions=
                entity_resolutions,

            mandatory_tables=
                mandatory_tables,

            grounded_terms=
                term_grounding.get(
                    "mapped",
                    {}
                ),

            quoted_entities=
                term_grounding.get(
                    "quoted_entities",
                    []
                ),

            unresolved_terms=
                term_grounding.get(
                    "unresolved",
                    []
                )
        )

        grounding.relationship_validation = (
            self.relationship_validator.validate(
                grounding
            )
        )

        return grounding
        
   

    def derive_mandatory_tables(
        self,
        analysis,
        term_grounding
    ):
        
        
        

        logger.warning(
            "ENTERING_DERIVE_MANDATORY_TABLES"
        )

        logger.warning(
            "ANALYSIS=%s",
            analysis
        )

        logger.warning(
            "TERM_GROUNDING=%s",
            term_grounding
        )

        mapped = term_grounding.get(
            "mapped",
            {}
        )

        logger.warning(
            "MAPPED=%s",
            mapped
        )

        tables = set()

        for term, refs in mapped.items():

            logger.warning(
                "TERM=%s REFS=%s",
                term,
                refs
            )

            for ref in refs:

                match = re.search(
                    r"([A-Za-z0-9_]+)\.",
                    ref
                )

                if match:

                    table_name = match.group(1)

                    logger.warning(
                        "ADDING_TABLE=%s FROM_REF=%s",
                        table_name,
                        ref
                    )

                    tables.add(
                        table_name
                    )

        logger.warning(
            "MANDATORY_TABLES=%s",
            sorted(tables)
        )

        return sorted(
            tables
        )




    