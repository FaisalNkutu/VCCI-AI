from __future__ import annotations

from dataclasses import dataclass, field

from query_analysis.query_types import QueryType
from query_analysis.literal_resolver import (
    LiteralResolutionResult
)


@dataclass
class EntityResolutionResult:

    term: str

    matched_table: str | None = None

    confidence: float = 0.0

    resolution_source: str | None = None
    


@dataclass
class RelationshipValidationResult:

    valid: bool

    relationship_type: str

    join_path: list[str] = field(
        default_factory=list
    )

    reason: str = ""    



@dataclass
class QueryAnalysisResult:

    original_query: str

    query_type: QueryType

    confidence: float

    literals: list[str] = field(default_factory=list)

    literal_resolutions: list[
        LiteralResolutionResult
    ] = field(
        default_factory=list
    )

    noun_chunks: list[str] = field(default_factory=list)

    business_concepts: list[str] = field(
        default_factory=list
    )

    relationship_verbs: list[str] = field(
        default_factory=list
    )

    entity_resolutions: list[
        EntityResolutionResult
    ] = field(
        default_factory=list
    )

@dataclass
class GroundingContext:

    query_type: QueryType

    literal_resolutions: list[LiteralResolutionResult] = field(
        default_factory=list
    )

    entity_resolutions: list[EntityResolutionResult] = field(
        default_factory=list
    )

    mandatory_tables: list[str] = field(
        default_factory=list
    )

    candidate_tables: list[str] = field(
        default_factory=list
    )

    literals: list[str] = field(
        default_factory=list
    )

    grounded_terms: dict = field(
        default_factory=dict
    )

    quoted_entities: list[str] = field(
        default_factory=list
    )

    unresolved_terms: list[str] = field(
        default_factory=list
    )
    
    relationship_validation: (
            RelationshipValidationResult | None
        ) = None
    

@dataclass
class ValidatedQueryContext:

    relationship_status: str

    mandatory_tables: list[str]

    fk_paths: list[str]

    predicate_groups: list[list[str]]

    entity_filters: list[str]

    relevant_columns: dict[str, list[str]]

    display_columns: dict[str, list[str]]
            
    
    
