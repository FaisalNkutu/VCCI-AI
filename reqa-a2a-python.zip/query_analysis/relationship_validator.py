# agent/relationship_validator.py

from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict
import logging
from RAG.knowledge_base import (
    load_kb,
    get_relationships
)

from collections import deque
from itertools import combinations

from RAG.knowledge_base import get_table_kb


logger = logging.getLogger(__name__)

CORRELATION_KEYWORDS = [
    "using",
    "uses",
    "used by",
    "belongs to",
    "assigned to",
    "equipped with",
    "located in",
    "participating in",
    "part of",
    "owned by",
    "within",
]



       
from dataclasses import dataclass

logger.error(
    "USING_RELATIONSHIP_VALIDATOR_PY"
)

@dataclass(frozen=True)
class FKPath:

    table: str

    related_table: str

    own_column: str

    related_column: str

    role: str

    relationship_name: str

    cardinality: str

    join_on: str

    source: str = "RAG"
    
    

@dataclass
class JoinPath:

    source_table: str

    target_table: str

    tables: list[str]

    fk_paths: list[FKPath]




class RelationshipStatus(str, Enum):

    FULLY_CONNECTED = "FULLY_CONNECTED"

    PARTIALLY_CONNECTED = "PARTIALLY_CONNECTED"

    LOGICAL_AND = "LOGICAL_AND"

    IMPOSSIBLE = "IMPOSSIBLE"

    LOGICAL_INDEPENDENT = "LOGICAL_INDEPENDENT"

    UNSATISFIABLE_CORRELATION = "UNSATISFIABLE_CORRELATION"
    
    

from dataclasses import dataclass


@dataclass(frozen=True)
class FKPath:

    table: str

    related_table: str

    own_column: str

    related_column: str

    role: str

    relationship_name: str

    cardinality: str

    join_on: str

    source: str = "RAG"
    

from collections import defaultdict


class FKGraph:

    def __init__(self):

        self.paths = []

        self.adj = defaultdict(set)

    def add_path(self, fk):

        self.paths.append(fk)

        self.adj[fk.table].add(
            fk.related_table
        )

        self.adj[fk.related_table].add(
            fk.table
        )
        
        
from RAG.knowledge_base import load_kb


def build_fk_graph():

    kb = load_kb()

    graph = FKGraph()

    for table_name, entry in kb.items():

        for rel in entry.get(
            "relationships",
            []
        ):

            fk = FKPath(

                table=table_name,

                related_table=
                    rel["related_table"],

                own_column=
                    rel["own_column"],

                related_column=
                    rel["related_column"],

                role=
                    rel["role"],

                relationship_name=
                    rel["name"],

                cardinality=
                    rel["cardinality"],

                join_on=
                    rel.get("join_on", ""),

                source="RAG"
            )

            graph.add_path(fk)

    return graph

@dataclass
class ConnectedComponent:

    tables: set[str]

    fk_paths: list[FKPath] = field(
        default_factory=list
    )
    
    
@dataclass
class RelationshipValidationResult:

    status: RelationshipStatus

    connected_components: list[
        ConnectedComponent
    ] = field(
        default_factory=list
    )

    logical_groups: list[
        ConnectedComponent
    ] = field(
        default_factory=list
    )

    reason: str = ""
    

    
    
class RelationshipValidator:

    def __init__(self):

        self.fk_graph = build_fk_graph()
        
            
    
    @staticmethod
    def build_recommended_join_chain(
        validated_context,
    ):

        chain = []

        for fk in validated_context.fk_paths:

            chain.append(
                {
                    "from": fk.table,
                    "to": fk.related_table,
                    "join": fk.join_on,
                }
            )

        return chain

        
    

    def validate(
        self,
        mandatory_tables: set[str]        # All list of tables from grounding
    ) -> RelationshipValidationResult:
        
        
        logger.error(
            "XXXXXXXXXXXXXXXX VALIDATE ENTERED XXXXXXXXXXXXXXXX"
        )
                
                
        
        logger.warning("==================================================")
        
       

       
        logger.warning(
            "MANDATORY_TABLES=%s",
            sorted(mandatory_tables)
        )

        
        
        logger.warning(
            "BREAKPOINT_TEST_VALIDATE"
        )
        
        
        
         ## temporary
        
        logger.error("ENTERING_BFS_TEST")

        path = "TEST"

        logger.error(
            "OBJ_ITEM_TO_WEAPON_TYPE_PATH=%s",
            path
        )

        logger.error("EXITING_BFS_TEST")
        
        ## temporary
        
        
        join_paths = self.extract_join_paths(
            mandatory_tables
        )
        
        validated_fk_paths = []

        for source, target, table_path in join_paths:

            validated_fk_paths.extend(
                self.tables_path_to_fk_paths(
                    table_path
                )
            )
            
        deduped_fk_paths = []
        seen = set()

        for fk in validated_fk_paths:

            key = (
                fk.table,
                fk.related_table,
                fk.join_on
            )

            if key not in seen:

                seen.add(key)
                deduped_fk_paths.append(fk)
                
        
        logger.warning(
            "VALIDATED_FK_COUNT=%s",
            len(deduped_fk_paths)
        )

        logger.warning(
            "VALIDATED_FK_PATHS=%s",
            [
                f"{fk.table}->{fk.related_table}"
                for fk in deduped_fk_paths
            ]
        )


        logger.warning(
            "JOIN_PATHS=%s",
            join_paths
        )

        for source, target, path in join_paths:
            logger.error(
                "PATH[%s->%s]=%s",
                source,
                target,
                " -> ".join(path)
            )

        components = self.find_connected_components(
            mandatory_tables
        )
        
        

        logger.warning(
            "JOIN_PATHS=%s",
            join_paths
        )
            
        

       
        
        
        print("BREAKPOINT_TEST")
        
        for comp in components:
            logger.warning(
                "COMPONENT_TABLES=%s",
                sorted(comp.tables)
            )

            logger.warning(
                "COMPONENT_FK_COUNT=%s",
                len(comp.fk_paths)
            )

        logger.warning(
            "CONNECTED_COMPONENTS=%s",
            [
                sorted(c.tables)
                for c in components
            ]
        )

        if len(components) == 1:

            total_fk_paths = sum(
                len(c.fk_paths)
                for c in components
            )

            logger.warning(
                "TOTAL_COMPONENT_FK_PATHS=%s",
                total_fk_paths
            )

            if total_fk_paths == 0:

                logger.warning(
                    "INVALID_FULLY_CONNECTED_NO_FK"
                )

                return RelationshipValidationResult(
                    status=RelationshipStatus.IMPOSSIBLE,
                    connected_components=components,
                    reason="Connected graph without validated FK path."
                )
                
            logger.error(
                "COMPONENT_FK_PATHS=%s",
                [
                    f"{fk.table}->{fk.related_table}"
                    for fk in comp.fk_paths
                ]
            )

            for comp in components:

                comp.fk_paths = deduped_fk_paths

            result = RelationshipValidationResult(
                status=RelationshipStatus.FULLY_CONNECTED,
                connected_components=components
            )
            
            logger.warning(
                "VALIDATOR_COMPONENT_COUNT=%s",
                len(result.connected_components)
            )

            for i, comp in enumerate(
                    result.connected_components):

                logger.warning(
                    "VALIDATOR_COMPONENT_%s_TABLES=%s",
                    i,
                    sorted(comp.tables)
                )

                logger.warning(
                    "VALIDATOR_COMPONENT_%s_FK_COUNT=%s",
                    i,
                    len(comp.fk_paths)
                )
                
            for comp in components:

                logger.error(
                    "COMPONENT_FK_PATHS=%s",
                    [
                        f"{fk.table}->{fk.related_table}"
                        for fk in comp.fk_paths
                    ]
                )

            return result
        
        
        if any(
            len(c.tables) > 1
                    for c in components
            ):
        
            for comp in components:

                comp.fk_paths = deduped_fk_paths

            result = RelationshipValidationResult(
                status=RelationshipStatus.PARTIALLY_CONNECTED,
                connected_components=components
            )
        
            logger.warning(
                "PARTIAL_COMPONENTS=%s",
                    [
                        sorted(c.tables)
                        for c in components
                        ]
                    )
        
            logger.warning(
                "RELATIONSHIP_STATUS=%s",
                result.status
                )
        
            return result
        
        

        if self._validate_logical_and(
            components
        ):

            result = RelationshipValidationResult(
                status=RelationshipStatus.LOGICAL_AND,
                connected_components=components,
                logical_groups=components
            )

            logger.warning(
                "LOGICAL_GROUPS=%s",
                [
                    sorted(c.tables)
                    for c in components
                ]
            )

            logger.warning(
                "RELATIONSHIP_STATUS=%s",
                result.status
            )

            return result
        
        
        

        

        result = RelationshipValidationResult(
            status=RelationshipStatus.IMPOSSIBLE,
            connected_components=components,
            reason=(
                "No FK path and no logical decomposition."
            )
        )

        logger.warning(
            "RELATIONSHIP_STATUS=%s",
            result.status
        )

        return result
    
    
    def tables_path_to_fk_paths(
        self,
        table_path: list[str]
    ) -> list[FKPath]:

        fk_paths = []

        for i in range(len(table_path) - 1):

            left = table_path[i]
            right = table_path[i + 1]

            for fk in self.fk_graph.paths:

                if (
                    fk.table == left
                    and fk.related_table == right
                ) or (
                    fk.table == right
                    and fk.related_table == left
                ):
                    fk_paths.append(fk)
                    break

        return fk_paths

        
    
    def find_connected_components(
        self,
        required_tables: set[str]   # receiving the mandatory tables
    ):
        
        logger.warning(
            "ENTERING_FIND_CONNECTED_COMPONENTS"
        )

        logger.warning(
            "REQUIRED_TABLES=%s",
            sorted(required_tables)
        )

        visited = set()
        components = []

        for start_table in required_tables:

            if start_table in visited:
                continue

            stack = [start_table]

            reachable_required_tables = set()

            traversed_tables = set()

            component_fk_paths = []

            local_seen_fk = set()

            while stack:

                current = stack.pop()

                if current in traversed_tables:
                    continue

                traversed_tables.add(current)

                if current in required_tables:
                    reachable_required_tables.add(current)

                for fk in self.fk_graph.paths:

                    if fk.table == current:
                        neighbour = fk.related_table

                    elif fk.related_table == current:
                        neighbour = fk.table

                    else:
                        continue

                    fk_key = (
                        fk.table,
                        fk.related_table,
                        fk.join_on
                    )

                    #
                    # Explore the full graph
                    #
                    if neighbour not in traversed_tables:

                        stack.append(neighbour)

                        #
                        # Conserver uniquement
                        # les FK réellement utilisés
                        # pour la traversée
                        #
                        if fk_key not in local_seen_fk:

                            component_fk_paths.append(fk)

                            local_seen_fk.add(fk_key)

            visited.update(reachable_required_tables)

            if reachable_required_tables:
                
                logger.warning(
                    "COMPONENT_TABLES=%s",
                    sorted(reachable_required_tables)
                )

                logger.warning(
                    "COMPONENT_FK_COUNT=%s",
                    len(component_fk_paths)
                )

                logger.warning(
                    "COMPONENT_FK_PREVIEW=%s",
                    [
                        f"{fk.table}->{fk.related_table}"
                        for fk in component_fk_paths[:10]
                    ]
                )
                
                
                logger.warning(
                    "TRAVERSED_TABLES_COUNT=%s",
                    len(traversed_tables)
                )
                
                logger.warning(
                    "REACHABLE_REQUIRED=%s",
                    sorted(reachable_required_tables)
                )

                logger.warning(
                    "COMPONENT_FK_COUNT=%s",
                    len(component_fk_paths)
                )

                for fk in component_fk_paths[:10]:
                    logger.warning(
                        "COMPONENT_FK=%s",
                        fk.join_on
                    )
                
                
                logger.warning(
                    "REACHABLE_REQUIRED_TABLES=%s",
                    sorted(reachable_required_tables)
                )

                logger.warning(
                    "COMPONENT_FK_COUNT=%s",
                    len(component_fk_paths)
                )

                logger.warning(
                    "COMPONENT_FIRST20=%s",
                    [
                        f"{fk.table}->{fk.related_table}"
                        for fk in component_fk_paths[:20]
                    ]
                )
                
                
                logger.warning(
                    "REACHABLE_REQUIRED_TABLES=%s",
                    sorted(reachable_required_tables)
                )

                logger.warning(
                    "COMPONENT_FK_TABLES=%s",
                    sorted(
                        set(
                            [fk.table for fk in component_fk_paths]
                            +
                            [fk.related_table for fk in component_fk_paths]
                        )
                    )
                )    
                
                logger.error(
                    "COMPONENT_FK_PATHS=%s",
                    [
                        f"{fk.table}->{fk.related_table}"
                        for fk in component_fk_paths
                    ]
                )

                components.append(
                    ConnectedComponent(
                        tables=reachable_required_tables,
                        fk_paths=component_fk_paths
                    )
                )
        logger.warning(
            "RETURNING_COMPONENTS=%s",
            len(components)
        )

        return components
    
    
    def _validate_logical_and(
        self,
        components
    ):

        if len(components) < 2:
            return False

        for i in range(len(components)):

            for j in range(
                i + 1,
                len(components)
            ):

                overlap = self._logical_overlap(
                    components[i],
                    components[j]
                )

                if overlap > 0:

                    logger.warning(
                        "LOGICAL_AND_ACCEPTED"
                    )

                    return True

        logger.warning(
            "LOGICAL_AND_REJECTED"
        )

        return False
    
    
    def build_verified_fk_graph(self):

        kb = load_kb()

        graph = FKGraph()

        for table_name in kb:

            for rel in get_relationships(table_name):

                fk = FKPath(

                    table=table_name,

                    related_table=rel["related_table"],

                    own_column=rel["own_column"],

                    related_column=rel["related_column"],

                    role=rel["role"],

                    relationship_name=rel["name"],

                    cardinality=rel["cardinality"],

                    join_on=rel["join_on"],

                    source="RAG"
                )

                graph.add_path(fk)

        return graph
    
    
    def _component_business_signature(
        self,
        component: ConnectedComponent
    ) -> set[str]:
        
        signature = set()

        for table in component.tables:

            kb = get_table_kb(table)

            signature.add(table.lower())

            label = kb.get(
                "label",
                ""
            )

            if label:
                signature.update(
                    label.lower().split()
                )

            description = kb.get(
                "description",
                ""
            )

            if description:
                signature.update(
                    description.lower().split()
                )

            for keyword in kb.get(
                "keywords",
                []
            ):
                signature.add(
                    keyword.lower()
                )

            domain = kb.get(
                "domain",
                []
            )

            if isinstance(domain, list):

                for item in domain:

                    signature.update(
                        str(item).lower().split()
                    )
                    
        logger.warning(
            "COMPONENT_SIGNATURE=%s",
            sorted(signature)
        )

        return signature
    
    
    def _logical_overlap(
        self,
        component_a,
        component_b
    ):

        sig_a = self._component_business_signature(
            component_a
        )

        sig_b = self._component_business_signature(
            component_b
        )

        overlap = len(
            sig_a.intersection(
                sig_b
            )
        )

        logger.warning(
            "OVERLAP_BETWEEN=%s <-> %s = %s",
            sorted(component_a.tables),
            sorted(component_b.tables),
            overlap
        )

        return overlap
    
    def build_relationship_context(
        self,
        result: RelationshipValidationResult
    ) -> str:

        lines = []

        lines.append("=" * 50)
        lines.append("RELATIONSHIP VALIDATION")
        lines.append("=" * 50)

        lines.append("")
        lines.append(f"Status: {result.status}")

        lines.append("")
        lines.append("Connected Components:")

        for idx, component in enumerate(
            result.connected_components,
            start=1
        ):

            lines.append("")
            lines.append(
                f"Component {idx}:"
            )

            for table in sorted(
                component.tables
            ):
                lines.append(
                    f"    {table}"
                )

        lines.append("")
        lines.append(
            "IMPORTANT:"
        )

        lines.append(
            "Only use validated tables."
        )

        lines.append(
            "Do not invent joins."
        )

        lines.append(
            "Do not invent foreign keys."
        )

        return "\n".join(lines)
    
    
    
    def _requires_correlation(
        self,
        question: str,
    ) -> bool:

        q = question.lower()

        return any(
            keyword in q
            for keyword in CORRELATION_KEYWORDS
        )
        
        



    def extract_join_paths(
        self,
        mandatory_tables: set[str]
    ):
        logger.error(
            "EXTRACT_JOIN_PATHS_CALLED"
        )

        logger.warning(
            "ENTERING_EXTRACT_JOIN_PATHS"
        )

        join_paths = []

        for source, target in combinations(
            sorted(mandatory_tables),
            2
        ):

            logger.warning(
                "SEARCHING_PATH %s -> %s",
                source,
                target
            )

            queue = deque()

            queue.append(
                (source, [source])
            )

            visited = {source}

            found_path = None

            while queue:

                current, path = queue.popleft()

                if current == target:

                    found_path = path

                    logger.warning(
                        "JOIN_PATH_FOUND %s -> %s : %s",
                        source,
                        target,
                        path
                    )

                    break

                for neighbour in self.fk_graph.adj.get(
                    current,
                    set()
                ):

                    if neighbour in visited:
                        continue

                    visited.add(neighbour)

                    queue.append(
                        (
                            neighbour,
                            path + [neighbour]
                        )
                    )

            if found_path:

                join_paths.append(
                    (
                        source,
                        target,
                        found_path
                    )
                )

            else:

                logger.warning(
                    "JOIN_PATH_NOT_FOUND %s -> %s",
                    source,
                    target
                )

        logger.warning(
            "TOTAL_JOIN_PATHS=%s",
            len(join_paths)
        )

        return join_paths
    

    from collections import deque

    def bfs_shortest_path(
        self,
        source: str,
        target: str
    ):

        queue = deque()

        queue.append(
            (source, [source])
        )

        visited = {source}

        while queue:

            current, path = queue.popleft()

            if current == target:
                return path

            for neighbour in self.fk_graph.adj.get(
                current,
                set()
            ):

                if neighbour in visited:
                    continue

                visited.add(neighbour)

                queue.append(
                    (
                        neighbour,
                        path + [neighbour]
                    )
                )

        return None
            
            
    