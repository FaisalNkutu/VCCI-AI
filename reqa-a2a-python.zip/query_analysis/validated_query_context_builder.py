from dataclasses import dataclass
from query_analysis.relationship_validator import (
    RelationshipStatus,
)

import logging
from dataclasses import field

logger = logging.getLogger(__name__)

from query_analysis.connected_graph import ConnectedGraph

from query_analysis.connected_graph_builder import (
    build_query_specific_connected_graph,
)

@dataclass
class ValidatedQueryContext:

    relationship_status: str
    mandatory_tables: list[str]
    fk_paths: list[str]
    predicate_groups: list[list[str]]
    entity_filters: list[str]
    relevant_columns: dict[str, list[str]]
    display_columns: dict[str, list[str]]
    recommended_join_chain: list[dict] = field(
    default_factory=list
    ) 
    connected_graph: ConnectedGraph | None = None
    
    required_join_path: list[str] = field(default_factory=list)
    

def _requires_correlation(
    question: str,
) -> bool:

    q = question.lower()

    correlation_keywords = [
        "using",
        "uses",
        "used by",
        "belongs to",
        "assigned to",
        "equipped with",
        "located in",
        "participating in",
        "owned by",
        "within",
    ]

    return any(
        keyword in q
        for keyword in correlation_keywords
    )
    
    
def _collect_validated_fk_paths(
    relationship_result
):
    all_fk_paths = []

    for component in relationship_result.connected_components:

        all_fk_paths.extend(
            component.fk_paths
        )

    seen = set()
    deduped = []

    for fk in all_fk_paths:

        key = (
            fk.table,
            fk.related_table,
            fk.join_on
        )

        if key not in seen:

            seen.add(key)
            deduped.append(fk)

    return deduped


def build_validated_query_context(
    question: str,
    relationship_result,
    resolved_entities,
    mandatory_tables
) -> ValidatedQueryContext:

    entity_filters = []

    for resolution in resolved_entities:

        for candidate in resolution.candidates:
            
            logger.warning(
                "RESOLUTION=%s",
                resolution,
            )

            logger.warning(
                "CANDIDATE=%s",
                candidate,
            )


            entity_filters.append(
                f"{candidate.table}."
                f"{candidate.column}="
                f"{candidate.value}"
            )
     
    
    predicate_groups = []
    
    all_fk_paths = _collect_validated_fk_paths(
        relationship_result
    )

    logger.warning(
        "ALL_FK_PATHS_COUNT=%s",
        len(all_fk_paths)
    )

    logger.warning(
        "ALL_FK_PATHS=%s",
        [
            f"{fk.table}->{fk.related_table}"
            for fk in all_fk_paths
        ]
    )
        
        

    if hasattr(
        relationship_result,
        "logical_groups"
    ):

        for group in relationship_result.logical_groups:

            predicate_groups.append(
                sorted(list(group.tables))
            )
            
            
        #
    # LOGICAL_AND -> UNSATISFIABLE_CORRELATION
    #

    if (relationship_result.status
        == RelationshipStatus.LOGICAL_AND):

        logger.warning(
            "CORRELATION_CHECK=%s",
            _requires_correlation(
                question
            )
        )

        if _requires_correlation(
            question
        ):

            logger.warning(
                "UNSATISFIABLE_CORRELATION_DETECTED"
            )

            logger.warning(
                "QUESTION=%s",
                question
            )

            logger.warning(
                "PREDICATE_GROUPS=%s",
                predicate_groups
            )
            
            logger.warning(
                "RELATIONSHIP_RESULT_FK_PATHS=%s",
                getattr(relationship_result, "fk_paths", None)
            )
            
            

            logger.warning(
                "ALL_FK_PATHS=%s",
                all_fk_paths
            )
            
            logger.warning(
                "ALL_FK_PATHS_COUNT=%s",
                len(all_fk_paths)
            )
            
            
            logger.warning(
                "MANDATORY_TABLES=%s",
                mandatory_tables
            )

            logger.warning(
                "ALL_FK_PATHS_COUNT=%s",
                len(all_fk_paths)
            )

            logger.warning(
                "ALL_FK_TABLES=%s",
                sorted(
                    {
                        fk.table
                        for fk in all_fk_paths
                    }
                    |
                    {
                        fk.related_table
                        for fk in all_fk_paths
                    }
                )
            )
            
            logger.warning(
                "RETURNING_VALIDATED_CONTEXT_FK_COUNT=%s",
                len(all_fk_paths)
            )

            logger.warning(
                "RETURNING_VALIDATED_CONTEXT_FK_PATHS=%s",
                [
                    f"{fk.table}->{fk.related_table}"
                    for fk in all_fk_paths
                ]
            )
            
            connected_graph=None
            
            
                                    

            return ValidatedQueryContext(

                relationship_status=
                    str(
                        RelationshipStatus.UNSATISFIABLE_CORRELATION
                    ),

                mandatory_tables=
                    sorted(mandatory_tables),

                fk_paths=[],

                predicate_groups=
                    predicate_groups,

                entity_filters=
                    entity_filters,

                relevant_columns={},

                display_columns={}
            )
        
        
    logger.warning(
        "RELATIONSHIP_RESULT_FK_PATHS=%s",
        getattr(relationship_result, "fk_paths", None)
    )
   

    logger.warning(
        "ALL_FK_PATHS=%s",
        all_fk_paths
    )
    
    logger.warning(
        "ALL_FK_PATHS_COUNT=%s",
        len(all_fk_paths)
    )
    
    
    logger.warning(
        "RETURNING_VALIDATED_CONTEXT_FK_COUNT=%s",
        len(all_fk_paths)
    )
    
    logger.warning(
        "RETURNING_VALIDATED_CONTEXT_FK_COUNT=%s",
        len(all_fk_paths)
    )

    logger.warning(
        "RETURNING_VALIDATED_CONTEXT_FK_PATHS=%s",
        [
            f"{fk.table}->{fk.related_table}"
            for fk in all_fk_paths
        ]
    )
    
    connected_graph = build_query_specific_connected_graph(
        mandatory_tables=sorted(mandatory_tables),
        fk_paths=all_fk_paths,
    )
    
    logger.warning(
        "CONNECTED_GRAPH_NODES=%s",
        sorted(connected_graph.nodes),
    )

    logger.warning(
        "CONNECTED_GRAPH_EDGE_COUNT=%s",
        len(connected_graph.edges),
    )

    for edge in connected_graph.edges:
        logger.warning(
            "CONNECTED_GRAPH_EDGE=%s -> %s | %s",
            edge.from_table,
            edge.to_table,
            edge.join_condition,
        )           

    return ValidatedQueryContext(

        relationship_status=
            str(relationship_result.status),

        mandatory_tables=
            sorted(mandatory_tables),

        fk_paths=all_fk_paths,

        connected_graph=
            connected_graph,

        predicate_groups=
            predicate_groups,

        entity_filters=
            entity_filters,

        relevant_columns={},

        display_columns={}
    )