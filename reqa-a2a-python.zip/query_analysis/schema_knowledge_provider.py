class SchemaKnowledgeProvider:

    def get_tables(self):
        pass

    def get_table_description(
        self,
        table_name: str
    ):
        pass

    def get_table_keywords(
        self,
        table_name: str
    ):
        pass

    def get_table_relationships(
        self,
        table_name: str
    ):
        pass