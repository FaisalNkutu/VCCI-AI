from collections import defaultdict, deque


def build_required_join_path(
    connected_graph,
    mandatory_tables,
):
    """
    Returns the shortest path connecting
    the mandatory tables.
    """

    tables = list(mandatory_tables)

    if len(tables) < 2:
        return tables

    start = tables[0]
    target = tables[-1]

    graph = defaultdict(list)

    for edge in connected_graph.edges:

        graph[edge.from_table].append(
            edge.to_table
        )

        graph[edge.to_table].append(
            edge.from_table
        )

    queue = deque(
        [(start, [start])]
    )

    visited = {start}

    while queue:

        node, path = queue.popleft()

        if node == target:
            return path

        for nxt in graph[node]:

            if nxt not in visited:

                visited.add(nxt)

                queue.append(
                    (
                        nxt,
                        path + [nxt]
                    )
                )

    return []


def _shortest_path(
    graph,
    start,
    target,
):
    """
    Return the shortest path between two tables.
    """

    if start == target:
        return [start]

    queue = deque([
        (start, [start])
    ])

    visited = {start}

    while queue:

        node, path = queue.popleft()

        for nxt in graph.get(node, []):

            if nxt in visited:
                continue

            next_path = path + [nxt]

            if nxt == target:
                return next_path

            visited.add(nxt)

            queue.append(
                (
                    nxt,
                    next_path,
                )
            )

    return []


def build_required_join_graph(
    connected_graph,
    mandatory_tables,
):
    """
    Build the union of the validated paths needed
    to connect all mandatory tables.

    Returns GraphEdge objects from connected_graph.
    """

    if not connected_graph:
        return []

    required_tables = [
        table
        for table in mandatory_tables
        if table in connected_graph.nodes
    ]

    if len(required_tables) < 2:
        return []

    graph = defaultdict(list)
    edge_lookup = {}

    for edge in connected_graph.edges:

        graph[edge.from_table].append(
            edge.to_table
        )

        graph[edge.to_table].append(
            edge.from_table
        )

        edge_lookup[
            frozenset(
                (
                    edge.from_table,
                    edge.to_table,
                )
            )
        ] = edge

    # Use one mandatory table as anchor.
    anchor = required_tables[0]

    merged_edges = []
    seen_edges = set()

    for target in required_tables[1:]:

        path = _shortest_path(
            graph,
            anchor,
            target,
        )

        if not path:
            continue

        for left, right in zip(
            path,
            path[1:],
        ):

            edge = edge_lookup.get(
                frozenset(
                    (
                        left,
                        right,
                    )
                )
            )

            if edge is None:
                continue

            edge_key = (
                edge.from_table,
                edge.to_table,
                edge.join_condition,
            )

            if edge_key in seen_edges:
                continue

            seen_edges.add(edge_key)
            merged_edges.append(edge)

    return merged_edges