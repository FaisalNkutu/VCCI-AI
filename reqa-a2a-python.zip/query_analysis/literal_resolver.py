from dataclasses import dataclass
from typing import Optional


@dataclass
class LiteralResolutionResult:

    literal: str

    resolution_type: str

    matched_table: Optional[str] = None

    matched_column: Optional[str] = None

    matched_value: Optional[str] = None

    confidence: float = 0.0





from .query_models import (
    LiteralResolutionResult
)


class LiteralResolver:


    def resolve(
        self,
        literal: str
    ) -> LiteralResolutionResult:

        enum_match = self.resolve_enum(
            literal
        )

        if enum_match:
            return enum_match

        return self.resolve_data_value(
            literal
        )

    def resolve_enum(
        self,
        literal: str
    ) -> LiteralResolutionResult | None:

        return None

    def resolve_data_value(
        self,
        literal: str
    ) -> LiteralResolutionResult:

        #payloads = self.schema_rag._payload_by_table()

        print(
            f"LITERAL={literal}"
        )

        #print(
        #    f"TABLE_COUNT={len(payloads)}"
        #)

        
        return LiteralResolutionResult(
            literal=literal,
            resolution_type="DATA_VALUE",
            confidence=1.0
        )
    
        

