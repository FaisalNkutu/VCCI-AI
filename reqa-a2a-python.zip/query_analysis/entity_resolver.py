from .query_models import EntityResolutionResult




class EntityResolver:

    def resolve(
        self,
        term: str
    ) -> EntityResolutionResult | None:

        return None