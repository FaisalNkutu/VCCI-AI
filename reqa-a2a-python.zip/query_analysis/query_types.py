# query_analyzer.py

from enum import Enum
from dataclasses import dataclass

RELATIONSHIP_VERBS = {
    "use",
    "own",
    "participate",
    "assign",
    "associate",
    "belong",
    "support",
    "deploy",
    "contain",
    "relate",
    "connect",
    "link",
    "join",
    "hold",
    "equip",
    "report",
    "command",
    "control",
    "operate",
    "locate",
    "attach",
}

class QueryType(str, Enum):
    SINGLE_ENTITY = "SINGLE_ENTITY"
    MULTI_ENTITY_DESCRIPTIVE = "MULTI_ENTITY_DESCRIPTIVE"
    RELATIONSHIP = "RELATIONSHIP"
    UNKNOWN = "UNKNOWN"
