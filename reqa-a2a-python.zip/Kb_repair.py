#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
kb_repair.py -- Répare les décodages d'enum pollués de la KB REQA.

Constat (log de production du 2026-07-28) : les `allowed_values` de la KB
mélangent des devinettes d'abréviations militaires avec des codes standard,
p. ex. country_code 'BTN': 'Battalion' (en réalité Bhoutan), 'COL':
'Colonel / column' (Colombie), 'FLK': 'Flanker Su-27' (Falkland),
'HTI': 'Hostile intent' (Haïti). Ce bruit est injecté dans le contexte du
LLM à chaque question : il le désinforme et gonfle le prompt.

Ce script applique DEUX types de correction, volontairement prudents :

  1. CORRECTIONS SÛRES (appliquées d'office) :
     - toute colonne nommée *country_code* : les valeurs qui sont des codes
       ISO 3166-1 alpha-3 reçoivent le nom officiel du pays ;
     - toute colonne nommée *hostility_code* : les codes standard
       JC3IEDM/MIP (HO, FR, SUSPCT, ...) reçoivent leur sens standard.

  2. RAPPORT (aucune modification) : tout décodage suspect ailleurs
     (libellés placeholder du type "Tactical code", "equipment code",
     "Phonetic/abbreviation", ...) est listé dans kb_suspect_report.tsv
     pour revue humaine -- ce script ne devine JAMAIS un sens métier.

Usage :
    python kb_repair.py [chemin/vers/KB_full_update2.json]

Le fichier original est sauvegardé en <nom>.bak avant écriture.
Relancez ensuite l'ingestion Qdrant (conteneur reqa-ingest / bouton
Re-index) pour que les payloads reflètent la KB corrigée.
"""

import json
import re
import shutil
import sys
from pathlib import Path

ISO3166 = {
 "NOS": "Not otherwise specified",
 "NKN": "Unknown",
 "ABW": "Aruba",
 "AFG": "Afghanistan",
 "AGO": "Angola",
 "AIA": "Anguilla",
 "ALA": "Åland Islands",
 "ALB": "Albania",
 "AND": "Andorra",
 "ARE": "United Arab Emirates",
 "ARG": "Argentina",
 "ARM": "Armenia",
 "ASM": "American Samoa",
 "ATA": "Antarctica",
 "ATF": "French Southern Territories",
 "ATG": "Antigua and Barbuda",
 "AUS": "Australia",
 "AUT": "Austria",
 "AZE": "Azerbaijan",
 "BDI": "Burundi",
 "BEL": "Belgium",
 "BEN": "Benin",
 "BES": "Bonaire, Sint Eustatius and Saba",
 "BFA": "Burkina Faso",
 "BGD": "Bangladesh",
 "BGR": "Bulgaria",
 "BHR": "Bahrain",
 "BHS": "Bahamas",
 "BIH": "Bosnia and Herzegovina",
 "BLM": "Saint Barthélemy",
 "BLR": "Belarus",
 "BLZ": "Belize",
 "BMU": "Bermuda",
 "BOL": "Bolivia",
 "BRA": "Brazil",
 "BRB": "Barbados",
 "BRN": "Brunei Darussalam",
 "BTN": "Bhutan",
 "BVT": "Bouvet Island",
 "BWA": "Botswana",
 "CAF": "Central African Republic",
 "CAN": "Canada",
 "CCK": "Cocos (Keeling) Islands",
 "CHE": "Switzerland",
 "CHL": "Chile",
 "CHN": "China",
 "CIV": "Ivory Coast (Cote d'Ivoire)",
 "CMR": "Cameroon",
 "COD": "DR Congo (Kinshasa)",
 "COG": "Congo (Brazzaville)",
 "COK": "Cook Islands",
 "COL": "Colombia",
 "COM": "Comoros",
 "CPV": "Cabo Verde",
 "CRI": "Costa Rica",
 "CUB": "Cuba",
 "CUW": "Curaçao",
 "CXR": "Christmas Island",
 "CYM": "Cayman Islands",
 "CYP": "Cyprus",
 "CZE": "Czech Republic",
 "DEU": "Germany",
 "DJI": "Djibouti",
 "DMA": "Dominica",
 "DNK": "Denmark",
 "DOM": "Dominican Republic",
 "DZA": "Algeria",
 "ECU": "Ecuador",
 "EGY": "Egypt",
 "ERI": "Eritrea",
 "ESH": "Western Sahara",
 "ESP": "Spain",
 "EST": "Estonia",
 "ETH": "Ethiopia",
 "FIN": "Finland",
 "FJI": "Fiji",
 "FLK": "Falkland Islands (Malvinas)",
 "FRA": "France",
 "FRO": "Faroe Islands",
 "FSM": "Micronesia",
 "GAB": "Gabon",
 "GBR": "United Kingdom (Great Britain)",
 "GEO": "Georgia",
 "GGY": "Guernsey",
 "GHA": "Ghana",
 "GIB": "Gibraltar",
 "GIN": "Guinea",
 "GLP": "Guadeloupe",
 "GMB": "Gambia",
 "GNB": "Guinea-Bissau",
 "GNQ": "Equatorial Guinea",
 "GRC": "Greece",
 "GRD": "Grenada",
 "GRL": "Greenland",
 "GTM": "Guatemala",
 "GUF": "French Guiana",
 "GUM": "Guam",
 "GUY": "Guyana",
 "HKG": "Hong Kong",
 "HMD": "Heard Island and McDonald Islands",
 "HND": "Honduras",
 "HRV": "Croatia",
 "HTI": "Haiti",
 "HUN": "Hungary",
 "IDN": "Indonesia",
 "IMN": "Isle of Man",
 "IND": "India",
 "IOT": "British Indian Ocean Territory",
 "IRL": "Ireland",
 "IRN": "Iran",
 "IRQ": "Iraq",
 "ISL": "Iceland",
 "ISR": "Israel",
 "ITA": "Italy",
 "JAM": "Jamaica",
 "JEY": "Jersey",
 "JOR": "Jordan",
 "JPN": "Japan",
 "KAZ": "Kazakhstan",
 "KEN": "Kenya",
 "KGZ": "Kyrgyzstan",
 "KHM": "Cambodia",
 "KIR": "Kiribati",
 "KNA": "Saint Kitts and Nevis",
 "KOR": "South Korea (Republic of Korea)",
 "KWT": "Kuwait",
 "LAO": "Laos",
 "LBN": "Lebanon",
 "LBR": "Liberia",
 "LBY": "Libya",
 "LCA": "Saint Lucia",
 "LIE": "Liechtenstein",
 "LKA": "Sri Lanka",
 "LSO": "Lesotho",
 "LTU": "Lithuania",
 "LUX": "Luxembourg",
 "LVA": "Latvia",
 "MAC": "Macao",
 "MAF": "Saint Martin (French part)",
 "MAR": "Morocco",
 "MCO": "Monaco",
 "MDA": "Moldova",
 "MDG": "Madagascar",
 "MDV": "Maldives",
 "MEX": "Mexico",
 "MHL": "Marshall Islands",
 "MKD": "North Macedonia",
 "MLI": "Mali",
 "MLT": "Malta",
 "MMR": "Myanmar",
 "MNE": "Montenegro",
 "MNG": "Mongolia",
 "MNP": "Northern Mariana Islands",
 "MOZ": "Mozambique",
 "MRT": "Mauritania",
 "MSR": "Montserrat",
 "MTQ": "Martinique",
 "MUS": "Mauritius",
 "MWI": "Malawi",
 "MYS": "Malaysia",
 "MYT": "Mayotte",
 "NAM": "Namibia",
 "NCL": "New Caledonia",
 "NER": "Niger",
 "NFK": "Norfolk Island",
 "NGA": "Nigeria",
 "NIC": "Nicaragua",
 "NIU": "Niue",
 "NLD": "Netherlands",
 "NOR": "Norway",
 "NPL": "Nepal",
 "NRU": "Nauru",
 "NZL": "New Zealand",
 "OMN": "Oman",
 "PAK": "Pakistan",
 "PAN": "Panama",
 "PCN": "Pitcairn",
 "PER": "Peru",
 "PHL": "Philippines",
 "PLW": "Palau",
 "PNG": "Papua New Guinea",
 "POL": "Poland",
 "PRI": "Puerto Rico",
 "PRK": "North Korea (DPRK)",
 "PRT": "Portugal",
 "PRY": "Paraguay",
 "PSE": "Palestine",
 "PYF": "French Polynesia",
 "QAT": "Qatar",
 "REU": "Réunion",
 "ROU": "Romania",
 "RUS": "Russia",
 "RWA": "Rwanda",
 "SAU": "Saudi Arabia",
 "SDN": "Sudan",
 "SEN": "Senegal",
 "SGP": "Singapore",
 "SGS": "South Georgia and the South Sandwich Islands",
 "SHN": "Saint Helena, Ascension and Tristan da Cunha",
 "SJM": "Svalbard and Jan Mayen",
 "SLB": "Solomon Islands",
 "SLE": "Sierra Leone",
 "SLV": "El Salvador",
 "SMR": "San Marino",
 "SOM": "Somalia",
 "SPM": "Saint Pierre and Miquelon",
 "SRB": "Serbia",
 "SSD": "South Sudan",
 "STP": "Sao Tome and Principe",
 "SUR": "Suriname",
 "SVK": "Slovakia",
 "SVN": "Slovenia",
 "SWE": "Sweden",
 "SWZ": "Eswatini (Swaziland)",
 "SXM": "Sint Maarten (Dutch part)",
 "SYC": "Seychelles",
 "SYR": "Syria",
 "TCA": "Turks and Caicos Islands",
 "TCD": "Chad",
 "TGO": "Togo",
 "THA": "Thailand",
 "TJK": "Tajikistan",
 "TKL": "Tokelau",
 "TKM": "Turkmenistan",
 "TLS": "Timor-Leste",
 "TON": "Tonga",
 "TTO": "Trinidad and Tobago",
 "TUN": "Tunisia",
 "TUR": "Turkey",
 "TUV": "Tuvalu",
 "TWN": "Taiwan",
 "TZA": "Tanzania",
 "UGA": "Uganda",
 "UKR": "Ukraine",
 "UMI": "United States Minor Outlying Islands",
 "URY": "Uruguay",
 "USA": "United States of America",
 "UZB": "Uzbekistan",
 "VAT": "Vatican (Holy See)",
 "VCT": "Saint Vincent and the Grenadines",
 "VEN": "Venezuela",
 "VGB": "Virgin Islands, British",
 "VIR": "Virgin Islands, U.S.",
 "VNM": "Vietnam",
 "VUT": "Vanuatu",
 "WLF": "Wallis and Futuna",
 "WSM": "Samoa",
 "YEM": "Yemen",
 "ZAF": "South Africa",
 "ZMB": "Zambia",
 "ZWE": "Zimbabwe"
}

HOSTILITY = {
 "AFR": "Assumed Friend",
 "FAKER": "Faker (friendly acting as hostile, exercise)",
 "FR": "Friend",
 "HO": "Hostile",
 "IV": "Interdicted Vehicle",
 "JOKER": "Joker (friendly acting as suspect, exercise)",
 "NEUTRL": "Neutral",
 "NKN": "Unknown",
 "PENDNG": "Pending",
 "SUSPCT": "Suspect",
 "UNK": "Unknown"
}

# Libellés "placeholder" trahissant un décodage deviné/manquant.
SUSPECT_RE = re.compile(
    r"tactical code|equipment code|materiel code|phonetic|abbreviation"
    r"|aircraft type designator|^code$|^type code|variant [A-Z]{2,}$"
    r"|ethnic/language group|NATO reporting name",
    re.IGNORECASE,
)


def main() -> None:
    kb_path = Path(sys.argv[1] if len(sys.argv) > 1 else "RAG/KB_full_update2.json")
    if not kb_path.exists():
        sys.exit(f"KB introuvable : {kb_path}")

    data = json.loads(kb_path.read_text(encoding="utf-8"))
    tables = data.get("tables", data)

    fixed_country = fixed_host = 0
    suspects: list[str] = []

    for table, entry in tables.items():
        for col, cd in (entry.get("columns") or {}).items():
            allowed = (cd or {}).get("allowed_values")
            if not isinstance(allowed, dict):
                continue

            if col.endswith("country_code"):
                for code in list(allowed):
                    official = ISO3166.get(str(code).upper())
                    if official and allowed[code] != official:
                        allowed[code] = official
                        fixed_country += 1
            elif col.endswith("hostility_code"):
                for code in list(allowed):
                    std = HOSTILITY.get(str(code).upper())
                    if std and allowed[code] != std:
                        allowed[code] = std
                        fixed_host += 1
            else:
                for code, meaning in allowed.items():
                    if isinstance(meaning, str) and SUSPECT_RE.search(meaning):
                        suspects.append(f"{table}\t{col}\t{code}\t{meaning}")

    backup = kb_path.with_suffix(kb_path.suffix + ".bak")
    shutil.copy2(kb_path, backup)
    kb_path.write_text(json.dumps(data, ensure_ascii=False, indent=2),
                       encoding="utf-8")

    report = Path("kb_suspect_report.tsv")
    report.write_text("table\tcolumn\tcode\tmeaning_suspect\n"
                      + "\n".join(suspects) + "\n", encoding="utf-8")

    print(f"Corrections country_code : {fixed_country}")
    print(f"Corrections hostility_code : {fixed_host}")
    print(f"Decodages suspects a revoir : {len(suspects)} -> {report}")
    print(f"Sauvegarde de l'original : {backup}")
    print("\nN'oubliez pas de relancer l'ingestion Qdrant (Re-index) !")


if __name__ == "__main__":
    main()