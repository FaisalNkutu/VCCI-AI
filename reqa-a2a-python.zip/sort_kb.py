KB_full = "RAG\\KB_full_update2.json"

import json

# Charger le fichier JSON
with open(KB_full, "r", encoding="utf-8") as f:
    data = json.load(f)

# Trier les clés du dictionnaire
sorted_data = dict(sorted(data.items()))

#print(sorted_data.items().get(0))


# Sauvegarder le JSON trié
with open("RAG\\KB_full_update2_sorted.json", "w", encoding="utf-8") as f:
    json.dump(sorted_data, f, indent=4, ensure_ascii=False)

print("JSON file sorted successfuly")

