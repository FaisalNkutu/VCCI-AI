# say if LLM generated this as part of SQL query,
# but it is not one of the values used in the database itself
# match it to be best value that does get used in the db
full_query = "SELECT * FROM pers_stat WHERE duty_stat_code = 'MISSING'"
input_text = "MISSING"

full_query = "SELECT * FROM pers_stat WHERE duty_stat_code = 'MISSING' -- Assuming 'MISSING' is the code used for missing personnel"

import json
import sqlglot
from sqlglot import exp

# determine the table names, field names, etc., from this statement
def analyze_sql(sql_statement):
    sql_parsed = sqlglot.parse_one(sql_statement)
    sql_parsed = sql_parsed.sql(comments=False)
    sql_parsed = sqlglot.parse_one(sql_parsed)
    
    columns, literals = [], []

    # column names; also check what value (e.g., 'missing') we are looking for
    for column in sql_parsed.find_all(exp.Column):
        columns.append(column.name)        
        #print (column.name)

    for lit in sql_parsed.find_all(exp.Literal):
        literals.append(lit)        
        #print (lit)

    return columns, literals

def find_best_matches(search_term, column):
    print (search_term)
    print (type(search_term))
    
    if "_code" in column:
        search_term = str(search_term).replace("'", "")
        data_enums  = []
            
        # Opening JSON file
        with open("all_enums/columns_values_def.json") as json_file:
            data = json.load(json_file)
            
            for i in range(len(data)):
                k = list(data.keys())[i]
                v = list(data.values())[i]
                data_enums.append((k, v))

        # find best match
        found_enum = None
        for i in range(len(data_enums)):
            if data_enums[i][1].lower() == search_term.lower():
                if found_enum is None:
                    found_enum = data_enums[i][0]

        return found_enum
    else:
        return search_term

# assume these 2 lists are of same length
# todo: see if there are any cases where that is not true
columns, literals = analyze_sql(full_query)

full_query = sqlglot.parse_one(full_query)
full_query = full_query.sql(comments=False)

for i in range(len(literals)):
    found_enum = find_best_matches(literals[i], columns[i])
    full_query = full_query.replace(str(literals[i]), f"'{found_enum}'")
    print (literals[i])
    print (found_enum)

print ("new query:", full_query)
