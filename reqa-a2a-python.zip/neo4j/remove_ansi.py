import re

def strip_ansi(text):
    # Regex to match ANSI escape sequences
    ansi_escape = re.compile(r'\x1b\[[0-9;]*[a-zA-Z]')
    return ansi_escape.sub('', text)

clean_text = strip_ansi("LEFT JOIN elctrnc_addr ON addr.addr_id = elctrnc_addr.electronic_addr_id [4mAS[0m T2")
print("clean_text:", clean_text)  # Output: Hello
