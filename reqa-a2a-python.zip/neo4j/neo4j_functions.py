
import sys
from neo4j import GraphDatabase

driver = None


#=======================   config.json  ====================================================
sys.path.insert(0, "../") # add this path to get the config in root dir
from config.settings import get_settings
settings = get_settings()
#===========================================================================================



import logging
logging.basicConfig(level=logging.DEBUG,format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("NEO4J") 


# uses a table name, a direction to traverse, and a number of levels to traverse
# to find all related tables by cat_codes
def find_info_by_table_names(current_table,   direction, depth):
    global driver
    if driver is None:
        driver = GraphDatabase.driver(
            f"{settings.NEO4J_HOST}:{settings.NEO4J_PORT}",
            auth=("neo4j", "secretpassword")
        )
        driver.verify_connectivity()
    
    n = 0
    
    new_tables    = True
    input_tables  = [current_table]
    all_tables    = []
    valid_tables = [] # All tables valid. Todo: supply this in **kwargs

    while new_tables and n < depth:
        if len(input_tables) > 0:
            for current_table in input_tables:
                template = ""
                if direction == 0:
                    template = "MATCH p=({name: '"+current_table+"'})-[]->() RETURN p"
                elif direction == 1:
                    template = "MATCH p=({name: '"+current_table+"'})<-[]-() RETURN p"
                elif direction == 2:
                    template = "MATCH p=({name: '"+current_table+"'})-[]-() RETURN p"
              #  print ("template:", template)
                
                records, summary, keys = driver.execute_query(template)
                cat_codes, found_tables = [], []

                for record in records:
                    cat_code    = record.data()["p"][1]
                    found_table = record.data()["p"][2]["name"]

                    #if found_table not in all_tables and found_table not in all_tables_thus_far and found_table not in found_tables and found_table != current_table:
                    if found_table not in all_tables  and found_table != current_table:
                        # if valid tables is None or empty, 
                        if valid_tables == None or len(valid_tables) == 0 or found_table in valid_tables:
                            found_tables.append(found_table)

                #print ("new child tables:", found_tables)

                input_tables = found_tables
                
                for table in found_tables:  
                    all_tables.append(table)
        else:
            new_tables = False

        n += 1

    # make unique
    found_tables= list(set(found_tables))

    print ("initial table:", current_table)
    print ("found tables:", found_tables)    
    print ("all related tables:", all_tables)
    print ("")

    return found_tables # all_tables

def find_info_by_cat_codes(current_cat_code):
    global driver
    if driver is None:
        driver = GraphDatabase.driver(
            f"{settings.NEO4J_HOST}:{settings.NEO4J_PORT}",
            auth=("neo4j", "secretpassword")
        )
        driver.verify_connectivity()
    
    template = "MATCH p=()-[:"+current_cat_code+"]-() RETURN p"

    records, summary, keys = driver.execute_query(template)
    cat_codes, adj_tables = [], []

    for record in records:
        cat_code    = record.data()["p"][1]
        adj_table   = record.data()["p"][0]["name"]

        adj_tables.append(adj_table)

    adj_tables= list(set(adj_tables))
    print ("adjoining tables:", adj_tables)

    return adj_tables

if __name__ == "__main__":
    init_tables = []
    valid_tables = []

    # examples of navigating the database:
    # - get every possible single type of action event; will want to traverse graph recursively here
    init_tables.append('act_event')

    init_cat_codes = []

    init_cat_codes.append("ACTEV")

    '''
    - 0: forwards
    - 1: backwards
    - 2: bidirectional
    '''
    direction = 2
    depth     = float('inf')

    processed_tables = []

    # find info by table names
    for i in range(len(init_tables)):        
        all_tables = find_info_by_table_names( init_tables[i], processed_tables, valid_tables, direction, depth)
        processed_tables.append(init_tables[i])

    '''
    # find info by cat_codes
    for i in range(len(init_cat_codes)):
        all_tables = find_info_by_cat_codes(init_cat_codes[i])
    '''
