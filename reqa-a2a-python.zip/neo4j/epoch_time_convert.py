from datetime import datetime
from dateutil import parser

# dec 4 2025 -> 1764824400               
# dec 5 2025 -> 1764910800

epoch_time = 1767225600.000
epoch_time = 1764941313.787
date_str   = "December 4, 2025"

# Convert to local datetime
dt_object = datetime.fromtimestamp(epoch_time)
print("Local Time:", dt_object)

'''
# Format as a custom string (e.g., YYYY-MM-DD HH:MM:SS)
formatted_time = dt_object.strftime("%Y-%m-%d %H:%M:%S")
print("Formatted:", formatted_time)

dt_object  = parser.parse(date_str)
epoch_time = (dt_object - datetime(1970, 1, 1)).total_seconds()

print("Epoch Time:", epoch_time)
'''
