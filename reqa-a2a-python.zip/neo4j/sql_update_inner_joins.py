full_query = "SELECT COUNT(DISTINCT T1.mat_id) FROM mat AS T1 INNER JOIN mat_stat AS T2 ON T1.cat_code = T2.cat_code WHERE T2.operat_stat_code = 'OPR'"
#full_query = "SELECT COUNT(DISTINCT mat.mat_id) FROM mat INNER JOIN mat_stat ON mat.cat_code = mat_stat.cat_code WHERE mat_stat.operat_stat_code = 'OPR'"

import json
import sqlglot
from sqlglot import exp

tables_list    = []
inner_joins    = []
conditions     = []
new_conditions = []
found_pks      = []

primary_keys = [
    ["mat", "mat_id"],
    ["mat_stat", "mat_stat_id"],
    ["mat_type", "mat_type_id"]
]

def get_primary_key(table_name):
    if table_name == "mat":
        return "mat_id"
    if table_name == "mat_stat":
        return "mat_stat_id"

# determine the table names, field names, etc., from this statement
def get_inner_joins(sql_statement): 
    parsed = sqlglot.parse_one(sql_statement)
    tables = parsed.find_all(exp.Table)
    joins  = parsed.find_all(exp.Join)
    
    for table in tables:
        tables_list.append(str(table).split(" AS "))

    for join in joins:
        kind = join.args.get("kind")
        
        if kind in (None, "INNER"):
            inner_joins.append(join)
            
    print(f"Found {len(tables_list)} table(s)")
    for table in tables_list:
        print(table)    

    print(f"Found {len(inner_joins)} inner join(s)")
    for join in inner_joins:
        print(f"- Table: {join.this.name}, Condition: {join.args.get('on')}")
        conditions.append(str(join.args.get('on')).split(" = "))

    for i in range(len(tables_list)):
        pk = get_primary_key(tables_list[i][0])
        if len(tables_list[i]) == 2:            
            found_pks.append((pk, tables_list[i][1]))
        else:
            found_pks.append((pk, tables_list[i][0]))

    print (found_pks)

    for i in range(len(found_pks)):
        for j in range(len(conditions)):
            if found_pks[i][1] in conditions[j][0]:
                conditions[j][0] = f"{found_pks[i][1]}.{found_pks[i][0]}"
            if found_pks[i][1] in conditions[j][1]:
                conditions[j][1] = f"{found_pks[i][1]}.{found_pks[i][0]}"                

print ("conditions (before):", conditions)

get_inner_joins(full_query)
print ("new query:", full_query)

print ("conditions (after):", conditions)
