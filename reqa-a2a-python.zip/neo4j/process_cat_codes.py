import json

cat_codes_txt = []

f = open("../data/all_cat_codes.txt", "r")

lines = f.readlines()

for line in lines:
    cat_codes_txt.append(line.replace("\n", ""))

print (cat_codes_txt)

# Opening JSON file
with open("../data/columns_values_def.json") as json_file:
    data = json.load(json_file)
    
    for i in range(len(data)):
        k = str(list(data.keys())[i])
        v = str(list(data.values())[i])        

        if k in cat_codes_txt:
            print (f'    "{k}": "" ({v})')
