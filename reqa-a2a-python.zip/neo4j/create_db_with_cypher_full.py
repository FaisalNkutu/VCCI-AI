import json

# Reads the data from all_tables_referenced_by, to get
# every table and the foreign keys that link one table to another

def get_refs_info_from_json(filename_json):
    data = []
    
    with open(filename_json) as json_file:
        data_json = json.load(json_file)

        print ("# k,v pairs:", len(data_json))
        
        for i in range(len(data_json)):
            k = list(data_json.keys())[i]
            v = list(data_json.values())[i]
            data.append((k, v))

    print (data)
    
    return data

references_info = get_refs_info_from_json("all_tables_referenced_by_fxd.json")

for i in range(len(references_info)):
    for j in range(len(references_info)[i][1]):
        #[...]

output_file = open("output_full.txt", "w")

output_file.close()
