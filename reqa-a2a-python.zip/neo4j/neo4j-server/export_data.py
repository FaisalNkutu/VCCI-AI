

import json
from neo4j import GraphDatabase

# Configuration
URI = "bolt://localhost:7687"
AUTH = ("neo4j", "secretpassword")  # Change to your credentials
DATABASE = "neo4j"



output_file = "full_database_export.json"
query = 'CALL apoc.export.json.all(  "full_database_export.json" , {}  )'

def export_neo4j_database(driver, file_name):
    with driver.session() as session:
        result = session.run(query, file=file_name)
        record = result.single()
        print(f"Export successful: {record['file']} ({record['nodes']} nodes, {record['relationships']} relationships exported)")



def export_neo4j_database_file( file_name, uri, auth):

        driver = GraphDatabase.driver(uri, auth=auth)
                
        try:
                export_neo4j_database(driver, file_name)
        finally:
                driver.close()


if __name__=="__main__":
        export_neo4j_database_file( output_file, URI, AUTH  )

