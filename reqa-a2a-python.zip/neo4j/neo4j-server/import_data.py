

import json
import traceback
from neo4j import GraphDatabase, exceptions

# Configuration
URI = "bolt://localhost:7687"
AUTH = ("neo4j", "secretpassword")  # Change to your credentials


output_file = "full_database_export.json"
query = 'CALL apoc.import.json("file:///full_database_export.json", {batchSize: 5000, unwindBatchSize: 5000})'

def import_neo4j_database(driver, file_name):
    with driver.session() as session:

        try:
                result = session.run( "MATCH (n) DETACH DELETE n" )
                result = session.run( "CREATE CONSTRAINT FOR (n:Child) REQUIRE n.neo4jImportId IS UNIQUE;" )
                result = session.run( "CREATE CONSTRAINT FOR (n:Table) REQUIRE n.neo4jImportId IS UNIQUE;" )
                result = session.run( "CREATE CONSTRAINT FOR (n:Parent) REQUIRE n.neo4jImportId IS UNIQUE;" )
        except exceptions.ClientError: 
                print("Warning: Constraint Already Exists!")
        except Exception as e:
                traceback.print_exc()
     

        result = session.run(query, file=file_name)
        record = result.single()
        print(f"Import successful: {record['file']} ({record['nodes']} nodes, {record['relationships']} relationships exported)")






def import_neo4j_database_file( fname, uri, auth ):

        print(f"=================> import_neo4j_database_file({fname},{uri},{auth})")

        driver = GraphDatabase.driver(uri, auth=auth)            
        try:
                import_neo4j_database(driver, fname)
        finally:
                driver.close()



if __name__=="__main__":
        import_neo4j_database_file( output_file, URI, AUTH  )

