"""
MCP server for REQA-SQL — transport SSE, 100% local (127.0.0.1 only).

Start the server:
    python server.py
    # listening on http://127.0.0.1:8081/sse

Register in Claude Desktop (~/.config/claude/claude_desktop_config.json)
or Claude Code (.claude/settings.json) :

    {
      "mcpServers": {
        "reqa-sql": {
          "url": "http://127.0.0.1:8081/sse"
        }
      }
    }

Any local MCP-compatible client (Cursor, Zed, Continue, Windsurf…)
can connect to the same URL. No data ever leaves the machine.

Tools exposed:
    ingest_schema(sql_file)  — parse + load schema into Qdrant (run once)
    text_to_sql(question)    — full pipeline: NL → SQL → execution → answer
"""

import json
from pathlib import Path

from mcp.server.fastmcp import FastMCP
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct

from config.settings import get_settings
from agent.embedder import Embedder

settings = get_settings()
from agent.schema_rag import SchemaRAG
from agent.sql_generator import SQLGenerator
from agent.static_check import StaticChecker
from agent.dry_run import DryRunner
from agent.executor import Executor
from agent.renderer import Renderer
from agent.circuit_breaker import CircuitBreaker
from agent.pipeline import Pipeline
from ingest import parse_sql_to_documents


mcp = FastMCP("reqa-sql", description="Text-to-SQL agent for MariaDB databases")


# ── LLM factory ───────────────────────────────────────────────────────────────

def _build_llm(model: str):
    if settings.LLM_PROVIDER == "ollama":
        from agent.llm.ollama_llm import OllamaLLM
        return OllamaLLM(model=model, base_url=settings.ollama_base_url)
    if settings.LLM_PROVIDER == "openai_compat":
        from agent.llm.openai_compat import OpenAICompatLLM
        return OpenAICompatLLM(
            model=settings.OPENAI_COMPAT_MODEL,
            base_url=settings.OPENAI_COMPAT_BASE_URL,
            api_key=settings.OPENAI_COMPAT_API_KEY,
        )
    raise ValueError(f"Unknown LLM_PROVIDER: {settings.LLM_PROVIDER!r}. Use 'ollama' or 'openai_compat'.")


# ── Singletons (initialised once at server startup) ───────────────────────────

_db_params = dict(
    host=settings.DB_HOST,
    port=settings.DB_PORT,
    database=settings.DB_NAME,
    user=settings.DB_USER,
    password=settings.DB_PASSWORD,
)

_embedder   = Embedder()
_qdrant     = QdrantClient(host=settings.QDRANT_HOST, port=settings.QDRANT_PORT)
_sql_llm    = _build_llm(settings.ollama_sql_model)
_render_llm = _build_llm(settings.ollama_render_model)

_pipeline = Pipeline(
    schema_rag      = SchemaRAG(_qdrant, _embedder, settings.QDRANT_COLLECTION, settings.top_k_tables),
    sql_generator   = SQLGenerator(_sql_llm, settings.max_rows),
    static_checker  = StaticChecker(),
    dry_runner      = DryRunner(_db_params),
    executor        = Executor(_db_params),
    renderer        = Renderer(_render_llm),
    circuit_breaker = CircuitBreaker(settings.circuit_breaker_threshold),
    max_retries     = settings.max_sql_retries,
)


# ── MCP Tools ─────────────────────────────────────────────────────────────────

@mcp.tool()
def ingest_schema(sql_file: str) -> str:
    """Parse a .sql schema file and load table descriptions into Qdrant.
    Must be called once (or after schema changes) before using text_to_sql.

    Args:
        sql_file: Absolute path to the SQL file containing CREATE TABLE statements.

    Returns:
        JSON with success status, number of tables ingested, and their names.
    """
    sql_content = Path(sql_file).read_text(encoding="utf-8")
    documents = parse_sql_to_documents(sql_content)

    if not documents:
        return json.dumps({
            "success": False,
            "error": "No CREATE TABLE statements found — check your SQL file.",
        })

    table_names = [d["table"] for d in documents]

    if _qdrant.collection_exists(settings.QDRANT_COLLECTION):
        _qdrant.delete_collection(settings.QDRANT_COLLECTION)
    _qdrant.create_collection(
        collection_name=settings.QDRANT_COLLECTION,
        vectors_config=VectorParams(size=Embedder.DIMENSION, distance=Distance.COSINE),
    )

    points = [
        PointStruct(id=i, vector=_embedder.embed(doc["description"]), payload=doc)
        for i, doc in enumerate(documents)
    ]
    _qdrant.upsert(collection_name=settings.QDRANT_COLLECTION, points=points)

    return json.dumps({
        "success":         True,
        "tables_ingested": len(points),
        "table_names":     table_names,
        "collection":      settings.QDRANT_COLLECTION,
    }, ensure_ascii=False, indent=2)


@mcp.tool()
def text_to_sql(question: str) -> str:
    """Convert a natural language question into SQL, execute it against MariaDB,
    and return a human-readable answer together with the generated query.

    Args:
        question: A question in natural language about the database content.

    Returns:
        JSON with answer, generated SQL, row count, attempts, and any error.
    """
    result = _pipeline.run(question)
    return json.dumps({
        "success":   result.success,
        "answer":    result.answer,
        "sql":       result.sql,
        "row_count": result.row_count,
        "attempts":  result.attempts,
        "error":     result.error,
    }, ensure_ascii=False, indent=2)


@mcp.tool()
def switch_database(
    host: str,
    database: str,
    user: str,
    password: str,
    port: int = 3306,
    sql_file: str = "",
) -> str:
    """Switch the active database connection at runtime without restarting the server.
    Optionally ingest a new schema file in the same call.

    Args:
        host:     Database host (e.g. "localhost" or "192.168.1.10").
        database: Database name.
        user:     Database user.
        password: Database password.
        port:     Database port (default 3306).
        sql_file: Optional absolute path to a .sql schema file to ingest immediately.

    Returns:
        JSON with success status, active connection info, and optional ingestion result.
    """
    global _db_params, _pipeline

    new_params = dict(host=host, port=port, database=database, user=user, password=password)

    # Validate connection before committing the switch
    try:
        import pymysql
        conn = pymysql.connect(**new_params)
        conn.close()
    except Exception as e:
        return json.dumps({"success": False, "error": f"Connection failed: {e}"})

    _db_params = new_params
    _pipeline = Pipeline(
        schema_rag      = SchemaRAG(_qdrant, _embedder, settings.QDRANT_COLLECTION, settings.top_k_tables),
        sql_generator   = SQLGenerator(_sql_llm, settings.max_rows),
        static_checker  = StaticChecker(),
        dry_runner      = DryRunner(_db_params),
        executor        = Executor(_db_params),
        renderer        = Renderer(_render_llm),
        circuit_breaker = CircuitBreaker(settings.circuit_breaker_threshold),
        max_retries     = settings.max_sql_retries,
    )

    result = {
        "success":      True,
        "connected_to": {"host": host, "port": port, "database": database},
    }

    if sql_file:
        result["schema_ingestion"] = json.loads(ingest_schema(sql_file))

    return json.dumps(result, ensure_ascii=False, indent=2)


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    # SSE on 127.0.0.1: compatible with all local MCP clients, never exposed outside the machine.
    mcp.run(transport="sse", host="127.0.0.1", port=8081)
