"""Build a backward-compatible, validated production KB.

The source KB remains untouched.  Physical facts are checked against the
authoritative populated LN25 DDL and additional reasoning metadata is added
to each table entry.
"""
import json, re
from pathlib import Path

SOURCE = Path(r"C:\Users\r.hassan\Desktop\New folder (6)\kb_updated_rezwan.json")
SCHEMA = Path("RAG/files/new_schema_withln25data.sql")
OUTPUT = Path("RAG/KB_production_rezwan.json")

def read_schema(path):
    tables, current, cols = {}, None, set()
    for line in path.open(encoding="utf-8", errors="ignore"):
        m = re.match(r"CREATE TABLE(?: IF NOT EXISTS)? [`\"]?(\w+)[`\"]?\s*\(", line, re.I)
        if m:
            current, cols = m.group(1), set(); continue
        if current:
            m = re.match(r"\s*`(\w+)`\s+", line)
            if m: cols.add(m.group(1))
            if re.match(r"\s*\)\s*(ENGINE|;)", line, re.I):
                tables[current] = cols; current = None
    return tables

def rules_for(table):
    t = table.lower()
    rules = []
    if t in {"fire_event", "act", "obj_item_stat", "obj_item_point_loc"} or "fire" in t:
        rules.append({"intent": "fire-event analysis", "guidance": "Use act for event time and firing organisation, fire_event for fire attributes, and time-aware obj_item_stat for hostility; do not infer the firing organisation from the target.", "provenance": "application/domain guidance", "confidence": "high"})
    if t in {"holding", "mat_type", "obj_item", "obj_type", "unit"}:
        rules.append({"intent": "inventory or combat-power analysis", "guidance": "Use historical holding rows and material/object relationships; apply the documented eligibility and aggregation rule before calculating a metric.", "provenance": "application/domain guidance", "confidence": "medium"})
    return rules

def patterns_for(table):
    if table == "fire_event":
        return [{"intent": "direct or indirect fire", "required_tables": ["act", "fire_event"], "supporting_tables": ["obj_item", "obj_item_stat"], "notes": "Direct/indirect classification is fire_event.cat_code or the validated event label; friendly/hostile status is the latest status at event time."}]
    if table == "holding":
        return [{"intent": "latest inventory or combat power", "required_tables": ["holding", "mat_type"], "supporting_tables": ["obj_item", "obj_type", "unit"], "notes": "Use the latest row at or before the requested time; do not treat cumulative quantities as independent events."}]
    return []

def main():
    source = json.loads(SOURCE.read_text(encoding="utf-8"))
    physical = read_schema(SCHEMA)
    out = {}
    for table, entry in source.items():
        e = dict(entry)
        kb_cols = set((entry.get("columns") or {}).keys())
        actual_cols = physical.get(table, set())
        e["schema"] = {"table": table, "columns_source": "RAG/files/new_schema_withln25data.sql", "schema_validated": table in physical, "invalid_columns": sorted(kb_cols - actual_cols)}
        e["semantic"] = {"purpose": entry.get("description", ""), "aliases": sorted(set(entry.get("domain", []) + entry.get("keywords", []))), "provenance": "KB source; validate domain claims with SME"}
        e["reasoning_rules"] = rules_for(table)
        e["query_patterns"] = patterns_for(table)
        e["retrieval"] = {"document_types": ["table", "columns", "relationships"] + (["query_pattern"] if patterns_for(table) else []), "lexical_terms": sorted(set([table] + entry.get("domain", []) + entry.get("keywords", [])))}
        e["provenance"] = {"source_kb": str(SOURCE), "physical_schema": str(SCHEMA), "status": "schema-validated", "semantic_validation": "SME/application validation required"}
        out[table] = e
    OUTPUT.write_text(json.dumps(out, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"wrote {OUTPUT} ({len(out)} tables); schema tables: {len(physical)}")

if __name__ == "__main__": main()
