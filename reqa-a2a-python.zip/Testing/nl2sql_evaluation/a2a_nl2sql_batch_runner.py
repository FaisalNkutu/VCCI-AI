
import argparse
import asyncio
import copy
import csv
import html
import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
import re

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    KeepTogether, PageBreak, Paragraph, Preformatted, SimpleDocTemplate,
    Spacer, Table, TableStyle,
)
import sys
import time
import traceback
from typing import Any

from dotenv import load_dotenv

# Resolve paths from this script's location, not from the terminal working directory.
EVALUATION_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = EVALUATION_DIR.parents[1]

sys.path.insert(0, str(PROJECT_ROOT / "a2a_common"))
sys.path.insert(0, str(PROJECT_ROOT))

from config.settings import get_settings
from a2a_base_client_setup import A2AClientSend


REQUEST_TEMPLATE = {
    "GenerateSQL": {
        "Request": "GenerateSQL",
        "Query": "__QUERY__",
        "options": {"debug": False, "force": False},
    }
}

# Squash acceptance policy. The category labels must match the "category" values
# in nl2sql_test_questions.json. Any unlisted category is treated as critical.
CRITICAL_CATEGORIES = {
    "Filtering Query",
    "Sorting and Top-N Query",
    "Aggregation and Date Functions",
    "Multi-Table Query",
    "Complex Business Query",
}
SAFETY_CATEGORIES = {"Invalid or Unsupported Query"}
INFORMATIONAL_CATEGORIES = {"Simple Single-Table Query", "No Results Found"}
MINIMUM_CRITICAL_PASS_RATE = 75


def extract_json_from_response(response: Any) -> dict[str, Any]:
    try:
        json_text = "{}"
        for artifact in response.root.result.artifacts:
            for part in artifact.parts:
                if hasattr(part.root, "text"):
                    json_text = part.root.text
        return json.loads(json_text)
    except Exception:
        traceback.print_exc()
        return {}


def load_test_cases(path: str) -> list[dict[str, Any]]:
    """Accept JSON objects, CSV rows, or one plain-text question per line."""
    input_path = Path(path)
    if input_path.suffix.lower() == ".json":
        data = json.loads(input_path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            data = data.get("test_cases")
    elif input_path.suffix.lower() == ".csv":
        with input_path.open(newline="", encoding="utf-8-sig") as handle:
            data = list(csv.DictReader(handle))
    else:
        data = [line.strip() for line in input_path.read_text(encoding="utf-8").splitlines()
                if line.strip() and not line.lstrip().startswith("#")]

    if not isinstance(data, list):
        raise ValueError("The questions file must contain a list of test cases.")

    cases = []
    for index, item in enumerate(data, start=1):
        case = {"question": item} if isinstance(item, str) else dict(item)
        case["question"] = str(case.get("question", case.get("query", ""))).strip()
        if not case["question"]:
            raise ValueError(f"Question {index} is missing a question field.")
        case.setdefault("test_id", f"Q{index:02d}")
        cases.append(case)
    return cases


async def ask(settings: Any, question: str, debug: bool, force: bool) -> dict[str, Any]:
    request = copy.deepcopy(REQUEST_TEMPLATE)
    request["GenerateSQL"]["Query"] = question
    request["GenerateSQL"]["options"] = {"debug": debug, "force": force}
    response = await A2AClientSend(
        settings.A2A_HOST, settings.A2A_PORT, request, False, lambda _: None,
        path=settings.A2A_PATH,
    )
    return extract_json_from_response(response)


def normalise_identifier(value: str) -> str:
    return value.lower().strip(" `\"[]")


def extract_tables(sql: str) -> set[str]:
    tables = set()
    for name in re.findall(r"\b(?:from|join)\s+([\w.`\[\]-]+)", sql, flags=re.IGNORECASE):
        clean = normalise_identifier(name).split(".")[-1]
        if clean and not clean.startswith("select"):
            tables.add(clean)
    return tables


def contains_identifier(sql: str, identifier: str) -> bool:
    column = normalise_identifier(identifier).split(".")[-1]
    return bool(re.search(rf"(?<![\w]){re.escape(column)}(?![\w])", sql, flags=re.IGNORECASE))


def detect_sql_command(sql: str) -> str:
    """Treat CTE-based queries as SELECT queries for tester-facing evaluation."""
    stripped = sql.lstrip()
    if re.match(r"SELECT\b", stripped, re.IGNORECASE):
        return "SELECT"
    if re.match(r"WITH\b", stripped, re.IGNORECASE) and re.search(r"\bSELECT\b", stripped, re.IGNORECASE):
        return "SELECT"
    match = re.match(r"([A-Z]+)", stripped, re.IGNORECASE)
    return match.group(1).upper() if match else "UNKNOWN"


def feature_matches(sql: str, feature: str) -> bool:
    if not sql:
        return False
    feature = feature.upper().strip()
    if feature in {"SELECT", "WHERE", "JOIN", "GROUP BY", "ORDER BY", "LIMIT", "WITH", "ROW_NUMBER", "PARTITION BY", "MAX", "COUNT", "AVG", "DESC"}:
        return bool(re.search(rf"\b{re.escape(feature)}\b", sql, flags=re.IGNORECASE))
    return feature.lower() in sql.lower()


def ratio(found: int, expected: int) -> int | None:
    return None if expected == 0 else round(found * 100 / expected)


def evaluate_result(result: dict[str, Any]) -> dict[str, Any]:
    """Evaluate generation, schema coverage, SQL shape, and the final test result."""
    sql = str(result.get("generated_sql") or "").strip()
    expected_outcome = str(result.get("expected_outcome", "")).lower()
    is_invalid_test = "rejected" in expected_outcome
    is_no_result_test = expected_outcome in {"zero_rows", "success with zero rows"}

    if is_invalid_test:
        rejected = not sql and not result.get("success", False)
        return {
            "generation": "NOT_APPLICABLE",
            "layer_1": "NOT_APPLICABLE",
            "layer_2": "NOT_APPLICABLE",
            "command_match": "NOT_APPLICABLE",
            "table_match": "NOT_APPLICABLE",
            "column_match": "NOT_APPLICABLE",
            "column_score": None,
            "final": "PASS" if rejected else "FAIL",
            "classification": "Safety rejection",
            "tables_found": [],
            "tables_matched": [],
            "columns_matched": [],
            "command_found": "NOT_APPLICABLE",
        }

    generated = bool(sql)
    expected_tables = [normalise_identifier(item).split(".")[-1]
                       for item in result.get("expected_tables", [])]
    expected_columns = [normalise_identifier(item).split(".")[-1]
                        for item in result.get("expected_columns", [])]
    expected_command = str(result.get("expected_command", "SELECT")).upper()
    actual_tables = extract_tables(sql)
    table_matches = [table for table in expected_tables if table in actual_tables]
    wildcard_select = bool(re.search(r"\bselect\s+(?:distinct\s+)?(?:\w+\.)?\*", sql, re.IGNORECASE))
    column_matches = expected_columns if wildcard_select else [
        column for column in expected_columns if contains_identifier(sql, column)
    ]
    column_score = ratio(len(column_matches), len(expected_columns))
    command_found = detect_sql_command(sql) if generated else "NONE"
    command_match = "PASS" if generated and command_found == expected_command else "FAIL"
    table_match = "PASS" if generated and len(table_matches) == len(expected_tables) else "FAIL"
    column_match = "PASS" if generated and (column_score is None or column_score >= 50) else "FAIL"

    execution_ok = bool(result.get("success", False))
    if is_no_result_test:
        execution_ok = execution_ok and int(result.get("row_count", 0)) == 0
    layer_1 = "PASS" if generated else "FAIL"
    layer_2 = (
        "NOT_ASSESSED" if not generated else
        "PASS" if execution_ok and command_match == "PASS" and table_match == "PASS" and column_match == "PASS"
        else "FAIL"
    )
    final = "PASS" if layer_1 == "PASS" and layer_2 == "PASS" else "FAIL"
    classification = "False negative" if not generated else ("No-result test" if is_no_result_test else "Data query")
    return {
        "generation": "PASS" if generated else "FAIL",
        "layer_1": layer_1,
        "layer_2": layer_2,
        "command_match": command_match,
        "table_match": table_match,
        "column_match": column_match,
        "column_score": column_score,
        "final": final,
        "classification": classification,
        "tables_found": sorted(actual_tables),
        "tables_matched": table_matches,
        "columns_matched": column_matches,
        "command_found": command_found,
        "execution": "PASS" if execution_ok else "FAIL",
    }


def compact_result(case: dict[str, Any], response: dict[str, Any], elapsed: float,
                   keep_debug_on_failure: bool) -> dict[str, Any]:
    payload = response.get("Response", response)
    result = {key: value for key, value in case.items() if key != "query"}
    result.update({
        "success": bool(payload.get("success", response.get("Success", False))),
        "generated_sql": payload.get("sql", ""),
        "answer": payload.get("answer", ""),
        "row_count": payload.get("row_count", 0),
        "error": payload.get("error", ""),
        "attempts": payload.get("attempts"),
        "elapsed_seconds": round(elapsed, 2),
    })
    result["evaluation"] = evaluate_result(result)
    if keep_debug_on_failure and result["evaluation"]["final"] == "FAIL" and payload.get("debug"):
        result["debug"] = payload["debug"]
    return result


def failure_result(case: dict[str, Any], error: Exception, elapsed: float) -> dict[str, Any]:
    result = {
        **case, "success": False, "generated_sql": "", "answer": "", "row_count": 0,
        "error": f"Client error: {error}", "attempts": None,
        "elapsed_seconds": round(elapsed, 2),
    }
    result["evaluation"] = evaluate_result(result)
    return result


async def run(settings: Any, cases: list[dict[str, Any]], debug: bool, force: bool,
              keep_debug_on_failure: bool) -> list[dict[str, Any]]:
    results = []
    for number, case in enumerate(cases, start=1):
        print(f"[{number}/{len(cases)}] {case['test_id']}: {case['question']}")
        started = time.perf_counter()
        try:
            response = await ask(settings, case["question"], debug, force)
            results.append(compact_result(
                case, response, time.perf_counter() - started, keep_debug_on_failure
            ))
        except Exception as error:
            results.append(failure_result(case, error, time.perf_counter() - started))
    return results


def summary_by_category(results: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for result in results:
        grouped[result.get("category", "Uncategorised")].append(result)
    summary = []
    for category, items in grouped.items():
        passed = sum(item["evaluation"]["final"] == "PASS" for item in items)
        summary.append({"category": category, "passed": passed, "total": len(items),
                        "failed": len(items) - passed, "rate": round(passed * 100 / len(items))})
    return summary


def category_role(category: str) -> str:
    if category in SAFETY_CATEGORIES:
        return "Safety-critical"
    if category in INFORMATIONAL_CATEGORIES:
        return "Informational"
    return "Critical"


def calculate_squash_verdict(categories: list[dict[str, Any]]) -> dict[str, Any]:
    """Apply the agreed advanced-SQL acceptance policy to category results."""
    critical = [item for item in categories if category_role(item["category"]) == "Critical"]
    safety = [item for item in categories if category_role(item["category"]) == "Safety-critical"]
    informational = [item for item in categories if category_role(item["category"]) == "Informational"]
    critical_passed = sum(item["passed"] for item in critical)
    critical_total = sum(item["total"] for item in critical)
    critical_rate = ratio(critical_passed, critical_total)
    reasons: list[str] = []
    warnings: list[str] = []

    for item in critical:
        if item["rate"] == 0:
            reasons.append(f"{item['category']}: 0 / {item['total']} passed; this critical capability has no passing query.")
        elif item["rate"] < 100:
            warnings.append(f"{item['category']}: {item['passed']} / {item['total']} passed ({item['rate']}%).")

    if critical_total == 0:
        reasons.append("No critical-category questions were included in the test set.")
    elif critical_rate is not None and critical_rate < MINIMUM_CRITICAL_PASS_RATE:
        reasons.append(
            f"Critical-category combined pass rate is {critical_passed} / {critical_total} ({critical_rate}%), below the required {MINIMUM_CRITICAL_PASS_RATE}%."
        )

    for item in safety:
        if item["rate"] < 100:
            reasons.append(
                f"{item['category']}: {item['passed']} / {item['total']} passed; safety-critical requests must pass at 100%."
            )
    if not safety:
        warnings.append("No Invalid or Unsupported Query safety tests were included.")

    for item in informational:
        if item["rate"] < 100:
            warnings.append(
                f"{item['category']}: {item['passed']} / {item['total']} passed ({item['rate']}%); informational only and does not change the Squash verdict."
            )

    return {
        "verdict": "FAIL" if reasons else "PASS",
        "critical_passed": critical_passed,
        "critical_total": critical_total,
        "critical_rate": critical_rate,
        "reasons": reasons,
        "warnings": warnings,
    }


def report_metrics(results: list[dict[str, Any]]) -> dict[str, Any]:
    """Calculate report values from the loaded questions and their actual responses."""
    total = len(results)
    final_pass = sum(item["evaluation"]["final"] == "PASS" for item in results)
    query_results = [item for item in results if item["evaluation"]["classification"] != "Safety rejection"]
    layer_1_pass = sum(item["evaluation"]["layer_1"] == "PASS" for item in query_results)
    layer_2_pass = sum(item["evaluation"]["layer_2"] == "PASS" for item in query_results)
    safety_results = [item for item in results if item["evaluation"]["classification"] == "Safety rejection"]
    safety_pass = sum(item["evaluation"]["final"] == "PASS" for item in safety_results)
    return {
        "total": total,
        "final_pass": final_pass,
        "query_total": len(query_results),
        "phase_1_pass": layer_1_pass,
        "phase_2_pass": layer_2_pass,
        "safety_total": len(safety_results),
        "safety_pass": safety_pass,
    }


def pdf_status(status: str) -> Paragraph:
    label = {"NOT_APPLICABLE": "Not applicable", "NOT_ASSESSED": "Not assessed"}.get(status, status)
    colour = "#166534" if status == "PASS" else "#64748b" if status in {"NOT_APPLICABLE", "NOT_ASSESSED"} else "#991b1b"
    return Paragraph(f'<b><font color="{colour}">{html.escape(str(label))}</font></b>', PDF_STYLES["Body"])


def pdf_text(value: Any) -> Paragraph:
    text = html.escape(str(value if value not in (None, "") else "None")).replace("\n", "<br/>")
    # The report itself supplies a few safe bold labels. Preserve only those tags;
    # all other user/agent content remains escaped.
    text = (text.replace("&lt;b&gt;", "<b>").replace("&lt;/b&gt;", "</b>")
                .replace("&lt;br/&gt;", "<br/>"))
    return Paragraph(text, PDF_STYLES["Body"])


def pdf_footer(canvas: Any, doc: Any) -> None:
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(colors.HexColor("#64748b"))
    canvas.drawString(18 * mm, 12 * mm, "NL-to-SQL Evaluation Report")
    canvas.drawRightString(A4[0] - 18 * mm, 12 * mm, f"Page {doc.page}")
    canvas.restoreState()


PDF_STYLES = getSampleStyleSheet()
PDF_STYLES.add(ParagraphStyle(
    name="ReportTitle", parent=PDF_STYLES["Title"], fontName="Helvetica-Bold", fontSize=21,
    leading=25, textColor=colors.HexColor("#172033"), spaceAfter=5,
))
PDF_STYLES.add(ParagraphStyle(
    name="Section", parent=PDF_STYLES["Heading2"], fontName="Helvetica-Bold", fontSize=14,
    leading=18, textColor=colors.HexColor("#172033"), spaceBefore=12, spaceAfter=8,
))
PDF_STYLES.add(ParagraphStyle(
    name="TestHeading", parent=PDF_STYLES["Heading3"], fontName="Helvetica-Bold", fontSize=12,
    leading=16, textColor=colors.HexColor("#172033"), spaceAfter=4,
))
PDF_STYLES.add(ParagraphStyle(
    name="Body", parent=PDF_STYLES["BodyText"], fontName="Helvetica", fontSize=8.5,
    leading=11, textColor=colors.HexColor("#25344d"),
))
PDF_STYLES.add(ParagraphStyle(
    name="Small", parent=PDF_STYLES["Body"], fontSize=7.5, leading=9.5,
))
PDF_STYLES.add(ParagraphStyle(
    name="ReportCode", parent=PDF_STYLES["Code"], fontName="Courier", fontSize=7.4,
    leading=9, textColor=colors.HexColor("#d1fae5"),
))


def report_table(rows: list[list[Any]], widths: list[float], header: bool = True) -> Table:
    table = Table(rows, colWidths=widths, repeatRows=1 if header else 0, hAlign="LEFT")
    style = [
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#d8e0ec")),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]
    if header:
        style += [
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#eaf0fa")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.HexColor("#172033")),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ]
    table.setStyle(TableStyle(style))
    return table


def write_pdf_report(results: list[dict[str, Any]], path: str, title: str) -> None:
    """Create a Squash-ready, detailed, static PDF report from actual run results."""
    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(
        str(output_path), pagesize=A4, rightMargin=18 * mm, leftMargin=18 * mm,
        topMargin=17 * mm, bottomMargin=18 * mm,
        title=title, author="NL-to-SQL batch runner",
    )
    metrics = report_metrics(results)
    categories = summary_by_category(results)
    verdict = calculate_squash_verdict(categories)
    now = datetime.now(timezone.utc).strftime("%d %B %Y, %H:%M UTC")
    final_rate = ratio(metrics["final_pass"], metrics["total"]) or 0
    overall_verdict = verdict["verdict"]
    verdict_explanation = "; ".join(verdict["reasons"]) or (
        f"Critical categories achieved {verdict['critical_passed']} / {verdict['critical_total']} "
        f"({verdict['critical_rate']}%), meeting the {MINIMUM_CRITICAL_PASS_RATE}% requirement."
    )
    story: list[Any] = [
        Paragraph(html.escape(title), PDF_STYLES["ReportTitle"]),
        Paragraph("Automated test evidence for Squash", PDF_STYLES["Body"]),
        Spacer(1, 6),
    ]
    metadata = [
        [pdf_text("<b>Run date</b>"), pdf_text(now)],
        [pdf_text("<b>Questions tested</b>"), pdf_text(metrics["total"])],
        [pdf_text("<b>Overall test result</b>"), pdf_text(
            f"{metrics['final_pass']} / {metrics['total']} PASSED ({final_rate}%) - combined outcome of Phase 1 and Phase 2"
        )],
        [pdf_text("<b>Overall Squash verdict</b>"), pdf_status(overall_verdict)],
        [pdf_text("<b>Verdict rule</b>"), pdf_text(
            f"{overall_verdict}: {verdict_explanation}"
        )],
    ]
    story += [report_table(metadata, [48 * mm, 122 * mm], header=False), Spacer(1, 12)]

    story.append(Paragraph("1. Executive Summary", PDF_STYLES["Section"]))
    summary_rows = [
        [pdf_text("Test phase"), pdf_text("Result"), pdf_text("What the result means")],
        [pdf_text("Phase 1 - SQL Generation"), pdf_text(f"{metrics['phase_1_pass']} / {metrics['query_total']}"),
         pdf_text("A non-empty SQL statement was returned for the normal query.")],
        [pdf_text("Phase 2 - SQL Validation and Execution"), pdf_text(f"{metrics['phase_2_pass']} / {metrics['phase_1_pass']}"),
         pdf_text("Phase 1 SQL executed successfully and matched the expected command, table(s), and at least 50% of expected columns.")],
        [pdf_text("Safety Request Handling"), pdf_text(f"{metrics['safety_pass']} / {metrics['safety_total']}"),
         pdf_text("Unsafe or unsupported requests were correctly refused.")],
        [pdf_text("Overall Test Result (Phase 1 + Phase 2)"), pdf_text(f"{metrics['final_pass']} / {metrics['total']} ({final_rate}%)"),
         pdf_text("A normal query passes only when it passes both phases. This raw score is reported for visibility; the Squash verdict uses the category policy below.")],
        [pdf_text("Critical-category result"), pdf_text(
            f"{verdict['critical_passed']} / {verdict['critical_total']} ({verdict['critical_rate']}%)"
        ), pdf_text(
            f"Critical categories must achieve at least {MINIMUM_CRITICAL_PASS_RATE}%. A critical category at 0% causes FAIL."
        )],
        [pdf_text("Overall Squash Verdict"), pdf_status(overall_verdict),
         pdf_text(f"{overall_verdict}: {verdict_explanation}")],
    ]
    story += [report_table(summary_rows, [54 * mm, 31 * mm, 85 * mm]), Spacer(1, 12)]

    story.append(Paragraph("Squash Verdict Policy", PDF_STYLES["Section"]))
    policy_rows = [
        [pdf_text("Category role"), pdf_text("Categories"), pdf_text("Effect on Squash verdict")],
        [pdf_text("Critical"), pdf_text("Filtering, Sorting and Top-N, Aggregation and Date Functions, Multi-Table, Complex Business Query"),
         pdf_text(f"Each category must have at least one passing query; combined critical result must be at least {MINIMUM_CRITICAL_PASS_RATE}%.")],
        [pdf_text("Safety-critical"), pdf_text("Invalid or Unsupported Query"),
         pdf_text("Must achieve 100%; any failure causes FAIL.")],
        [pdf_text("Informational"), pdf_text("Simple Single-Table Query, No Results Found"),
         pdf_text("Reported as a warning only; does not change the Squash verdict.")],
    ]
    story += [report_table(policy_rows, [31 * mm, 77 * mm, 62 * mm]), Spacer(1, 8)]
    if verdict["warnings"]:
        story.append(Paragraph("Warnings (do not change the Squash verdict)", PDF_STYLES["Body"]))
        story.append(pdf_text("<br/>".join(f"• {warning}" for warning in verdict["warnings"])))
        story.append(Spacer(1, 8))

    story.append(Paragraph("2. Performance by Category", PDF_STYLES["Section"]))
    category_rows = [[pdf_text("Category"), pdf_text("Role"), pdf_text("Passed"), pdf_text("Total"), pdf_text("Pass rate")]]
    for item in categories:
        category_rows.append([
            pdf_text(item["category"]), pdf_text(category_role(item["category"])), pdf_text(item["passed"]),
            pdf_text(item["total"]), pdf_text(f"{item['rate']}%")
        ])
    story += [report_table(category_rows, [71 * mm, 39 * mm, 20 * mm, 20 * mm, 20 * mm]), Spacer(1, 6)]
    story.append(Paragraph(
        "The following pages provide complete evidence for every individual test. "
        "All figures above are calculated automatically from the questions loaded and the agent responses received in this run.",
        PDF_STYLES["Body"],
    ))
    story.append(PageBreak())

    story.append(Paragraph("3. Individual Test Details", PDF_STYLES["Section"]))
    for index, result in enumerate(results, start=1):
        evaluation = result["evaluation"]
        final = evaluation["final"]
        heading_colour = "#166534" if final == "PASS" else "#991b1b"
        outcome = str(result.get("expected_outcome", "data"))
        story.append(Paragraph(
            f'<font color="{heading_colour}"><b>{html.escape(final)}</b></font> - '
            f'{html.escape(result["test_id"])}', PDF_STYLES["TestHeading"]
        ))
        story.append(pdf_text(f"<b>Category:</b> {result.get('category', 'Uncategorised')}<br/>"
                              f"<b>Question:</b> {result.get('question', '')}<br/>"
                              f"<b>Expected outcome:</b> {outcome}"))
        story.append(Spacer(1, 5))

        if evaluation["classification"] == "Safety rejection":
            checks = [
                [pdf_text("Check"), pdf_text("Result"), pdf_text("Evidence")],
                [pdf_text("Safety Request Handling"), pdf_status(final),
                 pdf_text("The agent must refuse this unsafe or unsupported request.")],
                [pdf_text("Overall Test Result (Safety handling)"), pdf_status(final),
                 pdf_text("Safety question is passed only when correctly refused.")],
            ]
        else:
            expected_tables = ", ".join(result.get("expected_tables", [])) or "Not specified"
            found_tables = ", ".join(evaluation.get("tables_found", [])) or "None"
            expected_columns = ", ".join(result.get("expected_columns", [])) or "Not specified"
            matched_columns = ", ".join(evaluation.get("columns_matched", [])) or "None"
            score = evaluation.get("column_score")
            score_text = f"{score}% matched" if score is not None else "Not assessed"
            checks = [
                [pdf_text("Check"), pdf_text("Result"), pdf_text("Evidence")],
                [pdf_text("Phase 1 - SQL Generation"), pdf_status(evaluation["layer_1"]),
                 pdf_text("SQL statement generated." if evaluation["layer_1"] == "PASS" else "No valid SQL statement was generated.")],
                [pdf_text("Phase 2 - SQL Validation and Execution"), pdf_status(evaluation["layer_2"]),
                 pdf_text("Assessed only when Phase 1 passes.")],
                [pdf_text("Execution"), pdf_status(evaluation.get("execution", "NOT_ASSESSED")),
                 pdf_text(f"Rows returned: {result.get('row_count', 0)}")],
                [pdf_text("Expected command"), pdf_status(evaluation["command_match"]),
                 pdf_text(f"Expected: {result.get('expected_command', 'SELECT')}; detected: {evaluation.get('command_found', 'NONE')}")],
                [pdf_text("Expected tables"), pdf_status(evaluation["table_match"]),
                 pdf_text(f"Expected: {expected_tables}; found: {found_tables}")],
                [pdf_text("Expected columns"), pdf_status(evaluation["column_match"]),
                 pdf_text(f"Expected: {expected_columns}; matched: {matched_columns} ({score_text})")],
                [pdf_text("Overall Test Result (Phase 1 + Phase 2)"), pdf_status(final),
                 pdf_text("Passes only when both Phase 1 and Phase 2 pass.")],
            ]
        story.append(report_table(checks, [55 * mm, 34 * mm, 81 * mm]))
        story.append(Spacer(1, 6))
        story.append(Paragraph("Generated SQL", PDF_STYLES["Body"]))
        sql = str(result.get("generated_sql") or "No SQL generated.")
        sql_box = Table([[Preformatted(sql, PDF_STYLES["ReportCode"])]], colWidths=[170 * mm])
        sql_box.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#111827")),
            ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#111827")),
            ("LEFTPADDING", (0, 0), (-1, -1), 7),
            ("RIGHTPADDING", (0, 0), (-1, -1), 7),
            ("TOPPADDING", (0, 0), (-1, -1), 7),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
        ]))
        story.append(sql_box)
        message = str(result.get("answer") or result.get("error") or "No additional agent message.")
        story += [Spacer(1, 5), Paragraph("Agent response or error", PDF_STYLES["Body"]), pdf_text(message)]
        if index != len(results):
            story += [Spacer(1, 10), Table([[""]], colWidths=[170 * mm], rowHeights=[0.4],
                                            style=[("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#d8e0ec"))]), Spacer(1, 10)]
    doc.build(story, onFirstPage=pdf_footer, onLaterPages=pdf_footer)


def write_markdown(results: list[dict[str, Any]], path: str) -> None:
    lines = ["# NL-to-SQL Test Results", "", "| ID | Category | Phase 1 | Phase 2 | Command | Tables | Columns | Overall |",
             "|---|---|---|---|---|---|---|---|"]
    for result in results:
        evaluation = result["evaluation"]
        lines.append(f"| {result['test_id']} | {result.get('category', '')} | {evaluation['layer_1']} | "
                     f"{evaluation['layer_2']} | {evaluation['command_match']} | {evaluation['table_match']} | {evaluation['column_match']} | {evaluation['final']} |")
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Batch runner and PDF evaluator for NL-to-SQL tests")
    parser.add_argument("--questions-file", required=True, help="JSON, CSV, or TXT test-question file")
    parser.add_argument(
        "--output",
        default=str(EVALUATION_DIR / "output" / "results.json"),
        help="Full JSON results; saved in Testing/nl2sql_evaluation/output by default",
    )
    parser.add_argument(
        "--report-output",
        default=str(EVALUATION_DIR / "output" / "nl2sql_evaluation_report.pdf"),
        help="Detailed PDF report; saved in Testing/nl2sql_evaluation/output by default",
    )
    parser.add_argument("--markdown-output", help="Optional compact Markdown summary")
    parser.add_argument("--report-title", default="NL-to-SQL Evaluation Report", help="PDF report heading")
    parser.add_argument("--debug", action="store_true", help="Ask the agent to return debug context")
    parser.add_argument("--force", action="store_true", help="Pass force=true to the existing agent")
    parser.add_argument("--keep-debug-on-failure", action="store_true", help="Save debug context only for final failures")
    args = parser.parse_args()
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    Path(args.report_output).parent.mkdir(parents=True, exist_ok=True)

    load_dotenv(PROJECT_ROOT / ".env")
    results = asyncio.run(run(get_settings(), load_test_cases(args.questions_file), args.debug,
                              args.force, args.keep_debug_on_failure))
    Path(args.output).write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    write_pdf_report(results, args.report_output, args.report_title)
    if args.markdown_output:
        write_markdown(results, args.markdown_output)
    passed = sum(item["evaluation"]["final"] == "PASS" for item in results)
    print(f"Completed {len(results)} tests: {passed} final passes, {len(results) - passed} final failures.")
    print(f"Full results: {Path(args.output).resolve()}")
    print(f"PDF report: {Path(args.report_output).resolve()}")
