"""Build evaluator-compatible LN25 expert question JSON from the source DOCX."""
import json, re
from pathlib import Path
from docx import Document

src = Path("Testing/nl2sql_evaluation/Question_Sets/ln25.docx")
out = Path("Testing/nl2sql_evaluation/Question_Sets/LN25_Expert_Test_Questions.json")
rows = Document(src).tables[0].rows
cases = []
for row in rows[1:]:
    category, question, reference_sql, rules = [c.text.strip() for c in row.cells]
    if not question or not reference_sql:
        continue
    question = re.sub(r"\s+", " ", question).strip().strip('“”"')
    question = re.sub(r"\s*\.\s*\.$", ".", question)
    question = re.sub(r"\s+Or\s+Which units are using M777 artillery systems in this exercise\??", "", question, flags=re.I)
    ctes = {x.lower() for x in re.findall(r"\b([A-Za-z_]\w*)\s+AS\s*\(", reference_sql, re.I)}
    tables = []
    for table in re.findall(r"\b(?:FROM|JOIN)\s+([A-Za-z_][A-Za-z0-9_]*)", reference_sql, re.I):
        if table.lower() in ctes:
            continue
        if table.lower() not in {x.lower() for x in tables}:
            tables.append(table)
    cols = []
    for col in re.findall(r"\b[A-Za-z_]\w*\.([A-Za-z_]\w*)", reference_sql):
        if col.lower() not in {x.lower() for x in cols}:
            cols.append(col)
    cases.append({
        "test_id": f"ln25_{len(cases)+1:02d}",
        "category": category.title() if category else "Administration / Exercise Validation",
        "question": question,
        "expected_command": "SELECT",
        "expected_tables": tables,
        "expected_columns": cols,
        "expected_outcome": "data",
        "reference_sql": reference_sql,
        "validation_note": "Expert-supplied reference; validate semantics and row availability against populated LN25 data.",
    })
payload = {
    "instructions": {
        "purpose": "Run expert LN25 natural-language questions against the populated LN25 database.",
        "schema_file": "RAG/files/new_schema_withln25data.sql",
        "footprint_rule": "Use the approximate 10 m x 10 m footprint only when the question explicitly requests a possible/approximate result; do not label it as exact MIDAS geometry.",
        "reference_sql_note": "reference_sql is expert-supplied guidance, not a hardcoded answer for the NL2SQL agent.",
        "comparison_note": "Use structural/execution results as evidence and manually review semantic correctness.",
    },
    "test_cases": cases,
}
# Keep evaluator expectations focused on answer-bearing fields.  Join keys and
# helper CTE columns are useful for review but should not make an otherwise
# correct alternative query fail automatically.
essential = {
    "ln25_01": ["name_txt", "total_qty", "on_hand_qty", "operat_cnt"],
    "ln25_02": ["time", "total_qty", "operat_cnt"],
    "ln25_03": ["name_txt", "operat_cnt"],
    "ln25_04": ["name_txt", "operat_cnt"],
    "ln25_05": ["act_id", "time", "name_txt", "target_oi_id", "target_lat", "target_lon"],
    "ln25_06": ["fire_event_id", "target_lat", "target_lon"],
    "ln25_07": ["fire_event_id", "target_lat", "target_lon"],
    "ln25_08": ["fire_event_id", "fire_type", "target_lat", "target_lon"],
    "ln25_09": ["fire_event_id", "fire_type", "target_lat", "target_lon"],
    "ln25_10": ["fire_event_id", "fire_type", "target_lat", "target_lon"],
    "ln25_11": ["act_id", "time", "name_txt", "target_oi_id"],
    "ln25_12": ["act_id", "time", "name_txt", "target_oi_id"],
    "ln25_13": ["name_txt", "fire_event_id"],
    "ln25_14": ["name_txt", "fire_event_id"],
    "ln25_15": ["fire_event_id"],
    "ln25_16": ["name_txt", "fire_event_id"],
    "ln25_17": ["unit_id", "name_txt", "fire_event_id"],
    "ln25_18": ["sim_offset_time"],
    "ln25_19": ["unit_id", "hostility_code"],
    "ln25_20": ["name_txt", "starting_qty", "current_qty"],
}
for case in payload["test_cases"]:
    case["expected_columns"] = essential.get(case["test_id"], case["expected_columns"])
out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"wrote {out} ({len(cases)} cases)")
