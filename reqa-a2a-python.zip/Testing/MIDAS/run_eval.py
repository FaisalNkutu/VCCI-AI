#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_eval.py (v2) -- Batch evaluation of the REQA text-to-SQL agent on a
set of natural-language queries (e.g. mds_queries.json: {"q1": "...", ...}),
WITH confidence scoring.

For each question the script drives the SAME public API the Streamlit UI
uses (POST /query/start then poll GET /query/status/{job_id}), so the
evaluation exercises the full production path: RAG, catalog, negative
pre-flight, generation loop, enum guard, contradiction guard, EXPLAIN,
execution, renderer.

CONFIDENCES -- extracted from result.explanation.confidence, as computed
by the pipeline (v3.x):
  confidence   = 0.3*rag_conf + 0.4*gen_conf + 0.3*sem_conf  (additive)
  score_strict = (0.4*rag_conf + 0.6*gen_conf) * sem_conf    (sem = veto)
  rag_conf : mean cosine similarity of the RAG-retrieved tables
  gen_conf : linear decay per retry (1.0 = first-attempt success)
  sem_conf : deterministic semantic-consistency score

Scoring methodology (identical to run_eval_by_domain / blue_tables v3.1):
  - success rate over ALL questions ("does the pipeline answer?");
  - mean confidences over SUCCESSES only ("when it answers, how sure
    is it?") -- failures carry empty/0 confidences that would
    artificially crush the mean;
  - global_score = success_rate x mean_confidence: one value that
    penalizes both failures and unsure answers, comparable run to run.

Each run is also classified into one outcome:
  success        -- pipeline succeeded and returned at least one data row
  empty_success  -- SUCCESS but 0 rows: the silent failure class (invented
                    enums, contradictory filters, wrong join) -- REVIEW
  declined       -- negative pre-flight / unanswerable: explained refusal
  failed         -- pipeline gave up after its retries
  pipeline_error -- job finished with status 'error' (exception)
  timeout        -- no terminal status within --timeout seconds
  infra_error    -- API unreachable / HTTP error

Outputs (prefix configurable with --out):
  eval_results.json  -- full machine-readable record of every run
  eval_report.md     -- summary (rates + mean confidences) + per-query table
  eval_results.csv   -- flat table, columns = EVAL_FIELDNAMES (compatible
                        with run_eval_by_domain.py and Excel/pandas)

This module is ALSO importable by campaign drivers (run_eval_by_domain.py):
it exposes EVAL_FIELDNAMES, run_one_query(), load_questions() and
load_already_tested() with the expected signatures.

Usage:
  python run_eval.py                                  # all queries
  python run_eval.py --only q1,q4,q20                 # subset
  python run_eval.py --api http://localhost:8080 --timeout 400
  python run_eval.py --queries mds_queries.json --out eval_run1

Queries run SEQUENTIALLY on purpose: the LLM backend (Ollama, single
GPU) serializes generations anyway, and parallel submission would only
distort per-query latency numbers.
"""

from __future__ import annotations

import argparse
import csv
import functools
import json
import re
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

# Column layout shared with the campaign drivers (run_eval_by_domain.py
# reads this attribute if present -- keep names and order stable).
EVAL_FIELDNAMES = [
    "table", "question", "success", "attempts", "row_count",
    "confidence", "rag_conf", "gen_conf", "sem_conf", "score_strict",
    "error", "sql", "elapsed",
]

CONF_FIELDS = ["confidence", "rag_conf", "gen_conf", "sem_conf", "score_strict"]

# ---------------------------------------------------------------------------
# HTTP helpers (stdlib only -- no extra dependency needed on the host)
# ---------------------------------------------------------------------------

def _headers(api_key: str = "") -> dict:
    h = {"Content-Type": "application/json"}
    if api_key:
        h["X-API-Key"] = api_key
        h["Authorization"] = f"Bearer {api_key}"
    return h


def _post_json(url: str, payload: dict, api_key: str = "",
               timeout: float = 30.0) -> tuple[int, dict]:
    req = urllib.request.Request(
        url, data=json.dumps(payload).encode("utf-8"),
        headers=_headers(api_key), method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.status, json.loads(resp.read().decode("utf-8"))


def _get_json(url: str, api_key: str = "",
              timeout: float = 30.0) -> tuple[int, dict]:
    req = urllib.request.Request(url, headers=_headers(api_key))
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.status, json.loads(resp.read().decode("utf-8"))


def start_job(api: str, question: str, api_key: str = "") -> str:
    """POST /query/start -> job_id. Tries the payload keys the API may use."""
    last_err = None
    for key in ("question", "query", "text"):
        try:
            status, body = _post_json(f"{api}/query/start", {key: question},
                                      api_key)
            if status < 400:
                job_id = body.get("job_id") or body.get("id")
                if job_id:
                    return str(job_id)
                last_err = f"no job_id in response: {body}"
        except urllib.error.HTTPError as e:
            last_err = f"HTTP {e.code}"
            if e.code != 422:      # 422 = wrong payload key -> try the next one
                raise
        except Exception as e:
            last_err = str(e)
            raise
    raise RuntimeError(f"could not start job: {last_err}")


def poll_job(api: str, job_id: str, timeout_s: float, poll_s: float,
             api_key: str = "") -> dict:
    """Poll /query/status/{job_id} until done/error or the timeout expires."""
    deadline = time.monotonic() + timeout_s
    last: dict = {}
    while time.monotonic() < deadline:
        try:
            _s, body = _get_json(f"{api}/query/status/{job_id}", api_key)
            last = body or {}
            if last.get("status") in ("done", "error"):
                return last
        except Exception:
            pass                    # transient poll failure: keep trying
        time.sleep(poll_s)
    last["status"] = last.get("status", "running")
    last["_timed_out"] = True
    return last


# ---------------------------------------------------------------------------
# Result introspection (defensive: works whatever the exact result shape)
# ---------------------------------------------------------------------------

_ROW_KEYS = ("rows", "data", "results", "records", "result_rows")


def find_row_count(obj, depth: int = 0):
    """Best-effort row count: first list of dicts/lists under a rows-ish key."""
    if depth > 6 or obj is None:
        return None
    if isinstance(obj, dict):
        for k in _ROW_KEYS:
            v = obj.get(k)
            if isinstance(v, list):
                return len(v)
        for k in ("row_count", "num_rows", "n_rows", "count"):
            v = obj.get(k)
            if isinstance(v, int):
                return v
        for v in obj.values():
            n = find_row_count(v, depth + 1)
            if n is not None:
                return n
    return None


def _find_rows(obj, depth: int = 0):
    """Best-effort: the first list found under a rows-ish key."""
    if depth > 6 or obj is None:
        return None
    if isinstance(obj, dict):
        for k in _ROW_KEYS:
            v = obj.get(k)
            if isinstance(v, list):
                return v
        for v in obj.values():
            rows = _find_rows(v, depth + 1)
            if rows is not None:
                return rows
    return None


_NULLISH = (None, "None", "NULL", "null", "")


def is_hollow_result(result: dict) -> bool:
    """True when the 'successful' result carries no actual data: every
    value of every row is NULL. The classic shape is an aggregate over an
    empty set -- `SELECT SUM(x) ... WHERE <matches nothing>` returns ONE
    row containing NULL, which row-count checks read as real data
    (observed in production eval: q2/q17, '| None |' answers). Falls back
    to the rendered answer's markdown table when rows are not exposed."""
    rows = _find_rows(result)
    if rows:
        def vals(row):
            return row.values() if isinstance(row, dict) else (
                row if isinstance(row, (list, tuple)) else [row])
        if all(all(v in _NULLISH for v in vals(r)) for r in rows):
            return True
    if rows is None:
        # No rows exposed by the API: inspect the rendered markdown table.
        # First "|" line = header, "---" line = separator, rest = data.
        answer = str((result or {}).get("answer") or "")
        table_lines = [l.strip() for l in answer.splitlines()
                       if l.strip().startswith("|")]
        data_lines = [l for l in table_lines[1:] if "---" not in l]
        cells = [c.strip() for l in data_lines
                 for c in l.strip("|").split("|")]
        if cells and all(c in ("None", "NULL", "null", "") for c in cells):
            return True
    return False


# ---------------------------------------------------------------------------
# SQL faithfulness -- is the generated SQL an honest translation of the
# question? An EMPTY result on FAITHFUL SQL is a legitimate answer ("the
# data holds nothing for this") and counts as a success; an empty result
# on hallucinated filters is the silent failure class.
# ---------------------------------------------------------------------------

def sql_faithfulness(question: str, sql: str) -> dict:
    """Deterministic hallucination screen. Returns
    {"verdict": "faithful" | "unverified" | "hallucinated", "flags": [...]}.

    - hallucinated : the SQL admits guessing ("-- Assuming ..." comments,
      observed in production on every wrong-id/wrong-code query);
    - unverified   : filter literals (strings/numbers) that do NOT appear
      in the question -- possibly legit derived codes, possibly invented
      ('ENEENG', 'NRD12H'); resolvable definitively with --verify-db;
    - faithful     : every filter literal is grounded in the question and
      nothing is guessed.
    """
    out = {"verdict": "faithful", "flags": [],
           "counts": {"total": 0, "grounded": 0, "guessed": 0,
                      "db_verified": 0, "db_missing": 0}}
    if not (sql or "").strip():
        out.update(verdict="unverified", flags=["no SQL generated"])
        return out
    c = out["counts"]
    hall = unver = False
    ql = (question or "").lower()

    # 1. "Assuming ..." comments: the model documents its own guess.
    for m in re.finditer(r"--[^\n]*", sql):
        if re.search(r"assum|guess|placeholder|add condition", m.group(0), re.I):
            hall = True
            c["guessed"] += 1
            out["flags"].append(f"guess comment: {m.group(0).strip()[:90]}")

    # 2. String literals used as filters must be grounded in the question.
    for lit in dict.fromkeys(re.findall(r"'([^']+)'", sql)):
        c["total"] += 1
        if lit.lower() in ql:
            c["grounded"] += 1
            continue
        unver = True
        kind = ("enum-like code" if re.fullmatch(r"[A-Z0-9_]{2,12}", lit)
                else "string literal")
        out["flags"].append(f"{kind} '{lit}' not present in the question")

    # 3. Numeric comparison literals must come from the question
    #    (LIMIT excluded; 0/1 tolerated: CASE WHEN x = 0 patterns).
    nums_q = set(re.findall(r"\d+", question or ""))
    sql_wo_limit = re.sub(r"\bLIMIT\s+\d+", "", sql, flags=re.I)
    for n in dict.fromkeys(re.findall(r"(?:=|<>|!=|>=|<=|>|<)\s*(\d+)",
                                      sql_wo_limit)):
        c["total"] += 1
        if n in nums_q or n in ("0", "1"):
            c["grounded"] += 1
            continue
        unver = True
        out["flags"].append(f"numeric literal {n} not present in the question")

    if hall:
        out["verdict"] = "hallucinated"
    elif unver:
        out["verdict"] = "unverified"
    return out


def grounding_score(faith: dict) -> float:
    """ANTI-HALLUCINATION METRIC (0..1): share of the SQL's filter
    literals that are VERIFIED -- grounded in the question, or (with
    --verify-db) confirmed to exist in the actual column data. Each
    "Assuming..." guess comment counts as one extra unverified unit.

      1.0  -> every filter value is provable (question or database)
      0.0  -> every filter value is invented
      1.0 with no literals at all -> nothing to hallucinate

    A DB-checked literal that is NOT FOUND stays unverified (it is
    precisely the hallucination), so the score drops. Schema errors found
    by --verify-db (invented table, invented column, type mismatch) each
    count as one extra unverified unit as well.
    """
    c = (faith or {}).get("counts") or {}
    total = (c.get("total", 0) + c.get("guessed", 0)
             + c.get("schema_errors", 0) + c.get("enum_errors", 0))
    if total == 0:
        return 1.0
    grounded = c.get("grounded", 0) + c.get("db_verified", 0)
    return round(min(grounded, total) / total, 4)


def _alias_map(sql: str) -> dict:
    """alias -> table, regex-based (stdlib only)."""
    amap = {}
    for m in re.finditer(r"\b(?:FROM|JOIN)\s+`?(\w+)`?(?:\s+AS)?(?:\s+(?!ON|WHERE|JOIN|LEFT|RIGHT|INNER|OUTER|GROUP|ORDER|ON\b)(\w+))?",
                         sql, re.I):
        table, alias = m.group(1), m.group(2)
        amap[(alias or table).lower()] = table.lower()
        amap.setdefault(table.lower(), table.lower())
    return amap


# SQL type families for the column/literal type-compatibility check.
_NUM_TYPES = {"int", "integer", "bigint", "smallint", "mediumint", "tinyint",
              "decimal", "numeric", "double", "float", "bit", "boolean"}
_DATE_TYPES = {"date", "datetime", "timestamp", "time", "year"}
_DATEISH_RE = re.compile(r"^\d{4}-\d{2}-\d{2}([ T]\d{2}:\d{2}(:\d{2})?)?$"
                         r"|^\d{2}:\d{2}(:\d{2})?$")


def _strip_strings(sql: str) -> str:
    """SQL with string literal contents blanked (keeps positions simple)."""
    return re.sub(r"'[^']*'", "''", sql)


def run_db_checks(sql: str, question: str, schema_map: dict,
                  value_exists, enum_map: dict | None = None) -> dict:
    """Pure verification logic (testable without a live DB).

    schema_map   : {table -> {column -> data_type(lowercase)}} from
                   information_schema for the target database.
    value_exists : callable(table, column, literal) -> True/False/None
                   (None = could not check).
    enum_map     : {(table, column) -> frozenset(UPPERCASED allowed
                   values)} for ENUM/SET-typed columns, parsed from
                   information_schema COLUMN_TYPE.

    Five families of checks, all deterministic:
      1. INVENTED TABLES  -- every FROM/JOIN table must exist in the DB;
      2. INVENTED COLUMNS -- every qualified column reference must exist
         in its resolved table;
      3. TYPE MISMATCHES  -- a filter literal must be compatible with the
         column's declared type (string vs INT, number vs VARCHAR
         [the id/name confusion], number vs DATE, non-date string vs
         DATE). MariaDB coerces silently instead of erroring: these
         comparisons execute fine and just match nothing.
      4. VALUE EXISTENCE  -- filter values NOT grounded in the question
         must actually exist in the filtered column's data;
      5. ENUM MEMBERSHIP  -- a value compared to an ENUM/SET column must
         belong to the column's DECLARED value set. Stronger than check 4
         and applied even to question-grounded literals: a valid enum
         value with zero rows is legitimate data absence, but a value
         outside the declaration can NEVER match (MariaDB just returns
         empty). Enum columns are excluded from check 4 accordingly.
    """
    out = {"details": [], "schema_errors": 0, "enum_errors": 0,
           "found": 0, "missing": 0, "unchecked": 0}
    enum_map = enum_map or {}
    amap = _alias_map(sql)
    clean = _strip_strings(sql)
    ql = (question or "").lower()

    # -- 1. Invented tables ------------------------------------------------
    real_tables, _reported = {}, set()
    for alias, table in amap.items():
        if table in schema_map:
            real_tables[alias] = table
        elif table not in _reported:
            _reported.add(table)
            out["schema_errors"] += 1
            out["details"].append(
                f"table `{table}` does NOT exist in the database "
                f"-> invented by the model")

    def resolve(alias_or_none, col):
        """Candidate real tables for a (possibly unqualified) column."""
        if alias_or_none:
            t = real_tables.get(alias_or_none.lower())
            return [t] if t else []
        return [t for t in dict.fromkeys(real_tables.values())
                if col.lower() in schema_map.get(t, {})]

    # -- 2. Invented columns (qualified references only: unambiguous) ------
    seen_cols = set()
    for cm in re.finditer(r"\b([a-zA-Z_]\w*)\.([a-zA-Z_]\w*)\b", clean):
        alias, col = cm.group(1).lower(), cm.group(2).lower()
        t = real_tables.get(alias)
        if t is None or (t, col) in seen_cols:
            continue
        seen_cols.add((t, col))
        if col not in schema_map.get(t, {}):
            out["schema_errors"] += 1
            out["details"].append(
                f"column `{t}.{col}` does NOT exist in the database "
                f"-> invented by the model")

    # -- 3. Type compatibility of filter comparisons -----------------------
    def col_type(alias, col):
        for t in resolve(alias, col):
            dt = schema_map.get(t, {}).get(col.lower())
            if dt:
                return t, dt
        return None, None

    #    column <op> 'string literal'
    for cm in re.finditer(
            r"(?:([a-zA-Z_]\w*)\.)?([a-zA-Z_]\w*)\s*(?:=|!=|<>|>=|<=|>|<)"
            r"\s*'([^']*)'", sql):
        alias, col, lit = cm.groups()
        t, dt = col_type(alias, col)
        if not dt:
            continue
        if dt in _NUM_TYPES and not re.fullmatch(r"-?\d+(\.\d+)?", lit):
            out["schema_errors"] += 1
            out["details"].append(
                f"type mismatch: {t}.{col} is {dt.upper()} but compared "
                f"to string '{lit}' (silently matches nothing)")
        elif dt in _DATE_TYPES and not _DATEISH_RE.match(lit):
            out["schema_errors"] += 1
            out["details"].append(
                f"type mismatch: {t}.{col} is {dt.upper()} but compared "
                f"to non-date string '{lit}'")

    #    column <op> numeric literal
    for cm in re.finditer(
            r"(?:([a-zA-Z_]\w*)\.)?([a-zA-Z_]\w*)\s*(?:=|!=|<>|>=|<=|>|<)"
            r"\s*(-?\d+(?:\.\d+)?)\b", clean):
        alias, col, lit = cm.groups()
        t, dt = col_type(alias, col)
        if not dt:
            continue
        if dt not in _NUM_TYPES and dt not in _DATE_TYPES:
            out["schema_errors"] += 1
            out["details"].append(
                f"type mismatch: {t}.{col} is {dt.upper()} (text) but "
                f"compared to number {lit} -> likely id/name confusion")
        elif dt in _DATE_TYPES:
            out["schema_errors"] += 1
            out["details"].append(
                f"type mismatch: {t}.{col} is {dt.upper()} but compared "
                f"to bare number {lit}")

    def is_enum_col(alias, col):
        return any((t, col.lower()) in enum_map for t in resolve(alias, col))

    # -- 4. Existence of NON-question-grounded string literals -------------
    #    (a value quoted from the question that is absent from the data is
    #    DATA ABSENCE, not hallucination -- only invented values are
    #    checked; ENUM columns are handled by check 5 instead, because a
    #    declared value with zero rows is legitimate)
    for cm in re.finditer(
            r"(?:([a-zA-Z_]\w*)\.)?([a-zA-Z_]\w*)\s*(?:=|!=|<>)\s*'([^']+)'",
            sql):
        alias, col, lit = cm.groups()
        if lit.lower() in ql or is_enum_col(alias, col):
            continue
        found = None
        for t in resolve(alias, col):
            try:
                r = value_exists(t, col, lit)
            except Exception:
                r = None
            if r:
                found = t
                break
            if r is False and found is None:
                found = False
        if found:
            out["found"] += 1
            out["details"].append(f"'{lit}' EXISTS in {found}.{col}")
        elif found is False:
            out["missing"] += 1
            out["details"].append(f"'{lit}' NOT FOUND in column {col} "
                                  f"-> hallucinated value")
        else:
            out["unchecked"] += 1

    # -- 5. ENUM/SET membership (question-grounded literals included) ------
    def check_enum(alias, col, lits):
        for t in resolve(alias, col):
            allowed = enum_map.get((t, col.lower()))
            if allowed is None:
                continue
            for lit in lits:
                if lit.upper() in allowed:
                    out["found"] += 1
                    out["details"].append(
                        f"'{lit}' is a declared enum value of {t}.{col}")
                else:
                    out["enum_errors"] += 1
                    preview = ", ".join(sorted(allowed)[:8])
                    more = f", +{len(allowed) - 8} more" if len(allowed) > 8 else ""
                    out["details"].append(
                        f"enum value '{lit}' is NOT among the declared "
                        f"values of {t}.{col} ({preview}{more}) "
                        f"-> can never match")
            return          # authoritative table found: stop resolving

    #    column <op> 'literal'
    for cm in re.finditer(
            r"(?:([a-zA-Z_]\w*)\.)?([a-zA-Z_]\w*)\s*(?:=|!=|<>)\s*'([^']+)'",
            sql):
        alias, col, lit = cm.groups()
        check_enum(alias, col, [lit])
    #    column IN ('a', 'b', ...)
    for cm in re.finditer(
            r"(?:([a-zA-Z_]\w*)\.)?([a-zA-Z_]\w*)\s+(?:NOT\s+)?IN\s*\(([^)]*)\)",
            sql, re.I):
        alias, col, body = cm.groups()
        lits = re.findall(r"'([^']*)'", body)
        if lits:
            check_enum(alias, col, lits)
    return out


@functools.lru_cache(maxsize=4)
def _db_connect(db_dsn: str):
    """(connection, database_name) for a user:pass@host:port/db DSN."""
    m = re.match(r"([^:]+):([^@]*)@([^:/]+):?(\d+)?/(.+)", db_dsn or "")
    if not m:
        raise ValueError("--verify-db DSN not parseable (user:pass@host:port/db)")
    user, pwd, host, port, db = m.groups()
    try:
        import pymysql
        conn = pymysql.connect(host=host, port=int(port or 3306), user=user,
                               password=pwd, database=db, connect_timeout=5)
    except ImportError:
        import mysql.connector
        conn = mysql.connector.connect(host=host, port=int(port or 3306),
                                       user=user, password=pwd, database=db,
                                       connection_timeout=5)
    return conn, db


_SCHEMA_CACHE: dict = {}


def _db_schema_map(conn, db: str) -> tuple:
    """(schema_map, enum_map) from information_schema (cached).
    schema_map: {table -> {column -> data_type}};
    enum_map:   {(table, column) -> frozenset(UPPER allowed values)} for
    ENUM/SET columns, parsed from COLUMN_TYPE ("enum('CM','EQ',...)")."""
    if db in _SCHEMA_CACHE:
        return _SCHEMA_CACHE[db]
    cur = conn.cursor()
    cur.execute(
        "SELECT LOWER(TABLE_NAME), LOWER(COLUMN_NAME), LOWER(DATA_TYPE), "
        "COLUMN_TYPE FROM information_schema.COLUMNS "
        "WHERE TABLE_SCHEMA = %s", (db,))
    smap: dict = {}
    emap: dict = {}
    for t, c, dt, ct in cur.fetchall():
        smap.setdefault(t, {})[c] = dt
        if dt in ("enum", "set"):
            ct = ct.decode() if isinstance(ct, (bytes, bytearray)) else str(ct)
            vals = frozenset(v.upper() for v in re.findall(r"'([^']*)'", ct))
            if vals:
                emap[(t, c)] = vals
    _SCHEMA_CACHE[db] = (smap, emap)
    return smap, emap


def verify_sql_against_db(sql: str, question: str, db_dsn: str) -> tuple:
    """Full DB-backed verification: invented tables/columns, type
    mismatches, and existence of non-grounded filter values.
    Returns (resolved_verdict_or_None, detail_flags, counts_dict).
    None verdict = could not verify (driver/connection missing)."""
    try:
        conn, db = _db_connect(db_dsn)
        schema_map, enum_map = _db_schema_map(conn, db)
        cur = conn.cursor()

        def value_exists(table, column, literal):
            try:
                cur.execute(
                    f"SELECT EXISTS(SELECT 1 FROM `{table}` "
                    f"WHERE `{column}` = %s)", (literal,))
                return bool(cur.fetchone()[0])
            except Exception:
                return None

        res = run_db_checks(sql, question, schema_map, value_exists,
                            enum_map)
    except Exception as e:
        return None, [f"DB verification unavailable: {e}"], {}

    if res["schema_errors"] or res["enum_errors"] or res["missing"]:
        verdict = "hallucinated"
    elif res["unchecked"] == 0:
        verdict = "faithful"
    else:
        verdict = None
    return verdict, res["details"], res


def extract_confidence(result: dict) -> dict:
    """result.explanation.confidence -> {confidence, rag_conf, gen_conf,
    sem_conf, score_strict} (missing components stay None)."""
    conf = ((result or {}).get("explanation") or {}).get("confidence") or {}
    return {
        "confidence": conf.get("score"),
        "rag_conf": conf.get("rag_conf"),
        "gen_conf": conf.get("gen_conf"),
        "sem_conf": conf.get("sem_conf"),
        "score_strict": conf.get("score_strict"),
    }


def guard_events(result: dict) -> list[str]:
    """Extract guardrail interventions from explanation.attempts."""
    events = []
    attempts = ((result or {}).get("explanation") or {}).get("attempts") or []
    for i, att in enumerate(attempts, 1):
        err = str((att or {}).get("error") or "")
        low = err.lower()
        if "not a valid value" in low or "enum" in low:
            events.append(f"attempt {i}: ENUM GUARD")
        elif "mutually exclusive" in low or "contradict" in low:
            events.append(f"attempt {i}: CONTRADICTION GUARD")
        elif (att or {}).get("failed_at"):
            events.append(f"attempt {i}: {att['failed_at']}")
    return events


def _guard_label(err: str) -> str:
    """Short label for what blocked an attempt, from its error text."""
    low = (err or "").lower()
    if "not a valid value" in low or "enum" in low:
        return "ENUM GUARD"
    if "mutually exclusive" in low or "contradict" in low:
        return "CONTRADICTION GUARD"
    return ""


def summarize_log(outcome: str, result: dict, rec: dict) -> str:
    """One-paragraph, human-readable digest of the pipeline's journey for
    this question -- the 'what happened' you would otherwise grep the API
    logs for: per-attempt blocks (stage + guard + error head), then how
    the run ended (rows, confidence / decline reason / timeout stage)."""
    parts: list[str] = []
    expl = (result or {}).get("explanation") or {}
    attempts = expl.get("attempts") or []
    for i, att in enumerate(attempts, 1):
        stage = (att or {}).get("failed_at") or "generation"
        err = str((att or {}).get("error") or "").strip()
        label = _guard_label(err) or stage
        head = (" -- " + err[:110] + ("..." if len(err) > 110 else "")) if err else ""
        parts.append(f"attempt {i}: blocked at {label}{head}")

    total = rec.get("attempts")
    if outcome == "success":
        rows = rec.get("row_count")
        if rows in (0, "0"):
            rows_txt = ("0 rows -- SQL judged FAITHFUL to the question, "
                        "the data genuinely holds nothing for this")
        else:
            rows_txt = (f"{rows} row(s)" if rows not in (None, "")
                        else "data returned")
        final = (f"attempt {total}: " if total else "") + \
            f"SQL passed static check + EXPLAIN, executed -> {rows_txt}"
        conf = _to_float(rec.get("confidence"))
        if conf is not None:
            comp = []
            for k, tag in (("rag_conf", "rag"), ("gen_conf", "gen"),
                           ("sem_conf", "sem")):
                v = _to_float(rec.get(k))
                if v is not None:
                    comp.append(f"{tag} {v:.2f}")
            final += f"; confidence {conf:.2f}" + \
                (f" ({', '.join(comp)})" if comp else "")
        parts.append(final)
    elif outcome == "empty_success":
        msg = ((f"attempt {total}: " if total else "") +
               "SQL executed WITHOUT error but returned no data -- ")
        verdict = rec.get("faithfulness")
        if verdict == "hallucinated":
            msg += "and the SQL contains GUESSED filters: " + \
                str(rec.get("faithfulness_flags"))[:180]
        elif verdict == "unverified":
            msg += ("filter literals could not be grounded in the question "
                    "(run with --verify-db to check them against the data): "
                    + str(rec.get("faithfulness_flags"))[:180])
        else:
            msg += ("silent failure class (likely wrong filter value, "
                    "contradictory filters or wrong join): review the SQL")
        parts.append(msg)
    elif outcome == "declined":
        ans = str(rec.get("answer") or "")[:140]
        parts.append("declined without generation (negative pre-flight / "
                     f"unanswerable): {ans}")
    elif outcome == "timeout":
        parts.append(f"no terminal status before timeout; last stage: "
                     f"{rec.get('error') or 'unknown'}")
    elif outcome == "pipeline_error":
        parts.append(f"job ended in error: {rec.get('error') or 'unknown'}")
    elif outcome == "failed":
        parts.append("pipeline gave up after its retries" +
                     (f" -- {rec.get('error')}" if rec.get("error") else ""))
    elif outcome == "infra_error":
        parts.append(f"API unreachable / HTTP error: {rec.get('error') or ''}")
    return " | ".join(parts)


def classify(body: dict, faith: dict | None = None) -> str:
    """Map a terminal job body onto one evaluation outcome.

    An EMPTY (or all-NULL) result is a SUCCESS when the SQL is judged
    FAITHFUL to the question -- "the data holds nothing for this" is a
    legitimate answer. It stays empty_success (suspect) when the SQL
    contains guessed/hallucinated or unverifiable filters.
    """
    if body.get("_timed_out"):
        return "timeout"
    if body.get("status") == "error":
        return "pipeline_error"
    result = body.get("result") or {}
    answer = str(result.get("answer") or "")
    if result.get("success"):
        n = find_row_count(result)
        empty = (n == 0) or is_hollow_result(result)
        if not empty:
            return "success"
        if faith and faith.get("verdict") == "faithful":
            return "success"          # legitimately empty answer
        return "empty_success"
    low = answer.lower()
    declined_markers = (
        "cannot be answered", "not answerable", "unanswerable",
        "cannot answer", "no platoon", "declin", "impossible",
        "does not contain", "not available in this database",
    )
    if any(m in low for m in declined_markers):
        return "declined"
    return "failed"


# ---------------------------------------------------------------------------
# Campaign-driver interface (imported by run_eval_by_domain.py)
# ---------------------------------------------------------------------------

def run_one_query(api_url: str, api_key: str, question: str,
                  timeout: float, poll_s: float = 2.0,
                  verify_db: str = "") -> dict:
    """Run ONE question through the API; return a flat record whose keys
    match EVAL_FIELDNAMES (minus table/question, supplied by the caller).

    success is True ONLY for a real success WITH data rows when the row
    count is observable -- an empty result is the silent failure class,
    not a pass. (If the API does not expose rows, success falls back to
    the pipeline's own flag.)
    """
    api = api_url.rstrip("/")
    t0 = time.monotonic()
    rec = {"success": False, "attempts": "", "row_count": "",
           "confidence": "", "rag_conf": "", "gen_conf": "", "sem_conf": "",
           "score_strict": "", "error": "", "sql": "", "elapsed": 0.0,
           "outcome": "infra_error", "answer": "", "guards": [],
           "log_summary": "", "faithfulness": "", "faithfulness_flags": "",
           "grounding": ""}
    try:
        job_id = start_job(api, question, api_key)
        body = poll_job(api, job_id, timeout, poll_s, api_key)
        result = body.get("result") or {}
        _sql = result.get("sql") or ""
        faith = sql_faithfulness(question, _sql) if _sql else None
        # Optional full DB verification: invented tables/columns, type
        # mismatches, and existence of non-grounded filter values. Runs on
        # EVERY SQL (schema/type checks apply even when all literals are
        # grounded in the question).
        if faith and verify_db and _sql:
            resolved, details, vcounts = verify_sql_against_db(
                _sql, question, verify_db)
            faith["flags"].extend(details)
            if vcounts:
                faith["counts"]["db_verified"] = vcounts.get("found", 0)
                faith["counts"]["db_missing"] = vcounts.get("missing", 0)
                faith["counts"]["schema_errors"] = vcounts.get(
                    "schema_errors", 0)
                faith["counts"]["enum_errors"] = vcounts.get(
                    "enum_errors", 0)
            if resolved == "hallucinated":
                faith["verdict"] = "hallucinated"
            elif resolved == "faithful" and faith["verdict"] == "unverified":
                faith["verdict"] = "faithful"
        outcome = classify(body, faith)
        n = find_row_count(result)
        conf = extract_confidence(result)
        rec.update(
            outcome=outcome,
            success=(outcome == "success"),
            attempts=result.get("attempts", ""),
            row_count="" if n is None else n,
            sql=result.get("sql") or "",
            answer=(str(result.get("answer"))[:2000]
                    if result.get("answer") is not None else ""),
            error=result.get("error") or (
                str(body.get("stage")) if body.get("_timed_out") else ""),
            guards=guard_events(result),
            **{k: ("" if v is None else v) for k, v in conf.items()},
        )
        if faith:
            rec["faithfulness"] = faith["verdict"]
            rec["faithfulness_flags"] = " ; ".join(faith["flags"])
            rec["grounding"] = grounding_score(faith)
        if outcome == "empty_success" and not rec["error"]:
            base = ("SUCCESS but every value is NULL (aggregate over empty "
                    "set)" if (n or 0) > 0 else
                    "SUCCESS with 0 rows (silent failure class)")
            if faith and faith["flags"]:
                base += " -- SQL " + faith["verdict"] + ": " + \
                    " ; ".join(faith["flags"][:3])
            rec["error"] = base
        rec["log_summary"] = summarize_log(outcome, result, rec)
    except Exception as e:
        rec["error"] = str(e)
        rec["log_summary"] = summarize_log("infra_error", {}, rec)
    rec["elapsed"] = round(time.monotonic() - t0, 2)
    return rec


def load_questions(kb_path: str, tables=None, kinds=None,
                   sample_per_table: int | None = None) -> list[dict]:
    """POSITIVE gold questions from the KB's sample_queries.

    Returns [{"table": t, "question": q}, ...]. Entries without SQL
    (UNANSWERABLE class) are excluded: they test the refusal path, which
    a success-rate campaign would mis-count as failures. `kinds` filters
    on the entry's "kind" field when given.
    """
    kb = json.loads(Path(kb_path).read_text(encoding="utf-8"))
    kb_tables = kb.get("tables", kb)
    items: list[dict] = []
    for name, entry in kb_tables.items():
        if not isinstance(entry, dict):
            continue
        if tables is not None and name not in set(tables):
            continue
        picked = 0
        for q in entry.get("sample_queries") or []:
            if not isinstance(q, dict) or not q.get("question"):
                continue
            if q.get("sql") is None:
                continue                      # UNANSWERABLE: refusal path
            if kinds and q.get("kind") not in set(kinds):
                continue
            items.append({"table": name, "question": q["question"].strip()})
            picked += 1
            if sample_per_table and picked >= sample_per_table:
                break
    return items


def load_already_tested(csv_path) -> set[tuple]:
    """(table, question) pairs already present in a detailed CSV (--resume)."""
    p = Path(csv_path)
    if not p.exists():
        return set()
    with open(p, newline="", encoding="utf-8") as f:
        return {(r.get("table", ""), r.get("question", ""))
                for r in csv.DictReader(f)}


# ---------------------------------------------------------------------------
# Score aggregation (same methodology as run_eval_by_domain.py)
# ---------------------------------------------------------------------------

def _to_float(value):
    """"0.92", "92%", 92, "" or None -> float 0..1, or None."""
    if value is None:
        return None
    s = str(value).strip().rstrip("%")
    if not s:
        return None
    try:
        v = float(s)
    except ValueError:
        return None
    return v / 100.0 if v > 1.0 else v


def summarize_confidences(records: list[dict]) -> dict:
    """Success rate over ALL records; mean confidences over SUCCESSES only;
    global_score = success_rate x mean confidence. Also aggregates the
    anti-hallucination metric: mean_grounding over every record that
    produced SQL, and hallucination_rate = share of SQL-producing records
    whose faithfulness verdict is 'hallucinated'."""
    successes = [r for r in records if r.get("outcome") == "success"]
    rate = len(successes) / len(records) if records else 0.0
    out = {"questions": len(records), "passed": len(successes),
           "success_rate": round(rate, 4)}
    with_sql = [r for r in records if r.get("sql")]
    g_vals = [v for r in with_sql
              if (v := _to_float(r.get("grounding"))) is not None]
    out["mean_grounding"] = (round(sum(g_vals) / len(g_vals), 4)
                             if g_vals else None)
    out["hallucination_rate"] = (
        round(sum(1 for r in with_sql
                  if r.get("faithfulness") == "hallucinated")
              / len(with_sql), 4) if with_sql else None)
    means = {}
    for field in CONF_FIELDS:
        vals = [v for r in successes
                if (v := _to_float(r.get(field))) is not None]
        out[f"mean_{field}"] = round(sum(vals) / len(vals), 4) if vals else None
        if vals:
            means[field] = sum(vals) / len(vals)
    quality = means.get("confidence")
    if quality is None and means:
        quality = sum(means.values()) / len(means)
    out["global_score"] = (round(rate * quality, 4)
                           if quality is not None else None)
    return out


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------

_OUTCOME_ICON = {
    "success": "PASS", "empty_success": "WARN(0 rows)", "declined": "DECLINED",
    "failed": "FAIL", "pipeline_error": "ERROR", "timeout": "TIMEOUT",
    "infra_error": "INFRA",
}


def _pct(v) -> str:
    return "n/a" if v is None else f"{v * 100:.1f}%"


def write_reports(records: list[dict], out_prefix: str, api: str,
                  started_at: str) -> None:
    Path(f"{out_prefix}.json").write_text(
        json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")

    # CSV: EVAL_FIELDNAMES layout (campaign-compatible) + id/outcome up
    # front and the generated SQL / log digest columns at the end.
    with open(f"{out_prefix}.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh,
                           fieldnames=["id", "outcome"] + EVAL_FIELDNAMES
                           + ["faithfulness", "grounding",
                              "faithfulness_flags", "log_summary"],
                           extrasaction="ignore")
        w.writeheader()
        for r in records:
            w.writerow(r)

    stats = summarize_confidences(records)
    counts: dict[str, int] = {}
    for r in records:
        counts[r["outcome"]] = counts.get(r["outcome"], 0) + 1
    total = len(records)
    lat = [r["elapsed"] for r in records if r.get("elapsed") is not None]

    lines = [
        "# REQA agent evaluation report", "",
        f"- API: `{api}`",
        f"- Started: {started_at}",
        f"- Queries: {total}",
        f"- Latency: avg {sum(lat)/len(lat):.1f}s / max {max(lat):.1f}s"
        if lat else "- Latency: n/a", "",
        "## Scores", "",
        "| Metric | Value |", "|---|---|",
        f"| Success rate | {stats['passed']}/{stats['questions']} "
        f"({_pct(stats['success_rate'])}) |",
        f"| Mean confidence (successes) | {_pct(stats['mean_confidence'])} |",
        f"| Mean rag_conf | {_pct(stats['mean_rag_conf'])} |",
        f"| Mean gen_conf | {_pct(stats['mean_gen_conf'])} |",
        f"| Mean sem_conf | {_pct(stats['mean_sem_conf'])} |",
        f"| Mean score_strict | {_pct(stats['mean_score_strict'])} |",
        f"| Mean grounding (anti-hallucination) | {_pct(stats['mean_grounding'])} |",
        f"| Hallucination rate | {_pct(stats['hallucination_rate'])} |",
        f"| **Global score** (rate x conf) | **{_pct(stats['global_score'])}** |",
        "",
        "## Outcome summary", "",
        "| Outcome | Count | Share |", "|---|---|---|",
    ]
    for k in ("success", "empty_success", "declined", "failed",
              "pipeline_error", "timeout", "infra_error"):
        if counts.get(k):
            lines.append(f"| {k} | {counts[k]} | {100*counts[k]/total:.0f}% |")
    lines += [
        "",
        "`empty_success` = the silent-failure class (SUCCESS with 0 rows):",
        "review each one manually -- it usually means an invented enum value,",
        "contradictory filters, or a wrong join that the guards did not catch.",
        "", "## Per-query results", "",
        "| ID | Outcome | Latency | Attempts | Rows | Conf | Strict | Ground | Guards | Question |",
        "|---|---|---|---|---|---|---|---|---|---|",
    ]
    for r in records:
        q = r["question"][:70] + ("..." if len(r["question"]) > 70 else "")
        lat_s = "" if r.get("elapsed") is None else "%.1fs" % r["elapsed"]
        conf = _to_float(r.get("confidence"))
        strict = _to_float(r.get("score_strict"))
        ground = _to_float(r.get("grounding"))
        lines.append(
            f"| {r['id']} | {_OUTCOME_ICON.get(r['outcome'], r['outcome'])} "
            f"| {lat_s} | {r.get('attempts') or ''} "
            f"| {'' if r.get('row_count') in (None, '') else r['row_count']} "
            f"| {'' if conf is None else '%.2f' % conf} "
            f"| {'' if strict is None else '%.2f' % strict} "
            f"| {'' if ground is None else '%.2f' % ground} "
            f"| {'; '.join(r.get('guards') or [])} | {q} |")
    # Full per-query detail: generated SQL + log digest for EVERY query
    # (failures are flagged; successes keep their SQL reviewable too).
    lines += ["", "## Per-query detail (generated SQL + log digest)", ""]
    needs_attention = ("empty_success", "failed", "pipeline_error",
                       "timeout", "infra_error")
    for r in records:
        flag = "  ⚠ NEEDS ATTENTION" if r["outcome"] in needs_attention else ""
        lines += [f"### {r['id']} -- {r['outcome']}{flag}",
                  f"**Q:** {r['question']}", ""]
        if r.get("sql"):
            lines += ["```sql", r["sql"], "```", ""]
        else:
            lines += ["_No SQL generated._", ""]
        if r.get("faithfulness"):
            ff = f" — {r['faithfulness_flags']}" if r.get("faithfulness_flags") else ""
            lines += [f"**SQL faithfulness:** {r['faithfulness']}{ff}", ""]
        if r.get("log_summary"):
            lines += [f"**Log:** {r['log_summary']}", ""]
        if r.get("error") and r["outcome"] in needs_attention:
            lines += [f"Error: `{r['error']}`", ""]
        if r.get("answer") and r["outcome"] != "success":
            lines += [f"Answer (truncated): {r['answer'][:400]}", ""]
    Path(f"{out_prefix}.md").write_text("\n".join(lines) + "\n",
                                        encoding="utf-8")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(description="Evaluate the REQA agent on a "
                                 "JSON dictionary of natural-language queries.")
    ap.add_argument("--queries", default="mds_queries.json",
                    help="JSON file: {id: question} (default mds_queries.json)")
    ap.add_argument("--api", "--api-url", dest="api",
                    default="http://localhost:8080",
                    help="Base URL of the REQA API (default http://localhost:8080)")
    ap.add_argument("--api-key", default="", help="Optional API key header")
    ap.add_argument("--timeout", type=float, default=400.0,
                    help="Per-query timeout in seconds (default 400)")
    ap.add_argument("--poll", type=float, default=2.0,
                    help="Status poll interval in seconds (default 2)")
    ap.add_argument("--only", default="",
                    help="Comma-separated subset of query ids (e.g. q1,q4,q20)")
    ap.add_argument("--verify-db", default="",
                    help="Optional DB DSN user:pass@host:port/db to check "
                         "unverified filter literals against real data "
                         "(needs pymysql or mysql-connector installed)")
    ap.add_argument("--out", default="eval_results",
                    help="Output file prefix (default eval_results)")
    args = ap.parse_args()

    qpath = Path(args.queries)
    if not qpath.exists():
        print(f"Queries file not found: {qpath}", file=sys.stderr)
        return 2
    raw = json.loads(qpath.read_text(encoding="utf-8"))
    queries = {k: v for k, v in raw.items()
               if isinstance(v, str) and not k.startswith("_")}
    if args.only:
        keep = {x.strip() for x in args.only.split(",") if x.strip()}
        queries = {k: v for k, v in queries.items() if k in keep}
    if not queries:
        print("No queries to run.", file=sys.stderr)
        return 2

    api = args.api.rstrip("/")
    started_at = time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"Evaluating {len(queries)} queries against {api} "
          f"(timeout {args.timeout:.0f}s each)\n")

    records: list[dict] = []
    for i, (qid, question) in enumerate(queries.items(), 1):
        print(f"[{i}/{len(queries)}] {qid}: {question[:70]}"
              f"{'...' if len(question) > 70 else ''}")
        rec = run_one_query(args.api, args.api_key, question,
                            args.timeout, args.poll,
                            verify_db=args.verify_db)
        rec.update(id=qid, question=question, table="")
        records.append(rec)
        icon = _OUTCOME_ICON.get(rec["outcome"], rec["outcome"])
        conf = _to_float(rec.get("confidence"))
        extra = ""
        if rec.get("row_count") not in (None, ""):
            extra += f", rows={rec['row_count']}"
        if conf is not None:
            extra += f", conf={conf:.2f}"
        if rec.get("faithfulness") and rec["faithfulness"] != "faithful":
            extra += f", sql={rec['faithfulness']}"
        guards = (f", guards: {'; '.join(rec['guards'])}"
                  if rec.get("guards") else "")
        print(f"    -> {icon} in {rec['elapsed']}s"
              f" (attempts={rec.get('attempts')}{extra}){guards}")
        if rec.get("sql"):
            sql_flat = " ".join(rec["sql"].split())
            print(f"       SQL: {sql_flat[:160]}"
                  f"{'...' if len(sql_flat) > 160 else ''}")
        if rec.get("log_summary"):
            print(f"       log: {rec['log_summary'][:220]}"
                  f"{'...' if len(rec['log_summary']) > 220 else ''}")
        print()

    write_reports(records, args.out, api, started_at)

    stats = summarize_confidences(records)
    counts: dict[str, int] = {}
    for r in records:
        counts[r["outcome"]] = counts.get(r["outcome"], 0) + 1
    print("=" * 60)
    print("SUMMARY:", ", ".join(f"{k}={v}" for k, v in sorted(counts.items())))
    print(f"Success rate : {stats['passed']}/{stats['questions']} "
          f"({_pct(stats['success_rate'])})")
    print(f"Mean conf    : {_pct(stats['mean_confidence'])} "
          f"(rag {_pct(stats['mean_rag_conf'])} / gen {_pct(stats['mean_gen_conf'])} "
          f"/ sem {_pct(stats['mean_sem_conf'])} / strict {_pct(stats['mean_score_strict'])})")
    print(f"Grounding    : {_pct(stats['mean_grounding'])} mean, "
          f"hallucination rate {_pct(stats['hallucination_rate'])}")
    print(f"GLOBAL SCORE : {_pct(stats['global_score'])} (rate x conf)")
    print(f"Reports: {args.out}.md  {args.out}.json  {args.out}.csv")
    bad = sum(counts.get(k, 0) for k in
              ("failed", "pipeline_error", "timeout", "infra_error"))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())