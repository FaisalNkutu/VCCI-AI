"""Create a clean, in-scope smoke benchmark with executable reference SQL."""
import json
from pathlib import Path

OUT = Path(__file__).parent / "question_sets" / "Targeted_VCCI_32_Test_Questions.json"
TABLES = [
    "act_event", "act_task", "simulator_task", "act_stat", "comms_event", "conn",
    "action_group", "simulator_task_event", "fire_event", "tx_event", "rx_event",
    "msg_type", "comms_event_msg_type_assoc", "simulator_task_trigger", "blob_obj",
    "data_flow_spec", "scenario", "callsign", "loc", "obj_item", "obj_type", "contxt",
    "move_act_task", "param", "mapper", "act_loc_assoc", "act_oi_assoc", "act_ot_assoc",
    "contxt_act_assoc", "conn_mapper_assoc", "conn_param_assoc", "holding",
]
CATEGORIES = ["single-table", "filtering", "aggregation", "ordering"]
cases = []
for i, table in enumerate(TABLES, 1):
    category = CATEGORIES[(i - 1) % len(CATEGORIES)]
    if category == "filtering":
        question = f"Show up to 25 records from {table}."
    elif category == "aggregation":
        question = f"Count the records in {table}."
    elif category == "ordering":
        question = f"Show the first 25 records from {table}."
    else:
        question = f"List up to 25 records from {table}."
    cases.append({
        "test_id": f"targeted_{i:02d}",
        "category": category,
        "question": question,
        "expected_command": "SELECT",
        "required_tables": [table],
        "expected_tables": [table],
        "expected_columns": [],
        "semantic_assertions": [f"The query reads from {table}"],
        "expected_outcome": "data",
        "reference_sql": (f"SELECT COUNT(*) AS record_count FROM `{table}`;" if category == "aggregation"
                           else f"SELECT * FROM `{table}` LIMIT 25;"),
    })
OUT.write_text(json.dumps({"instructions": {"purpose": "In-scope VCCI benchmark; reference SQL is an execution oracle, not a required syntax."}, "test_cases": cases}, indent=2) + "\n", encoding="utf-8")
print(f"Wrote {len(cases)} cases to {OUT}")
