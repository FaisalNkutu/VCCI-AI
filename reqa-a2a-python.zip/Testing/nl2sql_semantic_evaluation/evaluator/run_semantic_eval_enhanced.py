"""Tolerant semantic/performance evaluation for the NL2SQL agent.

This deliberately lives beside, rather than inside, the historical evaluator.
It treats the reference SQL as guidance, accepts equivalent query shapes, and
keeps infrastructure failures separate from SQL failures.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import re
import sys
import time
from decimal import Decimal, InvalidOperation
from collections import Counter
from pathlib import Path
from typing import Any
try:
    import pymysql
except ImportError:  # reference comparison is optional
    pymysql = None

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, Preformatted, SimpleDocTemplate, Spacer, Table, TableStyle, PageBreak

ROOT = Path(__file__).resolve().parents[3]
EVAL = ROOT / "Testing" / "nl2sql_semantic_evaluation"
sys.path.insert(0, str(ROOT))
from config.settings import get_settings  # noqa: E402
from a2a_common.a2a_base_client_setup import A2AClientSend  # noqa: E402
from agent.sem_conf import _compute_sem_conf  # noqa: E402


DEFAULT_FILES = [
    Path(__file__).resolve().parents[1] / "question_sets" / "Targeted_VCCI_32_Test_Questions.json",
    Path(__file__).resolve().parents[1] / "question_sets" / "Action_Domain_16_Test_Questions.json",
    Path(__file__).resolve().parents[1] / "question_sets" / "Action_Domain_32_Test_Questions.json",
    Path(__file__).resolve().parents[1] / "question_sets" / "LN25_Expert_Test_Questions.json",
]


def load_cases(path: Path) -> list[dict[str, Any]]:
    # PowerShell ConvertTo-Json commonly writes a UTF-8 BOM.
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    data = data.get("test_cases", data) if isinstance(data, dict) else data
    return [dict(x) for x in data if isinstance(x, dict) and x.get("question")]


def tables(sql: str) -> set[str]:
    return {x.lower().split(".")[-1].strip('`[]"') for x in re.findall(r"\b(?:from|join)\s+([\w.`\[\]-]+)", sql or "", re.I)}


def identifiers(sql: str, expected: list[str]) -> list[str]:
    return [c for c in expected if re.search(rf"(?<!\w){re.escape(c.split('.')[-1])}(?!\w)", sql or "", re.I)]


def sql_safety(sql: str) -> dict[str, Any]:
    """Classify SQL without rejecting valid equivalent SELECT syntax."""
    text = (sql or "").strip()
    if not text:
        return {"status": "MISSING", "reason": "No SQL"}
    statements = [part.strip() for part in text.split(";") if part.strip()]
    first = statements[0].lower()
    if len(statements) > 1:
        return {"status": "UNSAFE", "reason": "Multiple SQL statements"}
    if not re.match(r"^(select|with)\b", first):
        return {"status": "UNSAFE", "reason": "Only read-only SELECT/WITH is allowed"}
    if re.search(r"\b(insert|update|delete|drop|alter|truncate|create|replace)\b", first, re.I):
        return {"status": "UNSAFE", "reason": "Write or schema-changing keyword detected"}
    return {"status": "VALID", "reason": "Read-only SELECT/WITH"}


def context_diagnostics(debug: dict[str, Any], expected: list[str], sql_tables: list[str]) -> dict[str, Any]:
    """Extract retrieval/planner evidence when the agent exposes debug data."""
    context = str(debug.get("schema_context") or debug.get("schema_preview") or "")
    # A2A debug may expose tables as a list, or only in the rendered schema.
    raw_tables = debug.get("retrieved_tables") or []
    retrieved = {str(t).lower().split(".")[-1] for t in raw_tables}
    retrieved.update(tables(context))
    if not retrieved and context:
        retrieved.update(x.lower() for x in re.findall(r"--\s*\[[^\]]*\]\s+([A-Za-z0-9_]+)", context))
    required = {x.lower().split(".")[-1] for x in expected}
    matched = sorted(required & retrieved) if required else []
    recall = (len(matched) / len(required)) if required else 1.0
    planner = debug.get("planner") or {}
    completion = debug.get("completion_check") or {}
    planner_tables = [str(x).lower() for x in planner.get("tables_needed", [])] if isinstance(planner, dict) else []
    planner_missing = sorted(set(planner_tables) - set(sql_tables))
    relevance = [float(x) for x in re.findall(r"Relevance:\s*([0-9.]+)", context, re.I)]
    return {"retrieved_tables": sorted(retrieved), "required_table_recall": round(recall, 3),
            "context_chars": len(context), "relevance_scores": relevance[:20],
            "planner_tables": planner_tables, "planner_missing_tables": planner_missing,
            "completion_missing_tables": completion.get("missing_tables", []) if isinstance(completion, dict) else [],
            "completion_missing_joins": bool(completion.get("missing_joins")) if isinstance(completion, dict) else False}


def semantic_checks(case: dict[str, Any], sql: str, result: dict[str, Any]) -> dict[str, Any]:
    """Lightweight, explainable assertions; they supplement (not replace) execution."""
    q = str(case.get("question", "")).lower()
    text = (sql or "").lower()
    checks: list[dict[str, Any]] = []
    def check(name: str, ok: bool, evidence: str):
        checks.append({"name": name, "status": "PASS" if ok else "REVIEW", "evidence": evidence})
    if re.search(r"\b(count|how many|number of)\b", q):
        check("aggregation", bool(re.search(r"\b(count|sum|avg|min|max)\s*\(", text)), "aggregate function expected")
    if re.search(r"\b(first|top|up to|limit|latest|most recent)\b", q):
        check("row_limit_or_order", bool(re.search(r"\blimit\b", text)) or bool(re.search(r"\border\s+by\b", text)), "LIMIT/ORDER BY expected")
    if re.search(r"\b(join|related|with|including)\b", q) and len(case.get("expected_tables", [])) > 1:
        check("multi_table_join", bool(re.search(r"\bjoin\b", text)), "JOIN expected for multiple required tables")
    for phrase, pattern in [("direct fire", r"direct\s+fire|cat_code\s*=\s*['\"]df['\"]"),
                            ("indirect fire", r"indirect\s+fire|cat_code\s*=\s*['\"]idf['\"]"),
                            ("friendly", r"hostility_code\s*=\s*['\"]fr['\"]|['\"]fr['\"]"),
                            ("hostile", r"hostility_code\s*=\s*['\"]ho['\"]|['\"]ho['\"]")]:
        if phrase in q:
            check(phrase, bool(re.search(pattern, text, re.I)), f"condition related to '{phrase}'")
    if not checks:
        return {"status": "NOT_APPLICABLE", "checks": [], "passed": 0, "total": 0}
    passed = sum(x["status"] == "PASS" for x in checks)
    return {"status": "PASS" if passed == len(checks) else "REVIEW", "checks": checks, "passed": passed, "total": len(checks)}


def extract_payload(response: Any) -> dict[str, Any]:
    try:
        json_text = "{}"
        for artifact in response.root.result.artifacts:
            for part in artifact.parts:
                if hasattr(part.root, "text"):
                    json_text = part.root.text
        value = json.loads(json_text)
        # A2A wraps the agent payload in an outer Success/Response object.
        if isinstance(value, dict) and isinstance(value.get("Response"), dict):
            return value["Response"]
        return value
    except Exception:
        return {}


async def ask(settings: Any, question: str) -> dict[str, Any]:
    started = time.perf_counter()
    try:
        # Same A2A request contract as the legacy runner, implemented here
        # independently so this evaluator does not import or modify it.
        request = {"GenerateSQL": {"Request": "GenerateSQL", "Query": question,
                                    "options": {"debug": True, "force": True}}}
        response = await A2AClientSend(settings.A2A_HOST, settings.A2A_PORT, request, False, lambda _: None,
                                       path=settings.A2A_PATH)
        result = extract_payload(response)
        # Legacy A2A names the SQL field `generated_sql`.
        if result and not result.get("sql") and result.get("generated_sql"):
            result["sql"] = result["generated_sql"]
        if not result or (not result.get("success") and not result.get("sql")):
            preview = ""
            try:
                preview = response.model_dump_json(exclude_none=True)[:2000]
            except Exception:
                preview = repr(response)[:2000]
            raise RuntimeError("A2A returned no usable SQL response | response=" + preview)
    except Exception as exc:
        result = {"success": False, "error": f"A2A failure: {exc}"}
    result["elapsed_seconds"] = round(time.perf_counter() - started, 3)
    return result


def reference_compare(case: dict[str, Any], generated: dict[str, Any], settings: Any) -> dict[str, Any]:
    """Compare result sets when expert reference_sql is supplied.

    Comparison is tolerant: column names are ignored, values are normalised,
    and row order is ignored unless the question explicitly asks for ordering.
    """
    ref = case.get("reference_sql")
    if not ref:
        return {"status": "NOT_PROVIDED"}
    if pymysql is None:
        return {"status": "UNAVAILABLE", "error": "pymysql is not installed"}
    try:
        conn = pymysql.connect(host=settings.DB_HOST, port=int(settings.DB_PORT), user=settings.DB_USER,
                               password=settings.DB_PASSWORD, database=settings.DB_NAME, cursorclass=pymysql.cursors.DictCursor)
        with conn.cursor() as cur:
            cur.execute(ref); reference_rows = cur.fetchall()
        conn.close()
        actual = generated.get("rows") or []
        def norm_value(value):
            # The A2A renderer serializes SQL NULL as the literal string
            # "None"; the reference cursor returns Python None. Treat them
            # as the same value (and similarly for JSON-style null).
            if value is None or str(value).strip().lower() in {"none", "null"}:
                return None
            if isinstance(value, (int, float, Decimal)) and not isinstance(value, bool):
                return Decimal(str(value))
            if isinstance(value, str) and re.fullmatch(r"[-+]?\d+(?:\.\d+)?", value.strip()):
                try:
                    return Decimal(value.strip())
                except InvalidOperation:
                    pass
            return value
        def norm(rows):
            return sorted((tuple(norm_value(v) for v in dict(row).values()) for row in rows), key=repr)
        equal = norm(actual) == norm(reference_rows)
        return {"status": "MATCH" if equal else "MISMATCH", "reference_row_count": len(reference_rows), "generated_row_count": len(actual)}
    except Exception as exc:
        return {"status": "UNAVAILABLE", "error": f"reference execution failed: {exc}"}


def evaluate(case: dict[str, Any], result: dict[str, Any], settings: Any) -> dict[str, Any]:
    sql = str(result.get("sql") or "")
    expected = [str(x).lower().split(".")[-1] for x in case.get("expected_tables", [])]
    found = sorted(tables(sql))
    missing = [t for t in expected if t not in found]
    cols = [str(x) for x in case.get("expected_columns", [])]
    matched_cols = identifiers(sql, cols)
    debug = result.get("debug") or {}
    safety = sql_safety(sql)
    retrieval = context_diagnostics(debug, expected, found)
    semantic = semantic_checks(case, sql, result)
    sem = debug.get("sem_conf")
    if sem is None:
        try:
            sem = _compute_sem_conf(case["question"], sql, expected)
        except Exception:
            sem = None
    infra = bool(result.get("error")) and not sql
    ref_check = reference_compare(case, result, settings) if result.get("success") else {"status": "NOT_RUN"}
    expected_outcome = str(case.get("expected_outcome", "data")).lower()
    if infra:
        verdict = "INFRA_FAILURE"
        reason = str(result.get("error"))
    elif expected_outcome == "rejected" and not sql:
        verdict, reason = "PASS", "Question correctly rejected without SQL"
    elif not sql:
        verdict, reason = "FAIL", "No SQL was generated"
    elif safety["status"] == "UNSAFE":
        verdict, reason = "FAIL", safety["reason"]
    elif not result.get("success", False):
        verdict, reason = "FAIL", "SQL did not execute successfully"
    elif expected_outcome == "rejected":
        verdict, reason = ("PASS", "Question correctly rejected") if not sql else ("NEEDS_REVIEW", "Expected rejection but SQL was generated")
    elif expected_outcome == "zero_rows" and int(result.get("row_count", 0) or 0) != 0:
        verdict, reason = "NEEDS_REVIEW", "Expected zero rows but the query returned data"
    elif (ref_check.get("status") == "MATCH" and expected_outcome == "data"
          and int(ref_check.get("reference_row_count", 0) or 0) == 0
          and int(ref_check.get("generated_row_count", 0) or 0) == 0):
        verdict, reason = "NEEDS_REVIEW", "Both queries returned zero rows; result equality is inconclusive"
    elif ref_check.get("status") == "MISMATCH":
        verdict, reason = "NEEDS_REVIEW", "Generated result differs from tolerant reference result"
    elif missing:
        verdict, reason = "NEEDS_REVIEW", f"Required tables not observed: {', '.join(missing)}"
    elif sem is not None and float(sem) < 0.5:
        verdict, reason = "NEEDS_REVIEW", f"Low semantic confidence ({float(sem):.2f})"
    elif semantic["status"] == "REVIEW":
        verdict, reason = "NEEDS_REVIEW", "One or more question-intent checks need review"
    else:
        verdict, reason = "PASS", "Executable SQL with tolerant table/intent checks"
    return {"test_id": case.get("test_id", ""), "question": case["question"],
            "category": case.get("category", "Uncategorised"), "verdict": verdict, "reason": reason,
            "elapsed_seconds": result.get("elapsed_seconds", 0), "success": bool(result.get("success")),
            "sem_conf": sem, "expected_tables": expected, "retrieved_tables": found, "missing_tables": missing,
            "expected_columns": cols, "matched_columns": matched_cols, "reference_comparison": ref_check,
            "sql": sql, "rows": result.get("rows") or [], "row_count": result.get("row_count", 0),
            "answer": result.get("answer", ""), "error": result.get("error", ""),
            "raw_preview": result.get("raw_preview", ""), "debug": debug,
            "sql_safety": safety, "retrieval": retrieval, "semantic_checks": semantic,
            "expected_outcome": expected_outcome}


def write_pdf(path: Path, rows: list[dict[str, Any]], files: list[Path], total_seconds: float | None = None) -> None:
    base = getSampleStyleSheet()
    styles = {"title": ParagraphStyle("ReportTitle", parent=base["Title"], fontSize=19, leading=23, textColor=colors.HexColor("#172033")),
              "section": ParagraphStyle("Section", parent=base["Heading2"], fontSize=13, leading=16, textColor=colors.HexColor("#172033"), spaceBefore=8, spaceAfter=6),
              "heading": ParagraphStyle("TestHeading", parent=base["Heading3"], fontSize=11, leading=14, spaceBefore=8),
              "body": base["BodyText"], "code": ParagraphStyle("ReportCode", fontName="Courier", fontSize=7, leading=8, textColor=colors.white)}
    doc = SimpleDocTemplate(str(path), pagesize=A4, rightMargin=18*mm, leftMargin=18*mm, topMargin=17*mm, bottomMargin=18*mm, title="Tolerant NL2SQL Evaluation")
    story = [Paragraph("Tolerant NL-to-SQL Evaluation Report", styles["title"]),
             Paragraph("Automated test evidence with semantic and performance diagnostics", styles["body"]), Spacer(1, 6)]
    counts = Counter(r["verdict"] for r in rows)
    avg = sum(float(r["elapsed_seconds"]) for r in rows) / max(len(rows), 1)
    if counts.get("FAIL", 0) or counts.get("INFRA_FAILURE", 0):
        verdict_text, verdict_colour = "FAIL", "#b91c1c"
    elif counts.get("NEEDS_REVIEW", 0):
        verdict_text, verdict_colour = "NEEDS REVIEW", "#b45309"
    else:
        verdict_text, verdict_colour = "PASS", "#15803d"
    total_display = f"{float(total_seconds):.2f} seconds" if total_seconds is not None else "See per-question times"
    metadata = [[Paragraph("<b>Run date</b>", styles["body"]), Paragraph(time.strftime("%d %B %Y, %H:%M"), styles["body"])],
                [Paragraph("<b>Questions tested</b>", styles["body"]), Paragraph(str(len(rows)), styles["body"])],
                [Paragraph("<b>Overall verdict</b>", styles["body"]), Paragraph(f'<font color="{verdict_colour}"><b>{verdict_text}</b></font> ({counts.get("PASS", 0)} / {len(rows)} PASS)', styles["body"])],
                [Paragraph("<b>Total run time</b>", styles["body"]), Paragraph(total_display, styles["body"])],
                [Paragraph("<b>Average question time</b>", styles["body"]), Paragraph(f"{avg:.2f} seconds", styles["body"])]]
    story.append(Table(metadata, colWidths=[48*mm, 122*mm], style=TableStyle([("GRID", (0,0), (-1,-1), .4, colors.HexColor("#aab4c3")), ("BACKGROUND", (0,0), (0,-1), colors.HexColor("#eef2f7")), ("VALIGN", (0,0), (-1,-1), "TOP"), ("LEFTPADDING", (0,0), (-1,-1), 6), ("RIGHTPADDING", (0,0), (-1,-1), 6)])))
    story.append(Spacer(1, 8))
    story.append(Paragraph("1. Executive Summary", styles["section"]))
    summary = [["Verdict", "Count", "Meaning"], ["PASS", counts.get("PASS", 0), "Executable and semantically supported"], ["NEEDS_REVIEW", counts.get("NEEDS_REVIEW", 0), "Executable but semantic evidence is incomplete"], ["FAIL", counts.get("FAIL", 0), "SQL missing, invalid, or unsuccessful"], ["INFRA_FAILURE", counts.get("INFRA_FAILURE", 0), "Agent, API, or response-format problem"]]
    story.append(Table(summary, colWidths=[42*mm, 20*mm, 108*mm], style=TableStyle([("GRID", (0,0), (-1,-1), .4, colors.HexColor("#aab4c3")), ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#d8e0ec")), ("VALIGN", (0,0), (-1,-1), "TOP"), ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"), ("LEFTPADDING", (0,0), (-1,-1), 6), ("RIGHTPADDING", (0,0), (-1,-1), 6)])))
    story.append(Paragraph("2. Quality and Performance Metrics", styles["section"]))
    review_count = sum(r["verdict"] == "NEEDS_REVIEW" for r in rows)
    recalls = [float(r.get("retrieval", {}).get("required_table_recall", 0)) for r in rows]
    ref_match = sum(r.get("reference_comparison", {}).get("status") == "MATCH" for r in rows)
    metrics = [["Metric", "Value", "Interpretation"],
               ["Infrastructure failures", counts.get("INFRA_FAILURE", 0), "A2A/API/response problems"],
               ["Needs manual review", review_count, "SQL ran but evidence is incomplete"],
               ["Average required-table recall", f"{sum(recalls)/max(len(recalls),1):.2f}", "Retrieved/used required tables"],
               ["Reference result matches", ref_match, "Equivalent result set where reference SQL exists"]]
    story.append(Table(metrics, colWidths=[58*mm, 30*mm, 92*mm], style=TableStyle([("GRID", (0,0), (-1,-1), .4, colors.HexColor("#aab4c3")), ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#d8e0ec")), ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"), ("VALIGN", (0,0), (-1,-1), "TOP")])))
    story.append(Paragraph("3. Performance by Category", styles["section"]))
    cats = Counter(r["category"] for r in rows)
    story.append(Table([["Category", "Questions", "Passes"]] + [[k, v, sum(r["verdict"] == "PASS" and r["category"] == k for r in rows)] for k, v in sorted(cats.items())], colWidths=[90*mm, 35*mm, 45*mm], style=TableStyle([("GRID", (0,0), (-1,-1), .4, colors.HexColor("#aab4c3")), ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#d8e0ec")), ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold")])) )
    story.append(PageBreak())
    story.append(Paragraph("4. Individual Test Details", styles["section"]))
    for r in rows:
        sem = "n/a" if r["sem_conf"] is None else f"{float(r['sem_conf']):.2f}"
        colour = "#166534" if r["verdict"] == "PASS" else "#991b1b" if r["verdict"] == "FAIL" else "#92400e"
        retrieval = r.get("retrieval", {})
        checks = [["Check", "Result", "Evidence"], ["Semantic confidence", sem, "Deterministic confidence signal"], ["Execution", "PASS" if r["success"] else "FAIL", "Agent execution status"], ["Required tables", "PASS" if not r["missing_tables"] else "REVIEW", ", ".join(r["retrieved_tables"]) or "None"], ["Table recall", f"{retrieval.get('required_table_recall', 0):.2f}", "Required tables found in SQL/schema context"], ["SQL safety", r.get("sql_safety", {}).get("status", "n/a"), r.get("sql_safety", {}).get("reason", "")], ["Intent checks", r.get("semantic_checks", {}).get("status", "n/a"), f"{r.get('semantic_checks', {}).get('passed', 0)}/{r.get('semantic_checks', {}).get('total', 0)} checks passed"], ["Reference result", r.get("reference_comparison", {}).get("status", "NOT_RUN"), "Tolerant row comparison when reference SQL exists"]]
        returned = r.get("rows") or []
        # Render every returned row; ReportLab splits the table across pages.
        preview_rows = returned if isinstance(returned, list) else []
        if preview_rows and isinstance(preview_rows[0], dict):
            keys = list(preview_rows[0].keys())
            data_table = [[Paragraph(f"<b>{str(k)}</b>", styles["body"]) for k in keys]]
            data_table += [[Paragraph(str(row.get(k, "")), styles["body"]) for k in keys] for row in preview_rows]
            returned_flowable = Table(data_table, repeatRows=1, colWidths=[170*mm / max(len(keys), 1)],
                                      style=TableStyle([("GRID", (0,0), (-1,-1), .35, colors.HexColor("#aab4c3")),
                                                        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#d8e0ec")),
                                                        ("VALIGN", (0,0), (-1,-1), "TOP"),
                                                        ("LEFTPADDING", (0,0), (-1,-1), 4), ("RIGHTPADDING", (0,0), (-1,-1), 4)]))
        else:
            returned_flowable = Preformatted("No rows returned.", styles["code"])
        story.extend([Paragraph(f'<font color="{colour}"><b>{r["verdict"]}</b></font> - {r["test_id"]}', styles["heading"]), Paragraph(f"<b>Category:</b> {r['category']}<br/><b>Question:</b> {r['question']}<br/><b>Time:</b> {r['elapsed_seconds']}s", styles["body"]), Spacer(1, 4), Table(checks, colWidths=[45*mm, 30*mm, 95*mm], style=TableStyle([("GRID", (0,0), (-1,-1), .4, colors.HexColor("#aab4c3")), ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#d8e0ec")), ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"), ("VALIGN", (0,0), (-1,-1), "TOP")])), Spacer(1, 4), Paragraph("Generated SQL", styles["body"]), Table([[Preformatted(r["sql"] or r["error"] or "No SQL generated.", styles["code"])]], colWidths=[170*mm], style=TableStyle([("BACKGROUND", (0,0), (-1,-1), colors.HexColor("#111827")), ("BOX", (0,0), (-1,-1), .5, colors.HexColor("#111827")), ("LEFTPADDING", (0,0), (-1,-1), 7), ("RIGHTPADDING", (0,0), (-1,-1), 7), ("TOPPADDING", (0,0), (-1,-1), 7), ("BOTTOMPADDING", (0,0), (-1,-1), 7)])), Spacer(1, 4), Paragraph(f"Returned Data ({r.get('row_count', len(returned))} row(s))", styles["body"]), returned_flowable, Spacer(1, 8)])
    doc.build(story)


async def main() -> None:
    p = argparse.ArgumentParser(); p.add_argument("--questions-file", action="append", type=Path); p.add_argument("--test-id", help="run only one test_id from each selected question file"); p.add_argument("--output-dir", type=Path, default=EVAL / "output" / "semantic_evaluation"); p.add_argument("--all", action="store_true", help="evaluate all default sets (default)")
    args = p.parse_args(); files = args.questions_file or DEFAULT_FILES
    settings = get_settings(); all_rows = []; overall_started = time.perf_counter()
    for file in files:
        if not file.exists(): print(f"Skipping missing question set: {file}"); continue
        rows = []; file_started = time.perf_counter()
        cases = load_cases(file)
        if args.test_id:
            cases = [case for case in cases if case.get("test_id") == args.test_id]
            if not cases:
                print(f"{args.test_id}: not found in {file.name}"); continue
        for case in cases:
            result = await ask(settings, case["question"])
            rows.append(evaluate(case, result, settings))
        stem = file.stem.replace("_Test_Questions", "")
        args.output_dir.mkdir(parents=True, exist_ok=True)
        (args.output_dir / f"{stem}_semantic.json").write_text(json.dumps(rows, indent=2, default=str), encoding="utf-8")
        file_elapsed = time.perf_counter() - file_started
        write_pdf(args.output_dir / f"{stem}_semantic.pdf", rows, [file], file_elapsed); all_rows.extend(rows)
        print(f"{stem}: {sum(r['verdict']=='PASS' for r in rows)}/{len(rows)} PASS; report written")
    if len(files) > 1: write_pdf(args.output_dir / "combined_semantic_report.pdf", all_rows, files, time.perf_counter() - overall_started)


if __name__ == "__main__": asyncio.run(main())
