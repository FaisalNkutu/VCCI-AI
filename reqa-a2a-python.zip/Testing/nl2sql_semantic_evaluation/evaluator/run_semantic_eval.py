"""Tolerant semantic/performance evaluation for the NL2SQL agent.

This deliberately lives beside, rather than inside, the historical evaluator.
It treats the reference SQL as guidance, accepts equivalent query shapes, and
keeps infrastructure failures separate from SQL failures.
"""
# Last update of DB agent script evaluator

from __future__ import annotations

import argparse
import asyncio
import json
import re
import sys
import time
import textwrap

from decimal import Decimal, InvalidOperation
from collections import Counter
from pathlib import Path
from typing import Any
try:
    import pymysql
except ImportError:  # reference comparison is optional
    pymysql = None

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, Preformatted, SimpleDocTemplate, Spacer, Table, TableStyle, PageBreak, KeepInFrame

ROOT = Path(__file__).resolve().parents[3]
EVAL = ROOT / "Testing" / "nl2sql_semantic_evaluation"
sys.path.insert(0, str(ROOT))
from config.settings import get_settings  # noqa: E402
from a2a_common.a2a_base_client_setup import A2AClientSend  # noqa: E402
from agent.sem_conf import _compute_sem_conf  # noqa: E402
import traceback
from datetime import datetime

DEFAULT_FILES = [
    Path(__file__).resolve().parents[1] / "question_sets" / "Action_Domain_16_Test_Questions.json",
    Path(__file__).resolve().parents[1] / "question_sets" / "Action_Domain_32_Test_Questions.json",
    Path(__file__).resolve().parents[1] / "question_sets" / "LN25_Expert_Test_Questions.json",
]

MAX_ROWS = 20  
MAX_CHARS = 100 # max chars in one cell

def load_cases(path: Path) -> list[dict[str, Any]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    data = data.get("test_cases", data) if isinstance(data, dict) else data
    return [dict(x) for x in data if isinstance(x, dict) and x.get("question")]


def tables(sql: str) -> set[str]:
    return {x.lower().split(".")[-1].strip('`[]"') for x in re.findall(r"\b(?:from|join)\s+([\w.`\[\]-]+)", sql or "", re.I)}


def identifiers(sql: str, expected: list[str]) -> list[str]:
    return [c for c in expected if re.search(rf"(?<!\w){re.escape(c.split('.')[-1])}(?!\w)", sql or "", re.I)]


def extract_payload(response: Any) -> dict[str, Any]:
    try:
        json_text = "{}"
        for artifact in response.root.result.artifacts:
            for part in artifact.parts:
                if hasattr(part.root, "text"):
                    json_text = part.root.text
        value = json.loads(json_text)
        # A2A wraps the agent payload in an outer Success/Response object.
        if isinstance(value, dict) and isinstance(value.get("Response"), dict):
            return value["Response"]
        return value
    except Exception:
        return {}


async def ask(settings: Any, question: str, **kwargs) -> dict[str, Any]:

    options = kwargs.get("options",  {"debug": True, "force": True, "rag_num_rated_rules" : 0 } )


    started = time.perf_counter()
    try:
        # Same A2A request contract as the legacy runner, implemented here
        # independently so this evaluator does not import or modify it.
        request = {"GenerateSQL": {"Request": "GenerateSQL", "Query": question,
                                    "options": options}}
        response = await A2AClientSend(settings.A2A_HOST, settings.A2A_PORT, request, False, lambda _: None,
                                       path=settings.A2A_PATH)
        result = extract_payload(response)
        # Legacy A2A names the SQL field `generated_sql`.
        if result and not result.get("sql") and result.get("generated_sql"):
            result["sql"] = result["generated_sql"]
        if not result or (not result.get("success") and not result.get("sql")):
            preview = ""
            try:
                preview = response.model_dump_json(exclude_none=True)[:2000]
            except Exception:
                preview = repr(response)[:2000]
            raise RuntimeError("A2A returned no usable SQL response | response=" + preview)
    except Exception as exc:
        result = {"success": False, "error": f"A2A failure: {exc}"}
    result["elapsed_seconds"] = round(time.perf_counter() - started, 3)
    return result

def rows_to_str(rows):
    rval = ""
    for row in rows:
        rval += str(row)  + "\n"
    return rval

def reference_compare(case: dict[str, Any], generated: dict[str, Any], settings: Any) -> dict[str, Any]:
    """Compare result sets when expert reference_sql is supplied.

    Comparison is tolerant: column names are ignored, values are normalised,
    and row order is ignored unless the question explicitly asks for ordering.
    """

    generated_sql = generated.get("sql")
    ref = case.get("reference_sql")
    if not ref:
        return {"status": "NOT_PROVIDED"}
    if pymysql is None:
        return {"status": "UNAVAILABLE", "error": "pymysql is not installed"}

    verification_info_dict = {}
    try:
        conn = pymysql.connect(host=settings.DB_HOST, port=int(settings.DB_PORT), user=settings.DB_USER,
                               password=settings.DB_PASSWORD, database=settings.DB_NAME, cursorclass=pymysql.cursors.DictCursor)
        with conn.cursor() as cur:
            cur.execute(ref); reference_rows = cur.fetchall()
        conn.close()
        actual = generated.get("rows") or []
        if len(actual) > MAX_ROWS:
            actual = actual[:MAX_ROWS]


        # return this info in the Json, it can be useful for Manual Verification
        # The Rows Compare can be severe, so NEED_REVIEW Still happens sometimes
        verification_info_dict = { "generated_rows" :  actual ,
                                    "reference_rows" : reference_rows,
                                    "generated_sql" :  str(generated_sql), 
                                    "reference_sql" : str(ref)  
                                    }

        print("===================================================================================")
        print("ROWS GENERATED=\n" + rows_to_str(verification_info_dict["generated_rows"])  + "\n" )
        print("ROWS REFERENCE=\n" + rows_to_str(verification_info_dict["reference_rows"]) + "\n" )
        print("SQL GENERATED=\n" +  verification_info_dict["generated_sql"] + "\n" )
        print("SQL REFERENCE=\n" +  verification_info_dict["reference_sql"]+ "\n" )
        print("===================================================================================")


        def norm_value(key, value):
            #print( f"norm_value({key},{value})" )
            # The A2A renderer serializes SQL NULL as the literal string
            # "None"; the reference cursor returns Python None. Treat them
            # as the same value (and similarly for JSON-style null).
            if value is None or str(value).strip().lower() in {"none", "null"}:
                return None
            # Drivers may return DECIMAL as Decimal while the A2A JSON
            # renderer returns the same value as a string.
            if isinstance(value, datetime):
                time_string = value.strftime("%Y-%m-%d %H:%M:%S.%f")
                return time_string
            elif isinstance(value, (int, float, Decimal)) and not isinstance(value, bool):
                # Change decimal time into string time
                if 'time' in key and not "sim_offset_time" in key:
                    try:
                        value = float(value) / 1e3                    
                        # 1. Convert integer to a UTC datetime object
                        dt = datetime.fromtimestamp( value )
                        # 2. Format with .%f for 6 digits of microseconds
                        time_string = dt.strftime("%Y-%m-%d %H:%M:%S.%f")
                    except:
                        print( f"Time Parsing failed for key={key}"  )
                        traceback.print_exc()                        
                    return time_string
                else:
                    return Decimal(str(value))
            elif isinstance(value, str) and re.fullmatch(r"[-+]?\d+(?:\.\d+)?", value.strip()):
                try:
                    return Decimal(value.strip())
                except InvalidOperation:
                    pass
            return value
        def norm(rows):
            # Compare the returned values, not aliases such as COUNT(*) vs
            # record_count. This accepts equivalent SQL result sets.
            returned_rows = []
            for row in rows:
                returned_row = []
                for k,v in dict(row).items():
                    nval = norm_value(k,v)
                    returned_row.append( nval )
                returned_rows.append(  tuple(returned_row) )
            return returned_rows                    
            #return sorted((tuple(norm_value(k,v) for k,v in dict(row).items()) for row in rows), key=repr)

        #
        #   Check if all rows equal.
        #   #Note: This is too severe
        #
        def rows_equal( genrow, refrow ):            
            if len(genrow) >= len(refrow):    
                for i in range( len(refrow) ):
                    if genrow[i] != refrow[i]:                    
                        return False                        
            else:
                return False

            return True
        
        norm_actual = norm(actual)
        norm_ref = norm(reference_rows)
        
        print("===================================================================================")
        print("NORM ROWS GENERATED=\n" + rows_to_str(norm_actual)  + "\n" )
        print("NORM ROWS REFERENCE=\n" + rows_to_str(norm_ref) + "\n" )
        print("===================================================================================")
        
        equal = False
        if len(norm_actual) == len(norm_ref):
            equal = True
            for i in range(len(norm_actual)):
                if not rows_equal( norm_actual[i], norm_ref[i] ):
                    equal = False
                    break
                    
        return {"status": "MATCH" if equal else "MISMATCH", "reference_row_count": len(reference_rows), "generated_row_count": len(actual), "verification_info" : verification_info_dict }
    except Exception as exc:
        traceback.print_exc()
        return {"status": "UNAVAILABLE", "error": f"reference execution failed: {exc}",  "verification_info" : verification_info_dict }


def evaluate(case: dict[str, Any], result: dict[str, Any], settings: Any) -> dict[str, Any]:
    sql = str(result.get("sql") or "")
    expected = [str(x).lower().split(".")[-1] for x in case.get("expected_tables", [])]
    found = sorted(tables(sql))
    missing = [t for t in expected if t not in found]
    cols = [str(x) for x in case.get("expected_columns", [])]
    matched_cols = identifiers(sql, cols)
    debug = result.get("debug") or {}
    sem = debug.get("sem_conf")
    if sem is None:
        try:
            sem = _compute_sem_conf(case["question"], sql, expected)
        except Exception:
            sem = None
    infra = bool(result.get("error")) and not sql
    ref_check = reference_compare(case, result, settings) if result.get("success") else {"status": "NOT_RUN"}
    expected_outcome = str(case.get("expected_outcome", "data")).lower()
    if infra:
        verdict = "INFRA_FAILURE"
        reason = str(result.get("error"))
    elif not sql:
        verdict, reason = "FAIL", "No SQL was generated"
    elif not result.get("success", False):
        verdict, reason = "FAIL", "SQL did not execute successfully"
    elif (ref_check.get("status") == "MATCH" and expected_outcome == "data"
          and int(ref_check.get("reference_row_count", 0) or 0) == 0
          and int(ref_check.get("generated_row_count", 0) or 0) == 0):
        verdict, reason = "NEEDS_REVIEW", "Both queries returned zero rows; result equality is inconclusive"
    elif ref_check.get("status") == "MISMATCH":
        verdict, reason = "NEEDS_REVIEW", "Generated result differs from tolerant reference result"
    elif missing:
        verdict, reason = "NEEDS_REVIEW", f"Required tables not observed: {', '.join(missing)}"
    elif sem is not None and float(sem) < 0.5:
        verdict, reason = "NEEDS_REVIEW", f"Low semantic confidence ({float(sem):.2f})"
    else:
        verdict, reason = "PASS", "Executable SQL with tolerant table/intent checks"

    saferows = result.get("rows")
    if saferows != None and len(saferows) > MAX_ROWS:
        saferows = saferows[:MAX_ROWS]

    return {"test_id": case.get("test_id", ""), "question": case["question"],
            "category": case.get("category", "Uncategorised"), "verdict": verdict, "reason": reason,
            "elapsed_seconds": result.get("elapsed_seconds", 0), "success": bool(result.get("success")),
            "sem_conf": sem, "expected_tables": expected, "retrieved_tables": found, "missing_tables": missing,
            "expected_columns": cols, "matched_columns": matched_cols, "reference_comparison": ref_check,
            "sql": sql, "rows": saferows or [], "row_count": result.get("row_count", 0),
            "reference_sql" : case.get("reference_sql"),
            "answer": result.get("answer", ""), "error": result.get("error", ""),
            "raw_preview": result.get("raw_preview", ""), "debug": debug}


def write_pdf(path: Path, rows: list[dict[str, Any]], files: list[Path], total_seconds: float | None = None) -> None:
    base = getSampleStyleSheet()
    styles = {"title": ParagraphStyle("ReportTitle", parent=base["Title"], fontSize=19, leading=23, textColor=colors.HexColor("#172033")),
              "section": ParagraphStyle("Section", parent=base["Heading2"], fontSize=13, leading=16, textColor=colors.HexColor("#172033"), spaceBefore=8, spaceAfter=6),
              "heading": ParagraphStyle("TestHeading", parent=base["Heading3"], fontSize=11, leading=14, spaceBefore=8),
              "body": base["BodyText"], "code": ParagraphStyle("ReportCode", fontName="Courier", fontSize=7, leading=8, textColor=colors.white)}
    doc = SimpleDocTemplate(str(path), pagesize=A4, rightMargin=18*mm, leftMargin=18*mm, topMargin=17*mm, bottomMargin=18*mm, title="Tolerant NL2SQL Evaluation")
    story = [Paragraph("Tolerant NL-to-SQL Evaluation Report", styles["title"]),
             Paragraph("Automated test evidence with semantic and performance diagnostics", styles["body"]), Spacer(1, 6)]
    counts = Counter(r["verdict"] for r in rows)
    avg = sum(float(r["elapsed_seconds"]) for r in rows) / max(len(rows), 1)
    if counts.get("FAIL", 0) or counts.get("INFRA_FAILURE", 0):
        verdict_text, verdict_colour = "FAIL", "#b91c1c"
    elif counts.get("NEEDS_REVIEW", 0):
        verdict_text, verdict_colour = "NEEDS REVIEW", "#b45309"
    else:
        verdict_text, verdict_colour = "PASS", "#15803d"
    total_display = f"{float(total_seconds):.2f} seconds" if total_seconds is not None else "See per-question times"
    metadata = [[Paragraph("<b>Run date</b>", styles["body"]), Paragraph(time.strftime("%d %B %Y, %H:%M"), styles["body"])],
                [Paragraph("<b>Questions tested</b>", styles["body"]), Paragraph(str(len(rows)), styles["body"])],
                [Paragraph("<b>Overall verdict</b>", styles["body"]), Paragraph(f'<font color="{verdict_colour}"><b>{verdict_text}</b></font> ({counts.get("PASS", 0)} / {len(rows)} PASS)', styles["body"])],
                [Paragraph("<b>Total run time</b>", styles["body"]), Paragraph(total_display, styles["body"])],
                [Paragraph("<b>Average question time</b>", styles["body"]), Paragraph(f"{avg:.2f} seconds", styles["body"])]]
    story.append(Table(metadata, colWidths=[48*mm, 122*mm], style=TableStyle([("GRID", (0,0), (-1,-1), .4, colors.HexColor("#aab4c3")), ("BACKGROUND", (0,0), (0,-1), colors.HexColor("#eef2f7")), ("VALIGN", (0,0), (-1,-1), "TOP"), ("LEFTPADDING", (0,0), (-1,-1), 6), ("RIGHTPADDING", (0,0), (-1,-1), 6)])))
    story.append(Spacer(1, 8))
    story.append(Paragraph("1. Executive Summary", styles["section"]))
    summary = [["Verdict", "Count", "Meaning"], ["PASS", counts.get("PASS", 0), "Executable and semantically supported"], ["NEEDS_REVIEW", counts.get("NEEDS_REVIEW", 0), "Executable but semantic evidence is incomplete"], ["FAIL", counts.get("FAIL", 0), "SQL missing, invalid, or unsuccessful"], ["INFRA_FAILURE", counts.get("INFRA_FAILURE", 0), "Agent, API, or response-format problem"]]
    story.append(Table(summary, colWidths=[42*mm, 20*mm, 108*mm], style=TableStyle([("GRID", (0,0), (-1,-1), .4, colors.HexColor("#aab4c3")), ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#d8e0ec")), ("VALIGN", (0,0), (-1,-1), "TOP"), ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"), ("LEFTPADDING", (0,0), (-1,-1), 6), ("RIGHTPADDING", (0,0), (-1,-1), 6)])))
    story.append(Paragraph("2. Performance by Category", styles["section"]))
    cats = Counter(r["category"] for r in rows)
    story.append(Table([["Category", "Questions", "Passes"]] + [[k, v, sum(r["verdict"] == "PASS" and r["category"] == k for r in rows)] for k, v in sorted(cats.items())], colWidths=[90*mm, 35*mm, 45*mm], style=TableStyle([("GRID", (0,0), (-1,-1), .4, colors.HexColor("#aab4c3")), ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#d8e0ec")), ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold")])) )
    story.append(PageBreak())
    story.append(Paragraph("3. Individual Test Details", styles["section"]))

    row_index = 0
    for r in rows:
        sem = "n/a" if r["sem_conf"] is None else f"{float(r['sem_conf']):.2f}"
        colour = "#166534" if r["verdict"] == "PASS" else "#991b1b" if r["verdict"] == "FAIL" else "#92400e"
        checks = [["Check", "Result", "Evidence"], ["Semantic confidence", sem, "Existing deterministic sem_conf"], ["Execution", "PASS" if r["success"] else "FAIL", "Agent execution status"], ["Required tables", "PASS" if not r["missing_tables"] else "REVIEW", ", ".join(r["retrieved_tables"]) or "None"], ["Reference result", r.get("reference_comparison", {}).get("status", "NOT_RUN"), "Tolerant row comparison when reference SQL exists"]]
        returned = r.get("rows") or []
        reference_sql = r.get( "reference_sql" ) or "No reference SQL"
        if len(returned) > MAX_ROWS:
            returned = returned[:MAX_ROWS]
        # Render every returned row; ReportLab splits the table across pages.
        preview_rows = returned if isinstance(returned, list) else []
        

        try:
            if preview_rows and isinstance(preview_rows[0], dict):
                for prow in preview_rows:
                    for key,val in prow.items():
                        strcell = str(val)
                        if len(strcell) > MAX_CHARS:
                            prow[key] = strcell[:MAX_CHARS] + "..."

                print( f"PREVIEW_ROWS[1]={preview_rows[1]}" )
                keys = list(preview_rows[0].keys())
                data_table = [[Paragraph(f"<b>{str(k)}</b>", styles["body"]) for k in keys]]
                data_table += [[Paragraph(str(row.get(k, "")), styles["body"]) for k in keys] for row in preview_rows]
                returned_flowable = Table(data_table, repeatRows=1, colWidths=[170*mm / max(len(keys), 1)],
                                        style=TableStyle([("GRID", (0,0), (-1,-1), .35, colors.HexColor("#aab4c3")),
                                                            ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#d8e0ec")),
                                                            ("VALIGN", (0,0), (-1,-1), "TOP"),
                                                            ("LEFTPADDING", (0,0), (-1,-1), 4), ("RIGHTPADDING", (0,0), (-1,-1), 4)]))
            else:
                returned_flowable = Preformatted("No rows returned.", styles["code"])
        except Exception as e:
            pdf_gen_err = traceback.format_exc()
            traceback.print_exc()
            returned_flowable = Preformatted(f"PDF Generation error: {pdf_gen_err}", styles["code"])

        """ safe_returned_flowable = KeepInFrame(
            maxWidth=doc.width, 
            maxHeight=doc.height, 
            content=[returned_flowable], 
            mode='shrink'
        )"""

        reference_sql = str(r["reference_sql"])
        try:
            reference_sql =  "\n".join(textwrap.wrap(reference_sql, width=60))
        except:
            pass

        story.extend([Paragraph(f'<font color="{colour}"><b>{r["verdict"]}</b></font> - {r["test_id"]}', styles["heading"]), 
                    Paragraph(f"<b>Category:</b> {r['category']}<br/><b>Question:</b> {r['question']}<br/><b>Time:</b> {r['elapsed_seconds']}s", styles["body"]), Spacer(1, 4), 
                        Table(checks, colWidths=[45*mm, 30*mm, 95*mm], style=TableStyle([("GRID", (0,0), (-1,-1), .4, colors.HexColor("#aab4c3")), 
                        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#d8e0ec")), ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"), ("VALIGN", (0,0), (-1,-1), "TOP")])), Spacer(1, 4), 
                    Paragraph("Reference SQL", styles["body"]), Table([[Preformatted(reference_sql or r["error"] or "No SQL generated.", styles["code"])]], colWidths=[170*mm], style=TableStyle([("BACKGROUND", (0,0), (-1,-1), colors.HexColor("#111827")), 
                        ("BOX", (0,0), (-1,-1), .5, colors.HexColor("#111827")), ("LEFTPADDING", (0,0), (-1,-1), 7), ("RIGHTPADDING", (0,0), (-1,-1), 7), ("TOPPADDING", (0,0), (-1,-1), 7), ("BOTTOMPADDING", (0,0), (-1,-1), 7)])), Spacer(1, 4),
                    Paragraph("Generated SQL", styles["body"]), Table([[Preformatted(r["sql"] or r["error"] or "No SQL generated.", styles["code"])]], colWidths=[170*mm], style=TableStyle([("BACKGROUND", (0,0), (-1,-1), colors.HexColor("#111827")), 
                        ("BOX", (0,0), (-1,-1), .5, colors.HexColor("#111827")), ("LEFTPADDING", (0,0), (-1,-1), 7), ("RIGHTPADDING", (0,0), (-1,-1), 7), ("TOPPADDING", (0,0), (-1,-1), 7), ("BOTTOMPADDING", (0,0), (-1,-1), 7)])), Spacer(1, 4),
                    Paragraph(f"Returned Data ({r.get('row_count', len(returned))} row(s))", styles["body"]), returned_flowable, Spacer(1, 8)])

        row_index +=1
    doc.build(story)


async def main() -> None:
    p = argparse.ArgumentParser(); p.add_argument("--questions-file", action="append", type=Path); p.add_argument("--test-id", help="run only one test_id from each selected question file"); p.add_argument("--output-dir", type=Path, default=EVAL / "output" / "semantic_evaluation"); p.add_argument("--all", action="store_true", help="evaluate all default sets (default)")
    args = p.parse_args(); files = args.questions_file or DEFAULT_FILES
    settings = get_settings(); all_rows = []; overall_started = time.perf_counter()
    for file in files:
        if not file.exists(): print(f"Skipping missing question set: {file}"); continue
       
        rows = []; file_started = time.perf_counter()
        cases = load_cases(file)
        if args.test_id:
            cases = [case for case in cases if case.get("test_id") == args.test_id]
            if not cases:
                print(f"{args.test_id}: not found in {file.name}"); continue
        for case in cases:            
            result = await ask(settings, case["question"])
            rows.append(evaluate(case, result, settings))

        stem = file.stem.replace("_Test_Questions", "")
        args.output_dir.mkdir(parents=True, exist_ok=True)   
        if len(rows) > MAX_ROWS:
            rows = rows[MAX_ROWS]
        (args.output_dir / f"{stem}_semantic.json").write_text(json.dumps(rows, indent=2, default=str), encoding="utf-8")
        write_pdf(args.output_dir / f"{stem}_semantic.pdf", rows, [file], time.perf_counter() - file_started); all_rows.extend(rows)
        print(f"{stem}: {sum(r['verdict']=='PASS' for r in rows)}/{len(rows)} PASS; report written")
    if len(files) > 1: write_pdf(args.output_dir / "combined_semantic_report.pdf", all_rows, files, time.perf_counter() - overall_started)


if __name__ == "__main__": asyncio.run(main())
