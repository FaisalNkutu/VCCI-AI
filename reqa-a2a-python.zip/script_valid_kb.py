import json

KB_FILE = r"RAG\KB_full_update2.json"

with open(KB_FILE, encoding="utf-8") as f:
    kb = json.load(f)

errors = []

for table_name, table_data in kb.items():

    columns = table_data.get("columns", {})

    if not isinstance(columns, dict):
        errors.append(
            f"{table_name}: columns is not a dict"
        )
        continue

    for col_name, col_data in columns.items():

        if not isinstance(col_data, dict):
            errors.append(
                f"{table_name}.{col_name} "
                f"-> invalid type "
                f"{type(col_data).__name__} "
                f"value={repr(col_data)}"
            )
            continue

        if "description" not in col_data:
            errors.append(
                f"{table_name}.{col_name} "
                f"-> missing description"
            )

        if "data_type" not in col_data:
            errors.append(
                f"{table_name}.{col_name} "
                f"-> missing data_type"
            )

print("\n" + "=" * 80)

if errors:
    print("❌ INVALID COLUMN DEFINITIONS FOUND\n")

    for err in errors:
        print(err)

else:
    print("✅ ALL COLUMNS ARE VALID")

print("=" * 80)