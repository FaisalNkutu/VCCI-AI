import streamlit as st

st.title("Test")
st.write("WSL OK")