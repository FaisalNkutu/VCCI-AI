"""
Schema ingestion script — run ONCE before starting the agent.

Usage:
    python ingest.py path/to/schema.sql

What it does:
    1. Parses all CREATE TABLE statements from the SQL file
    2. Builds a rich text description for each table (columns, types, constraints, FKs)
    3. Embeds each description locally (fastembed, no external API)
    4. Upserts into Qdrant

Re-running recreates the collection (safe to run multiple times).
"""

import sys
sys.path.insert(0,"../")  # for importing at root of project
import argparse
from pathlib import Path

import sqlglot
from sqlglot import exp
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct

from config import settings
from agent.embedder import Embedder
from extract_foreignkeys_from_html import extract_foreignkeys_from_html as extract_foreignkeys_from_html
import re
import json
import traceback

# ── Schema parser ─────────────────────────────────────────────────────────────

def _col_constraints(node: exp.ColumnDef) -> list[str]:
    parts = []
    for c in node.constraints:
        k = c.kind
        if isinstance(k, exp.NotNullColumnConstraint):
            parts.append("NOT NULL")
        elif isinstance(k, exp.PrimaryKeyColumnConstraint):
            parts.append("PRIMARY KEY")
        elif isinstance(k, exp.UniqueColumnConstraint):
            parts.append("UNIQUE")
        elif isinstance(k, exp.AutoIncrementColumnConstraint):
            parts.append("AUTO_INCREMENT")
        elif isinstance(k, exp.DefaultColumnConstraint):
            try:
                parts.append(f"DEFAULT {k.this.sql('mysql')}")
            except Exception:
                pass
        elif isinstance(k, exp.CommentColumnConstraint):
            try:
                parts.append(f"-- {k.this.name}")
            except Exception:
                pass
        elif isinstance(k, exp.CheckColumnConstraint):
            try:
                parts.append(f"CHECK({k.this.sql('mysql')})")
            except Exception:
                pass
    return parts


def parse_sql_to_documents(sql_content: str) -> list[dict]:
    documents = []

    try:
        statements = sqlglot.parse(sql_content, dialect="mysql")
    except Exception as e:
        print(f"[ingest] sqlglot warning: {e}")
        return []

    for stmt in statements:
        if not isinstance(stmt, exp.Create):
            continue
        kind = stmt.args.get("kind")
        kind_str = kind.name if hasattr(kind, "name") else kind
        if not kind or kind_str != "TABLE":
            continue

        schema_node = stmt.this
        if not isinstance(schema_node, exp.Schema):
            continue

        table_name = schema_node.this.name
        col_lines, fk_lines, idx_lines = [], [], []

        for node in schema_node.expressions:
            if isinstance(node, exp.ColumnDef):
                col_type = node.kind.sql("mysql") if node.kind else "UNKNOWN"
                constraints = _col_constraints(node)
                line = f"  - {node.name} {col_type}"
                if constraints:
                    line += "  [" + ", ".join(constraints) + "]"
                col_lines.append(line)

            elif isinstance(node, exp.ForeignKey):
                fk_cols = [c.name for c in node.expressions]
                ref = node.args.get("reference")
                if ref:
                    try:
                        ref_table = ref.this.name
                        ref_cols  = [c.name for c in ref.expressions]
                        fk_lines.append(
                            f"  - ({', '.join(fk_cols)}) → {ref_table}({', '.join(ref_cols)})"
                        )
                    except Exception:
                        pass

            elif isinstance(node, exp.Index):
                try:
                    idx_cols = [c.name for c in node.expressions]
                    idx_lines.append(f"  - INDEX({', '.join(idx_cols)})")
                except Exception:
                    pass

        parts = [f"Table: {table_name}"]
        if col_lines:
            parts.append("Columns:")
            parts.extend(col_lines)
        if fk_lines:
            parts.append("Foreign keys:")
            parts.extend(fk_lines)
        if idx_lines:
            parts.append("Indexes:")
            parts.extend(idx_lines)

        documents.append({"table": table_name, "description": "\n".join(parts)})

    return documents



def write_output_file(fname, content):
    with open( ".output/" + fname, "w") as file:        
        file.write(content)


# ── Ingestion ─────────────────────────────────────────────────────────────────
TABLE_COLUMNS_RE = re.compile(r"-\W([\w]*)")
def ingest(sql_file: str, qdrant_insert) -> None:
    sql_content = Path(sql_file).read_text(encoding="utf-8")
    documents = parse_sql_to_documents(sql_content)

    if not documents:
        print("[ingest] No CREATE TABLE statements found — check your SQL file.")
        sys.exit(1)

    table_names = [d["table"] for d in documents]
    print(f"[ingest] Parsed {len(documents)} tables: {table_names}")

    print("[ingest] Loading embedding model (first run downloads ~130 MB)...")
    embedder = Embedder()





if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Ingest SQL schema into Qdrant")
    parser.add_argument("sql_file", default=".input/calian_nodata.sql", help="Path to your .sql schema file")  
    args = parser.parse_args()
    ingest(args.sql_file, args.qdrant_insert)



