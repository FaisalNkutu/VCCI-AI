#  Example


Tables_descriptions = dict()


metadata = {
    "db_name": "BD_MIL",
    "description": "Relational database for the armed forces information system. All tables, columns, and values use abbreviated or codified naming for operational security. This file is the data dictionary for RAG systems and SQL query generation.",
    "version": "2.0",
    "sgbd": "MariaDB 10.5+",
    "table_count": 252,
    "language": "en",
    "domains": [
      "Personnel & Organisation",
      "Operations",
      "Intelligence",
      "Equipment / Materiel",
      "Logistics",
      "Armament",
      "Training",
      "Communications",
      "Medical & Health",
      "Cyber & IS Security",
      "Finance & Budget",
      "Legal"
    ]
  }



## Example of table:


"""

Table format example

   {
  "name": "grd",
  "label": "Military Ranks",
  "description": "Reference table of all military ranks and grades. Each rank belongs to a category (officer, non-commissioned officer, enlisted) and an armed service. The numeric level enables hierarchical comparisons.",
  "primary_key": "id_grd",
  "columns": {
    "id_grd": "Auto-incremented rank identifier",
    "cod_grd": "Short rank code (e.g. MDL=Private, CPL=Corporal, SCH=Staff Sergeant, ADJ=Warrant Officer, SLT=2nd Lieutenant, LT=Lieutenant, CNE=Captain, CDT=Major, LCL=Lieutenant Colonel, COL=Colonel, GBR=Brigadier General, GDI=Major General, GAL=General)",
    "lib_grd": "Official full rank title",
    "cat_grd": "Category: OFF=Officer, SOFF=Non-commissioned officer, MAT=Enlisted (also called 'troop')",
    "niv_grd": "Hierarchical numeric level 1 (lowest) to 20 (highest). Used for rank comparisons.",
    "arme": "Armed service: TER=Army, AIR=Air Force, MER=Navy, GEN=Gendarmerie, ALL=Common to all services"
  },
  "allowed_values": [],
  "referenced_by": [
    "pers.id_grd",
    "poste.id_grd_req"
  ]
}




 {
  "name": "grd",
  "label": "",
  "description": "",
  "primary_key": "",
  "columns": {
  },
  "referenced_by": []
}


Important files: RAG/database_entities.csv, RAG/all_table_columns.json,  RAG/table_names.csv, RAG/all_table_columns.json, RAG/all_tables_referenced_by.json


"""

import csv
import json
from pathlib import Path


import csv

def load_csv_as_dict(file_path):
    """
    Charge un CSV et retourne un dictionnaire :
    - 1ère colonne = clé
    - 2ème colonne = valeur
    - ignore la ligne d'en-tête si elle contient 'Acronym' et 'Description'
    """
    result = {}

    with open(file_path, mode="r", encoding="utf-8") as f:
        reader = csv.reader(f)

        for row in reader:
            if not row or len(row) < 2:
                continue

            # Ignorer l'en-tête
            if row[0].strip().lower() == "acronym" and row[1].strip().lower() == "description":
                continue

            key = row[0].strip()
            value = row[1].strip()

            result[key] = value

    return result


def load_json(file_path):
    """
    Charge un fichier JSON (dict ou list).
    """
    with open(file_path, mode="r", encoding="utf-8") as f:
        return json.load(f)


def build_database_dictionary(base_path="RAG"):
    base_path = Path(base_path)

    db_dict = {
        "database_entities": None,
        "table_names": None,
        "table_columns": None,
        "tables_referenced_by": None
    }

    # CSV: entités base de données
    db_dict["database_entities"] = load_csv_as_dict(
        base_path / "database_entities.csv"
    )

    # CSV: noms des tables
    db_dict["table_names"] = load_csv_as_dict(
        base_path / "table_names.csv"
    )

    # JSON: colonnes des tables
    db_dict["table_columns"] = load_json(
        base_path / "all_table_columns.json"
    )

    # JSON: relations entre tables
    db_dict["tables_referenced_by"] = load_json(
        base_path / "all_tables_referenced_by.json"
    )

    return db_dict


"""

if __name__ == "__main__":
    db = build_database_dictionary()

    # Exemple d'affichage
    print("Tables chargées :", len(db["table_names"]))
    print("Entités :", len(db["database_entities"]))

    # Sauvegarde optionnelle
    with open("database_dictionary.json", "w", encoding="utf-8") as f:
        json.dump(db, f, indent=2, ensure_ascii=False)

"""





Tables_descriptions["metadata"] = metadata

Tables_descriptions["tables"] = []

elmt = {
  "name": "",
  "label": "",
  "description": "",
  "primary_key": [],
  "columns": {
  },
  "referenced_by": []
}


tables_list = [elmt for i in range(171)]

#print(len(tables_list))

#print(tables_list)


Tables_descriptions["tables"] = tables_list


# Files loading and json files reparation

def repair_json_file(input_file: str, output_file: str):
    """
    Fixes a JSON file that contains JSON encoded as a string.
    """

    try:
      
        with open(input_file, "r", encoding="utf-8") as f:
            data = json.load(f)

     
        if isinstance(data, str):
            print("⚠ JSON detected as a string")
            data = json.loads(data)

        
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)

        print(f"✅ Json file repaired and saved in : {output_file}")

    except json.JSONDecodeError as e:
        print("❌ JSON not good")
        print(f"Line   : {e.lineno}")
        print(f"Column : {e.colno}")
        print(f"Error  : {e.msg}")

    except Exception as e:
        print(f"❌ Erreur : {e}")


#  RAG/all_table_columns.json,  RAG/table_names.csv, RAG/all_table_columns.json, RAG/all_tables_referenced_by.json

#database_entities = load_csv_as_dict("RAG/database_entities.csv")
#table_names = load_csv_as_dict("RAG/table_names.csv")

"""
repair_json_file("RAG/all_table_columns1.json", "RAG/table_col_fixed.json" )
repair_json_file("RAG/all_tables_referenced_by.json", "RAG/all_tables_referenced_by_fxd.json" )
repair_json_file("RAG/columns_def.json", "RAG/columns_def_fxd.json" )
repair_json_file("RAG/all_tables_primary_key.json", "RAG/all_tables_primary_key_fxd.json")




print("===========================================================")

print("===========================================================")

tabl_pks = load_json("RAG/all_tables_primary_key_fxd.json")

col_defs = load_json("RAG/columns_def_fxd.json")

tabl_cols = load_json("RAG/table_col_fixed.json")

tabl_refs = load_json("RAG/all_tables_referenced_by_fxd.json")

all_attr_defs = load_json("RAG/all_attr_def.json")

"""


#print(tabl_refs)



# Definition of columns and adding to Tables_descriptions["tables"]


"""
present = False

for k, v in tabl_cols.items():

    

    for v_key in v.keys():

        

        for l, w in col_defs.items():

            if  v_key == l:

                tabl_cols[k][v_key] = w
                present = True

        if not present:
            present = False

            tabl_cols[k][v_key] = v_key.replace("_", " ")
"""

"""
for k, v in tabl_cols.items():

    for v_key in v.keys():

        if v_key in col_defs:
            tabl_cols[k][v_key] = col_defs[v_key]
        else:
            tabl_cols[k][v_key] = v_key.replace("_", " ")

 """           


#print(tabl_cols)



i = 0

#print(table_names.items())

# List of mixing tables

mix_tables = ['Acronym', 'bio_mat_type', 'acft_type', 'oig_pln_ordr_cntnt', 'pln_ordr_distr_ack', 'mapped_object', 'railcar_type', 'visibility', 'runway', 'point', 'mil_obs_type', 'airfield_type', 'fac_stat', 'route', 'geo_feat_type', 'ammo_type', 'eng_eqpt_type', 'mapper', 'mat_stat', 'fire_capab', 'precipitation', 'comm_eqpt_type', 'minefield_land', 'act_loc_assoc', 'unit_type', 'data_flow_spec', 'orbit_area', 'loc', 'obj_item_stat', 'met_org_type', 'subsurf_vessel_type', 'action_group', 'vehicle_type', 'obj_item_assoc', 'contxt_oi_assoc', 'act_task', 'org', 'ctrl_feat_type', 'obj_type_capab_norm', 'tx_event', 'netwrk', 'surf_vessel_type', 'landing_area', 'callsign_alias', 'pers_stat', 'hrbr_type', 'metrics', 'combat_power_metrics_spec', 'pln_ordr', 'chm_mat_type', 'system_capability', 'org_type', 'wind', 'org_poa_stat', 'blob_transcript', 'met_obj_item_point_loc', 'aerodrome_surface_point_assoc', 'rx_event', 'obj_type', 'radar_stat', 'capab', 'sim_param', 'metrics_results', 'gfeat_stat', 'simulator_task', 'disroute', 'porter_route_endpoint', 'met_feat_type', 'simulator_task_parameter', 'elctrnc_eqpt_type', 'physcl_addr', 'move_act_task', 'bridge_type', 'act_ot_assoc', 'fratricide_metrics_results', 'fan_area', 'geom_feat', 'approach_direction', 'netwrk_service', 'feat_type', 'cbrn_eqpt_type', 'oig_org_assoc', 'met_contxt_oi_assoc', 'route_segment', 'cons_mat_type', 'cloud_cover', 'obj_item_addr', 'met_unit_type', 'folder', 'met_org']

#print(len(mix_tables))



"""


tables_no_pk = []

Tables_descriptions["tables"] = []

for k1, v1 in table_names.items():

    table = {
        "name": k1,
        "label": v1,
        "description": v1
    }

    #ok = False

    for k2, v2 in tabl_pks.items():

        if k1 == k2:
            table["primary_key"] = v2

    
           # ok = True
    #if not ok:
    #    tables_no_pk.append(k1)


    for k3, v3 in tabl_cols.items():

        data = dict()

        if k1 == k3:
             
             
             for kv3, vv3 in v3.items():
                 
                 allowed_vals = []

                 data[kv3] = {"description":vv3}
                 

                 for k5, v5 in all_attr_defs.items():
                     
                     
                     if k1 == k5.lower() and kv3 == list(v5.keys())[0]:
                         #print(list(v5.keys())[0])

                         #print(type(v5.values()))

                         data[kv3]["allowed_values"] = list(v5.values())[0]
                         
                         #allowed_vals.append(list(v5.keys())[0])
                    #print(allowed_vals)
             #print(allowed_vals)
                         
             #data[kv3]["allowed_values"] = allowed_vals
                     #else:
                         
                         
                         
                         
                        

             table["columns"] = data

    
    for k4, v4 in tabl_refs.items():


        if k1 == k4:

             table["referenced_by"] = v4



    Tables_descriptions["tables"].append(table)


i = 0

"""

#Tables_descriptions["tables"] = Tables_descriptions["tables"][1:]

#print(Tables_descriptions["tables"][:10])



def save_json(data, file_path):
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

#print(len(tables_no_pk))

#save_json(Tables_descriptions, "RAG/all_tables_descriptions.json")



from AttributeMetaData import GAttributeMetaData

#print(GAttributeMetaData[0])

data2 = GAttributeMetaData[:3]

data1 = GAttributeMetaData[0]

"""
This function create a json format from data whose structure like:  

[ ['ABS_POINT', ['cat_code', [['CARTPT', 'CARTESIAN-POINT'], ['GEOGPT', 'GEOGRAPHIC-POINT']]]], ... ]


-----------------------------------

"branches": {
    "table_description": "Military service branches such as Army, Navy, Air Force",
    "domain": "Reference",
    "columns": {
      "branch_id": {
        "description": "Surrogate PK",
        "allowed_values": [],
        "example_values": [],
        "notes": ""
      },
      "branch_name": {
        "description": "Service branch name",
        "allowed_values": [],
        "example_values": [
          "Army",
          "Navy",
          "Air Force",
          "Marine Corps",
          "Special Forces"
        ],
        "notes": ""
      },
      "branch_code": {
        "description": "Short 4-char code",
        "allowed_values": [],
        "example_values": [
          "ARMY",
          "NAVY",
          "AIRF",
          "MRNE",
          "SOFC"
        ],
        "notes": ""
      },
      "description": {
        "description": "Free-text description of the branch mission",
        "allowed_values": [],
        "example_values": [],
        "notes": ""
      }
    },
    "referenced_by": [
      "personnel.branch_id",
      "ranks.branch_id",
      "specialties.branch_id",
      "training_programs.branch_id",
      "unit_types.branch_id"
    ],
    "sample_queries": [
      "What is the current list of all military service branches and their codes?",
      "How many airborne infantry units does each branch have in total?",
      "Which service branches have similar missions or descriptions?",
      "How has the number of personnel in the Navy and Marines changed over the past decade?",
      "What is the description for the branch with code 'USAJ'?"
    ]
  }


  =======================================================


   "columns": {
      "branch_id": {
        "description": "Surrogate PK",
        "allowed_values": [],
        "example_values": [],
        "notes": ""
      },
      "branch_name": {
        "description": "Service branch name",
        "allowed_values": [],
        "example_values": [
          "Army",
          "Navy",
          "Air Force",
          "Marine Corps",
          "Special Forces"
        ],
        "notes": ""
      }
      ...

      }


"""


import json


def convert_to_json_structure(data):
    table_name = data[0]
    column_name = data[1][0]
    values = data[1][1]

    data_json = {
        table_name: {
            column_name: {
                code: label
                for code, label in values
            }
        }
    }

    return data_json

#json_data1 = convert_to_json_structure(data1)

#print(json.dumps(json_data1, indent=4))


def convert_all_structure(data):

    all_data_dict = dict()

    for elmt in data:

        elmt_json = convert_to_json_structure(elmt)

        for k, v in elmt_json.items():

            all_data_dict[k]=v
        
    return all_data_dict




if __name__ == "__main__":

    #print(convert_all_structure(data2))

    #print(convert_all_structure(GAttributeMetaData))

    # repair_json_file("RAG/all_table_columns1.json", "RAG/table_col_fixed.json" )
    

    #convert_all_structure_json = convert_all_structure(GAttributeMetaData)



    #save_json(convert_all_structure_json, "RAG/all_attr_def.json")


    ## KB_full loading

    KB_full =  load_json("RAG/KB_full.json")



    #repair_json_file("RAG/Domain_map.json", "RAG/Domain_map_fix.json")

    table_domain = load_json("RAG/Domain_map.json")

    KB_full_interm = KB_full["tables"]

    print("=== Before table domain adding ===")

    #print(list(KB_full_interm.items())[:1])

    #print(table_domain)

    for table, val in list(KB_full_interm.items()):
        
        nv_val = val
        
        for k, v in table_domain.items():
            
            if(table == k):
                
                nv_val["domain"] = v
                
                KB_full["table"] = nv_val
                
    print("==== After table domain adding ===")

    #print(list(KB_full_interm.items())[:1])

    KB_full["tables"] = KB_full_interm

    print("==== Updating in the full KB dictionnary ===")

    #print(list(KB_full["tables"].items())[2])

    #l = len(list(KB_full["tables"].items()))

    #print("\n KB length: " + str(l))

    import random

    #n = random.randint(0, l)

    #print("==== Updating in the full KB dictionnary (checking ...) ===")

    #print(list(KB_full["tables"].items())[n])

    save_json(KB_full, "RAG/KB_full.json")


                
                

