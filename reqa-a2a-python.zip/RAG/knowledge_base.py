"""
Knowledge base loader — reads KB_PATH = Path(__file__).parent / "KB_full_update.json".

v2.1 — composite-key aware revision of the v2 loader. Changes vs v2:
  - primary_key may be a composite string "col_a, col_b": all PK logic now
    goes through _pk_cols() and works per-column.
  - relationships' join_on is DeZign notation and is NOT valid SQL for
    composite keys ("a, b = c, d"). Everything shown to the LLM is now
    rendered from own_column/related_column pairs as an executable
    AND-composed condition via _join_sql(). The raw join_on is never
    emitted anywhere anymore.
  - fk_by_column splits composite own_column/related_column pairs so each
    physical column receives its own FK tag (the composite _stat family
    previously got no inline FK tags at all).
  - get_sample_queries() gained a level-balanced cap (default 4) because
    the v2 KB carries 8-16 validated queries per table — injecting all of
    them bloats the prompt for local 7B models.
  - .get() hardening on relationship type/cardinality (optional in v2).

--- v3.0 (KB_full_enrichie.json) ---
The enriched KB adds 4 669 generated queries to the 2 064 curated ones, in
three NEW families that are NOT safe to use the way the old ones were:

  * "Complex Business Query"     -> valid SQL, returns rows      (usable)
  * "No Results Found"           -> valid SQL, returns NOTHING   (must not
                                    be shown as an answerable example)
  * "Invalid/Unsupported Query"  -> raises at execution, or has NO SQL at
                                    all (sql is None, 508 entries), and
                                    includes DELETE statements written on
                                    purpose to test read-only guardrails

Consequences, all handled here so that no caller has to know about it:

  1. `sql` may now be None. Any code doing `item["sql"]` breaks.
  2. Feeding an invalid example to the LLM as a few-shot actively teaches
     it to produce broken SQL, and a "No Results" example teaches it to
     produce queries that answer nothing.
  3. The questions of the negative families ("Delete all X records added
     last month", "Show the customer email address of each X") must never
     become retrieval anchors, nor be offered as "guaranteed answerable"
     suggestions, nor reach the pipeline's catalog short-circuit -- which
     executes the matched SQL verbatim.

Every query therefore now carries a CLASS, derived from the KB fields
(`expected_outcome`, `expected_error`, `sql is None`) and double-checked
against the SQL text itself:

    POSITIVE | EMPTY | INVALID | UNANSWERABLE

and every accessor filters on it. Default everywhere: POSITIVE only, i.e.
exactly the old behaviour on the old KB, which classifies fully POSITIVE.

--- v3.1 (exploit the enriched KB, don't just survive it) ---
v3.0 made the new families SAFE. v3.1 makes them USEFUL. Three additions,
each targeting a measured failure mode of the pipeline:

  A. KIND-AWARE FEW-SHOTS. get_sample_queries() now accepts the user's
     question and ranks the table's examples by SHAPE affinity instead of
     picking a fixed level-balanced sample. "How many X per Y" pulls the
     group_by_enum / having / share_of_total examples; "which X has no Y"
     pulls anti_join / coverage_gap. Four RELEVANT examples are worth far
     more to a 7B model than four arbitrary ones, at identical prompt cost.
     The 1 157 business queries (ratios, peer-group comparison, CASE-based
     rates, period-over-period) become reachable this way -- patterns the
     old KB simply did not contain.

  B. NEGATIVE PRE-FLIGHT. best_negative_match() matches the question
     against the questions the KB records as NOT answerable for the
     retrieved tables. A hit returns the recorded reason. The pipeline can
     then decline immediately, with an explanation, instead of burning
     max_retries LLM calls to arrive at "Could not generate a valid query".

  C. ERROR -> REPAIR HINT. repair_hint() turns a raw DB error into the
     corrective instruction the KB already documents for that error class
     (1054/1146/1111/1055/1052/1064), and for unknown columns/tables it
     proposes the closest REAL identifiers from the KB. Fed back into the
     retry loop, it converts a blind retry into a guided one.

Public function names/signatures are unchanged — drop-in replacement.
New in v3.0: query_class(), is_readonly_select(),
             retrieval_safe_sample_queries(), get_negative_examples(),
             query_profile().
New in v3.1: KIND_TAXONOMY, rank_kinds(), get_business_examples(),
             best_negative_match(), repair_hint().
"""

import difflib
import json
import os
from functools import lru_cache
from pathlib import Path
import re
import sys
from config.settings import get_settings
settings = get_settings()

# Single runtime source of truth.  The API, A2A service and Streamlit app
# receive KB_FILE from .env, so the safeguards use the same KB selected for
# ingestion.  Preserve the current production file as the safe fallback.
KB_PATH = Path(os.getenv("KB_FILE", str(Path(__file__).parent / "KB_production_rezwan.json")))

def set_global_kb_path(  fname ):
    global KB_PATH
    KB_PATH = fname

#
#   These tables should be excluded, because they are actually output
#   for midas processors. they will be empty. These must be instead computed
#  
METRICS_TABLES_PATTERNS = [ "met_", "metrics_" ]
def is_excluded_table( name ):
    if settings.EXCLUDE_METRICS_TABLES != 0:
        for pattern in METRICS_TABLES_PATTERNS:
            if pattern in name:
                return True
    return False


@lru_cache(maxsize=1)
def load_kb(kb_fname=None) -> dict[str, dict]:
  
    """Load and cache the full knowledge base from JSON."""
    if kb_fname is None:
        kb_fname = KB_PATH

    print(f"\n========================================== BASE LOAD_KB({kb_fname}) =======================================================\n")
        
    with open(kb_fname, encoding="utf-8") as fh:
        data = json.load(fh)
        rval = dict(data["tables"]) if "tables" in data else data
        
        # remove the metrics tables after loading
        # TODO: Permanent solution. this is just a quick fix to avoid modifying the json        
        tables_to_remove = []
        for key,val in rval.items():       
           # print(f"LOAD_KB={key}")    
            if is_excluded_table( key ):
                print(f"REMOVE metrics table '{key}'")
                tables_to_remove.append(key)                        

        for to_rem in tables_to_remove:
            del rval[to_rem]            
           

       # sys.exit(90)
        return rval


def get_all_table_names() -> list:
    return get_all_table_names_from_d( load_kb() )


def get_all_table_names_from_d(d: dict):
    rval = []
    for key, val in d.items():
        rval.append(key)
    return rval


def get_table_kb(table: str) -> dict:
    """Return the full KB entry for a table (safe default if missing)."""
    return get_table_kb_from_d(load_kb(), table)


def get_table_kb_from_d(d: dict, table: str) -> dict:
    """Return the full KB entry for a table (safe default if missing)."""
    return d.get(table, {
        "label": "",
        "description": "",
        "keywords": [],
        "domain": [],
        "columns": {},
        "primary_key": "",
        "relationships": [],
        "sample_queries": [],
    })


def get_column_kb(table: str, column: str) -> dict:
    """Return the KB entry for a single column (safe default if missing)."""
    return get_column_kb_from_d(load_kb(), table, column)


def get_column_kb_from_d(d: dict, table: str, column: str) -> dict:
    """Return the KB entry for a single column (safe default if missing)."""
    return get_table_kb_from_d(d, table).get("columns", {}).get(column, {
        "data_type": "",
        "description": "",
        "allowed_values": {},
        "notes": "",
    })


# ---------------------------------------------------------------------------
# Query classes (v3.0) — what a sample query is safe to be used FOR
# ---------------------------------------------------------------------------

POSITIVE = "positive"          # valid SQL, expected to return rows
EMPTY = "empty"                # valid SQL, expected to return zero rows
INVALID = "invalid"            # parses but fails at execution / unsupported
UNANSWERABLE = "unanswerable"  # no SQL can be produced from this schema

#: Classes safe to expose as answerable examples (few-shots, suggestions,
#: embedding anchors, catalog short-circuit).
SAFE_CLASSES = (POSITIVE,)

_WRITE_STMT_RE = re.compile(
    r"^\s*(INSERT|UPDATE|DELETE|DROP|ALTER|TRUNCATE|CREATE|REPLACE|RENAME|"
    r"GRANT|REVOKE|MERGE|CALL|LOAD|LOCK|SET|USE)\b", re.I)
_READ_STMT_RE = re.compile(r"^\s*(SELECT|WITH)\b", re.I)


def is_readonly_select(sql) -> bool:
    """True only for a single, read-only statement.

    Belt-and-braces guard: the enriched KB deliberately contains
    `DELETE FROM <table>;` entries (kind=write_operation_out_of_scope) to
    exercise read-only guardrails. Nothing that reaches execution should
    ever be able to come from the KB, whatever a classifier upstream
    decided.
    """
    if not isinstance(sql, str) or not sql.strip():
        return False
    body = sql.strip().rstrip(";").strip()
    if ";" in body:            # stacked statements
        return False
    if _WRITE_STMT_RE.match(body):
        return False
    return bool(_READ_STMT_RE.match(body))


def query_class(item) -> str:
    """Classify one sample_queries entry. Legacy entries -> POSITIVE.

    Accepts the raw KB dict, or any dict carrying the same keys (e.g. the
    match returned by schema_rag.best_sample_query, or a Qdrant payload
    item), so the same guard can be applied at every layer.
    """
    if isinstance(item, str):
        return POSITIVE
    if not isinstance(item, dict):
        return UNANSWERABLE

    sql = item.get("sql")
    if not sql:                                   # None or "" -> 508 entries
        return UNANSWERABLE
    if item.get("expected_error"):
        return INVALID

    outcome = str(item.get("expected_outcome") or "").strip().lower()
    if outcome == "error":
        return INVALID
    if outcome == "empty":
        return EMPTY

    # No outcome field = curated legacy query. Still verify the statement
    # itself: a KB regenerated with different conventions must not be able
    # to slip a write statement through on the strength of a missing field.
    if not is_readonly_select(sql):
        return INVALID
    return POSITIVE


def _iter_queries(entry: dict, classes=SAFE_CLASSES):
    """Yield (item, class) for the entry's sample_queries in the given classes."""
    for item in entry.get("sample_queries") or []:
        if isinstance(item, str):
            if POSITIVE in classes and item.strip():
                yield {"question": item.strip(), "sql": None}, POSITIVE
            continue
        if not isinstance(item, dict):
            continue
        cls = query_class(item)
        if cls in classes:
            yield item, cls


def query_profile(table: str) -> dict:
    """{class: count} for a table — diagnostics / ingestion reports."""
    return query_profile_from_entry(get_table_kb(table))


def query_profile_from_entry(entry: dict) -> dict:
    prof = {POSITIVE: 0, EMPTY: 0, INVALID: 0, UNANSWERABLE: 0}
    for item in entry.get("sample_queries") or []:
        prof[query_class(item)] += 1
    return prof


def retrieval_safe_sample_queries(entry: dict) -> list[dict]:
    """The subset of sample_queries safe to store in a Qdrant payload.

    schema_rag.best_sample_query() reads this list and the pipeline
    EXECUTES the matched SQL verbatim. Anything not POSITIVE and not a
    read-only SELECT is dropped here, at the single point where the
    payload is built, rather than trusted downstream.
    """
    out = []
    for item, _cls in _iter_queries(entry, (POSITIVE,)):
        if not is_readonly_select(item.get("sql")):
            continue
        out.append({k: v for k, v in item.items()
                    if k in ("question", "sql", "level", "kind")})
    return out


def get_negative_examples(table: str, limit: int = 3) -> list[dict]:
    """Questions this schema CANNOT answer, with the reason.

    Not injected anywhere by default (prompt budget). Intended for a
    refusal/guardrail prompt: showing a 7B model two examples of a question
    it must decline is cheaper and more reliable than describing the rule.
    """
    entry = get_table_kb(table)
    out = []
    for item, cls in _iter_queries(entry, (UNANSWERABLE, INVALID)):
        out.append({
            "question": item.get("question", ""),
            "why": item.get("expected_error") or item.get("guidance") or "",
            "class": cls,
        })
        if len(out) >= limit:
            break
    return out


# ---------------------------------------------------------------------------
# Kind taxonomy (v3.1) — the 54 query kinds of the enriched KB
# ---------------------------------------------------------------------------
# Each kind maps to: the category it belongs to, its class, and the lexical
# cues of the QUESTION SHAPE it answers. Cues are matched against the user's
# question to select few-shots that rhyme with what is being asked, rather
# than a fixed sample. FR + EN cues: the UI accepts both.

KIND_TAXONOMY: dict[str, dict] = {
    # ---- Simple Single-Table Query -------------------------------------
    "examples":        {"cat": "simple", "cls": POSITIVE, "cues": r"example|sample|look like|show me some|exemple|apercu|à quoi ressemble"},
    "count":           {"cat": "simple", "cls": POSITIVE, "cues": r"how many\s+(?!different|distinct)|number of|total number|\bcount\b|combien|nombre de"},
    "distinct":        {"cat": "simple", "cls": POSITIVE, "cues": r"distinct|unique|which values|what values|list of|valeurs|lesquelles"},
    # ---- Filtering Query ------------------------------------------------
    "enum_filter":     {"cat": "filter", "cls": POSITIVE, "cues": r"where|with .* (equal|of type)|classified as|of category|dont le|qui sont|de type"},
    "enum_multi":      {"cat": "filter", "cls": POSITIVE, "cues": r"either|or\b|any of|among|one of|soit|parmi|ou bien"},
    "text_search":     {"cat": "filter", "cls": POSITIVE, "cues": r"contain|named|called|starting with|like|whose name|contenant|nomme|appele"},
    "multi_condition": {"cat": "filter", "cls": POSITIVE, "cues": r"and .*(greater|less|more than|above|below)|both .* and|et .*(superieur|inferieur|plus de)"},
    # ---- Aggregation & Date Functions -----------------------------------
    "group_by_enum":   {"cat": "aggregate", "cls": POSITIVE, "cues": r"\bper\b|by category|for each|breakdown|group(ed)? by|\bpar\b|pour chaque|repartition|ventil"},
    "aggregate_measure": {"cat": "aggregate", "cls": POSITIVE, "cues": r"average|mean|sum|total|maximum|minimum|moyenne|somme|maximal|minimal"},
    "distinct_count":  {"cat": "aggregate", "cls": POSITIVE, "cues": r"how many different|how many distinct|number of distinct|combien de differents"},
    "date_window":     {"cat": "aggregate", "cls": POSITIVE, "cues": r"last \d+ days|recent|since|past (week|month|year)|derniers? jours|recent|depuis"},
    # ---- Sorting & Top-N -------------------------------------------------
    "top_n_measure":   {"cat": "topn", "cls": POSITIVE, "cues": r"top \d+|highest|largest|biggest|best|ranked|les plus|meilleur|classement"},
    "top_n_recent":    {"cat": "topn", "cls": POSITIVE, "cues": r"latest|most recent|newest|last \d+|derniers?|plus recents?"},
    "top_frequent":    {"cat": "topn", "cls": POSITIVE, "cues": r"most common|most frequent|commonest|les plus frequents?|les plus courants?"},
    # ---- Multi-Table ------------------------------------------------------
    "parent_join":     {"cat": "join", "cls": POSITIVE, "cues": r"with (its|their)|together with|along with|and its|avec (son|leur|sa)"},
    "assoc_3table":    {"cat": "join", "cls": POSITIVE, "cues": r"linked to|associated with|related to|connected to|lies? a|associes? a"},
    "anti_join":       {"cat": "join", "cls": POSITIVE, "cues": r"without|no\s+\w*\s*(linked|associated|attached|matching)|never (linked|associated)|not (linked|associated)|orphan|sans|aucun"},
    "not_exists_parent": {"cat": "join", "cls": POSITIVE, "cues": r"orphan|dangling|points? to a missing|invalid reference|orphelin|reference manquante"},
    "self_join":       {"cat": "join", "cls": POSITIVE, "cues": r"pairs? of|same table|both roles|paires? de"},
    "parent_concentration": {"cat": "join", "cls": POSITIVE, "cues": r"which .* has the most|concentrat|busiest|qui (a|concentre) le plus"},
    "coverage_gap":    {"cat": "join", "cls": POSITIVE, "cues": r"coverage|what (share|proportion) .* (no|without)|taux de couverture|part sans"},
    # ---- Complex Business -------------------------------------------------
    "having":          {"cat": "business", "cls": POSITIVE, "cues": r"more than \d+|at least \d+|fewer than|only .* with (more|at least)|plus de \d+|au moins \d+"},
    "subquery":        {"cat": "business", "cls": POSITIVE, "cues": r"above (the )?average|below average|than average|compared to the average|au-dessus de la moyenne|superieur a la moyenne"},
    "duplicate_check": {"cat": "business", "cls": POSITIVE, "cues": r"duplicate|twice|same .* more than once|doublon|en double"},
    "duration":        {"cat": "business", "cls": POSITIVE, "cues": r"how long|duration|elapsed|lasted|duree|combien de temps"},
    "share_of_total":  {"cat": "business", "cls": POSITIVE, "cues": r"share|percentage|proportion|what (%|percent)|part|pourcentage"},
    "peer_group_outlier": {"cat": "business", "cls": POSITIVE, "cues": r"outlier|anomal|exceed .* (its|their) (own|category)|stands? out|aberrant|hors norme"},
    "category_kpi_table": {"cat": "business", "cls": POSITIVE, "cues": r"summary|dashboard|kpi|overview per|performance (per|by)|tableau de bord|synthese"},
    "extreme_per_category": {"cat": "business", "cls": POSITIVE, "cues": r"(highest|best|largest) .* (in each|per|for each)|le plus .* (de chaque|par)"},
    "measure_concentration": {"cat": "business", "cls": POSITIVE, "cues": r"concentrat|pareto|80/20|dominated by|concentration"},
    "cross_dimension_matrix": {"cat": "business", "cls": POSITIVE, "cues": r"cross|combination of|by .* and .*|matrix|croise|combinaison"},
    "completeness_audit": {"cat": "business", "cls": POSITIVE, "cues": r"missing|empty|not filled|null|incomplete|manquant|vide|non renseigne"},
    "period_over_period": {"cat": "business", "cls": POSITIVE, "cues": r"compar\w*|versus|vs\.? (last|previous)|trend|increas|decreas|growth|evolution|tendance|par rapport|progression"},
    "recent_activity_by_category": {"cat": "business", "cls": POSITIVE, "cues": r"active .* (recently|last)|recent activity|activite recente"},
    "sla_breach":      {"cat": "business", "cls": POSITIVE, "cues": r"longer than|slower than|took too long|sla|breach|trop long|depassement"},
    "duplicate_business_key": {"cat": "business", "cls": POSITIVE, "cues": r"duplicate|same (name|code|label|value)|listed twice|doublon|meme (nom|code)"},
    # ---- No Results Found (never few-shot; matched for expectation setting)
    "nonexistent_enum_value":     {"cat": "empty", "cls": EMPTY, "cues": r""},
    "contradictory_predicate":    {"cat": "empty", "cls": EMPTY, "cues": r""},
    "not_null_violation_search":  {"cat": "empty", "cls": EMPTY, "cues": r""},
    "impossible_range":           {"cat": "empty", "cls": EMPTY, "cues": r""},
    "future_date_window":         {"cat": "empty", "cls": EMPTY, "cues": r""},
    "improbable_text_match":      {"cat": "empty", "cls": EMPTY, "cues": r""},
    "out_of_domain_key":          {"cat": "empty", "cls": EMPTY, "cues": r""},
    "referential_integrity_clean": {"cat": "empty", "cls": EMPTY, "cues": r""},
    # ---- Invalid / Unsupported (never few-shot; drive refusal + repair) --
    "unknown_column":              {"cat": "invalid", "cls": INVALID, "cues": r""},
    "unknown_table":               {"cat": "invalid", "cls": INVALID, "cues": r""},
    "aggregate_in_where":          {"cat": "invalid", "cls": INVALID, "cues": r""},
    "group_by_violation":          {"cat": "invalid", "cls": INVALID, "cues": r""},
    "ambiguous_column":            {"cat": "invalid", "cls": INVALID, "cues": r""},
    "unsupported_window_function": {"cat": "invalid", "cls": INVALID, "cues": r""},
    "unsupported_cte":             {"cat": "invalid", "cls": INVALID, "cues": r""},
    "write_operation_out_of_scope": {"cat": "invalid", "cls": INVALID, "cues": r""},
    "unanswerable_from_schema":    {"cat": "invalid", "cls": UNANSWERABLE, "cues": r""},
    "out_of_domain_concept":       {"cat": "invalid", "cls": UNANSWERABLE, "cues": r""},
}

_CUE_RE = {k: re.compile(v["cues"], re.I) for k, v in KIND_TAXONOMY.items() if v["cues"]}


def rank_kinds(question: str, limit: int = 8) -> list[str]:
    """Kinds whose question shape matches `question`, strongest first.

    Purely lexical and deterministic: no model call, no latency. An empty
    result simply means "no shape detected" and callers fall back to the
    level-balanced default.
    """
    if not question:
        return []
    scored = []
    for kind, rx in _CUE_RE.items():
        hits = len(rx.findall(question))
        if hits:
            # A business/join kind matching is a stronger signal than a
            # generic "simple" one, which matches almost any phrasing.
            weight = 1.6 if KIND_TAXONOMY[kind]["cat"] in ("business", "join", "aggregate", "topn") else 1.0
            scored.append((hits * weight, kind))
    scored.sort(reverse=True)
    return [k for _s, k in scored[:limit]]


def get_business_examples(table: str, limit: int = 2) -> list[dict]:
    """Analytical examples (ratios, peer-group, period-over-period...).

    These carry a `business_need` field describing the decision they
    support; useful both as few-shots and as UI suggestions for a user who
    does not know what the data can answer.
    """
    entry = get_table_kb(table)
    out = []
    for item, _cls in _iter_queries(entry, (POSITIVE,)):
        if KIND_TAXONOMY.get(item.get("kind"), {}).get("cat") != "business":
            continue
        if not is_readonly_select(item.get("sql")):
            continue
        out.append({"question": item.get("question", ""), "sql": item["sql"],
                    "business_need": item.get("business_need", ""),
                    "kind": item.get("kind", "")})
        if len(out) >= limit:
            break
    return out


# ---------------------------------------------------------------------------
# Negative pre-flight (v3.1)
# ---------------------------------------------------------------------------

_WORD_RE = re.compile(r"[a-z0-9]+")
_STOP = {"the", "a", "an", "of", "for", "in", "on", "to", "and", "or", "is",
         "are", "what", "which", "show", "list", "give", "me", "all", "each",
         "que", "les", "des", "de", "du", "la", "le", "un", "une", "quels",
         "quelles", "montre", "donne", "moi", "tous", "toutes", "chaque"}


def _tokens(text: str) -> set:
    return {w for w in _WORD_RE.findall((text or "").lower()) if w not in _STOP}


def best_negative_match(question: str, tables, min_overlap: float = 0.85) -> dict | None:
    """Is this question one the KB records as NOT answerable?

    Symmetric to the pipeline's positive catalog short-circuit: instead of
    returning gold SQL, it returns the recorded reason so the caller can
    decline immediately and explain, rather than spending max_retries LLM
    calls to fail without a diagnosis.

    Deliberately strict (0.85) and restricted to UNANSWERABLE: an INVALID
    entry describes a badly-WRITTEN query, which a different phrasing may
    well fix, whereas UNANSWERABLE describes data the schema simply does
    not hold. A false refusal is far more costly than a wasted retry.
    """
    qt = _tokens(question)
    if not qt:
        return None
    best = None
    for table in tables or []:
        entry = get_table_kb(table)
        for item, cls in _iter_queries(entry, (UNANSWERABLE,)):
            it = _tokens(item.get("question", ""))
            if not it:
                continue
            overlap = len(qt & it) / max(len(qt), len(it))
            if overlap >= min_overlap and (best is None or overlap > best["overlap"]):
                best = {"table": table, "question": item.get("question", ""),
                        "why": item.get("expected_error") or item.get("guidance", ""),
                        "guidance": item.get("guidance", ""),
                        "kind": item.get("kind", ""), "class": cls,
                        "overlap": overlap}
    return best


# ---------------------------------------------------------------------------
# Error -> repair hint (v3.1)
# ---------------------------------------------------------------------------

_ERR_UNKNOWN_COL = re.compile(r"unknown column '([^']+)'", re.I)
_ERR_UNKNOWN_TBL = re.compile(r"table '([^']*?[`.]?([a-z0-9_]+))' doesn'?t exist", re.I)
_ERR_AMBIGUOUS = re.compile(r"column '([^']+)' in .* is ambiguous", re.I)


def _known_columns(tables) -> list[str]:
    cols = []
    for t in tables or []:
        cols.extend(get_table_kb(t).get("columns", {}).keys())
    return cols


def repair_hint(error_text: str, tables=None) -> str:
    """Corrective instruction for a DB error, in the KB's own vocabulary.

    The enriched KB documents one canonical guidance per error class
    (kinds unknown_column, unknown_table, aggregate_in_where,
    group_by_violation, ambiguous_column, unsupported_*). This turns the
    raw engine message into that instruction, and — for unknown
    identifiers — proposes the closest REAL ones taken from the KB, which
    is what actually lets the next attempt succeed instead of guessing
    again.

    Returns "" when nothing useful can be said (never invents).
    """
    err = error_text or ""
    low = err.lower()

    m = _ERR_UNKNOWN_COL.search(err)
    if m:
        bad = m.group(1).split(".")[-1]
        near = difflib.get_close_matches(bad, _known_columns(tables), n=3, cutoff=0.6)
        hint = f"Column '{bad}' does not exist in the tables of this schema."
        if near:
            hint += " Closest real columns: " + ", ".join(near) + "."
        return hint + (" Use only the columns listed in the CREATE TABLE above, "
                       "or state that the information is not available.")

    m = _ERR_UNKNOWN_TBL.search(err)
    if m:
        bad = m.group(2)
        near = difflib.get_close_matches(bad, list(load_kb().keys()), n=3, cutoff=0.5)
        hint = f"Table '{bad}' does not exist."
        if near:
            hint += " Closest real tables: " + ", ".join(near) + "."
        return hint + " Only the tables provided in the schema context may be used."

    m = _ERR_AMBIGUOUS.search(err)
    if m:
        return (f"Column '{m.group(1)}' exists in several joined tables. "
                f"Qualify every column with its table name or alias.")

    if "invalid use of group function" in low:
        return ("An aggregate cannot appear in WHERE. Move the condition to "
                "HAVING after a GROUP BY, or wrap the aggregate in a subquery.")
    if "only_full_group_by" in low or "not in group by" in low or "1055" in low:
        return ("Every selected column must either appear in GROUP BY or be "
                "wrapped in an aggregate function.")
    if "window function" in low or "over (" in low or "row_number" in low:
        return ("Window functions are not supported by this engine. Rewrite "
                "with a correlated subquery or a self-join.")
    if "with " in low and "syntax" in low:
        return ("Common table expressions are not supported by this engine. "
                "Use a derived table in the FROM clause instead.")
    if "division by zero" in low:
        return "Guard the denominator with NULLIF(expr, 0)."
    return ""


# ---------------------------------------------------------------------------
# Composite-key helpers (v2.1)
# ---------------------------------------------------------------------------

def _split_cols(value) -> list[str]:
    """'a, b' -> ['a', 'b'] ; ['a','b'] -> ['a','b'] ; None -> []."""
    if not value:
        return []
    if isinstance(value, list):
        return [str(v).strip() for v in value if str(v).strip()]
    return [c.strip() for c in str(value).split(",") if c.strip()]


def _pk_cols(entry: dict) -> list[str]:
    """Primary key as a list of columns, whatever the stored format."""
    return _split_cols(entry.get("primary_key"))


def _rel_pairs(rel: dict) -> list[tuple[str, str]]:
    """[(own_col, related_col), ...] — composite-safe."""
    own = _split_cols(rel.get("own_column"))
    ref = _split_cols(rel.get("related_column"))
    return list(zip(own, ref)) if own and len(own) == len(ref) else []


def _join_sql(rel: dict, table: str) -> str:
    """Executable AND-composed join condition rendered from column pairs.
    Falls back to the raw join_on ONLY for single-column relationships
    where pairs could not be derived (legacy entries)."""
    pairs = _rel_pairs(rel)
    if pairs:
        rt = rel.get("related_table", "?")
        return " AND ".join(f"{rt}.{rc} = {table}.{oc}" for oc, rc in pairs)
    join_on = rel.get("join_on", "")
    # never emit DeZign composite notation
    return join_on if "," not in join_on else ""


# ---------------------------------------------------------------------------

def get_sample_questions(table: str) -> list[str]:
    """
    Return raw NL questions for a table, regardless of format: legacy
    plain strings, or the "question" field of curated {question, sql}
    pairs. Used ONLY for embedding enrichment — never as SQL few-shots.

    v3.0: POSITIVE queries only. Embedding the negative families would
    make "Delete all X records added last month" a retrieval anchor for
    table X, and pull the table in on questions it cannot answer.
    """
    return _sample_questions_from_entry(get_table_kb(table))


def get_sample_queries(table: str, max_pairs: int = 4, question: str = "") -> list[dict]:
    """
    Return curated {"question", "sql"} pairs for few-shot injection into
    the SQL-generation prompt (build_ddl_with_kb).

    v3.0: filtered to POSITIVE queries before any capping (see module
    docstring); the level balance below then applies to that subset only.

    v2.1: level-balanced cap. The v2 KB carries 8-16 validated queries per
    table; injecting all of them bloats the prompt (bad for local 7B
    models) without improving generation. We pick one query per level
    (basic, intermediate, advanced) favouring kind diversity, then fill up
    to max_pairs. Pass max_pairs=0 for the previous unlimited behaviour.
    """
    entry = get_table_kb(table)

    # v3.0: POSITIVE only. An INVALID example teaches the model to emit
    # broken SQL; an EMPTY one teaches it to answer nothing. Both are in
    # the enriched KB on purpose, for evaluation -- not for prompting.
    pairs = [
        {"question": item["question"], "sql": item["sql"],
         "level": item.get("level", "basic"), "kind": item.get("kind", "")}
        for item, _cls in _iter_queries(entry, (POSITIVE,))
        if item.get("question") and is_readonly_select(item.get("sql"))
    ]
    if not max_pairs or len(pairs) <= max_pairs:
        return [{"question": p["question"], "sql": p["sql"]} for p in pairs]

    # v3.1 -- SHAPE-AWARE selection. When the user's question is known,
    # prefer the examples whose kind answers that shape: "how many X per Y"
    # -> group_by_enum / having / share_of_total; "which X has no Y" ->
    # anti_join / coverage_gap. Same prompt budget, far higher relevance.
    # Falls back to the v2.1 level-balanced pick when no shape is detected,
    # so behaviour is unchanged for callers that pass no question.
    wanted = rank_kinds(question)
    if wanted:
        rank = {k: i for i, k in enumerate(wanted)}
        matched = sorted((p for p in pairs if p["kind"] in rank),
                         key=lambda p: rank[p["kind"]])
        picked = []
        seen_kinds = set()
        for p in matched:
            if p["kind"] in seen_kinds:
                continue
            picked.append(p)
            seen_kinds.add(p["kind"])
            if len(picked) >= max_pairs:
                break
        # Always keep one plain example: it anchors the table's real column
        # names, which a purely analytical few-shot set may never show.
        if len(picked) < max_pairs:
            for p in pairs:
                if p["kind"] in ("examples", "count") and p["kind"] not in seen_kinds:
                    picked.append(p)
                    seen_kinds.add(p["kind"])
                    break
        for p in pairs:
            if len(picked) >= max_pairs:
                break
            if p not in picked:
                picked.append(p)
        if picked:
            return [{"question": p["question"], "sql": p["sql"]} for p in picked[:max_pairs]]

    picked: list[dict] = []
    seen_kinds: set = set()
    for lvl in ("basic", "intermediate", "advanced"):
        for p in pairs:
            if p["level"] == lvl and p["kind"] not in seen_kinds:
                picked.append(p)
                seen_kinds.add(p["kind"])
                break
    for p in pairs:
        if len(picked) >= max_pairs:
            break
        if p not in picked:
            picked.append(p)
    return [{"question": p["question"], "sql": p["sql"]} for p in picked[:max_pairs]]


def get_relationships(table: str, role: str | None = None) -> list[dict]:
    """
    Return this table's relationships, optionally filtered by role
    ("parent_of" or "child_of").
    """
    entry = get_table_kb(table)
    rels = entry.get("relationships", [])
    if role is None:
        return rels
    return [r for r in rels if r.get("role") == role]


def get_related_tables(table: str) -> list[str]:
    """Sorted, de-duplicated list of directly connected table names."""
    return sorted({r["related_table"] for r in get_relationships(table) if r.get("related_table")})


def _sample_questions_from_entry(entry: dict) -> list[str]:
    """POSITIVE questions only -- see get_sample_questions()."""
    return [item["question"] for item, _cls in _iter_queries(entry, (POSITIVE,))
            if item.get("question")]


def _related_tables_from_entry(entry: dict) -> list[str]:
    return sorted({r["related_table"] for r in entry.get("relationships", []) if r.get("related_table")})


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------

def _format_allowed_values(allowed: dict | list) -> str:
    """{code: meaning} -> 'CODE=meaning|...' ; legacy list -> 'A|B'."""
    if isinstance(allowed, dict):
        return "|".join(f"{code}={meaning}" for code, meaning in allowed.items())
    if isinstance(allowed, list):
        return "|".join(str(v) for v in allowed)
    return ""


def _data_type_hint(data_type: str) -> str:
    """Short semantic category from a raw SQL type (numeric/text/...)."""
    if not data_type:
        return ""
    t = data_type.strip().upper()
    numeric_prefixes = ("INT", "BIGINT", "SMALLINT", "TINYINT", "DECIMAL", "NUMERIC", "FLOAT", "DOUBLE", "REAL")
    text_prefixes = ("VARCHAR", "CHAR", "TEXT", "MEDIUMTEXT", "LONGTEXT", "TINYTEXT")
    date_prefixes = ("DATE", "DATETIME", "TIMESTAMP", "TIME", "YEAR")
    boolean_prefixes = ("BOOL", "BIT")

    if t.startswith(numeric_prefixes):
        return "numeric"
    if t.startswith("ENUM") or t.startswith("SET"):
        return "categorical"
    if t.startswith(date_prefixes):
        return "date/time"
    if t.startswith(boolean_prefixes):
        return "boolean"
    if t.startswith(text_prefixes):
        return "text"
    return ""


def column_inline_comment(col_entry: dict) -> str:
    """Concise inline SQL comment for a column (type tag, description,
    allowed values, examples, notes)."""
    parts: list[str] = []

    data_type = col_entry.get("data_type", "").strip()
    if data_type:
        category = _data_type_hint(data_type)
        type_tag = f"[{data_type}, {category}]" if category else f"[{data_type}]"
        parts.append(type_tag)

    desc = col_entry.get("description", "").strip()
    if desc:
        parts.append(desc)

    allowed = col_entry.get("allowed_values", {})
    _capped, _more = _cap_allowed(allowed, PROMPT_MAX_ENUM_VALUES)
    allowed_str = _format_allowed_values(_capped)
    if allowed_str:
        if _more:
            allowed_str += f"|(+{_more} more)"
        parts.append("Allowed: " + allowed_str)

    examples = col_entry.get("example_values", [])
    if examples and not allowed:
        parts.append("e.g. " + ", ".join(f'"{v}"' for v in examples[:3]))

    notes = col_entry.get("notes", "").strip()
    if notes:
        parts.append(f"({notes})")

    return "  -- " + ".  ".join(parts) if parts else ""


# Max ENUM values folded into the DDL PROMPT per column (v3.4).
# Measured on a real run (2026-07-28): country_code alone carries ~200
# decoded values, pushing the schema context to 62k chars -- 4+ minutes
# of generation on a partially-offloaded local model, for enum values the
# question almost never filters on. The FIRST values (+ an explicit
# "(+N more)" marker) preserve the LLM's awareness that the column is
# categorical; a question needing a rare value still works because the
# static checker / EXPLAIN validate the SQL against the real DB, not this
# comment. Env-tunable; set very high to restore the old behaviour.
PROMPT_MAX_ENUM_VALUES = int(os.getenv("REQA_PROMPT_MAX_ENUM", "16"))


def _cap_allowed(allowed, limit: int):
    """First `limit` allowed_values + count marker, format-preserving."""
    if isinstance(allowed, dict) and len(allowed) > limit:
        capped = dict(list(allowed.items())[:limit])
        return capped, len(allowed) - limit
    if isinstance(allowed, list) and len(allowed) > limit:
        return allowed[:limit], len(allowed) - limit
    return allowed, 0


# Max ENUM values folded into the embedding text per column. Full lists
# (e.g. country_code: ~200 decoded values) blow past fastembed's ~512-token
# window on their own, silently truncating everything after them — including
# sample questions, the strongest retrieval signal. The DDL prompt and the
# static checker still see the FULL list via column_inline_comment /
# extract_business_rules; this cap applies to the embedding text only.
EMBED_MAX_ENUM_VALUES = 12

def table_embedding_tokens(table: str, ddl_description: str = "", kb_entry: dict | None = None) -> str:
    """Rich text string used to embed a table into Qdrant.

    v2.1.1 token ordering: identity -> keywords -> SAMPLE QUESTIONS ->
    related tables -> primary key -> columns. Sample questions are the
    text most similar to real user queries, so they must be embedded
    FIRST-class, never risk truncation behind long column/enum blocks."""
    entry = kb_entry if kb_entry is not None else get_table_kb(table)

    domain = entry.get("domain", [])
    domain_str = ", ".join(domain) if isinstance(domain, list) else str(domain)

    description = entry.get("description") or entry.get("label") or ddl_description

    tokens: list[str] = [
        f"table:{table}",
        f"label:{entry.get('label', table)}",
        f"domain:{domain_str}",
        f"description:{description}",
    ]

    keywords = entry.get("keywords", [])
    if keywords:
        tokens.append("keywords:" + ",".join(keywords))

    # Structured semantic/reasoning/query-pattern fields remain in the
    # payload and runtime context, but are intentionally not embedded here.
    # Keeping long guidance out of vectors avoids retrieval drift/noise.

    # Sample questions FIRST (before columns): closest text to real user
    # queries — must never be truncated away by long enum blocks.
    for q in _sample_questions_from_entry(entry):
        tokens.append(f"sample_q:{q}")

    related = _related_tables_from_entry(entry)
    if related:
        tokens.append("related_to:" + ",".join(related))

    pk_cols = _pk_cols(entry)
    if pk_cols:
        tokens.append("primary_key:" + ", ".join(pk_cols))

    for col_name, col_data in entry.get("columns", {}).items():
        data_type = col_data.get("data_type", "")
        desc = col_data.get("description", "")
        allowed = col_data.get("allowed_values", {})
        examples = col_data.get("example_values", [])
        notes = col_data.get("notes", "")

        token = f"col:{col_name}"
        if col_name in pk_cols:                      # composite-safe
            token += "(PK)"
        if data_type:
            category = _data_type_hint(data_type)
            token += f"({data_type}" + (f"/{category})" if category else ")")
        if desc:
            token += f"={desc}"
        # Cap enum values in the embedding text (full list stays in the
        # DDL prompt via column_inline_comment / extract_business_rules).
        if isinstance(allowed, dict) and len(allowed) > EMBED_MAX_ENUM_VALUES:
            capped = dict(list(allowed.items())[:EMBED_MAX_ENUM_VALUES])
            allowed_str = _format_allowed_values(capped) + f"|(+{len(allowed) - EMBED_MAX_ENUM_VALUES} more)"
        elif isinstance(allowed, list) and len(allowed) > EMBED_MAX_ENUM_VALUES:
            allowed_str = _format_allowed_values(allowed[:EMBED_MAX_ENUM_VALUES]) + f"|(+{len(allowed) - EMBED_MAX_ENUM_VALUES} more)"
        else:
            allowed_str = _format_allowed_values(allowed)
        if allowed_str:
            token += " values:" + allowed_str.replace("|", ",")
        elif examples:
            token += " eg:" + ",".join(str(e) for e in examples[:3])
        if notes:
            token += f" note:{notes}"
        tokens.append(token)

    return " | ".join(tokens)


enum_re =  re.compile( r"ENUM\(([^)]*)\)" )
enum_values_re = re.compile( r"'([^']+)'" )

def table_embedding_payload(
    table: str,
    ddl_description: str = "",
    kb_entry: dict | None = None,
    **kwargs
) -> dict:

    modified_description = ddl_description

    strip_enums = kwargs.get("strip_enums", False)

    if strip_enums:
        enum_matches = enum_re.findall(modified_description)
        for m in enum_matches:
            modified_description = modified_description.replace(m, "")

    # v2.1.2 -- enrich the payload with the KB fields that downstream code
    # already reads from `payload` (and, until now, never found there):
    #   sample_queries -> schema_rag's boost/rescue (retrieve, lines ~425/449)
    #                     and best_sample_query() -- the catalog short-circuit
    #                     was silently blind because this field was missing;
    #   domain         -> pipeline's explanation["retrieved_tables"] (XAI/UI);
    #   label/keywords -> future lexical matching, cheap to carry;
    #   columns        -> _llm_reformulations' schema vocabulary (was always
    #                     "(columns unknown)"). Names only: full column dicts
    #                     with ENUM meanings would bloat every point.

    rval = {
        "table": table,
        "description": modified_description,
        "category": "table",
        }
        
    if kb_entry:

        rval["sample_queries"] = retrieval_safe_sample_queries(kb_entry)
        rval["domain"] = kb_entry.get("domain", []) or []
        rval["label"] = kb_entry.get("label", "") or ""
        rval["keywords"] = kb_entry.get("keywords", []) or []

        cols = kb_entry.get("columns") or {}
        rval["columns"] = (
            [{"name": c} for c in cols]
            if isinstance(cols, dict)
            else [
                {"name": c.get("name", "")}
                for c in cols
                if isinstance(c, dict)
            ]
        )

        # -------- Relationships --------

        relationships = kb_entry.get("relationships", []) or []

        rval["relationships"] = [
            {
                "role": rel.get("role", ""),
                "related_table": rel.get("related_table", ""),
                "own_column": rel.get("own_column", ""),
                "related_column": rel.get("related_column", ""),
                "cardinality": rel.get("cardinality", ""),
            }
            for rel in relationships
            if isinstance(rel, dict)
        ]

        rval["primary_key"]    = kb_entry.get("primary_key", "") or ""
        rval["relationships"]  = kb_entry.get("relationships", []) or []
        # Preserve structured production guidance for retrieval/reranking and
        # runtime context. These are compact, curated fields (not full DDL).
        for key in ("semantic", "reasoning_rules", "query_patterns", "provenance"):
            if kb_entry.get(key):
                rval[key] = kb_entry[key]

        # Keep the structured column knowledge used by RAG/reranker, but cap
        # enum values so a single large code list cannot bloat every point.
        column_knowledge = {}
        if isinstance(cols, dict):
            for name, data in cols.items():
                if not isinstance(data, dict):
                    continue
                metadata = {
                    key: data[key]
                    for key in ("data_type", "description", "notes")
                    if data.get(key)
                }
                allowed = data.get("allowed_values")
                if isinstance(allowed, dict):
                    metadata["allowed_values"] = dict(list(allowed.items())[:20])
                    if len(allowed) > 20:
                        metadata["allowed_values_truncated"] = len(allowed) - 20
                elif isinstance(allowed, list):
                    metadata["allowed_values"] = allowed[:20]
                    if len(allowed) > 20:
                        metadata["allowed_values_truncated"] = len(allowed) - 20
                if metadata:
                    column_knowledge[name] = metadata
        rval["column_knowledge"] = column_knowledge
    return rval
    return rval



def build_ddl_with_kb(table: str, columns: list[dict], question: str = "") -> str:
    """
    Generate a DDL CREATE TABLE fragment enriched with KB inline comments.
    Used by schema_rag.py to build the schema context sent to the LLM.

    v2.1: every relationship shown to the LLM is rendered as an EXECUTABLE
    join condition via _join_sql() (AND-composed for composite keys). The
    raw DeZign join_on ("a, b = c, d") is never emitted — it was invalid
    SQL and the historical source of hallucinated JOINs.
    """
    entry = get_table_kb(table)
    domain = entry.get("domain", [])
    domain_str = ", ".join(domain) if isinstance(domain, list) else str(domain)
    description = entry.get("description") or entry.get("label", "")
    pk_cols = _pk_cols(entry)

    lines = [
        f"-- [{domain_str}] {table}",
        f"-- Description: {description}",
    ]

    if pk_cols:
        lines.append("-- Primary key: " + ", ".join(pk_cols))

    keywords = entry.get("keywords", [])
    if keywords:
        lines.append(f"-- Also known as: {', '.join(keywords)}")

    parent_of = get_relationships(table, "parent_of")
    child_of = get_relationships(table, "child_of")
    if parent_of:
        lines.append("-- Referenced by (parent of):")
        for r in parent_of:
            join_sql = _join_sql(r, table)
            meta = f"[{r.get('type', '?')}, {r.get('cardinality', '?')}]"
            lines.append(f"--   {r.get('related_table', '?')}  ON {join_sql}  {meta}  (fk: {r.get('name', '')})")
    if child_of:
        lines.append("-- References (child of):")
        for r in child_of:
            join_sql = _join_sql(r, table)
            meta = f"[{r.get('type', '?')}, {r.get('cardinality', '?')}]"
            lines.append(f"--   {r.get('related_table', '?')}  ON {join_sql}  {meta}  (fk: {r.get('name', '')})")

    # Per-column FK annotation from own_column/related_column pairs.
    # v2.1: composite relationships are split into their column pairs so
    # each physical column gets its own tag (the _stat family previously
    # matched nothing because own_column was "a, b").
    fk_by_column: dict[str, list[str]] = {}
    for r in parent_of + child_of:
        rel_table = r.get("related_table")
        if not rel_table:
            continue
        arrow = "<-" if r.get("role") == "parent_of" else "->"
        for own_col, rel_col in _rel_pairs(r):
            fk_by_column.setdefault(own_col, []).append(f"{arrow} {rel_table}.{rel_col}")

    lines.append(f"CREATE TABLE {table} (")
    for col in columns:
        col_kb = get_column_kb(table, col["name"])
        comment = column_inline_comment(col_kb)
        if col["name"] in pk_cols:                  # composite-safe
            comment = "  -- [PRIMARY KEY]" + (comment[4:] if comment else "")

        fk_tags = fk_by_column.get(col["name"])
        if fk_tags:
            fk_str = "FK: " + "; ".join(fk_tags)
            comment = comment + f"  ({fk_str})" if comment else f"  -- ({fk_str})"

        nullable = "" if col.get("nullable") == "YES" else " NOT NULL"

        col_type = col.get("type") or ""
        if not col_type or col_type.upper() == "UNKNOWN":
            col_type = col_kb.get("data_type") or col_type or "UNKNOWN"
        lines.append(f"    {col['name']}  {col_type}{nullable}{comment}")

    lines.append(");\n")

    # ── Few-shot sample queries (POSITIVE only, level-balanced cap) ──────
    # v3.1: `question` is optional and defaults to "" -- callers that do not
    # pass it get exactly the v2.1 level-balanced selection.
    samples = get_sample_queries(table, question=question)   # max_pairs=4
    if samples:
        lines.append(f"-- Example queries for {table}:")
        for s in samples:
            lines.append(f"-- Q: {s['question']}")
            lines.append(f"-- A: {s['sql']}")
        lines.append("")

    # ── Optional: what this schema CANNOT answer (v3.0) ──────────────────
    # OFF by default: costs ~2 lines of prompt per table and the budget is
    # tight for local 7B models. Turn on with REQA_KB_NEGATIVE_HINTS=1 when
    # the failure mode you are fighting is confident answers to questions
    # the schema has no data for.
    if os.getenv("REQA_KB_NEGATIVE_HINTS", "0") == "1":
        negatives = get_negative_examples(table, limit=2)
        if negatives:
            lines.append(f"-- NOT answerable from {table} (decline, do not invent):")
            for n in negatives:
                lines.append(f"--   \"{n['question']}\" -- {n['why']}")
            lines.append("")

    return "\n".join(lines)


def extract_business_rules(table: str) -> list[str]:
    """Business rules derived from allowed_values for each column."""
    rules: list[str] = []
    entry = get_table_kb(table)
    for col_name, col_data in entry.get("columns", {}).items():
       

        print(str(table) + " " +  str(col_name) + "  " +  str(col_data))

        if not isinstance(col_data, dict):
            print(
                f"*** INVALID COLUMN ***\n"
                f"TABLE={table}\n"
                f"COLUMN={col_name}\n"
                f"VALUE={repr(col_data)}\n"
            )
        allowed = col_data.get("allowed_values", {})
        
        #################
        
        if not allowed:
            continue
        _capped, _more = _cap_allowed(allowed, PROMPT_MAX_ENUM_VALUES)
        if isinstance(_capped, dict):
            body = ", ".join(f"'{code}': '{meaning}'" for code, meaning in _capped.items())
        else:  # legacy flat list fallback
            body = ", ".join(f"'{v}'" for v in _capped)
        if _more:
            body += f", ... (+{_more} more values)"
        rules.append(f"{table}.{col_name} \u2208 " + "{" + body + "}")
    return rules
