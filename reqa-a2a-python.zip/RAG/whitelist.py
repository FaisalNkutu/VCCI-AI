"""
Schema ingestion script V2 — run ONCE before starting the agent.

Usage:
    python ingest.py path/to/schema.sql

What it does:
    1. Loads the already generated file: RAG/all_tables_descriptions.json
    2. Embeds each description locally (fastembed, no external API)
    3. Upserts into Qdrant

Re-running recreates the collection (safe to run multiple times).
"""

import sys
import argparse
from pathlib import Path

import json

import sqlglot
from sqlglot import exp
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct

from config import settings
from agent.embedder import Embedder



def is_table_included( name, wl_json  ):

    # No whitelist Filter 
    if len(wl_json) == 0:
        return True
    # If there is a whiteliost, table must be in it to be processed
    if name in wl_json["table_names"]:
        return True
    
    return False

#
# load_whitelist()
#
def load_whitelist(whitelist_file):
    
    wl_json = {}
    if whitelist_file is not None:
        try:
            with open( whitelist_file, "r", encoding="utf-8") as file:
                content = file.read()
                wl_json = json.loads( content )                
        except:
            print("whitelist could not be opened")
            return

    return wl_json




#
#   _load_all_table_definitions()
#       DEPRECATED
#       we should reload the full_kb which was already filled with the same information
#
def _load_all_table_definitions(json_table_def_file):
    table_defs = {}
    # Load The file with all the definitions
    with open( json_table_def_file, "r", encoding="utf-8") as file:
        content = file.read()
        table_defs = json.loads( content )
    return table_defs

#
#   _load_all_table_definitions()
#       DEPRECATED
#       we should reload the full_kb which was already filled with the same information
#
def _filter_all_tables(table_defs: str, whitelist_file : str):

    used_table_definitions = {}
    if whitelist_file is not None:
        try:
            with open( whitelist_file, "r", encoding="utf-8") as file:
                content = file.read()
                wl_json = json.loads( content )                
        except:
            print("whitelist could not be opened")
            return

    tables = table_defs["tables"]
    for tbl in tables:
        tbl_name = tbl["name"]
        if is_table_included( tbl_name  , wl_json ):
            used_table_definitions[tbl_name] = tbl 
#            print( "USE " +  tbl_name )

    return used_table_definitions



# ── Ingestion ─────────────────────────────────────────────────────────────────



if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Ingest JSON table definitions into Qdrant")
    parser.add_argument("json_file", default="RAG/all_tables_descriptions.json"   ,  help="Path to your .json file")    
    parser.add_argument("--whitelist", default=None,  help="Json file containing a list of valid table names. All tables in not this list will be ignored")    

    args = parser.parse_args()

    table_defs = {}
    wl_json = {}

    # Load the whitelist if specified    
    table_defs = load_all_table_definitions(json_table_def_file)    
    used_table_definitions = filter_all_tables()
       
    for key, val in used_table_definitions.items():
        descr_short = str(val)
        print( key + ":\t" + descr_short[ : 32 ] + "..."  )
    




