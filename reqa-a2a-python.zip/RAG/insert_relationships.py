"""
Insère un champ "relationships" (parent_of / child_of) dans les définitions
RAG des tables bleues, à partir des relations extraites du rapport DeZign
(entd.html).

Usage:
    python insert_relationships.py <rag_definitions.json> <blue_relationships.json> [-o output.json]

- rag_definitions.json  : ton fichier JSON existant contenant les définitions
                          de tables pour le RAG (ex: {"act": {...}, "act_stat": {...}, ...})
- blue_relationships.json : le fichier généré précédemment (dict brut role/name/
                          type/related_table/cardinality par table bleue)
"""

import json
import argparse
from pathlib import Path

# Les 15 tables bleues
BLUE_TABLES = [
    "act",
    "act_stat",
    "action_group",
    "act_event",
    "act_task",
    "move_act_task",
    "simulator_task",
    "simulator_task_trigger",
    "simulator_task_event",
    "comms_event",
    "comms_event_msg_type_assoc",
    "tx_event",
    "rx_event",
    "fire_event",
    "msg_type",
]


def build_semantics(table: str, entry: dict) -> str:
    """
    Génère une phrase en langage naturel décrivant la relation,
    utilisable directement par un système de retrieval (RAG).
    """
    role = entry["role"]
    other = entry["related_table"]
    card = entry["cardinality"]
    typ = entry["type"]

    card_txt = {
        "Exactly One": "exactly one",
        "Zero Or One": "zero or one",
        "One Or More": "one or more",
        "Zero Or More": "zero or more",
    }.get(card, card.lower())

    if role == "parent_of":
        base = f"{table} is the parent of {card_txt} {other} record(s)"
    else:  # child_of
        base = f"{table} references {other} ({card_txt} on the {other} side)"

    if typ == "Identifying":
        base += " — identifying relationship: the child's primary key includes the parent's key"
    else:
        base += " — non-identifying relationship: simple foreign key reference"

    return base


def transform_relationships(raw_entries: list[dict], table: str) -> dict:
    """
    Transforme la liste plate [{"role":..., "name":..., "type":..., "related_table":...,
    "cardinality":...}, ...] en structure groupée {"parent_of": [...], "child_of": [...]}.
    """
    grouped = {"parent_of": [], "child_of": []}

    for entry in raw_entries:
        role = entry["role"]  # "parent_of" or "child_of"
        item = {
            "table": entry["related_table"],
            "fk_name": entry["name"],
            "type": entry["type"],
            "cardinality": entry["cardinality"],
            "semantics": build_semantics(table, entry),
        }
        grouped[role].append(item)

    return grouped


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("rag_json", type=Path, help="Fichier JSON de définitions RAG à mettre à jour")
    parser.add_argument("relationships_json", type=Path, help="Fichier JSON des relations extraites (blue_relationships.json)")
    parser.add_argument("-o", "--output", type=Path, default=None, help="Fichier de sortie (par défaut: écrase l'entrée)")
    parser.add_argument("--dry-run", action="store_true", help="Affiche le résultat sans écrire de fichier")
    args = parser.parse_args()

    with open(args.rag_json, encoding="utf-8") as f:
        rag_definitions = json.load(f)

    with open(args.relationships_json, encoding="utf-8") as f:
        raw_relationships = json.load(f)

    updated = []
    skipped = []

    for table in BLUE_TABLES:
        if table not in rag_definitions:
            skipped.append(table)
            continue

        raw_entries = raw_relationships.get(table, [])
        rag_definitions[table]["relationships"] = transform_relationships(raw_entries, table)
        updated.append(table)

    output_path = args.output or args.rag_json
    if not args.dry_run:
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(rag_definitions, f, indent=2, ensure_ascii=False)

    print(f"Tables mises à jour ({len(updated)}): {updated}")
    if skipped:
        print(f"Tables absentes du fichier RAG, ignorées ({len(skipped)}): {skipped}")
    if args.dry_run:
        print("\n--- DRY RUN: aucun fichier écrit ---")
        print(json.dumps({t: rag_definitions[t]["relationships"] for t in updated}, indent=2, ensure_ascii=False))
    else:
        print(f"\nFichier écrit: {output_path}")


if __name__ == "__main__":
    main()
