import json

def load_json_file(file_path):
    """
    Load a JSON file and return its content.

    Args:
        file_path (str): Path to the JSON file.

    Returns:
        dict or list: JSON content.
    """
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            data = json.load(file)
        return data

    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found.")
        return None

    except json.JSONDecodeError:
        print(f"Error: Invalid JSON format in '{file_path}'.")
        return None
    

def save_dict_to_json(data, file_path):
    """
    Save a dictionary to a JSON file.

    Args:
        data (dict): Dictionary to save.
        file_path (str): Path to the output JSON file.
    """
    try:
        with open(file_path, "w", encoding="utf-8") as file:
            json.dump(data, file, indent=4, ensure_ascii=False)

        print(f"JSON file saved successfully: {file_path}")

    except Exception as e:
        print(f"Error saving JSON file: {e}")
    
KB_full = load_json_file("RAG/KB_full_update.json")
mltr_codes_meanings = load_json_file("RAG/military_codes_meanings.json")
KB_full_spleq = load_json_file("RAG/KB_spleq_v2nlp.json")
Schema_ddl = load_json_file("RAG/schema_from_ddl.json")

# schema_from_ddl.json

#print(KB_full)
#print(mltr_codes_meanings)
#print(KB_full_spleq)

#print(Schema_ddl)
##########################################################
"""
for table, table_desc in KB_full.items():
    
    Columns = table_desc["columns"]
    Sample_queries = table_desc["sample_queries"]
    
    for col, col_desc in Columns.items():
        
        
        Col_desc = col_desc
        
        
        if "data_type" not in Col_desc.keys() and col in Schema_ddl[table]["columns"].keys():
            
            Col_desc["data_type"] = Schema_ddl[table]["columns"][col]["data_type"]
        
        
        if Col_desc["data_type"] == "ENUM" and "allowed_values" not in Col_desc.keys():
            
            keys = Schema_ddl[table]["columns"][col]["allowed_values"]
            
            
            
            Allwd_val = dict()
            
            #for enum_val, enum_mean in mltr_codes_meanings:
                
            for elmt in keys:
                Allwd_val[elmt] = mltr_codes_meanings[elmt]
                
            Col_desc["allowed_values"] = Allwd_val
            
               
            
        
        #if col_desc["data_type"] == 'ENUM' and "allowed_values" not in col_desc.keys():
        #print(Col_desc["data_type"] == 'ENUM' and "allowed_values" not in col_desc.keys())        
            
        """
        

    
    
    
        
        
####################################################################
        
import logging

logger = logging.getLogger("kb_ingest")


def enrich_kb_with_schema(KB_full, schema_ddl, codes_meanings, *, verbose=False):
    """Complète KB_full avec les data_type et allowed_values issus du schéma DDL.

    - Renseigne data_type depuis le schéma quand il manque.
    - Pour les colonnes ENUM, construit allowed_values = {code: signification}.
    - Ne plante pas sur une table/colonne/signification manquante : on journalise.
    Modifie KB_full en place et le retourne.
    """
    stats = {"data_type_set": 0, "enums_filled": 0,
             "missing_meaning": [], "missing_in_schema": []}

    for table, table_desc in KB_full.items():
        schema_table = schema_ddl.get(table)
        schema_cols = (schema_table or {}).get("columns", {})

        for col, col_desc in table_desc.get("columns", {}).items():
            schema_col = schema_cols.get(col)

            # 1) Compléter data_type depuis le schéma s'il manque
            if "data_type" not in col_desc:
                if schema_col and "data_type" in schema_col:
                    col_desc["data_type"] = schema_col["data_type"]
                else:
                    stats["missing_in_schema"].append(f"{table}.{col}")
                    if verbose:
                        logger.warning("data_type introuvable pour %s.%s", table, col)
                    continue  # sans data_type, rien de plus à faire

            # 2) Pour un ENUM sans allowed_values, les construire
            if col_desc.get("data_type") == "ENUM" and "allowed_values" not in col_desc:
                allowed = (schema_col or {}).get("allowed_values")
                if not allowed:
                    if verbose:
                        logger.warning("ENUM sans allowed_values dans le schéma : %s.%s",
                                       table, col)
                    continue

                mapping = {}
                for code in allowed:
                    meaning = codes_meanings.get(code)
                    if meaning is None:
                        stats["missing_meaning"].append(f"{table}.{col}:{code}")
                        if verbose:
                            logger.warning("Pas de signification pour le code %r (%s.%s)",
                                           code, table, col)
                    mapping[code] = meaning  # None si inconnu -> à compléter plus tard
                col_desc["allowed_values"] = mapping
                stats["enums_filled"] += 1

    logger.info(
        "Ingestion : %d ENUM complétés, %d data_type manquants, %d codes sans signification",
        stats["enums_filled"], len(stats["missing_in_schema"]), len(stats["missing_meaning"]),
    )
    return KB_full, stats


# --- usage ---
KB_full = load_json_file("RAG/KB_full_update.json")

mltr_codes_meanings = load_json_file("RAG/military_codes_meanings.json")
Schema_ddl = load_json_file("RAG/schema_from_ddl.json")

"""
for table in KB_full.keys():
    
    KB_full[table]["sample_queries"] = KB_full_spleq[table]

KB_full, stats = enrich_kb_with_schema(
    KB_full, Schema_ddl, mltr_codes_meanings, verbose=True
)

#print(KB_full)

#print(stats)

save_dict_to_json(KB_full, "RAG/KB_full_update2.json")
        
"""