"""
Sample query generator — one-shot per table.

For each table in KB_full.json that has no (or bad) sample_queries, calls
the Ollama render model to generate 5 realistic NL questions. Persists
incrementally so partial runs are safe to re-run.
"""
from __future__ import annotations

import copy
import json
import re
import time
from typing import Optional

import ollama

from config.settings import get_settings
from RAG.knowledge_base import KB_PATH, load_kb

# ---------------------------------------------------------------------------
# SQL / technical-term detector used to reject contaminated outputs
# ---------------------------------------------------------------------------

_SQL_PATTERN = re.compile(
    r"\b(SELECT|FROM|WHERE|JOIN|ON|INSERT|UPDATE|DELETE|ORDER\s+BY|GROUP\s+BY"
    r"|HAVING|LIMIT|UNION|WITH\s+\w|INNER|OUTER|LEFT|RIGHT|COUNT\(|SUM\(|AVG\()\b",
    re.IGNORECASE,
)

_TECH_PATTERN = re.compile(
    r"_idx\b|_id\b|_stat\b|proute_|obj_item|CREATE\s+TABLE|\bNULL\b|=\s*\d+",
    re.IGNORECASE,
)

_GENERIC_PHRASES = [
    "what data is available",
    "what information is available",
    "list all records",
    "list all entries",
    "show all data",
    "show all records",
    "what is in the database",
    "all information about",
    "everything in the",
]

# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

_SYSTEM = """\
You are a senior military intelligence and operational data analyst.
Your task is to produce realistic natural language questions for a military
information system.  The questions will be used to train and evaluate a
Text-to-SQL retrieval system — they must sound like what a real analyst
would type into a search box, not like SQL queries.
"""

_TEMPLATE = """\
You are provided with the full metadata of one database table from a military
information management system.

═══════════════════════════════════════════
TABLE: {table}
LABEL: {label}
DOMAIN: {domain}
DESCRIPTION: {description}
═══════════════════════════════════════════

PRIMARY KEY: {primary_key}

COLUMNS:
{columns}

TABLES THAT REFERENCE THIS TABLE (potential JOINs):
{referenced_by}

BUSINESS RULES:
{business_rules}
═══════════════════════════════════════════

TASK
Generate exactly 5 realistic natural-language analytical questions.

REQUIREMENTS
1. Questions must sound like what a military analyst types into a search box.
2. Cover exactly these 5 question types (one each):
   a. FILTER    — specific filtering on one or more column values
   b. COUNT     — aggregation, count, or summary
   c. TREND     — temporal or comparative trend analysis
   d. CROSS     — cross-entity analysis requiring data from referenced tables
   e. DECISION  — an operationally motivated question supporting a real decision

3. Use the allowed values and business rules when relevant — refer to them by
   their human-readable meaning, never by their code.
   Example: use "Hurricane" not "HURR", use "active mission" not "stat_code=A".

4. When referenced tables exist, at least two questions should naturally
   require combining information from this table and its related entities.
   The connection must be implied by context, not stated explicitly.

5. Keep questions specific enough that a SQL query can be generated from them.

ABSOLUTE PROHIBITIONS — any question that contains any of the following will
be rejected and you will have wasted your generation:
  ✗ SQL keywords: SELECT, FROM, WHERE, JOIN, ORDER BY, GROUP BY, HAVING, COUNT(
  ✗ Column names ending in _idx, _id, _stat, _code, _type
  ✗ Table names or schema identifiers
  ✗ Parentheses containing filter values, e.g. (stat = 'A')
  ✗ Generic questions: "What data is available?", "List all records"
  ✗ Introductory text, numbering, bullet points, or explanations

OUTPUT FORMAT
  • Exactly 5 lines
  • One question per line
  • No numbering, no bullets, no labels, no blank lines between questions
"""


# ---------------------------------------------------------------------------
# Context builders
# ---------------------------------------------------------------------------

def _str(v) -> str:
    """Safely convert any value (str, list, dict, …) to a plain string."""
    if isinstance(v, list):
        return ", ".join(str(x) for x in v)
    if isinstance(v, dict):
        return ", ".join(str(x) for x in v.values())
    return str(v) if v is not None else ""


def _format_allowed(allowed) -> str:
    """
    Format allowed_values for the LLM prompt.
    - list  → "A | B | C"
    - dict  → "Label1 | Label2 | Label3"  (uses dict VALUES = human labels)
    """
    if isinstance(allowed, dict):
        items = list(allowed.values())[:10]
        return " | ".join(str(v) for v in items)
    if isinstance(allowed, list):
        return " | ".join(str(v) for v in allowed[:10])
    return _str(allowed)


def _build_column_summary(columns: dict, foreign_keys: list[str] | None = None) -> str:
    """
    Build a rich column summary for the LLM prompt.
    Includes description, allowed values, and FK hints.
    """
    fk_lookup: dict[str, str] = {}
    for fk in (foreign_keys or []):
        # format: "local_col → parent_table.parent_col"
        match = re.match(r"(\w+)\s*→\s*(\w+)\.(\w+)", fk)
        if match:
            fk_lookup[match.group(1)] = f"{match.group(2)}.{match.group(3)}"

    parts: list[str] = []
    for col_name, col_data in list(columns.items()):
        desc    = _str(col_data.get("description", "")).strip()
        allowed = col_data.get("allowed_values", []) or []
        examples = col_data.get("example_values", []) or []
        notes   = _str(col_data.get("notes", "")).strip()

        line = f"  • {col_name}"
        if desc:
            line += f": {desc}"
        if allowed:
            line += f"  [allowed: {_format_allowed(allowed)}]"
        elif examples:
            vals = ", ".join(f'"{_str(v)}"' for v in (examples or [])[:4])
            line += f"  [e.g. {vals}]"
        if notes:
            line += f"  ({notes})"
        if col_name in fk_lookup:
            line += f"  → links to {fk_lookup[col_name]}"
        parts.append(line)

    return "\n".join(parts) if parts else "  No column metadata available."


def _build_referenced_by_summary(referenced_by: list, kb: dict | None = None) -> str:
    """
    Build the referenced-by section with rich context from the KB.

    For each entry, extracts:
      - child table name and FK column
      - label and description from KB (if available)

    Format:
      • act_event (Activity Events — records operational activities)
          links via: act_event.fac_id
    """
    if not referenced_by:
        return "  None"

    lines: list[str] = []
    for ref in referenced_by:
        if isinstance(ref, str):
            # "child_table.fk_column" → e.g. "act_event.fac_id"
            parts = ref.split(".", 1)
            child_table = parts[0]
            fk_col = parts[1] if len(parts) > 1 else ""

            # Enrich with KB data if available
            if kb:
                kb_entry = kb.get(child_table, {})
                label = kb_entry.get("label", "") or ""
                desc  = kb_entry.get("description", "") or ""
                domain_raw = kb_entry.get("domain", "") or ""
                # domain can be a list in the KB
                if isinstance(domain_raw, list):
                    domain = domain_raw[0] if domain_raw else ""
                else:
                    domain = str(domain_raw)
                label  = label.strip() if isinstance(label, str) else str(label)
                desc   = desc.strip()  if isinstance(desc, str)  else str(desc)
                domain = domain.strip()

                line = f"  • {child_table}"
                if label or desc:
                    line += f" ({label or desc}"
                    if domain:
                        line += f", domain: {domain}"
                    line += ")"
                if fk_col:
                    line += f"\n      → links via column: {fk_col}"
            else:
                line = f"  • {child_table}"
                if fk_col:
                    line += f" (linked via {fk_col})"

            lines.append(line)

        elif isinstance(ref, dict):
            label = ref.get("label") or ref.get("table") or "Unknown"
            desc = ref.get("description", "").strip()
            lines.append(f"  • {label}" + (f": {desc}" if desc else ""))

    return "\n".join(lines) if lines else "  None"


def _build_business_rules(columns: dict) -> str:
    """Extract domain rules from allowed_values to guide LLM."""
    rules: list[str] = []
    for col_name, col_data in columns.items():
        allowed = col_data.get("allowed_values", []) or []
        desc = _str(col_data.get("description", "")).strip()
        if allowed and desc:
            rules.append(f"  • {desc}: {_format_allowed(allowed)}")
    return "\n".join(rules) if rules else "  No explicit business rules defined."


# ---------------------------------------------------------------------------
# LLM call
# ---------------------------------------------------------------------------

def _call_llm(prompt: str, temperature: float = 0.75) -> list[str]:
    settings = get_settings()
    resp = ollama.chat(
        model=settings.ollama_render_model,
        messages=[
            {"role": "system", "content": _SYSTEM},
            {"role": "user", "content": prompt},
        ],
        options={"temperature": temperature, "num_predict": 600},
    )

    # Handle both old dict API and new Pydantic model API
    if hasattr(resp, "message"):
        raw = resp.message.content
    else:
        raw = resp["message"]["content"]

    raw = raw.strip()

    lines = []
    for ln in raw.splitlines():
        ln = ln.strip()
        if not ln or ln.startswith("#"):
            continue
        ln = re.sub(r"^\d+[\.\)]\s*", "", ln)   # remove leading "1. " "1) "
        ln = re.sub(r"^[-•*]\s*", "", ln)         # remove leading bullets
        ln = re.sub(r"^[a-e][\.\)]\s*", "", ln)   # remove "a. " "b) " labels
        ln = ln.strip()
        if len(ln) > 15:
            lines.append(ln)

    return lines[:5]


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def _is_valid_question(q: str) -> bool:
    """Return True only if the question looks like real natural language."""
    if len(q) < 25:
        return False
    if _SQL_PATTERN.search(q):
        return False
    if _TECH_PATTERN.search(q):
        return False
    q_lower = q.lower()
    if any(phrase in q_lower for phrase in _GENERIC_PHRASES):
        return False
    starts_with_question_word = any(
        q_lower.startswith(w)
        for w in ("what", "which", "how", "who", "when", "where", "list",
                  "show", "find", "give", "are", "is", "do", "does",
                  "identify", "compare", "summarize", "count")
    )
    has_question_mark = "?" in q
    if not starts_with_question_word and not has_question_mark:
        return False
    return True


def _validate_questions(questions: list[str]) -> list[str]:
    return [q for q in questions if _is_valid_question(q)]


# ---------------------------------------------------------------------------
# Per-table generation
# ---------------------------------------------------------------------------

def generate_sample_queries_for_table(
    table_name: str,
    kb_entry: dict,
    target: int = 5,
    max_attempts: int = 5,
    kb: dict | None = None,
) -> list[str]:
    """
    Generate up to `target` (default 5) realistic NL questions for a single table.

    Args:
        table_name  : Name of the table in the database.
        kb_entry    : KB entry for this table (label, domain, columns, referenced_by…).
        target      : Number of questions to aim for.
        max_attempts: Max LLM calls (accumulates unique valid questions across calls).
        kb          : Full knowledge base dict. When provided, referenced_by entries
                      are enriched with the label and description of each child table.

    Strategy:
      - Calls the LLM up to `max_attempts` times.
      - Accumulates unique valid questions across attempts (deduplication by lowercase).
      - Stops as soon as `target` questions are collected.
      - Temperature increases slightly on each attempt for more variety.
    """
    columns = kb_entry.get("columns", {})
    foreign_keys = kb_entry.get("foreign_keys", [])

    domain_raw = kb_entry.get("domain", "General") or "General"
    domain_str = (
        domain_raw[0] if isinstance(domain_raw, list) and domain_raw
        else _str(domain_raw)
    )

    prompt = _TEMPLATE.format(
        table=table_name,
        label=_str(kb_entry.get("label", table_name)).strip() or table_name,
        domain=domain_str,
        description=_str(
            kb_entry.get("description")
            or kb_entry.get("table_description")
            or kb_entry.get("label", table_name)
        ).strip(),
        primary_key=_str(kb_entry.get("primary_key", "unknown")),
        columns=_build_column_summary(columns, foreign_keys),
        referenced_by=_build_referenced_by_summary(
            kb_entry.get("referenced_by", []),
            kb=kb,
        ),
        business_rules=_build_business_rules(columns),
    )

    collected: list[str] = []
    seen: set[str] = set()

    for attempt in range(max_attempts):
        if len(collected) >= target:
            break

        temperature = 0.70 + attempt * 0.07   # 0.70 → 0.77 → 0.84 → 0.91 → 0.98
        try:
            raw = _call_llm(prompt, temperature=temperature)
            candidates = _validate_questions(raw)
            for q in candidates:
                q_key = q.lower().strip()
                if q_key not in seen and len(collected) < target:
                    collected.append(q)
                    seen.add(q_key)
        except Exception as e:
            if attempt == max_attempts - 1:
                raise
            time.sleep(1)

    return collected


# ---------------------------------------------------------------------------
# Batch generation
# ---------------------------------------------------------------------------

def _has_bad_queries(entry: dict) -> bool:
    """Return True if existing sample_queries contain SQL or technical leakage."""
    for q in entry.get("sample_queries", []):
        if _SQL_PATTERN.search(q) or _TECH_PATTERN.search(q):
            return True
    return False


def generate_all_missing_sample_queries(
    force: bool = False,
    fix_bad: bool = True,
    min_queries: int = 3,
    target_queries: int = 5,
    save_every: int = 10,
    progress_callback: Optional[callable] = None,
) -> int:
    """
    Generate sample_queries for all tables that need them.

    Args:
        force           : Regenerate all tables, including those with existing queries.
        fix_bad         : Regenerate tables whose existing queries contain SQL/tech leakage.
        min_queries     : Minimum valid questions required to consider a table updated (default 3).
        target_queries  : How many questions to aim for per table (default 5).
        save_every      : Flush KB to disk every N tables (crash-safe incremental saves).
        progress_callback: Optional fn(idx, total, table_name, success, n_queries) called
                           after each table — useful for Streamlit progress bars.

    Returns:
        Number of tables successfully updated (reached min_queries).
    """
    kb_raw = load_kb()
    kb = copy.deepcopy(kb_raw)   # never mutate the lru_cache object

    def _needs_generation(entry: dict) -> bool:
        if force:
            return True
        existing = entry.get("sample_queries", [])
        if not existing:
            return True
        if len(existing) < target_queries:
            return True
        if fix_bad and _has_bad_queries(entry):
            return True
        return False

    tables_to_process = [
        (name, entry)
        for name, entry in kb.items()
        if _needs_generation(entry)
    ]

    if not tables_to_process:
        print("✓ All tables already have valid sample queries.")
        return 0

    total = len(tables_to_process)
    updated = 0
    failed: list[str] = []

    print(f"\nGenerating sample queries for {total} / {len(kb)} tables "
          f"(target={target_queries}, min={min_queries})...\n")

    for idx, (table_name, entry) in enumerate(tables_to_process, start=1):
        success = False
        n_got = 0
        try:
            queries = generate_sample_queries_for_table(
                table_name, entry,
                target=target_queries,
                kb=kb,
            )
            n_got = len(queries)

            if n_got < min_queries:
                raise ValueError(
                    f"Only {n_got} valid questions (need ≥ {min_queries})"
                )

            kb[table_name]["sample_queries"] = queries
            updated += 1
            success = True
            print(f"[{idx:>4}/{total}] ✓  {table_name}  ({n_got}/{target_queries})")

        except Exception as exc:
            failed.append(table_name)
            print(f"[{idx:>4}/{total}] ✗  {table_name}  FAILED: {exc}")

        if progress_callback:
            try:
                progress_callback(idx, total, table_name, success, n_got)
            except Exception:
                pass

        if idx % save_every == 0:
            _flush(kb)
            print(f"         ↳ progress saved ({idx}/{total})")

    _flush(kb)
    load_kb.cache_clear()

    print(f"\n{'='*50}")
    print(f"  Updated : {updated}")
    print(f"  Failed  : {len(failed)}")
    if failed:
        print("  Failed tables:")
        for t in failed:
            print(f"    - {t}")

    return updated


def _flush(kb: dict) -> None:
    """Write the kb dict to KB_PATH (no 'tables' wrapper — matches load_kb logic)."""
    with open(KB_PATH, "w", encoding="utf-8") as fh:
        json.dump(kb, fh, indent=2, ensure_ascii=False)
