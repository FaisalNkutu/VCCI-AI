"""
KB-aware query expansion.

Takes the user question + a KB extract of the most likely tables (from a
quick preview search) and asks Mistral to generate N-1 alternative
formulations that:
  - Use actual column/table names from the schema
  - Cover different phrasings and angles
  - Bridge the gap between natural language and the SQL schema

Returns [original_question, rewrite_1, rewrite_2, ...]
"""
from __future__ import annotations

import ollama

from config.settings import get_settings
from RAG.knowledge_base__ import get_table_kb

_SYSTEM = """\
You are a schema-aware query reformulation assistant for a military database.
Your task is to rewrite a user question into alternative formulations that are
closer to the actual database schema provided.
"""

_TEMPLATE = """\
Original question: {question}

Relevant schema context (actual table/column names):
{kb_context}

Generate exactly {n} alternative reformulations of the original question.
Rules:
- Each reformulation must be a natural language question (not SQL)
- At least one reformulation should use exact column or table names from the schema
- Cover different phrasings (e.g., one general, one schema-specific)
- Stay true to the original intent

Output only the {n} questions, one per line, no numbering, no extra text.
"""


def _build_kb_context(tables_preview: list[dict]) -> str:
    """
    Build a concise KB snippet for the preview tables.
    Each entry: table_name → description + key columns with allowed values.
    """
    lines = []
    for t in tables_preview[:5]:
        tname = t.get("table_name", "")
        kb = get_table_kb(tname)
        desc = kb.get("table_description", "")
        cols = kb.get("columns", {})

        key_cols = []
        for col_name, col_data in list(cols.items())[:6]:
            allowed = col_data.get("allowed_values", [])
            col_str = col_name
            if allowed:
                col_str += f"({', '.join(allowed[:5])})"
            key_cols.append(col_str)

        lines.append(
            f"  Table `{tname}`: {desc}"
            + (f"\n    Columns: {', '.join(key_cols)}" if key_cols else "")
        )
    return "\n".join(lines)


def expand_query(
    question: str,
    preview_tables: list[dict],
    n_rewrites: int = 2,
) -> list[str]:
    """
    Returns [original_question] + n_rewrites reformulations.
    Falls back to [original_question] if the LLM call fails.
    """
    if not preview_tables or n_rewrites == 0:
        return [question]

    settings = get_settings()
    kb_context = _build_kb_context(preview_tables)

    prompt = _TEMPLATE.format(
        question=question,
        kb_context=kb_context,
        n=n_rewrites,
    )

    try:
        resp = ollama.chat(
            model=settings.ollama_render_model,
            messages=[
                {"role": "system", "content": _SYSTEM},
                {"role": "user",   "content": prompt},
            ],
            options={"temperature": 0.4, "num_predict": 256},
        )
        raw = resp["message"]["content"].strip()
        rewrites = [
            ln.strip()
            for ln in raw.splitlines()
            if ln.strip() and len(ln.strip()) > 10
        ][:n_rewrites]

        return [question] + rewrites if rewrites else [question]

    except Exception:
        return [question]
