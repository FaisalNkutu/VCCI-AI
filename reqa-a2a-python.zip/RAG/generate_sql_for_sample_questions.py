"""
Batch-generate and validate SQL for existing sample questions.

For each table in KB_full.json whose sample_queries are still plain
strings (no validated SQL — typically produced by
RAG/sample_query_generator.py), this script:

  1. Builds the same schema_context the live pipeline would use for that
     question (via SchemaRAG.retrieve + build_schema_context).
  2. Generates SQL via the existing SQLGenerator (no changes to its logic
     or prompts — this script is a consumer, not a modification).
  3. Validates the SQL with the same static checker + EXPLAIN dry-run used
     in production (never executes against real data — read-only safety
     net, consistent with the live pipeline's guarantees).
  4. On success, upgrades that question's KB_full.json entry from a plain
     string to a {"question", "sql"} dict — which then becomes usable as
     a genuine few-shot example (see knowledge_base.get_sample_queries).
  5. On failure, leaves the entry untouched (still usable for embedding
     via get_sample_questions, just not promoted to a few-shot example)
     and logs it for manual review — a SQL-generation failure here is
     itself a useful signal that a table's schema/KB documentation needs
     improvement (e.g. a missing FK in referenced_by).

This is a one-shot offline maintenance script — run it after
RAG/sample_query_generator.py, or any time the schema/KB changes
significantly. Persists incrementally so partial runs are safe to re-run.

Usage:
    python -m RAG.generate_sql_for_sample_questions
    python -m RAG.generate_sql_for_sample_questions --tables act action_group act_task
    python -m RAG.generate_sql_for_sample_questions --max-questions-per-table 3
"""
from __future__ import annotations

import argparse
import copy
import json
import logging
import time
from typing import Optional

from qdrant_client import QdrantClient

from config.settings import get_settings
from agent.embedder import Embedder
from agent.schema_rag import SchemaRAG
from agent.sql_generator import SQLGenerator
from agent.llm.base import BaseLLM
from RAG.knowledge_base import KB_PATH, load_kb, get_sample_questions

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("SAMPLE SQL GENERATOR")


# ---------------------------------------------------------------------------
# Wiring — reuses the exact same components the live API uses, so the SQL
# generated here is representative of what the running pipeline would
# actually produce for these questions.
# ---------------------------------------------------------------------------

def _build_components():
    settings = get_settings()

    qdrant = QdrantClient(host=settings.QDRANT_HOST, port=settings.QDRANT_PORT)
    embedder = Embedder()

    schema_rag = SchemaRAG(
        qdrant,
        embedder,
        settings.qdrant_collection,
        settings.top_k_tables,
    )

    # Import lazily to avoid a hard dependency if the project structure
    # differs slightly — adjust the import path below if your LLM client
    # is constructed differently in api.py.
    from agent.llm.codestral_client import CodestralClient

    llm: BaseLLM = CodestralClient()
    sql_generator = SQLGenerator(llm)

    # Static checker / dry runner: reuse the same ones api.py wires up.
    # Imported lazily and defensively — if these modules don't exist under
    # these exact names in your project, adjust the two imports below.
    try:
        from agent.static_checker import StaticChecker
        static_checker = StaticChecker()
    except ImportError:
        static_checker = None
        logger.warning(
            "StaticChecker not found — SQL will only be checked for "
            "SELECT-only validity inside SQLGenerator, not full sqlglot "
            "static analysis."
        )

    try:
        from agent.dry_runner import DryRunner
        dry_runner = DryRunner()
    except ImportError:
        dry_runner = None
        logger.warning(
            "DryRunner not found — generated SQL will NOT be validated "
            "against MariaDB EXPLAIN. Validation will rely on syntax "
            "checks only, which is weaker."
        )

    return schema_rag, sql_generator, static_checker, dry_runner


# ---------------------------------------------------------------------------
# Per-question SQL generation + validation
# ---------------------------------------------------------------------------

def generate_and_validate_sql(
    question: str,
    schema_rag: SchemaRAG,
    sql_generator: SQLGenerator,
    static_checker,
    dry_runner,
    max_attempts: int = 2,
) -> Optional[str]:
    """
    Generate SQL for a single question and validate it the same way the
    live pipeline would (static check + EXPLAIN dry-run, never executed
    against real data). Returns the validated SQL string, or None if
    validation failed after max_attempts.
    """

    try:
        schema_chunks = schema_rag.retrieve(question)
        schema_context = schema_rag.build_schema_context(schema_chunks)
        all_tables = schema_rag.all_table_names()
    except Exception as exc:
        logger.warning(f"  retrieval failed: {exc}")
        return None

    logger.info("===================================== CONTEXT ==========================================================")
    logger.info(f"{schema_context}")
    logger.info("========================================================================================================")

    error_feedback = ""

    for attempt in range(1, max_attempts + 1):
        try:
            sql = sql_generator.generate(
                question, schema_context, all_tables, error_feedback
            )
        except Exception as exc:
            logger.warning(f"  [attempt {attempt}] generation failed: {exc}")
            error_feedback = f"LLM error: {exc}"
            continue

        if sql.upper().startswith("IMPOSSIBLE:"):
            logger.info(f"  [attempt {attempt}] declared IMPOSSIBLE: {sql[11:].strip()}")
            return None

        if static_checker is not None:
            valid, static_err = static_checker.check(sql)
            if not valid:
                logger.info(f"  [attempt {attempt}] static check failed: {static_err}")
                error_feedback = f"Syntax/policy error: {static_err}"
                continue

        if dry_runner is not None:
            plan_ok, plan_err = dry_runner.explain(sql)
            if not plan_ok:
                logger.info(f"  [attempt {attempt}] EXPLAIN failed: {plan_err}")
                error_feedback = f"EXPLAIN failed: {plan_err}"
                continue

        # Passed every available validation layer.
        return sql

    return None


# ---------------------------------------------------------------------------
# Batch driver
# ---------------------------------------------------------------------------

def _flush(kb: dict) -> None:
    with open(KB_PATH, "w", encoding="utf-8") as fh:
        json.dump(kb, fh, indent=2, ensure_ascii=False)


def generate_sql_for_all_sample_questions(
    tables: Optional[list[str]] = None,
    max_questions_per_table: int = 5,
    save_every: int = 5,
) -> dict:
    """
    Walk every table in KB_full.json (or only `tables` if given), find
    sample_queries entries that are still plain strings, generate +
    validate SQL for each, and upgrade successful ones to
    {"question", "sql"} dicts in place.

    Returns a summary dict: {"validated": int, "skipped": int, "failed": int}.
    """

    schema_rag, sql_generator, static_checker, dry_runner = _build_components()

    kb_raw = load_kb()
    kb = copy.deepcopy(kb_raw)

    table_names = tables if tables else list(kb.keys())

    summary = {"validated": 0, "skipped": 0, "failed": 0}
    processed_tables = 0

    for table_name in table_names:
        entry = kb.get(table_name)
        if entry is None:
            logger.warning(f"Table {table_name!r} not found in KB — skipping.")
            continue

        raw_queries = entry.get("sample_queries", [])
        updated_queries: list = []
        n_processed_this_table = 0

        for item in raw_queries:
            already_dict = isinstance(item, dict) and item.get("sql")

            if already_dict:
                updated_queries.append(item)
                continue

            question = item if isinstance(item, str) else item.get("question", "")
            if not question.strip():
                continue

            if n_processed_this_table >= max_questions_per_table:
                # Leave remaining plain-string questions untouched this run.
                updated_queries.append(item)
                continue

            logger.info(f"[{table_name}] generating SQL for: {question!r}")

            sql = generate_and_validate_sql(
                question, schema_rag, sql_generator, static_checker, dry_runner
            )

            n_processed_this_table += 1

            if sql:
                updated_queries.append({"question": question, "sql": sql})
                summary["validated"] += 1
                logger.info(f"  ✓ validated: {sql}")
            else:
                # Keep the plain-string question as-is — still useful for
                # embedding, just not promoted to a few-shot example.
                updated_queries.append(question)
                summary["failed"] += 1
                logger.info(f"  ✗ could not validate SQL for this question")

        kb[table_name]["sample_queries"] = updated_queries
        processed_tables += 1

        if processed_tables % save_every == 0:
            _flush(kb)
            logger.info(f"  ↳ progress saved ({processed_tables}/{len(table_names)} tables)")

    _flush(kb)
    load_kb.cache_clear()

    logger.info(
        f"\n{'='*50}\n"
        f"  Validated : {summary['validated']}\n"
        f"  Failed    : {summary['failed']}\n"
        f"  Skipped   : {summary['skipped']}\n"
    )

    return summary


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description=(
            "Generate and validate SQL for existing plain-string sample "
            "questions in KB_full.json, upgrading them to {question, sql} "
            "few-shot examples when validation succeeds."
        )
    )
    parser.add_argument(
        "--tables",
        nargs="*",
        default=None,
        help="Limit to specific table names (default: all tables in KB_full.json).",
    )
    parser.add_argument(
        "--max-questions-per-table",
        type=int,
        default=5,
        help="Max questions to process per table in this run (default: 5).",
    )
    parser.add_argument(
        "--save-every",
        type=int,
        default=5,
        help="Flush KB to disk every N tables processed (default: 5).",
    )
    args = parser.parse_args()

    generate_sql_for_all_sample_questions(
        tables=args.tables,
        max_questions_per_table=args.max_questions_per_table,
        save_every=args.save_every,
    )


if __name__ == "__main__":
    main()