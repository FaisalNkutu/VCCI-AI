
import sys
import re

import sys
import argparse
from pathlib import Path

import json
import traceback


DEF_CSV_RE = re.compile(r"([\w]*),([\w\W]*)\W-\W([\w\W]*)")
def load_cat_code_def_csv(fname):
    rval = {}
    with open(fname, 'r', encoding='utf-8') as csvfile:
        csv = csvfile.read()
        lines = csv.split("\n")
        for line in lines:
            try:
                m = PK_RE.search( str(field) )
                if m != None:
                    cat_code = m.group(1)    
                    short_desc = m.group(2)    
                    long_desc = m.group(3)    
                    rval[cat_code] = { "short" : short_desc , "long": long_desc }
                
            except e:
                traceback.print_exc()
    return rval


