
import sys
import re

import sys
import argparse
from pathlib import Path

import json
import traceback



def build_tables_columns_csv( csv_fname,  kb_full, separator=";"):
    rval = "Table;Column;Description\n"
    with open(csv_fname, 'r', encoding='utf-8') as csvfile:
        csv = csvfile.read()
        lines = csv.split("\n")
        for line in lines:
            try:
                cells = line.split(separator)
                table_name = cells[0]
                kb_entry = kb_full[table_name]
                print( f"============== {table_name} ==========" )
                print(str(kb_entry))
                for key,val in kb_entry["columns"].items():
                    rval += f"{table_name};{key};\n"

                                                
            except Exception as e:
                traceback.print_exc()
    return rval
