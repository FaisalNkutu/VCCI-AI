"""
Generates real, natural-language synonym keywords for every table in the
schema, using a local Ollama LLM (default: mistral:7b, NATO-country origin)
grounded in BOTH:
  1. The full context of the individual table (label, description, columns,
     and its real relationships to other tables)
  2. The full context of the whole database (database_context.json)

Unlike a mechanical name-splitting approach, this asks the model to think
like an end user: what everyday words would someone type instead of the
table's technical name? For example, for "act" (Activity), a good user might
also say "mission", "operation", or "task" — words that never appear in the
table name or its columns at all, but are true domain synonyms.

Requires Ollama running locally with the target model pulled:
    ollama pull mistral:7b

Usage:
    python generate_table_keywords_llm.py \\
        --relationships all_relationships.json \\
        --columns columns_detail.json \\
        --descriptions table_descriptions.json \\
        --db-context database_context.json \\
        -o table_keywords.json

    # quick test on a few tables first
    python generate_table_keywords_llm.py ... -o test.json --tables act,bio_mat_type,porter_route
"""

import json
import argparse
import time
from pathlib import Path
from urllib import request as urllib_request
from urllib.error import URLError

OLLAMA_URL = "http://ollama:11434/api/generate"


def load_json(path: Path) -> dict:
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def build_table_context(table: str, relationships: list[dict], columns: dict,
                         description_entry: dict) -> str:
    label = description_entry.get("label", table)
    description = description_entry.get("description", "")

    col_names = list(columns.keys())[:12]

    parent_of = sorted({r["related_table"] for r in relationships if r.get("role") == "parent_of"})
    child_of = sorted({r["related_table"] for r in relationships if r.get("role") == "child_of"})

    rel_lines = []
    if parent_of:
        rel_lines.append(f"  - Is referenced by (parent of): {', '.join(parent_of)}")
    if child_of:
        rel_lines.append(f"  - References (child of): {', '.join(child_of)}")
    if not rel_lines:
        rel_lines.append("  - No foreign key relationships detected (standalone table).")

    return (
        f"Table name: {table}\n"
        f"Label: {label}\n"
        f"Description: {description or '(no description available)'}\n"
        f"Columns: {', '.join(col_names) if col_names else '(none found)'}\n"
        f"Relationships:\n" + "\n".join(rel_lines)
    )


def build_prompt(db_context: dict, table_context: str, table: str, label: str) -> str:
    return f"""You are helping build a search/retrieval system for a database. Your job is to think like an ORDINARY END USER (not a database expert) who wants information from this table but does NOT know its exact technical name or column names.

=== DATABASE-WIDE CONTEXT ===
{db_context['database_overview']}

=== TABLE TO GENERATE SYNONYMS FOR ===
{table_context}

=== INSTRUCTIONS ===
- Generate 4 to 8 keywords/synonyms an ordinary user might type or say when they actually mean this table, even if those words never appear in the table's name, label, or columns.
- Think of real everyday or domain-standard synonyms (e.g. for a table about a top-level military activity, a user might say "mission", "operation", or "task" even though none of those words are in the table name).
- Always include the table's own name ("{table}") and its label ("{label}") as two of the keywords, in addition to the true synonyms.
- Keywords should be short (1-2 words), lowercase, and genuinely different phrasings a person could realistically use — not just the column names spelled out.
- Do NOT include generic words that would apply to almost any table (e.g. "id", "record", "data", "information", "type" alone).
- Return ONLY a JSON array of lowercase strings, nothing else. Example: ["activity", "mission", "operation", "task", "action", "act"]
"""


def call_ollama(model: str, prompt: str, timeout: int = 90) -> str:
    payload = json.dumps({
        "model": model,
        "prompt": prompt,
        "stream": False,
        "options": {"temperature": 0.4},
    }).encode("utf-8")
    req = urllib_request.Request(
        OLLAMA_URL, data=payload, headers={"Content-Type": "application/json"}
    )
    with urllib_request.urlopen(req, timeout=timeout) as resp:
        body = json.loads(resp.read().decode("utf-8"))
    return body.get("response", "").strip()


def parse_keyword_list(raw_response: str) -> list[str]:
    text = raw_response.strip()
    if "```" in text:
        text = text.split("```")[1] if text.count("```") >= 2 else text
        text = text.replace("json", "", 1).strip()
    start = text.find("[")
    end = text.rfind("]")
    if start == -1 or end == -1:
        return []
    try:
        parsed = json.loads(text[start:end + 1])
        if isinstance(parsed, list):
            seen = set()
            result = []
            for x in parsed:
                w = str(x).strip().lower()
                if w and w not in seen:
                    seen.add(w)
                    result.append(w)
            return result
    except json.JSONDecodeError:
        pass
    return []


def generate_keywords(all_relationships: dict, all_columns: dict, all_descriptions: dict,
                       db_context: dict, model: str, tables_filter: list[str] | None,
                       retries: int) -> dict:
    all_known_tables = sorted(set(all_relationships.keys()) | set(all_columns.keys()))
    tables = tables_filter if tables_filter else all_known_tables

    result = {}
    for i, table in enumerate(tables, 1):
        relationships = all_relationships.get(table, [])
        columns = all_columns.get(table, {})
        description_entry = all_descriptions.get(table, {})
        label = description_entry.get("label", table)

        table_context = build_table_context(table, relationships, columns, description_entry)
        prompt = build_prompt(db_context, table_context, table, label)

        keywords = []
        for attempt in range(1, retries + 1):
            try:
                raw = call_ollama(model, prompt)
                keywords = parse_keyword_list(raw)
                if keywords:
                    break
            except (URLError, TimeoutError) as e:
                print(f"  [retry {attempt}/{retries}] {table}: {e}")
                time.sleep(1.5)

        if not keywords:
            print(f"  [warning] {table}: could not obtain keywords, using fallback")
            keywords = [table.replace("_", " "), label.lower()]

        result[table] = keywords
        print(f"[{i}/{len(tables)}] {table} -> {keywords}")

    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--relationships", type=Path, default=Path("all_relationships.json"))
    parser.add_argument("--columns", type=Path, default=Path("columns_detail.json"))
    parser.add_argument("--descriptions", type=Path, default=Path("table_descriptions.json"))
    parser.add_argument("--db-context", type=Path, default=Path("database_context.json"))
    parser.add_argument("--model", type=str, default="mistral:7b")
    parser.add_argument("-o", "--output", type=Path, default=Path("table_keywords.json"))
    parser.add_argument("--tables", type=str, default=None,
                         help="Comma-separated list of tables to process (default: all)")
    parser.add_argument("--retries", type=int, default=3)
    args = parser.parse_args()

    all_relationships = load_json(args.relationships)
    all_columns = load_json(args.columns)
    all_descriptions = load_json(args.descriptions)
    db_context = load_json(args.db_context)

    tables_filter = [t.strip() for t in args.tables.split(",")] if args.tables else None

    print(f"Generating synonym keywords using Ollama model '{args.model}'...")
    print(f"Make sure Ollama is running and the model is pulled: ollama pull {args.model}\n")

    result = generate_keywords(
        all_relationships, all_columns, all_descriptions, db_context,
        args.model, tables_filter, args.retries
    )

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    print(f"\nFile written: {args.output}")


if __name__ == "__main__":
    main()
