
#KB_FULL_path = "RAG\\KB_full.json"

blue_tables_relationships = {
  "act": [
    {
      "role": "parent_of",
      "name": "act_action_group",
      "type": "Non Identifying",
      "related_table": "action_group",
      "cardinality": "One Or More"
    },
    {
      "role": "parent_of",
      "name": "act_action_group_2",
      "type": "Non Identifying",
      "related_table": "action_group",
      "cardinality": "One Or More"
    },
    {
      "role": "parent_of",
      "name": "act_act_event",
      "type": "Identifying",
      "related_table": "act_event",
      "cardinality": "Exactly One"
    },
    {
      "role": "parent_of",
      "name": "act_act_loc_assoc",
      "type": "Non Identifying",
      "related_table": "act_loc_assoc",
      "cardinality": "Zero Or More"
    },
    {
      "role": "parent_of",
      "name": "act_act_oi_assoc",
      "type": "Non Identifying",
      "related_table": "act_oi_assoc",
      "cardinality": "Zero Or More"
    },
    {
      "role": "parent_of",
      "name": "act_act_ot_assoc",
      "type": "Non Identifying",
      "related_table": "act_ot_assoc",
      "cardinality": "Zero Or More"
    },
    {
      "role": "parent_of",
      "name": "act_act_stat",
      "type": "Identifying",
      "related_table": "act_stat",
      "cardinality": "One Or More"
    },
    {
      "role": "parent_of",
      "name": "act_act_task",
      "type": "Identifying",
      "related_table": "act_task",
      "cardinality": "Exactly One"
    },
    {
      "role": "parent_of",
      "name": "act_contxt_act_assoc",
      "type": "Identifying",
      "related_table": "contxt_act_assoc",
      "cardinality": "Exactly One"
    },
    {
      "role": "parent_of",
      "name": "act_simulator_task",
      "type": "Identifying",
      "related_table": "simulator_task",
      "cardinality": "Exactly One"
    }
  ],
  "act_stat": [
    {
      "role": "child_of",
      "name": "act_act_stat",
      "type": "Identifying",
      "related_table": "act",
      "cardinality": "One Or More"
    }
  ],
  "action_group": [
    {
      "role": "child_of",
      "name": "act_action_group",
      "type": "Non Identifying",
      "related_table": "act",
      "cardinality": "One Or More"
    },
    {
      "role": "child_of",
      "name": "act_action_group_2",
      "type": "Non Identifying",
      "related_table": "act",
      "cardinality": "One Or More"
    }
  ],
  "act_event": [
    {
      "role": "child_of",
      "name": "act_act_event",
      "type": "Identifying",
      "related_table": "act",
      "cardinality": "Exactly One"
    },
    {
      "role": "parent_of",
      "name": "act_event_comms_event",
      "type": "Identifying",
      "related_table": "comms_event",
      "cardinality": "Exactly One"
    },
    {
      "role": "parent_of",
      "name": "act_event_fire_event",
      "type": "Identifying",
      "related_table": "fire_event",
      "cardinality": "Exactly One"
    },
    {
      "role": "parent_of",
      "name": "act_event_simulator_task_event",
      "type": "Identifying",
      "related_table": "simulator_task_event",
      "cardinality": "Exactly One"
    }
  ],
  "act_task": [
    {
      "role": "child_of",
      "name": "act_act_task",
      "type": "Identifying",
      "related_table": "act",
      "cardinality": "Exactly One"
    },
    {
      "role": "parent_of",
      "name": "act_task_move_act_task",
      "type": "Identifying",
      "related_table": "move_act_task",
      "cardinality": "Exactly One"
    }
  ],
  "move_act_task": [
    {
      "role": "child_of",
      "name": "act_task_move_act_task",
      "type": "Identifying",
      "related_table": "act_task",
      "cardinality": "Exactly One"
    }
  ],
  "simulator_task": [
    {
      "role": "child_of",
      "name": "act_simulator_task",
      "type": "Identifying",
      "related_table": "act",
      "cardinality": "Exactly One"
    },
    {
      "role": "child_of",
      "name": "callsign_simulator_task",
      "type": "Non Identifying",
      "related_table": "callsign",
      "cardinality": "Zero Or More"
    },
    {
      "role": "child_of",
      "name": "scenario_simulator_task",
      "type": "Non Identifying",
      "related_table": "scenario",
      "cardinality": "Zero Or More"
    },
    {
      "role": "parent_of",
      "name": "simulator_task_simulator_task_trigger",
      "type": "Non Identifying",
      "related_table": "simulator_task_trigger",
      "cardinality": "Zero Or More"
    }
  ],
  "simulator_task_trigger": [
    {
      "role": "child_of",
      "name": "simulator_task_simulator_task_trigger",
      "type": "Non Identifying",
      "related_table": "simulator_task",
      "cardinality": "Zero Or More"
    }
  ],
  "simulator_task_event": [
    {
      "role": "child_of",
      "name": "act_event_simulator_task_event",
      "type": "Identifying",
      "related_table": "act_event",
      "cardinality": "Exactly One"
    }
  ],
  "comms_event": [
    {
      "role": "child_of",
      "name": "act_event_comms_event",
      "type": "Identifying",
      "related_table": "act_event",
      "cardinality": "Exactly One"
    },
    {
      "role": "child_of",
      "name": "callsign_comms_event",
      "type": "Non Identifying",
      "related_table": "callsign",
      "cardinality": "Zero Or One"
    },
    {
      "role": "parent_of",
      "name": "comms_event_comms_event_msg_type_assoc",
      "type": "Identifying",
      "related_table": "comms_event_msg_type_assoc",
      "cardinality": "Exactly One"
    },
    {
      "role": "parent_of",
      "name": "comms_event_rx_event",
      "type": "Identifying",
      "related_table": "rx_event",
      "cardinality": "Exactly One"
    },
    {
      "role": "parent_of",
      "name": "comms_event_tx_event",
      "type": "Identifying",
      "related_table": "tx_event",
      "cardinality": "Exactly One"
    }
  ],
  "comms_event_msg_type_assoc": [
    {
      "role": "child_of",
      "name": "comms_event_comms_event_msg_type_assoc",
      "type": "Identifying",
      "related_table": "comms_event",
      "cardinality": "Exactly One"
    },
    {
      "role": "child_of",
      "name": "msg_type_comms_event_msg_type_assoc",
      "type": "Identifying",
      "related_table": "msg_type",
      "cardinality": "Exactly One"
    }
  ],
  "tx_event": [
    {
      "role": "child_of",
      "name": "blob_obj_tx_event",
      "type": "Non Identifying",
      "related_table": "blob_obj",
      "cardinality": "Exactly One"
    },
    {
      "role": "child_of",
      "name": "comms_event_tx_event",
      "type": "Identifying",
      "related_table": "comms_event",
      "cardinality": "Exactly One"
    },
    {
      "role": "parent_of",
      "name": "tx_event_rx_event",
      "type": "Non Identifying",
      "related_table": "rx_event",
      "cardinality": "Exactly One"
    }
  ],
  "rx_event": [
    {
      "role": "child_of",
      "name": "comms_event_rx_event",
      "type": "Identifying",
      "related_table": "comms_event",
      "cardinality": "Exactly One"
    },
    {
      "role": "child_of",
      "name": "tx_event_rx_event",
      "type": "Non Identifying",
      "related_table": "tx_event",
      "cardinality": "Exactly One"
    }
  ],
  "fire_event": [
    {
      "role": "child_of",
      "name": "act_event_fire_event",
      "type": "Identifying",
      "related_table": "act_event",
      "cardinality": "Exactly One"
    }
  ],
  "msg_type": [
    {
      "role": "parent_of",
      "name": "msg_type_comms_event_msg_type_assoc",
      "type": "Identifying",
      "related_table": "comms_event_msg_type_assoc",
      "cardinality": "Exactly One"
    }
  ]
}


#print(blue_tables_relationships)

import json
from pathlib import Path

KB_FULL_path = r"RAG\KB_full.json"

def load_json(path: str) -> dict:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Fichier introuvable : {path.resolve()}")
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        raise ValueError(f"JSON invalide dans {path} : {e}")

kb_full = load_json(KB_FULL_path)
#print(f"{len(kb_full)} entrées chargées depuis {KB_FULL_path}")

firt_3 = dict(list(kb_full.items())[1:3])
print(firt_3)