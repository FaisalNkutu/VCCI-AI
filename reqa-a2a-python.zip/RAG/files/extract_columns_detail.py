"""
Extrait uniquement le type de données (data_type) de chaque colonne de chaque
table depuis attrd.html (rapport DeZign for Databases - "Attribute details").

Format de sortie:
{
  "act": {
    "act_id": "INTEGER",
    "cat_code": "ENUM",
    "name_txt": "VARCHAR",
    ...
  },
  "act_stat": {
    "act_id": "INTEGER",
    ...
  },
  ...
}

Usage:
    python extract_columns_detail.py <attrd.html> [-o output.json]
"""

import re
import json
import argparse
from pathlib import Path


BLOCK_PATTERN = re.compile(
    r'<A NAME=".*?"></A>\s*'
    r'<div class="objectname">Attribute: (.*?)</div>.*?'
    r'Entity name</td><td class="fielddata"><A HREF="entd\.html#(.*?)">.*?</A></td></tr>\s*'
    r'<tr><td class="fieldname">Description</td><td class="fielddata">.*?</td></tr>\s*'
    r'<tr><td class="fieldname">Primary key</td><td class="fielddata">.*?</td></tr>\s*'
    r'<tr><td class="fieldname">Refers to</td><td class="fielddata">.*?</td></tr>\s*'
    r'<tr><td class="fieldname">Data type</td><td class="fielddata">(.*?)</td></tr>',
    re.DOTALL
)


def extract_raw_columns(html_content: str) -> list[tuple]:
    """
    Retourne une liste de tuples: (col_name, table_name, data_type)
    Déduplique en conservant l'ordre.
    """
    matches = BLOCK_PATTERN.findall(html_content)
    unique = list(dict.fromkeys(matches))
    return unique


def build_columns_dict(unique_cols: list[tuple]) -> dict:
    """
    Transforme la liste de tuples en dictionnaire imbriqué {table: {colonne: data_type}}.
    """
    columns: dict[str, dict[str, str]] = {}

    for col_name, table_name, data_type in unique_cols:
        columns.setdefault(table_name, {})
        columns[table_name][col_name] = data_type.strip()

    return columns


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("html_path", type=Path, help="Chemin vers attrd.html")
    parser.add_argument("-o", "--output", type=Path, default=Path("columns_detail.json"),
                         help="Fichier de sortie JSON (défaut: columns_detail.json)")
    args = parser.parse_args()

    html_content = args.html_path.read_text(encoding="utf-8", errors="ignore")

    unique_cols = extract_raw_columns(html_content)
    columns = build_columns_dict(unique_cols)

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(columns, f, indent=2, ensure_ascii=False)

    total_cols = sum(len(v) for v in columns.values())
    print(f"{len(unique_cols)} entrées colonne uniques trouvées.")
    print(f"{len(columns)} tables référencées.")
    print(f"{total_cols} colonnes au total.")
    print(f"Fichier écrit : {args.output}")


if __name__ == "__main__":
    main()
