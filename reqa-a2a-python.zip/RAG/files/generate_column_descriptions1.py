"""
Generates a short, natural-language description for every column of every
table in the schema, based on common naming patterns (id/ix suffixes,
cat_code/subcat_code, name_txt, descr_txt, time/date columns, lat/lon/alt,
duration, etc.) combined with the table's own label for context.

This is a template-based, deterministic generator — not an LLM call — so it
is fast, free, and 100% reproducible, but the results are necessarily more
generic than a hand-written description like the ones already crafted for
the "act" table. Treat this as a solid first draft to review, not a final
authoritative source.

Usage:
    python generate_column_descriptions.py <columns_detail.json> <table_descriptions.json> [-o column_descriptions.json]
"""

import json
import argparse
from pathlib import Path

# Reused/extended from the table-description and keyword generators, for
# consistent expansion of domain abbreviations inside descriptions.
WORD_MAP = {
    "rep": "reported", "qty": "quantity", "cnt": "count", "rat": "ratio",
    "dim": "size", "amt": "amount", "wt": "weight", "num": "number",
    "val": "value", "req": "required", "prio": "priority", "descr": "description",
    "det": "detail", "actv": "active", "compl": "completion", "qual": "qualifier",
    "hand": "hand", "ext": "external", "ref": "reference", "incl": "inclination",
    "brng": "bearing", "acc": "accuracy", "org": "organization", "loc": "location",
    "alt": "altitude", "lat": "latitude", "lon": "longitude", "cat": "category",
    "txt": "text", "on": "on", "operat": "operational", "seq": "sequence",
    "ord": "order", "sim": "simulation", "offset": "offset", "effctv": "effective",
    "start": "start", "end": "end", "target": "target", "firing": "firing",
    "subcat": "subcategory", "fac": "facility", "obj": "object", "item": "item",
    "type": "type", "assoc": "association", "dst": "destination", "src": "source",
    "ind": "indicator", "min": "minimum", "max": "maximum", "curr": "current",
    "prev": "previous", "def": "default", "eqpt": "equipment", "mat": "material",
    "pers": "person", "msg": "message", "netwrk": "network", "contxt": "context",
    "stat": "status", "capab": "capability", "mrt": "mrt", "hrbr": "harbor",
    "geo": "geographic", "geom": "geometric", "feat": "feature", "unit": "unit",
    "spec": "specification", "grp": "group", "cntnt": "content", "hdr": "header",
    "cmpnt": "component", "poc": "point of contact", "pln": "plan", "ordr": "order",
    "distr": "distribution", "ack": "acknowledgement",
    "oi": "object/installation", "ot": "object type", "hndl": "handling",
    "mnt": "maintenance", "mob": "mobility", "surv": "surveillance",
    "trnsm": "transmission", "supp": "support", "cfeat": "control feature",
    "gfeat": "geographic feature", "hhour": "h-hour", "lvcts": "lvc training system",
    "cbrn": "chemical, biological, radiological, nuclear", "radact": "radioactive", "chm": "chemical", "bio": "biological",
    "subsurf": "subsurface", "surf": "surface", "misc": "miscellaneous",
    "plyrc": "polyarc",
    # additional abbreviation expansions identified by full-schema token audit
    "addtnl": "additional", "appid": "application id", "appr": "approach",
    "arsp": "airspeed", "atc": "air traffic control", "auth": "authorized",
    "avg": "average", "avlbty": "availability", "avtn": "aviation",
    "bcast": "broadcast", "biolg": "biological", "bndg": "boundary",
    "bw": "bandwidth", "calc": "calculation", "chnl": "channel",
    "civ": "civilian", "clmb": "climb", "clsfc": "classification",
    "cmd": "command", "cmps": "compass", "cmtmnt": "commitment",
    "comm": "communication", "comms": "communications", "cond": "condition",
    "cons": "consumable", "const": "constant", "conv": "conversion",
    "coord": "coordinate", "cp": "control point", "cpower": "combat power",
    "crypto": "cryptographic", "ctrl": "control", "cvrg": "coverage",
    "dcl": "declassification", "desc": "description", "dev": "device",
    "dfng": "defining", "diam": "diameter", "dir": "direction",
    "displ": "display", "dist": "distance", "dmltn": "demolition",
    "dscpt": "descriptor", "dttm": "date/time", "dur": "duration",
    "dvlpm": "development", "echln": "echelon", "eff": "effective",
    "elmt": "element", "en": "enemy", "entr": "entry", "env": "environment",
    "err": "error", "est": "estimate", "estab": "establish",
    "estabd": "established", "eta": "estimated time of arrival",
    "ew": "electronic warfare", "exec": "execute", "exer": "exercise",
    "expl": "explosive", "fov": "field of view", "frat": "fratricide",
    "freq": "frequency", "fsm": "finite state machine", "func": "function",
    "gen": "general", "geoid": "geoid", "geopt": "geo point", "hh": "hour",
    "hngr": "hangar", "id1": "identifier 1", "id2": "identifier 2",
    "ident": "identifier", "iff": "identification friend or foe",
    "ils": "instrument landing system", "imo": "international maritime organization",
    "instr": "instruction", "intl": "international", "invstg": "investigation",
    "kms": "kilometers", "lash": "lashing", "lndg": "landing", "lrf": "laser range finder",
    "lvl": "level", "magn": "magnitude", "malf": "malfunction",
    "matrl": "materiel", "mcapab": "mission capability", "mcast": "multicast",
    "mdltn": "modulation", "met": "meteorological", "mil": "military",
    "mnm": "minimum", "mntnd": "maintained", "mrshl": "marshalling",
    "msn": "mission", "mthd": "method", "no": "number", "nuc": "nuclear",
    "nvgtn": "navigation", "obs": "observation", "ocptn": "occupation",
    "op": "operation", "orgn": "origin", "orient": "orientation",
    "perf": "performance", "physcl": "physical", "plcmnt": "placement",
    "poe": "point of entry", "posn": "position", "prim": "primary",
    "prob": "probability", "prog": "program", "proute": "porter route",
    "prs": "person", "prsnc": "presence", "psgr": "passenger", "pt": "point",
    "rad": "radius", "rcv": "receive", "rdns": "readiness",
    "recirc": "recirculation", "recv": "receive", "refl": "reflection",
    "regexp": "regular expression", "reqmnt": "requirement",
    "restr": "restriction", "rgstrd": "registered", "rom": "read-only",
    "rptbl": "reportable", "rptd": "reported", "rsdnc": "residence",
    "rt": "route", "scnd": "second", "sctr": "sector", "sev": "severity",
    "sgmnt": "segment", "siteid": "site id", "spc": "space",
    "specif": "specification", "spu": "signal processing unit", "std": "standard",
    "str": "structure", "suppl": "supplementary", "sys": "system",
    "temp": "temperature", "thrt": "threat", "tmpr": "temperature",
    "tmst": "timestamp", "trn": "turn", "trns": "transmission",
    "trnsp": "transport", "trnst": "transit", "utt": "utterance",
    "vals": "values", "veg": "vegetation", "wtrln": "waterline",
    "abbrev": "abbreviation",
    # compound tokens with no underscore separator, mapped as whole units
    "exerciseid": "exercise id", "arealabel": "area label",
    "ipaddress": "ip address", "pdutypeid": "pdu type id",
    "firstpoint": "first point", "secondpoint": "second point",
}


def humanize_token(tok: str) -> str:
    return WORD_MAP.get(tok.lower(), tok.lower())


def humanize_prefix(col_no_suffix: str) -> str:
    """Turn e.g. 'proute_src_endpoint' into 'proute source endpoint'."""
    tokens = col_no_suffix.split("_")
    return " ".join(humanize_token(t) for t in tokens if t)


def describe_column(table: str, col: str, data_type: str, label: str) -> str:
    lower = col.lower()

    # 1. own primary key (table_id / table_ix / table_idx), tolerant to
    # column names that glue the table name together without underscores
    # (e.g. table "pdutypes_filter" -> column "pdutypesfilter_idx")
    col_clean = lower.replace("_", "")
    table_clean = table.replace("_", "")
    if lower in (f"{table}_id", f"{table}_ix") or col_clean in (
        f"{table_clean}id", f"{table_clean}ix", f"{table_clean}idx"
    ):
        return f"Unique identifier for the {label} record."

    # 2. common category/status code columns
    if lower == "cat_code":
        return f"Category code classifying the {label}."
    if lower == "subcat_code":
        return f"Subcategory code further classifying the {label}."
    if lower in ("name_txt", "name"):
        return f"Name of the {label}."
    if lower in ("descr_txt", "description"):
        return f"Free-text description of the {label}."
    if lower == "time":
        return f"Reference or creation timestamp of the {label}."
    if lower == "sim_offset_time":
        return "Simulation time offset relative to scenario start, in seconds."
    if lower == "duration":
        return f"Duration of the {label}, typically in seconds."
    if lower in ("start_time", "start_dttm"):
        return f"Start time of the {label}."
    if lower in ("end_time", "end_dttm"):
        return f"End time of the {label}."

    # 3. geospatial
    if "lat" in lower and "lon" not in lower:
        prefix = humanize_prefix(lower.replace("_lat", "").replace("lat", ""))
        return f"{prefix.capitalize()} latitude coordinate." if prefix else "Latitude coordinate."
    if "lon" in lower:
        prefix = humanize_prefix(lower.replace("_lon", "").replace("lon", ""))
        return f"{prefix.capitalize()} longitude coordinate." if prefix else "Longitude coordinate."
    if "alt" in lower and "altern" not in lower:
        prefix = humanize_prefix(lower.replace("_alt", "").replace("alt", ""))
        return f"{prefix.capitalize()} altitude value." if prefix else "Altitude value."

    # 4. generic identifier / index columns (foreign keys or own PK variants)
    if lower.endswith("_id"):
        prefix = humanize_prefix(lower[:-3])
        return f"{prefix.capitalize()} identifier." if prefix else "Identifier."
    if lower.endswith("_ix") or lower.endswith("_idx"):
        suffix_len = 3 if lower.endswith("_ix") else 4
        prefix = humanize_prefix(lower[:-suffix_len])
        return f"{prefix.capitalize()} index." if prefix else "Index."

    # 5. code columns
    if lower.endswith("_code"):
        prefix = humanize_prefix(lower[:-5])
        return f"{prefix.capitalize()} code." if prefix else "Code."

    # 6. text columns
    if lower.endswith("_txt"):
        prefix = humanize_prefix(lower[:-4])
        return f"{prefix.capitalize()} text." if prefix else "Text value."

    # 7. quantity / count columns
    if lower.endswith("_qty"):
        prefix = humanize_prefix(lower[:-4])
        return f"{prefix.capitalize()} quantity." if prefix else "Quantity."
    if lower.endswith("_cnt"):
        prefix = humanize_prefix(lower[:-4])
        return f"{prefix.capitalize()} count." if prefix else "Count."

    # 8. fallback: humanize the whole column name
    prefix = humanize_prefix(lower)
    return f"{prefix.capitalize()} of the {label}." if prefix else f"Attribute of the {label}."


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("columns_json", type=Path, help="Path to columns_detail.json")
    parser.add_argument("descriptions_json", type=Path, help="Path to table_descriptions.json")
    parser.add_argument("-o", "--output", type=Path, default=Path("column_descriptions.json"))
    args = parser.parse_args()

    with open(args.columns_json, encoding="utf-8") as f:
        all_columns = json.load(f)
    with open(args.descriptions_json, encoding="utf-8") as f:
        all_table_descriptions = json.load(f)

    result = {}
    total_cols = 0
    for table, columns in all_columns.items():
        label = all_table_descriptions.get(table, {}).get("label", table.replace("_", " ").title())
        result[table] = {}
        for col, data_type in columns.items():
            result[table][col] = describe_column(table, col, data_type, label)
            total_cols += 1

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    print(f"{len(result)} tables, {total_cols} column descriptions generated.")
    print(f"File written: {args.output}")


if __name__ == "__main__":
    main()
