"""
Generates up to 7 sample_queries (natural language question + SQL) per table,
using:
- all_relationships.json (relationships + exact join_on clauses)
- columns_detail.json (data_type per column)
- table_descriptions.json (label + description per table)

For each of the 7 slots, the question phrasing alternates between two
registers, to give the resulting few-shot set some diversity:
  - "moderate"  -> still mentions the underlying column/table name, closer
                   to how someone with a bit of technical familiarity might ask
  - "natural"   -> fully conversational, no column names or SQL-ish wording,
                   aimed at someone with zero database knowledge

The underlying SQL is identical between the two registers for the same slot
— only the question text differs.

Query kinds covered, in priority order, guaranteed when the data allows it
(own columns, or via a relationship to a related table):
  1. listing        -> SELECT * ... LIMIT
  2. how many        -> COUNT(*)
  3. when            -> temporal question, based on a time-like column
  4. where           -> location question, based on lat/lon or location-like columns
  5. how long        -> duration question (duration column, or start_X/end_X pair)
  6. average         -> AVG() on a meaningful numeric metric column
  7. maximum         -> MAX() on the same metric column
  8. minimum         -> MIN() on the same metric column
  9. total (sum)     -> SUM() on the same metric column

Remaining slots (up to 7 total) fall back to: join to a child table, join to
the parent table, orphan detection, and a generic column filter.

Usage:
    python generate_sample_queries.py <all_relationships.json> <columns_detail.json> <table_descriptions.json> [-o output.json] [--tables act,act_stat,...]
"""

import json
import argparse
from pathlib import Path

TIME_HINTS = ("time", "date", "dttm", "_ts")
LOCATION_HINTS = ("lat", "lon", "loc_id", "_loc", "addr", "coord", "point", "brng")
DURATION_HINTS = ("duration",)

NUMERIC_TYPES = ("INTEGER", "BIGINT", "DECIMAL")
METRIC_EXCLUDE_HINTS = ("_id", "_ix", "code", "time", "date", "dttm", "lat", "lon")
METRIC_PRIORITY_HINTS = ("qty", "cnt", "count", "rat", "dim", "amt", "wt", "weight",
                          "height", "width", "length", "size", "total", "num",
                          "score", "value", "val")

# Alternating style pattern applied to the 7 output slots (position-based,
# independent of query kind) so the final set mixes both registers.
STYLE_PATTERN = ["natural", "moderate", "natural", "moderate", "natural", "moderate", "natural"]

# Domain abbreviation -> plain-English word, used to turn raw column names
# into natural phrases (lowercase, no underscores) for question text.
COLUMN_WORD_MAP = {
    "rep": "reported", "qty": "quantity", "cnt": "count", "rat": "ratio",
    "dim": "size", "amt": "amount", "wt": "weight", "num": "number",
    "val": "value", "req": "required", "prio": "priority", "descr": "description",
    "det": "detail", "actv": "active", "compl": "completion", "qual": "qualifier",
    "hand": "hand", "ext": "external", "ref": "reference", "incl": "inclination",
    "brng": "bearing", "acc": "accuracy", "org": "organization", "loc": "location",
    "alt": "altitude", "lat": "latitude", "lon": "longitude", "cat": "category",
    "txt": "text", "id": "identifier", "ix": "reference number", "code": "code",
    "on": "on", "operat": "operational", "seq": "sequence", "ord": "order",
    "sim": "simulation", "offset": "offset", "effctv": "effective",
    "start": "start", "end": "end", "target": "target", "firing": "firing",
    "subcat": "subcategory", "fac": "facility", "obj": "object", "item": "item",
    "type": "type", "assoc": "association",
}


def humanize(table_name: str) -> str:
    """Fallback: turn a snake_case table name into a readable label."""
    return table_name.replace("_", " ")


def get_label(table: str, descriptions: dict) -> str:
    entry = descriptions.get(table)
    if entry and entry.get("label"):
        return entry["label"]
    return humanize(table).title()


def humanize_column(col_name: str) -> str:
    """Turn a raw column name into a lowercase, natural-language phrase,
    for embedding inside a question aimed at a non-technical user."""
    tokens = col_name.split("_")
    words = []
    for tok in tokens:
        word = COLUMN_WORD_MAP.get(tok.lower(), tok.lower())
        if word:
            words.append(word)
    phrase = " ".join(words).strip()
    return phrase if phrase else col_name.replace("_", " ")


def pluralize(label: str) -> str:
    """Very simple English pluralization heuristic for question phrasing."""
    if label.endswith("y") and len(label) > 1 and label[-2].lower() not in "aeiou":
        return label[:-1] + "ies"
    if label.endswith(("s", "x", "z", "ch", "sh")):
        return label + "es"
    return label + "s"


def pick(style: str, moderate_text: str, natural_text: str) -> str:
    return natural_text if style == "natural" else moderate_text


def find_column(columns: dict, hints: tuple) -> str | None:
    if not columns:
        return None
    for col_name in columns:
        lower = col_name.lower()
        if any(hint in lower for hint in hints):
            return col_name
    return None


def find_lat_lon_pair(columns: dict):
    if not columns:
        return None
    lat_cols = [c for c in columns if "lat" in c.lower()]
    lon_cols = [c for c in columns if "lon" in c.lower()]
    for lat_col in lat_cols:
        prefix = lat_col.lower().replace("lat", "")
        for lon_col in lon_cols:
            if lon_col.lower().replace("lon", "") == prefix:
                return lat_col, lon_col
    if lat_cols and lon_cols:
        return lat_cols[0], lon_cols[0]
    return None


def find_start_end_pair(columns: dict):
    """Look for a start_X / end_X time-related column pair (e.g. start_time/end_time)."""
    if not columns:
        return None
    candidates = []
    for col in columns:
        if col.lower().startswith("start_"):
            suffix = col[len("start_"):]
            candidate_end = f"end_{suffix}"
            if candidate_end in columns:
                candidates.append((col, candidate_end, suffix))
    time_candidates = [c for c in candidates if any(hint in c[2].lower() for hint in TIME_HINTS)]
    if time_candidates:
        start_col, end_col, _ = time_candidates[0]
        return start_col, end_col
    return None


def pick_metric_column(columns: dict) -> str | None:
    """Pick a meaningful numeric column for aggregation (avg/max/min/sum),
    excluding IDs, indexes, codes, timestamps and coordinates."""
    if not columns:
        return None
    candidates = [
        c for c, dtype in columns.items()
        if dtype in NUMERIC_TYPES and not any(h in c.lower() for h in METRIC_EXCLUDE_HINTS)
    ]
    if not candidates:
        return None
    for c in candidates:
        if any(h in c.lower() for h in METRIC_PRIORITY_HINTS):
            return c
    return candidates[0]


def pick_first_column(columns: dict) -> str | None:
    if not columns:
        return None
    return next(iter(columns))


def guess_pk(columns: dict, table: str) -> str | None:
    for c in columns:
        if c.lower() in (f"{table}_id", f"{table}_ix"):
            return c
    for c in columns:
        if c.lower().endswith("_id") or c.lower().endswith("_ix"):
            return c
    return pick_first_column(columns)


def build_join_alias(table: str, related_table: str, join_on: str, default_a: str, default_b: str):
    alias_a, alias_b = table[0], related_table[0]
    if alias_a == alias_b:
        alias_a, alias_b = default_a, default_b
    join_on_aliased = join_on.replace(f"{table}.", f"{alias_a}.").replace(f"{related_table}.", f"{alias_b}.")
    return alias_a, alias_b, join_on_aliased


# ---------------------------------------------------------------------------
# "when" / "where" / "how long" generators
# ---------------------------------------------------------------------------

def gen_when(style, table, label, relationships, columns, all_columns, descriptions):
    time_col = find_column(columns, TIME_HINTS)
    if time_col:
        time_phrase = humanize_column(time_col)
        question = pick(
            style,
            f"When did the most recent {label} record occur, based on its {time_phrase}?",
            f"When did the most recent {label} happen?"
        )
        return {"question": question, "sql": f"SELECT * FROM {table} ORDER BY {time_col} DESC LIMIT 1;"}
    for rel in relationships:
        related_cols = all_columns.get(rel["related_table"], {})
        related_time_col = find_column(related_cols, TIME_HINTS)
        if related_time_col:
            related_label = get_label(rel["related_table"], descriptions)
            related_time_phrase = humanize_column(related_time_col)
            alias_a, alias_b, join_on = build_join_alias(table, rel["related_table"], rel["join_on"], "t1", "t2")
            question = pick(
                style,
                f"When did the most recent {label} occur, based on the {related_time_phrase} of its related {related_label}?",
                f"When did the most recent {label} happen, based on its linked {related_label}?"
            )
            return {
                "question": question,
                "sql": f"SELECT {alias_a}.*, {alias_b}.{related_time_col} FROM {table} {alias_a} JOIN {rel['related_table']} {alias_b} ON {join_on} ORDER BY {alias_b}.{related_time_col} DESC LIMIT 1;"
            }
    return None


def gen_where(style, table, label, relationships, columns, all_columns, descriptions):
    lat_lon = find_lat_lon_pair(columns)
    if lat_lon:
        lat_col, lon_col = lat_lon
        question = pick(
            style,
            f"What is the geographic position (based on its {humanize_column(lat_col)} and {humanize_column(lon_col)}) of each {label} record?",
            f"Where is each {label} located?"
        )
        return {"question": question, "sql": f"SELECT *, {lat_col}, {lon_col} FROM {table} WHERE {lat_col} IS NOT NULL AND {lon_col} IS NOT NULL;"}
    loc_col = find_column(columns, LOCATION_HINTS)
    if loc_col:
        question = pick(
            style,
            f"What is the {humanize_column(loc_col)} of each {label} record?",
            f"Where is each {label} located?"
        )
        return {"question": question, "sql": f"SELECT * FROM {table} WHERE {loc_col} IS NOT NULL;"}
    for rel in relationships:
        related_cols = all_columns.get(rel["related_table"], {})
        related_label = get_label(rel["related_table"], descriptions)
        alias_a, alias_b, join_on = build_join_alias(table, rel["related_table"], rel["join_on"], "t1", "t2")
        related_lat_lon = find_lat_lon_pair(related_cols)
        if related_lat_lon:
            lat_col, lon_col = related_lat_lon
            question = pick(
                style,
                f"Where is each {label} located, based on the {humanize_column(lat_col)} and {humanize_column(lon_col)} of its associated {related_label}?",
                f"Where is each {label} located, based on its linked {related_label}?"
            )
            return {"question": question, "sql": f"SELECT {alias_a}.*, {alias_b}.{lat_col}, {alias_b}.{lon_col} FROM {table} {alias_a} JOIN {rel['related_table']} {alias_b} ON {join_on};"}
        related_loc_col = find_column(related_cols, LOCATION_HINTS)
        if related_loc_col:
            question = pick(
                style,
                f"Where is each {label} located, based on the {humanize_column(related_loc_col)} of its associated {related_label}?",
                f"Where is each {label} located, based on its linked {related_label}?"
            )
            return {"question": question, "sql": f"SELECT {alias_a}.*, {alias_b}.{related_loc_col} FROM {table} {alias_a} JOIN {rel['related_table']} {alias_b} ON {join_on};"}
    return None


def gen_how_long(style, table, label, relationships, columns, all_columns, descriptions):
    duration_col = find_column(columns, DURATION_HINTS)
    if duration_col:
        question = pick(
            style,
            f"What is the {humanize_column(duration_col)} of each {label} record?",
            f"How long did each {label} last?"
        )
        return {"question": question, "sql": f"SELECT *, {duration_col} FROM {table};"}
    start_end = find_start_end_pair(columns)
    if start_end:
        start_col, end_col = start_end
        question = pick(
            style,
            f"How long does each {label} record last, from its {humanize_column(start_col)} to its {humanize_column(end_col)}?",
            f"How long did each {label} last?"
        )
        return {"question": question, "sql": f"SELECT *, ({end_col} - {start_col}) AS duration FROM {table};"}
    for rel in relationships:
        related_cols = all_columns.get(rel["related_table"], {})
        related_label = get_label(rel["related_table"], descriptions)
        alias_a, alias_b, join_on = build_join_alias(table, rel["related_table"], rel["join_on"], "t1", "t2")
        related_duration_col = find_column(related_cols, DURATION_HINTS)
        if related_duration_col:
            question = pick(
                style,
                f"How long did each {label} last, based on the {humanize_column(related_duration_col)} of its associated {related_label}?",
                f"How long did each {label} last, based on its linked {related_label}?"
            )
            return {"question": question, "sql": f"SELECT {alias_a}.*, {alias_b}.{related_duration_col} FROM {table} {alias_a} JOIN {rel['related_table']} {alias_b} ON {join_on};"}
        related_start_end = find_start_end_pair(related_cols)
        if related_start_end:
            start_col, end_col = related_start_end
            question = pick(
                style,
                f"How long did each {label} last, based on the {humanize_column(start_col)} and {humanize_column(end_col)} of its associated {related_label}?",
                f"How long did each {label} last, based on its linked {related_label}?"
            )
            return {"question": question, "sql": f"SELECT {alias_a}.*, ({alias_b}.{end_col} - {alias_b}.{start_col}) AS duration FROM {table} {alias_a} JOIN {rel['related_table']} {alias_b} ON {join_on};"}
    return None


# ---------------------------------------------------------------------------
# Aggregate generators (average / maximum / minimum / total)
# ---------------------------------------------------------------------------

def find_metric_source(table, label, relationships, columns, all_columns, descriptions):
    own_metric = pick_metric_column(columns)
    if own_metric:
        return {"scope": "own", "metric": own_metric}
    for rel in relationships:
        related_cols = all_columns.get(rel["related_table"], {})
        related_metric = pick_metric_column(related_cols)
        if related_metric:
            related_label = get_label(rel["related_table"], descriptions)
            alias_a, alias_b, join_on = build_join_alias(table, rel["related_table"], rel["join_on"], "t1", "t2")
            pk_guess = guess_pk(columns, table)
            return {
                "scope": "related", "metric": related_metric,
                "related_table": rel["related_table"], "related_label": related_label,
                "alias_a": alias_a, "alias_b": alias_b,
                "join_on": join_on, "pk_guess": pk_guess,
            }
    return None


def gen_aggregate(style, agg_func: str, agg_word: str, table, label, source: dict):
    if source is None:
        return None
    metric = source["metric"]
    metric_phrase = humanize_column(metric)

    if source["scope"] == "own":
        plural_label = pluralize(label)
        if agg_func == "SUM":
            question = pick(style,
                f"What is the total {metric_phrase} recorded across all {label} entries?",
                f"What is the total {metric_phrase} across all {plural_label}?")
        elif agg_func == "AVG":
            question = pick(style,
                f"What is the average {metric_phrase} recorded across all {label} entries?",
                f"On average, what is the {metric_phrase} for {plural_label}?")
        elif agg_func == "MAX":
            question = pick(style,
                f"What is the highest {metric_phrase} recorded across all {label} entries?",
                f"What is the highest {metric_phrase} recorded for {plural_label}?")
        else:  # MIN
            question = pick(style,
                f"What is the lowest {metric_phrase} recorded across all {label} entries?",
                f"What is the lowest {metric_phrase} recorded for {plural_label}?")
        return {"question": question, "sql": f"SELECT {agg_func}({metric}) FROM {table};"}

    else:
        related_label = source["related_label"]
        related_label_plural = pluralize(related_label)
        alias_a, alias_b = source["alias_a"], source["alias_b"]
        join_on = source["join_on"]
        pk_guess = source["pk_guess"]
        related_table = source["related_table"]
        if agg_func == "SUM":
            question = pick(style,
                f"For each {label} record, what is the total {metric_phrase} recorded across its linked {related_label_plural}?",
                f"For each {label}, what is the total {metric_phrase} of its linked {related_label_plural}?")
        elif agg_func == "AVG":
            question = pick(style,
                f"For each {label} record, what is the average {metric_phrase} recorded across its linked {related_label_plural}?",
                f"For each {label}, what is the average {metric_phrase} of its linked {related_label_plural}?")
        elif agg_func == "MAX":
            question = pick(style,
                f"For each {label} record, what is the highest {metric_phrase} recorded among its linked {related_label_plural}?",
                f"For each {label}, what is the highest {metric_phrase} among its linked {related_label_plural}?")
        else:  # MIN
            question = pick(style,
                f"For each {label} record, what is the lowest {metric_phrase} recorded among its linked {related_label_plural}?",
                f"For each {label}, what is the lowest {metric_phrase} among its linked {related_label_plural}?")
        return {
            "question": question,
            "sql": (f"SELECT {alias_a}.{pk_guess}, {agg_func}({alias_b}.{metric}) AS {agg_word}_{metric} "
                    f"FROM {table} {alias_a} JOIN {related_table} {alias_b} ON {join_on} "
                    f"GROUP BY {alias_a}.{pk_guess};")
        }


# ---------------------------------------------------------------------------
# Generic fallback generators (join child / join parent / orphan / filter)
# ---------------------------------------------------------------------------

def gen_join_child(style, table, label, parent_of, descriptions):
    if not parent_of:
        return None
    rel = next((r for r in parent_of if r["type"] == "Identifying"), parent_of[0])
    related_label = get_label(rel["related_table"], descriptions)
    alias_a, alias_b, join_on = build_join_alias(table, rel["related_table"], rel["join_on"], "t1", "t2")
    question = pick(
        style,
        f"For each {label} record, what related {related_label} details can be found?",
        f"What {related_label} details are linked to each {label}?"
    )
    return {"question": question, "sql": f"SELECT {alias_a}.*, {alias_b}.* FROM {table} {alias_a} JOIN {rel['related_table']} {alias_b} ON {join_on};"}


def gen_join_parent(style, table, label, child_of, descriptions):
    if not child_of:
        return None
    rel = child_of[0]
    related_label = get_label(rel["related_table"], descriptions)
    alias_a, alias_b, join_on = build_join_alias(table, rel["related_table"], rel["join_on"], "c", "p")
    question = pick(
        style,
        f"Show each {label} record along with its parent {related_label} information.",
        f"Which {related_label} does each {label} belong to?"
    )
    return {"question": question, "sql": f"SELECT {alias_a}.*, {alias_b}.* FROM {table} {alias_a} JOIN {rel['related_table']} {alias_b} ON {join_on};"}


def gen_orphan(style, table, label, parent_of, descriptions):
    identifying_parent = next((r for r in parent_of if r["type"] == "Identifying"), None)
    if not identifying_parent:
        return None
    rel = identifying_parent
    related_label = get_label(rel["related_table"], descriptions)
    alias_a, alias_b, join_on = build_join_alias(table, rel["related_table"], rel["join_on"], "t1", "t2")
    question = pick(
        style,
        f"Which {label} records have no associated {related_label} yet?",
        f"Are there any {label} without a matching {related_label} yet?"
    )
    return {"question": question, "sql": f"SELECT {alias_a}.* FROM {table} {alias_a} LEFT JOIN {rel['related_table']} {alias_b} ON {join_on} WHERE {alias_b}.{rel['related_column']} IS NULL;"}


def gen_generic_filter(style, table, label, columns, skip_first_n: int):
    cols = list(columns.keys())
    if skip_first_n >= len(cols):
        return None
    col = cols[skip_first_n]
    col_phrase = humanize_column(col)
    question = pick(
        style,
        f"Can I retrieve a specific {label} record using its {col_phrase}?",
        f"Can I look up a specific {label} by its {col_phrase}?"
    )
    return {"question": question, "sql": f"SELECT * FROM {table} WHERE {col} = :{col};"}


# ---------------------------------------------------------------------------
# Main per-table generation
# ---------------------------------------------------------------------------

def generate_queries_for_table(table, relationships, columns, all_columns, descriptions):
    label = get_label(table, descriptions)
    parent_of = [r for r in relationships if r.get("role") == "parent_of"]
    child_of = [r for r in relationships if r.get("role") == "child_of"]
    all_rels_ordered = parent_of + child_of

    metric_source = find_metric_source(table, label, all_rels_ordered, columns, all_columns, descriptions)

    def build(style):
        return [
            {"question": pick(style, f"List the first 20 {label} records.", f"Can you show me some examples of {pluralize(label)}?"),
             "sql": f"SELECT * FROM {table} LIMIT 20;"},
            {"question": pick(style, f"How many {label} records are there?", f"How many {pluralize(label)} are there in total?"),
             "sql": f"SELECT COUNT(*) FROM {table};"},
            gen_when(style, table, label, all_rels_ordered, columns, all_columns, descriptions),
            gen_where(style, table, label, all_rels_ordered, columns, all_columns, descriptions),
            gen_how_long(style, table, label, all_rels_ordered, columns, all_columns, descriptions),
            gen_aggregate(style, "AVG", "avg", table, label, metric_source),
            gen_aggregate(style, "MAX", "max", table, label, metric_source),
            gen_aggregate(style, "MIN", "min", table, label, metric_source),
            gen_aggregate(style, "SUM", "total", table, label, metric_source),
            gen_join_child(style, table, label, parent_of, descriptions),
            gen_join_parent(style, table, label, child_of, descriptions),
            gen_orphan(style, table, label, parent_of, descriptions),
        ]

    # Determine which candidate slots are available (style-independent).
    probe = build("moderate")
    available_indices = [i for i, c in enumerate(probe) if c is not None][:7]

    queries = []
    for slot_pos, gen_idx in enumerate(available_indices):
        style = STYLE_PATTERN[slot_pos % len(STYLE_PATTERN)]
        candidates_for_style = build(style)
        queries.append(candidates_for_style[gen_idx])

    # pad with generic column filters if still under 7
    skip_n = 0
    while len(queries) < 7:
        style = STYLE_PATTERN[len(queries) % len(STYLE_PATTERN)]
        filler = gen_generic_filter(style, table, label, columns, skip_n)
        if not filler:
            break
        queries.append(filler)
        skip_n += 1

    return queries[:7]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("relationships_json", type=Path, help="Path to all_relationships.json")
    parser.add_argument("columns_json", type=Path, help="Path to columns_detail.json")
    parser.add_argument("descriptions_json", type=Path, help="Path to table_descriptions.json")
    parser.add_argument("-o", "--output", type=Path, default=Path("sample_queries.json"))
    parser.add_argument("--tables", type=str, default=None,
                         help="Comma-separated list of tables (default: all known tables)")
    args = parser.parse_args()

    with open(args.relationships_json, encoding="utf-8") as f:
        all_relationships = json.load(f)
    with open(args.columns_json, encoding="utf-8") as f:
        all_columns = json.load(f)
    with open(args.descriptions_json, encoding="utf-8") as f:
        all_descriptions = json.load(f)

    if args.tables:
        target_tables = [t.strip() for t in args.tables.split(",")]
    else:
        target_tables = sorted(set(all_relationships.keys()) | set(all_columns.keys()))

    result = {}
    for table in target_tables:
        relationships = all_relationships.get(table, [])
        columns = all_columns.get(table, {})
        result[table] = generate_queries_for_table(table, relationships, columns, all_columns, all_descriptions)

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    total = sum(len(v) for v in result.values())
    print(f"{len(result)} tables processed, {total} sample_queries generated.")
    print(f"File written: {args.output}")


if __name__ == "__main__":
    main()
