"""
Extrait toutes les relations (foreign keys) depuis reld.html (rapport DeZign
for Databases - "Relationship details"), en incluant cette fois le nom EXACT
des colonnes de jointure (parent et enfant), et organise le tout en
dictionnaire par table sous forme de liste plate, avec un champ "join_on"
prêt à l'emploi pour la génération de SQL.

Contrairement à entd.html (qui donne seulement les noms de tables parent/
enfant), reld.html donne le détail "Parent: table (colonne)" / "Child: table
(colonne)" pour chaque relation, ce qui permet de construire une clause de
jointure exacte, y compris quand deux relations vers la même table utilisent
des colonnes différentes (ex: action_group.parent_act_id vs child_act_id).

Format de sortie par table:
{
  "act": [
    {
      "role": "parent_of",
      "name": "act_action_group",
      "type": "Non Identifying",
      "related_table": "action_group",
      "cardinality": "One Or More",
      "join_on": "act.act_id = action_group.parent_act_id",
      "own_column": "act_id",
      "related_column": "parent_act_id"
    },
    ...
  ],
  ...
}

Usage:
    python extract_relationships_with_joins.py <reld.html> [-o output.json]
"""

import re
import json
import argparse
from pathlib import Path


BLOCK_PATTERN = re.compile(
    r'<A NAME="(.*?)"></A>\s*'
    r'<div class="objectname">Relationship: .*?</div>.*?'
    r'Type</td><td class="fielddata">(.*?)</td></tr>\s*'
    r'<tr><td class="fieldname">Cardinality</td><td class="fielddata">(.*?)</td></tr>\s*'
    r'<tr><td class="fieldname">Parent</td><td class="fielddata">(.*?) \((.*?)\)</td></tr>\s*'
    r'<tr><td class="fieldname">Child</td><td class="fielddata">(.*?) \((.*?)\)</td></tr>',
    re.DOTALL
)


def extract_raw_relationships(html_content: str) -> list[tuple]:
    """
    Retourne une liste de tuples:
    (rel_name, type, cardinality, parent_table, parent_col, child_table, child_col)
    Déduplique en conservant l'ordre (le rapport HTML peut répéter des blocs).
    """
    matches = BLOCK_PATTERN.findall(html_content)
    unique = list(dict.fromkeys(matches))
    return unique


def build_relationships_dict(unique_rels: list[tuple]) -> dict:
    """
    Transforme la liste de tuples en dictionnaire indexé par table -> liste
    plate de relations (role parent_of / child_of), avec join_on explicite.
    """
    relationships: dict[str, list[dict]] = {}

    for rel_name, typ, card, parent_table, parent_col, child_table, child_col in unique_rels:
        relationships.setdefault(parent_table, [])
        relationships.setdefault(child_table, [])

        join_on = f"{parent_table}.{parent_col} = {child_table}.{child_col}"

        relationships[parent_table].append({
            "role": "parent_of",
            "name": rel_name,
            "type": typ,
            "related_table": child_table,
            "cardinality": card,
            "join_on": join_on,
            "own_column": parent_col,
            "related_column": child_col,
        })
        relationships[child_table].append({
            "role": "child_of",
            "name": rel_name,
            "type": typ,
            "related_table": parent_table,
            "cardinality": card,
            "join_on": join_on,
            "own_column": child_col,
            "related_column": parent_col,
        })

    return relationships


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("html_path", type=Path, help="Chemin vers reld.html")
    parser.add_argument("-o", "--output", type=Path, default=Path("all_relationships.json"),
                         help="Fichier de sortie JSON (défaut: all_relationships.json)")
    args = parser.parse_args()

    html_content = args.html_path.read_text(encoding="utf-8", errors="ignore")

    unique_rels = extract_raw_relationships(html_content)
    relationships = build_relationships_dict(unique_rels)

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(relationships, f, indent=2, ensure_ascii=False)

    print(f"{len(unique_rels)} relations uniques trouvées.")
    print(f"{len(relationships)} tables référencées.")
    print(f"Fichier écrit : {args.output}")


if __name__ == "__main__":
    main()
