"""
Rephrases the "question" field of an existing sample_queries.json file using
a local Ollama model (default: mistral:7b, NATO-country origin), while
leaving the "sql" field completely untouched.

Requires Ollama running locally (https://ollama.com) with the target model
already pulled:
    ollama pull mistral:7b

Usage:
    python rephrase_with_ollama.py sample_queries.json -o sample_queries_rephrased.json
    python rephrase_with_ollama.py sample_queries.json -o out.json --model mistral:7b
    python rephrase_with_ollama.py sample_queries.json -o out.json --tables act,holding
    python rephrase_with_ollama.py sample_queries.json -o out.json --limit 10   # quick test
"""

import json
import argparse
import time
from pathlib import Path
from urllib import request as urllib_request
from urllib.error import URLError

OLLAMA_URL = "http://ollama:11434/api/generate"

SYSTEM_PROMPT = (
    "You rewrite short database-related questions in plain, natural, "
    "conversational English, as if a non-technical person were asking them. "
    "Rules:\n"
    "- Keep the exact same meaning and intent as the original question.\n"
    "- Never mention SQL, columns, tables, database jargon, or technical terms.\n"
    "- Do not add new information, assumptions, or extra questions.\n"
    "- Keep it short: one sentence, ending with a question mark.\n"
    "- Return ONLY the rewritten question, nothing else — no quotes, no preamble, no explanation."
)


def call_ollama(model: str, question: str, timeout: int = 60) -> str:
    """Send one rephrasing request to a local Ollama server and return the
    rewritten question text."""
    prompt = f"{SYSTEM_PROMPT}\n\nOriginal question: {question}\nRewritten question:"

    payload = json.dumps({
        "model": model,
        "prompt": prompt,
        "stream": False,
        "options": {"temperature": 0.3},
    }).encode("utf-8")

    req = urllib_request.Request(
        OLLAMA_URL, data=payload, headers={"Content-Type": "application/json"}
    )
    with urllib_request.urlopen(req, timeout=timeout) as resp:
        body = json.loads(resp.read().decode("utf-8"))
    return body.get("response", "").strip().strip('"')


def rephrase_file(input_path: Path, output_path: Path, model: str,
                   tables_filter: list[str] | None, limit: int | None,
                   keep_original: bool, retries: int) -> None:
    with open(input_path, encoding="utf-8") as f:
        data = json.load(f)

    tables = tables_filter if tables_filter else list(data.keys())
    total_processed = 0
    total_failed = 0

    for table in tables:
        if table not in data:
            print(f"  [skip] table '{table}' not found in input file")
            continue

        for entry in data[table]:
            if limit is not None and total_processed >= limit:
                break

            original_question = entry["question"]
            new_question = None

            for attempt in range(1, retries + 1):
                try:
                    new_question = call_ollama(model, original_question)
                    if new_question:
                        break
                except (URLError, TimeoutError) as e:
                    print(f"  [retry {attempt}/{retries}] {table}: {e}")
                    time.sleep(1.5)

            if new_question:
                if keep_original:
                    entry["question_original"] = original_question
                entry["question"] = new_question
                total_processed += 1
            else:
                total_failed += 1
                print(f"  [failed] {table}: kept original question -> {original_question}")

        if limit is not None and total_processed >= limit:
            break

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    print(f"\nDone. {total_processed} questions rephrased, {total_failed} failed (kept original).")
    print(f"File written: {output_path}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_json", type=Path, help="Path to the existing sample_queries.json")
    parser.add_argument("-o", "--output", type=Path, default=Path("sample_queries_rephrased.json"))
    parser.add_argument("--model", type=str, default="mistral:7b",
                         help="Ollama model tag to use (default: mistral:7b)")
    parser.add_argument("--tables", type=str, default=None,
                         help="Comma-separated list of tables to process (default: all)")
    parser.add_argument("--limit", type=int, default=None,
                         help="Only process the first N questions total (useful for a quick test)")
    parser.add_argument("--keep-original", action="store_true",
                         help="Also store the original question under 'question_original'")
    parser.add_argument("--retries", type=int, default=3,
                         help="Number of retries per question on failure (default: 3)")
    args = parser.parse_args()

    tables_filter = [t.strip() for t in args.tables.split(",")] if args.tables else None

    print(f"Rephrasing questions from {args.input_json} using Ollama model '{args.model}'...")
    print("Make sure Ollama is running locally and the model is pulled:")
    print(f"    ollama pull {args.model}\n")

    rephrase_file(
        input_path=args.input_json,
        output_path=args.output,
        model=args.model,
        tables_filter=tables_filter,
        limit=args.limit,
        keep_original=args.keep_original,
        retries=args.retries,
    )


if __name__ == "__main__":
    main()
