"""
Extrait toutes les relations (foreign keys) depuis un rapport DeZign for
Databases au format "Entity Detail" (entd.html), et les organise en
dictionnaire par table, sous forme de LISTE PLATE de relations (une entrée
par relation, avec un champ "role" indiquant si la table est parent ou enfant).

Format de sortie:
{
  "act": [
    {"role": "parent_of", "name": "act_action_group", "type": "Non Identifying",
     "related_table": "action_group", "cardinality": "One Or More"},
    ...
  ],
  ...
}

Usage:
    python extract_all_relationships.py <entd.html> [-o output.json]
"""

import re
import json
import argparse
from pathlib import Path


ROW_PATTERN = re.compile(
    r'<tr><td class="fielddata">(.*?)</td>'
    r'<td class="fielddata">(.*?)</td>'
    r'<td class="fielddata">(.*?)</td>'
    r'<td class="fielddata">(.*?)</td>'
    r'<td class="fielddata">(.*?)</td></tr>'
)

VALID_TYPES = {"Identifying", "Non Identifying"}


def extract_raw_relationships(html_content: str) -> list[tuple]:
    """
    Repère toutes les lignes de tableau à 5 colonnes correspondant à des
    relations (filtrées sur le champ 'Type' = Identifying / Non Identifying),
    puis déduplique (le rapport HTML répète parfois les mêmes lignes).
    Chaque tuple: (name, type, parent, child, cardinality)
    """
    rows = ROW_PATTERN.findall(html_content)
    rels = [r for r in rows if r[1] in VALID_TYPES]
    unique_rels = list(dict.fromkeys(rels))  # dedupe en gardant l'ordre
    return unique_rels


def build_relationships_dict(unique_rels: list[tuple]) -> dict:
    """
    Transforme la liste plate de tuples (name, type, parent, child, cardinality)
    en dictionnaire indexé par table -> liste plate de relations, chacune
    portant un champ "role" ("parent_of" ou "child_of").
    """
    relationships: dict[str, list[dict]] = {}

    for name, typ, parent, child, card in unique_rels:
        relationships.setdefault(parent, [])
        relationships.setdefault(child, [])

        relationships[parent].append({
            "role": "parent_of",
            "name": name,
            "type": typ,
            "related_table": child,
            "cardinality": card,
        })
        relationships[child].append({
            "role": "child_of",
            "name": name,
            "type": typ,
            "related_table": parent,
            "cardinality": card,
        })

    return relationships


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("html_path", type=Path, help="Chemin vers entd.html")
    parser.add_argument("-o", "--output", type=Path, default=Path("all_relationships.json"),
                         help="Fichier de sortie JSON (défaut: all_relationships.json)")
    args = parser.parse_args()

    html_content = args.html_path.read_text(encoding="utf-8", errors="ignore")

    unique_rels = extract_raw_relationships(html_content)
    relationships = build_relationships_dict(unique_rels)

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(relationships, f, indent=2, ensure_ascii=False)

    print(f"{len(unique_rels)} relations uniques trouvées.")
    print(f"{len(relationships)} tables référencées.")
    print(f"Fichier écrit : {args.output}")


if __name__ == "__main__":
    main()
