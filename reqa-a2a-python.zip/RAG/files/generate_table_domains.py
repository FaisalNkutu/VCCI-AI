"""
Generates a precise, deeply-grounded "domain" classification for every table
in the schema, using a local Ollama LLM (default: mistral:7b, NATO-country
origin) that is given BOTH:
  1. The full context of the individual table (label, description, columns
     with their data types/descriptions, and its real relationships to other
     tables — parent_of / child_of, from all_relationships.json)
  2. The full context of the whole database (database_context.json — a
     genuinely-informed narrative of what this schema models end-to-end,
     plus a closed taxonomy of domain tags spanning the entire schema)

This two-level context is what makes the classification precise: the model
is not guessing from a table name in isolation, it is told what role that
table plays inside the bigger DIS/M&S military exercise system, and asked to
pick from — or, only if truly necessary, extend — a taxonomy that already
covers the schema's real sub-domains (Operations, DIS interoperability,
CBRN, Logistics, Meteorology, Tactical Graphics, After-Action Metrics, ...).

Requires Ollama running locally with the target model pulled:
    ollama pull mistral:7b

Usage:
    python generate_table_domains.py \\
        --relationships all_relationships.json \\
        --columns columns_detail.json \\
        --descriptions table_descriptions.json \\
        --db-context database_context.json \\
        -o table_domains.json

    # quick test on a few tables first
    python generate_table_domains.py ... -o test.json --tables act,bio_mat_type,porter_route
"""

import json
import argparse
import time
from pathlib import Path
from urllib import request as urllib_request
from urllib.error import URLError

OLLAMA_URL = "http://ollama:11434/api/generate"


def load_json(path: Path) -> dict:
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def build_table_context(table: str, relationships: list[dict], columns: dict,
                         description_entry: dict) -> str:
    """Assemble a compact but complete natural-language context block for
    one table: what it's called, what it's for, what columns it has, and
    how it connects to the rest of the schema."""
    label = description_entry.get("label", table)
    description = description_entry.get("description", "")

    col_lines = []
    for col_name, col_info in columns.items():
        if isinstance(col_info, dict):
            dtype = col_info.get("data_type", "")
            desc = col_info.get("description", "")
        else:
            dtype = col_info
            desc = ""
        piece = f"  - {col_name} ({dtype})"
        if desc:
            piece += f": {desc}"
        col_lines.append(piece)

    parent_of = sorted({r["related_table"] for r in relationships if r.get("role") == "parent_of"})
    child_of = sorted({r["related_table"] for r in relationships if r.get("role") == "child_of"})

    rel_lines = []
    if parent_of:
        rel_lines.append(f"  - Is referenced by (parent of): {', '.join(parent_of)}")
    if child_of:
        rel_lines.append(f"  - References (child of): {', '.join(child_of)}")
    if not rel_lines:
        rel_lines.append("  - No foreign key relationships detected (standalone table).")

    return (
        f"Table name: {table}\n"
        f"Label: {label}\n"
        f"Description: {description or '(no description available)'}\n"
        f"Columns:\n" + ("\n".join(col_lines) if col_lines else "  (no columns found)") + "\n"
        f"Relationships:\n" + "\n".join(rel_lines)
    )


def build_prompt(db_context: dict, table_context: str) -> str:
    taxonomy_lines = [
        f"- {t['name']}: {t['description']}"
        for t in db_context["domain_taxonomy"]
    ]
    taxonomy_block = "\n".join(taxonomy_lines)

    return f"""You are a data modeling expert classifying a database table into one or more precise domain tags.

=== DATABASE-WIDE CONTEXT ===
{db_context['database_overview']}

=== AVAILABLE DOMAIN TAGS (use these whenever they genuinely fit) ===
{taxonomy_block}

=== TABLE TO CLASSIFY ===
{table_context}

=== INSTRUCTIONS ===
- Pick 1 to 3 domain tags that most precisely describe this specific table's role, using the table's own columns and relationships as evidence — not just its name.
- Prefer tags from the list above. Only invent a new tag (short, Title Case, same style) if none of the listed tags genuinely fit.
- Order tags from most to least relevant.
- Return ONLY a JSON array of strings, nothing else. Example: ["Operations & Command Control", "Simulation & Exercise Management"]
"""


def call_ollama(model: str, prompt: str, timeout: int = 90) -> str:
    payload = json.dumps({
        "model": model,
        "prompt": prompt,
        "stream": False,
        "options": {"temperature": 0.1},
    }).encode("utf-8")
    req = urllib_request.Request(
        OLLAMA_URL, data=payload, headers={"Content-Type": "application/json"}
    )
    with urllib_request.urlopen(req, timeout=timeout) as resp:
        body = json.loads(resp.read().decode("utf-8"))
    return body.get("response", "").strip()


def parse_domain_list(raw_response: str) -> list[str]:
    """Extract a JSON array of strings from the model's raw response,
    tolerating minor formatting noise (code fences, leading text)."""
    text = raw_response.strip()
    if "```" in text:
        text = text.split("```")[1] if text.count("```") >= 2 else text
        text = text.replace("json", "", 1).strip()
    start = text.find("[")
    end = text.rfind("]")
    if start == -1 or end == -1:
        return []
    try:
        parsed = json.loads(text[start:end + 1])
        if isinstance(parsed, list):
            return [str(x).strip() for x in parsed if str(x).strip()]
    except json.JSONDecodeError:
        pass
    return []


def generate_domains(all_relationships: dict, all_columns: dict, all_descriptions: dict,
                      db_context: dict, model: str, tables_filter: list[str] | None,
                      retries: int) -> dict:
    all_known_tables = sorted(set(all_relationships.keys()) | set(all_columns.keys()))
    tables = tables_filter if tables_filter else all_known_tables

    result = {}
    for i, table in enumerate(tables, 1):
        relationships = all_relationships.get(table, [])
        columns = all_columns.get(table, {})
        description_entry = all_descriptions.get(table, {})

        table_context = build_table_context(table, relationships, columns, description_entry)
        prompt = build_prompt(db_context, table_context)

        domains = []
        for attempt in range(1, retries + 1):
            try:
                raw = call_ollama(model, prompt)
                domains = parse_domain_list(raw)
                if domains:
                    break
            except (URLError, TimeoutError) as e:
                print(f"  [retry {attempt}/{retries}] {table}: {e}")
                time.sleep(1.5)

        if not domains:
            print(f"  [warning] {table}: could not obtain a domain classification, leaving empty")

        result[table] = domains
        print(f"[{i}/{len(tables)}] {table} -> {domains}")

    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--relationships", type=Path, default=Path("all_relationships.json"))
    parser.add_argument("--columns", type=Path, default=Path("columns_detail.json"))
    parser.add_argument("--descriptions", type=Path, default=Path("table_descriptions.json"))
    parser.add_argument("--db-context", type=Path, default=Path("database_context.json"))
    parser.add_argument("--model", type=str, default="mistral:7b")
    parser.add_argument("-o", "--output", type=Path, default=Path("table_domains.json"))
    parser.add_argument("--tables", type=str, default=None,
                         help="Comma-separated list of tables to process (default: all)")
    parser.add_argument("--retries", type=int, default=3)
    args = parser.parse_args()

    all_relationships = load_json(args.relationships)
    all_columns = load_json(args.columns)
    all_descriptions = load_json(args.descriptions)
    db_context = load_json(args.db_context)

    tables_filter = [t.strip() for t in args.tables.split(",")] if args.tables else None

    print(f"Classifying domains using Ollama model '{args.model}'...")
    print(f"Make sure Ollama is running and the model is pulled: ollama pull {args.model}\n")

    result = generate_domains(
        all_relationships, all_columns, all_descriptions, db_context,
        args.model, tables_filter, args.retries
    )

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    print(f"\nFile written: {args.output}")


if __name__ == "__main__":
    main()
