"""
Generates a first-draft description (label + description) for each table in
the schema, based on:
- naming heuristics (patterns like _type, _assoc, _stat, _event, _alias...)
- expansion of common domain abbreviations (dictionary to be enriched)
- the actual relationships already extracted (all_relationships.json), to
  place the table in the graph (parent of / child of which tables)

Goal: provide a consistent baseline to review/refine by hand afterwards,
rather than starting from scratch on 250+ tables.

Usage:
    python generate_table_descriptions.py <all_relationships.json> <columns_detail.json> [-o output.json]
"""

import json
import argparse
from pathlib import Path

# Domain abbreviation -> full form dictionary.
# To be enriched over time (source: naming conventions observed in the schema).
ABBREVIATIONS = {
    "act": "Activity", "acft": "Aircraft", "addr": "Address",
    "aerodrome": "Aerodrome", "airfield": "Airfield", "assoc": "Association",
    "atmosphere": "Atmosphere", "bio": "Biological", "blob": "Blob",
    "bridge": "Bridge", "cat": "Category", "capab": "Capability",
    "cbrn": "CBRN", "cfeat": "Control Feature", "chm": "Chemical",
    "circuit": "Circuit", "cloud": "Cloud", "cmpnt": "Component",
    "cntnt": "Content", "code": "Code", "comms": "Communications",
    "contxt": "Context", "ctrl": "Control", "elctrnc": "Electronic",
    "eng": "Engineering", "eqpt": "Equipment", "event": "Event",
    "fac": "Facility", "feat": "Feature", "fire": "Fire",
    "footprint": "Footprint", "geom": "Geometric", "geo": "Geographic",
    "hrbr": "Harbor", "icing": "Icing", "id": "ID", "ix": "Index",
    "item": "Item", "loc": "Location", "mat": "Material",
    "met": "Meteorological", "mil": "Military", "msg": "Message",
    "netwrk": "Network", "obj": "Object", "oi": "Object/Installation",
    "ot": "Object Type", "org": "Organization", "param": "Parameter",
    "parking": "Parking", "pers": "Person", "point": "Point",
    "precipitation": "Precipitation", "radact": "Radioactive",
    "rel": "Relative", "route": "Route", "rx": "Receive",
    "scenario": "Scenario", "segment": "Segment", "simulator": "Simulator",
    "spot": "Spot", "stat": "Status", "tag": "Tag", "task": "Task",
    "taxiway": "Taxiway", "trigger": "Trigger", "tx": "Transmit",
    "txt": "Text", "type": "Type", "unit": "Unit", "weapon": "Weapon",
    "zone": "Zone", "abs": "Absolute", "crts": "CRTS", "alias": "Alias",
    "transcript": "Transcript", "fragment": "Fragment", "holding": "Holding",
    "ammo": "Ammunition", "mrt": "MRT", "appid": "Application ID",
}


def build_label(table_name: str) -> str:
    """Build a readable label from the table's snake_case name."""
    tokens = table_name.split("_")
    words = [ABBREVIATIONS.get(tok, tok.capitalize()) for tok in tokens]
    return " ".join(words)


def relationship_summary(table: str, relationships: list[dict]) -> str:
    """Summarize the table's relationships in one sentence, without SQL detail."""
    parents_referencing_me = sorted({r["related_table"] for r in relationships if r["role"] == "parent_of"})
    tables_i_reference = sorted({r["related_table"] for r in relationships if r["role"] == "child_of"})

    parts = []
    if tables_i_reference:
        parts.append(f"References {', '.join(tables_i_reference)}")
    if parents_referencing_me:
        parts.append(f"referenced by {', '.join(parents_referencing_me)}")

    if not parts:
        return "Standalone table with no foreign key relationships detected."
    summary = "; ".join(parts) + "."
    return summary[0].upper() + summary[1:]


def build_description(table: str, label: str, relationships: list[dict], columns: dict) -> str:
    """Build a description based on naming patterns + relationships."""
    n_cols = len(columns)
    rel_summary = relationship_summary(table, relationships)

    if table.endswith("_type"):
        base = f"Reference/lookup table defining the set of {label.replace(' Type', '').lower()} categories used elsewhere in the schema."
    elif table.endswith("_assoc"):
        base = f"Association (junction) table capturing a many-to-many or linking relationship — {label.lower()}."
    elif table.endswith("_stat"):
        base = f"Status/state tracking table recording status snapshots or history — {label.lower()}."
    elif table.endswith("_event"):
        base = f"Event table capturing occurrences of a specific type of event — {label.lower()}."
    elif table.endswith("_alias"):
        base = f"Alias table storing alternate names or codes — {label.lower()}."
    elif table.endswith("_trigger"):
        base = f"Trigger/condition table defining activation conditions — {label.lower()}."
    elif table.endswith("_parameter") or table.endswith("_param"):
        base = f"Parameter table storing configurable parameter values — {label.lower()}."
    else:
        base = f"Table storing records for: {label.lower()} ({n_cols} attributes)."

    return f"{base} {rel_summary}"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("relationships_json", type=Path, help="Path to all_relationships.json")
    parser.add_argument("columns_json", type=Path, help="Path to columns_detail.json")
    parser.add_argument("-o", "--output", type=Path, default=Path("table_descriptions.json"))
    args = parser.parse_args()

    with open(args.relationships_json, encoding="utf-8") as f:
        all_relationships = json.load(f)

    with open(args.columns_json, encoding="utf-8") as f:
        all_columns = json.load(f)

    all_tables = sorted(set(all_relationships.keys()) | set(all_columns.keys()))

    result = {}
    for table in all_tables:
        relationships = all_relationships.get(table, [])
        columns = all_columns.get(table, {})
        label = build_label(table)
        description = build_description(table, label, relationships, columns)
        result[table] = {
            "label": label,
            "description": description,
        }

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    print(f"{len(result)} table descriptions generated.")
    print(f"File written: {args.output}")


if __name__ == "__main__":
    main()
