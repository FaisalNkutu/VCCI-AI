"""
Generate rag/domain_map.json — assigns one or more military domains to each
table in schema_knowledge.json by calling Mistral via Ollama.

Usage:
    python docs/gen_domain_map.py
    python docs/gen_domain_map.py --force   # overwrite existing entries
    python docs/gen_domain_map.py --output path/to/custom.json
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

import ollama

ROOT       = Path(__file__).resolve().parent.parent
KB_PATH    = ROOT / "RAG" / "KB_full.json"
OUT_PATH   = ROOT / "RAG" / "Domain_map.json"

sys.path.insert(0, str(ROOT))
from config.settings import get_settings

# ---------------------------------------------------------------------------
# Authoritative NATO military domain hierarchy
# Keys   = top-level domains (use these for high-level classification)
# Values = sub-domains      (use these for fine-grained classification)
# ---------------------------------------------------------------------------
MILITARY_DOMAINS: dict[str, list[str]] = {
    "Personnel": [
        "Recruitment",
        "Career_Management",
        "Promotions_and_Awards",
        "Assignments_and_Rotation",
        "Service_Records",
        "Human_Resources",
        "Veterans_and_Reserves",
    ],
    "Operations": [
        "Tactical_Operations",
        "Combat_Operations",
        "Patrol_and_Reconnaissance",
        "Deployment",
        "Rules_of_Engagement",
        "After_Action_Review",
        "Campaign_Management",
        "Action"
    ],
    "Intelligence": [
        "HUMINT",
        "SIGINT",
        "IMINT_and_GEOINT",
        "OSINT",
        "Threat_Assessment",
        "Counterintelligence",
        "Order_of_Battle",
        "Collection_Planning",
    ],
    "Equipment": [
        "Weapons_Systems",
        "Vehicles_and_Armor",
        "Aircraft",
        "Naval_Vessels",
        "Ammunition_and_Ordnance",
        "UAV_and_Drones",
        "Protective_Equipment",
    ],
    "Logistics": [
        "Supply_Chain",
        "Transportation",
        "Fuel_and_Energy",
        "Rations_and_Subsistence",
        "Ammunition_Supply",
        "Warehousing_and_Distribution",
        "Resupply_Operations",
    ],
    "Maintenance": [
        "Preventive_Maintenance",
        "Corrective_Maintenance",
        "Spare_Parts_Management",
        "Technical_Orders",
        "Calibration_and_Testing",
        "Workshop_Operations",
    ],
    "Training": [
        "Courses_and_Curriculum",
        "Field_Exercises",
        "Simulations_and_Wargames",
        "Certification_and_Qualification",
        "Drills_and_Procedures",
        "Instructor_Management",
    ],
    "Medical": [
        "Triage_and_Casualty_Management",
        "Field_Hospital",
        "Pharmacy_and_Medication",
        "MEDEVAC",
        "Diagnosis_and_Treatment",
        "Mental_Health",
        "Preventive_Medicine",
    ],
    "Finance": [
        "Budget_and_Appropriations",
        "Payroll_and_Salary",
        "Expenditure_and_Disbursements",
        "Audit_and_Accounting",
        "Cost_Control",
        "Financial_Reporting",
    ],
    "Communications": [
        "Radio_and_Signal",
        "Satellite_Communications",
        "Network_Infrastructure",
        "Encryption_and_Crypto",
        "Electronic_Warfare",
        "Link16_and_Tactical_Datalinks",
        "Frequency_Management",
    ],
    "Command_and_Control": [
        "Headquarters_Operations",
        "Task_Force_Management",
        "Situation_Awareness",
        "Reporting_and_Briefings",
        "Joint_Operations",
        "Command_Posts",
        "Decision_Support",
    ],
    "Cybersecurity": [
        "Network_Defense",
        "Incident_Response",
        "Vulnerability_Management",
        "Malware_Analysis",
        "Access_Control_and_Identity",
        "Information_Assurance",
        "Cyber_Threat_Intelligence",
    ],
    "Planning": [
        "Operational_Planning",
        "Strategic_Planning",
        "Contingency_Planning",
        "Force_Structure_Planning",
        "Target_Planning",
        "Resource_Allocation",
    ],
    "Procurement": [
        "Acquisition",
        "Contracts_Management",
        "Vendor_and_Supplier",
        "Tendering_and_Bidding",
        "Supplier_Evaluation",
        "Delivery_and_Acceptance",
    ],
    "Infrastructure": [
        "Airfields_and_Runways",
        "Ports_and_Seabases",
        "Bases_and_Garrisons",
        "Forward_Operating_Bases",
        "Fortifications_and_Bunkers",
        "Barracks_and_Facilities",
        "Ammunition_Depots",
    ],
    "Doctrine": [
        "Tactics_and_Techniques",
        "Standard_Operating_Procedures",
        "Field_Manuals",
        "Training_Doctrine",
        "Joint_Doctrine",
        "Lessons_Learned",
    ],
    "Reference": [
        "Lookup_and_Classification",
        "Codes_and_Standards",
        "Country_and_Language",
        "Status_Types",
        "Unit_Types",
        "Rank_and_Grade",
    ],
    "Location": [
        "Geographic_Coordinates",
        "Area_of_Operations",
        "Checkpoints_and_Waypoints",
        "Terrain_and_Topography",
        "Grid_References",
        "Maps_and_Charts",
        "Borders_and_Zones",
    ],
}

# Flat sets for validation
_TOP_LEVEL_DOMAINS: set[str] = set(MILITARY_DOMAINS.keys())
_ALL_DOMAINS: set[str] = _TOP_LEVEL_DOMAINS | {
    sub for subs in MILITARY_DOMAINS.values() for sub in subs
}


def _domains_for_prompt() -> str:
    """Format the domain hierarchy for the LLM prompt."""
    lines = []
    for domain, subs in MILITARY_DOMAINS.items():
        lines.append(f"  {domain}: {', '.join(subs)}")
    return "\n".join(lines)


_SYSTEM = (
    "You are a NATO military database analyst. "
    "Your task is to classify database tables into military functional domains "
    "and sub-domains."
)

_USER_TMPL = """\
Assign 1 to 3 domains to the following database table.
You may use either a top-level domain OR one of its sub-domains.
Choose ONLY from the values below:

{domains}

Table: {table}
Description: {description}
Key columns: {columns}

Reply with ONLY a valid JSON array of domain strings (top-level or sub-domain).
Example: ["Operations", "Patrol_and_Reconnaissance"]
"""


# ---------------------------------------------------------------------------
# LLM call
# ---------------------------------------------------------------------------

def _extract_json_array(text: str) -> list[str]:
    """Return first JSON array found in text, raise ValueError if none."""
    m = re.search(r"\[.*?\]", text, re.DOTALL)
    if not m:
        raise ValueError(f"No JSON array found in LLM output: {text!r}")
    return json.loads(m.group())


def _build_column_summary(columns: dict, max_cols: int = 10) -> str:
    """Build a concise column summary for the LLM prompt."""
    parts = []
    for col_name, col_data in list(columns.items())[:max_cols]:
        line = col_name
        desc = col_data.get("description", "").strip()
        if desc:
            line += f" ({desc}"
            allowed = col_data.get("allowed_values", [])
            examples = col_data.get("example_values", [])
            if allowed:
                line += f", values: {', '.join(str(v) for v in allowed[:5])}"
            elif examples:
                line += f", e.g. {', '.join(str(v) for v in examples[:5])}"
            line += ")"
        else:
            allowed = col_data.get("allowed_values", [])
            examples = col_data.get("example_values", [])
            if allowed:
                line += f" (values: {', '.join(str(v) for v in allowed[:5])})"
            elif examples:
                line += f" (e.g. {', '.join(str(v) for v in examples[:5])})"
        parts.append(line)
    return "; ".join(parts) if parts else "—"


def classify_table(table_name: str, entry: dict, model: str) -> list[str]:
    col_summary = _build_column_summary(entry.get("columns", {}))
    prompt = _USER_TMPL.format(
        domains=_domains_for_prompt(),
        table=table_name,
        description=entry.get("table_description", ""),
        columns=col_summary,
    )
    resp = ollama.chat(
        model=model,
        messages=[
            {"role": "system", "content": _SYSTEM},
            {"role": "user",   "content": prompt},
        ],
        options={"temperature": 0, "num_predict": 64},
    )
    raw = resp["message"]["content"].strip()
    domains = _extract_json_array(raw)
    # keep only values from the authoritative hierarchy (top-level or sub-domain)
    return [d for d in domains if d in _ALL_DOMAINS]


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="Generate domain_map.json")
    parser.add_argument("--force",  action="store_true",
                        help="Re-classify tables that already have an entry")
    parser.add_argument("--output", type=Path, default=OUT_PATH,
                        help="Destination JSON file (default: rag/domain_map.json)")
    args = parser.parse_args()

    settings = get_settings()
    model    = settings.ollama_render_model   # mistral by default

    with open(KB_PATH, encoding="utf-8") as f:
        kb: dict[str, dict] = json.load(f)

    # Load existing map if present
    domain_map: dict[str, list[str]] = {}
    if args.output.exists():
        with open(args.output, encoding="utf-8") as f:
            domain_map = json.load(f)

    tables_to_process = [
        (tname, entry)
        for tname, entry in kb["tables"].items()
        if args.force or tname not in domain_map
    ]

    if not tables_to_process:
        print("All tables already classified. Use --force to re-classify.")
        return

    print(f"Classifying {len(tables_to_process)} tables with model '{model}' …\n")

    updated = 0
    for i, (tname, entry) in enumerate(tables_to_process, 1):
        try:
            domains = classify_table(tname, entry, model)
            if not domains:
                raise ValueError("LLM returned no valid domains")
            domain_map[tname] = domains
            updated += 1
            print(f"  [{i:>3}/{len(tables_to_process)}] {tname:<45} → {domains}")
        except Exception as exc:
            domain_map[tname] = []
            print(f"  [{i:>3}/{len(tables_to_process)}] {tname:<45} → FAILED: {exc}")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(domain_map, f, indent=2, ensure_ascii=False)

    print(f"\nDone. {updated}/{len(tables_to_process)} tables classified.")
    print(f"Saved to: {args.output}")


if __name__ == "__main__":
    main()
