

import os
import traceback
import json
import argparse

cat_code_lookup_json  = {}


def load_cat_code_lookup(fname : str):
    rval = {}
    with open( fname, "r") as file: 
        fcontent = file.read()
        rval = json.loads( fcontent )
    return rval        

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Convert cat_code_lookup.txt (CSV) to JSON")
    parser.add_argument("--input", default="input/cat_code_lookup.txt", help="Path to txt file")
    parser.add_argument("--output", default="cat_code_lookup.json", help="Path where to save the json")

    args = parser.parse_args()

    with open( args.input, "r") as file: 
        fcontent = file.read()
        lines = fcontent.split('\n')
        for line in lines:
            try:
                l = line.strip()
                entry = l.split(",")
                parent_table_name = entry[0]

                if not parent_table_name in cat_code_lookup_json:
                    cat_code_lookup_json[parent_table_name]  = {}

                branch = cat_code_lookup_json[parent_table_name] 
                cat_code = entry[1]
                leaf = entry[2]
                branch[cat_code] = leaf
                            
            except:
                traceback.print_exc()
                pass

        jsonstr = json.dumps( cat_code_lookup_json, indent=4, sort_keys=True)
        with open( args.output, "w") as outfile: 
            outfile.write( jsonstr )
            print( jsonstr )

        

