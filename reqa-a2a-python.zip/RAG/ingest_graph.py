"""
Build (idempotently) the schema graph in Neo4j from KB_full_update.json.

Graph model -- deliberately ADDITIVE to the existing cat_code-typed graph
already present in the Neo4j volume (it uses relationship types like
[:ACTEV]; this script never touches those):

    (:Table {name, label, domain, description, primary_key})
        -[:FK {name, own_column, related_column, join_on,
               cardinality, fk_type, role}]->
    (:Table)

Direction: child -[:FK]-> parent (role == "child_of"); the reverse role
("parent_of") is skipped since it describes the same physical FK from the
other side -- storing both would double every edge. Queries traverse
undirected anyway.

Idempotent: MERGE everywhere -- run it after every KB update, it only
creates what's missing and refreshes edge properties.

Usage (from the repo root, inside the api container or any env with the
`neo4j` package and network access to the neo4j-server container):

    python RAG/ingest_graph.py
    python RAG/ingest_graph.py --kb RAG/KB_full_update.json --wipe-fk
"""
import argparse
import json
import os

from neo4j import GraphDatabase

NEO4J_URI = os.getenv("NEO4J_URI", "bolt://neo4j-server:7687")
NEO4J_USER = os.getenv("NEO4J_USER", "neo4j")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD", "secretpassword")


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--kb", default="RAG/KB_full_update2.json")
    parser.add_argument("--wipe-fk", action="store_true",
                        help="Delete existing :FK edges and :Table nodes first "
                             "(full rebuild of THIS layer only; the legacy "
                             "cat_code graph is untouched)")
    args = parser.parse_args()

    with open(args.kb, encoding="utf-8") as f:
        kb = json.load(f)

    driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))
    driver.verify_connectivity()
    print(f"Connected to {NEO4J_URI}")

    with driver.session() as session:
        if args.wipe_fk:
            session.run("MATCH (:Table)-[r:FK]->(:Table) DELETE r")
            session.run("MATCH (t:Table) DELETE t")
            print("Wiped existing :Table/:FK layer")

        session.run("CREATE INDEX table_name IF NOT EXISTS FOR (t:Table) ON (t.name)")

        # -- nodes ---------------------------------------------------------
        n_nodes = 0
        for name, entry in kb.items():
            session.run(
                """
                MERGE (t:Table {name: $name})
                SET t.label = $label,
                    t.domain = $domain,
                    t.description = $description,
                    t.primary_key = $pk
                """,
                name=name,
                label=entry.get("label", ""),
                domain=(entry.get("domain") or [""])[0],
                description=(entry.get("description") or "")[:300],
                pk=entry.get("primary_key", ""),
            )
            n_nodes += 1

        # -- FK edges (child_of only: one physical FK = one edge) ----------
        n_edges = n_skipped = 0
        for name, entry in kb.items():
            for rel in entry.get("relationships") or []:
                if rel.get("role") != "child_of":
                    continue
                target = rel.get("related_table")
                if not target or target not in kb:
                    n_skipped += 1
                    continue
                session.run(
                    """
                    MATCH (child:Table {name: $child}), (parent:Table {name: $parent})
                    MERGE (child)-[r:FK {name: $rel_name}]->(parent)
                    SET r.own_column = $own_col,
                        r.related_column = $rel_col,
                        r.join_on = $join_on,
                        r.cardinality = $card,
                        r.fk_type = $fk_type
                    """,
                    child=name, parent=target,
                    rel_name=rel.get("name", f"{name}__{target}"),
                    own_col=rel.get("own_column", ""),
                    rel_col=rel.get("related_column", ""),
                    join_on=rel.get("join_on", ""),
                    card=rel.get("cardinality", ""),
                    fk_type=rel.get("type", ""),
                )
                n_edges += 1

        counts = session.run(
            "MATCH (t:Table) WITH count(t) AS n "
            "MATCH (:Table)-[r:FK]->(:Table) RETURN n, count(r) AS e"
        ).single()

    driver.close()
    print(f"Upserted {n_nodes} tables, {n_edges} FK edges "
          f"({n_skipped} skipped: target table not in KB)")
    if counts:
        print(f"Graph now holds: {counts['n']} :Table nodes, {counts['e']} :FK edges")


if __name__ == "__main__":
    main()
