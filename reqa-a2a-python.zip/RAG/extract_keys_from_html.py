
import sys
from bs4 import BeautifulSoup
import re

import sys
import argparse
from pathlib import Path

import json






def write_output_file(fname, content):
    with open( ".output/" + fname, "w") as file:        
        file.write(content)

HTML_SOURCE_FOLDER="input/calian-vcci-database-description"
FK_RE = re.compile( r"FOREIGN KEY \(([\w]*)\)\W*REFERENCES\W([\w]*)\(([\w]*)\)")
PK_RE = re.compile( r"PRIMARY KEY \(([\w]*)\)")
def extract_foreignkeys_from_html(fname = HTML_SOURCE_FOLDER ):
    fkdict = {}

    with open(fname, 'r', encoding='utf-8') as htmlfile:
        html = htmlfile.read()
        #   print(html)
        soup = BeautifulSoup(html, 'html.parser')

        tbl = soup.find_all("div", attrs={"class": "objectname"})
        for i in range( 0, len(tbl) ):
            try:
                section = tbl[i]
                
                text = section.get_text()
                table_name = section.get_text().replace("Entity: ", "")
                #print( "'" + table_name + "'"  )
                

                i0 = html.index(text)            
                if (i < len(tbl)-1):                    
                    next_section = tbl[i+1] 
                    next_text = next_section.get_text()
                    i1 = html.index(next_text)                            
                    text_block = html[i0:i1]
                else:
                    text_block = tbl[i0:]

                if "<A NAME=" in text_block:
                    i1 = text_block.index("<A NAME=")
                    text_block = text_block[:i1]

                #print( text_block )
                block_soup = BeautifulSoup(text_block, 'html.parser')
                details = block_soup.find_all("div", attrs={"class": "details"})
                for det in details:
                    #print (str(det))
                    txt = det.get_text()                
                    if txt == "Attributes:":
                        pass
                    elif txt == "Attributes:":
                        pass
                    elif txt == "Relationships:":                    
                        pass                                       
                    elif txt == "Constraints:":
                        table = det.find_next("table")
                        field_data = table.find_all("td", attrs={"class": "fielddata"})
                        for field in field_data:  
                            #print(str(field))
                            if "PRIMARY KEY" in str(field) :   
                                if not table_name in fkdict.keys():
                                    fkdict[table_name] = {}   
                                m = PK_RE.search( str(field) )
                                pkid = m.group(1)    
                                fkdict[table_name]['pk'] =  pkid          

                            if "FOREIGN KEY" in str(field) :                            
                                if not table_name in fkdict.keys():
                                    fkdict[table_name] = {}
                              #  print( str(field) )
                                m = FK_RE.search( str(field) )

                                fkid = m.group(1)
                                fkref = m.group(2)
                                fkrefid = m.group(3)

                                if not "fk" in fkdict[table_name]:
                                    fkdict[table_name]["fk"] = []
                               # print(  fkid + " " + fkref + " " + fkrefid )
                                new_key = { fkid : [fkref, fkrefid] }                                
                                fkdict[table_name]['fk'].append(new_key)

                                
            except:
                pass

            #return fkdict   # Skip after the 1st element for Debugging

    return fkdict
                                

def extract_keys_from_html(fname = HTML_SOURCE_FOLDER):
  
    fname = fname + "/" + "entd.html"
    # Write the files to output
    fkdict = extract_foreignkeys_from_html(fname)
    #print( "Num Tables with FK=" + str(len(fkdict.items())) );

    pkdict = {}
    for key, val in fkdict.items():
        if "pk" in val:
            pkdict[key] = val["pk"]        

    referenced_by_dict = {}
    
    for key, val in fkdict.items():
        #    "act_ot_assoc": 
        #       {"fk": [
        #           {"act_id": ["act", "act_id" ] },
            #       {"obj_type_id": ["obj_type", "obj_type_id" ] }
        #       ], "pk": "act_ot_assoc_ix"
        #}
      #  print(  "KeyVal=" +  str(key) + ":" + str(val) )
        if "fk" in val.keys():            
            try:                    
                for fk in val["fk"] :  
                    print( key + "->" + str(fk) )
                    # example fk={"act_id": ["act", "act_id" ] }
                    for fkk, fkv in fk.items():                    
                        refs = fkv
                        ref_table = refs[0]
                        ref_col = refs[1]

                        if not ref_table in referenced_by_dict:
                            referenced_by_dict[ ref_table ] = []    
                    keycol = key + "." + ref_col
                    if not keycol in referenced_by_dict[ref_table]:
                        referenced_by_dict[ref_table].append( keycol )
                    
            except Exception as e:
                traceback.print_exc()
                            
    num_referenced = len(referenced_by_dict.items())
    print( f"There are {num_referenced} tables that are referenced by others"  )    


    #sys.exit(0)
    return pkdict, fkdict, referenced_by_dict





if __name__ == "__main__":
    extract_keys_from_html()
