import json

#
# Todo: Is this file used ? 
#
#



"""
 {
            "name": "porter_route",
            "label": "Porter Route",
            "description": "Porter Route",
            "primary_key": "proute_idx",
            "columns": {
                "proute_idx": {
                    "description": "proute idx"
                },
                "proute_src_endpoint_idx": {
                    "description": "proute src endpoint idx"
                },
                "proute_dst_endpoint_idx": {
                    "description": "proute dst endpoint idx"
                },
                "route_code": {
                    "description": "route code"
                }
            },
            "referenced_by": [
                "porter_route_porter_filter_assoc.proute_idx"
            ]
        },
"""

with open("RAG/all_tables_descriptions.json", "r", encoding="utf-8") as f:
    data = json.load(f)

#print(type(data["tables"]))
#print(data["tables"])
# "primary_key": doc["primary_key"],
#  "referenced_by": doc["referenced_by"]

data_json = dict()

for doc in data["tables"]:

    data_json[doc["name"]] = {"label": doc["label"], "description": doc["description"], 
                          "columns": doc["columns"]}
    if "primary_key" in doc.keys():

        data_json[doc["name"]]["primary_key"] = doc["primary_key"]

    if "referenced_by" in doc.keys():

        data_json[doc["name"]]["referenced_by"] = doc["referenced_by"]

    

    

#print(data_json)

"""

import json

with open("RAG/KB_full.json", "w", encoding="utf-8") as f:
    json.dump(data_json, f, ensure_ascii=False, indent=4)

"""

data["tables"] = data_json

#print(data["tables"])

with open("RAG/KB_full.json", "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=4)