"""
Generate descriptions.json from three source files:
  - tables.json   : table metadata (nom, label, description, primary_key, business_rule, referenced_by)
  - columns.json  : column descriptions per table
  - values.json   : allowed code values per column per table

Optionally, pass a DDL file to auto-detect referenced_by from FOREIGN KEY constraints.
DDL values override whatever is written in tables.json.

Usage:
    python build_descriptions.py
    python build_descriptions.py --ddl schema.sql
    python build_descriptions.py --ddl schema.sql --out custom_output.json
"""

from __future__ import annotations
import argparse
import json
import re
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).parent


def load(filename: str) -> dict:
    with open(HERE / filename, encoding="utf-8") as f:
        return json.load(f)


def parse_fk_from_ddl(ddl_path: str) -> dict[str, list[str]]:
    """
    Parse a MariaDB/MySQL DDL file and return a map:
        referenced_table -> ["child_table.fk_column", ...]

    Handles both inline and ALTER TABLE forms:
        FOREIGN KEY (col) REFERENCES parent(pk)
        CONSTRAINT fk_name FOREIGN KEY (col) REFERENCES parent(pk)
        ALTER TABLE child ADD [CONSTRAINT ...] FOREIGN KEY (col) REFERENCES parent(pk);
    """
    text = Path(ddl_path).read_text(encoding="utf-8")

    # Remove single-line comments
    text = re.sub(r"--[^\n]*", " ", text)
    # Remove block comments
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.DOTALL)

    result: dict[str, list[str]] = defaultdict(list)

    # --- Inline FK inside CREATE TABLE blocks ---
    # Capture each CREATE TABLE block
    create_blocks = re.finditer(
        r"CREATE\s+TABLE\s+`?(\w+)`?\s*\((.+?)\)\s*(?:ENGINE|;)",
        text,
        re.IGNORECASE | re.DOTALL,
    )
    for m in create_blocks:
        child_table = m.group(1).lower()
        body = m.group(2)

        fk_pattern = re.compile(
            r"(?:CONSTRAINT\s+`?\w+`?\s+)?"
            r"FOREIGN\s+KEY\s*\(\s*`?(\w+)`?\s*\)"
            r"\s*REFERENCES\s+`?(\w+)`?\s*\(\s*`?(\w+)`?\s*\)",
            re.IGNORECASE,
        )
        for fk in fk_pattern.finditer(body):
            fk_col    = fk.group(1).lower()
            ref_table = fk.group(2).lower()
            entry = f"{child_table}.{fk_col}"
            if entry not in result[ref_table]:
                result[ref_table].append(entry)

    # --- ALTER TABLE ... ADD FOREIGN KEY ---
    alter_pattern = re.compile(
        r"ALTER\s+TABLE\s+`?(\w+)`?\s+ADD\s+"
        r"(?:CONSTRAINT\s+`?\w+`?\s+)?"
        r"FOREIGN\s+KEY\s*\(\s*`?(\w+)`?\s*\)"
        r"\s*REFERENCES\s+`?(\w+)`?\s*\(\s*`?(\w+)`?\s*\)",
        re.IGNORECASE,
    )
    for m in alter_pattern.finditer(text):
        child_table = m.group(1).lower()
        fk_col      = m.group(2).lower()
        ref_table   = m.group(3).lower()
        entry = f"{child_table}.{fk_col}"
        if entry not in result[ref_table]:
            result[ref_table].append(entry)

    return dict(result)


def build(
    tables_data: dict,
    columns_data: dict,
    values_data: dict,
    fk_map: dict[str, list[str]] | None = None,
) -> dict:
    columns_map: dict[str, dict] = columns_data.get("columns", {})
    values_map:  dict[str, dict] = values_data.get("values", {})

    tables_out = []
    for tbl in tables_data.get("tables", []):
        nom = tbl["nom"]

        # allowed_values: keep only the code keys (not descriptions)
        allowed_values = {
            col: list(codes.keys())
            for col, codes in values_map.get(nom, {}).items()
        }

        # referenced_by: DDL takes priority over tables.json when provided
        if fk_map is not None:
            referenced_by = sorted(fk_map.get(nom, []))
        else:
            referenced_by = tbl.get("referenced_by", [])

        tables_out.append({
            "nom":            nom,
            "label":          tbl.get("label", ""),
            "description":    tbl.get("description", ""),
            "primary_key":    tbl.get("primary_key", ""),
            "columns":        columns_map.get(nom, {}),
            "allowed_values": allowed_values,
            "referenced_by":  referenced_by,
        })

    # Preserve metadata from tables.json but upgrade version
    metadata = dict(tables_data.get("metadata", {}))
    metadata["version"] = "2.0"
    metadata.setdefault("domains", [
        "Personnel & Organisation", "Operations", "Intelligence",
        "Equipment / Materiel", "Logistics", "Armament", "Training",
        "Communications", "Medical & Health", "Cyber & IS Security",
        "Finance & Budget", "Legal",
    ])
    metadata["description"] = (
        "Relational database for the armed forces information system. "
        "All tables, columns, and values use abbreviated or codified naming "
        "for operational security. This file is the data dictionary for RAG "
        "systems and SQL query generation."
    )

    return {
        "metadata":       metadata,
        "conventions":    _conventions(),
        "tables":         tables_out,
        "business_rules": _business_rules(),
        "example_queries": [],
    }


def _conventions() -> dict:
    return {
        "column_prefix_abbreviations": {
            "id_":   "Unique identifier (primary or foreign key)",
            "dat_":  "Date or timestamp field",
            "lib_":  "Full label or title",
            "cod_":  "Short code or external alphanumeric identifier",
            "typ_":  "Type or category",
            "stat_": "Current status or state",
            "niv_":  "Numeric or ordinal level",
            "num_":  "Serial number or reference",
            "nbr_":  "Count (integer quantity)",
            "qte":   "Quantity",
            "cout":  "Financial cost",
            "nmat":  "Military matriculation number",
            "ddn":   "Date of birth",
            "eff_eng": "Engaged headcount",
            "prio_": "Priority level",
        },
        "generic_status_values": {
            "ACT":    "Active / in force",
            "INACT":  "Inactive / suspended",
            "TERM":   "Terminated / closed",
            "ENCOURS": "In progress / ongoing",
            "PLAN":   "Planned",
            "DISP":   "Available / on hand",
            "INDISPO": "Unavailable",
            "PANNE":  "Broken / out of service",
            "OPER":   "Operational",
            "VAL":    "Validated / approved",
            "REF":    "Refused / rejected",
        },
        "priority_values": {
            "1": "Immediate",
            "2": "Urgent",
            "3": "Normal",
            "4": "Routine",
        },
        "security_classification": {
            "NR":  "Non-classified",
            "C":   "Confidential",
            "S":   "Secret",
            "TRS": "Top Secret",
        },
    }


def _business_rules() -> list:
    return [
        {
            "rule": "Current assignment of a person",
            "sql_pattern": (
                "JOIN affect a ON p.id_personnel=a.id_personnel "
                "JOIN unite u ON a.id_unit=u.id_unit "
                "WHERE a.stat_affect='ACT' AND a.end_date IS NULL"
            ),
        },
        {
            "rule": "Active military personnel",
            "sql_pattern": "WHERE p.status='ACT'",
        },
        {
            "rule": "Ongoing operations",
            "sql_pattern": "WHERE o.operation_status='ENCOURS'",
        },
        {
            "rule": "Operational equipment",
            "sql_pattern": "WHERE m.equipment_status='OPER'",
        },
        {
            "rule": "Valid qualifications",
            "sql_pattern": (
                "WHERE pq.stat_qual='VAL' "
                "AND (pq.expiry_date IS NULL OR pq.expiry_date > CURRENT_DATE)"
            ),
        },
        {
            "rule": "Available ammunition stock",
            "sql_pattern": (
                "WHERE sm.stat_stk_mun='DISP' "
                "AND (sm.expiry_date IS NULL OR sm.expiry_date > CURRENT_DATE)"
            ),
        },
        {
            "rule": "Active IS/cyber access",
            "sql_pattern": (
                "WHERE stat_acces='ACT' "
                "AND (end_date IS NULL OR end_date > CURRENT_DATE)"
            ),
        },
    ]


def main() -> None:
    parser = argparse.ArgumentParser(description="Build descriptions.json from source files.")
    parser.add_argument("--out", default="descriptions.json", help="Output filename (default: descriptions.json)")
    parser.add_argument("--ddl", default=None, help="Path to DDL SQL file to auto-detect referenced_by from FOREIGN KEYs")
    args = parser.parse_args()

    tables_data  = load("tables.json")
    columns_data = load("columns.json")
    values_data  = load("values.json")

    fk_map = None
    if args.ddl:
        fk_map = parse_fk_from_ddl(args.ddl)
        total_refs = sum(len(v) for v in fk_map.values())
        print(f"DDL parsed: {len(fk_map)} referenced tables, {total_refs} foreign keys found.")

    result = build(tables_data, columns_data, values_data, fk_map=fk_map)

    out_path = HERE / args.out
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    n = len(result["tables"])
    print(f"Written {out_path} — {n} tables.")


if __name__ == "__main__":
    main()
