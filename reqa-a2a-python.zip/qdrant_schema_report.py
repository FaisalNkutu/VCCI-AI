from html import escape
from qdrant_client import QdrantClient
from config import settings


def main():
    client = QdrantClient(
        host=settings.QDRANT_HOST,
        port=settings.QDRANT_PORT,
    )

    points, _ = client.scroll(
        collection_name=settings.QDRANT_COLLECTION,
        limit=10_000,
        with_payload=True,
        with_vectors=False,
    )

    tables = []
    for point in points:
        payload = point.payload or {}
        tables.append({
            "table": payload.get("table", "UNKNOWN"),
            "domain": payload.get("domain", "General"),
            "columns": payload.get("columns", []),
            "foreign_keys": payload.get("foreign_keys", []),
            "description": payload.get("description", ""),
        })

    tables.sort(key=lambda x: x["table"])

    html = f"""
<!DOCTYPE html>
<html>
<head>
  <title>Qdrant Schema Report</title>
  <style>
    body {{ font-family: Arial, sans-serif; margin: 30px; }}
    h1 {{ margin-bottom: 5px; }}
    .summary {{ background: #f3f3f3; padding: 15px; border-radius: 8px; margin-bottom: 25px; }}
    .table-card {{ border: 1px solid #ddd; border-radius: 8px; padding: 15px; margin-bottom: 20px; }}
    .table-name {{ font-size: 20px; font-weight: bold; }}
    .domain {{ color: #666; margin-bottom: 10px; }}
    table {{ border-collapse: collapse; width: 100%; margin-top: 10px; }}
    th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
    th {{ background: #f7f7f7; }}
    pre {{ background: #f8f8f8; padding: 10px; overflow-x: auto; }}
  </style>
</head>
<body>
  <h1>Qdrant Schema Report</h1>

  <div class="summary">
    <strong>Total tables stored in Qdrant:</strong> {len(tables)}
  </div>
"""

    for t in tables:
        html += f"""
  <div class="table-card">
    <div class="table-name">{escape(t["table"])}</div>
    <div class="domain">Domain: {escape(t["domain"])}</div>

    <strong>Columns: {len(t["columns"])}</strong>
    <table>
      <tr>
        <th>Column Name</th>
        <th>Type</th>
        <th>Nullable</th>
      </tr>
"""

        for col in t["columns"]:
            html += f"""
      <tr>
        <td>{escape(str(col.get("name", "")))}</td>
        <td>{escape(str(col.get("type", "")))}</td>
        <td>{escape(str(col.get("nullable", "")))}</td>
      </tr>
"""

        html += """
    </table>
"""

        if t["foreign_keys"]:
            html += "<p><strong>Foreign Keys:</strong></p><ul>"
            for fk in t["foreign_keys"]:
                html += f"<li>{escape(str(fk))}</li>"
            html += "</ul>"

        html += f"""
    <p><strong>Description stored in Qdrant:</strong></p>
    <pre>{escape(t["description"])}</pre>
  </div>
"""

    html += """
</body>
</html>
"""

    output_file = "qdrant_schema_report.html"
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"Report generated: {output_file}")
    print(f"Total tables: {len(tables)}")


if __name__ == "__main__":
    main()