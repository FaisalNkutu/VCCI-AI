﻿import json

upd = json.load(open("RAG/KB_full_update.json", encoding="utf-8"))
upd = upd.get("tables", upd)
full = json.load(open("RAG/KB_full.json", encoding="utf-8"))
full = full.get("tables", full)

scaffolded = sorted(set(full) - set(upd))
print(f"{len(scaffolded)} tables echafaudees :")
for t in scaffolded:
    print("  ", t)

print()
print("=== Qualite des entrees echafaudees (3 exemples) ===")
for t in scaffolded[:3]:
    e = full[t]
    desc = e.get("description", "")
    cols = len(e.get("columns", {}))
    rels = len(e.get("relationships", []))
    sq = len(e.get("sample_queries", []))
    dom = e.get("domain", [])
    print(f"{t}: desc={desc!r}, cols={cols}, rels={rels}, sample_queries={sq}, domain={dom}")
