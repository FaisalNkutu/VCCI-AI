@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo MIDAS Build Approval Diagnostics - V4.1
where pnpm
pnpm --version
echo.
echo Explicit version-pinned MIDAS dependency script approvals:
type "midas-plan-midas#296\midas-frontend\pnpm-workspace.yaml"
echo.
echo Build scripts are allowed only for listed package versions; other dependencies remain blocked.
echo Private Artifactory access must still be configured.
echo.
pause
endlocal
