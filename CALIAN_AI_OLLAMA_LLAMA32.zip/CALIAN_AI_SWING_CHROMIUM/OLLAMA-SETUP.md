# CALIAN AI — Ollama Llama 3.2 Auto Selection

## One-time setup
1. Install Ollama from https://ollama.com/download and ensure it is running.
2. PowerShell: `ollama pull llama3.2`
3. Test: `ollama run llama3.2` (exit with `/bye`).
4. In `calian-ai-angular-material`, if `.env` already exists, copy the new OLLAMA_* variables from `.env.example` into `.env`. Do not overwrite existing service credentials.

## Run
1. Start your existing Python and AI Core services as before.
2. From `calian-ai-angular-material`, run `npm install` (if needed) and `npm run dev`.
3. From `swing-host`, run `mvn compile exec:java`.
4. Select Intelligent Auto Select and send `Translate hello into French` or `Roll two dice`.
5. Check the API response `method: ollama-llama3.2` in network diagnostics.

## Routing behavior
The Express `/api/router/select` endpoint now calls local Ollama with discovered trusted agents and validates the returned agent ID against the trusted list. It falls back to the original metadata router when Ollama is unreachable or returns an invalid ID. The model's confidence field is not used; `0.8` is a display placeholder, not a calibrated probability. Manual selection, A2A execution, AI Core execution, Angular and Swing are unchanged.

## Optional Python router
The `python-router-ollama` directory includes compatible replacement `agent_router.py`, `router_api.py`, `router_models.py`, and `main.py` from your uploads. To enable Ollama routing for callers using the Python `/router/select` endpoint directly, back up your Python service files and replace the corresponding modules with these. This is NOT required for Angular auto-select because Express handles it. The Python `/router/select` legacy endpoint still restricts choices to discovered North agents, as in your supplied main.py.

## Security and limitations
Keep Ollama bound to localhost; do not expose its port publicly. Only candidate metadata and user request text are sent to Ollama locally. AI Core availability and routing accuracy depend on registered agent metadata. Fallback to metadata is logged in the Express terminal. This build has not been tested against your running services.
