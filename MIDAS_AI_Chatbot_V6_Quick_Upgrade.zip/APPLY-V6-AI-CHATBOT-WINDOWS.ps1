# V6 source-only upgrade. Never stops running processes or changes registry credentials.
param([string]$ProjectRoot = '')
$ErrorActionPreference = 'Stop'
$files = @(
 'midas\midas-frontend\src\app\components\calian-ai\midas-calian-copilot.component.ts',
 'midas\midas-frontend\src\app\components\calian-ai\midas-tool-gateway.ts',
 'midas\midas-frontend\src\app\components\calian-ai\calian-ai.component.ts',
 'midas\midas-frontend\src\app\components\selection\selection.component.ts',
 'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\midas-bridge.ts',
 'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\app.component.ts',
 'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\app.component.html',
 'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\video-center.component.html',
 'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\index.html',
 'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\public\manifest.webmanifest'
)
$hostFile='midas\midas-frontend\src\app\components\calian-ai\midas-calian-copilot.component.ts'
$chatFile='Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\app.component.ts'
Write-Host 'MIDAS + AI Chatbot V6 source upgrade' -ForegroundColor Cyan
Write-Host 'Does not stop any services, install dependencies, alter ports or touch stored credentials.'
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
  $search = @((Join-Path $env:USERPROFILE 'Downloads'), (Get-Location).Path) | Select-Object -Unique
  $roots = New-Object System.Collections.Generic.List[string]
  foreach($directory in $search) {
    if (!(Test-Path -LiteralPath $directory)) {continue}
    $dirs = @((Get-Item -LiteralPath $directory)) + @(Get-ChildItem -LiteralPath $directory -Directory -Recurse -Depth 3 -ErrorAction SilentlyContinue)
    foreach($d in $dirs) {
      if ((Test-Path -LiteralPath (Join-Path $d.FullName $hostFile)) -and (Test-Path -LiteralPath (Join-Path $d.FullName $chatFile))) {
        if (!$roots.Contains($d.FullName)) {$roots.Add($d.FullName)}
      }
    }
  }
  if (!$roots.Count) {throw 'No extracted MIDAS + AI Chatbot source root found. Extract the full package or use -ProjectRoot.'}
  Write-Host 'Select the source folder corresponding to your RUNNING MIDAS instance:' -ForegroundColor Yellow
  for($i=0;$i -lt $roots.Count;$i++){Write-Host ('[{0}] {1}' -f ($i+1),$roots[$i])}
  $answer=Read-Host 'Enter installation number (blank cancels)'
  if($answer -notmatch '^\d+$' -or [int]$answer -lt 1 -or [int]$answer -gt $roots.Count){throw 'Cancelled: no changes made.'}
  $ProjectRoot=$roots[[int]$answer-1]
}
$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
if (!(Test-Path -LiteralPath (Join-Path $ProjectRoot $hostFile)) -or !(Test-Path -LiteralPath (Join-Path $ProjectRoot $chatFile))) {
  throw 'The selected folder does not contain both expected MIDAS and AI Chatbot projects.'
}
$hostText = [IO.File]::ReadAllText((Join-Path $ProjectRoot $hostFile))
$chatText = [IO.File]::ReadAllText((Join-Path $ProjectRoot $chatFile))
if (!$hostText.Contains('MIDAS_CALIAN_V1') -or !$chatText.Contains('proposeMidasCommand')) {
  throw 'Unexpected source: bridge signatures absent. Refusing to overwrite unrelated projects.'
}
if($hostText.Contains('midas-tool-gateway') -and $chatText.Contains('enrichedAgentQuery')) {
  Write-Host 'V6 code already appears to be installed in this folder. Confirm the browser is using THIS instance.' -ForegroundColor Yellow
  exit 0
}
foreach($f in $files){
  $source=Join-Path $PSScriptRoot (Join-Path 'PATCH' $f)
  if (!(Test-Path -LiteralPath $source)) {throw ('Missing patch file: '+$f)}
  if ($f -notlike '*midas-tool-gateway.ts' -and !(Test-Path -LiteralPath (Join-Path $ProjectRoot $f))) {throw ('Missing expected target file: '+$f)}
}
Write-Host ('Selected source: '+$ProjectRoot) -ForegroundColor Cyan
$ok=Read-Host 'Back up source files and apply V6 to this project? Type Y to continue'
if($ok -notin @('y','Y')) {Write-Host 'Cancelled.';exit 0}
$backup=Join-Path $ProjectRoot ('V6_BACKUP_'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
foreach($f in $files){
  $dest=Join-Path $ProjectRoot $f
  if(Test-Path -LiteralPath $dest){
    $backupTarget=Join-Path $backup $f
    New-Item -ItemType Directory -Path (Split-Path -Parent $backupTarget) -Force | Out-Null
    Copy-Item -LiteralPath $dest -Destination $backupTarget -ErrorAction Stop
  }
}
try{
  foreach($f in $files){
    $dest=Join-Path $ProjectRoot $f
    New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force | Out-Null
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot (Join-Path 'PATCH' $f)) -Destination $dest -Force -ErrorAction Stop
    Write-Host ('Updated: '+$f) -ForegroundColor Green
  }
}catch{
  Write-Warning 'Patch failed. Restoring all existing files from backup.'
  foreach($f in $files){
    $backupFile=Join-Path $backup $f
    $dest=Join-Path $ProjectRoot $f
    if(Test-Path -LiteralPath $backupFile){Copy-Item -LiteralPath $backupFile -Destination $dest -Force}
    elseif(Test-Path -LiteralPath $dest){Remove-Item -LiteralPath $dest -Force}
  }
  throw
}
Write-Host ('Backup folder: '+$backup) -ForegroundColor Cyan
Write-Host 'After Angular recompiles, refresh both MIDAS and the AI Chatbot browser window using Ctrl+Shift+R.' -ForegroundColor Green
Write-Host 'Look for AI Chatbot V6, Width slider, and Include MIDAS context in AI queries.' -ForegroundColor Yellow
Write-Host 'If missing, the running browser uses a different source tree/port.' -ForegroundColor Yellow
