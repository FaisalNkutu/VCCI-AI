# V6 Quick Upgrade — Existing V5.3 Installations

Download, extract all files, run `APPLY-V6-AI-CHATBOT-WINDOWS.bat`, select the **actual source directory** being served on your running MIDAS/AI Chatbot ports, and type `Y` to confirm.

This updates only MIDAS and AI Chatbot source files. It keeps your existing installed dependencies, private registry, data source setup, AI agents, automatic port selection, live video support, and external services untouched. It will create a timestamped `V6_BACKUP_...` folder within the selected source root. Do not run directly inside ZIP preview.

Look for the **AI Chatbot** title, **Width** slider and **Include MIDAS context in AI queries** checkbox after Angular recompiles and a browser hard refresh. If you see the old UI, the browser points to a different running instance/source folder.

Read `README-V6-START-HERE.md` included here for exact features and limits. A connected MIDAS data source and operational AI agents remain necessary for live analytical answers. This patch does not install private npm dependencies, stop any apps or add production SSO/auditing.
