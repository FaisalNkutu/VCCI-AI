# Integration status — explicit limitations

The standalone Swing chatbot retains Python A2A 1.0 support and its working `/agents` discovery. It now also supports an **optional HTTP AI Core registry** via `AICORE_REGISTRY_URL`. The registry may return either `{"agents":[{"name":"...","endpoint":"https://...","commands":[]}]}` or `{"commandList":{"name":[]},"agentURLs":{"name":"https://..."}}`. HTTP AI Core endpoints receive JSON `{ "message": "...", "contextId": "...", "context": {} }`.

**This is not a proven fully working RabbitMQ integration.** The source supplied does not include the `RabbitMQComm` listener contract, live broker connection settings, or AI Core wire protocol implementation. The optional HTTP registry requires an existing compatible HTTP bridge. The actual AI Core agent endpoint must accept the request format above; some agents may use a different protocol. The provided Paradigm callback adapter remains available for a host that issues `AIService.LIST`.

Run on the user's Windows machine with installed Calian Maven dependencies: `mvn clean compile` then `mvn exec:java`. This package has not been end-to-end tested against the user's AI Core environment.
