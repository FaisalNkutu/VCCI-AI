# REQA A2A: unblock the SQL pipeline, preserve JSON skill support.
# One-time live container patch. Docker image recreation may overwrite this.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$container = 'reqa-a2a'
$source = Join-Path $PSScriptRoot 'a2a_nl2sql_agent_FIXED.py'
$backupDir = Join-Path $HOME 'Downloads\REQA-A2A-Backups'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backup = Join-Path $backupDir "a2a_nl2sql_agent-before-nonblocking-$stamp.py"
$diagnostics = Join-Path $HOME "Downloads\REQA_A2A_AFTER_FIX_$stamp.txt"
$target = $null
$copied = $false
try {
    if (!(Test-Path -LiteralPath $source)) { throw "Source file missing: $source" }
    New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
    Write-Host '[1/5] Locating A2A container source...' -ForegroundColor Cyan
    $running = (& docker inspect -f '{{.State.Running}}' $container 2>&1 | Out-String).Trim()
    if ($LASTEXITCODE -ne 0 -or $running -ne 'true') { throw "Container $container is not running" }
    $finder = @'
import os,sys
for root in ['/app',os.getcwd(),'/code','/usr/src/app','/workspace']:
    p=os.path.join(root,'a2a_nl2sql_agent.py')
    if os.path.isfile(p):
        print(os.path.realpath(p)); break
else:
    sys.exit('Unable to find a2a_nl2sql_agent.py')
'@
    $result=@($finder | & docker exec -i $container python -)
    if ($LASTEXITCODE -ne 0) { throw 'Could not locate Python source in container' }
    $target=(@($result) | Where-Object { $_ -match '^/' } | Select-Object -First 1)
    if (!$target) { throw 'Container Python file path is missing' }
    $target=$target.Trim()
    Write-Host "FOUND: $target" -ForegroundColor Green

    Write-Host '[2/5] Backing up existing Python source...' -ForegroundColor Cyan
    & docker cp "${container}:$target" $backup
    if ($LASTEXITCODE -ne 0 -or !(Test-Path $backup)) { throw 'Backup failed; source not changed' }
    Write-Host "BACKUP SAVED: $backup" -ForegroundColor Green

    Write-Host '[3/5] Copying and verifying nonblocking patch...' -ForegroundColor Cyan
    & docker cp $source "${container}:$target"
    if ($LASTEXITCODE -ne 0) { throw 'Docker copy failed' }
    $copied=$true
    & docker exec $container python -m py_compile $target
    if ($LASTEXITCODE -ne 0) {
        & docker cp $backup "${container}:$target" | Out-Null
        $copied=$false
        throw 'Syntax validation failed; original Python source restored'
    }
    $verify = & docker exec $container python -c "from pathlib import Path; import sys; s=Path(sys.argv[1]).read_text(); assert 'await asyncio.to_thread' in s and '_normalize_a2a_user_text' in s; print('VERIFIED')" $target
    if ($LASTEXITCODE -ne 0 -or $verify -notmatch 'VERIFIED') { throw 'Patch content verification failed' }
    Write-Host 'SUCCESS: Source copied, syntax verified, previous text fix preserved.' -ForegroundColor Green

    Write-Host '[4/5] Restarting A2A and checking port 5022...' -ForegroundColor Cyan
    & docker restart $container | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Container restart failed' }
    $ready=$false
    for ($i=0;$i -lt 25;$i++) {
        $tcp=New-Object System.Net.Sockets.TcpClient
        try {
            $connect=$tcp.BeginConnect('127.0.0.1',5022,$null,$null)
            if ($connect.AsyncWaitHandle.WaitOne(1200)) { $tcp.EndConnect($connect); $ready=$true }
        } catch { } finally { $tcp.Dispose() }
        if ($ready) { break }
        Start-Sleep -Seconds 2
    }
    if (!$ready) { throw 'A2A port 5022 did not open' }
    Write-Host 'SUCCESS: Port 5022 listening.' -ForegroundColor Green

    Write-Host '[5/5] Testing a SELECT query through A2A (up to 180 seconds)...' -ForegroundColor Cyan
    $body=@{
        jsonrpc='2.0'
        id=[guid]::NewGuid().ToString()
        method='message/send'
        params=@{message=@{role='user';messageId=[guid]::NewGuid().ToString();parts=@(@{kind='text';text='SELECT * FROM context_ol_assoc LIMIT 1'})}}
    } | ConvertTo-Json -Depth 12 -Compress
    $response=Invoke-WebRequest 'http://127.0.0.1:5022/' -Method POST -ContentType 'application/json' -Body $body -UseBasicParsing -TimeoutSec 180
    $parsed=$response.Content | ConvertFrom-Json
    if ($parsed.error) { throw "A2A JSON-RPC error: $($parsed.error.message)" }
    $state=$parsed.result.status.state
    if (!$state) { $state='(not specified)' }
    Write-Host "HTTP STATUS: $($response.StatusCode); A2A TASK STATE: $state"
    if ($state -eq 'failed') {
        $parts=@($parsed.result.status.message.parts | Where-Object { $_.text } | ForEach-Object { $_.text })
        if ($parts.Count) { Write-Host ('AGENT ERROR: '+($parts -join ' | ')) -ForegroundColor Yellow }
        throw 'A2A execution returned a failed task'
    }
    if ($state -eq 'completed') { Write-Host 'SUCCESS: A2A task completed!' -ForegroundColor Green }
    else { Write-Host 'A2A request accepted. Inspect task details in CALIAN.AI.' -ForegroundColor Yellow }
} catch {
    Write-Host "NOT FULLY RESOLVED: $($_.Exception.Message)" -ForegroundColor Yellow
    if ($copied) { Write-Host 'The patch is installed; no further reinstall needed.' -ForegroundColor Cyan }
} finally {
    Write-Host 'Saving filtered diagnostics and recent Docker logs...' -ForegroundColor Cyan
    @("Recorded: $(Get-Date -Format o)","Container: $container","Python path: $target", "Backup: $backup", '---- Recent logs ----') | Out-File -FilePath $diagnostics -Encoding UTF8
    cmd.exe /d /c 'docker logs --tail 250 --timestamps reqa-a2a 2>&1' | Out-File -FilePath $diagnostics -Append -Encoding UTF8
    Write-Host "RESULT LOG: $diagnostics" -ForegroundColor Green
    Write-Host 'NOTE: Unsupported upgrade request is likely a separate WebSocket/probe issue. The SQL test above determines whether the query worked.' -ForegroundColor Yellow
    Write-Host 'NOTE: Recreating the Docker container may remove this patch. Update the source used to build the image before redeploying.' -ForegroundColor Yellow
}
