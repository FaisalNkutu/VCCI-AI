@echo off
setlocal
set "SCRIPT=%~dp0HOTFIX-MIDAS-CALIAN-V4-1-TO-V4-2-WINDOWS.ps1"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
set "EXITCODE=%ERRORLEVEL%"
echo.
if not "%EXITCODE%"=="0" ( echo Fix did not complete. See the message above. ) else ( echo Done. Check your existing MIDAS Angular console for recompilation. )
pause
exit /b %EXITCODE%
