import 'dotenv/config';
import express from 'express';
import { Readable } from 'node:stream';
import { WebSocketServer, WebSocket } from 'ws';
import { createServer } from 'node:http';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import { fileURLToPath } from 'node:url';
import {isDirectSql} from './db-natural-language';
import {classifyDbInput,executeReadOnlySql} from './direct-sql';
import {buildOriginalA2aMessage} from './db-a2a-dispatch';
import {queryViaReqaWebPipeline,formatReqaAnswer} from './reqa-web-query';
import {registerWhisperSpeech} from './speech-whisper';

const app = express();
app.use(express.json({limit:'1mb'}));
const PORT = Number(process.env.PORT || 8797);
const PYTHON_SERVICE_URL = process.env.PYTHON_SERVICE_URL || 'http://127.0.0.1:9999';
// The selection-only Ollama service is separate from the executable Python A2A service.
const OLLAMA_ROUTER_URL = process.env.OLLAMA_ROUTER_URL || 'http://127.0.0.1:9999';
const AI_CORE_REGISTRY_URL = process.env.AI_CORE_REGISTRY_URL || 'http://127.0.0.1:9801/api/ai-core/agents';
const PARADIGM_BRIDGE_TOKEN = process.env.PARADIGM_BRIDGE_TOKEN || '';
let paradigmSnapshot: {commandList: Record<string,string[]>;agentURLs:Record<string,string>} | null = null;
// Explicitly configured upstreams only; the browser cannot supply arbitrary target URLs.
const discoveredEndpoints = new Set<string>();
const allowed = new Set([PYTHON_SERVICE_URL,OLLAMA_ROUTER_URL,AI_CORE_REGISTRY_URL,...(process.env.AI_CORE_ENDPOINTS || '').split(',')].filter(Boolean).map(s=>s.replace(/\/+$/,'')));
function validate(urlText:string) {
 const u = new URL(urlText);
 if (!['http:','https:'].includes(u.protocol) || u.username || u.password || u.hash) throw new Error('Invalid upstream URL');
 if (!discoveredEndpoints.has(u.href) && ![...allowed].some(base => { const b=new URL(base); return u.origin===b.origin && (u.pathname===b.pathname || ((base===PYTHON_SERVICE_URL && ['/','/agents','/router/select'].includes(u.pathname)) || (base===OLLAMA_ROUTER_URL && u.pathname==='/router/select'))); })) throw new Error('Upstream not allowlisted');
 // No user-supplied upstreams, preventing arbitrary proxy access.
 return u;
}
async function forward(url:string,method:'GET'|'POST',payload?:unknown,stream=false){
 const target=validate(url);
 const response=await fetch(target,{method,headers:{Accept:stream?'text/event-stream, application/json':'application/json',...(method==='POST'?{'Content-Type':'application/json'}:{}),...(stream?{'A2A-Version':'1.0'}:{})},body:method==='POST'?JSON.stringify(payload):undefined,signal:AbortSignal.timeout(180000)});
 return response;
}
async function relay(res:express.Response,upstream:Response){
 res.status(upstream.status);
 res.setHeader('Content-Type',upstream.headers.get('content-type') || 'application/json');
 res.setHeader('Cache-Control','no-cache, no-transform');
 res.setHeader('X-Content-Type-Options','nosniff');
 if(!upstream.body){res.end();return;}
 const stream=Readable.fromWeb(upstream.body as any);
 stream.on('error',()=>res.end());
 stream.pipe(res);
}
const fail=(res:express.Response,e:unknown)=>res.status(502).json({error:e instanceof Error?e.message:String(e)});
// High-accuracy on-device speech-to-text. This replaces legacy Windows System.Speech,
// without touching REQA, A2A or any agent backend.
registerWhisperSpeech(app);

app.get('/api/health',(_req,res)=>res.json({status:'ready',instanceId:process.env.CALIAN_INSTANCE_ID||null,nlAdapterVersion:'8-reqa-web-ui-whisper-v2',nlAdapterEnabled:process.env.CALIAN_DB_NL_ENABLED!=='false',pythonService:PYTHON_SERVICE_URL,aiCoreConfigured:Boolean(AI_CORE_REGISTRY_URL)}));
// The local assistant executes against Ollama even when the optional Python router is offline.
const LOCAL_OLLAMA_AGENT={id:'local-ollama',name:'Local Ollama Assistant',description:'Local llama3.2 chat and translation',type:'north',streaming:false,configured:true,active:true,endpoint:'local',skills:[]};
app.get('/api/agents',async(_req,res)=>{
 try {
  const upstream=await forward(PYTHON_SERVICE_URL.replace(/\/+$/,'')+'/agents','GET');
  if(!upstream.ok)throw new Error(`Python router HTTP ${upstream.status}`);
  const data:any=await upstream.json();
  const agents=Array.isArray(data?.agents)?data.agents.filter((a:any)=>a?.id!=='local-ollama'):[];
  agents.unshift(LOCAL_OLLAMA_AGENT);
  res.json({...data,agents,count:agents.length});
 }catch{res.json({agents:[LOCAL_OLLAMA_AGENT],count:1,discovery:'local-ollama; Python router offline'});}
});
app.post('/api/ollama/chat',async(req,res)=>{
 const {message,context}=req.body||{};
 if(typeof message!=='string'||!message.trim()||message.length>16000){res.status(400).json({error:'Message must be 1-16000 characters'});return;}
 const history=Array.isArray(context?.conversationHistory)?context.conversationHistory.slice(-12):[];
 const system=[context?.systemInstructions,context?.userContext&&`User context: ${context.userContext}`,context?.taskContext&&`Task context: ${context.taskContext}`].filter(x=>typeof x==='string'&&x.trim()).join('\n');
 const messages=[...(system?[{role:'system',content:system}]:[]),...history.filter((t:any)=>['user','assistant'].includes(t?.role)&&typeof t.content==='string').map((t:any)=>({role:t.role,content:t.content.slice(0,16000)})),{role:'user',content:message}];
 try{
  const upstream=await fetch((process.env.OLLAMA_URL||'http://127.0.0.1:11434').replace(/\/+$/,'')+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({model:process.env.OLLAMA_MODEL||'llama3.2:latest',stream:false,messages}),signal:AbortSignal.timeout(180000)});
  if(!upstream.ok){res.status(502).json({error:`Ollama HTTP ${upstream.status}: ${(await upstream.text()).slice(0,500)}`});return;}
  const output:any=await upstream.json();
  const answer=output?.message?.content;
  if(typeof answer!=='string'||!answer.trim())throw new Error('Ollama returned no text');
  res.json({text:answer,model:output.model});
 }catch(e){res.status(502).json({error:'Cannot reach Ollama at '+(process.env.OLLAMA_URL||'http://127.0.0.1:11434')+': '+(e instanceof Error?e.message:String(e))});}
});
app.post('/api/paradigm/discovery',(req,res)=>{
 if (!PARADIGM_BRIDGE_TOKEN || req.get('X-Paradigm-Bridge-Token') !== PARADIGM_BRIDGE_TOKEN) {res.status(403).json({error:'Paradigm bridge token required'});return;}
 const {commandList,agentURLs}=req.body||{};
 if (!commandList || typeof commandList!=='object' || Array.isArray(commandList) || !agentURLs || typeof agentURLs!=='object' || Array.isArray(agentURLs)) {res.status(400).json({error:'Expected commandList and agentURLs objects'});return;}
 const safeCommands:Record<string,string[]>={}; const safeURLs:Record<string,string>={};
 for(const [id,values] of Object.entries(commandList)){if(id && Array.isArray(values))safeCommands[id]=values.filter((v):v is string=>typeof v==='string');}
 for(const [id,url] of Object.entries(agentURLs)){if(id && typeof url==='string')safeURLs[id]=url;}
 paradigmSnapshot={commandList:safeCommands,agentURLs:safeURLs};
 res.json({ok:true,count:new Set([...Object.keys(safeCommands),...Object.keys(safeURLs)]).size});
});
app.get('/api/ai-core/agents',async(_req,res)=>{try{const upstream=await forward(AI_CORE_REGISTRY_URL,'GET');if(!upstream.ok)throw new Error(`AI Core registry HTTP ${upstream.status}`);await relay(res,upstream);}catch(e){if(paradigmSnapshot){res.json(paradigmSnapshot);return;}fail(res,e);}});
// Route against the server-discovered registry, never caller-supplied endpoints.
// Ollama selects only among server-discovered executable agents. Never execute local-ollama placeholder.
const routeWords=(v:string)=>new Set((v.toLowerCase().match(/[a-z0-9]+/g)||[]).filter(w=>w.length>2));
const routeGroups=[['translate','translation','translator','french','spanish','german','language'],['dice','roll','random'],['database','sql','query','records','tables','table','db'],['speech','transcribe','transcription','audio','voice'],['social','media','linkedin','post','posts'],['json','structured','schema','format','fields']];
function expandRoute(v:string){const words=routeWords(v);for(const group of routeGroups)if(group.some(w=>words.has(w)))group.forEach(w=>words.add(w));return words;}
function overlaps(a:Set<string>,b:Set<string>){let n=0;for(const w of a)if(b.has(w))n++;return n;}
type RouteAgent={id:string;name:string;type:'north'|'aicore';description:string;commands:string[]};
// Route database queries to the registered DBAgent. CALIAN handles its
// direct SQL via MCP and English questions via the existing REQA v1 API.
function isDatabaseAgent(agent:RouteAgent):boolean {
 return agent.type==='aicore' && (
  /^(?:db[\s_-]*agent|database[\s_-]*agent)$/i.test(agent.id.trim()) ||
  /^(?:db[\s_-]*agent|database[\s_-]*agent)$/i.test(agent.name.trim())
 );
}
function isDatabaseRetrievalRequest(message:string):boolean {
 const text=message.trim();
 // Preserve existing SQL routing. Requests are still validated by DBAgent.
 if(/^(?:select|with|insert|update|delete|create|alter|drop|truncate)\b/i.test(text))return true;
 if(/^show\s+(?:tables?|databases?|columns?|index(?:es)?|create|full|status|variables|processlist)\b/i.test(text))return true;
 if(/^(?:describe|desc)\s+[a-z][a-z0-9_]*(?:\s*;)?$/i.test(text))return true;
 // High-confidence plain-English queries: explicit table / dataset / row language.
 const retrieval=/\b(?:show|list|display|find|fetch|retrieve|count|calculate|total|summarize|sum|average|group|filter|sort|compare|how many|how much|which|what|give me)\b/i;
 const dbTarget=/\b(?:database|tables?|rows?|records?|datasets?|schema|sql|queries|entries)\b/i;
 const namedTable=/\b[a-z][a-z0-9]*_[a-z0-9_]+\b/i;
 return retrieval.test(text) && (dbTarget.test(text) || namedTable.test(text));
}
function withDatabaseCapabilities(agent:RouteAgent):RouteAgent {
 if(!isDatabaseAgent(agent))return agent;
 return {...agent,description:[agent.description,
  'DBAgent is the database specialist. Handles SQL statements AND natural-language questions about stored tables and records. It can answer questions requesting counts, rows, filtering, aggregates, and database searches using the connected NL2SQL A2A service. Select this agent even if the user did not write SQL.'
 ].filter(Boolean).join(' ')};
}
app.post('/api/router/select',async(req,res)=>{try{
 const message=req.body?.message;
 if(typeof message!=='string'||!message.trim()||message.length>20000){res.status(400).json({error:'Invalid message'});return;}
 const [pythonResult,coreResult]=await Promise.allSettled([forward(PYTHON_SERVICE_URL.replace(/\/+$/,'')+'/agents','GET'),forward(AI_CORE_REGISTRY_URL,'GET')]);
 const trusted:RouteAgent[]=[];
 if(pythonResult.status==='fulfilled'&&pythonResult.value.ok){const data:any=await pythonResult.value.json();for(const a of (Array.isArray(data?.agents)?data.agents:[]))if(typeof a.id==='string'&&a.id)trusted.push({id:a.id,name:String(a.name||a.id),type:'north',description:String(a.description||''),commands:Array.isArray(a.skills)?a.skills.flatMap((x:any)=>[String(x.name||''),String(x.description||''),...(Array.isArray(x.tags)?x.tags:[])]):[]});}
 if(coreResult.status==='fulfilled'&&coreResult.value.ok){const data:any=await coreResult.value.json();if(data?.agents&&!Array.isArray(data.agents)){for(const [id,url] of Object.entries(data.agents))if(typeof url==='string')trusted.push({id,name:id,type:'aicore',description:'',commands:[]});}else if(Array.isArray(data?.agents)){for(const a of data.agents)if(a.id||a.name)trusted.push({id:String(a.id||a.name),name:String(a.name||a.id),type:'aicore',description:String(a.description||''),commands:Array.isArray(a.commands)?a.commands:[]});}else{const commands=data?.commandList||{};const urls=data?.agentURLs||{};for(const id of new Set([...Object.keys(commands),...Object.keys(urls)]))trusted.push({id,name:id,type:'aicore',description:'',commands:Array.isArray(commands[id])?commands[id]:[]});}}
 if(!trusted.length&&paradigmSnapshot){for(const id of new Set([...Object.keys(paradigmSnapshot.commandList),...Object.keys(paradigmSnapshot.agentURLs)]))trusted.push({id,name:id,type:'aicore',description:'',commands:paradigmSnapshot.commandList[id]||[]});}
 const requested=Array.isArray(req.body?.agents)?req.body.agents:[];
 // Selection is advisory: UI-discovered metadata may be used for selection, never for execution URLs.
 const candidates:RouteAgent[]=requested.filter((r:any)=>r && typeof r.id==='string' && r.id.length<150 && ['north','aicore'].includes(r.type))
  .map((r:any)=>{const known=trusted.find(t=>t.id===r.id && t.type===r.type);return known || {id:r.id,name:String(r.name||r.id).slice(0,200),type:r.type,description:String(r.description||'').slice(0,2000),commands:Array.isArray(r.commands)?r.commands.filter((c:any)=>typeof c==='string').slice(0,50):[]};});
 if(!candidates.length){res.json({agent:null,confidence:0,reason:'No discovered agents supplied by Electron UI'});return;}
 // Only select a DBAgent confirmed by trusted server-side discovery. The browser
 // may supply descriptive metadata, but it must never create an executable agent.
 const dbAgent=candidates.find(a=>isDatabaseAgent(a)&&trusted.some(t=>t.id===a.id&&t.type===a.type));
 if(dbAgent && isDatabaseRetrievalRequest(message)){
  res.json({agent:{id:dbAgent.id,name:dbAgent.name,type:dbAgent.type},agentId:dbAgent.id,agentName:dbAgent.name,
   confidence:.99,reason:'Database SQL or natural-language retrieval request; forward to the NL2SQL-enabled DBAgent',method:'database-intent'});
  return;
 }
 // PRIMARY: invoke local Ollama directly, rather than depending on the Python router.
 try {
  const catalog=candidates.map(raw=>{const a=withDatabaseCapabilities(raw);return {id:a.id,name:a.name,type:a.type,description:a.description,commands:a.commands};});
  const ollama=await fetch((process.env.OLLAMA_URL||'http://127.0.0.1:11434').replace(/\/+$/,'')+'/api/chat',{
   method:'POST',headers:{'Content-Type':'application/json'},signal:AbortSignal.timeout(30000),
   body:JSON.stringify({model:process.env.OLLAMA_MODEL||'llama3.2:latest',stream:false,format:'json',options:{temperature:0},messages:[
    {role:'system',content:'You are CALIAN AI agent selector. Choose ONE best agent from this catalog. Reply ONLY valid JSON {"agentId":"exact-id","reason":"short explanation"}. Never invent IDs. IMPORTANT: Database agents can handle BOTH raw SQL and ordinary English questions that ask to retrieve, count, filter, list, compare or aggregate records stored in a database. Prefer DBAgent over general-purpose assistants for requests about actual stored database data, even if the words SQL or database are missing. Choose general-purpose assistants for general knowledge and programming explanations that do not require accessing stored data. Catalog: '+JSON.stringify(catalog)},
    {role:'user',content:message}
   ]})
  });
  if(!ollama.ok)throw new Error('Ollama HTTP '+ollama.status);
  const output:any=await ollama.json();
  const decision=JSON.parse(String(output?.message?.content||'{}'));
  const selected=candidates.find(a=>a.id===decision.agentId);
  if(selected){res.json({agent:{id:selected.id,name:selected.name,type:selected.type},agentId:selected.id,agentName:selected.name,confidence:.8,reason:String(decision.reason||'Chosen by Ollama').slice(0,500),method:'ollama'});return;}
  throw new Error('Ollama did not return a registered agent ID');
 }catch(error){console.warn('Direct Ollama unavailable, attempting Python Ollama router:',error);}
 // Secondary: existing Python Ollama router, then trusted metadata fallback.
 try {
  const upstream=await forward(OLLAMA_ROUTER_URL.replace(/\/+$/,'')+'/router/select','POST',{
   message,agents:candidates.map(raw=>{const a=withDatabaseCapabilities(raw);return {id:a.id,name:a.name,type:a.type,description:a.description,commands:a.commands,skills:a.commands.map((c,i)=>({id:`command-${i}`,name:c,description:c,tags:[],examples:[]}))};}),contextId:req.body?.contextId,context:req.body?.context
  });
  if(upstream.ok){const choice:any=await upstream.json();const id=String(choice.agentId||choice.agent?.id||'');const selected=candidates.find(a=>a.id===id);
   if(selected&&choice.method==='ollama'){res.json({agent:{id:selected.id,name:selected.name,type:selected.type},agentId:selected.id,agentName:selected.name,confidence:Number(choice.confidence)||.8,reason:String(choice.reason||'Selected by Python Ollama'),method:'ollama'});return;}}
 }catch(error){console.warn('Python router unavailable; using metadata fallback:',error);}
 const query=expandRoute(message);const ranked=candidates.map(raw=>{const a=withDatabaseCapabilities(raw);return {agent:raw,score:5*overlaps(query,routeWords(a.name))+2*overlaps(query,routeWords(a.commands.join(' ')))+overlaps(query,routeWords(a.description))};}).sort((a,b)=>b.score-a.score||a.agent.id.localeCompare(b.agent.id));
 const best=ranked[0];if(best.score===0&&ranked.length!==1){res.json({agent:null,confidence:0,reason:'No agent capability matched the request'});return;}
 if(ranked.length>1&&ranked[1].score===best.score){res.json({agent:null,confidence:0,reason:'Ambiguous match between multiple agents'});return;}
 res.json({agent:{id:best.agent.id,name:best.agent.name,type:best.agent.type},agentId:best.agent.id,agentName:best.agent.name,confidence:best.score?Math.min(.95,.55+best.score*.04):.5,reason:best.score?'Selected using trusted agent metadata':'Only one registered agent is available',method:'metadata'});
 }catch(e){fail(res,e);}});
app.post('/api/a2a',async(req,res)=>{
  // The bundled Python router exposes discovery and selection, NOT an A2A executor.
  // Reject unsupported execution clearly instead of forwarding to its missing '/' route.
  res.status(503).json({error:'Python A2A execution service is not configured. Local Ollama Assistant works through /api/ollama/chat. Configure PYTHON_SERVICE_URL to a real A2A executor for other Python agents.'});
});
// Do not report success if the A2A envelope or ExecuteSQL tool returned a failure.
// A2A can return JSON-RPC, nested text parts, or a sequence of SSE updates.
// Never present intermediate [] as success when a later event reports a failure.
function assertNoA2aError(response:unknown, requireExecuteSql=false):void {
 const seen=new Set<unknown>();
 function check(v:unknown, depth:number):void {
  if(v==null || depth>25 || seen.has(v))return;
  if(typeof v==='string'){
   if(v.length>300000)return;
   let decoded:unknown;
   try {decoded=JSON.parse(v);}catch{decoded=undefined;}
   if(decoded!==undefined){check(decoded,depth+1);return;}
   if(/GROUNDING VIOLATION|Request payload validation error|Could not generate a valid query after multiple attempts/i.test(v))
    throw new Error(`DBAgent reported an execution error: ${v.slice(0,1200)}`);
   return;
  }
  if(typeof v!=='object')return;
  seen.add(v);
  if(Array.isArray(v)){for(const item of v)check(item,depth+1);return;}
  const obj=v as Record<string,unknown>;
  if(obj.error!=null && obj.error!==false && obj.error!=='')
   throw new Error(`DBAgent error: ${JSON.stringify(obj.error).slice(0,1200)}`);
  if(obj.success===false || obj.Success===false)
   throw new Error(`DBAgent execution failed: ${JSON.stringify(obj).slice(0,1200)}`);
  if(requireExecuteSql && typeof obj.used_skill==='string' && !/^(?:execute[_ -]?sql)$/i.test(obj.used_skill.trim()))
   throw new Error(`DBAgent invoked '${obj.used_skill}' instead of execute_sql. The SQL was translated successfully but the skill dispatcher did not honor Request=execute_sql. No changes were made to Fouad's service.`);
  const state=(obj.status && typeof obj.status==='object')?(obj.status as Record<string,unknown>).state:obj.state;
  if(typeof state==='string' && /^(?:failed|rejected|canceled|cancelled)$/i.test(state))
   {
     const status=obj.status as Record<string,unknown>|undefined;
     const parts=((status?.message as Record<string,unknown>|undefined)?.parts);
     const brief=Array.isArray(parts)
       ? parts.map((p:unknown)=>p && typeof p==='object' ? String((p as Record<string,unknown>).text||'') : '').filter(Boolean).join(' ').slice(0,1400)
       : '';
     throw new Error(`DBAgent task ended in '${state}' state${brief ? ': '+brief : ' (check DBAgent logs for task failure reason)'}`);
   }
  for(const child of Object.values(obj))check(child,depth+1);
 }
 check(response,0);
}
// Read JSON or A2A SSE without changing the working execution protocol.
async function readA2aBody(upstream:Response):Promise<unknown>{
 const body=await upstream.text();
 try{return JSON.parse(body);}catch{ /* may be an SSE stream */ }
 const events:unknown[]=[];
 for(const line of body.split(/\r?\n/))if(line.startsWith('data:')){
  const data=line.slice(5).trim();if(!data || data==='[DONE]')continue;
  try{events.push(JSON.parse(data));}catch{events.push(data);}
 }
 return events.length ? (events.length===1 ? events[0] : events) : body;
}
function readableA2aResult(value:unknown):string{
 const texts:string[]=[];
 const seen=new Set<unknown>();
 function visit(v:unknown,depth:number):void{
  if(v==null||depth>12||seen.has(v)||texts.length>30)return;
  if(typeof v==='string'){
   if(v.length>200000)return;
   try{const json=JSON.parse(v);visit(json,depth+1);return;}catch{/* plain text */}
   texts.push(v);return;
  }
  if(typeof v!=='object')return;
  seen.add(v);
  if(Array.isArray(v)){for(const part of v.slice(0,30))visit(part,depth+1);return;}
  const obj=v as Record<string,unknown>;
  // Prefer the actual A2A text parts; do not collect arbitrary metadata fields.
  if(typeof obj.text==='string'){visit(obj.text,depth+1);return;}
  if(obj.parts)visit(obj.parts,depth+1);
  if(obj.artifacts)visit(obj.artifacts,depth+1);
  if(obj.result)visit(obj.result,depth+1);
  if(obj.message)visit(obj.message,depth+1);
  if(obj.Response)visit(obj.Response,depth+1);
  if(obj.rows)texts.push(JSON.stringify(obj.rows,null,2));
  if(obj.error)texts.push(JSON.stringify({error:obj.error}));
 }
 visit(value,0);
 return (texts.join('\n\n').trim() || (typeof value==='string'?value:JSON.stringify(value,null,2))).slice(0,200000);
}
app.post('/api/ai-core/execute',async(req,res)=>{
 const {agentId,message,contextId,context}=req.body || {};
 if(typeof agentId!=='string'||typeof message!=='string'||typeof contextId!=='string'){res.status(400).json({error:'Invalid request'});return;}

 // CALIAN-only deterministic DBAgent execution. The REQA A2A service can choose
 // GenerateSQL even for literal SELECT text; do NOT rely on its skill selection.
 // Instead invoke REQA's existing MCP execute_sql tool inside the running reqa-api
 // container. This is a local read-only bridge: no Docker/Python changes.
 if(/^(?:db[\s_-]*agent|database[\s_-]*agent)$/i.test(agentId.trim())) {
   const inputKind=classifyDbInput(message);
   if(inputKind==='unsafe' || (isDirectSql(message) && inputKind!=='sql')){
     res.status(400).json({error:'Only read-only SELECT or WITH ... SELECT statements can be executed. Database writes and administrative SQL are blocked.'});return;
   }
   const runVerifiedSql=async(sql:string) => {
     const result=await executeReadOnlySql(sql);
     if(!result.success)throw new Error(result.error||'REQA MCP execute_sql returned an unsuccessful result');
     return result;
   };
   const formatExecution=(sql:string, result:{success:boolean;rows:unknown[];error:string})=>({
      Success:result.success,used_skill:'execute_sql',
      Request:{Request:'execute_sql',Query:sql,max_rows:1000},
      Response:{success:result.success,sql,rows:result.rows,row_count:result.rows.length,
        error:result.error,answer:result.success?`Returned ${result.rows.length} row(s), up to 1000.`:result.error}
   });
   try {
     if(inputKind==='sql'){
       // Both direct SQL and translated English reach this exact function.
       const result=await runVerifiedSql(message);
       res.json(formatExecution(message,result));return;
     }
     if(process.env.CALIAN_DB_NL_ENABLED==='false'){
       res.status(409).json({error:'CALIAN natural-language SQL translation is disabled.'});return;
     }
     // The existing REQA Streamlit v1 UI calls /query/start and then
     // /query/status/{job_id}. Use the exact same backend workflow for English.
     // REQA already executes the generated SQL. Never execute it a second time.
     if(/\b(?:delete|drop|truncate|insert|update|alter|replace|grant|revoke|erase|remove|overwrite)\b/i.test(message)) {
       res.status(400).json({error:'Natural-language database changes are not allowed. Only read-only questions may be submitted.'});return;
     }
     const result=await queryViaReqaWebPipeline(message);
     console.info('[CALIAN REQA v1] Completed English query with REQA SQL pipeline; rows:',result.row_count);
     res.json({text:formatReqaAnswer(result),generatedSql:result.sql,translationMethod:'reqa-v1-schema-rag',
       executionSkill:'REQA-v1-pipeline',rowCount:result.row_count,attempts:result.attempts,
       // The response includes a bounded preview. Full results remain available in REQA's own UI.
       rows:result.rows.slice(0,100),provider:'REQA web UI equivalent'});
     return;
   }catch(error){
     const reason=error instanceof Error?error.message:String(error);
     console.warn('[CALIAN DBAgent SQL/REQA v1] Request failed:',reason);
     res.status(422).json({error:'DBAgent MCP execute_sql: '+reason});return;
   }
 }

 // Client does not control destination. Registry endpoints must be explicitly allowlisted.
 const map=Object.fromEntries((process.env.AI_CORE_AGENT_ENDPOINT_MAP||'').split(',').filter(Boolean).map(x=>{const i=x.indexOf('=');return [x.slice(0,i),x.slice(i+1)];}));
  try {
    // Resolve the agent from the server-side AI Core registry, not from a browser-supplied URL.
    // The optional environment map remains a fallback for older deployments.
    let endpoint: string | undefined;
    const registryResponse = await forward(AI_CORE_REGISTRY_URL, 'GET');
    if (registryResponse.ok) {
      const registry: any = await registryResponse.json();
      const agents = registry?.agents;
      if (agents && !Array.isArray(agents) && typeof agents === 'object') {
        const value = agents[agentId];
        if (typeof value === 'string') endpoint = value;
      } else if (Array.isArray(agents)) {
        const entry = agents.find((a: any) => a?.id === agentId || a?.name === agentId);
        if (entry) endpoint = entry.endpoint || entry.url || entry.agentUrl;
      }
      if (!endpoint && registry?.agentURLs && typeof registry.agentURLs[agentId] === 'string') {
        endpoint = registry.agentURLs[agentId];
      }
    }
    if (!endpoint && paradigmSnapshot) endpoint = paradigmSnapshot.agentURLs[agentId];
    if (!endpoint) endpoint = map[agentId];
    if (!endpoint) {res.status(404).json({error:`No registered endpoint for AI Core agent: ${agentId}`});return;}

    // Permit only exact URLs learned from the trusted server-side registry.
    // Reject non-loopback endpoints unless explicitly allowlisted through AI_CORE_ENDPOINTS.
    const parsed = new URL(endpoint);
    const loopback = ['127.0.0.1','localhost','::1','[::1]'].includes(parsed.hostname);
    if (!loopback && ![...allowed].some(base => base === endpoint.replace(/\/+$/,''))) {
      res.status(403).json({error:'Agent endpoint must be loopback or explicitly allowlisted'});return;
    }
    if (!['http:','https:'].includes(parsed.protocol) || parsed.username || parsed.password || parsed.hash) {
      res.status(400).json({error:'Invalid registered agent endpoint'});return;
    }
    discoveredEndpoints.add(parsed.href);
    // The DBAgent Python A2A service (typically port 5022) requires a JSON-RPC
    // envelope. Other Paradigm/AI Core agents retain their existing request format.
    // Override CALIAN_A2A_EXECUTION_PORT if the Python service is remapped.
    const a2aPort = String(process.env.CALIAN_A2A_EXECUTION_PORT || '5022');
    const isPythonA2A = parsed.port === a2aPort;
    // ONE dispatch path for direct SQL and translated English queries.
    // The message/send envelope is identical to the original working A2A package.
    const sendA2a = (text: string, contextForMessage: unknown = context, idForMessage: string = contextId) =>
      forward(endpoint!, 'POST', buildOriginalA2aMessage(agentId,text,idForMessage,contextForMessage));
    // Keep the proven direct-SQL / A2A path byte-for-byte compatible in behavior.
    // Only intercept English questions addressed to the actual DBAgent A2A port.
    const databaseAgent = /^(?:db[\s_-]*agent|database[\s_-]*agent)$/i.test(agentId.trim());
    const englishDbQuestion = databaseAgent && !isDirectSql(message);
    const nlEnabled = process.env.CALIAN_DB_NL_ENABLED !== 'false';
    // Never silently forward an English DBAgent question to Fouad's GenerateSQL
    // when the local adapter should handle it. Report a configuration error instead.
    if (englishDbQuestion && nlEnabled && !isPythonA2A) {
      discoveredEndpoints.delete(parsed.href);
      res.status(409).json({error:`CALIAN NL->SQL adapter v6 is active, but DBAgent endpoint ${parsed.origin} is not on expected A2A execution port ${a2aPort}. Set CALIAN_A2A_EXECUTION_PORT to the actual Python A2A port. Refusing to send the English question to GenerateSQL.`});
      return;
    }
    const translate = isPythonA2A && englishDbQuestion && nlEnabled;
    if (translate) {
      const executeViaExistingA2a = async (sql: string): Promise<unknown> => {
        // Crucial: call the EXACT SAME sendA2a function as direct-SQL mode.
        // Only isolate the old English history; it must not influence backend skill choice.
        console.info(`[CALIAN NL->SQL v6] Shared direct-SQL dispatch (${sql.length} chars) via ${parsed.origin}`);
        const upstream=await sendA2a(sql,dbSqlOnlyContext(sql),randomUUID());
        const body=await readA2aBody(upstream);
        if(!upstream.ok) {
          let brief=`A2A HTTP ${upstream.status}`;
          try { assertNoA2aError(body,true); } catch(e) { brief += ': '+(e instanceof Error?e.message:String(e)); }
          throw new Error(brief);
        }
        // Never silently accept GenerateSQL as successful execution.
        assertNoA2aError(body,true);
        return body;
      };
      const invokeOllama = async (question:string, table:string, columns:string[]):Promise<unknown> => {
        const ollamaResponse=await fetch((process.env.OLLAMA_URL||'http://127.0.0.1:11434').replace(/\/+$/,'')+'/api/chat',{
          method:'POST',headers:{'Content-Type':'application/json'},signal:AbortSignal.timeout(90000),
          body:JSON.stringify({model:process.env.OLLAMA_MODEL||'llama3.2:latest',stream:false,format:'json',options:{temperature:0},messages:[
            {role:'system',content:'Convert the user question to a READ-ONLY, SINGLE-TABLE JSON query plan for MariaDB/MySQL. Respond with JSON only, never SQL. Use EXACTLY the named table and ONLY columns in the supplied list; do not invent joins, subqueries, tables or columns. Shape: {"operation":"count|list|aggregate","table":"exact name","columns":["actual_column"],"filters":[{"column":"actual_column","operator":"=|!=|>|>=|<|<=|contains|starts_with","value":"literal or number"}],"orderBy":{"column":"actual_column","direction":"ASC|DESC"},"limit":20,"aggregate":{"function":"SUM|AVG|MIN|MAX|COUNT","column":"actual_column"}}. Omit unused fields. For counts use count. For listing use list with a limit (max 100). For sums/averages use aggregate. Do not respond with more than one table or any mutating operation. Valid table: '+table+'. Actual columns: '+JSON.stringify(columns)},
            {role:'user',content:question}
          ]})
        });
        if(!ollamaResponse.ok) throw new Error(`Ollama HTTP ${ollamaResponse.status}`);
        const output:any=await ollamaResponse.json();
        const raw=output?.message?.content;
        if(typeof raw!=='string')throw new Error('Ollama did not return a query plan');
        try{return JSON.parse(raw);}catch{throw new Error('Ollama did not return valid JSON');}
      };
      try {
        const translation=await translateNaturalLanguage(message,executeViaExistingA2a,invokeOllama);
        console.info(`[CALIAN NL->SQL v6] ${translation.method} for ${agentId}: ${translation.sql}`);
        const result=await executeViaExistingA2a(translation.sql);
        const resultText=readableA2aResult(result);
        // The UI already displays the 'text' property using coreText().
        // Include generated SQL so users can audit what ran against the database.
        res.json({text:`Generated read-only SQL:\n${translation.sql}\n\nDBAgent result:\n${resultText}`,
          generatedSql:translation.sql,translationMethod:translation.method});
      } catch (error) {
        console.warn('[CALIAN NL->SQL v6] Request rejected:',error);
        res.status(422).json({error:error instanceof Error?error.message:String(error)});
      } finally { discoveredEndpoints.delete(parsed.href); }
      return;
    }
    // Original direct-SQL behavior: relay the raw response without reinterpretation.
    // A2A uses the same sendA2a() as the English-translated path above.
    if (isPythonA2A) console.info(`[CALIAN] Sending original A2A message/send to ${parsed.origin} for ${agentId}`);
    try {await relay(res, isPythonA2A ? await sendA2a(message) : await forward(endpoint,'POST',{message,contextId,context}));}
    finally {discoveredEndpoints.delete(parsed.href);}
  } catch(e) {fail(res,e);}
});
// Serve the packaged Angular UI from the same loopback origin.
const staticDir = process.env.CALIAN_STATIC_DIR;
if (staticDir) {
 app.use(express.static(staticDir));
 app.get(/^(?!\/api\/).*/, (_req,res)=>res.sendFile(path.join(staticDir,'index.html')));
}
const server = createServer(app);
const sockets = new WebSocketServer({server,path:'/ws',maxPayload:1024*1024});
sockets.on('connection',(socket,request)=>{
 const origin=request.headers.origin;
 if(origin){
  let validOrigin=false;
  try {
   const u=new URL(origin);
   validOrigin=u.protocol==='http:' && ['127.0.0.1','localhost'].includes(u.hostname) && ['4300',String(PORT)].includes(u.port);
  } catch { /* invalid origin */ }
  if(!validOrigin){socket.close(1008,'Invalid origin');return;}
 }
 const send=(data:unknown)=>{if(socket.readyState===WebSocket.OPEN)socket.send(JSON.stringify(data));};
 socket.on('message',async(raw)=>{
  let id:string|undefined;
  try {
   const input=JSON.parse(raw.toString());id=input.id;
   if(typeof id!=='string'||id.length>100||!['/api/health','/api/agents','/api/ai-core/agents','/api/router/select','/api/a2a','/api/ai-core/execute','/api/ollama/chat'].includes(input.path)||!['GET','POST'].includes(input.method))throw new Error('Invalid socket request');
   // Existing trusted Express routes retain all validation and upstream protections.
   const response=await fetch(`http://127.0.0.1:${PORT}${input.path}`,{method:input.method,headers:{'Content-Type':'application/json'},body:input.method==='POST'?JSON.stringify(input.body):undefined,signal:AbortSignal.timeout(input.path==='/api/ai-core/execute'?430000:180000)});
   if(!response.ok){send({id,type:'error',error:`HTTP ${response.status}: ${await response.text()}`});return;}
   if(input.path==='/api/a2a'){
    if(!response.body)throw new Error('Missing A2A stream');
    for await(const chunk of Readable.fromWeb(response.body as any))send({id,type:'chunk',data:Buffer.from(chunk).toString('utf8')});
    send({id,type:'done'});
   }else send({id,type:'result',data:await response.json()});
  }catch(e){send({id,type:'error',error:e instanceof Error?e.message:String(e)});}
 });
});
server.listen(PORT,'127.0.0.1',()=>console.log(`CALIAN WebSocket backend: ws://127.0.0.1:${PORT}/ws`));
