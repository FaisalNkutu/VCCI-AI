package com.calian.desktop;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.*;
import me.friwi.jcefmaven.CefAppBuilder;
import me.friwi.jcefmaven.MavenCefAppHandlerAdapter;
import org.cef.CefApp;
import org.cef.CefClient;
import org.cef.browser.CefBrowser;

public class AngularSwingHost {
    private static final String URL = "http://127.0.0.1:4200";

    public static void main(String[] args) throws Exception {
        // Initialize native Chromium before creating any Swing components.
        CefAppBuilder builder = new CefAppBuilder();
        builder.setInstallDir(new java.io.File(System.getProperty("user.home"), ".calian-jcef-demo-isolated"));
        builder.getCefSettings().windowless_rendering_enabled = false;
        builder.setAppHandler(new MavenCefAppHandlerAdapter() {});
        CefApp cefApp;
        try {
            cefApp = builder.build();
        } catch (Exception | LinkageError ex) {
            System.err.println("CALIAN embedded Chromium failed to initialize in isolated demo directory.");
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null,
                "Embedded Chromium initialization failed. Your existing applications are unchanged.\n" +
                "See the launcher console for the exact native error.\n" + ex,
                "CALIAN AI — JCEF initialization", JOptionPane.ERROR_MESSAGE);
            return;
        }
        CefClient client = cefApp.createClient();
        CefBrowser browser = client.createBrowser(URL, false, false);

        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("CALIAN AI — Angular Material Chatbot");
            frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
            frame.setLayout(new BorderLayout());
            frame.add(browser.getUIComponent(), BorderLayout.CENTER);
            frame.setMinimumSize(new Dimension(900, 650));
            frame.setSize(1280, 850);
            frame.setLocationRelativeTo(null);
            frame.addWindowListener(new WindowAdapter() {
                @Override public void windowClosing(WindowEvent e) {
                    browser.close(true);
                    client.dispose();
                    cefApp.dispose();
                    frame.dispose();
                    System.exit(0);
                }
            });
            frame.setVisible(true);
        });
    }
}
