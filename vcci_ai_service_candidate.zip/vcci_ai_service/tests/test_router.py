import asyncio
from agent_router import AgentRouter
from router_models import RouterRequest, RouterAgent
from agent_orchestrator import AgentOrchestrator
from orchestration_models import OrchestrationPlan, OrchestrationStep

def test_route_translation():
    agents=[RouterAgent(id='t',name='translation-agent'),RouterAgent(id='d',name='Dice Agent')]
    response=asyncio.run(AgentRouter().route(RouterRequest(message='Translate hello to French',agents=agents)))
    assert response.agentId=='t'

def test_no_match():
    agents=[RouterAgent(id='t',name='translation-agent'),RouterAgent(id='d',name='Dice Agent')]
    response=asyncio.run(AgentRouter().route(RouterRequest(message='Calculate mortgage payments',agents=agents)))
    assert response.agentId is None

def test_orchestrator_dependency():
    async def invoke(**kwargs): return kwargs['message']
    plan=OrchestrationPlan(steps=[OrchestrationStep(agentId='a',instruction='First'),
                                  OrchestrationStep(agentId='b',instruction='Second',dependsOn=[0])])
    result=asyncio.run(AgentOrchestrator(invoke).execute(plan,'Hello','ctx'))
    assert 'PREVIOUS AGENT RESULT' in result
