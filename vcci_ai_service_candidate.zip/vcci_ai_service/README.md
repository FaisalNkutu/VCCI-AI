# VCCI AI Service (hardened reference implementation)

This is a **candidate release**, not a certified production deployment. It preserves
`GET /agents`, `POST /router/select` (legacy response), A2A JSON-RPC, and the existing
North streaming executor. Adds `POST /router/select/v2` with typed response.

## Setup

1. Revoke the token embedded in the original `ttoken.py`; generate a new token.
2. Use Python 3.11+ and install FastAPI, Pydantic, dotenv, uvicorn, and **your
   validated versions** of the `north` and `a2a-sdk` packages. Package APIs differ
   by version; pin only after a real integration test.
3. Copy `.env.example` to `.env`, fill in secrets, and keep it out of Git.
4. `python -m uvicorn main:app --host 127.0.0.1 --port 9999`
5. Send `X-API-Key: <VCCI_API_KEY>` on Java UI requests to `/agents`, `/router/select`
   and A2A JSON-RPC. `/health` is intentionally unauthenticated.
6. `python -m pytest -q tests` for unit tests (install pytest separately).

## Important deployment notes

- The Java UI **must be updated** to send `X-API-Key`; otherwise existing calls will
  receive HTTP 401. Use TLS and a secret manager for non-loopback deployments.
- `/router/select` accepts caller-provided agents for compatibility. In production,
  verify agent identities/endpoints against a trusted registry before execution;
  never permit arbitrary external URLs as agent endpoints (SSRF risk).
- The metadata router is deterministic and deliberately declines ambiguous/no-match
  requests. It does **not** claim LLM semantic routing.
- Orchestrator is a tested library component, **not** exposed as a public endpoint;
  supply a validated, allowlisted agent invoker before enabling it.
- North SDK streaming/A2A integration, authentication, token refresh, connection
  lifecycle, observability, retry/backoff, rate limiting, and persistence require
  environment-specific integration and load tests before a production rollout.
- Existing `NorthAgentExecutor` uses process-local conversation dictionaries and
  an in-memory A2A task store. Do not scale to multiple workers until these are
  replaced with durable/shared state and appropriate cleanup.
