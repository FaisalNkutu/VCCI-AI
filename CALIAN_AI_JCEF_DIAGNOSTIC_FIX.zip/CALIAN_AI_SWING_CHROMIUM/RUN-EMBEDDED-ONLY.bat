@echo off
setlocal
cd /d "%~dp0swing-host"
echo Starting isolated CALIAN embedded Swing host.
echo Existing applications and JCEF installation will not be modified.
where mvn >nul 2>&1 || (echo Maven is not on PATH. & pause & exit /b 1)
mvn -q compile exec:java -Dexec.mainClass=com.calian.desktop.AngularSwingHost
if errorlevel 1 (echo Swing host failed. See messages above. & pause)
