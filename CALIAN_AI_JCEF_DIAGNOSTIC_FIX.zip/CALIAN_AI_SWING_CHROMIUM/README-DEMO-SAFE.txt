CALIAN AI - isolated demo candidate (not yet validated on your Windows machine)

Do not close your two working backups.
This package is a copy of CALIAN_AI_ANGULAR_NATIVE_SWING_OLLAMA(2).zip.
Changes: separate JCEF native install folder .calian-jcef-demo-isolated,
explicit JCEF error dialog, Ollama routing enabled in this copy,
and one RUN-EMBEDDED-ONLY.bat launcher.

When Angular at 127.0.0.1:4200 is already running, run RUN-EMBEDDED-ONLY.bat.
If JCEF still reports INITIALIZATION_FAILED, do not retry or modify backups.
This is a native initialization failure, not an Angular issue.

For a full independent startup, use the included RUN-ANGULAR.bat
ONLY if ports 4200 and 8787 are free. The native Swing UI remains
a separate working fallback in native-swing/RUN-SWING.bat.

Not validated end-to-end: JCEF requires Windows native runtime.
