# `run_eval.py` — Evaluating a question list from a text file

The most reliable way to test your own questions: **a `.txt` file, one
question per line**. Zero PowerShell quoting issues (unlike the inline
`'["..."]'` list), reusable, and versionable with the project.

---

## 1. Create the question file

At the **project root** (`...\pipeline-reqa-sql-mcp\`),

create `questions.txt`:

```text
# Personal mini-benchmark — '#' = comment, blank lines are skipped
How many Activity records are there?
Show me some fire events
Where is each Activity Task located?
What is the average duration of activities?
```



## 2. Run the evaluation

```powershell
docker exec reqa-api python squash_run_eval.py --questions my_questions.txt --output /app/eval_custom.csv
```

*(adapt the script name if you are using `squash_run_eval.py`)*

What the command does:

- reads every non-empty, non-comment line as a question;
- sends it to the **real pipeline** (the `/query` endpoint — the same one
  Streamlit uses);
- records every result with **all the metrics**: `confidence`,
  `score_strict`, `rag_conf`, `gen_conf`, `sem_conf`;
- ends with the `__GLOBAL__` footer row (pass rate + means).

Live terminal output:

```
4 question(s) to test.

[1/4] OK    custom      21.3s  conf=0.93 sem=1.0  How many Activity records are there?
[2/4] OK    custom      18.7s  conf=0.91 sem=1.0  Show me some fire events
...
[GLOBAL] pass_rate=4/4 (100.0%)  mean_conf=0.92  mean_sem=1.0
Results written to: /app/eval_custom.csv
```

---

## 3. Important notes

| Point | Detail |
|---|---|
| **`table = "custom"`** | When no expected table is provided, the `table` column reads `custom` and `table_match` stays **blank** (not `False` — there is nothing to verify) |
| **Expected tables?** | Use a **`.json`** file instead: `[{"question": "...", "table": "act"}, ...]` → enables `table_match` |
| **`--output`** | Always use the absolute path **`/app/...`** so the CSV lands in your Windows project folder |
| **Ignored options** | `--tables`, `--domain`, `--sample-per-table` do not apply (the KB is bypassed) |
| **Active options** | `--resume`, `--timeout`, `--limit`, and auto-versioning (`_v2.csv` if the file exists) work as usual |
| **Analyze afterwards** | `docker exec reqa-api python analyze_eval.py --input /app/eval_custom.csv` |

---

## 4. Prerequisite before launching

Verify the LLM is reachable (otherwise: a cascade of `Circuit breaker open`):

```powershell
docker exec reqa-api python -c "import os, urllib.request; print(urllib.request.urlopen(os.environ['OLLAMA_BASE_URL'] + '/api/version', timeout=5).read())"
```

---

## 5. Typical use cases

- **Reproduce in batch** a problematic question spotted in the UI;
- test **your own phrasings** (not the KB's) — measures robustness against
  real user vocabulary;
- build a **business benchmark**: questions provided by the supervisor /
  future users, scored with the same metrics as the large campaigns —
  directly comparable to the per-domain runs.
