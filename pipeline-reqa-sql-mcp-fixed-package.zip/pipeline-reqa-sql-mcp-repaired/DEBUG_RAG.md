# Débuguer et vérifier le RAG

## Niveau 1 — Qdrant : les vecteurs sont-ils bien indexés ?

```bash
# Nombre de points dans la collection
curl -s http://localhost:6333/collections/schema | python3 -m json.tool
```

Résultat attendu : `"points_count": 7`

```bash
# Voir le payload d'une table précise
curl -s http://localhost:6333/collections/schema/points \
  -H "Content-Type: application/json" \
  -d '{"limit": 1, "with_payload": true}' | python3 -m json.tool
```

Le payload doit contenir `domain`, `columns`, `foreign_keys`, `column_knowledge` — si ces clés sont absentes, relancer `ingest.py`.

---

## Niveau 2 — RAG : quelles tables sont retournées pour une question ?

Crée un script de test rapide :

```bash
cat > /tmp/test_rag.py << 'EOF'
import sys
sys.path.insert(0, "/home/alimijileking/Documents/ml_projects/pipeline-reqa-sql")

from qdrant_client import QdrantClient
from agent.embedder import Embedder
from agent.schema_rag import SchemaRAG

client   = QdrantClient(host="localhost", port=6333)
embedder = Embedder()
rag      = SchemaRAG(client, embedder, "schema", top_k=5)

question = sys.argv[1] if len(sys.argv) > 1 else "Which products are below the reorder threshold?"

# Tables retournées
payloads = rag.retrieve(question)
print(f"\n=== Tables retournées pour : '{question}' ===")
for i, p in enumerate(payloads, 1):
    print(f"  {i}. {p.get('table')} [{p.get('domain')}]")

# Contexte envoyé au LLM
print("\n=== Contexte KB envoyé au LLM ===")
print(rag.build_schema_context(payloads))
EOF

python3 /tmp/test_rag.py "Which products are below the reorder threshold?"
```

Tester avec différentes questions :

```bash
python3 /tmp/test_rag.py "Which supplier has the best rating?"
python3 /tmp/test_rag.py "What is the total stock per warehouse?"
python3 /tmp/test_rag.py "How many active products are there?"
```

Ce que tu dois observer :
- Les tables retournées sont **cohérentes avec la question** (ex: question sur le stock → `inventory` et `products` en tête)
- Le contexte KB contient les **commentaires inline** sur les colonnes et les **business rules**

---

## Niveau 3 — Pipeline complet : tester l'API

```bash
# Test v1 avec affichage du SQL généré
curl -s -X POST http://localhost:8080/query \
  -H "Content-Type: application/json" \
  -d '{"question": "How many active products are there?"}' \
  | python3 -m json.tool
```

Les champs à surveiller dans la réponse :

| Champ | Ce qu'il indique |
|---|---|
| `success: true` | Pipeline OK end-to-end |
| `attempts: 1` | SQL généré du premier coup — KB efficace |
| `attempts: 2-3` | SQL corrigé — KB partiellement utile |
| `success: false` | Vérifier le champ `error` pour diagnostiquer |
| `sql` | Vérifier que les valeurs filtrées (`status = 'active'`) correspondent aux `allowed_values` du KB |

Questions de validation ciblant le KB :

```bash
# Teste allowed_values → products.status
curl -s -X POST http://localhost:8080/query \
  -H "Content-Type: application/json" \
  -d '{"question": "How many active products are there?"}' \
  | python3 -m json.tool

# Teste la note métier → inventory (stock critique)
curl -s -X POST http://localhost:8080/query \
  -H "Content-Type: application/json" \
  -d '{"question": "Which products have a critical stock level?"}' \
  | python3 -m json.tool

# Teste allowed_values → inventory_movements.movement_type
curl -s -X POST http://localhost:8080/query \
  -H "Content-Type: application/json" \
  -d '{"question": "What is the total quantity received (IN) per warehouse?"}' \
  | python3 -m json.tool
```

---

## Diagnostic rapide si ça ne marche pas

```bash
# KB chargé correctement ?
python3 -c "
import sys; sys.path.insert(0, '.')
from rag.knowledge_base import load_kb
kb = load_kb()
print('Tables KB:', list(kb.keys()))
print('Allowed values products.status:', kb['products']['columns']['status']['allowed_values'])
"

# Qdrant accessible ?
curl -s http://localhost:6333/healthz

# MariaDB accessible ?
docker exec reqa-mariadb mariadb -u example_user -ptest example_db \
  -e "SELECT COUNT(*) FROM products;"
```

---

## Résumé des symptômes et solutions

| Symptôme | Cause probable | Solution |
|---|---|---|
| `points_count: 0` | Ingest non lancé | `python3 ingest.py example.sql` |
| Payload sans `domain` / `columns` | Ancien ingest sans KB | `python3 ingest.py example.sql` |
| Tables non pertinentes retournées | KB mal renseigné | Enrichir `schema_knowledge.json` |
| `attempts: 3` systématiquement | Contexte LLM insuffisant | Ajouter `description` et `notes` dans le KB |
| `success: false` + erreur SQL | Valeurs mal filtrées | Renseigner `allowed_values` dans le KB |
| `curl: connection refused` (Qdrant) | Container arrêté | `docker compose up -d qdrant` |
| `curl: connection refused` (API) | API non démarrée | `uvicorn api:app --reload --port 8080` |
