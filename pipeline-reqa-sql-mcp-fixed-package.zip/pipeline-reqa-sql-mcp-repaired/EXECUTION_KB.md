# Exécution du pipeline après intégration du KB RAG

Ce guide liste toutes les commandes à exécuter dans l'ordre pour lancer le pipeline avec le KB intégré.

---

## Prérequis

| Outil | Version | Rôle |
|---|---|---|
| Docker + Docker Compose | 24+ | MariaDB, Qdrant |
| Python | 3.10+ | API, agents, ingest |
| Ollama | dernière | LLMs locaux (codestral, mistral) |
| pip | 23+ | Dépendances Python |

---

## Étape 0 — Se placer dans le dossier du projet

```bash
cd /home/alimijileking/Documents/ml_projects/pipeline-reqa-sql
```

---

## Étape 1 — Configurer l'environnement

Copier le fichier d'exemple et l'adapter si nécessaire :

```bash
cp .env.example .env
```

Valeurs par défaut dans `.env` :

```env
LLM_PROVIDER=ollama
OLLAMA_BASE_URL=http://ollama:11434
OLLAMA_SQL_MODEL=codestral:latest
OLLAMA_MODEL=mistral:latest

DB_HOST=localhost
DB_PORT=3306
DB_NAME=example_db
DB_USER=example_user
DB_PASSWORD=test

QDRANT_HOST=localhost
QDRANT_PORT=6333
QDRANT_COLLECTION=schema

MAX_SQL_RETRIES=3
CB_THRESHOLD=3
TOP_K_TABLES=5
MAX_ROWS=100
```

> Modifier `OLLAMA_SQL_MODEL` et `OLLAMA_MODEL` si tu utilises d'autres modèles.

---

## Étape 2 — Installer les dépendances Python

```bash
pip install -r requirements.txt
```

Vérifier que le module `rag` est accessible :

```bash
python3 -c "from rag.knowledge_base import load_kb; print('KB OK —', list(load_kb().keys()))"
```

Résultat attendu :

```
KB OK — ['categories', 'suppliers', 'warehouses', 'products', 'product_suppliers', 'inventory', 'inventory_movements']
```

---

## Étape 3 — Démarrer l'infrastructure Docker

```bash
docker compose up -d mariadb qdrant
```

Attendre que les services soient healthy :

```bash
docker compose ps
```

Résultat attendu :

```
NAME           STATUS
reqa-mariadb   Up (healthy)
reqa-qdrant    Up (healthy)
```

> Si les services ne passent pas à `healthy` après 30 secondes :
> ```bash
> docker compose logs mariadb
> docker compose logs qdrant
> ```

---

## Étape 4 — Charger le schéma SQL dans MariaDB

```bash
docker exec -i reqa-mariadb mariadb -u example_user -ptest example_db < example.sql
```

Vérifier que les tables sont créées :

```bash
docker exec reqa-mariadb mariadb -u example_user -ptest example_db \
  -e "SHOW TABLES;"
```

Résultat attendu :

```
+----------------------+
| Tables_in_example_db |
+----------------------+
| categories           |
| inventory            |
| inventory_movements  |
| product_suppliers    |
| products             |
| suppliers            |
| warehouses           |
+----------------------+
```

Charger les données de test :

```bash
docker exec -i reqa-mariadb mariadb -u example_user -ptest example_db < seed.sql
```

Vérifier les données :

```bash
docker exec reqa-mariadb mariadb -u example_user -ptest example_db \
  -e "SELECT COUNT(*) AS nb_products FROM products; SELECT COUNT(*) AS nb_suppliers FROM suppliers;"
```

Résultat attendu :

```
+------------+
| nb_products|
+------------+
|         60 |
+------------+
+--------------+
| nb_suppliers |
+--------------+
|           55 |
+--------------+
```

---

## Étape 5 — Télécharger les modèles Ollama

```bash
ollama pull codestral   # ~9 GB — génération SQL
ollama pull mistral     # ~5 GB — rendu en langage naturel
```

Vérifier :

```bash
ollama list
```

Résultat attendu :

```
NAME                  ID              SIZE
codestral:latest      ...             ~9 GB
mistral:latest        ...             ~5 GB
```

> **Alternatives légères si RAM insuffisante :**
> ```bash
> ollama pull codellama:7b   # ~4 GB
> ollama pull phi4           # ~9 GB
> ```
> Puis mettre à jour `.env` :
> ```env
> OLLAMA_SQL_MODEL=codellama:7b
> OLLAMA_MODEL=phi4
> ```

---

## Étape 6 — Indexer le schéma dans Qdrant (KB-enrichi)

> **Étape clé après l'intégration du KB.** Cette commande remplace l'ancienne indexation avec des vecteurs KB-enrichis (domain + sémantique colonnes + valeurs autorisées + sample queries).

```bash
python3 ingest.py example.sql
```

Résultat attendu :

```
[ingest] Parsed 7 tables: ['categories', 'suppliers', 'warehouses', 'products', 'product_suppliers', 'inventory', 'inventory_movements']
[ingest] Loading embedding model (first run downloads ~130 MB)...
[ingest] Qdrant collection 'schema' ready.
[ingest] ✓ 7 table schemas ingested into Qdrant (KB-enriched embeddings).
```

> Au premier lancement, le modèle d'embedding `BAAI/bge-small-en-v1.5` (~130 MB) est téléchargé automatiquement.

Vérifier l'indexation dans Qdrant :

```bash
curl -s http://localhost:6333/collections/schema | python3 -m json.tool
```

Résultat attendu (extrait) :

```json
{
  "result": {
    "status": "green",
    "vectors_count": 7,
    "points_count": 7
  }
}
```

Vérifier qu'un point contient bien le payload KB enrichi :

```bash
curl -s http://localhost:6333/collections/schema/points \
  -H "Content-Type: application/json" \
  -d '{"limit": 1, "with_payload": true}' | python3 -m json.tool
```

Le payload doit contenir les clés `domain`, `columns`, `foreign_keys`, `column_knowledge` :

```json
{
  "result": {
    "points": [{
      "payload": {
        "table": "products",
        "domain": "Catalogue",
        "description": "Table: products\nColumns: ...",
        "columns": [{"name": "product_id", "type": "BIGINT", "nullable": "NO"}, "..."],
        "foreign_keys": ["category_id → categories.category_id"],
        "column_knowledge": {
          "status": {"allowed_values": ["draft", "active", "archived"], "...": "..."}
        }
      }
    }]
  }
}
```

---

## Étape 7 — Lancer l'API FastAPI

Dans un terminal dédié (terminal 1) :

```bash
uvicorn api:app --reload --port 8080
```

Résultat attendu :

```
INFO:     Started server process
INFO:     Waiting for application startup.
INFO:     Application startup complete.
INFO:     Uvicorn running on http://0.0.0.0:8080 (Press CTRL+C to quit)
```

Vérifier la santé de l'API :

```bash
curl -s http://localhost:8080/health | python3 -m json.tool
```

Résultat attendu :

```json
{
  "status": "ok",
  "llm_provider": "ollama",
  "sql_model": "codestral:latest",
  "render_model": "mistral:latest"
}
```

---

## Étape 8 — Tester le pipeline

### Test v1 — Pipeline mono-agent

```bash
curl -s -X POST http://localhost:8080/query \
  -H "Content-Type: application/json" \
  -d '{"question": "Which products are below the reorder threshold?"}' \
  | python3 -m json.tool
```

### Test v2 — Multi-agent + MCP

```bash
curl -s -X POST http://localhost:8080/v2/query \
  -H "Content-Type: application/json" \
  -d '{"question": "Which products are below the reorder threshold?"}' \
  | python3 -m json.tool
```

### Questions de validation du KB

Ces questions testent spécifiquement les enrichissements KB (valeurs autorisées, sémantique métier) :

```bash
# Test allowed_values — products.status
curl -s -X POST http://localhost:8080/query \
  -H "Content-Type: application/json" \
  -d '{"question": "How many active products are there?"}' \
  | python3 -m json.tool

# Test note métier — inventory (stock critique)
curl -s -X POST http://localhost:8080/query \
  -H "Content-Type: application/json" \
  -d '{"question": "Which products have a critical stock level?"}' \
  | python3 -m json.tool

# Test allowed_values — inventory_movements.movement_type
curl -s -X POST http://localhost:8080/query \
  -H "Content-Type: application/json" \
  -d '{"question": "What is the total quantity received (IN) per warehouse?"}' \
  | python3 -m json.tool

# Test domaine Approvisionnement — suppliers + product_suppliers
curl -s -X POST http://localhost:8080/query \
  -H "Content-Type: application/json" \
  -d '{"question": "Which supplier has the best rating?"}' \
  | python3 -m json.tool
```

Résultat attendu (structure) :

```json
{
  "success": true,
  "answer": "...",
  "sql": "SELECT ...",
  "row_count": 3,
  "attempts": 1,
  "error": ""
}
```

---

## Étape 9 — Lancer l'interface Streamlit

Dans un second terminal (terminal 2), l'API doit déjà tourner :

```bash
streamlit run app.py
```

L'interface s'ouvre sur : **http://localhost:8501**

Dans la sidebar, sélectionner :
- `v1 — Mono-Agent-external` pour tester le pipeline avec KB
- `v2 — Multi-Agent + MCP` pour le pipeline multi-agent

---

## Récapitulatif — ordre d'exécution

```bash
# ── 0. Se placer dans le projet ──────────────────────────────────────────
cd /home/alimijileking/Documents/ml_projects/pipeline-reqa-sql

# ── 1. Environnement ─────────────────────────────────────────────────────
cp .env.example .env
pip install -r requirements.txt

# ── 2. Vérifier le KB ────────────────────────────────────────────────────
python3 -c "from rag.knowledge_base import load_kb; print(list(load_kb().keys()))"

# ── 3. Infrastructure ────────────────────────────────────────────────────
docker compose up -d mariadb qdrant
docker compose ps                          # attendre healthy

# ── 4. Base de données ───────────────────────────────────────────────────
docker exec -i reqa-mariadb mariadb -u example_user -ptest example_db < example.sql
docker exec -i reqa-mariadb mariadb -u example_user -ptest example_db < seed.sql

# ── 5. Modèles LLM ───────────────────────────────────────────────────────
ollama pull codestral
ollama pull mistral

# ── 6. Indexation KB dans Qdrant  ← NOUVEAU après intégration KB ────────
python3 ingest.py example.sql

# ── 7. API (terminal 1) ──────────────────────────────────────────────────
uvicorn api:app --reload --port 8080

# ── 8. Test rapide ───────────────────────────────────────────────────────
curl -s http://localhost:8080/health
curl -s -X POST http://localhost:8080/query \
  -H "Content-Type: application/json" \
  -d '{"question": "Which products are below the reorder threshold?"}' \
  | python3 -m json.tool

# ── 9. UI Streamlit (terminal 2) ─────────────────────────────────────────
streamlit run app.py
```

---

## Dépannage

### KB non trouvé — `ModuleNotFoundError: No module named 'rag'`

```bash
# Vérifier que le dossier rag/ est bien présent
ls rag/
# Attendu : __init__.py  knowledge_base.py  schema_knowledge.json

# Lancer depuis la racine du projet
cd /home/alimijileking/Documents/ml_projects/pipeline-reqa-sql
python3 ingest.py example.sql
```

### Qdrant — payload sans les clés KB (`columns`, `domain`, etc.)

Les anciens vecteurs sont en cache. Réindexer :

```bash
python3 ingest.py example.sql
```

### `build_schema_context()` retourne un DDL vide

Le payload Qdrant ne contient pas la clé `columns`. Cause : `ingest.py` n'a pas été relancé après l'intégration KB. Solution : relancer l'ingestion (voir ci-dessus).

### Qdrant — collection non trouvée

```bash
# Vérifier les collections existantes
curl -s http://localhost:6333/collections | python3 -m json.tool

# Relancer l'ingestion pour créer la collection
python3 ingest.py example.sql
```

### MariaDB — accès refusé

```bash
docker compose up -d mariadb
docker compose ps mariadb     # attendre healthy
```

### Ollama — modèle non disponible

```bash
ollama list                   # lister les modèles présents
ollama pull codestral         # retélécharger si absent
```

### Port 8080 déjà utilisé

```bash
uvicorn api:app --reload --port 8082
# Puis mettre à jour l'URL dans la sidebar Streamlit : http://localhost:8082
```
