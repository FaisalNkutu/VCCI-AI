# Détail des modifications — Intégration KB RAG

Ce document montre ligne par ligne ce qui a été ajouté, modifié ou supprimé dans les 3 fichiers du pipeline.

---

## 1. `ingest.py`

### 1.1 Docstring du module (lignes 1–14)

```diff
- What it does:
-     1. Parses all CREATE TABLE statements from the SQL file
-     2. Builds a rich text description for each table (columns, types, constraints, FKs)
-     3. Embeds each description locally (fastembed, no external API)
-     4. Upserts into Qdrant
+ What it does:
+     1. Parses all CREATE TABLE statements from the SQL file
+     2. Enriches each table with KB metadata (domain, column semantics, allowed values)
+     3. Embeds a rich KB-enriched text (not raw DDL) via fastembed
+     4. Upserts into Qdrant with a structured payload (columns, FKs, column_knowledge)
```

---

### 1.2 Import ajouté (ligne 27)

```diff
  from config import settings
  from agent.embedder import Embedder
+ from rag.knowledge_base import table_embedding_tokens, get_table_kb
```

**Pourquoi :**
- `table_embedding_tokens` : génère le texte KB enrichi à embedder dans Qdrant
- `get_table_kb` : lit les métadonnées d'une table depuis `schema_knowledge.json`

---

### 1.3 Fonction `parse_sql_to_documents()` — ajout des données structurées (lignes 84–147)

```diff
  table_name = schema_node.this.name
  col_lines, fk_lines, idx_lines = [], [], []
+ structured_cols: list[dict] = []
+ structured_fks:  list[str]  = []
```

**Deux nouvelles variables** capturent les colonnes et FKs sous forme structurée (en plus du texte DDL déjà existant) pour les stocker dans le payload Qdrant.

---

#### Bloc `ColumnDef` — ajout du calcul de `nullable` et de `structured_cols`

```diff
  if isinstance(node, exp.ColumnDef):
      col_type    = node.kind.sql("mysql") if node.kind else "UNKNOWN"
      constraints = _col_constraints(node)
+     nullable    = (
+         "NO" if ("NOT NULL" in constraints or "PRIMARY KEY" in constraints)
+         else "YES"
+     )
+     structured_cols.append({
+         "name":     node.name,
+         "type":     col_type,
+         "nullable": nullable,
+     })
      line = f"  - {node.name} {col_type}"
      if constraints:
          line += "  [" + ", ".join(constraints) + "]"
      col_lines.append(line)
```

**Pourquoi :**
- `nullable` est calculé depuis les contraintes SQL plutôt qu'interrogé en base
- `structured_cols` est la liste de dicts `{name, type, nullable}` attendue par `build_ddl_with_kb()` dans `knowledge_base.py`

---

#### Bloc `ForeignKey` — ajout de `structured_fks`

```diff
  elif isinstance(node, exp.ForeignKey):
      fk_cols = [c.name for c in node.expressions]
      ref = node.args.get("reference")
      if ref:
          try:
              ref_table = ref.this.name
              ref_cols  = [c.name for c in ref.expressions]
              fk_lines.append(
                  f"  - ({', '.join(fk_cols)}) → {ref_table}({', '.join(ref_cols)})"
              )
+             for fc, rc in zip(fk_cols, ref_cols):
+                 structured_fks.append(f"{fc} → {ref_table}.{rc}")
          except Exception:
              pass
```

**Pourquoi :**
- `fk_lines` (texte) est conservé pour la `description` lisible
- `structured_fks` (format `"col → parent_table.col"`) est le format attendu par `build_ddl_with_kb()`

---

#### Construction du document — payload enrichi

```diff
- documents.append({"table": table_name, "description": "\n".join(parts)})
+ kb_entry = get_table_kb(table_name)
+ documents.append({
+     "table":            table_name,
+     "description":      "\n".join(parts),    # conservé pour rétrocompatibilité
+     "domain":           kb_entry.get("domain", "General"),
+     "columns":          structured_cols,
+     "foreign_keys":     structured_fks,
+     "column_knowledge": kb_entry.get("columns", {}),
+ })
```

**Avant** : le payload ne contenait que `table` et `description` (texte brut).

**Après** : le payload contient 4 champs supplémentaires :

| Clé | Type | Contenu |
|---|---|---|
| `domain` | `str` | Domaine fonctionnel lu du KB (`Catalogue`, `Logistique`, `Approvisionnement`) |
| `columns` | `list[dict]` | `[{name, type, nullable}, ...]` — colonnes structurées |
| `foreign_keys` | `list[str]` | `["col → parent.col", ...]` — FKs au format lisible |
| `column_knowledge` | `dict` | Métadonnées KB par colonne (`description`, `allowed_values`, `notes`) |

---

### 1.4 Fonction `ingest()` — embedding KB-enrichi (lignes 178–182)

```diff
  points = []
  for i, doc in enumerate(documents):
-     vector = embedder.embed(doc["description"])
+     embedding_text = table_embedding_tokens(doc["table"], doc["description"])
+     vector = embedder.embed(embedding_text)
      points.append(PointStruct(id=i, vector=vector, payload=doc))

  client.upsert(collection_name=settings.QDRANT_COLLECTION, points=points)
- print(f"[ingest] ✓ {len(points)} table schemas ingested into Qdrant.")
+ print(f"[ingest] ✓ {len(points)} table schemas ingested into Qdrant (KB-enriched embeddings).")
```

**Avant** : le vecteur était calculé depuis le texte DDL brut (`"Table: products\nColumns:\n  - status ENUM..."`).

**Après** : le vecteur est calculé depuis `table_embedding_tokens()` qui produit un texte structuré de la forme :

```
table:products | domain:Catalogue | description:Catalogue principal des produits … |
col:status=Statut commercial values:draft,active,archived |
col:price=Prix de vente brut eg:"5.99","49.99","299.99" note:>= 0 |
referenced_by:inventory.product_id,product_suppliers.product_id |
sample_q:Quels sont les 5 produits les plus chers ?
```

Ce texte encode la sémantique métier → la recherche vectorielle est plus précise.

---

## 2. `agent/schema_rag.py`

### 2.1 Import ajouté (ligne 3)

```diff
  from qdrant_client import QdrantClient
  from agent.embedder import Embedder
+ from rag.knowledge_base import build_ddl_with_kb, extract_business_rules
```

**Pourquoi :**
- `build_ddl_with_kb` : génère un DDL CREATE TABLE avec commentaires KB inline
- `extract_business_rules` : extrait les règles `col ∈ {val1, val2}` depuis le KB

---

### 2.2 Nouvelle méthode `build_schema_context()` (lignes 28–53)

Méthode entièrement nouvelle, insérée entre `retrieve()` et `all_table_names()`.

```python
def build_schema_context(self, payloads: list[dict]) -> str:
    """
    Build a KB-enriched schema context string for the SQL generator prompt.

    Each table is rendered as a DDL CREATE TABLE with inline KB comments
    (column descriptions, allowed values, notes) plus a business rules section
    listing all constrained enum values.
    """
    ddl_sections: list[str] = []
    all_rules:    list[str] = []

    for p in payloads:
        table        = p.get("table", "")
        columns      = p.get("columns", [])
        foreign_keys = p.get("foreign_keys", [])

        ddl_sections.append(build_ddl_with_kb(table, columns, foreign_keys))
        all_rules.extend(extract_business_rules(table))

    result = "\n".join(ddl_sections)

    if all_rules:
        result += "\n-- ── Business Rules (valeurs autorisées) ─────────────────────────────\n"
        result += "\n".join(f"-- {r}" for r in all_rules)

    return result
```

**Ce que produit cette méthode** — exemple pour une query sur les produits :

```sql
-- [Catalogue] products
-- Description: Catalogue principal des produits — articles disponibles à la vente avec prix et statut
-- Referenced by: inventory.product_id, inventory_movements.product_id, product_suppliers.product_id
CREATE TABLE products (
    product_id        BIGINT NOT NULL         -- Clé primaire surrogate
    category_id       INT NOT NULL            -- Catégorie du produit.  (FK → categories.category_id)
    sku               VARCHAR(50) NOT NULL    -- Stock Keeping Unit — identifiant unique du produit
    product_name      VARCHAR(150) NOT NULL   -- Nom d'affichage du produit
    status            ENUM NOT NULL           -- Statut commercial. Allowed: draft|active|archived.  (Utiliser status = 'active' pour les produits disponibles à la vente.)
    price             DECIMAL(10,2) NOT NULL  -- Prix de vente brut. e.g. "5.99", "49.99".  (Prix net = price * (1 - discount_percent / 100.0))
    discount_percent  TINYINT NOT NULL        -- Remise en %. e.g. "0", "5", "10".  (Entre 0 et 100.)
    -- Foreign keys:
    --   category_id → categories.category_id
);

-- ── Business Rules (valeurs autorisées) ─────────────────────────────
-- products.status ∈ {'draft', 'active', 'archived'}
-- inventory_movements.movement_type ∈ {'IN', 'OUT', 'ADJUSTMENT'}
```

**Comparaison avant/après pour le LLM :**

| | Avant | Après |
|---|---|---|
| Format | Texte brut DDL | DDL commenté avec KB |
| Domaine | Absent | `-- [Catalogue] products` |
| Description table | Absent | `-- Catalogue principal des produits …` |
| Sémantique colonne | Absent | `-- Statut commercial. Allowed: draft|active|archived` |
| Règles métier | Absent | `-- products.status ∈ {'draft', 'active', 'archived'}` |
| FKs | Texte brut | Commentaire SQL lisible |

---

### 2.3 Méthode `retrieve()` — inchangée

La méthode de recherche vectorielle n'a pas été modifiée. Elle retourne toujours les `top_k` payloads depuis Qdrant. Mais ces payloads sont maintenant plus riches (grâce aux changements dans `ingest.py`).

---

### 2.4 Méthode `all_table_names()` — inchangée

Toujours basée sur la clé `"table"` du payload, conservée telle quelle.

---

## 3. `agent/pipeline.py`

### 3.1 Une seule ligne modifiée (ligne 62)

```diff
  # ── Schema RAG ────────────────────────────────────────────────────────
  schema_chunks = self.schema_rag.retrieve(question)
- schema_context = "\n\n".join(c.get("description", "") for c in schema_chunks)
+ schema_context = self.schema_rag.build_schema_context(schema_chunks)
  all_tables = self.schema_rag.all_table_names()
```

**Avant** : la variable `schema_context` était construite en concaténant les champs `description` bruts des payloads Qdrant, séparés par des lignes vides.

**Après** : elle est construite par `build_schema_context()` qui produit le DDL enrichi KB avec business rules.

**Le reste du pipeline est inchangé** — `schema_context` est passée telle quelle à `sql_generator.generate()`, donc aucune autre modification n'est nécessaire.

---

## Récapitulatif des lignes touchées

| Fichier | Lignes ajoutées | Lignes supprimées | Lignes modifiées |
|---|---|---|---|
| `ingest.py` | +25 | -3 | 4 |
| `agent/schema_rag.py` | +27 | 0 | 1 |
| `agent/pipeline.py` | +1 | -1 | 1 |
| **Total** | **+53** | **-4** | **6** |

---

## Action requise pour activer les changements

```bash
# Réindexer Qdrant avec les nouveaux vecteurs KB-enrichis
python ingest.py example.sql
```

Sans cette étape, Qdrant contient encore les anciens vecteurs (DDL brut). Les payloads retournés par `retrieve()` n'auront pas les clés `columns`, `foreign_keys`, `column_knowledge` — `build_schema_context()` retournera alors des DDL vides.
