


from pydantic import BaseModel
from qdrant_client import QdrantClient


from agent.embedder import Embedder
from agent.schema_rag import SchemaRAG
from agent.sql_generator import SQLGenerator
from agent.static_check import StaticChecker
from agent.dry_run import DryRunner
from agent.executor import Executor
from agent.renderer import Renderer
from agent.circuit_breaker import CircuitBreaker
from agent.pipeline import Pipeline, _build_llm
from agent.pipelines.rated_rules_pipeline import RatedRulesPipeline
from agent.pipelines.dbagent_pipeline import DBAgentPipeline
from agent.pipelines.datagora_tool_pipeline import DatagoraToolPipeline


import sys
#=======================   config.json  ====================================================
from config.settings import get_settings
#===========================================================================================

settings = get_settings()

from a2a_base_agent_setup import A2AAgentBaseSetup, init_asyncio
from dotenv import load_dotenv


VERBOSE_DEBUG = True
import logging
logging.basicConfig(level=logging.DEBUG,format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("PIPELINE") 

settings = get_settings()



def get_pipeline_instance( query : str = None, **kwargs ):
   
    logger.info(f"*****************************************************************************************************************")
    logger.info(f"*    get_pipeline_instance({query})")
    logger.info(f"*****************************************************************************************************************")

    qlow = (query or "").lower()

    pipeline = kwargs.get("pipeline", "base")

    
    if "ambi" in pipeline:
        return DatagoraToolPipeline.get_pipeline_instance()            
    elif "rated" in pipeline:
        return RatedRulesPipeline.get_pipeline_instance()            
    elif "agent" in pipeline:
        return DBAgentPipeline.get_pipeline_instance()                
    else:
        return get_base_pipeline_instance()        
    


BASE_PIPELINE_INSTANCE = None
def get_base_pipeline_instance():
    global BASE_PIPELINE_INSTANCE

    logger.info(f"BASE PIPELINE INSTANCE")

    if BASE_PIPELINE_INSTANCE == None:
        load_dotenv()
        settings = get_settings()
        
        _db_params = dict(
            host=settings.DB_HOST,
            port=settings.DB_PORT,
            database=settings.DB_NAME,
            user=settings.DB_USER,
            password=settings.DB_PASSWORD,
        )

        # codestral → SQL generation (specialized)
        # mistral   → natural language rendering (general purpose)
        sql_llm    = _build_llm(settings.ollama_sql_model)
        render_llm = _build_llm(settings.ollama_render_model)

        qdrant     = QdrantClient(host=settings.QDRANT_HOST, port=settings.QDRANT_PORT)
        embedder   = Embedder()
        schema_rag = SchemaRAG(qdrant, embedder, settings.QDRANT_COLLECTION, settings.top_k_tables)

        BASE_PIPELINE_INSTANCE = Pipeline(
            schema_rag     = schema_rag,
            sql_generator  = SQLGenerator(sql_llm, settings.max_rows),
            static_checker = StaticChecker(),
            dry_runner     = DryRunner(_db_params),
            executor       = Executor(_db_params),
            renderer       = Renderer(render_llm),
            circuit_breaker= CircuitBreaker(settings.circuit_breaker_threshold),
            max_retries    = settings.max_sql_retries,
        )

    
    return BASE_PIPELINE_INSTANCE



