# REQA agent evaluation report

- API: `http://localhost:8080`
- Started: 2026-07-28 12:51:56
- Queries: 24
- Latency: avg 257.7s / max 401.9s

## Scores

| Metric | Value |
|---|---|
| Success rate | 2/24 (8.3%) |
| Mean confidence (successes) | 67.5% |
| Mean rag_conf | 78.7% |
| Mean gen_conf | 66.7% |
| Mean sem_conf | 57.5% |
| Mean score_strict | 41.2% |
| **Global score** (rate x conf) | **5.6%** |

## Outcome summary

| Outcome | Count | Share |
|---|---|---|
| success | 2 | 8% |
| empty_success | 14 | 58% |
| failed | 4 | 17% |
| timeout | 4 | 17% |

`empty_success` = the silent-failure class (SUCCESS with 0 rows):
review each one manually -- it usually means an invented enum value,
contradictory filters, or a wrong join that the guards did not catch.

## Per-query results

| ID | Outcome | Latency | Attempts | Rows | Conf | Strict | Guards | Question |
|---|---|---|---|---|---|---|---|---|
| q1 | WARN(0 rows) | 135.3s | 1 | 0 | 0.94 | 0.92 |  | How did the combat power of unit 1 IG BG HQ (Object Item ID: 1457) cha... |
| q2 | PASS | 323.0s | 2 | 1 | 0.55 | 0.11 | attempt 1: CONTRADICTION GUARD | Show the combat power trend for unit 1 IG BG HQ (Object Item ID: 1457)... |
| q3 | TIMEOUT | 401.9s |  |  |  |  |  | How did the operational equipment holdings of unit 1 IG BG HQ (Object ... |
| q4 | WARN(0 rows) | 214.1s | 1 | 0 | 0.91 | 0.89 |  | Show the equipment quantity trend by capability category for unit 1 IG... |
| q5 | WARN(0 rows) | 143.2s | 1 | 0 | 0.92 | 0.89 |  | How did enemy activity evolve within the control measure "BLUFOR KZ fo... |
| q6 | WARN(0 rows) | 133.2s | 1 | 0 | 0.91 | 0.89 |  | Show the enemy entity and engagement trend for control measure "BLUFOR... |
| q7 | WARN(0 rows) | 203.9s | 1 | 0 | 0.93 | 0.90 |  | Which enemy entities were present within "BLUFOR KZ for Red units" at ... |
| q8 | WARN(0 rows) | 123.2s | 1 | 0 | 0.93 | 0.90 |  | Which enemy entities were actively engaged within "BLUFOR KZ for Red u... |
| q9 | WARN(0 rows) | 102.9s | 1 | 0 | 0.92 | 0.89 |  | List all control measures available for Enemy Engagement analysis. |
| q10 | WARN(0 rows) | 82.8s | 1 | 0 | 0.92 | 0.90 |  | How did the picture of enemy evolve within control measure "BLUFOR KZ ... |
| q11 | WARN(0 rows) | 115.0s | 1 | 0 | 0.91 | 0.87 |  | Which enemy entities were detected within control measure "BLUFOR KZ f... |
| q12 | WARN(0 rows) | 230.0s | 1 | 0 | 0.92 | 0.90 |  | Which control measures are available for Picture of Enemy analysis? |
| q13 | WARN(0 rows) | 203.8s | 1 | 0 | 0.92 | 0.89 |  | At which simulation times did the number of detected enemy entities in... |
| q14 | FAIL | 397.5s | 3 | 0 | 0.00 |  | attempt 1: CONTRADICTION GUARD; attempt 2: explain | How did the movement speed of unit 1 IG BG HQ (Object Item ID: 1457) c... |
| q15 | FAIL | 391.4s | 3 | 0 | 0.00 |  | attempt 1: CONTRADICTION GUARD; attempt 2: explain | How did the cumulative distance traveled by unit 4 BDE 2 MERCIAN A COY... |
| q16 | TIMEOUT | 401.5s |  |  |  |  |  | Show the cumulative movement distance (last-hour sliding window) for u... |
| q17 | PASS | 391.6s | 2 | 1 | 0.80 | 0.72 | attempt 1: explain | Provide a movement summary for unit 4 BDE 2 MERCIAN A COY 2 PL (Object... |
| q18 | TIMEOUT | 400.5s |  |  |  |  |  | Where was unit 4 BDE 2 MERCIAN A COY 2 PL (Object Item ID: 1488) locat... |
| q19 | FAIL | 368.8s | 3 | 0 | 0.00 |  | attempt 1: explain; attempt 2: explain; attempt 3: explain | Which Areas of Operation and capture periods are available for Rate of... |
| q20 | TIMEOUT | 401.1s |  |  |  |  |  | Which units crossed the Line of Departure for H-Hour "LoD Red", and ho... |
| q21 | WARN(0 rows) | 363.9s | 3 | 0 | 0.63 | 0.46 | attempt 1: static_check; attempt 2: static_check | Show all units that crossed LoD Red, including crossing time, location... |
| q22 | WARN(0 rows) | 165.7s | 1 | 0 | 0.92 | 0.89 |  | Which H-Hour plans and associated Lines of Departure are available for... |
| q23 | WARN(0 rows) | 105.3s | 1 | 0 | 0.97 | 0.96 |  | Where did each unit first cross the LoD Red Line of Departure during t... |
| q24 | FAIL | 386.2s | 3 | 0 | 0.00 |  | attempt 1: static_check; attempt 2: static_check; attempt 3: static_check | Show the first recorded crossing location for each unit that crossed L... |

## Needs attention (SQL + error detail)

### q1 -- empty_success
**Q:** How did the combat power of unit 1 IG BG HQ (Object Item ID: 1457) change throughout the operation?

```sql
SELECT mr.time, cmpr.cpower
 FROM unit u
 JOIN org o ON u.unit_id = o.org_id
 JOIN metrics_results mr ON o.org_id = mr.obj_item_id AND mr.obj_item_id = 1457
 JOIN combat_power_metrics_results cmpr ON mr.metrics_result_id = cmpr.cpower_metrics_result_id
 WHERE u.unit_id = (SELECT unit_id FROM unit WHERE unit_id = 1) -- assuming '1' is the ID for '1 IG BG HQ'
 ORDER BY mr.time
```

Error: `SUCCESS with 0 rows (silent failure class)`

Answer (truncated): No results found.

### q3 -- timeout
**Q:** How did the operational equipment holdings of unit 1 IG BG HQ (Object Item ID: 1457) change by capability category from simulation time 0 to 900000?

Error: `{'stage': 'sql_generation', 'attempt': 3, 'of': 3}`

### q4 -- empty_success
**Q:** Show the equipment quantity trend by capability category for unit 1 IG BG HQ (Object Item ID: 14 57).

```sql
SELECT capab.cat_code AS Capability, SUM(obj_type_capab_norm.qty) AS TotalQuantity
FROM obj_item
JOIN obj_item_type ON obj_item.obj_item_id = obj_item_type.obj_item_id
JOIN obj_type ON obj_type.obj_type_id = obj_item_type.obj_type_id
JOIN obj_type_capab_norm ON obj_type.obj_type_id = obj_type_capab_norm.obj_type_id
JOIN capab ON capab.capab_id = obj_type_capab_norm.capab_id
WHERE obj_item.obj_item_id = 1457 AND obj_item.name_txt = '1 IG BG HQ' -- Filter for the specific unit and object item ID
GROUP BY capab.cat_code
```

Error: `SUCCESS with 0 rows (silent failure class)`

Answer (truncated): No results found.

### q5 -- empty_success
**Q:** How did enemy activity evolve within the control measure "BLUFOR KZ for Red units" throughout the operation? Report the number of enemy entities present and the number of enemy entities actively engaged at each simulation time.

```sql
SELECT mr.time, COUNT(DISTINCT eemr.ctrl_measure_id) AS num_enemy_entities, SUM(eemr.num_engaged) AS num_engaged_entities
 FROM metrics_results mr
 JOIN enemy_engagement_metrics_results eemr ON mr.metrics_result_id = eemr.en_eng_metrics_result_id
 WHERE eemr.ctrl_measure_name = 'BLUFOR KZ for Red units'
 GROUP BY mr.time
 ORDER BY mr.time
```

Error: `SUCCESS with 0 rows (silent failure class)`

Answer (truncated): No results found.

### q6 -- empty_success
**Q:** Show the enemy entity and engagement trend for control measure "BLUFOR KZ for Red units" (Control Measure ID: 1650) over the selected simulation period.

```sql
SELECT
 metrics_results.sim_start_time AS start_time,
 metrics_results.time AS end_time,
 enemy_engagement_metrics_results.ctrl_measure_name AS ctrl_measure,
 enemy_engagement_metrics_results.num_entities AS total_entities,
 enemy_engagement_metrics_results.num_engaged AS engaged_entities
 FROM
 metrics_results
 JOIN
 enemy_engagement_metrics_results ON metrics_results.metrics_result_id = enemy_engagement_metrics_results.en_eng_metrics_result_id
 WHERE
 enemy_engagement_metrics_results.ctrl_measure_name = 'BLUFOR KZ for Red units' AND
 enemy_engagement_metrics_results.ctrl_measure_id = 1650
```

Error: `SUCCESS with 0 rows (silent failure class)`

Answer (truncated): No results found.

### q7 -- empty_success
**Q:** Which enemy entities were present within "BLUFOR KZ for Red units" at simulation time 960000?

```sql
SELECT eermr.engaged_entities
 FROM enemy_engagement_metrics_results AS eermr
 JOIN metrics_results AS mr ON mr.metrics_result_id = eermr.en_eng_metrics_result_id
 WHERE eermr.ctrl_measure_name = "BLUFOR KZ for Red units" AND mr.time = 960000
```

Error: `SUCCESS with 0 rows (silent failure class)`

Answer (truncated): No results found.

### q8 -- empty_success
**Q:** Which enemy entities were actively engaged within "BLUFOR KZ for Red units" at simulation time 960000?

```sql
SELECT eermr.engaged_entities
 FROM enemy_engagement_metrics_results AS eermr
 JOIN metrics_results AS mr ON mr.metrics_result_id = eermr.en_eng_metrics_result_id
 WHERE eermr.ctrl_measure_name = "BLUFOR KZ for Red units" AND mr.time = 960000
```

Error: `SUCCESS with 0 rows (silent failure class)`

Answer (truncated): No results found.

### q9 -- empty_success
**Q:** List all control measures available for Enemy Engagement analysis.

```sql
SELECT *
 FROM enemy_engagement_metrics_results
 JOIN metrics_results ON metrics_results.metrics_result_id = enemy_engagement_metrics_results.en_eng_metrics_result_id
 WHERE metrics_results.cat_code = 'ENEENG'
```

Error: `SUCCESS with 0 rows (silent failure class)`

Answer (truncated): No results found.

### q10 -- empty_success
**Q:** How did the picture of enemy evolve within control measure "BLUFOR KZ for Red units" throughout the operation? Report the total offside entities and detected enemy entities at each simulation time.

```sql
SELECT mr.time AS simulation_time, poe.total_offside_entities, poe.num_detected_entities
 FROM metrics_results AS mr
 JOIN picture_of_enemy_metrics_results AS poe ON mr.metrics_result_id = poe.poe_metrics_result_id
 WHERE poe.ctrl_measure_name = 'BLUFOR KZ for Red units'
 GROUP BY mr.time, poe.total_offside_entities, poe.num_detected_entities
```

Error: `SUCCESS with 0 rows (silent failure class)`

Answer (truncated): No results found.

### q11 -- empty_success
**Q:** Which enemy entities were detected within control measure "BLUFOR KZ for Red units" at simulation time 960000?

```sql
SELECT eemr.entities AS detected_enemy_entities
 FROM enemy_engagement_metrics_results AS eemr
 JOIN metrics_results AS mr ON mr.metrics_result_id = eemr.en_eng_metrics_result_id
 WHERE mr.time = 960000 AND eemr.ctrl_measure_name = "BLUFOR KZ for Red units"
```

Error: `SUCCESS with 0 rows (silent failure class)`

Answer (truncated): No results found.

### q12 -- empty_success
**Q:** Which control measures are available for Picture of Enemy analysis?

```sql
SELECT DISTINCT ctrl_measure_id, ctrl_measure_name FROM picture_of_enemy_metrics_results
```

Error: `SUCCESS with 0 rows (silent failure class)`

Answer (truncated): No results found.

### q13 -- empty_success
**Q:** At which simulation times did the number of detected enemy entities increase or decrease within control measure "BLUFOR KZ for Red units"?

```sql
SELECT mr.time, COUNT(poemr.num_detected_entities) AS entity_count
 FROM metrics_results mr
 JOIN picture_of_enemy_metrics_results poemr ON mr.metrics_result_id = poemr.poe_metrics_result_id
 WHERE poemr.ctrl_measure_name = 'BLUFOR KZ for Red units'
 GROUP BY mr.time, poemr.num_detected_entities
 HAVING COUNT(*) > 1
```

Error: `SUCCESS with 0 rows (silent failure class)`

Answer (truncated): No results found.

### q14 -- failed
**Q:** How did the movement speed of unit 1 IG BG HQ (Object Item ID: 1457) change throughout the operation?

Error: `EXPLAIN failed: (1054, "Unknown column 'op.time' in 'SELECT'")
HOW TO FIX: Column 'time' does not exist in the tables of this schema. Closest real columns: time, time. Use only the columns listed in the CREATE TABLE above, or state that the information is not available.`

Answer (truncated): Could not generate a valid query after multiple attempts.

### q15 -- failed
**Q:** How did the cumulative distance traveled by unit 4 BDE 2 MERCIAN A COY 2 PL (Object Item ID: 1488) change throughout the operation?

Error: `EXPLAIN failed: (4074, 'Window functions can not be used as arguments to group functions.')
HOW TO FIX: Window functions are not supported by this engine. Rewrite with a correlated subquery or a self-join.`

Answer (truncated): Could not generate a valid query after multiple attempts.

### q16 -- timeout
**Q:** Show the cumulative movement distance (last-hour sliding window) for unit 4 BDE 2 MERCIAN A COY 2 PL (Object Item ID: 1488) during the selected simulation period.

Error: `{'stage': 'static_check', 'attempt': 1, 'of': 3}`

### q18 -- timeout
**Q:** Where was unit 4 BDE 2 MERCIAN A COY 2 PL (Object Item ID: 1488) located at each recorded movement interval while operating within the ABACUS Play Area?

Error: `{'stage': 'sql_generation', 'attempt': 2, 'of': 3}`

### q19 -- failed
**Q:** Which Areas of Operation and capture periods are available for Rate of Movement analysis?

Error: `EXPLAIN failed: (1054, "Unknown column 'rom_metrics_spec.ctrl_measure_name' in 'SELECT'")
HOW TO FIX: Column 'ctrl_measure_name' does not exist in the tables of this schema. Closest real columns: ctrl_measure_name, ctrl_measure_id. Use only the columns listed in the CREATE TABLE above, or state that the information is not available.`

Answer (truncated): Could not generate a valid query after multiple attempts.

### q20 -- timeout
**Q:** Which units crossed the Line of Departure for H-Hour "LoD Red", and how many minutes early or late did each unit cross relative to the planned H-Hour?

Error: `{'stage': 'explain', 'attempt': 3, 'of': 3}`

### q21 -- empty_success
**Q:** Show all units that crossed LoD Red, including crossing time, location, and deviation from H-Hour

```sql
SELECT
 hr.time AS crossing_time,
 CONCAT(hmr.lat_coord, ', ', hmr.long_coord) AS location,
 (hr.time - hs.time) AS deviation_from_hhour
 FROM
 metrics_results hr
 JOIN
 hhour_metrics_results hmr ON hr.metrics_result_id = hmr.hh_metrics_result_id
 JOIN
 hhour_metrics_spec hs ON hmr.hh_metrics_spec_ix = hs.hhour_metrics_spec_id
 WHERE
 hs.line_of_departure_name = 'Red'
```

Error: `SUCCESS with 0 rows (silent failure class)`

Answer (truncated): No results found.

### q22 -- empty_success
**Q:** Which H-Hour plans and associated Lines of Departure are available for assessment?

```sql
SELECT hms.*, st.*
 FROM hhour_metrics_spec AS hms
 JOIN metrics_spec AS ms ON ms.metrics_spec_id = hms.hhour_metrics_spec_id
 LEFT JOIN simulator_task AS st ON st.simulator_task_id = hms.hhour_metrics_spec_id AND st.type_cat_code = 'PLAN'
 WHERE ms.cat_code = 'HHOUR'
```

Error: `SUCCESS with 0 rows (silent failure class)`

Answer (truncated): No results found.

### q23 -- empty_success
**Q:** Where did each unit first cross the LoD Red Line of Departure during the operation?

```sql
SELECT u.unit_id, MIN(os.rdns_dur) AS lod_red_crossing_time
 FROM unit u
 JOIN org o ON o.org_id = u.unit_id
 JOIN obj_item_stat ois ON ois.obj_item_id = o.org_id
 JOIN org_stat os ON os.obj_item_stat_ix = ois.obj_item_stat_ix AND os.org_stat_id = o.org_id
 WHERE os.rdns_code = 'NRD12H' -- Assuming NRD12H represents LoD Red in the rdns_code column
 GROUP BY u.unit_id
```

Error: `SUCCESS with 0 rows (silent failure class)`

Answer (truncated): No results found.

### q24 -- failed
**Q:** Show the first recorded crossing location for each unit that crossed LoD Red, including the crossing time and coordinate

Error: `Syntax/policy error: Parse error: Required keyword: 'this' missing for <class 'sqlglot.expressions.query.Where'>. Line 8, Col: 9.
  j_item_loc oi ON l.loc_id = oi.loc_id
 WHERE -- Add condition representing 'LoD Red' crossing here
 GROUP BY u.unit_id`

Answer (truncated): Could not generate a valid query after multiple attempts.

