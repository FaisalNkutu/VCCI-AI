# Execution Guide — pipeline-reqa-sql

Architecture : **Multi-agent (5 agents) + MCP (2 serveurs)** + API FastAPI (v1 pipeline / v2 multi-agent)

---

## Prérequis

| Outil | Version minimale | Rôle |
|---|---|---|
| Docker + Docker Compose | 24+ | MariaDB, Qdrant |
| Python | 3.10+ | API + agents |
| Ollama | dernière | LLMs locaux |
| pip | 23+ | Dépendances Python |

---

## Étape 1 — Cloner et installer les dépendances

```bash
cd pipeline-reqa-sql
pip install -r requirements.txt
```

Le fichier `requirements.txt` inclut notamment :
- `mcp>=1.0.0` — protocole MCP pour les agents
- `qdrant-client[fastembed]` — base vectorielle + embeddings locaux
- `PyMySQL` — connecteur MariaDB
- `fastapi` + `uvicorn` — API REST
- `sqlglot` — validation syntaxe SQL

---

## Étape 2 — Démarrer l'infrastructure Docker

```bash
docker compose up -d mariadb qdrant
```

Vérifie que les services sont healthy :

```bash
docker compose ps
```

Résultat attendu :

```
NAME           STATUS
reqa-mariadb   Up (healthy)
reqa-qdrant    Up (healthy)
```

Ports exposés :
- MariaDB : `localhost:3306`
- Qdrant  : `localhost:6333`

---

## Étape 3 — Télécharger les modèles Ollama

Le projet utilise deux modèles distincts :

```bash
ollama pull codestral   # SQL generation (~9 GB) — spécialisé text-to-SQL
ollama pull mistral     # Natural language rendering (~5 GB) — généraliste
```

> **Alternatives légères** si RAM insuffisante :
> ```bash
> ollama pull codellama:7b   # ~4 GB — remplace codestral
> ollama pull phi4           # ~9 GB — meilleure qualité généraliste
> ```
> Dans ce cas, mettre à jour `.env.example` :
> ```env
> OLLAMA_SQL_MODEL=codellama:7b
> OLLAMA_MODEL=phi4
> ```

Vérifier les modèles disponibles :

```bash
ollama list
```

---

## Étape 4 — Configurer les variables d'environnement

Le fichier `.env.example` est utilisé directement. Vérifier les valeurs par défaut :

```env
LLM_PROVIDER=ollama
OLLAMA_BASE_URL=http://ollama:11434
OLLAMA_SQL_MODEL=codestral:latest
OLLAMA_MODEL=mistral:latest

DB_HOST=localhost
DB_PORT=3306
DB_NAME=example_db
DB_USER=example_user
DB_PASSWORD=test

QDRANT_HOST=localhost
QDRANT_PORT=6333
QDRANT_COLLECTION=schema

MAX_SQL_RETRIES=3
CB_THRESHOLD=3
TOP_K_TABLES=5
MAX_ROWS=100
```

---

## Étape 5 — Ingérer le schéma SQL dans Qdrant

Cette étape parse les `CREATE TABLE` de ton fichier SQL, génère des embeddings locaux (fastembed, ~130 MB téléchargés au premier lancement), et les stocke dans Qdrant.

```bash
# Avec le schéma de démonstration fourni
python3 ingest.py example.sql

# Avec ton propre schéma
python3 ingest.py chemin/vers/mon-schema.sql
```

Résultat attendu :

```
[ingest] Parsed 7 tables: ['categories', 'suppliers', 'warehouses', 'products', ...]
[ingest] Loading embedding model (first run downloads ~130 MB)...
[ingest] Qdrant collection 'schema' ready.
[ingest] ✓ 7 table schemas ingested into Qdrant.
```

Vérifier l'ingestion :

```bash
curl http://localhost:6333/collections/schema
```

---

## Étape 6 — Lancer l'API

```bash
uvicorn api:app --reload --port 8080
```

Résultat attendu :

```
INFO:     Started server process
INFO:     Uvicorn running on http://0.0.0.0:8080 (Press CTRL+C to quit)
INFO:     Application startup complete.
```

Swagger UI disponible sur : `http://localhost:8080/docs`

---

## Étape 7 — Tester les endpoints

### Santé du service

```bash
curl http://localhost:8080/health
```

```json
{
  "status": "ok",
  "llm_provider": "ollama",
  "sql_model": "codestral:latest",
  "render_model": "mistral:latest"
}
```

---

### v1 — Pipeline mono-agent (original)

```bash
curl -X POST http://localhost:8080/query \
  -H "Content-Type: application/json" \
  -d '{"question": "Which products are below the reorder threshold?"}'
```

Réponse :

```json
{
  "success": true,
  "answer": "3 products are currently below their reorder threshold.\n\n| product_name | ...",
  "sql": "SELECT p.product_name, i.quantity_on_hand ...",
  "row_count": 3,
  "attempts": 1,
  "error": ""
}
```

---

### v2 — Multi-agent + MCP (nouveau)

```bash
curl -X POST http://localhost:8080/v2/query \
  -H "Content-Type: application/json" \
  -d '{"question": "Which products are below the reorder threshold?"}'
```

Réponse (inclut la trace d'exécution des agents) :

```json
{
  "success": true,
  "answer": "3 products are currently below their reorder threshold.\n\n| product_name | ...",
  "sql": "SELECT p.product_name, i.quantity_on_hand ...",
  "row_count": 3,
  "attempts": 1,
  "error": "",
  "trace": [
    "orchestrator → schema_agent",
    "schema_agent ✓ — 7 tables indexed, top: ['products', 'inventory', ...]",
    "orchestrator → sql_agent",
    "sql_agent ✓ — SQL validated in 1 attempt(s)",
    "orchestrator → executor_agent",
    "executor_agent ✓ — 3 row(s) returned",
    "orchestrator → renderer_agent",
    "renderer_agent ✓ — answer ready"
  ]
}
```

---

### A2A — Agent-to-Agent protocol (v1 et v2)

Découverte de l'agent :

```bash
curl http://localhost:8080/.well-known/agent.json
```

Envoi d'une tâche A2A (v1) :

```bash
curl -X POST http://localhost:8080/tasks/send \
  -H "Content-Type: application/json" \
  -d '{
    "id": "task-001",
    "message": {
      "role": "user",
      "parts": [{"type": "text", "text": "Who are the top 5 customers by revenue?"}]
    }
  }'
```

Envoi d'une tâche A2A (v2 multi-agent) :

```bash
curl -X POST http://localhost:8082/v2/tasks/send \
  -H "Content-Type: application/json" \
  -d '{
    "id": "task-002",
    "message": {
      "role": "user",
      "parts": [{"type": "text", "text": "How many orders were placed last month?"}]
    }
  }'
```

---

### Test A2A live (script fourni)

```bash
python3 test_a2a_live.py

# Avec une question personnalisée
python3 test_a2a_live.py "Which warehouses have the most stock?"
```

---

## Étape 8 — Interface Streamlit (UI)

L'interface Streamlit se connecte à l'API FastAPI et permet d'interagir visuellement avec le système multi-agent.

### Lancer l'interface

Dans un **second terminal** (l'API doit déjà tourner sur le port 8080) :

```bash
streamlit run app.py
```

L'interface s'ouvre automatiquement sur : `http://localhost:8501`

### Fonctionnalités

| Fonctionnalité | Description |
|---|---|
| Choix du mode | Switcher entre v1 (pipeline) et v2 (multi-agent + MCP) |
| Questions exemples | 3 boutons de questions pré-remplies |
| Statut API | Indicateur de connexion en temps réel dans la sidebar |
| Réponse formatée | Phrase introductive + tableau de données interactif |
| SQL généré | Bloc de code avec coloration syntaxique |
| Trace des agents | Étapes d'exécution de chaque agent (v2 uniquement) |
| Métriques | Lignes retournées, tentatives SQL, durée de la requête |
| Historique | Toutes les questions de la session avec leurs résultats |

### Aperçu de l'interface

```
┌─ Sidebar ──────────────────┐  ┌─ Main ──────────────────────────────────┐
│ ⚙️ Configuration           │  │ 🔍 REQA-SQL                             │
│ API URL: localhost:8080    │  │                                         │
│ Mode: v2 Multi-Agent       │  │ [Exemple 1] [Exemple 2] [Exemple 3]     │
│                            │  │                                         │
│ Statut: ● Connecté         │  │ [Zone de saisie de la question...]      │
│ SQL model: codestral       │  │ [▶ Envoyer]                             │
│ Render: mistral            │  │                                         │
│                            │  │ ✅ Réponse générée                      │
│ 🤖 Agents actifs           │  │ Lignes: 3  Tentatives: 1  Durée: 4.2s  │
│ OrchestratorAgent ✗ ✗      │  │                                         │
│ SchemaAgent       ✗ ✓      │  │ 💬 "3 products are below threshold"     │
│ SQLAgent          ✓ ✓      │  │ ┌─────────────┬──────────┐             │
│ ExecutorAgent     ✗ ✓      │  │ │ product_name│ quantity │             │
│ RendererAgent     ✓ ✗      │  │ └─────────────┴──────────┘             │
│                            │  │                                         │
│                            │  │ 🗄️ SQL généré (expandable)             │
│                            │  │ 🤖 Trace des agents (expandable)        │
│                            │  │ 📜 Historique                           │
└────────────────────────────┘  └─────────────────────────────────────────┘
```

---

## Étape 9 (optionnel) — Déploiement Docker complet

Pour lancer l'API dans Docker (rebuild requis pour inclure `mcp` et le nouveau code) :

```bash
docker compose build api
docker compose up -d
```

L'API sera accessible sur `http://localhost:8081` (port Docker mappé dans `docker-compose.yml`).

Vérifier les logs :

```bash
docker compose logs -f api
```

Pour que Streamlit pointe vers le container Docker, changer l'URL dans la sidebar :
```
http://localhost:8081
```

---

## Dépannage

### Qdrant — 0 vecteurs après ingestion

```bash
# Relancer l'ingestion
python3 ingest.py example.sql
```

### Ollama — modèle manquant

```bash
ollama list          # vérifier les modèles présents
ollama pull mistral  # télécharger le modèle manquant
```

### MariaDB — connexion refusée

```bash
docker compose up -d mariadb
docker compose ps mariadb   # vérifier healthy
```

### Port 8080 déjà utilisé

```bash
uvicorn api:app --reload --port 8082
```

### MCP — erreur subprocess

Le MCP utilise le transport stdio : chaque agent spawne un sous-processus Python.
S'assurer que `python3` est dans le `PATH` et que `mcp>=1.0.0` est installé :

```bash
python3 -c "import mcp; print(mcp.__version__)"
```

---

## Récapitulatif des commandes

```bash
# 1. Infrastructure
docker compose up -d mariadb qdrant

# 2. Modèles LLM
ollama pull codestral && ollama pull mistral

# 3. Dépendances Python
pip install -r requirements.txt

# 4. Ingestion du schéma
python3 ingest.py example.sql

# 5. Démarrage API  (terminal 1)
uvicorn api:app --reload --port 8080

# 6. Interface Streamlit  (terminal 2)
streamlit run app.py

# 7. Test rapide v2 (optionnel, en plus de l'UI)
curl -X POST http://localhost:8080/v2/query \
  -H "Content-Type: application/json" \
  -d '{"question": "Which products are below the reorder threshold?"}'
```

---

## Architecture des composants au démarrage

```
┌─ Ollama (port 11434) ──────────────────────┐
│  codestral  → SQLAgent                     │
│  mistral    → RendererAgent                │
└────────────────────────────────────────────┘

┌─ Qdrant (port 6333) ───────────────────────┐
│  collection "schema" → SchemaAgent via MCP │
└────────────────────────────────────────────┘

┌─ MariaDB (port 3306) ──────────────────────┐
│  example_db → ExecutorAgent via MCP        │
│             → SQLAgent (EXPLAIN) via MCP   │
└────────────────────────────────────────────┘

┌─ API FastAPI (port 8080) ───────────────────┐
│  POST /query          → Pipeline v1         │
│  POST /v2/query       → Multi-agent v2      │
│  POST /tasks/send     → A2A v1              │
│  POST /v2/tasks/send  → A2A v2              │
│  GET  /health                               │
│  GET  /.well-known/agent.json               │
└─────────────────────────────────────────────┘

┌─ Streamlit UI (port 8501) ─────────────────┐
│  app.py                                    │
│  → appelle l'API FastAPI via HTTP          │
│  → affiche réponse + SQL + trace agents    │
│  → historique de session                   │
└────────────────────────────────────────────┘
```
