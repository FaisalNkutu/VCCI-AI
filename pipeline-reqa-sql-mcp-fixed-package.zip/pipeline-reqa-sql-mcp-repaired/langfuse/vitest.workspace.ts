export default ["web", "worker"];
