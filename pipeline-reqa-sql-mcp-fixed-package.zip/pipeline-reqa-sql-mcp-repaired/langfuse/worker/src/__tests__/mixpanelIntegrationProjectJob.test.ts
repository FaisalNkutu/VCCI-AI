import { describe, it, expect, beforeEach, vi } from "vitest";

/**
 * Regression tests for the Mixpanel analytics export throttling fix (issue #12786).
 *
 * The original implementation built one MixpanelClient per stream and ran all
 * streams concurrently via Promise.all, producing an unbounded export burst that
 * overwhelmed the target. This mirrors the PostHog fix in PR #13773 for Mixpanel:
 *   1. a single reused client per job,
 *   2. sequential stream execution (max concurrency 1), and
 *   3. a configurable inter-flush delay (LANGFUSE_MIXPANEL_FLUSH_DELAY_MS).
 *
 * NOTE: unlike the posthog-node SDK, the custom MixpanelClient has no background
 * flush timer, so no shutdown()/timer-cleanup is required here.
 */

// vi.mock factories are hoisted above module scope, so all shared mutable state
// the factories touch must live inside vi.hoisted().
const h = vi.hoisted(() => {
  const timeline: string[] = [];
  const constructed: unknown[] = [];
  const state = { activeStreams: 0, maxConcurrentStreams: 0 };

  // A fake async stream that records start/end on the shared timeline and yields
  // with a yield point in between, so concurrent (Promise.all) execution would
  // interleave and trip the max-concurrency assertion.
  function fakeStream(label: string) {
    return (async function* () {
      state.activeStreams++;
      state.maxConcurrentStreams = Math.max(
        state.maxConcurrentStreams,
        state.activeStreams,
      );
      timeline.push(`${label}:start`);
      await Promise.resolve();
      yield { langfuse_id: `${label}-1` };
      await Promise.resolve();
      yield { langfuse_id: `${label}-2` };
      timeline.push(`${label}:end`);
      state.activeStreams--;
    })();
  }

  const mixpanelIntegrationUpdate = vi.fn();

  const flushError: { value: Error | undefined } = { value: undefined };

  const defaultIntegration = () => ({
    projectId: "project-1",
    enabled: true,
    exportSource: "TRACES_OBSERVATIONS_EVENTS",
    mixpanelRegion: "api",
    encryptedMixpanelProjectToken: "enc",
    lastSyncAt: new Date("2024-01-01"),
    project: { name: "Test Project" },
  });

  // Mutable row returned by the prisma findFirst mock so individual tests can
  // vary exportSource.
  const db = { integration: defaultIntegration() as Record<string, unknown> };

  return {
    timeline,
    constructed,
    state,
    fakeStream,
    mixpanelIntegrationUpdate,
    defaultIntegration,
    db,
    flushError,
  };
});

vi.mock("../features/mixpanel/mixpanelClient", () => ({
  MixpanelClient: class {
    addEvent = vi.fn();
    flush = vi.fn().mockImplementation(async () => {
      if (h.flushError.value) {
        const err = h.flushError.value;
        h.flushError.value = undefined; // reject once, then behave
        throw err;
      }
      h.timeline.push("flush");
    });
    getBatchSize = vi.fn().mockReturnValue(0);
    getSerializedBytes = vi.fn().mockReturnValue(0);
    constructor() {
      h.constructed.push(this);
    }
  },
}));

vi.mock("../features/mixpanel/transformers", () => ({
  transformTraceForMixpanel: vi.fn((e) => e),
  transformGenerationForMixpanel: vi.fn((e) => e),
  transformScoreForMixpanel: vi.fn((e) => e),
  transformEventForMixpanel: vi.fn((e) => e),
}));

vi.mock("@langfuse/shared/encryption", () => ({
  decrypt: vi.fn(() => "decrypted-token"),
}));

// Keep the throttle delay out of the unit test (real value defaults to 500ms).
// Resolves to worker/src/env (read by exportWriteModeGuard and the score
// routing); the helpers mirror the real implementations.
vi.mock("../env", () => ({
  env: {
    LANGFUSE_MIXPANEL_FLUSH_DELAY_MS: 0,
    LANGFUSE_MIGRATION_V4_WRITE_MODE: "dual",
  },
  v4WritesToLegacyTables: (e: { LANGFUSE_MIGRATION_V4_WRITE_MODE: string }) =>
    e.LANGFUSE_MIGRATION_V4_WRITE_MODE !== "events_only",
  v4WritesToEventsTable: (e: { LANGFUSE_MIGRATION_V4_WRITE_MODE: string }) =>
    e.LANGFUSE_MIGRATION_V4_WRITE_MODE !== "legacy",
}));

vi.mock("@langfuse/shared/src/db", () => ({
  prisma: {
    mixpanelIntegration: {
      findFirst: vi.fn(async () => h.db.integration),
      update: h.mixpanelIntegrationUpdate,
    },
  },
}));

vi.mock("@langfuse/shared/src/server", () => ({
  QueueName: { MixpanelIntegrationProcessingQueue: "mixpanel" },
  logger: { info: vi.fn(), warn: vi.fn(), error: vi.fn(), debug: vi.fn() },
  recordIncrement: vi.fn(),
  getCurrentSpan: vi.fn(() => undefined),
  getTracesForAnalyticsIntegrations: vi.fn(() => h.fakeStream("traces")),
  getGenerationsForAnalyticsIntegrations: vi.fn(() =>
    h.fakeStream("generations"),
  ),
  getScoresForAnalyticsIntegrations: vi.fn(() => h.fakeStream("scores")),
  getEventsForAnalyticsIntegrations: vi.fn(() => h.fakeStream("events")),
}));

// Import after mocks are registered.
import {
  handleMixpanelIntegrationProjectJob,
  MIXPANEL_INTEGRATION_CUSTOMER_FAULT_METRIC,
} from "../features/mixpanel/handleMixpanelIntegrationProjectJob";
import {
  getScoresForAnalyticsIntegrations,
  recordIncrement,
} from "@langfuse/shared/src/server";
import { env } from "../env";

// Mirrors the real queue's defaultJobOptions (mixpanelIntegrationProcessingQueue.ts).
function makeJob(attemptsMade = 0) {
  return {
    data: { id: "job-1", payload: { projectId: "project-1" } },
    attemptsMade,
    opts: { attempts: 5 },
  } as unknown as Parameters<typeof handleMixpanelIntegrationProjectJob>[0];
}

function makeJobWithoutOpts() {
  return {
    data: { id: "job-1", payload: { projectId: "project-1" } },
    attemptsMade: 0,
  } as unknown as Parameters<typeof handleMixpanelIntegrationProjectJob>[0];
}

describe("handleMixpanelIntegrationProjectJob throttling (issue #12786)", () => {
  beforeEach(() => {
    h.timeline.length = 0;
    h.constructed.length = 0;
    h.state.activeStreams = 0;
    h.state.maxConcurrentStreams = 0;
    h.mixpanelIntegrationUpdate.mockClear();
    h.db.integration = h.defaultIntegration();
    // dual: the only mode where TRACES_OBSERVATIONS_EVENTS passes the guard
    (env as any).LANGFUSE_MIGRATION_V4_WRITE_MODE = "dual";
  });

  it("reuses a single MixpanelClient for the whole job", async () => {
    await handleMixpanelIntegrationProjectJob(makeJob());
    expect(h.constructed.length).toBe(1);
  });

  it("runs export streams sequentially (no concurrent streams)", async () => {
    await handleMixpanelIntegrationProjectJob(makeJob());
    // Each stream must fully finish before the next starts.
    expect(h.state.maxConcurrentStreams).toBe(1);
    // Timeline never has two starts without an intervening end.
    let open = 0;
    for (const entry of h.timeline) {
      if (entry.endsWith(":start")) open++;
      if (entry.endsWith(":end")) open--;
      expect(open).toBeLessThanOrEqual(1);
    }
  });
});

// LFE-10148: a persisted legacy export source on an events_only deployment
// reads the v3 traces/observations tables, which are no longer written — the
// job must fail loudly before exporting empty data and advancing lastSyncAt.
describe("handleMixpanelIntegrationProjectJob events_only legacy guard (LFE-10148)", () => {
  beforeEach(() => {
    h.timeline.length = 0;
    h.mixpanelIntegrationUpdate.mockClear();
    h.db.integration = h.defaultIntegration();
    (env as any).LANGFUSE_MIGRATION_V4_WRITE_MODE = "dual";
  });

  it("throws before export and does not advance lastSyncAt on events_only + legacy source", async () => {
    (env as any).LANGFUSE_MIGRATION_V4_WRITE_MODE = "events_only";
    h.db.integration = {
      ...h.defaultIntegration(),
      exportSource: "TRACES_OBSERVATIONS",
    };

    await expect(
      handleMixpanelIntegrationProjectJob(makeJob()),
    ).rejects.toThrow(/events_only/);

    // No stream was started (guard fires before the scores export too) and
    // sync state did not advance.
    expect(h.timeline).toHaveLength(0);
    expect(h.mixpanelIntegrationUpdate).not.toHaveBeenCalled();
  });

  it("exports an EVENTS source normally on events_only, routing score enrichment to events", async () => {
    (env as any).LANGFUSE_MIGRATION_V4_WRITE_MODE = "events_only";
    h.db.integration = {
      ...h.defaultIntegration(),
      exportSource: "EVENTS",
    };

    await handleMixpanelIntegrationProjectJob(makeJob());

    expect(h.mixpanelIntegrationUpdate).toHaveBeenCalledTimes(1);
    expect(vi.mocked(getScoresForAnalyticsIntegrations)).toHaveBeenCalledWith(
      "project-1",
      "Test Project",
      expect.any(Date),
      expect.any(Date),
      expect.objectContaining({ traceAttributesSource: "events" }),
    );
  });

  it("enriches scores from traces on dual write mode", async () => {
    await handleMixpanelIntegrationProjectJob(makeJob());

    expect(vi.mocked(getScoresForAnalyticsIntegrations)).toHaveBeenCalledWith(
      "project-1",
      "Test Project",
      expect.any(Date),
      expect.any(Date),
      expect.objectContaining({ traceAttributesSource: "traces" }),
    );
  });
});

// LFE-11009: enriched sources on legacy write mode must fail loudly instead
// of silently exporting empty data while lastSyncAt advances.
describe("handleMixpanelIntegrationProjectJob legacy-mode enriched guard (LFE-11009)", () => {
  beforeEach(() => {
    h.timeline.length = 0;
    h.mixpanelIntegrationUpdate.mockClear();
    h.db.integration = h.defaultIntegration();
    (env as any).LANGFUSE_MIGRATION_V4_WRITE_MODE = "legacy";
  });

  it.each(["EVENTS", "TRACES_OBSERVATIONS_EVENTS"])(
    "throws before export and does not advance lastSyncAt on legacy + %s source",
    async (exportSource) => {
      h.db.integration = { ...h.defaultIntegration(), exportSource };

      await expect(
        handleMixpanelIntegrationProjectJob(makeJob()),
      ).rejects.toThrow(/does not write them/);

      expect(h.timeline).toHaveLength(0);
      expect(h.mixpanelIntegrationUpdate).not.toHaveBeenCalled();
    },
  );

  it("exports a TRACES_OBSERVATIONS source normally on legacy write mode", async () => {
    h.db.integration = {
      ...h.defaultIntegration(),
      exportSource: "TRACES_OBSERVATIONS",
    };

    await handleMixpanelIntegrationProjectJob(makeJob());

    expect(h.mixpanelIntegrationUpdate).toHaveBeenCalledTimes(1);
  });
});

describe("handleMixpanelIntegrationProjectJob customer-fault observation (no disable)", () => {
  beforeEach(() => {
    h.timeline.length = 0;
    h.mixpanelIntegrationUpdate.mockClear();
    h.db.integration = h.defaultIntegration();
    h.flushError.value = undefined;
    (env as any).LANGFUSE_MIGRATION_V4_WRITE_MODE = "dual";
  });

  it("still throws a 401-shaped error and never calls update to disable the integration", async () => {
    const unauthorized = new Error("Mixpanel API error: 401 Unauthorized");
    Object.assign(unauthorized, { statusCode: 401 });
    h.flushError.value = unauthorized;

    await expect(handleMixpanelIntegrationProjectJob(makeJob())).rejects.toBe(
      unauthorized,
    );

    expect(h.mixpanelIntegrationUpdate).not.toHaveBeenCalled();
  });

  it("a job with no opts still does not disable on a classified-fault-shaped error", async () => {
    const unauthorized = new Error("Mixpanel API error: 401 Unauthorized");
    Object.assign(unauthorized, { statusCode: 401 });
    h.flushError.value = unauthorized;

    await expect(
      handleMixpanelIntegrationProjectJob(makeJobWithoutOpts()),
    ).rejects.toBe(unauthorized);

    expect(h.mixpanelIntegrationUpdate).not.toHaveBeenCalled();
  });
});

describe("handleMixpanelIntegrationProjectJob customer-fault observability", () => {
  beforeEach(() => {
    h.timeline.length = 0;
    h.mixpanelIntegrationUpdate.mockClear();
    h.db.integration = h.defaultIntegration();
    h.flushError.value = undefined;
    vi.mocked(recordIncrement).mockClear();
    (env as any).LANGFUSE_MIGRATION_V4_WRITE_MODE = "dual";
  });

  it("records the customer-fault metric with reason and attempt, then still rethrows", async () => {
    const unauthorized = new Error("Mixpanel API error: 401 Unauthorized");
    Object.assign(unauthorized, { statusCode: 401 });
    h.flushError.value = unauthorized;

    await expect(handleMixpanelIntegrationProjectJob(makeJob(2))).rejects.toBe(
      unauthorized,
    );

    expect(recordIncrement).toHaveBeenCalledWith(
      MIXPANEL_INTEGRATION_CUSTOMER_FAULT_METRIC,
      1,
      { reason: "credentials", attempt: 2 },
    );
  });

  it("does not record the customer-fault metric for an unclassified error", async () => {
    const infraError = new Error("connection reset");
    Object.assign(infraError, { code: "ECONNRESET" });
    h.flushError.value = infraError;

    await expect(handleMixpanelIntegrationProjectJob(makeJob())).rejects.toBe(
      infraError,
    );

    expect(recordIncrement).not.toHaveBeenCalled();
  });
});
