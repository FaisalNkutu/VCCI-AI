import { afterEach, beforeEach, describe, it, expect, vi } from "vitest";
import dns from "node:dns/promises";
import { validateWebhookURL } from "../../../packages/shared/src/server/webhooks/validation";

const nonexistentDomain = "this-domain-definitely-does-not-exist-12345.com";

const dnsError = (code: string, hostname: string) =>
  Object.assign(new Error(`queryA ${code} ${hostname}`), { code });

beforeEach(() => {
  vi.spyOn(dns, "resolve4").mockImplementation(async (hostname: string) => {
    if (hostname === nonexistentDomain) {
      throw dnsError("ENOTFOUND", hostname);
    }

    return ["93.184.216.34"];
  });
  vi.spyOn(dns, "resolve6").mockImplementation(async (hostname: string) => {
    throw dnsError("ENODATA", hostname);
  });
  vi.spyOn(dns, "lookup").mockImplementation(async (hostname: string) => {
    if (hostname === nonexistentDomain) {
      throw dnsError("ENOTFOUND", hostname);
    }

    return [{ address: "93.184.216.34", family: 4 }];
  });
});

afterEach(() => {
  vi.restoreAllMocks();
});

describe("Webhook URL Validation", () => {
  describe("validateWebhookURL", () => {
    it("should accept valid public HTTPS URLs", async () => {
      await expect(
        validateWebhookURL("https://httpbin.org/post"),
      ).resolves.not.toThrow();
    });

    it("should accept valid public HTTP URLs", async () => {
      await expect(
        validateWebhookURL("http://httpbin.org/post"),
      ).resolves.not.toThrow();
    });

    it("should reject invalid URL syntax", async () => {
      await expect(validateWebhookURL("not-a-url")).rejects.toThrow(
        "Invalid URL syntax",
      );
    });

    it("should reject non-HTTP/HTTPS protocols", async () => {
      await expect(validateWebhookURL("ftp://example.com")).rejects.toThrow(
        "Only HTTP and HTTPS protocols are allowed",
      );
      await expect(validateWebhookURL("file:///etc/passwd")).rejects.toThrow(
        "Only HTTP and HTTPS protocols are allowed",
      );
    });

    it("should reject disallowed ports", async () => {
      await expect(
        validateWebhookURL("https://example.com:8080/hook"),
      ).rejects.toThrow("Only ports 80 and 443 are allowed");
      await expect(
        validateWebhookURL("http://example.com:3000/hook"),
      ).rejects.toThrow("Only ports 80 and 443 are allowed");
    });

    // Protocol and port rejections must carry an OutboundUrlValidationError
    // code, not just a message: callers classify deterministic config faults
    // off the code, so an uncoded rejection is silently unclassifiable and
    // retries forever instead of disabling the integration.
    it.each([
      ["ftp://example.com", "protocol-not-allowed"],
      ["file:///etc/passwd", "protocol-not-allowed"],
      ["https://example.com:8080/hook", "port-not-allowed"],
      ["http://example.com:3000/hook", "port-not-allowed"],
    ])("should reject %s with a coded error", async (url, code) => {
      await expect(validateWebhookURL(url)).rejects.toMatchObject({
        name: "OutboundUrlValidationError",
        code,
      });
    });

    it("should allow standard ports", async () => {
      await expect(
        validateWebhookURL("https://httpbin.org:443/post"),
      ).resolves.not.toThrow();
      await expect(
        validateWebhookURL("http://httpbin.org:80/post"),
      ).resolves.not.toThrow();
    });

    it("should reject localhost URLs", async () => {
      await expect(validateWebhookURL("http://localhost/hook")).rejects.toThrow(
        "Blocked hostname detected",
      );
      await expect(
        validateWebhookURL("http://test.localhost/hook"),
      ).rejects.toThrow("Blocked hostname detected");
      // Generic error message without IP address
      await expect(
        validateWebhookURL("https://127.0.0.1/hook"),
      ).rejects.toThrow("Blocked IP address detected");
      await expect(validateWebhookURL("http://[::1]/hook")).rejects.toThrow(
        /Blocked IP address detected|ipaddr:/,
      );
    });

    it("should reject private network URLs", async () => {
      // Generic error messages without exposing IP addresses
      await expect(
        validateWebhookURL("http://192.168.1.1/hook"),
      ).rejects.toThrow("Blocked IP address detected");
      await expect(validateWebhookURL("http://10.0.0.1/hook")).rejects.toThrow(
        "Blocked IP address detected",
      );
      await expect(
        validateWebhookURL("http://172.16.0.1/hook"),
      ).rejects.toThrow("Blocked IP address detected");
    });

    it("should reject link-local addresses", async () => {
      await expect(
        validateWebhookURL("http://169.254.169.254/hook"),
      ).rejects.toThrow("Blocked hostname detected");
    });

    it("should reject multicast addresses", async () => {
      // Generic error message without exposing IP address
      await expect(validateWebhookURL("http://224.0.0.1/hook")).rejects.toThrow(
        "Blocked IP address detected",
      );
    });

    it("should reject broadcast addresses", async () => {
      // Generic error message without exposing IP address
      await expect(
        validateWebhookURL("http://255.255.255.255/hook"),
      ).rejects.toThrow("Blocked IP address detected");
    });

    it("should reject IPv6 private addresses", async () => {
      // Generic error messages without exposing IP addresses
      await expect(validateWebhookURL("http://[fc00::1]/hook")).rejects.toThrow(
        /Blocked IP address detected|ipaddr:/,
      );
      await expect(validateWebhookURL("http://[fe80::1]/hook")).rejects.toThrow(
        /Blocked IP address detected|ipaddr:/,
      );
    });

    it("should handle DNS resolution failures gracefully", async () => {
      await expect(
        validateWebhookURL(`https://${nonexistentDomain}/hook`),
      ).rejects.toThrow("DNS lookup failed");
      expect(dns.resolve4).toHaveBeenCalledWith(nonexistentDomain);
      expect(dns.resolve6).toHaveBeenCalledWith(nonexistentDomain);
      expect(dns.lookup).toHaveBeenCalledWith(nonexistentDomain, {
        all: true,
      });
    });

    it("should reject URL-encoded localhost bypass attempts", async () => {
      // %6C%6F%63%61%6C%68%6F%73%74 decodes to "localhost" but fails on port check first
      await expect(
        validateWebhookURL("http://%6C%6F%63%61%6C%68%6F%73%74/hook"),
      ).rejects.toThrow("Blocked hostname detected");
    });

    it("should reject encoded delimiter userinfo SSRF bypass attempts", async () => {
      // Percent-encoded delimiters are data to the WHATWG URL parser before
      // parsing, but become syntax if the whole URL is decoded first.
      // Validation must parse the same URL string that fetch will execute.
      const encodedDelimiters = ["%2F", "%23", "%3F", "%5C"];

      for (const delimiter of encodedDelimiters) {
        await expect(
          validateWebhookURL(`http://example.com${delimiter}@127.0.0.1/hook`),
        ).rejects.toThrow(
          "URL credentials are not allowed. Use authentication headers instead.",
        );
      }
    });

    it("should reject URLs with embedded credentials", async () => {
      await expect(
        validateWebhookURL("https://user:pass@example.com/hook"),
      ).rejects.toThrow(
        "URL credentials are not allowed. Use authentication headers instead.",
      );
    });

    it("should validate IDN hostnames using their punycoded hostname", async () => {
      await expect(
        validateWebhookURL("http://тест.example.com/hook"),
      ).resolves.not.toThrow();

      expect(dns.resolve4).toHaveBeenCalledWith("xn--e1aybc.example.com");
      expect(dns.resolve6).toHaveBeenCalledWith("xn--e1aybc.example.com");
      expect(dns.lookup).toHaveBeenCalledWith("xn--e1aybc.example.com", {
        all: true,
      });
    });

    it("should reject internal/intranet hostnames", async () => {
      // Note: "internal.company.com" would require DNS resolution which can timeout
      // Using domains that match blocked patterns directly for faster tests
      await expect(
        validateWebhookURL("http://service.internal/hook"),
      ).rejects.toThrow("Blocked hostname detected");
      await expect(
        validateWebhookURL("http://app.internal/hook"),
      ).rejects.toThrow("Blocked hostname detected");
      await expect(validateWebhookURL("http://intranet/hook")).rejects.toThrow(
        "Blocked hostname detected",
      );
    });

    it("should reject docker internal hostnames", async () => {
      await expect(
        validateWebhookURL("http://host.docker.internal/hook"),
      ).rejects.toThrow("Blocked hostname detected");
      await expect(
        validateWebhookURL("http://gateway.docker.internal/hook"),
      ).rejects.toThrow("Blocked hostname detected");
    });

    it("should reject cloud metadata endpoints", async () => {
      await expect(
        validateWebhookURL("http://metadata.google.internal/hook"),
      ).rejects.toThrow("Blocked hostname detected");
      await expect(
        validateWebhookURL("http://[fd00:ec2::254]/hook"),
      ).rejects.toThrow(
        /Blocked hostname detected|Blocked IP address detected/,
      );
    });

    it("should handle malformed URL encoding", async () => {
      await expect(
        validateWebhookURL("http://exam%ple.com/hook"),
      ).rejects.toThrow(/Invalid URL encoding|Invalid URL syntax/);
    });

    it("should allow local hostname, if it is included in the whitelist", async () => {
      await expect(
        validateWebhookURL("http://internal.company.com/hook", {
          hosts: ["internal.company.com"],
          ips: [],
          ip_ranges: [],
        }),
      ).resolves.not.toThrow();
      await expect(
        validateWebhookURL("http://app.internal/hook", {
          hosts: ["app.internal"],
          ips: [],
          ip_ranges: [],
        }),
      ).resolves.not.toThrow();
      await expect(
        validateWebhookURL("http://intranet/hook", {
          hosts: ["intranet"],
          ips: [],
          ip_ranges: [],
        }),
      ).resolves.not.toThrow();
    });
  });
});
