# graph_lab

A question in plain language becomes one MariaDB `SELECT`, and the query is
judged before it is allowed to run. The judging is the point. A generator
alone gives you SQL that looks right; here the joins are imposed from the
schema graph, then audited, then explained, then executed inside a
transaction that is rolled back. Nothing in this package writes.

```
question
  1  clarify        ambiguity resolved with the user, not guessed
  2  anchors        which tables the question is really about
  3  sub-schema     the joins imposed by the graph, not invented
  4  generate       the SQL model writes, knowing only that sub-schema
  5  dialect lint   SQLite habits MariaDB would run silently wrong
  6  join audit     every pair must be an edge; fan and chasm rules
  7  EXPLAIN        cartesian products, before touching data
  8  execute        read-only, in a transaction that is rolled back
  9  answer         the reasoner turns rows back into a sentence
answer
```

Steps 5 to 7 reject rather than warn, and their verdict is handed back to the
SQL model as the next attempt's instruction. That loop is why the generator
never has to be trusted: it only has to be checkable.

## Install the library

Build and verify the wheel from the repository root:

```powershell
.venv\Scripts\python.exe scripts\build_graph_lab_wheel.py
python -m pip install "dist\datagora_graph_lab-1.2.0-py3-none-any.whl[qdrant]"
```

`[qdrant]` adds the Qdrant client, for the corpus of answered questions and
the column index; without it the library works with no corpus.
`examples/try_one_question.py` builds the client both ways, with the fewest
parameters and with every service.

The complete installation, coverage API and integration contracts are in
[INTEGRATION.md](INTEGRATION.md).

## The shortest useful thing

```python
from graph_lab import Datagora

dg = Datagora(mysql=dict(host="db.internal", port=3306, database="sales",
                         user="readonly", password=os.environ["DB_PASSWORD"]))

out = dg.ask("how many orders per city last month")
if out.waiting:                                  # the question was ambiguous
    out = dg.ask(out.question, choice=out.options[0].label)
print(out.answer, out.sql, out.rows)
```

Credentials are passed in and never read from a file, so an application that
already has a secret manager keeps using it. The full surface, the LangGraph
wiring and the credential handling are in [INTEGRATION.md](INTEGRATION.md).

## Questions the asker can pick

A question that needs a choice, or more detail, stops before any SQL is
written. Its readings are recorded the way the database records them
("employees with status_code = 'ACTIVE'"), which nobody outside the data team
can choose between. So the stop also comes back with whole questions in the
asker's own words, to put to them instead:

- **NEEDS A CHOICE**: one question per reading, each carrying the option it
  settles. Picked, it is answered as it is, without a second clarification.
- **NEEDS MORE**: two to four questions that supply what is missing with
  values taken from the data (a column's range and quartiles for "cheap", the
  latest date it holds and today for "recently"), or one with a `[blank]` when
  nothing concrete can be found. Picked, it is asked as a new question.
- **NOT COVERED** and **NO DATA** get none: their verdict is the answer.

One short model call writes them, without thinking. A question that names a
column, shows a code or SQL, or brings a number nobody gave, is replaced by a
template built from the reading, and without a model the templates alone come
back; it never raises.

**The switch.** `reformulate=True` or `False` forces it; `None`, the default,
reads `DATAGORA_REFORMULATE` (`on` or `off`, on when unset) at each question.
The UI's settings page writes the same variable (Engine, "Suggest questions to
pick"). Off, no suggestion is computed and no model call is made for it.

With the client (`reasoner=` takes a configured endpoint's name or an `LLM`
object; the suggestions are written by the reasoner):

```python
dg = Datagora(mysql=..., reformulate=True)       # or None: the environment

out = dg.ask("How many active employees work in each department?")
out.clarifying    # 'By "active employees", which do you mean?'
out.suggestions   # [Suggestion(question='How many employees with an active
                  #   status work in each department?',
                  #   choice='employees.status_code', note=...), ...]
s = out.suggestions[0]
out = dg.ask(out.question, choice=s.choice, suggestion=s.question)

out = dg.ask("Which products are cheap?")
out.suggestions   # [Suggestion(question='Which products cost less than 10?',
                  #   choice=None, note='In the data, the price goes from
                  #   1.2 to 2300.'), ...]
out = dg.ask(out.suggestions[0].question)        # a new question

dg.reformulate = False                           # from the next ask on
```

With the switch off, `Answer.suggestions` is empty and `clarifying` is "": the
answer carries the clarifier's readings in `options` and its question in
`clarification`, exactly as before, and no model call is made for it.

With the functional API, stateless like the other steps:

```python
from graph_lab.api import is_ambiguous, suggest_questions

a = is_ambiguous("Which products are cheap?", db="sales", reformulate=True)
a.suggestions                                    # filled for a choice or more

a = is_ambiguous("Which products are cheap?", db="sales")
suggest_questions("Which products are cheap?", a, db="sales")
```

## Who decides whether a question is clear

Before any SQL is written, a judge decides whether the question can be
answered as asked, needs a choice, needs more, or asks for something the
database does not hold. Two judges are available:

- `single`, the default: one model call, then checks against the live
  schema. Seconds per question.
- `agent`: a judge that explores the database with bounded, read-only
  tools (tables, values, joins, dates, counts) and whose conclusion is
  checked fact by fact before it becomes a verdict. Better on hard
  questions, and slower: about a minute or more per question. On Ask it
  runs with fewer turns than in a coverage run (5), a shorter limit (180 s)
  and thinking only to plan and conclude.

```python
dg = Datagora(mysql=...)                         # the agent, or DATAGORA_ASK_JUDGE
a = dg.ask("How many active employees work in each department?")
dg.judge = "single"                              # the one call, from the next ask on
```

The agent's verdict is kept for the question, so picking one of its
options answers with the options the asker saw, without exploring again.
The variables `DATAGORA_ASK_AGENT_MAX_TURNS`, `DATAGORA_ASK_AGENT_MAX_SECONDS`
and `DATAGORA_ASK_AGENT_THINK` (all, plan_conclude, none) move its limits;
on the web page, the Engine settings have an "Ask judge" choice. A coverage
run chooses its own judge (`judge_mode`, `DATAGORA_JUDGE`).

The agent reasons in steps it can act on: each turn it lists what it does
not know yet and how it will find it out (the data, a computation, the
clock, or last the asker). Two of its tools serve that: `compute` works out
one safe expression on numbers and dates (`add_months(today(), -3)`,
`days_between(a, b)`; no import, no loop, bounded, see [`calc.py`](calc.py)),
and `clock` gives the asker's date, the database's clock and time zone and
how far a table's dates reach.

## Who asks, and when

A model does not know today's date: asked "What was our revenue last
year?", it cannot tell which year that is. Every question therefore goes to
the models (both judges, the SQL generator, the suggestions) with what is
known of the asker, as a chat assistant does: the date and the time of the
question, the UTC offset and timezone, the language and the system, read
from the machine at each question, plus any static facts you add.

```python
dg = Datagora(mysql=..., context={"location": "Montreal, Canada", "currency": "CAD"})
a = dg.ask("What was our revenue last year?")            # 2025, asked in 2026

# a server answering several people: each one's own day and timezone
a = dg.ask("Which orders are due this week?",
           context={"date": "2026-10-23", "time": "09:15", "timezone": "Europe/Paris"})
dg.context = False                                       # no context at all
```

`context` is a dict of facts laid over the machine's (a key you give
replaces the machine's), a callable returning one, or `False`. Static facts
for every question can also come from `DATAGORA_CONTEXT`, as JSON or as the
path of a JSON file. The web page sends the browser's own date, time,
timezone and language with each question. Only short plain values are kept,
and nothing names the machine or the user.

## A follow-up knows what was decided

When a question stopped for the asker and they pick one of the suggestions,
the question they picked is judged knowing what happened just before: the
question first asked, its verdict and what was open, what was offered, what
they picked, and the tables the judge found. What the asker settled stays
settled; the rest is judged from the facts, as any question. The note is a
few lines (900 characters at most).

```python
first = dg.ask("How many products did we sell recently?")   # needs more
second = dg.ask(first.suggestions[0].question)              # follows `first` by itself
other = dg.ask("Which suppliers are in Germany?")            # follows nothing

dg.ask(question, earlier=some_answer)                       # say which one it follows
dg.ask(question, earlier=False)                             # or that it follows none
```

A question picked from the last answer's suggestions, or answered with a
choice, follows that answer without being told; any other question starts
afresh.

## What you can reuse, piece by piece

Nothing here requires taking the whole thing. Each part runs on its own, and
several are useful against a pipeline you already have.

| Part | What it does alone | Needs |
|---|---|---|
| `assess_file` ([`coverage.py`](coverage.py)) | incrementally assesses and resumes a CSV of questions | a connection, a model |
| `Datagora` ([`__init__.py`](__init__.py)) | the whole journey behind one method | a connection |
| `Clarifier` ([`ambisql.py`](ambisql.py)) | spots an ambiguous question and writes the question to put to a human | a connection |
| `lint`, `repair_message`, `transpile` ([`dialect_lint.py`](dialect_lint.py)) | catches SQLite habits MariaDB accepts and runs differently | nothing |
| `audit_joins`, `audit_traps` ([`schema_graph.py`](schema_graph.py)) | judges joins in SQL you already have, and catches fan and chasm traps | the graph |
| `explain_check` ([`schema_graph.py`](schema_graph.py)) | cartesian products, before a row is read | a connection |
| `build_graph` ([`build_graph.py`](build_graph.py)) | reads `information_schema`, writes the join graph | a connection, Neo4j |
| `LLM` ([`llm.py`](llm.py)) | one client for Ollama and for anything OpenAI-compatible | nothing |
| `Span`, `get_logger`, `prompt` ([`observability.py`](observability.py)) | one trace id shared by the logs and Langfuse, prompts read by label | nothing |
| `nodes_for` ([`langgraph_nodes.py`](langgraph_nodes.py)) | the same steps as LangGraph nodes, to drop into an existing graph | a connection |

The most reusable of these on its own is `Datagora.check_sql(sql)`. It judges a
query your current pipeline produced, without running it, and returns a list of
`(verdict, explanation)`. That is a way to measure what you have today before
changing any of it.

## Going to production: what to change

Everything below is configuration. None of it is a code change.

| What | Where | Today | In production |
|---|---|---|---|
| The two models | the roles on the Settings page, or `roles` in the file `DATAGORA_MODELS` names | `local-small` twice, gemma3:4b | `reasoner` on a large Gemma, `sql` on Arctic |
| Where they live | the endpoints on the Settings page, `DATAGORA_ENDPOINTS` in `.env`, or `endpoints` in that file | localhost Ollama | the server or JARVIS, confirmed with `--probe` |
| Database credentials | passed to `Datagora(mysql=...)` | the Settings page, or `DATAGORA_DATABASES` plus `.env`, for the lab | your secret manager, passed in |
| Database rights | the MySQL user | root, in the sandbox | a user with `SELECT` and nothing else |
| The graph | Neo4j, namespaced by `name` | the demo databases | `dg.build_graph()` once per schema, re-run after a migration |
| Tracing | `LANGFUSE_PUBLIC_KEY`, `LANGFUSE_SECRET_KEY`, `LANGFUSE_BASE_URL` | local Langfuse on 3001 | your instance, or `DATAGORA_TRACING=off` |
| Prompt versions | Langfuse, label from `DATAGORA_PROMPT_LABEL` | `production` | the label you promote to, prompts registered once |
| Logs | `DATAGORA_LOG_LEVEL` | `INFO` | `INFO`, or `DEBUG` while you audit |
| Row ceiling | `MAX_ROWS` in [pipeline.py](pipeline.py) | 50 | as high as your UI can display honestly |
| Attempts | `MAX_ATTEMPTS` in [pipeline.py](pipeline.py) | 3 | 3 is the measured plateau; more spends time, not accuracy |

### Moving the models

Pick the roles on the Settings page, or edit `roles` in the file
`DATAGORA_MODELS` points at, nothing else:

```json
"roles": { "reasoner": "local-small", "sql": "local-sql-specialist" }
```

No other file in the project names a model, and the package ships none:
a deployment says its endpoints on the Settings page, in `.env`
(`DATAGORA_ENDPOINTS`), or in a file `DATAGORA_MODELS` points at, of
which [deploy/config/models.json](../../deploy/config/models.json) is the
example to copy. Its databases the same way, with
[deploy/config/profiles.json](../../deploy/config/profiles.json) as the
example.

Confirm the served name before trusting it, because a name the host does
not serve returns a 404 that reads exactly like a network failure:

```bash
python llm.py --probe http://your-server:11434   # what it really serves
python llm.py --probe http://your-server:8000 --save-as house-sql
python llm.py --set sql=house-sql
python llm.py                      # each role, and whether it answers
```

`url` is a base and nothing more: the code appends `/api/chat` for an
`ollama` endpoint and `/v1/chat/completions` for an `openai` one, so
getting `api` wrong reports a healthy server as unreachable.

Two variables that do not do what their names suggest. `DATAGORA_LLM_URL`
and `DATAGORA_LLM_MODEL` describe a model entirely, with no file read at
all. `DATAGORA_LLM_ENDPOINT` instead names an entry of the file, has no
effect on either role, and setting it cancels the other two. Measured on
this build; prefer `DATAGORA_LLM_REASONER` and `DATAGORA_LLM_SQL` to move
a role from the environment.

### Why the two roles are not the same model

`reasoner` talks to the user: it spots ambiguity, writes the question a human
reads, and turns result rows back into a sentence. It needs general language
ability. `sql` writes the query and nothing else. Arctic-Text2SQL-R1 was
reinforcement-trained on a single reward, whether the SQL executes to the right
result, which makes it the specialist for step 4 and a poor choice for anything
above it.

### Neo4j is optional

Without it the engine still clarifies, generates, lints the dialect, runs
`EXPLAIN` and executes read-only, and every run says plainly that joins were
not verified. With it, the joins are imposed and audited. Adopt the first, add
the second when you want the guarantee. [INTEGRATION.md](INTEGRATION.md) has
the table of what exactly changes.

## Does it work on a schema it has never seen

That question is answered by tests, not by assertion. `datagora_lib` is a
library schema with no table name in common with the demo, built as a
structural twin: the same traps in different clothes.

```bash
python test_portability.py     # the checks, on a schema they were not written for
python test_reusable.py        # queries generated from each schema, end to end
python audit.py                # the installation itself
```

Test questions per database and per ambiguity level, with the behaviour
actually observed for each, are in [TEST_QUESTIONS.md](TEST_QUESTIONS.md).

## Can it answer *their* questions

Before adopting anything, a team asks whether it covers what they ask.
Hand `coverage.py` a CSV of their questions and a connection and it
answers that, one line each, with no SQL generated and nothing executed.

```bash
python coverage.py --profile Warehouse \
  --questions examples/questions_products.csv --out verdicts.csv
```

The output is flushed after every question. If a 500-question run is
interrupted, run the same command again: completed rows are kept and only
unfinished or `UNKNOWN` rows are retried. The command exits non-zero while
any row is still `UNKNOWN`; use `--stop-on-error` to stop at the first one,
or `--restart` to deliberately replace an existing run. Omitting `--out`
names the file after the questions rather than keeping the run in memory,
because an hour of verdicts that exist only in a terminal has to be
redone.

**A run is identified by its questions, not by the name of its output.**
Each question file has a job id, printed at the start and recorded in a
`.job.json` beside the verdicts, so resuming means pointing at the same
question file again. Two different question lists sent to the same
`--out` do not collide: the second is written as `verdicts.<job>.csv`
beside the first, which is left untouched. Editing the question file
gives a new job, and the verdicts already decided for the questions you
did not touch are carried into it, so adding one question to a list of
five hundred costs one model call rather than five hundred.

Or from the page: there is a button beside the ask button, at
http://localhost:8080/coverage, which takes a dropped file or a pasted
list and streams the verdicts as they are decided. The page saves every
verdict in browser storage, shows the count and percentage, and resumes at
the first unfinished row after a disconnect or page reload. `UNKNOWN` rows
are retried; **Start over** deliberately clears the saved browser run.

Six verdicts, and the split between the middle four is the point.
**ANSWERABLE** and **NEEDS A CHOICE** are covered today. **NEEDS MORE**
is a question missing something the asker has and the data does not, so
it names what to add. **NO DATA** can be asked, and no row matches today.
**NOT COVERED** is a gap in the data, where asking again wastes an
afternoon. **UNKNOWN** is kept apart, because the model failing to answer
is not the database failing to hold something.

Three ready-made lists are in [examples/](examples/), for the Library,
Warehouse and Enterprise databases. Each row carries its `real_verdict`
and the verdicts it also accepts (`also_accepted`), which the pages score
a run against; the measured gaps stay in `examples/README.md`.

## The no-LLM lab

`test_no_llm.py` validates, without any generative model, the quickly testable
claims of `docs/architecture/join_correctness_checklist.md`:

- T1 anchors from Qdrant neighbours alone (nomic-embed-text embeddings, corpus
  of 12 executed-certified question/SQL pairs, 5 held-out paraphrases): full
  table recall 5/5;
- T2 force-union of `allShortestPaths` over the Neo4j demo graph covers the
  expected sub-schema 5/5;
- T3 the static join audit passes valid SQL and rejects an invented edge and a
  wrong-key join;
- T4 fan and chasm traps are caught statically from edge cardinalities, with no
  execution: two fine branches converging, or an additive aggregate above the
  finest table;
- T5 `EXPLAIN` exposes a cartesian product before execution.

Prerequisites: the demo graph loaded in Neo4j, MariaDB sandbox seeded, Qdrant
and Ollama running. Run `python test_no_llm.py`.

## Known limits, stated rather than hidden

- The final sentence is only as good as the `reasoner`. On gemma3:4b, a
  fifty-row grouped result becomes "There are fifty entries", which is true and
  useless. The SQL, the joins and the table are correct in that same run. The
  page shows the table beside the sentence for exactly this reason.
- Aggregate granularity is read from the first column of the expression.
- Retrieval is recall-first by design, so precision is not the metric to judge
  step 2 on.
- A query can be rejected three times and the run fails. It says so. It does
  not answer anyway, which is the behaviour worth keeping.

## Versions

The version is declared in two places and a test refuses to let them
drift: `__version__` in [`__init__.py`](__init__.py) and `version` in the
repository's `pyproject.toml`, which is what names the wheel. The same
test checks that no document installs a wheel filename other than the
current one. Bump both together, and tag the commit with the same number
prefixed by `v`.

The rule used here: the **minor** number moves when the coverage contract
changes, meaning a question could come back with a different verdict than
it did before, or when a new configuration variable appears. The **patch**
number moves for a fix that cannot change a verdict. An integrator pinning
`==0.2.*` should never see a verdict move under them.

| Tag | What changed |
| --- | --- |
| `v0.1.0` | The pipeline and the coverage verdicts as first packaged: nine steps, the four outcomes, five verdicts, resumable batches, the assess-a-list page, the wheel and `INTEGRATION.md`. |
| `v0.2.0` | Deployment from the environment alone, `.json` reserved for the several-databases case. Job identity keyed on the whole input row, so a rerun resumes on the input file and versions when the output name is taken. An optional table and column dictionary. A value-decision step: when nothing is named for a phrase and nothing holds it, the engine reads a column's distinct values and asks the model about them. Saved runs on the server, with the output file and directory in the page. |
| `v1.0.0` | The core changed: coverage is judged by an agent that explores the database with bounded read-only tools, and code checks its facts (values, joins, results that really differ, periods and points in time) before a verdict. Ask can use the same judge, and reformulates a choice or a missing detail into questions a person picks from. Real verdicts and accuracy, the schema graph per question and precision in History on the Coverage pages. |
| `v1.2.0` | A stabilisation release: a systematic review of the whole product and a second review of its fixes, every finding fixed with a test, then the verdicts measured live again (Ask 23 of 29, Enterprise 14 of 16). Each person keeps their own state on Ask; counts are reliable; Qdrant and Neo4j reconnect after an outage; the corpus learns only verified answers. Rankings and age words are compared rather than refused, a state at a date needs a history of that value, the agent's prompt v7 and 1200 seconds per question. `Datagora()` takes Qdrant, the extra `[qdrant]`. |
| `v1.1.0` | Who asks and when goes to every model. A follow-up knows what was decided before it. A NEEDS MORE says who can fill it: an editable question with the data's values, or what the database would have to record. The agent's prompt v6 (unknowns, a safe calculator, a clock) and new checks on time, distances, what-if and history coverage. The Ask history in History, Follow live on Coverage, the judge's trace per question. Fixes from two independent reviews, among them an XSS in the Ask answer table and a false SQL rejection of YEAR(). |

### What to know before upgrading to 1.2.0

From 0.2.x, read this section and the two below it: 1.2.0 carries the
changes of 1.0.0 and 1.1.0 as well. CHANGELOG.md gathers them under
"Upgrading from 0.2.x".

- **Verdicts can change**: unsure is NEEDS MORE, never a silent answer; a
  ranking ("the busiest suppliers") or an age word ("the oldest members")
  is compared on its columns or its dates rather than refused; a state at a
  date needs a history that keeps that very value back to that date.
- **The coverage agent has 1200 seconds per question** by default
  (`agent_max_seconds`): on one GPU shared by several questions, 600 cut it
  short. Ask keeps its own 180 seconds.
- **Ask is judged by the agent by default**: 23 of 29 questions right
  against 19 for the single call (27 October), about two minutes a question
  against thirty seconds. `judge="single"`, `DATAGORA_ASK_JUDGE=single` or
  the `ask_judge` setting keeps the single call. On one GPU, several people
  asking at once share it, and the agent's 180 seconds can run out.
- **The corpus learns less and better**: only answers whose joins a graph
  verified, with the tables their SQL reads, and a question deleted from the
  history leaves it. `DATAGORA_REMEMBER=off` for a test instance.
- **For an application using the package**: `Datagora()` takes
  `qdrant_url`, `qdrant_collection`, `embed_url` and `embed_model`; install
  the extra `[qdrant]` to use them.

### What to know before upgrading to 1.1.0

- **Every question carries who asks and when.** The date, time, timezone
  and language of the question reach both judges, the SQL generator and
  the suggestions; the page sends the browser's own. `DATAGORA_CONTEXT`
  adds static facts, `Datagora(context=...)` and `ask(..., context=...)`
  set them, `False` turns them off.
- **A follow-up knows what was decided.** A question picked from the last
  answer's suggestions is judged with a short note on the question it
  follows (`Datagora.ask(earlier=...)`, `False` for none).
- **A NEEDS MORE says who can fill it** (`Outcome.gap`: "asker" or "data")
  and what is missing (`Outcome.missing`). Suggestions change shape: for a
  threshold the editable question comes first, then the data's values; for
  a gap in the records there is no blank, the sentence says what the
  database would have to record.
- **The agent's prompt is v6.** It lists what it does not know and has two
  more tools, `compute` (a safe calculator) and `clock`. Verdicts on time,
  distance and what-if questions can change.

### What to know before upgrading to 1.0.0

The major number moved because the core changed: a coverage run is judged
by an agent that explores the database, and a verdict can differ from the
one 0.2.x gave for the same question.

- **The coverage judge is the agent by default.** `DATAGORA_JUDGE=single`
  (or `judge_mode` in Settings, or `judge="single"`) keeps the 0.2.x judge.
  A run takes two to three times as long.
- **Ask keeps the single call by default.** `DATAGORA_ASK_JUDGE=agent`,
  `Pipeline(judge="agent")` or `Datagora(judge="agent")` judges Ask with the
  agent as well.
- **Reformulation** of NEEDS A CHOICE and NEEDS MORE answers into questions
  a person can pick from: `DATAGORA_REFORMULATE`, `Pipeline(reformulate=)`
  or `Datagora(reformulate=)`.
- **`DATAGORA_REMEMBER=off`** keeps an instance from writing its answered
  questions into the shared corpus; a test instance should set it.

### What to know before upgrading to 0.2.0

- **`DATAGORA_ASK_VALUES` defaults to `on`.** It adds one model call per
  question that would otherwise have guessed, and it can change a verdict
  from `NEEDS A CHOICE` to `ANSWERABLE` or to `NEEDS MORE`. It cannot
  produce `NOT COVERED`. Set it to `off` to get 0.1.0 behaviour exactly.
- **`DATAGORA_MYSQL_HOST` now rewrites only a loopback address.** A
  profile naming its own server is left as written. In 0.1.0 the variable
  redirected every profile, which sent a deployment at the wrong host and
  reported it as an unknown database.
- **The real environment now outranks a `.env` in the working copy.** It
  was the other way round, so a container given its password by a secret
  manager used a developer's instead.
- **An unset `NEO4J_URI` means there is no join graph.** Set it only when
  a graph is deployed. `off`, `none` and `disabled` remain accepted as
  explicit ways to clear a URI inherited from a profile.
