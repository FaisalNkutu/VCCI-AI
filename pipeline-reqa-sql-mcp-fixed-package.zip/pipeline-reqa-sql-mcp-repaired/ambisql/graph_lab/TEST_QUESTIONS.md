# Test questions, and what the system should do with each

Paste them into the interface at http://localhost:8080, or run them from
the command line:

```
python src/graph_lab/pipeline.py --profile datagora_lib --question "..."
```

Anything marked "observed" was **run**, not assumed, with `gemma3:4b` on
both roles. Where the observed behaviour differs from the expected one it
says so: those are the cases to revisit on the larger model.

A question followed by a `·` was re-run on the current build and reached
the outcome this document says it should: a clear question was answered,
an ambiguous one produced the choice, an unanswerable one produced the
explanation. 34 of the 42 questions that state an expected outcome do.
The eight that do not are named in their own rows, and the section at the
end says what the small model still gets wrong.

A question without a `·` is not broken. It is either in a group that
states no expected outcome, such as the multi-hop and trap tables, or it
is one of the eight.

---

## The four outcomes, and why each one exists

**ANSWER.** Nothing to settle, the question goes to the generator.
*Why:* asking a question when there is none to ask is the fastest way to
make a product unbearable.

**CLARIFY.** Several readings exist **and the database can honour all of
them**.
*Why:* this is the only case where interrupting is worth it, because
every option leads to a real answer.

**GUIDE.** The question cannot be answered from this database, and the
system says what is missing instead of guessing. No options, no query, no
rows. The explanation is the outcome.
*Why:* offering an option the database would not serve is exactly the
lie we are trying to prevent.

**ERROR.** The model did not answer.
*Why it is kept separate:* a system that reports "no ambiguity" because
its model timed out is lying to itself. Not knowing, and knowing there is
nothing, are two different states.

---

## The two levels, and what separates them

The criterion is **who can settle it**.

### Level 1: the database can settle it

| Type | What is unclear | Where the options come from |
|---|---|---|
| **AmbiSchema** | which column | the real columns, confirmed in `information_schema` |
| **AmbiValue** | which value | a `SELECT DISTINCT` on the actual column |
| **AmbiView** | which operation | a closed vocabulary: count, sum, average, rank, list, group |

**The steps, for AmbiSchema:** the model flags the unclear phrase and
proposes columns; the code checks each one against the catalogue;
those that do not exist are dropped; if at least two survive, it is a
CLARIFY.

*Why AmbiView is handled apart:* its options are operations, and no table
can confirm a `COUNT`. The closed vocabulary plays the part the catalogue
plays for the other two.

### Level 2: the database cannot settle it

| Type | What is unclear | Example |
|---|---|---|
| **AmbiSource** | the database, or knowledge of the world | "members taller than average" |
| **AmbiContext** | something is missing | "products cheaper than a coffee" |
| **AmbiFallacy** | the question assumes something false | "books by Shakespeare published in 2020" |
| **AmbiRef** | a vague reference to a time or a place | "stock after the merger" |

The outcome is GUIDE, **with no options**. *Why:* the model could invent
plausible choices, and nothing would confirm them. An unverifiable choice
is worse than an honest explanation.

---

## What GUIDE actually does

It is the outcome people find surprising, so it is worth being precise:
**GUIDE stops the run**. No SQL is written, nothing is executed, no rows
come back. What the user gets is a sentence naming what the question
needs and the database does not have.

Two real outputs, taken from a run on this build:

```
Q:  products cheaper than a coffee
GUIDE
    "what constitutes 'coffee'?" has no equivalent in this database.
    The question uses the word 'coffee' without specifying a price for it.
```

```
Q:  members taller than average
GUIDE
    "average of what?" has no equivalent in this database.
    The question asks for 'taller' which needs a defined measurement.
```

### Why it does not offer choices

A CLARIFY offers options because each one is a real column and each leads
to a real answer: the user is picking between readings the data can
serve. A GUIDE has nothing like that to offer. A model asked for choices
here would happily produce four plausible prices for a coffee, and
**nothing in the schema could confirm any of them**. Showing them would
move the guess from the machine to the person while making it no more
grounded, and the person would reasonably assume that a listed option
means the data supports it.

### The three situations that produce one

**Something outside the database is needed.** "Cheaper than a coffee"
needs the price of a coffee; "taller than average" needs a height. The
schema holds neither and cannot derive them.

**The question assumes something false.** "Books written by Shakespeare
in 2020" names an author and a year that do not meet in this catalogue.
Answering "no rows" would be technically true and misleading, because it
implies the premise was sound.

**Only one reading of a genuine ambiguity exists here.** "The oldest
members" is really ambiguous, age or seniority, but the database holds no
date of birth. This case is not in the AmbiSQL paper and it still needs an
answer: GUIDE names what the data does hold and offers that, labelled.
Answering silently would hide that the other reading was impossible, and
calling the question clear would be false.

### What it means when you are watching a demonstration

A GUIDE is the system declining, on purpose, with a reason. It is the
behaviour that separates a tool you can put in front of an analyst from
one that returns a number for every question asked of it. The failure it
prevents is not an error message: it is a confident answer built on a
definition nobody chose.

---

# Library database, `datagora_lib`

`authors`, `books`, `book_authors`, `genres`, `loans`, `members`

## Clear questions, ANSWER expected

| Question | What it exercises | Observed |
|---|---|---|
| `how many books are in the catalogue` · | a plain count | ANSWER |
| `number of loans per member` · | one join, one aggregate | ANSWER |
| `list the members and their email addresses` · | two columns, nothing competing | ANSWER |
| `books published before 2024` · | a date filter | ANSWER |
| `how many books per genre` · | an explicit grouping | ANSWER |
| `books that have more than one author` · | `HAVING` over a junction | ANSWER |
| `average number of pages per genre` · | an average across two tables | ANSWER |
| `the longest book` · | `ORDER BY` with a limit | ANSWER |
| `who borrowed the most expensive book` · | three tables, a superlative | ANSWER |
| `books that have never been borrowed` · | an absence | ANSWER |

## Level 1 ambiguities, CLARIFY expected

| Question | Options observed | Why it is a good case |
|---|---|---|
| `how many loans are still open` · | `loans.status`, `loans.returned_at` | two real ways to define "open", both valid |
| `who are the oldest members` · | `members.joined_at` | age does not exist, so only one reading survives |
| `list every genre and its parent genre` · | `genres.name`, `genres.parent_genre_id` | exercises the self-reference |
| `which authors are the most famous` | `books.title`, `authors.name` | **observed GUIDE**, not CLARIFY: neither column survived the check |
| `loans after the World Cup` · | `loans.returned_at`, `members.joined_at` | which date, and which event |
| `average discount per category` | `discount_percent`, `categories.name` | the measure and the grouping are both unclear. **Observed GUIDE**: neither column exists here |

## Level 2 ambiguities, GUIDE expected

| Question | Type | Why the database cannot settle it |
|---|---|---|
| `members taller than average` · | AmbiSource | height is neither stored nor derivable |
| `books cheaper than 10` · | AmbiContext | ten of what, in which currency |
| `books written by Shakespeare in 2020` · | AmbiFallacy | the question assumes a false fact |
| `books by an author who never existed here` · | AmbiFallacy | the author is absent by hypothesis |
| `which genre is the most expensive` · | AmbiView | the sum, the average or the maximum price |
| `the average rating of each book` | absent | there is no rating column, and the question is **answered anyway**: a real miss |
| `which members live in Paris` · | absent | `members` holds neither a city nor an address |

## Multi-hop, to exercise the imposed joins

| Question | Imposed path |
|---|---|
| `which authors wrote books borrowed by members` | authors > book_authors > books > loans > members |
| `how many books does each author have` | authors > book_authors > books |
| `which members borrowed books of the genre Mystery` | members > loans > books > genres |
| `the authors of the books borrowed most often` | authors > book_authors > books > loans |
| `genres borrowed by more than five members` | genres > books > loans > members |

## Absences and negations

| Question | What it exercises |
|---|---|
| `books that have never been borrowed` · | `NOT EXISTS`, not a join |
| `genres with no book at all` | absence across a dimension |
| `members who never borrowed anything` | absence across a fact |
| `authors whose books were never borrowed` | absence two hops away |

## The traps, worth watching closely

| Question | The trap | What should happen |
|---|---|---|
| `per book, the number of authors and the number of loans` | **chasm** | rejected on attempt 1, two pre-aggregated `WITH` blocks on attempt 2 |
| `total pages of the books that have at least one author` | **EXISTS** | `EXISTS` and not a join, or the pages are multiplied |
| `sum of the pages per member who borrowed them` | **fan** | the pages belong to the book, not to the loan |
| `per genre, the number of books and the number of loans` | **chasm**, two hops | the same shape, one table further out |

---

# Products database, `datagora_generic`

`categories`, `products`, `suppliers`, `product_suppliers`,
`inventory`, `inventory_movements`, `warehouses`

## Clear questions, ANSWER expected

| Question | What it exercises | Observed |
|---|---|---|
| `how many products are there in each category` · | a join and a grouping | ANSWER |
| `list the warehouses and their cities` · | a single table | ANSWER |
| `average lead time in days per supplier` · | an average over a junction | ANSWER |
| `products whose quantity is below their reorder level` · | two columns compared | ANSWER |
| `the top 5 warehouses by capacity` · | sort and limit | ANSWER |
| `products supplied by more than three suppliers` · | `HAVING` over a junction | ANSWER |
| `total quantity on hand per warehouse city` | a join and a clean aggregate | ANSWER expected, **CLARIFY observed**: a false alarm, and the last one left in this table |

## Level 1 ambiguities, CLARIFY expected

| Question | Options observed |
|---|---|
| `which supplier is the most reliable` · | `suppliers.rating`, `suppliers.is_active` |
| `show me the oldest products` · | `products.created_at`, `products.updated_at` |
| `products in Rotterdam` · | `warehouses.city`, `warehouses.code` |
| `categories and their parent category` · | `parent_category_id`, `categories.name` |
| `the best products` | none, therefore GUIDE |

## Level 2 ambiguities, GUIDE expected

| Question | Type |
|---|---|
| `products cheaper than a coffee` · | AmbiContext |
| `stock after the merger` | AmbiRef, **observed CLARIFY**: "merger" is a time reference the guard does not catch |
| `movements of type OUT last month` · | AmbiContext, which month |
| `the newest suppliers` · | `suppliers` holds no creation date |
| `the warranty duration of each product` · | a plausible column that is absent |
| `the blood type of our suppliers` | an entity foreign to this database |
| `products from a supplier that does not exist` | AmbiFallacy, **observed CLARIFY** |

## Multi-hop

| Question | Imposed path |
|---|---|
| `which suppliers provide products stored in the warehouse with code 'WH-ROT-01'` | warehouses > inventory > products > product_suppliers > suppliers |
| `which warehouses hold products of the category Cordless Drills` | categories > products > inventory > warehouses |
| `the cities where the preferred suppliers' products are stored` | suppliers > product_suppliers > products > inventory > warehouses |
| `categories stored in more than three cities` | categories > products > inventory > warehouses |

## Absences and unusual structures

| Question | What it exercises |
|---|---|
| `products never moved in or out` | absence across `inventory_movements` |
| `warehouses that store nothing` | absence across a dimension |
| `movements of a product and a warehouse pair` | a **composite key** on `inventory_movements` |
| `categories that have no parent` | the self-reference, the root of the hierarchy |
| `suppliers that supply nothing` | absence through a junction |

## The traps

| Question | The trap | Expected figure |
|---|---|---|
| `per product, the total stock and the number of suppliers` | **chasm** | rejected, then two pre-aggregated blocks |
| `total stock of the products that have at least one supplier` | **EXISTS** | 86,569 and not 150,674 |
| `total storage capacity per city` | **fan** | 25,276 and not 177,296 |
| `sum of the prices of the products in each warehouse` | **fan** | the price belongs to the product, not to the stock line |

The two figures in each trap row are the point. The wrong one is not a
crash and not an error message: it is a larger number that looks
perfectly reasonable, which is why these are the rows to check first
whenever anything changes.

---

## What the small model gets wrong today

Re-measured on this build with `gemma3:4b` on both roles, over the 42
questions in this file that state an expected outcome. **34 reach it.**
Here are the eight that do not, so that none of them is mistaken for a
flaw in the design.

**It answers two questions it should decline.** `the average rating of
each book` and `the blood type of our suppliers` both come back as
ordinary questions. There is no rating column and no blood type, and the
second is not even about anything a supplier database would hold. These
are the clearest misses in the file, and the ones to check first on a
larger model.

**It declines two it should have offered a choice on.** `which authors
are the most famous` and `average discount per category` come back as
GUIDE. That is the safer direction to be wrong in, and in the second
case it is arguably right: neither `discount_percent` nor a category
exists in the library schema.

**It asks about one clear question.** `total quantity on hand per
warehouse city` triggers a clarification it does not need. One false
alarm in seventeen clear questions, against six in eight before the
guards were added.

**It reads two vague references as column choices.** `stock after the
merger` and `products from a supplier that does not exist` come back as
CLARIFY. Both are level 2: a fuzzy time reference and a false premise.
Nothing in a schema can settle either, and the guard that catches a
missing value does not catch a missing event.

The measurement is one command, and it is the same one that produced the
numbers above:

```
python src/graph_lab/coverage.py --profile datagora_generic \
       --questions src/graph_lab/examples/questions_products.csv
python src/graph_lab/test_levels.py                      per level, both databases
python src/graph_lab/test_answers.py                     are the answers the right ones
```

## Measure rather than observe

```
python src/graph_lab/test_ambisql.py         detection against false alarms
python src/graph_lab/test_pipeline_batch.py  the whole journey, both databases
```

The first gives two numbers that must **always be read together**: how
many real ambiguities are caught, and how many clear questions are
interrupted for nothing. *Why together:* a clarifier judged on detection
alone always wins by asking about everything, which is precisely the
behaviour that makes a product unusable.
