# Prompts

Every prompt that decides something has a version, and the version is not
a promise: `prompts.py` holds each one's text and the fingerprint of that
text, and a test recomputes the fingerprint. A prompt whose words changed
while its version did not fails the suite, by name. Every coverage run
records in its `.job.json` the versions it was judged with, so a verdict
can always be traced back to the exact words that produced it.

To change a prompt:

1. edit its text in [prompts.py](prompts.py)
2. bump its `version` in `VERSIONS` and set `sha` to the new fingerprint,
   which the failing test prints
3. add an entry below saying what changed and what it measured
4. measure on both question sets before calling it better

The measurement that matters most is not the count of exact matches. It is
the count of **false denials**, a question reported as uncovered that the
database answers, and of **false yeses**, a question reported as answerable
that needs something the database lacks or the asker holds. Those two are
what a team repeats to its management.

## agent: the judge that explores the database

### v7, 2026-10-26

Under v6, Warehouse Q09 ("the most reliable suppliers") came back
ANSWERABLE three times out of three, where v5 gave a choice: the unknowns
frame turned "how is reliability measured" into a lookup, the first column
that fitted (suppliers.rating) settled it, and the list emptied. v7 adds
readings to the ways an unknown is found out: a word the data can measure
more than one way stays unknown until every column that could measure it
was looked for and the two best compared; two that differ are a choice, a
finding of the data. The code backs it: a probe looks for the columns of
each comparison of the reading (find_columns, on the tables one key away
too), and the verifier sends an answer that ranks without comparing back
once. To be settled by an A/B against v6 on Q09, Q10, Q11, Library Q08 and
Q09, E35 to E37 and plain questions.

### v6, 2026-10-23

The agent says each turn what it does not know yet and how it will find it
out (unknowns: the data, compute, clock, or last the asker), and gets two
tools: compute, one safe Python expression on numbers and dates worked out
by the code (calc.py), and clock, the asker's date, the database's clock and
a table's latest dates. Today's date comes under WHO ASKS AND WHEN, and a
follow-up carries EARLIER IN THIS CONVERSATION: a relative period is counted
from today with compute, never from the latest row, and what the asker
settled before is settled. No model knew the date: "revenue last year" was
stopped for its period (E36).

### v5, 2026-10-20

After the first run of the day (37 of 40 on Enterprise). A period ("in 2025",
"last year") is time none and as_of needs a point in time (E17 was read as
as_of and refused a history); the supposition of a what-if question is the
asker's (E26 was called absent); a business measure may be kept in invoices,
orders, the ledger or payments, and each is looked for (E36 read the ledger
alone), and "oldest" or "newest" may read several dates (Warehouse Q10, Q11);
what a question compares with is the asker's too ("cheaper than a coffee",
Warehouse Q15). The verifier holds the period, the what-if and the comparison
whatever the agent says.

### v4, 2026-10-20

After the runs of 19 October. A table with one row per date (daily rates)
counts as a history for a question at a date (E04 was refused as 'only the
current state'); a summary view or report table is not a rival reading of
the records (Warehouse Q01, Q08); a threshold has no check_sql (Q12 'cheap'
was dropped because the agent's query returned rows); what is absent is
named in one to three words (E39 swept the whole question). The example's
choice on "late" is now between two deadlines: with a status holding LATE,
the word names the status and the verifier rightly overturns the choice.

### v3, 2026-10-19

After the first live run of the agent (v1 code, six Enterprise
questions, gemma4:31b thinking, one GPU): 5 of 6 right, E16, E27, E33
and E35 among them, which the single judge got wrong. E34 found the
right fact (no budget rate for 2027) but called it no_matching_row,
whose verdict is NO DATA, where the key expects NEEDS MORE. v3 tells
the two apart: a value the computation needs and the data lacks is
what the asker must say; no matching row is a list or a count whose
answer is "none". It also asks to conclude on the next turn when the
code's probes already showed the tables, columns and joins: E01, a
plain question, made seven calls and reached the time cap.

### v2, 2026-10-19

After an independent review of v1 against the code that reads its
replies. check_sql was asked for as "the count", while the verifier
reads how many rows the SELECT returns: a COUNT(*) always returns one
row, so a missing value read as held and NO DATA became ANSWERABLE. v2
asks for the SELECT of the rows that would settle it (the verifier also
reads a COUNT(*) correctly now). It defines the issue fields the
verifier relies on: phrase (the question's own words), what (a few
words, never a sentence, since it is the term swept for an absence),
kind (optional, and only within the kinds the issue's type allows), and
AmbiRef and AmbiSource. "Do not repeat a call" no longer contradicts
rereading a table whose description was cut. Not yet measured.

### v1, 2026-10-19

The prompt of the agent judge (verdict_agent.py), sent with every turn.
It describes the loop (notes, plan, one call or a conclusion), the ten
bounded tools, the reading the first turn writes, the time rules of the
temporal note (deliverables/notes/temporalite_methodes_2026-10.md), the
four kinds of issue the verifier checks, and the rules for when two
columns are not a choice, taken from the detect v4 draft. A short
trajectory on a schema of staff, teams and projects shows the shape of
three turns. Not yet measured: the first runs are step 18 of
deliverables/plans/plan_verdicts_agent_2026-10-19.md.

## agent_wording: does the question's wording select one reading

### v1, 2026-10-20

A closed question asked once the facts show that the readings of a choice
give different results: do the words of the question already select one?
Fresh context (question, readings, the fact that they differ), no thinking,
never the agent's notes nor its verdict. Added because 'the results differ'
confirmed invented choices on 19 October (E03, E18, E20, Warehouse Q01, Q08).
Replayed offline on the 25 choices of those runs: 22 agree with the answer
key, the five expected choices (E35, E36, E37, Library Q08, Q09) are kept;
E15 (twice) and E16 stay choices. Engine switch DATAGORA_AGENT_WORDING.

## agent_ranking: is a phrase said absent a ranking of held things

### v1, 2026-10-26

A closed question asked by the verifier when the agent says a phrase is
absent and neither the age words nor the form of a ranking (a superlative,
a comparative with "than") settle it, and the phrase qualifies a thing the
database holds ("popular books"): does it rank those things by an open
measure, or name a thing that would have to be stored? Fresh context, no
thinking, at most twice a question. A ranking is never refused: the agent
is sent to look for the columns that measure it, and in the end the asker
says by what. Added in the review of 26 October (rule 3); not yet measured.

## agent_values, agent_joins: the strategies of the vote

### v1, 2026-10-19

Two short preambles added to the agent's prompt for the second and third
passes of the vote (engine setting agent_arbiter = vote): values first,
joins first. Two runs of one agent are correlated (0.75 to 0.85 in
DivSkill-SQL), so the passes are made different by strategy rather than
by temperature. Not yet measured; kept only if it wins on a paired test.

## detect: is this question ambiguous, and how

### A v4 draft, measured and not adopted, 2026-09-30

The draft asked the model to fill `value` and `candidates` even on a clear
question, with a fourth example showing it, so that an empty result could
be reported for "books written by Shakespeare". Measured on gemma3:4b
against v3 on the same code, it was worse on every question it moved:
Shakespeare became AmbiFallacy and a false NOT COVERED, "most reliable"
lost its choice, two answerable questions about capacity and quantity per
city became AmbiContext with no candidates. 24 of 38 exact and one false
denial, against 27 of 38 and none for v3 with the same code.

The empty result is found without it: v3 already names the holding
column on a clear question, and the literal is read from the question
itself when the model leaves `value` empty. The prompt stays at v3.

### v3, 2026-09-30, `a286eb72d434`

What changed:

- The schema is shown one column per line with its type, whether it is a
  key, where a foreign key leads, a few values it really holds and what it
  is documented to mean, and the prompt now says how to read that line.
  Before, the model saw names only and proposed `genres.genre_id` for a
  question about genres.
- It says what happens to the candidates: checked against the catalogue,
  invented ones discarded, real values read back.
- A key is never the meaning of a word; a concept one table away is
  reachable through a join.
- `reason` is written first. With the reply constrained by a JSON schema
  at decoding time, keys come out in schema order, so the model states its
  reason before it commits.
- `AmbiContext` and `AmbiFallacy` no longer overlap. A first draft
  described AmbiContext as "a threshold or a context", the model filed
  absent things such as audiobooks under it, and four correct denials
  became "tell me more". It is now a degree of something the schema holds;
  AmbiFallacy is a thing the schema has no column for.
- Three contrastive examples, from a schema that is not the customer's,
  one of them not ambiguous.

Measured on gemma3:4b, both question sets, 25 questions with a designed
verdict:

| | exact | false denials | false yes |
| --- | --- | --- | --- |
| v2 | 22 / 25 | 1 | 2 |
| v3 | 20 / 25 | 0 | 0 |

v3 gives two fewer exact matches and none of the dangerous errors. The two
it loses fall on the safe side, NEEDS MORE where the design wanted
ANSWERABLE or NOT COVERED. Stable across two consecutive runs.

### v2, 2026-09-28, `f8aafedb2598`

`AmbiIntent` renamed `AmbiView`, an `operations` field, and instructions per
kind saying what to fill for each.

### v1, 2026-09-21, `1a4ead2624ac`

The first version, with the AmbiSQL taxonomy and general rules.

## decide: can this concept be read off these real values

### v2, 2026-09-30, `414c435c2d7c`

What changed:

- A candidate that is a key is now shown as the column it stands for, one
  join away, marked `[reached through books.genre_id = genres.genre_id]`.
  The prompt says the join is known and the column is judged on its
  values. The model still names one column and never a join: the path
  comes from the catalogue's foreign keys, so it is one that exists.
- `why` comes first, and the reply is constrained by a JSON schema whose
  table and column can only be ones that were shown, or empty on a no.
- A value spelt another way counts: DE is Germany. This is what lets the
  step overturn an empty result on a column of codes, the one case where
  a LIKE and a SOUNDEX cannot connect the question to the data.
- The rule about bread and rice is written as a sentence.

Measured with detect v3, both question sets on gemma3:4b: 27 of 38
exact, no false denial, no false yes (v1 with the earlier code: 26, 0, 1).
The gain is the code around it as much as the prompt: an empty result
reported as NO DATA, and a judgement whose column the values settled
still asking for its threshold.

### v1, 2026-09-30, `9b0b98480c0a`

New. Asked only after the columns are identified and their distinct values
read, so the model decides about rows that exist. Its "no" is weak by
design: it may withdraw a menu of free-text columns, never one built on a
column that records a state, and never produce NOT COVERED on its own.

## sql, anchor, answer: the pipeline that writes and explains SQL

### sql v2, 2026-10-20

WHAT TO SELECT: a list is selected by what a person knows the things by (a
name, title or label) with the value that orders it, never a key alone. Ask
answered "Show me the oldest products" with twenty product_id values, which
the answer sentence could only recite as numbers.

### v1, 2026-09-24

Unchanged since they moved from `pipeline.py` into `prompts.py`; their
earlier history is in `pipeline.py`.

## reformulate: questions the asker can pick

### v2, 2026-10-20, `63137b1c0f27`

One rule and the second example changed: a value question names what it
compares by the name given under "Measured on" ("Which products have a
price under 10?", not "cost less than 10"). Found by the live run of the
29 Ask questions on gemma3:4b (docs/test_strategy/ask_reformulate): "Which
books cost less than 100?", picked, was judged NEEDS MORE again because
nothing in the Library schema is called "cost", while "Which books have a
price below 100?" was answerable. The code now also refuses a value
question that drops the measure's name, so the template stands in.

### v1, 2026-10-20, `60a0d199d300`

Written for the Ask page. When a question stops on NEEDS A CHOICE or
NEEDS MORE, the asker used to be shown the readings as the database
records them ("employees with status_code = 'ACTIVE'") or nothing to click
at all. This prompt turns the readings, or the values and periods read
from the data, into complete questions in the asker's words, one per
reading or proposal. It decides nothing about the verdict: the clarifier
has already given it. One call, thinking off, bounded (`reformulate.py`).

Its text is checked rather than trusted. A question that names a table or
column that is not an everyday word, shows an underscore, a symbol, SQL or
a quoted code, or brings a number that was neither in the question nor in
its proposal, is replaced by a template built from the option's meaning,
for that suggestion only. Without a model the templates alone are shown.
Engine switch DATAGORA_REFORMULATE (setting `reformulate`).
