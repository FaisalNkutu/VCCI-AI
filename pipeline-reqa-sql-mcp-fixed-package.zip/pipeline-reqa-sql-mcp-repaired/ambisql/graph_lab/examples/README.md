# Example question lists

The products and library files are shaped like a list a client would
actually hand over: an `id`, a `theme`, who asked, and the question.
Nothing else. **The verdict is what you are coming to find out, so it is
not in the input.**

```bash
python src/graph_lab/coverage.py --profile datagora_generic \
       --questions src/graph_lab/examples/questions_products.csv \
       --out verdicts.csv
```

Or from the page, http://localhost:8080/coverage: drop the file, or
click the example link to fill the box without one.

| File | Database | Questions |
|---|---|---|
| `questions_products.csv` | `datagora_generic` | 25 |
| `questions_library.csv` | `datagora_lib` | 23 |
| `questions_enterprise.csv` | `datagora_enterprise` | 70 |

`questions_enterprise.csv` carries the verdict each question should get
(`expected`), the verdicts also accepted, and its difficulty; the
database is built by `scripts/make_enterprise_db.py`, its dictionary is
`kb_enterprise.json` (`scripts/make_enterprise_kb.py`), and the tables and
reference SQL of each question are in `scripts/enterprise_questions.json`.
E01 to E40 run on the 156 original tables; E41 to E70 ask about time
(state at a date, sequences, durations, objects behind a type column)
and need the 256-table build, `datagora_enterprise_next` until
`datagora_enterprise` is rebuilt. `scripts/build_enterprise_questions.py`
runs every reference query and writes the JSON and this CSV.

Every column other than `question` is carried through to the export
untouched, so each verdict comes back next to the row it came from.

For schemas whose short names do not explain the business meaning, point
`DATAGORA_DESCRIPTIONS` at a JSON data dictionary. The format and a complete
example are in `deploy/config/descriptions.example.json`. It is optional;
without it, coverage continues from table and column names alone.

`DATAGORA_ASK_VALUES=on` enables the bounded value-decision step. Only after
candidate columns have been confirmed does coverage read their real
`SELECT DISTINCT` values and ask the model whether those values can decide
the concept. `DATAGORA_SAMPLE_VALUES` controls the sample size and
`DATAGORA_ENUMERATION` the largest closed vocabulary treated as a state.
See `INTEGRATION.md` for the evidence rules that prevent a model response or
a failed database lookup from becoming a false `NOT COVERED`.

To test the installed library with one real question instead of a coverage
file, run from the repository root after installing the local wheel:

```powershell
.venv\Scripts\python.exe -m graph_lab.examples.try_one_question
```

Pass `--question "your question"` to replace the default library question.

For a long batch, always provide `--out`. It is updated after every
question, and the same command resumes from that file after an interruption.
Rows marked `UNKNOWN` are retried; successful rows are not. Use
`--stop-on-error` when a shell job should stop at the first failed call, and
`--restart` only when the existing output should be replaced deliberately.

## The five verdicts

**ANSWERABLE**, the question can be answered as asked.
**NEEDS A CHOICE**, the data supports multiple interpretations and someone
picks; the choices are real columns, listed.
**NEEDS MORE**, the question is missing something the asker has and the
database does not. It names what to add, and it works on the next try.
**NOT COVERED**, the database holds nothing of the kind. Asking again
will not help.
**UNKNOWN**, nothing was decided: a model that did not answer, a database
that refused the connection. It says something about the installation and
nothing about the data, so it must never be read as a negative verdict.
Re-running retries exactly those rows.

The split between NEEDS MORE and NOT COVERED is the point of the whole
report. Telling a team to rephrase a question their data can never answer
wastes their afternoon, and telling them their data is missing when the
question was merely vague sends them building something they already have.

## What these two lists should come back as

Each CSV says it too, in its `real_verdict` and `also_accepted` columns,
copied from the evaluation sets (docs/test_strategy/coverage_bench/datasets)
by scripts/add_real_verdict.py, so the coverage page can score a run
started from it. The judge never reads them: a question is judged on its
text alone. What the taxonomy says, against what this build produced with
`gemma3:4b` on both roles:

### questions_products.csv, 25 questions

Measured on `gemma3:4b` on both roles, which is the weakest model in the
set and therefore the floor rather than the result. The table covers Q01
to Q20; Q21 to Q25 (shipments by mode, vessels) came later and were not
part of that measure.

| | Question | Intended | gemma3:4b |
|---|---|---|---|
| Q01-Q07 | direct aggregates and joins | ANSWERABLE | as intended |
| Q08 | total quantity per warehouse city | ANSWERABLE | NEEDS A CHOICE |
| Q09 | which supplier is the most reliable | NEEDS A CHOICE | as intended |
| Q10 | show me the oldest products | NEEDS A CHOICE | as intended |
| Q11 | who are our newest suppliers | NEEDS A CHOICE | NEEDS MORE |
| Q12 | which products are cheap | NEEDS MORE | as intended |
| Q13 | which warehouses are nearly full | NEEDS MORE | as intended |
| Q14 | how many products did we sell recently | ANSWERABLE | as intended |
| Q15 | products cheaper than a coffee | NEEDS MORE | **ANSWERABLE** |
| Q16 | warranty duration of each product | NOT COVERED | as intended |
| Q17 | which products are gluten free | NOT COVERED | as intended |
| Q18 | blood type of our suppliers | NOT COVERED | **ANSWERABLE** |
| Q19 | warehouses that store nothing at all | ANSWERABLE | NEEDS MORE |
| Q20 | total value of the stock per warehouse | ANSWERABLE | NEEDS MORE |

16 of 20 as intended. The four that differ are worth reading separately,
because two are model misses and two are the component being cautious.

**Q15 and Q18 are the misses that matter.** Both come back ANSWERABLE
because the reasoner does not flag the question at all, so it never
reaches any classification rule. Q15 is the more dangerous of the two: no
price of a coffee exists anywhere, so the next step writes SQL against a
threshold it invented. These are the cases to re-check on a larger
reasoner, and the reason the model on that role is the lever.

**Q19 and Q20 are cautious rather than wrong.** A LEFT JOIN answers the
first and `price` times `quantity_on_hand` answers the second, so
ANSWERABLE is the better verdict, but NEEDS MORE only costs the reader a
rephrasing. They were `NOT COVERED` until the quantifier rule was fixed,
which was a false claim about a schema holding both columns.

### questions_library.csv, 23 questions

The table covers Q01 to Q18; Q19 to Q23 (digital, damaged and braille
copies) came later and were not part of that measure.

| | Question | Intended | gemma3:4b |
|---|---|---|---|
| Q01-Q03, Q05-Q07 | direct aggregates, joins | ANSWERABLE | as intended |
| Q04 | which is the longest book | ANSWERABLE | NEEDS MORE |
| Q08 | how many loans are still open | NEEDS A CHOICE | as intended |
| Q09 | who are the oldest members | NEEDS A CHOICE | NEEDS MORE |
| Q10 | what are the most popular books | NEEDS MORE | as intended |
| Q11 | which members live in Paris | NOT COVERED | as intended |
| Q12 | which members are taller than average | NOT COVERED | as intended |
| Q13 | which books are cheap | NEEDS MORE | as intended |
| Q14 | which members borrowed something recently | NEEDS MORE | NEEDS A CHOICE |
| Q15 | books written by Shakespeare in 2020 | NOT COVERED | NEEDS A CHOICE |
| Q16 | which books are available as audiobooks | NOT COVERED | as intended |
| Q17 | which members have unpaid fines | NOT COVERED | as intended |
| Q18 | which authors are still alive | NOT COVERED | NEEDS MORE |

13 of 18 as intended, and every difference errs on the cautious side.

**Q11 is the one to show a client.** `members` holds a `full_name` and an
`email` and no city at all, so "which members live in Paris" is genuinely
not coverable. The component proves it by sweeping the data for the value
before saying so, rather than by reading the question, which is what makes
the claim safe to put in front of someone.

**Q15 is a false premise**, and coming back as NEEDS A CHOICE is the safe
direction to be wrong in: the reader rephrases and finds out that the
catalogue has no Shakespeare from 2020, rather than being told their data
is missing something it never had.

**Q18 has half the answer.** `authors.born_year` exists and nothing
records a death, so NOT COVERED is the truthful verdict and NEEDS MORE is
too soft. A question the data can only half answer is the hardest case in
the whole set.

## Questions to try the reformulation on Ask

One file per test database, the questions whose real verdict is NEEDS A
CHOICE or NEEDS MORE, taken from the evaluation datasets
(docs/test_strategy/coverage_bench/datasets/). They are the ones Ask stops
on: a choice to make, or something the asker must say. `expect` is what
the answer key says: for a choice, the readings it accepts, one per
proposal Ask should make; for NEEDS MORE, what is missing, which the
proposals should fill with values taken from the data.

| File | Database | Questions |
|---|---|---|
| ask_reformulate_enterprise.csv | Enterprise (datagora_enterprise) | 16: 7 choices, 9 needs more |
| ask_reformulate_warehouse.csv | Warehouse (datagora_generic) | 7: 3 choices, 4 needs more |
| ask_reformulate_library.csv | Library (datagora_lib) | 5: 2 choices, 3 needs more |
| ask_reformulate_point.csv | Point (datagora_points) | 1 needs more |

Point has no question whose answer key is a choice yet. Each file also
runs as a coverage question list: its `real_verdict` column gives the
accuracy on the Coverage page.
