# Deploying and integrating this engine

**Two ways in, and they are not the same amount of work.**

**Part 1, running it.** Docker does all of it. A handful of lines in a
`.env`, one `docker compose up -d`, and the coverage page is in front of
your own database. No code to write, no file to edit inside the package,
nothing to build. The first two sections are all most deployments ever
need; the rest of Part 1 is reference.

**Part 2, taking the code out.** This is where you change things: you
already run a pipeline and want our clarifier, our join audit or our
coverage batch inside it, with your connection pool and your model client
instead of ours. Then you install the wheel and write the two small
adapters Part 2 describes.

Most people want Part 1. Read Part 2 when the answer to "where does this
run" is "inside our LangGraph", not "next to it".

Three checks cover the promises made here:

- `test_integration.py` imports the source package from another directory
  and exercises the complete engine with and without Neo4j;
- `test_coverage.py` exercises incremental saving, interruption and resume;
- `build_graph_lab_wheel.py` installs the built artifact into a temporary
  location and imports `graph_lab` from that installed copy, not from `src/`.

The engine is built as a local `datagora-graph-lab` wheel and imported as
`graph_lab`; this workflow does not publish it.

# Part 1: running it

Everything is in the image: the page, the engine, their dependencies. What
comes from outside is a short environment block. Copy `.env.example` to
`.env` as a starting point; it contains no working credentials.

`.env.example` describes the demonstration: several databases in
`DATAGORA_DATABASES` and several model servers in `DATAGORA_ENDPOINTS`.
Each of those two lines takes precedence over the one-database, one-model
block below, which is then ignored. For one database and one model, delete
both lines from your `.env` before adding the block; for several, describe
them in the format `.env.example` shows. The Settings page can do either
once the container is up.

```
MYSQL_DATABASE=warehouse
MYSQL_HOST=db.internal
MYSQL_USER=coverage_reader
MYSQL_PASSWORD=...
DATAGORA_LLM_URL=http://models.internal:8000
DATAGORA_LLM_MODEL=your-served-model-name
DATAGORA_LLM_API=openai
```

```bash
docker compose up -d
```

That is the deployment. The page is on the published port, `/coverage` for
the question list.

### Changing something afterwards

This paragraph used to say "edit the `.env` and `docker compose restart`:
nothing is baked into the image". Both halves were wrong, and a deployment
lost an hour to them. What is actually true:

| What you changed | What re-reads it |
| --- | --- |
| a value in `.env` | `docker compose up -d --force-recreate ambisql-ui` |
| a mounted file, such as your `profiles.json` under `/config` | restarting is enough, the file is read on each request path that needs it |
| anything under `src/graph_lab` | `docker compose build ambisql-ui` first, then `up -d --force-recreate` |

`docker compose restart` re-runs the container with the environment it was
created with. It does not look at `.env` again. And the source is copied
into the image at build time: the only bind mount is `./coverage_runs`, so
editing a Python file or a page on the host changes nothing until you
build.

If the page shows a model or a database you never configured, it is
telling you which configuration it is actually reading, in amber, under
the status line. That sentence names the file, and it is the answer.

## What it needs, and what it does not

A database and a chat model. That is the whole list.

| Service | Coverage | The rest of the pipeline |
|---|---|---|
| MariaDB or MySQL | **required** | required |
| A chat model | **required**, the `reasoner` role only | required |
| Neo4j | not used | required, it holds the join graph |
| Qdrant | not used | optional, it holds the anchor corpus |
| Langfuse | not used | optional, it holds traces |

Leave a service out of the `.env` and it is simply not part of your
deployment. Nothing invents an address for a service nobody deployed,
which would only be reported as unreachable rather than as unused. Without
a join graph the engine says on every run that joins were not verified,
rather than refusing to start; coverage never asks for one at all.

Verified rather than assumed: with Neo4j pointed at a closed port, a
coverage batch returns every verdict.

A read-only database user is enough and is what we would recommend. The
coverage path issues `SELECT` against `information_schema` and samples
values; nothing in it writes.

## The variables

`MYSQL_DATABASE` is what decides the database: set it and the page offers
exactly that one. `DATAGORA_LLM_URL` and `DATAGORA_LLM_MODEL` together
decide the model, and every role plays on it. `DATAGORA_LLM_API` is
`ollama` or `openai`; anything serving the OpenAI chat-completions shape,
vLLM and TGI included, is `openai`.

A SQL specialist on its own host, when there is one:

```
DATAGORA_LLM_SQL_URL=http://models.internal:8001
DATAGORA_LLM_SQL_MODEL=your-sql-model-name
```

`docker compose up -d` starts the page and nothing else. This repository's
own MariaDB, Neo4j and Qdrant are in a `demo` profile, because they exist
for the demonstration and a deployment has its own. They used to be hard
dependencies of the page, which meant it would not start until a demo
database nobody asked for was healthy, while this same document was
telling you Neo4j was optional. For local development,
`COMPOSE_PROFILES=demo` in `.env` brings them up with the same command.

## Every variable

| Variable | Meaning |
|---|---|
| `MYSQL_DATABASE` | **the database.** Setting it is what makes the page offer it, with no file involved |
| `MYSQL_HOST`, `MYSQL_PORT` | where it lives. The library defaults to `127.0.0.1:3306`; Docker deployments should set the real host |
| `MYSQL_USER`, `MYSQL_PASSWORD` | the login. A read-only user is enough and is what we would recommend |
| `DATAGORA_DB_NAME` | a label for the page, when the schema name is not the one to show |
| `DATAGORA_LLM_URL`, `DATAGORA_LLM_MODEL` | **the model.** Both set means every role plays on it |
| `DATAGORA_LLM_API` | `ollama` or `openai`. Defaults to `ollama` |
| `DATAGORA_LLM_SQL_URL`, `DATAGORA_LLM_SQL_MODEL`, `DATAGORA_LLM_SQL_API` | a separate SQL specialist, when there is one; set its API shape when it differs from the main model |
| `DATAGORA_LLM_ENDPOINT` | pin the single endpoint to override when a `models.json` file is used |
| `DATAGORA_LLM_REASONER`, `DATAGORA_LLM_SQL` | assign configured endpoint names to roles without editing `models.json` |
| `NEO4J_URI`, `NEO4J_USER`, `NEO4J_PASSWORD` | the join graph. Unset means no graph |
| `QDRANT_URL`, `QDRANT_COLLECTION`, `QDRANT_API_KEY` | the anchor corpus. Unset URL means no corpus; the same API key is sent by the server and client |
| `OLLAMA_URL`, `EMBED_MODEL` | where embeddings come from, only if you use the corpus |
| `DATAGORA_DESCRIPTIONS` | optional JSON data dictionary for table and column meanings |
| `LANGFUSE_PUBLIC_KEY`, `LANGFUSE_SECRET_KEY`, `LANGFUSE_BASE_URL`, `LANGFUSE_PUBLIC_URL` | tracing and its browser-facing link. Unset keys mean no tracing |
| `DATAGORA_TRACING` | `off` to send nothing even when keys are present |
| `DATAGORA_LOG_LEVEL`, `DATAGORA_PROMPT_LABEL` | application log level and promoted Langfuse prompt label |
| `DATAGORA_HOST_GATEWAY` | inside a container, what `127.0.0.1` in any endpoint should become |
| `DATAGORA_COVERAGE_DIR`, `DATAGORA_COVERAGE_DIR_LABEL` | server save directory and the corresponding path shown to a person on the host |
| `DATAGORA_ASK_VALUES`, `DATAGORA_SAMPLE_VALUES`, `DATAGORA_ENUMERATION` | optional decision on real values and its two limits; detailed below |
| `DATAGORA_CONTEXT` | static facts about who asks, given to every model with each question, as JSON (`{"location": "Montreal", "currency": "CAD"}`) or the path of a JSON file; the machine's date, time, timezone and language are always added (`Datagora(context=...)` and `ask(..., context=...)` override it, `False` turns it off; see the package README) |
| `DATAGORA_REFORMULATE` | `off` stops the questions offered to pick when a question needs a choice or more detail (on by default; `Datagora(reformulate=...)` overrides it; see the package README) |
| `DATAGORA_PROFILES`, `DATAGORA_MODELS` | paths to files, for the two cases below and nothing else |

An unset variable and an empty one mean the same thing, deliberately.
Compose passes a variable it cannot resolve as an empty string, so a
configuration read that trusted the presence of a key rather than its
content would silently blank out the value it was supposed to default.
That is a bug we shipped and fixed: the page reported a model with no name
and no host, which reads exactly like a network failure.

## When you need a file after all

Two cases, and only two.

**Several databases offered side by side** in the page's select. A
`profiles.json` names them, and nothing else can express more than one:

```json
{
  "profiles": {
    "warehouse": {
      "mysql": {"host": "db.internal", "port": 3306, "database": "warehouse"}
    },
    "billing": {
      "mysql": {"host": "db.internal", "port": 3306, "database": "billing"}
    }
  }
}
```

**A shelf of model endpoints to switch between**, rather than the one the
environment names. A `models.json` holds them, and `roles` is the one line
you edit to move a role from one to another:

```json
{
  "roles": {"reasoner": "house-model", "sql": "house-sql-specialist"},
  "endpoints": {
    "house-model": {"api": "openai", "url": "http://models.internal:8000",
                    "model": "your-model"},
    "house-sql-specialist": {"api": "openai",
                             "url": "http://models.internal:8001",
                             "model": "your-sql-model"}
  }
}
```

Credentials stay out of both files, so they can live in git: they come
from `MYSQL_USER` and `MYSQL_PASSWORD` as before.

`deploy/config` holds a commented example of each. Mount the folder
read-only and name the files, which is the commented volume already in
`docker-compose.yml` under `ambisql-ui`:

```yaml
    volumes:
      - ./deploy/config:/config:ro
    environment:
      DATAGORA_PROFILES: /config/profiles.json
      DATAGORA_MODELS: /config/models.json
```

Read-only on purpose: the container never writes its own configuration,
which is one less way for a running service to drift from what you
deployed. A file named but not present is reported on the page rather than
crashing it:

```
DATAGORA_PROFILES names /config/profiles-typo.json, which is not a
readable file. Unset it to use the packaged profiles, or mount the file
there.
```

### Which one is used, in order

The first that applies wins:

| | Databases | Models |
|---|---|---|
| 1. the settings page | what it saved | what it saved |
| 2. the `.env`, one block each | `DATAGORA_DATABASES` and `DATAGORA_DB_<NAME>_*` | `DATAGORA_ENDPOINTS` and `DATAGORA_ENDPOINT_<NAME>_*`, roles in `DATAGORA_LLM_REASONER` / `DATAGORA_LLM_SQL` |
| 3. a file named explicitly | `DATAGORA_PROFILES` | `DATAGORA_MODELS` |
| 4. one of each, from variables | `MYSQL_DATABASE` and friends | `DATAGORA_LLM_URL` **and** `DATAGORA_LLM_MODEL` |
| nothing | an empty list, and the page says so | the same |

The settings page comes first because production is configured there:
what somebody changes on it is what runs. It used to be second, and a
database added on the page was saved and then ignored because a `.env` on
the same machine listed others. The `.env` blocks serve while the page has
none, which is how scripts, a CI and the package without the page are
configured ([deploy/TESTING.md](../../deploy/TESTING.md) has a complete
one). A service value typed on the page (a Neo4j password, the Qdrant
minimum score, the Langfuse keys) replaces the `.env`'s; emptied on the
page, the `.env`'s value is back. The real environment wins over the `.env`
file itself, so a variable set by compose or a secret manager wins over a
working copy.

There is no packaged demo any more. It used to be level 5: two example
databases on 127.0.0.1 with root/root, used whenever nothing was
configured, which made a production page answer from databases nobody
there had named.

One thing that does **not** layer: `DATAGORA_LLM_URL` and
`DATAGORA_LLM_MODEL` are how the environment describes a model, not a
patch applied on top of a file. With a `models.json` in force they are
ignored, and each role takes the endpoint its `roles` block names. To
redirect one endpoint of a file without editing it, name it in
`DATAGORA_LLM_ENDPOINT` and those two variables apply to that one.

## Check it before trusting it

Open the page. The **Database** select holds the profiles you declared,
each marked reachable or not, and the line under the buttons names the
model actually in force rather than the one you meant to configure. Or
ask the API directly:

```bash
curl -s http://localhost:8080/api/health
```

A database that is unreachable says why there, rather than failing when
somebody presses the button. A mistyped `DATAGORA_PROFILES` is reported on
the page as well:

```
DATAGORA_PROFILES names /config/profiles-typo.json, which is not a
readable file. Unset it to use the packaged profiles, or mount the file
there.
```

Then drop a CSV of questions on `/coverage` and read the verdicts. What
each one means is in **What comes back for one question**, below.

## If you would rather not deploy our page at all

It is a demonstration of the library, not the only way in. Your own front
end can call the same code with your connection pool and your model
client, and then none of the configuration above applies.
`examples/coverage_in_production.py` is a runnable version of exactly
that, streaming endpoint included. Part 2 is the reference.

# Part 2: taking the code out

Everything above needed no code. This part is the other case: your own
front end, your own connection pool, your own model client, and one of our
steps inside a pipeline you already run. That is where you write something,
and it is about fifteen lines.

What you would take, and why anyone would:

| | What it does | Why take just this |
|---|---|---|
| `is_ambiguous` | is this question ambiguous in this schema, with the readings named | your pipeline already answers questions; this is the step it lacks |
| `suggest_questions` | whole questions in the asker's words for a choice or a NEEDS MORE, from what `is_ambiguous` returned | your users cannot choose between column names |
| `check_sql` | judge SQL you already generate, without running it | measures the queries your current pipeline produces, changes nothing |
| `assess_coverage` | a verdict per question, for a whole list | the coverage report, behind your own interface |
| `imposed_joins` | every join the schema allows between these tables | hand it to whatever writes your SQL today and it has nothing left to invent |

Nothing in the package has to change for any of this. It already takes the
two things it cannot invent as arguments: the database, as `db=` a dict of
MySQL credentials straight from your secret manager (`assess_coverage`
also takes a `connect` function returning a DB-API connection, with its
`schema`), and the model, as `llm=` a function taking `(system, user)` and
returning text or a dict. So no `profiles.json`, no `models.json`, no
`DbProfile` and no `LLM` class unless you want them.
`examples/coverage_in_production.py` is a runnable version of exactly that,
streaming endpoint included.

## Build and install the wheel

From the repository root:

```powershell
.venv\Scripts\python.exe scripts\build_graph_lab_wheel.py
```

The wheel is written to `dist/` and immediately installed into an isolated
temporary target for an import check. Install the resulting artifact in an
application environment with:

```powershell
python -m pip install "dist\datagora_graph_lab-1.2.0-py3-none-any.whl[qdrant]"
```

For the Web UI dependencies too:

```powershell
python -m pip install ".[ui]"
```

The package also installs two commands: `datagora-coverage` and
`datagora-audit`.

## Smallest runnable import test

The repository includes a one-question consumer in
`src/graph_lab/examples/try_one_question.py`. It imports the locally
installed wheel, connects to the local Docker MySQL service, asks one
question and prints the generated SQL and final answer.

From the repository root, build and install the local artifact, then run
the sample:

```powershell
.venv\Scripts\python.exe scripts\build_graph_lab_wheel.py
.venv\Scripts\python.exe -m pip install --force-reinstall --no-deps `
  dist\datagora_graph_lab-1.2.0-py3-none-any.whl
.venv\Scripts\python.exe -m graph_lab.examples.try_one_question
```

No package is published by these commands. The first command only writes
under `dist/`, and `pip` installs that local file. The default question is
`how many books per genre` against `datagora_lib`. To ask another one:

```powershell
.venv\Scripts\python.exe -m graph_lab.examples.try_one_question `
  --question "which authors have the most books?"
```

The script prints the path from which `graph_lab` was imported, making it
clear whether the installed wheel is the code being exercised. It uses
`MYSQL_USER` and `MYSQL_PASSWORD` when set, with the local Compose defaults
`root` / `root` otherwise. `DATAGORA_MYSQL_HOST` and
`DATAGORA_MYSQL_PORT` can override the connection address.

If the question needs clarification, the script prints the available
labels. Repeat the command with `--choice LABEL` to continue that question.

## Coverage as a library

This is the high-level import for a long, resumable question file:

```python
from graph_lab import assess_file


def progress(verdict, done, total):
    print(f"{done}/{total} ({done / total:.1%}) "
          f"{verdict.verdict}: {verdict.question}")


report = assess_file(
    "questions.csv",
    "coverage_results.csv",
    profile="Library",               # a database configured on the Settings page
                                     # or in DATAGORA_DATABASES
    on_each=progress,
)

print(report.counts)
print(report.complete, report.remaining)
```

Every callback happens only after the row is flushed and synchronised to
the output CSV. Run the same call again after a failure: valid rows are
skipped, `UNKNOWN` or truncated rows are retried, and duplicate questions
remain distinct. Pass `restart=True` to deliberately replace an existing
run, or `stop_on_error=True` to stop at the first failed question after all
preceding rows have been saved.

The judge is the agent that explores the database, unless `judge="single"`
or `DATAGORA_JUDGE=single` asks for the single call. A rerun is refused,
with a message saying why, when the output holds verdicts of the other
judge or of another database: a file mixing them would compare a run with
itself. Pass `restart=True`, or another `out`. A resumed run counts "last
year" from the date its first run did (`context=` changes it), and its
manifest records that date and the prompt versions of each run.

The run is identified by its questions. `job_id(questions)` is a short
hash of the question list, recorded in a `.job.json` next to the output,
which is what makes a resume a matter of passing the same question file
again. If `out` already holds a different job, this one is written as
`<name>.<job>.csv` beside it and `report.note` says so; verdicts already
decided for identical question rows are carried into the new version, so
an edited list only re-judges what changed.

`BatchReport` exposes `total`, `already_done`, `processed`, `counts`,
`remaining`, `complete`, `job`, `note`, `stopped` and the resolved
`output` path, which is the one to read rather than the path you passed.
An `UNKNOWN` makes `complete` false; it is never counted as a negative
coverage verdict. A run that ends early, whether interrupted or stopped
by `stop_on_error`, still returns its report with `stopped` naming the
reason: the rows that landed are described rather than lost with the
traceback.

## Telling the engine what your columns mean

Optional, and the single highest-value thing you can give it. A schema
says what a column is **called**; it never says what the column holds.
`fee`, `sku`, `qty` and `rating` carry almost nothing, and a question
asked in the words your users actually use will not match them.

A data dictionary fixes that. Point `DATAGORA_DESCRIPTIONS` at a JSON
file, or name it in a profile's `descriptions` field:

```json
{
  "tables": {
    "inventory_reorder_report": "a derived view of inventory, not a source of truth"
  },
  "columns": {
    "suppliers.rating": "our own score out of five, how reliable they have been",
    "appointments.fee": "what the patient is charged, in euros, before insurance"
  }
}
```

Describe only what needs describing and leave the rest out. It changes
three things, all of them measurable:

| | Without | With |
|---|---|---|
| what the model sees when it picks columns | names only | names and meanings |
| "how reliable is this supplier" matched against `suppliers.rating` | no match | matched |
| a view reported as derived rather than as a second opinion | no | yes |

`deploy/config/descriptions.example.json` is a commented starting point.
An unreadable or missing file is ignored rather than fatal: it is an aid,
not a source of truth.

### A knowledge base, as a modelling team exports one

The same field takes a knowledge base in the production shape, one entry
per table, and tells the two apart by their keys:

```json
{"abs_point": {
   "label": "Absolute Point",
   "description": "Extension table ... Use cat_code to classify records.",
   "columns": {
     "cat_code": {"description": "Category code classifying the Absolute Point.",
                  "data_type": "ENUM",
                  "allowed_values": {"CARTPT": {"label": "CARTESIAN-POINT"},
                                     "GEOGPT": {"label": "GEOGRAPHIC-POINT"}}}},
   "primary_key": "abs_point_id",
   "relationships": [{"role": "parent_of", "related_table": "geo_point",
                      "cardinality": "Zero Or One", "type": "Identifying",
                      "join_on": "abs_point.abs_point_id = geo_point.geo_point_id",
                      "own_column": "abs_point_id", "related_column": "geo_point_id"}],
   "semantic": {"aliases": ["coordinate", "reference point"]},
   "sample_queries": [{"question": "...", "sql": "..."}]}}
```

What is read from it, and what each part changes
([dictionary.py](dictionary.py)):

| Part | Used for |
|---|---|
| `label`, `description`, column descriptions | shown to the model, and matched against the question's words |
| `allowed_values` with their labels | the model sees `GEOGPT (GEOGRAPHIC-POINT)`; "geographic points" is looked up as `GEOGPT` with no query; a value outside the list, found in no other column, is NOT COVERED |
| `primary_key`, `relationships` | keys and joins the catalogue does not declare: a reference whose target depends on a code cannot be a foreign key, and column names often do not match across a join |
| `relationships` of one row at most, key on key | which tables continue a parent's rows. Which code's rows are in which table is not written anywhere; it is asked of the data, one bounded query per child, and linked only when the child's rows carry a single code |
| `aliases`, `keywords` | evidence that withholds a denial, never a reason to say yes |

Provenance, retrieval hints and validation notes are dropped on the way
in. The file is parsed once per process and read again only when it
changes: a 2.3 MB knowledge base of 700 tables parses in about a third of
a second, and later reads take a millisecond.

The two demo databases ship with one each, generated from their catalogue
by `scripts/make_demo_kb.py`, including coded kinds in the production
shape: copies coded `PRNTCP` / `DGTLCP` with a table per kind, shipments
coded `ROADSH` / `SEASHP` / `AIRSHP`. A relative path in a profiles file is
read from that file's folder, which is how the packaged demo finds them.

The same file is available through the direct library entry point:

```python
dg = Datagora(mysql=mysql_config, descriptions="/config/descriptions.json")
```

## Teaching it your trade's words for a degree

This one guards the strongest claim the engine makes, so read it before you
rely on `NOT COVERED`.

A question can be short of a **threshold the asker holds** rather than
short of a column the schema lacks. "Which products are cheap?" needs a
price ceiling from the person asking; `products.price` is right there.
Sweeping the data for the word "cheap" proves nothing, so a denial resting
on that sweep would say "your database cannot answer this" about a
question that only needs a number.

The engine recognises that case from a list of adjectives. **The list is
written in English and it is not complete**, and that is a real limit
rather than a theoretical one. Measured on a shipments schema holding
`due_date` and `delivered_at`:

```
before:  Which shipments are overdue?  ->  NOT COVERED
                                           "Nothing here can express it."
```

`overdue` was not in the list, so nothing withheld the denial, and the two
columns that answer it in one query sat in the schema. The same happened
for `delayed`, `stale` and `urgent`. Those four are in the defaults now.
Yours will not be.

So the vocabulary is yours to extend:

```bash
DATAGORA_VOCABULARY=/config/vocabulary.json
```

or as `vocabulary` in a profile, beside `descriptions`.
`deploy/config/vocabulary.example.json` is a commented starting point.

```json
{
  "judgements": ["overdue", "at-risk", "understaffed", "knackered"],
  "phrasings": [],
  "not_a_value": [],
  "filter_words": [],
  "stopwords": []
}
```

Four properties worth knowing:

- **Additive, never replacing.** Your words are added to the engine's. A
  file cannot remove a word, so it cannot silence a denial the data
  earned, and a file that lists only `judgements` keeps all four other
  vocabularies intact.
- **It can only ever soften a verdict.** A word you add moves a question
  from `NOT COVERED` to `NEEDS MORE` and never the other way. That
  direction is the whole point: the cost of a missing word is a false
  denial, and the cost of an extra one is a question that asks you for a
  threshold.
- **Unreadable is ignored, not fatal and not empty.** A missing file, a
  malformed one, or a key holding something that is not a list leaves the
  defaults in place. Becoming an empty vocabulary would withdraw the
  protection at the moment the file was meant to strengthen it.
- **A word that is also a stored value should be left out.** In the demo
  library `loans.status` really holds `late`, so the data answers "which
  loans are late?" and calling the word vague would hide that. `late` is
  deliberately absent from the defaults for this reason. On a schema where
  `late` is only ever a degree, add it.

## Asking the model to decide on real values

Some questions cannot be settled by matching at all. **Nothing in a
catalogue is called "gluten"**, so no `LIKE` will ever find it, yet a
person shown a list of product names can tell bread from rice. That is
world knowledge, and the model has it.

So when a literal search has already failed and two or more real columns
are still on the table, the engine reads the columns' **actual distinct
values** and puts them to the model:

```
Concept: gluten free
Question as asked: Which products are gluten free?
Candidate columns and the distinct values they hold:
- products.product_name: 18V Cordless Drill, Heavy Duty Drill, ...
- categories.name: Adjustable Wrenches, Angle Grinders, ...
```

Measured on `gemma3:4b`, the weakest model in the set:

```
gluten free     -> no,  "the column contains names of power tools and does
                         not relate to gluten-free products"
cordless tools  -> yes, "product_name contains 'Cordless Drills', directly
                         indicating cordless tools"
```

The order matters and is deliberate. **The columns are identified first,
the values are read second, and the model is asked last**, so it is
deciding about rows that exist rather than about a sentence. One extra
model call, only on the path that would otherwise have guessed.

### What this step is allowed to do, and what it is not

The bounds matter more than the feature, and they were set by
measurement rather than by intention. An early version let a "no" deny
coverage. On `gemma3:4b` it then denied *"how many loans are still
open?"* against a table whose `status` column holds `borrowed`,
`returned`, `late`, and 16 rows with no `returned_at`. That question is
answerable in one query. A second version let a "no" merely withdraw the
menu, and it withdrew the menu for *"show me the oldest products"*, whose
two options were `products.created_at` and `products.updated_at`, which
are exactly the right two.

So the step is now **monotone**: it can sharpen an answer or add a
remark, and it cannot make a verdict worse.

- **A "no" never denies coverage on its own.** `NOT COVERED` requires a
  successful engine sweep of every eligible column. A failed SQL lookup is
  different from an empty result and stays `NEEDS MORE`. The model may
  explain or overturn that evidence; its opinion alone is never proof of
  absence, because `NOT COVERED` is the verdict a customer repeats to
  management.
- **A "no" cannot touch a column that records a state.** Two shapes count,
  both read from the catalogue rather than judged: a **closed vocabulary**
  (asked for one more value than the ceiling allows and fewer came back)
  and a **moment** (`date`, `datetime`, `timestamp`, `time`, `year`). Those
  are where *"still open"*, *"late"* and *"recently"* actually live. A menu
  built on one of them stands whatever the model thinks, and the model's
  doubt is carried into the reason instead.
- **A "no" on free text withdraws the menu**, which is the case the step
  exists for: answering a question about gluten with
  `products.product_name` is offering a `LIKE` that no row will ever
  satisfy.
- **A "yes" names the offered column that decides** and makes the question
  `ANSWERABLE`. Names are checked case-insensitively and normalised to the
  catalogue; a real but unoffered column is still rejected.
- **Anything else adds no model evidence.** A model that cannot be reached,
  will not decide, or names a column it was not shown cannot create a
  verdict. A successful database sweep may still support its own result;
  a failed sweep never does. Not knowing is never reported as absence.

This is the one place the component trusts a judgement instead of a
match, which is why it is bounded this narrowly.

Three variables tune it, and none of them is a constant in the source:

| Variable | Default | What it does |
| --- | --- | --- |
| `DATAGORA_ASK_VALUES` | `on` | `off` switches the step off entirely. The engine then behaves as it did before, which is also what the test suite does, so the tests never need a model. |
| `DATAGORA_SAMPLE_VALUES` | `30` | How many distinct values are read from a column and shown to the model. |
| `DATAGORA_ENUMERATION` | `12` | How few distinct values a column may hold and still count as a closed vocabulary. Raise it for a schema that spells its states with more of them. |

Both numbers are read at the moment they are used, so a container and a
test get the same answer from the same variable. An empty value counts as
unset, because compose passes a variable it cannot resolve as an empty
string, and anything unreadable or non-positive falls back to the default
rather than silently disabling a check.

## How a question is matched to the database: exact first, meaning only to withhold a denial

Worth being explicit, because the usual guess is a vector search. Every
step that can say yes or no is exact: no embedding model, no vector store,
no similarity threshold decides a verdict. A column index for synonyms,
described at the end of this section, is on whenever a Qdrant and an
embedding model are configured, and it can only withhold a denial. Five
steps, all of them checkable:

1. **The catalogue, read once.** `information_schema.columns` gives the
   real tables, columns and types. This is the only source of truth about
   what exists.
2. **The catalogue goes into the prompt.** `schema_text()` lists every
   table and column, so the model is choosing among names that exist
   rather than recalling names it has seen elsewhere.
3. **Every name the model returns is confirmed.** `has(table, column)`
   checks it against the catalogue, case-insensitively. A column the
   model invented is dropped, not reported. This is why a verdict never
   offers a choice between columns that are not there.
4. **Words, for the one dangerous claim.** Before saying a database holds
   no equivalent of a phrase, `resembles_column()` searches the column
   names for the phrase's own words, longer than three letters and
   singularised. It is what stops "email addresses" being declared absent
   while `members.email` sits in the schema.
5. **Values are looked up in the data, with SQL.** `near_values()` runs
   `SELECT DISTINCT col FROM tbl WHERE col LIKE '%...%'` against the real
   column, and `holds_value()` sweeps the text, char and enum columns to
   find where a literal actually lives. Numeric columns are refused
   outright: a model that mistook a vague phrase for a literal and
   pointed at an id column once turned primary keys into multiple-choice
   options, offering "197, 170 or 317" for "how many products do we
   have".

Why string matching and a `SELECT` rather than embeddings. A verdict of
`NOT COVERED` tells a client their database cannot express something, and
that claim has to be defensible. "This column exists" and "this value
occurs in this column" are facts anyone can re-check in one query. A
cosine distance of 0.83 is not, and no threshold on it can be defended in
a review. It also keeps the deployment to a database and a chat model:
nothing here needs an embedding service.

A word on embeddings, since this is the obvious next question. Steps 1 to
3 must stay exact: a verdict of `NOT COVERED` has to be defensible, and
"this column exists" is a fact a reviewer can re-check in one query while
a cosine distance of 0.83 is not. Steps 4 and 5 are where meaning belongs,
and that is exactly where the two features above put it: a written
description, and the model reading real values. Both keep the evidence
quotable. An embedding over column names and descriptions would be a
reasonable **ranking hint** for step 4, to order candidates before the
exact checks run; it must never become the basis of a denial.

Where embeddings **do** appear today is a different question, in
[`recall.py`](recall.py): which *tables* a new question is probably about,
learned from questions already answered, held in Qdrant with
`nomic-embed-text`. That serves the SQL-writing pipeline and saves a model
call. Coverage never touches it.

The honest limit of step 4 is synonyms. Word matching finds `members.email`
from "email addresses", and will not find it from "how do we reach them".
For that case there is a column index ([recall.py](recall.py),
`ColumnIndex`), **on by default** for a database that has a Qdrant and an
embedding model, and turned off with `DATAGORA_COLUMN_INDEX=off` or the
switch in the settings page's Engine section. It embeds one short text per
column that is not a key, name spelt out, type, description and a few
values, in a collection named `<database>_columns_<fingerprint>`, the
fingerprint covering the tables, columns, types, descriptions and the
embedding model; when any of them changes a new index is built and the old
one dropped. It is built when a database is indexed from the settings page,
or on the first coverage question otherwise. Its only power is to withhold
a denial: a hit is shown as a lead and never makes a question answerable.
Its text holds a few real values of each column, which a deployment should
know before pointing it at a shared Qdrant.

It is on by default because of what it can and cannot do: it can only
prevent a wrong `NOT COVERED`, the verdict that costs a client most, and it
was measured not to let an unrelated phrase through.

Its threshold was measured, not chosen. A raw cosine cannot separate a
phrase that names a column under another word ("storage space" for
`capacity_units`) from a phrase that names nothing the schema holds
("warranty"): on 24 phrases over the two demo schemas the two overlapped
with both nomic-embed-text and multilingual-e5-large. What separates them
is how far the best column stands above the rest of the schema, in
standard deviations: at 3.4, no unrelated phrase passed and 7 (nomic) or
9 (e5) of the 13 related ones did. The bar rises with the number of
columns. `python recall.py --profile X --columns "a phrase"` prints the
numbers on your own schema. The bar is `DATAGORA_COLUMN_MIN_Z`, or "How far
a column must stand out" on the settings page; empty is 3.4.

## What comes back for one question

Every question produces one `Verdict`, whatever happened. Six fields, and
`sentence()` is the only one meant to be shown to a person as it is.

| Field | Type | What it holds |
|---|---|---|
| `question` | `str` | the question as it was asked, unmodified |
| `verdict` | `str` | one of the six constants below |
| `kind` | `str` | the AmbiSQL class behind the verdict: `AmbiSchema`, `AmbiValue`, `AmbiView`, `AmbiSource`, `AmbiContext`, `AmbiFallacy`, `AmbiRef`. Empty for `ANSWERABLE` |
| `missing` | `str` | what a person would have to supply, or why nothing here can express it. Empty for `ANSWERABLE` |
| `choices` | `list[str]` | the readings to choose between, as `table.column`. Only for `NEEDS A CHOICE` |
| `extra` | `dict` | every other column of the input row, carried through untouched |
| `sentence()` | `str` | the same thing as one sentence, phrased for the person who asked |

The six verdicts, with real output from `datagora_generic`:

**`ANSWERABLE`**: nothing is in the way.

```python
Verdict(question="List the warehouses.", verdict="ANSWERABLE",
        kind="", missing="", choices=[], extra={"id": "1"})
# sentence(): "Yes, this can be answered as asked."
```

**`NEEDS A CHOICE`**: answerable today, but the question has more than
one reading in this schema and each one is available. `choices` is the
pick to put to the user. This is a covered question, not a problem.

```python
Verdict(question="Which supplier is the most reliable?",
        verdict="NEEDS A CHOICE", kind="AmbiSchema",
        choices=["suppliers.rating", "suppliers.is_active"], extra={...})
# sentence(): "Yes, but a choice is needed. Choose between:
#              suppliers.rating, suppliers.is_active"
```

**`NEEDS MORE`**: the data is there but the question is short of
something only the asker has, such as a threshold, a unit or a period.
They rephrase and it becomes answerable.

```python
Verdict(question="How many products did we sell recently?",
        verdict="ANSWERABLE", kind="", extra={...})
# "How many" already selects a count; a model-proposed count/sum menu
# does not manufacture an ambiguity.
```

**`NOT COVERED`**: no rephrasing will help, because the database does
not hold the thing at all. This is the only verdict that makes a claim
about the schema, so it is the one held to the highest bar: the clarifier
must have swept the catalogue and the data and found nothing of the kind,
not merely guessed from the wording.

```python
Verdict(question="What is the warranty duration of each product?",
        verdict="NOT COVERED", kind="AmbiValue",
        missing='"warranty duration" has no equivalent in this database. '
                "Nothing here can express it.", extra={...})
# sentence(): the missing text, which is already a complete sentence
```

**`NO DATA`**: the columns that answer it are there, and no row matches.
An empty result is an **answer**, not a gap, and this component exists to
say whether a result is reachable rather than to write the SQL that
fetches it.

It used to be reported as `NOT COVERED`. On the demo library, *"which
books were written by Shakespeare in 2020?"* came back *"Nothing here can
express it"*, while `authors.name` and `books.published_on` both sit in
the schema and answer it in one query. What the database lacks is a row
for Shakespeare.

```python
Verdict(question="Which books were written by Shakespeare in 2020?",
        verdict="NO DATA", kind="AmbiValue",
        missing='This database can ask the question, and no row answers '
                'it: authors.name could hold "Shakespeare" and none does. '
                'The result is empty.', extra={...})
```

The line between this and `NOT COVERED` is **whether a column of the
right kind exists at all**, and both sides rest on one query you can
repeat:

| | `NO DATA` | `NOT COVERED` |
| --- | --- | --- |
| "Shakespeare" | `authors.name` is a text column and could hold it | |
| "Paris", against a `members` table with no place column | | nothing in the schema could hold it |

Two consequences worth planning for:

- **Count it as covered.** It is in `FINAL_VERDICTS`, so a resumed run
  does not re-ask it and a batch does not fail on it.
- **A benchmark should isolate it.** A question whose correct answer is
  the empty set cannot be scored the same way as one the schema cannot
  reach. Filtering on this verdict is how you keep those out of a test
  set deliberately rather than by accident, which is a known trap in
  text-to-SQL suites.

### Why the line between those two is drawn where it is

This is the distinction a coverage report is bought for, and getting it
backwards is expensive in both directions. `NEEDS MORE` costs somebody a
rephrasing. `NOT COVERED` tells a client their data cannot answer a
question, which they will repeat to their own management.

So a denial may only rest on a sweep that **could** have found the thing.
A phrase that is a judgement rather than a value can never be found: no
schema stores "nearly full", it stores a capacity; none stores "cheap", it
stores a price. Sweeping the data for one of those returns nothing
whatever the schema holds, so an absence proved that way proves nothing.
Those phrases are recognised word by word, not as whole strings, because
a model returns "what constitutes 'cheap'" and "expensive in what sense?"
at least as often as the bare adjective.

Measured on a battery of eleven questions, half of them thresholds over
columns that exist and half genuinely absent attributes: **6/11 before
this rule, 10/11 after**. Five questions moved from `NOT COVERED` to
`NEEDS MORE` and nothing that was already right changed.

| Question | Verdict | Because |
|---|---|---|
| Which warehouses are nearly full? | `NEEDS MORE` | `capacity` exists; the threshold does not |
| Which products are cheap? | `NEEDS MORE` | `unit_price` exists; "cheap" is theirs to define |
| What is the warranty duration of each product? | `NOT COVERED` | nothing in the schema expresses a warranty |
| Which products are gluten free? | `NOT COVERED` | no allergen anywhere |

The eleventh is worth knowing about because no classification rule can
reach it: "what is the blood type of our suppliers" comes back
`ANSWERABLE`, because the reasoner does not flag the question at all and
the question never reaches this code. That is a detection miss belonging
to the model on the `reasoner` role, and it is one of the cases a larger
reasoner is expected to fix.

**`UNKNOWN`**: nothing was decided. A model that did not answer, a
database that refused the connection. **This is not a negative verdict
and must never be reported as one**: it says something about your
infrastructure, not about the client's data. `missing` holds the reason.

```python
Verdict(question="List the warehouses.", verdict="UNKNOWN", kind="",
        missing="http://model-host:8000 did not answer: "
                "[Errno 11001] getaddrinfo failed", extra={"id": "5"})
# sentence(): "Could not tell: http://model-host:8000 did not answer ..."
```

Import the constants rather than matching the strings, since the wording
is chosen for a reader and the constants are the contract:

```python
from graph_lab import (ANSWERABLE, NEEDS_CHOICE, NEEDS_MORE, NO_DATA,
                       NOT_COVERED, UNKNOWN)

covered = [v for v in verdicts if v.verdict in (ANSWERABLE, NEEDS_CHOICE)]
ask_again = [v for v in verdicts if v.verdict == NEEDS_MORE]
empty = [v for v in verdicts if v.verdict == NO_DATA]      # askable, no row today
absent = [v for v in verdicts if v.verdict == NOT_COVERED]
retry = [v for v in verdicts if v.verdict == UNKNOWN]      # your problem
```

### The same verdict as a CSV row

`row_for(verdict)` is what the ledger and the page's export write. The
input columns come first, in alphabetical order with the question last, so
each verdict sits next to the row it came from:

```
id,theme,question,verdict,kind,answer_to_give,choices
2,stock,Which supplier is the most reliable?,NEEDS A CHOICE,AmbiSchema,"Yes, but a choice is needed. Choose between: suppliers.rating, suppliers.is_active",suppliers.rating | suppliers.is_active
```

`answer_to_give` is `sentence()`. `choices` is the list joined with
` | `, because a CSV cell cannot hold a list and a comma would be read as
a new column. `kind` is deliberately blank on an `ANSWERABLE` row: a
classification of an ambiguity means nothing beside a question that had
none.

An application that owns its database and model configuration does not
need `profiles.json` or `models.json`:

```python
report = assess_file(
    "questions.csv",
    "coverage_results.csv",
    connect=pool.getconn,             # returns a DB-API connection
    schema="sales",
    llm=my_model,                     # callable or object; contract below
    on_each=progress,
)
```

The complete runnable sample ships in
`src/graph_lab/examples/coverage_library.py`. After installing the wheel:

```powershell
python -m graph_lab.examples.coverage_library
```

It uses `questions_library.csv`, writes `coverage_results.csv`, and resumes
that file on the next run. `DATAGORA_PROFILE`, `DATAGORA_ENDPOINT`,
`DATAGORA_QUESTIONS` and `DATAGORA_COVERAGE_OUT` override its defaults.

### Public coverage imports

| Import | Purpose |
|---|---|
| `assess_file` | File-to-file incremental batch with automatic resume |
| `assess_coverage` | In-memory iterable of questions to verdict objects |
| `BatchReport` | Counts and completion status returned by `assess_file` |
| `CoverageVerdict` | One question, verdict, choices and carried metadata |
| `job_id` | The short id a question list resumes under |
| `read_questions` | Read a CSV or one-question-per-line file |
| `read_questions_from_text` | Same parser for text already in memory |
| `write_verdicts` | Atomically replace a CSV from verdict objects |
| `ANSWERABLE`, `NEEDS_CHOICE`, `NEEDS_MORE`, `NOT_COVERED`, `UNKNOWN` | Stable verdict constants |

For questions already held in memory, use the lower-level function:

```python
from graph_lab import assess_coverage

verdicts = assess_coverage(
    [{"ticket": "A-17", "question": "the best products"}],
    connect=pool.getconn, schema="sales", llm=my_model,
)
```

Every input key other than `question` is preserved in `verdict.extra` and
carried back into exported CSV rows.

For a configured installation, the equivalent command is:

```powershell
datagora-coverage --profile datagora_lib `
  --questions questions.csv --out coverage_results.csv
```

## The whole surface

```python
from graph_lab import Datagora

dg = Datagora(
    mysql=dict(host="db.internal", port=3306, database="sales",
               user="readonly", password=os.environ["DB_PASSWORD"]),
)

out = dg.ask("how many orders per city last month")

if out.waiting:                       # the question was ambiguous
    print(out.clarification)          # the question to put to the user
    for o in out.options:
        print(o.means)                # what to show; o.label is internal
    out = dg.ask(out.question, choice=out.options[0].label)

print(out.answer)                     # plain words
print(out.sql, out.rows)              # the trail, if you want it
```

`ask` returns one of four things and never a silent guess: an answer, a
clarification to put to the user, a stated gap when the data cannot
express the question, or an error when a model did not reply. The last
one is deliberately distinct: a pipeline that reports "no ambiguity"
because its model timed out is lying to itself.

## Credentials

Passed in, never read from a file, so an application that already has a
secret manager keeps using it:

```python
dg = Datagora(
    mysql=dict(host=..., port=3306, database=..., user=..., password=...),
    neo4j_uri="bolt://graph.internal:7687",        # optional
    neo4j_password=os.environ["NEO4J_PASSWORD"],   # optional
    qdrant_url="http://vectors.internal:6333",     # optional
    embed_url="http://models.internal:11434",      # optional, with Qdrant
    embed_model="nomic-embed-text",                # optional, with Qdrant
)
```

Qdrant holds the corpus of questions already answered and the column
index; `qdrant_collection` names the corpus when it is not the default
`<database>_corpus`. Its key, when the deployment requires one, is read
from `QDRANT_API_KEY`. The Qdrant client is an extra of the package:
`pip install "datagora-graph-lab[qdrant]"`. Without Qdrant the client works
as it does on a database with no corpus. `graph_lab/examples/try_one_question.py` shows
both: the fewest parameters, and every one of them.

Nothing writes. Every statement runs inside a transaction that is rolled
back, so a query that slipped through and tried to write leaves no
trace.

## Do you need Neo4j? No, and here is what changes

| | without Neo4j | with Neo4j |
|---|---|---|
| clarification, grounded in the real schema and values | yes | yes |
| dialect check, the silent SQLite habits | yes | yes |
| EXPLAIN dry-run, cartesian products | yes | yes |
| read-only execution, rolled back | yes | yes |
| answer in plain words | yes | yes |
| **joins imposed from the schema** | no | yes |
| **join audit, fan and chasm rejected before execution** | no | yes |

Without a graph the engine degrades rather than refusing to start, and
every run says plainly that joins were not verified. An absent graph
never causes a rejection, only a stated gap. Adopt it with one
connection string, add the graph when you want the guarantee:

```python
dg.build_graph()     # reads information_schema, writes the graph
```

Idempotent, and it preserves any `weight` or `meaning` a human curated,
so running it again after a migration costs nothing.

## Choosing the models

Two roles, because they are different jobs. The `reasoner` talks to the
user: it spots ambiguity, writes the question a human reads, and turns
rows back into a sentence. The `sql` role writes the query and nothing
else. Arctic-Text2SQL-R1 was reinforcement-trained on a single reward,
the execution correctness of SQL, so it is the specialist for the second
and a poor choice for the first.

In code:

```python
dg = Datagora(mysql=..., reasoner="server-gemma", sql="jarvis-arctic")
```

Or globally, in `models.json`, switchable in one command:

```
python -m graph_lab.llm                                  show and probe
python -m graph_lab.llm --set sql=jarvis-arctic
python -m graph_lab.llm --set reasoner=server-gemma sql=server-arctic
```

Or per run, without touching anything: `DATAGORA_LLM_REASONER`,
`DATAGORA_LLM_SQL`.

vLLM speaks the OpenAI API, so a JARVIS endpoint needs only its host and
its served model name filled into the `jarvis-arctic` entry.

## With LangGraph

`ask` runs the whole journey in one call, which is right for a script
and wrong for an application that already owns its control flow. The
same stages are available separately, as plain functions of a state
dict, importing nothing from LangGraph:

```python
from graph_lab.langgraph_nodes import (nodes_for, should_clarify, after_anchors,
                                       after_check, after_execute)

n = nodes_for(dg)
g = StateGraph(dict)
for name, fn in n.items():
    g.add_node(name, fn)

g.set_entry_point("clarify")
g.add_conditional_edges("clarify", should_clarify,
                        {"ask_user": END, "continue": "anchors", "give_up": END})
g.add_conditional_edges("anchors", after_anchors,
                        {"continue": "generate", "give_up": END})
g.add_edge("generate", "check")
g.add_conditional_edges("check", after_check,
                        {"retry": "generate", "run": "execute", "give_up": END})
g.add_conditional_edges("execute", after_execute,
                        {"answer": "answer", "retry": "generate", "give_up": END})
g.add_edge("answer", END)
```

Every edge function's every return value is mapped: `should_clarify`
gives up when the judge could not run, `after_anchors` when no table
matches, and `after_execute` sends a statement the database refused back
to the generator, like a rejected check. The clarify node runs the
pipeline's own first step (`Pipeline.prepare` and `Pipeline.judge_stage`),
so the graph and `Datagora.ask` cannot judge a question differently;
`context` and `earlier` in the state carry who asks and what was decided
before, as `ask` takes them.

The interrupt point is `should_clarify` returning `ask_user`, which is
where a human answers. A rejection is not a failure: the verdict travels
in the state and lands in the next generation's prompt, which is why the
generator never has to be trusted, only checked.

Every state value is a string, a list or a dict, so a checkpointer can
serialise it and a trace can show it.

## Judging SQL you already have

```python
problems = dg.check_sql(some_query)     # nothing runs
```

Returns the verdicts: dialect ambiguity, a join with no edge, wrong
keys, a fan or a chasm trap. Useful on a query somebody else generated.

## Taking one piece into a system that already has its own

This is the case that matters most: a team with their own Qdrant, their
own Neo4j, their own model client and their own pipeline, who want one of
these steps and not the rest. Nothing below reads `profiles.json`,
`models.json`, Neo4j or Qdrant.

### The clarifier, on your connection and your model

```python
from graph_lab.ambisql import Clarifier

clar = Clarifier.for_connection(
    connect=lambda: your_pool.getconn(),   # any DB-API connection
    schema="sales",
    llm=your_model)                        # see below

out = clar.clarify("which supplier is the most reliable")
out.action      # ANSWER, CLARIFY, GUIDE or ERROR
out.kind        # AmbiSchema, AmbiValue, AmbiView, ...
out.question    # the question to put to a person
out.options     # real columns, confirmed against your catalogue
```

`connect` is called whenever a connection is needed and closed
afterwards, so a pool, a factory or a plain connect function all work.

`llm` is anything you already have. A function is enough:

```python
def your_model(system, user):
    """Return text or a dict. Called with two strings."""
    return your_client.chat(system=system, user=user)
```

An object exposing `json(system, user)` and `chat(system, user)` is
accepted as it is, which covers our `LLM` and most wrappers.

### Import and runtime cost

The wheel installs the engine dependencies declared in `pyproject.toml`.
Importing a symbol does not connect to MySQL, Neo4j, Qdrant, an LLM or
Langfuse; those connections remain lazy until the corresponding function is
called. The narrow imports are still useful because they make the adopted
contract explicit:

| Import | Intended contract |
|---|---|
| `from graph_lab.ambisql import Clarifier` | Clarification only |
| `from graph_lab.api import is_ambiguous, check_sql` | Individual stateless steps |
| `from graph_lab import assess_file` | Resumable coverage batch |
| `from graph_lab import Datagora` | Complete question-to-answer engine |

### Judging SQL your own pipeline wrote

```python
from graph_lab.api import check_sql

for verdict, why in check_sql(their_sql, db=YOUR_CREDENTIALS, graph=False):
    print(verdict, why)
```

`graph=False` skips the join and trap audits, which are the two that
need Neo4j. The dialect lint, the literal audit and `EXPLAIN` still run,
and those three need only a connection. Start there, and turn the graph
on when you want the join guarantee too.

### Which model for which role

Bigger is not better here, and we measured it rather than assuming.
On the same thirteen cases, `gemma3:4b` scored 11 and `llama3.1:8b`
scored 3. The larger model treats nearly every question as ambiguous and
asks instead of answering, which is the failure mode that makes a
clarifier unusable. Fit for the role beats size: the reasoner needs to
follow an instruction and return JSON, the SQL specialist needs to write
SQL that executes.

### What changing the model actually buys, measured

Three swaps, same cases, same databases, one variable at a time.

| Swap | Before | After |
|---|---|---|
| reasoner: gemma3:4b to llama3.1:8b | 11 / 13 | **3 / 13** |
| sql: gemma3:4b to llama3.1:8b | 7 / 11 | **6 / 11**, and five times slower |
| reasoner: gemma3:4b to the 31B, phrasing step only | wrong figures | correct, checked row by row |

Two generalist swaps, both neutral or worse. The larger reasoner treats
nearly every question as ambiguous; the larger SQL model is no better at
SQL and takes 70 seconds instead of 13.

The one swap that paid was a *specialist* doing the job it was trained
for. That is the whole reason `roles` has two entries rather than one: a
model reinforcement-trained on whether its SQL executes correctly is the
right occupant of the `sql` seat, and it is the swap still worth making.
Reaching for a bigger generalist is not.
## Is this installation sound?

```
datagora-audit           models, databases, graphs, gates
datagora-audit --deep    plus one real question per database
```

It reports facts and names the command that fixes each gap. Exit code 0
when everything essential is in place, so it can gate a deployment.

## Does it work on our schema?

That question has a test rather than an opinion:

```
.venv\Scripts\python src\graph_lab\test_reusable.py
.venv\Scripts\python src\graph_lab\test_integration.py
.venv\Scripts\python src\graph_lab\test_pipeline_batch.py
.venv\Scripts\python src\graph_lab\test_ambisql.py
```

Add your database to `profiles.json` and `test_reusable.py` covers it
too. The engine names no table anywhere, and that is enforced on every
run rather than believed.
