# pipeline-reqa-sql

Local Text-to-SQL Agent — query any relational database in natural language.  
100% local, zero data leaves your machine.

---

## Pipeline Architecture

```text
User Query (natural language)
        │
        ▼
┌───────────────────┐
│  1. Embedding     │  ← local fastembed (nomic-ai/nomic-embed-text-v1.5, CPU)
└────────┬──────────┘
         │ vector
         ▼
┌───────────────────┐    ┌─────────────────────────────┐
│  2. Schema RAG    │◄───│  Qdrant (local Vector DB)   │
│  (top-k tables)   │    │  + full table list           │
└────────┬──────────┘    └─────────────────────────────┘
         │ contextualized schema
         ▼
┌───────────────────┐
│  3. SQL Generator │  ← LLM (Ollama/Mistral, 100% local)
│     (LLM #1)      │    generates SQL from question + schema
└────────┬──────────┘
         │ raw SQL
         ▼
┌───────────────────┐
│  4. Static Check  │  ← sqlglot (MariaDB syntax + SELECT-only)
│   (sqlglot)       │    if invalid → retry to SQL Generator (max 3x)
└────────┬──────────┘
         │ valid SQL
         ▼
┌───────────────────┐
│  5. EXPLAIN       │  ← MariaDB EXPLAIN (dry-run, zero data read)
│   (dry-run)       │    if failure → Circuit Breaker → Graceful Failure
└────────┬──────────┘
         │ plan OK
         ▼
┌───────────────────┐    ┌──────────────────┐
│  6. DB Execution  │◄───│  MariaDB 11.4    │
│                   │    │  (local SQL DB)  │
└────────┬──────────┘    └──────────────────┘
         │ raw results (rows)
         ▼
┌───────────────────┐
│  7. Renderer      │  ← LLM (Ollama/Mistral, same model)
│     (LLM #2)      │    formats results into a natural language response
└────────┬──────────┘
         │
         ▼
   Final Response

─────────────────────────────
Circuit Breaker (cross-cutting)
  → opens after 3 consecutive failures (EXPLAIN or Execution)
  → Graceful Failure: clear message to the user
─────────────────────────────
```

---

## Tech Stack

| Component       | Technology                          | Role                             |
|-----------------|-------------------------------------|----------------------------------|
| SQL LLM         | Ollama + Codestral                  | SQL generation (specialized)     |
| Render LLM      | Ollama + Mistral 7B                 | Natural language response        |
| Vector DB       | Qdrant v1.12                        | Semantic schema search           |
| Embeddings      | fastembed / BAAI/bge-small-en-v1.5  | Local vectorization (CPU)        |
| Database        | MariaDB 11.4                        | Data source                      |
| SQL validation  | sqlglot                             | Static syntax validation         |
| API             | FastAPI + uvicorn                   | REST interface                   |

---

## Quick Start

### 1. Disable native Ollama (if installed)

If Ollama is running on your machine, it occupies port `11434` — stop it before launching Docker:

```bash
sudo systemctl stop ollama
sudo systemctl disable ollama
```

### 2. Start all services

```bash
docker compose up -d
```

Docker automatically handles:
- installing Python dependencies (`pip install`)
- setting up the environment (`.env.example` used directly)
- downloading `codestral` and `mistral` into Ollama (first start only)

Verify everything is running:

```bash
docker compose ps
```

### 3. Ingest your database schema

```bash
# With the provided test schema:
docker compose run --rm ingest example.sql

# Or with your own schema:
docker compose run --rm ingest /app/my-schema.sql
```

### 4. Query the database

```bash
curl -X POST http://localhost:8080/query \
  -H "Content-Type: application/json" \
  -d '{"question": "Which products are below the reorder threshold?"}'
```

### 5. Check agent health

```bash
curl http://localhost:8080/health
```

---

## Switching LLM Models

The pipeline is designed to be **LLM-agnostic**. All implementations inherit from `agent/llm/base.py`.

### Ollama (local, default)

```env
LLM_PROVIDER=ollama
OLLAMA_MODEL=mistral        # or codestral, phi4, codellama:7b, llama3.1:8b
OLLAMA_BASE_URL=http://ollama:11434
```

### OpenAI-compatible API (Mistral API, LM Studio, Groq…)

```env
LLM_PROVIDER=openai_compat
OPENAI_COMPAT_BASE_URL=https://api.mistral.ai/v1
OPENAI_COMPAT_API_KEY=your-key
OPENAI_COMPAT_MODEL=mistral-small-latest
```

### Plugging in a new LLM

```python
# agent/llm/my_llm.py
from agent.llm.base import BaseLLM

class MyLLM(BaseLLM):
    def complete(self, system: str, messages: list[dict], max_tokens: int = 1024) -> str:
        # your implementation here
        ...
```

Then in `api.py`, add the branch in `_build_llm()`.

---

## Project Structure

```text
pipeline-reqa-sql/
├── docker-compose.yml     # MariaDB + Qdrant + Ollama
├── .env.example           # Configuration template
├── requirements.txt
├── config.py              # Environment variable reader
├── ingest.py              # SQL schema ingestion → Qdrant
├── api.py                 # FastAPI (POST /query, GET /health)
└── agent/
    ├── llm/
    │   ├── base.py            # Abstract BaseLLM interface
    │   ├── ollama_llm.py      # Ollama implementation
    │   └── openai_compat.py   # OpenAI-compatible implementation
    ├── circuit_breaker.py     # Circuit breaker (opens after N failures)
    ├── embedder.py            # Local embedding model (fastembed)
    ├── schema_rag.py          # Semantic search in Qdrant
    ├── sql_generator.py       # SQL generation via LLM
    ├── static_check.py        # sqlglot syntax validation
    ├── dry_run.py             # MariaDB EXPLAIN (dry-run)
    ├── executor.py            # Actual MariaDB execution
    ├── renderer.py            # Natural language rendering via LLM
    └── pipeline.py            # Main orchestrator
```

---

## API Response

```json
{
  "success": true,
  "answer": "3 products are below the reorder threshold...",
  "sql": "SELECT p.sku, p.product_name, i.quantity_on_hand, i.reorder_level FROM inventory i JOIN products p ON i.product_id = p.product_id WHERE i.quantity_on_hand <= i.reorder_level LIMIT 100;",
  "row_count": 3,
  "attempts": 1,
  "error": ""
}
```

---

## Recommended LLM Models (open, commercial, NATO countries)

All models below run **100% locally** via Ollama — no data leaves your machine.

| Model                   | Organization | Country | RAM    | SQL Quality | Notes                        |
|-------------------------|--------------|---------|--------|-------------|------------------------------|
| `mistral:7b`            | Mistral AI   | France  | ~5 GB  | ★★★★☆      | Default configured           |
| `llama3.1:8b`           | Meta         | USA     | ~6 GB  | ★★★★★      | Great all-rounder            |
| `codellama:7b`          | Meta         | USA     | ~4 GB  | ★★★★☆      | Specialized for code/SQL     |
| `phi4:14b`              | Microsoft    | USA     | ~9 GB  | ★★★★★      | More powerful, heavier       |
| `codestral`             | Mistral AI   | France  | ~9 GB  | ★★★★★      | Specialized for code/SQL     |

> **Text-to-SQL recommendation:** `codestral` (specialized) or `phi4:14b` (high-performance all-rounder).

```bash
ollama pull mistral                 # default
ollama pull codestral               # best for text-to-SQL
ollama pull phi4                    # best general quality
ollama pull codellama:7b            # alternative for code
ollama pull llama3.1:8b             # general-purpose
```
