docker compose up -d ingest --force-recreate && docker logs reqa-ingest -f 
