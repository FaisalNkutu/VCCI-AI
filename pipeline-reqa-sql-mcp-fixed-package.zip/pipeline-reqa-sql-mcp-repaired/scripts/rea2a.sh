
docker compose up -d a2a --force-recreate && docker logs reqa-a2a -f 
