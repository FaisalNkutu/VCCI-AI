
#!/bin/bash 
python a2a_nl2sql_client.py --ingest --INGEST_OPTIONS="--no-tables --kb RAG/KB_production_rezwan.json --verbose --reindex" --ingest-file RAG\rated_rules_AOC.csv