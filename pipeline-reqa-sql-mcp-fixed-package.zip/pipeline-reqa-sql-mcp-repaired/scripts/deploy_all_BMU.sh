rm -rf __pycache__ rm  */__pycache__ */*/__pycache__ */*/*/__pycache__ */*/*/*/__pycache__
cp -rf RAG/*  /t/pipeline-reqa-sql-mcp/RAG/
#cp -rf langfuse  /t/pipeline-reqa-sql-mcp/


# JP Caron 2026/06/22
#
# Very specific Script to deploy the git working folder from local git working copy
# to a BMU Linux Machine
#


rm __pycache__ -rf
rm */*__pycache__ -rf
rm */*/*__pycache__ -rf


cp -rf *.yml *.py Dockerfile* RAG_KB_CHANGES_DETAIL.md agent/ agents/ a2a_common attributes.csv \
	config/ docker/ export/ mcp_servers/ qdrant_schema_report.html \
	requirements*.txt /t/pipeline-reqa-sql-mcp

cp -rf config  /t/pipeline-reqa-sql-mcp/
cp -rf RAG/*.py /t/pipeline-reqa-sql-mcp/RAG/
cp -rf neo4j/neo4j-server/*.py /t/pipeline-reqa-sql-mcp/neo4j/neo4j-server/
cp -rf Testing  /t/pipeline-reqa-sql-mcp/
cp -rf RAG/*.py  /t/pipeline-reqa-sql-mcp/RAG
cp -rf query_analysis /t/pipeline-reqa-sql-mcp/
cp -rf ambisql /t/pipeline-reqa-sql-mcp/

dos2unix /t/pipeline-reqa-sql-mcp/docker/ollama/entrypoint.sh

# Not practical in windowes for now ...
#rsync -av  --exclude ".git/" --src=./ --dest=T:\\pipeline-reqa-sql-mcp


