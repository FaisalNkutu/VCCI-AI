# Execution Guide — pipeline-reqa-sql

Architecture: **Multi-agent (5 agents) + MCP (2 servers)** + FastAPI API (v1 pipeline / v2 multi-agent)

---

## Prerequisites

| Tool | Minimum Version | Role |
|---|---|---|
| Docker + Docker Compose | 24+ | MariaDB, Qdrant |
| Python | 3.10+ | API + agents |
| Ollama | latest | Local LLMs |
| pip | 23+ | Python dependencies |

---

## Step 1 — Clone and install dependencies

```bash
cd pipeline-reqa-sql
pip install -r requirements.txt


## Step 2 — Start Docker infrastructure

docker compose up -d mariadb qdrant

Check that services are healthy:

docker compose ps

Expected output:

NAME           STATUS
reqa-mariadb   Up (healthy)
reqa-qdrant    Up (healthy)

Ports exposed:

MariaDB: localhost:3306
Qdrant: localhost:6333


## Step 3 — Download Ollama models

ollama pull codestral   # SQL generation (~9 GB)
ollama pull mistral     # Natural language rendering (~5 GB)

Lightweight alternatives:

ollama pull codellama:7b
ollama pull phi4

Update .env if needed:

OLLAMA_SQL_MODEL=codellama:7b
OLLAMA_MODEL=phi4

Check models:

ollama list


## Step 4 — Configure environment variables


LLM_PROVIDER=ollama
OLLAMA_BASE_URL=http://ollama:11434
OLLAMA_SQL_MODEL=codestral:latest
OLLAMA_MODEL=mistral:latest

DB_HOST=localhost
DB_PORT=3306
DB_NAME=example_db
DB_USER=example_user
DB_PASSWORD=test

QDRANT_HOST=localhost
QDRANT_PORT=6333
QDRANT_COLLECTION=schema


MAX_SQL_RETRIES=3
CB_THRESHOLD=3
TOP_K_TABLES=10  
MAX_ROWS=100  


## Step 5 — Ingest SQL schema into Qdrant
python3 ingest.py example.sql
python3 ingest.py path/to/my-schema.sql

Expected output:

[ingest] Parsed all 259 tables
[ingest] Loading embedding model...
[ingest] Qdrant collection 'schema' ready.
[ingest] ✓ 259 tablea schemas ingested into Qdrant.

Verify:

curl http://localhost:6333/collections/schema


## Step 6 — Start the API
uvicorn api:app --reload --port 8080

Swagger:

http://localhost:8080/docs


## Step 7 — Test endpoints

Health check
curl http://localhost:8080/health
v1 — Pipeline (mono-agent)
curl -X POST http://localhost:8080/query \
  -H "Content-Type: application/json" \
  -d '{"question": "Which products are below the reorder threshold?"}'
v2 — Multi-agent + MCP
curl -X POST http://localhost:8080/v2/query \
  -H "Content-Type: application/json" \
  -d '{"question": "Which products are below the reorder threshold?"}'
A2A — Agent-to-Agent
Discover agent
curl http://localhost:8080/.well-known/agent.json
Send task v1
curl -X POST http://localhost:8080/tasks/send \
  -H "Content-Type: application/json" \
  -d '{
    "id": "task-001",
    "message": {
      "role": "user",
      "parts": [{"type": "text", "text": "Who are the top 5 customers by revenue?"}]
    }
  }'
Send task v2
curl -X POST http://localhost:8082/v2/tasks/send \
  -H "Content-Type: application/json" \
  -d '{
    "id": "task-002",
    "message": {
      "role": "user",
      "parts": [{"type": "text", "text": "How many orders were placed last month?"}]
    }
  }'


## Step 8 — Streamlit UI

Start UI:

streamlit run app.py

Open:

http://localhost:8501

Features:

Switch v1 / v2 mode
Example questions
Live API status
SQL display
Agent trace (v2)
Metrics
History
Step 9 — Docker full deployment (optional)
docker compose build api
docker compose up -d

API:

http://localhost:8081

Logs:

docker compose logs -f api
Troubleshooting
Qdrant empty
python3 ingest.py example.sql
Ollama missing model
ollama pull mistral
MariaDB issue
docker compose up -d mariadb
Port conflict
uvicorn api:app --reload --port 8082
Summary
docker compose up -d mariadb qdrant
ollama pull codestral && ollama pull mistral
pip install -r requirements.txt
python3 ingest.py example.sql
uvicorn api:app --reload --port 8080
streamlit run app.py
Architecture
Ollama → SQL + Rendering models
Qdrant → Schema embeddings
MariaDB → Execution layer
FastAPI → API layer (v1 / v2 / A2A)
Streamlit → UI layer