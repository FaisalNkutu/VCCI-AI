cp -rf RAG/*  /t/pipeline-reqa-sql-mcp/RAG/

