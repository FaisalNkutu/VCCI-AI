# Intégration du KB RAG dans le pipeline REQA-SQL

## Vue d'ensemble

Le dossier `rag/` a été créé et branché sur le pipeline existant pour enrichir la recherche vectorielle et le contexte envoyé au LLM avec des métadonnées métier (descriptions, valeurs autorisées, domaines fonctionnels).

---

## Fichiers créés

### `rag/__init__.py`
Fichier vide — marque le dossier comme package Python.

---

### `rag/schema_knowledge.json`
Source de vérité unique du KB — contient les métadonnées métier des **7 tables** du schéma ecommerce.

**Structure par table :**
```json
{
  "nom_table": {
    "table_description": "Description lisible de la table",
    "domain": "Catalogue | Logistique | Approvisionnement",
    "columns": {
      "nom_colonne": {
        "description": "Rôle de la colonne",
        "allowed_values": ["val1", "val2"],
        "example_values": [1, 10, 500],
        "notes": "Contrainte ou règle métier"
      }
    },
    "referenced_by": ["autre_table.fk_col"],
    "sample_queries": ["Question exemple en langage naturel"]
  }
}
```

**Tables documentées et domaines :**

| Table | Domain | Points clés du KB |
|---|---|---|
| `categories` | Catalogue | Auto-référence `parent_category_id`, `is_active` |
| `suppliers` | Approvisionnement | `country_code` (13 valeurs), `rating` 0–5 |
| `warehouses` | Logistique | Format code `WH-XXX-NN`, capacités |
| `products` | Catalogue | `status` (`draft`/`active`/`archived`), formule prix remisé |
| `product_suppliers` | Approvisionnement | `is_preferred`, `lead_time_days` |
| `inventory` | Logistique | Stock critique = `quantity_on_hand <= reorder_level` |
| `inventory_movements` | Logistique | `movement_type` (`IN`/`OUT`/`ADJUSTMENT`) |

---

### `rag/knowledge_base.py`
Module de chargement et de formatage du KB. Fonctions publiques :

| Fonction | Rôle |
|---|---|
| `load_kb()` | Charge et met en cache le JSON |
| `get_table_kb(table)` | Retourne l'entrée KB d'une table |
| `get_column_kb(table, column)` | Retourne l'entrée KB d'une colonne |
| `table_embedding_tokens(table, ddl_description)` | Texte riche utilisé pour l'embedding Qdrant |
| `build_ddl_with_kb(table, columns, foreign_keys)` | DDL commenté avec inline KB pour le prompt LLM |
| `extract_business_rules(table)` | Liste des règles `col ∈ {val1, val2}` |
| `column_inline_comment(col_entry)` | Formate un commentaire inline pour une colonne |

---

## Fichiers modifiés

### `ingest.py`

**Changements :**

1. **Import** ajouté :
   ```python
   from rag.knowledge_base import table_embedding_tokens, get_table_kb
   ```

2. **Parser `parse_sql_to_documents()`** — extrait maintenant des données structurées en plus du texte DDL :
   - `columns` : liste de `{name, type, nullable}` pour chaque colonne
   - `foreign_keys` : liste de strings `"col → parent_table.parent_col"`
   - `domain` : domaine fonctionnel lu depuis le KB
   - `column_knowledge` : métadonnées colonnes du KB

3. **Payload Qdrant enrichi** — avant vs après :

   ```python
   # Avant
   {"table": "products", "description": "Table: products\nColumns:\n  - status ENUM ..."}

   # Après
   {
     "table": "products",
     "description": "Table: products\nColumns: ...",   # conservé
     "domain": "Catalogue",
     "columns": [{"name": "status", "type": "ENUM", "nullable": "NO"}, ...],
     "foreign_keys": ["category_id → categories.category_id"],
     "column_knowledge": {"status": {"allowed_values": ["draft","active","archived"], ...}}
   }
   ```

4. **Embedding** — utilise le texte KB enrichi au lieu du DDL brut :
   ```python
   # Avant
   vector = embedder.embed(doc["description"])

   # Après
   embedding_text = table_embedding_tokens(doc["table"], doc["description"])
   vector = embedder.embed(embedding_text)
   ```
   Le vecteur encode maintenant : domain + descriptions colonnes + valeurs autorisées + sample queries.

> **Action requise** : relancer `python ingest.py example.sql` pour réindexer avec les nouveaux vecteurs KB.

---

### `agent/schema_rag.py`

**Changements :**

1. **Import** ajouté :
   ```python
   from rag.knowledge_base import build_ddl_with_kb, extract_business_rules
   ```

2. **Nouvelle méthode `build_schema_context(payloads)`** :
   - Génère un bloc DDL par table avec commentaires KB inline
   - Ajoute une section `-- Business Rules` listant toutes les valeurs autorisées
   - Remplace l'ancien join brut de descriptions

   **Exemple de sortie** pour `products` :
   ```sql
   -- [Catalogue] products
   -- Description: Catalogue principal des produits …
   -- Referenced by: inventory.product_id, product_suppliers.product_id
   CREATE TABLE products (
       status  ENUM NOT NULL  -- Statut commercial. Allowed: draft|active|archived.
       price   DECIMAL(10,2) NOT NULL  -- Prix brut. (Prix net = price * (1 - discount_percent/100))
       discount_percent TINYINT NOT NULL  -- Remise en %. e.g. "0", "5", "10".
       -- Foreign keys:
       --   category_id → categories.category_id
   );

   -- Business Rules:
   -- products.status ∈ {'draft', 'active', 'archived'}
   -- inventory_movements.movement_type ∈ {'IN', 'OUT', 'ADJUSTMENT'}
   ```

---

### `agent/pipeline.py`

**Changement :** une ligne remplacée dans `run()` :

```python
# Avant
schema_context = "\n\n".join(c.get("description", "") for c in schema_chunks)

# Après
schema_context = self.schema_rag.build_schema_context(schema_chunks)
```

---

## Flux de données après intégration

```
                    rag/schema_knowledge.json
                            │
            ┌───────────────┼───────────────┐
            ▼               ▼               ▼
       [ingest.py]   [schema_rag.py]  [sql_generator.py]
  table_embedding_     build_schema_     reçoit le DDL
  tokens() → vecteur   context() →      commenté + rules
  KB enrichi dans      DDL + Business    dans son prompt
  Qdrant               Rules

User Query
   │
   ▼
[SchemaRAG.retrieve()]  ──embed query──►  Qdrant (vecteurs KB)
   │                                          │ top-k payloads enrichis
   ▼                                          │
[build_schema_context()] ◄────────────────────┘
   │  DDL commenté + business rules
   ▼
[SQLGenerator.generate()]
   │  SQL MariaDB correct
   ▼
[StaticCheck → DryRun → Executor → Renderer]
   │
   ▼
Réponse finale
```

---

## Checklist d'intégration

- [x] `rag/__init__.py` créé
- [x] `rag/schema_knowledge.json` créé (7 tables documentées)
- [x] `rag/knowledge_base.py` créé (loaders + helpers)
- [x] `ingest.py` — embedding KB-enrichi + payload structuré
- [x] `agent/schema_rag.py` — méthode `build_schema_context()`
- [x] `agent/pipeline.py` — utilise `build_schema_context()`
- [ ] **Relancer** `python ingest.py example.sql` pour réindexer Qdrant
- [ ] **Tester** une requête end-to-end via `uvicorn api:app` + UI Streamlit
