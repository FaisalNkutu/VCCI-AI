
## Input folder

This folder contain the source data to generate the RAG

### Files

```
calian_nodata.sql   # SQL obtained from mariadb dump with --no-data
    

calian-vcci-database-description    # HTML Folder of documentation, used in parsing

kb_full.json    # A copy of the last good kb_full.json, to be used in input to rebuild the new one.
```

### Used by scripts

ingest.py RAG/input/calian_nodata.sql --kb=RAG/input/KB_full.json 


