### Updating RAG
To update one or more tables in the knowledge base, copy the modified table definitions in this folder.


### Example:

```
copy RAG\kb_tables\kb_act.json to  RAG\input\kb_tables
```