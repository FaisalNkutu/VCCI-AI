# NL2SQL Review Report: Suggestion of improving



> KB_blue_entity is KB_34_tables_updated_metadata improved version

## Comparison: KB_34_tables_updated_metadata vs KB_blue_entity

### Objective

Transform a predominantly technical schema into a business-oriented knowledge base optimized for NL2SQL agents.


# Executive Summary

KB_blue_entity represents a major improvement over KB_34_tables_updated_metadata.

Key benefits:

* Improved business understanding of tables.
* Enriched and contextualized column descriptions.
* Extensive semantic enrichment of ENUM values.
* Addition of business vocabulary and synonyms.
* Richer keyword coverage.
* Reduced SQL hallucinations.
* Stronger schema linking.
* Better grounding of user questions.
* Addition of advanced SQL examples and negative examples.


# Global Improvements

## 1. Table Descriptions

### Before

Descriptions were primarily technical and schema-oriented.

### After

Descriptions explain the real operational and business purpose of each entity.

### NL2SQL Impact

* Better table selection
* Improved retrieval
* Better intent understanding


## 2. Column Descriptions

### Before

Short, generic descriptions.

### After

Business-oriented, contextualized descriptions.

### NL2SQL Impact

* Better understanding of dates and timestamps
* Better distinction between identifiers and measures
* Better interpretation of status and classification fields


## 3. ENUM Enrichment

### Before

ENUM values were mostly labels. Like : `CODE:{“label”: Meaning}  `

This format is not matched  as presented in the full schema context json file (kb_full_update2.json)

### After

Format:

```text
CODE: Meaning + Business Description
```

### NL2SQL Impact

* Exceptional schema-linking improvements
* Better synonym matching
* Reduced filtering errors


## 4. Richer Keywords

### Before

A few generic keywords.

### After

Comprehensive business vocabulary including operational terminology and synonyms.

### NL2SQL Impact

* Better table ranking
* Better vector retrieval
* Better hybrid search performance


## 5. Business Synonyms

Many additional synonyms allow the agent to map different user expressions to the same business concept.

### Impact

* Better intent resolution
* Improved robustness to natural language variation


## 6. Temporal Clarification

Examples:

* effective time
* start time
* end time

Their business meanings are now explicitly documented.

### Impact

Significant reduction in temporal reasoning errors.


# 

## Improvements by Table

| Table | Elements Improved or Reviewed |
|----|----|
| act | Description, columns, enums, keywords |
| act_event | Description, columns, enums, keywords |
| act_task | Description, columns, enums, keywords |
| act_stat | Description, columns, enums, keywords |
| action_group | Description, columns, keywords |
| act_loc_assoc | Description, columns, keywords |
| act_oi_assoc | Description, columns, keywords |
| act_ot_assoc | Description, columns, keywords |
| comms_event | Description, columns, enums, keywords |
| tx_event | Description, columns, enums, keywords |
| rx_event | Description, columns, enums, keywords |
| scenario | Description, columns, enums, keywords |
| simulator_task | Description, columns, enums, keywords |
| simulator_task_event | Description, columns, enums, keywords |
| simulator_task_trigger | Description, columns, enums, keywords |
| loc | Description, columns, enums, keywords |
| obj_item | Description, columns, enums, keywords |
| obj_type | Description, columns, enums, keywords |
| holding | Description, columns, enums, keywords |
| callsign | Description, columns, enums, keywords |
| conn | Description, columns, enums, keywords |
| mapper | Description, columns, enums, keywords |
| param | Description, columns, enums, keywords |
| data_flow_spec | Description, columns, enums, keywords |
| blob_obj | Description, columns, enums, keywords |
| msg_type | Description, columns, keywords |
|    |    |



# Sample queries improving (Major Additional Enhancement) (in progress)



> **The next phase of schema enrichment will focus on improving the sample queries associated with each table. Sample queries will be redesigned to better reflect how end users naturally ask questions about operational data, while still maintaining a representative set of discovery, validation, and data quality examples.**
>
> **Recommended distribution:**
>
> * **Discovery & Profiling:** 5%–10%
> * **SQL Benchmark & Technical Validation:** 20%–25%
> * **Data Quality & Completeness Checks:** 5%–10%
> * **Business, Operational, and Mission-Oriented Queries:** 55%–60%
>
> **Priority will be given to business-focused scenarios that leverage table descriptions, relationships, enums, domains, and operational terminology to improve NL2SQL accuracy and schema-linking performance. Then,** KB_blue_entity will be more improved with this additionnal improvement that i am working on…
>
> \


**Impact**

> These examples effectively act as embedded supervised training material for an NL2SQL agent.

# Final Assessment

| Area | Benefit |
|----|----|
| Table descriptions | Very High |
| Column descriptions | Very High |
| ENUM grounding | Exceptional |
| Business keywords | Very High |
| Synonyms | Very High |
| Schema linking | Exceptional |
| SQL examples | Exceptional |
| Negative examples | Exceptional |
| Hallucination reduction | Very High |
| Overall NL2SQL quality | Exceptional |



# References

The following sources and best practices were used as guidance when reviewing and enriching the metadata knowledge base for NL2SQL applications.

## Documentation and Domain References

* Official JC3IEDM (Joint Consultation, Command and Control Information Exchange Data Model) documentation.
  * Tables descriptions: Just take the exact description in action.html or entities.html (More concise and busineess-oriented) (in 3.1.4 folder)
  * 2- columns description: Just take the exact description in attributes.html or index.html ---> attribute list.html (More concise and busineess-oriented) (in 3.1.4 folder)
  * 3- Enums description: Meaning + little description  ---→

  JC3IEDM-Annex E-Domain values-DMWG-Edition_3.0.2_20090514 (for enums values) /

  JC3IEDM-Annex N-Dom value diff-DMWG-Edition_3.0.2_20090514 (for enum values)

## Metadata and Schema Design Principles

* Internal metadata design guideline:

> "Tables and columns descriptions should be accurate, concise, and business-oriented. They should explain the table's business purpose and provide sufficient context for an LLM to determine whether the table is relevant to a user query, while avoiding unnecessary details that may increase schema-context noise."

## Research Papers

* ArXiv. *[2507.23104](https://arxiv.org/abs/2507.23104)*. Knowledge-base and semantic enrichment strategies for enterprise AI systems.
* ArXiv. *[2606.28601](https://arxiv.org/abs/2606.28601)*. Advanced approaches for semantic grounding and structured knowledge representation in LLM-powered systems. 【2-ca7073】
* Lewis, P., Perez, E., Piktus, A., et al. (2020). *Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks (RAG).* NeurIPS 2020.
* Yu, T., Zhang, R., Yang, K., et al. (2018). *Spider: A Large-Scale Human-Labeled Dataset for Complex and Cross-Domain Semantic Parsing and Text-to-SQL Task.*

## NL2SQL and LLM Engineering References

* Defog AI. *SQLCoder Documentation and Text-to-SQL Best Practices.*
* Hugging Face Documentation. *LLM Fine-Tuning, Embeddings, Retrieval, and Text-to-SQL Resources.*

## Design Objectives Adopted for KB_blue_entity

The KB_blue_entity enhancement was designed following established Text-to-SQL, RAG, and semantic-schema engineering practices:




1. Business-oriented table descriptions.
2. Context-rich column descriptions.
3. Semantically grounded ENUM values.
4. Expanded business vocabulary and synonyms.
5. NL2SQL-focused schema linking optimization.
6. Reduction of retrieval ambiguity and hallucinations.
7. SQL learning examples and negative examples to improve reasoning quality.


