# Report – Target Distribution of Sample Queries Across the 34 REQA-SQL Tables

## Executive Summary

As part of the recent schema context enhancement effort across the 34 core REQA-SQL tables, sample queries were redesigned to better support:

* Natural Language to SQL (NL2SQL) performance
* Schema linking and entity linking
* Business and operational reasoning
* Context retrieval (RAG)
* Join path discovery
* Hallucination reduction
* Improved performance across evaluated models (Arctic, Granite, Codestral, etc.)

The primary objective was not to maximize SQL syntax coverage, but rather to maximize exposure to realistic user questions and operational business scenarios.


---

# Global Target Distribution

| Query Category | Target Distribution |
|----|---:|
| **Business / Operational** | **58–60%** |
| Relationship / Join | 15–18% |
| Category / Classification | 10–12% |
| Aggregation / Count | 8–10% |
| Temporal | 4–6% |


---

# 1. Core Activity Tables

These tables represent the primary operational entities most frequently queried by end users.

| Table | Business | Join | Category | Aggregation | Temporal |
|----|---:|---:|---:|---:|---:|
| act | 60% | 15% | 10% | 10% | 5% |
| act_event | 60% | 15% | 10% | 5% | 10% |
| act_task | 60% | 15% | 10% | 5% | 10% |
| simulator_task | 55% | 20% | 10% | 5% | 10% |
| action_group | 60% | 20% | 5% | 5% | 10% |
| act_stat | 55% | 15% | 10% | 15% | 5% |

### Example Business Questions

* Show all operational activities related to Exercise Maple Resolve.
* List tasks assigned to a specific organization.
* Show recent operational events reported by Canadian units.
* Display actions associated with a mission.


---

# 2. Association Tables

These tables primarily exist to reinforce relationship discovery and join-path learning.

| Table | Business | Join | Category | Aggregation | Temporal |
|----|---:|---:|---:|---:|---:|
| act_loc_assoc | 45% | 35% | 5% | 5% | 10% |
| act_oi_assoc | 45% | 35% | 5% | 5% | 10% |
| act_ot_assoc | 45% | 35% | 5% | 5% | 10% |
| contxt_act_assoc | 45% | 35% | 5% | 5% | 10% |
| obj_item_assoc | 40% | 40% | 5% | 5% | 10% |
| org_item_assoc | 40% | 40% | 5% | 5% | 10% |

### Primary Goals

* Strengthen relationship reasoning.
* Improve automatic join-path selection.
* Improve entity association discovery.
* Increase schema graph awareness.


---

# 3. Operational Entity Tables

These tables contain the primary operational entities used throughout exercises and simulations.

| Table | Business | Join | Category | Aggregation | Temporal |
|----|---:|---:|---:|---:|---:|
| obj_item | 60% | 15% | 10% | 10% | 5% |
| organisation | 60% | 15% | 10% | 10% | 5% |
| person | 60% | 15% | 10% | 10% | 5% |
| facility | 60% | 15% | 10% | 10% | 5% |
| materiel | 60% | 15% | 10% | 10% | 5% |

### Example Business Questions

* Show all organizations participating in Exercise X.
* List facilities located in Area Y.
* Display equipment operated by Unit Z.
* Show personnel assigned to a specific organization.


---

# 4. Context and Scenario Tables

These tables provide the operational framework surrounding exercises, missions, and simulations.

| Table | Business | Join | Category | Aggregation | Temporal |
|----|---:|---:|---:|---:|---:|
| scenario | 65% | 10% | 10% | 5% | 10% |
| context | 65% | 10% | 10% | 5% | 10% |
| plan | 65% | 15% | 5% | 5% | 10% |

### Importance

These tables receive the highest proportion of business-oriented questions because they are frequently queried directly by operational users.


---

# 5. Type and Classification Reference Tables

These tables primarily define classification schemes and controlled vocabularies.

## Tables Included

* weapon_type
* eqpt_type
* misc_eqpt_type
* eng_eqpt_type
* elctrnc_eqpt_type
* actor_type
* organisation_type

### Target Distribution

| Query Type | Target Distribution |
|----|---:|
| Business | 50% |
| Category / Classification | 25% |
| Relationship / Join | 10% |
| Aggregation | 10% |
| Temporal | 5% |

### Example Questions

* What weapon categories exist in the system?
* Show electronic equipment classified as RADAR.
* List engineering equipment used for mine-clearing operations.
* Count available equipment categories.


---

# Standard Distribution Per 10 Sample Queries

To maintain consistency across most tables, the following structure was adopted:

| Query Type | Queries |
|----|---:|
| Business / Operational | 6 |
| Relationship / Join | 1–2 |
| Category / Classification | 1 |
| Aggregation / Count | 1 |
| Temporal | 1 |


---

# Design Principles

## Prioritized

✅ Real-world business questions

✅ Operational terminology

✅ Mission and exercise scenarios

✅ Category and classification usage

✅ Relationship-driven queries

✅ User-centric information needs

✅ Realistic military and defense use cases


---

## Intentionally Reduced

❌ Generic `SELECT * LIMIT 10`

❌ Purely technical SQL examples

❌ Data profiling queries

❌ Schema exploration for its own sake

❌ Overuse of `COUNT(*)`

❌ Overuse of `DISTINCT`

❌ Synthetic examples with limited operational relevance


---

# Expected Benefits

The revised sample query strategy is expected to improve:

* Schema linking accuracy
* Table selection accuracy
* Join-path discovery
* Business intent recognition
* Retrieval quality
* Model grounding
* Hallucination reduction
* NL2SQL generation quality


---

# Final Recommendation

The final target distribution adopted for the schema context enhancement effort is:

| Category | Target |
|----|---:|
| **Business / Operational** | **58–60%** |
| **Relationship / Join** | **15–18%** |
| **Category / Classification** | **10–12%** |
| **Aggregation / Count** | **8–10%** |
| **Temporal** | **4–6%** |

This distribution is particularly well suited for a defense-oriented NL2SQL system because it emphasizes operational intent, entity relationships, and mission-relevant business questions rather than generic SQL patterns.