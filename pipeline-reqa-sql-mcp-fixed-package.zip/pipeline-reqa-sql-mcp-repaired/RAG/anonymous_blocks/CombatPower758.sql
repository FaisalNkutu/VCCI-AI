




DELIMITER //

BEGIN NOT ATOMIC
  
DECLARE unit_object_item_id INT DEFAULT 0;

WITH eligible_item_types AS
(    
     SELECT DISTINCT        
    h.obj_type_id    
    FROM holding h 
    JOIN mat_type mt 
    ON mt.mat_type_id = h.obj_type_id  
    AND mt.mcapab_cat_code <> 'NOS'  
    WHERE h.obj_item_id = unit_object_item_id 
), 
event_times AS 
(
    SELECT DISTINCT h.time  
    FROM holding h   
    JOIN eligible_item_types eit   
    ON eit.obj_type_id = h.obj_type_id  
    WHERE h.obj_item_id = unit_object_item_id 
),
holding_state AS 
(
        SELECT         et.time,         eit.obj_type_id,        
        (        SELECT h2.total_qty        
                FROM holding h2             
                WHERE h2.obj_item_id = unit_object_item_id     
                AND h2.obj_type_id = eit.obj_type_id          
                AND h2.time <= et.time      
                ORDER BY h2.time DESC, h2.holding_ix DESC    
                LIMIT 1         
        )
        AS total_qty,     
        (
            SELECT h2.operat_cnt   
            FROM holding h2           
            WHERE h2.obj_item_id = unit_object_item_id        
            AND h2.obj_type_id = eit.obj_type_id    
            AND h2.time <= et.time        
            ORDER BY h2.time DESC, h2.holding_ix DESC  
            LIMIT 1         
        ) 
        AS operat_cnt   
        FROM event_times et    
        CROSS JOIN eligible_item_types eit 
) 
SELECT unit_object_item_id AS unit_name,  
FROM_UNIXTIME(time / 1000) AS reported_at,   
ROUND(         100.0 * SUM(operat_cnt) /
NULLIF(SUM(total_qty), 0),         2     ) 
AS combat_power_percent FROM holding_state GROUP BY time ORDER BY time;


END //

DELIMITER ;

