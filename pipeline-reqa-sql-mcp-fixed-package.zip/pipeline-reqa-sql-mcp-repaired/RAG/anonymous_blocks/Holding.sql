

DELIMITER //

BEGIN NOT ATOMIC
  
DECLARE unit_object_name VarChar(100) DEFAULT "3R22R 13B";


SELECT
    oi.name_txt AS unit_name,
    ot.name_txt AS item_type,
    h.total_qty,
    h.on_hand_qty,
    h.operat_cnt
FROM holding h
JOIN obj_item oi
    ON oi.obj_item_id = h.obj_item_id
JOIN obj_type ot
    ON ot.obj_type_id = h.obj_type_id
WHERE oi.name_txt LIKE unit_object_name
ORDER BY h.time DESC, ot.name_txt;



END //

DELIMITER ;

