WITH RECURSIVE unit_scope AS (
    SELECT
        oi.obj_item_id,
        oi.name_txt AS entity_name
    FROM obj_item oi
    WHERE oi.name_txt = '5 AMB de C - MMU'

    UNION ALL

    SELECT
        child.obj_item_id,
        child.name_txt AS entity_name
    FROM obj_item_assoc a
    JOIN unit_scope parent_scope
        ON parent_scope.obj_item_id = a.parent_obj_item_id
    JOIN obj_item child
        ON child.obj_item_id = a.child_obj_item_id
    WHERE a.cat_code = 'CMDCTL'
      AND a.subcat_code = 'COMD'
),
friendly_fire_to_5amb AS (
    SELECT
        a.act_id AS fire_event_id,
        a.name_txt AS fire_type,
        a.time AS fire_time,
        a.rep_org_id AS firing_obj_item_id,
        fe.target_oi_id,
        fe.target_lat,
        fe.target_lon,
        scope.entity_name AS receiving_entity,
        (
            SELECT p.lat_coord
            FROM obj_item_point_loc p
            WHERE p.obj_item_id = fe.target_oi_id
              AND p.time <= a.time
            ORDER BY p.time DESC
            LIMIT 1
        ) AS target_location_lat,
        (
            SELECT p.long_coord
            FROM obj_item_point_loc p
            WHERE p.obj_item_id = fe.target_oi_id
              AND p.time <= a.time
            ORDER BY p.time DESC
            LIMIT 1
        ) AS target_location_lon
    FROM act a
    JOIN fire_event fe
        ON fe.fire_event_id = a.act_id
    JOIN unit_scope scope
        ON scope.obj_item_id = fe.target_oi_id
    WHERE a.name_txt IN ('Direct Fire', 'InDirect Fire')
      AND (
          SELECT s.hostility_code
          FROM obj_item_stat s
          WHERE s.obj_item_id = a.rep_org_id
            AND s.time <= a.time
          ORDER BY s.time DESC
          LIMIT 1
      ) = 'FR'
      AND (
          SELECT s.hostility_code
          FROM obj_item_stat s
          WHERE s.obj_item_id = fe.target_oi_id
            AND s.time <= a.time
          ORDER BY s.time DESC
          LIMIT 1
      ) = 'FR'
)
SELECT
    f.fire_event_id,
    FROM_UNIXTIME(f.fire_time / 1000) AS occurred_at,
    f.fire_type,
    firing.name_txt AS firing_organisation,
    f.receiving_entity,
    f.target_lat,
    f.target_lon,
    'Approximate 10m x 10m footprint' AS method
FROM friendly_fire_to_5amb f
JOIN obj_item firing
    ON firing.obj_item_id = f.firing_obj_item_id
WHERE f.target_location_lat IS NOT NULL
  AND f.target_location_lon IS NOT NULL
  AND ABS(f.target_lat - f.target_location_lat) <= 5.0 / 111320.0
  AND ABS(f.target_lon - f.target_location_lon)
      <= 5.0 / (
          111320.0 * COS(RADIANS(f.target_location_lat))
      )
ORDER BY f.fire_time;