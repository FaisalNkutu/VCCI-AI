WITH friendly_indirect_fire AS (
    SELECT
        a.act_id AS fire_event_id,
        a.time AS fire_time,
        a.rep_org_id AS firing_obj_item_id,
        fe.target_oi_id,
        fe.target_lat,
        fe.target_lon,
        (
            SELECT p.lat_coord
            FROM obj_item_point_loc p
            WHERE p.obj_item_id = fe.target_oi_id
              AND p.time <= a.time
            ORDER BY p.time DESC
            LIMIT 1
        ) AS target_location_lat,
        (
            SELECT p.long_coord
            FROM obj_item_point_loc p
            WHERE p.obj_item_id = fe.target_oi_id
              AND p.time <= a.time
            ORDER BY p.time DESC
            LIMIT 1
        ) AS target_location_lon
    FROM act a
    JOIN fire_event fe
        ON fe.fire_event_id = a.act_id
    WHERE a.name_txt = 'InDirect Fire'
      AND (
          SELECT s.hostility_code
          FROM obj_item_stat s
          WHERE s.obj_item_id = a.rep_org_id
            AND s.time <= a.time
          ORDER BY s.time DESC
          LIMIT 1
      ) = 'FR'
      AND (
          SELECT s.hostility_code
          FROM obj_item_stat s
          WHERE s.obj_item_id = fe.target_oi_id
            AND s.time <= a.time
          ORDER BY s.time DESC
          LIMIT 1
      ) = 'FR'
)
SELECT
    f.fire_event_id,
    FROM_UNIXTIME(f.fire_time / 1000) AS occurred_at,
    firing.name_txt AS firing_organisation,
    target.name_txt AS receiving_friendly_entity,
    f.target_lat AS impact_lat,
    f.target_lon AS impact_lon,
    'Approximate 10m x 10m footprint' AS method
FROM friendly_indirect_fire f
JOIN obj_item firing
    ON firing.obj_item_id = f.firing_obj_item_id
JOIN obj_item target
    ON target.obj_item_id = f.target_oi_id
WHERE f.target_location_lat IS NOT NULL
  AND f.target_location_lon IS NOT NULL
  AND ABS(f.target_lat - f.target_location_lat) <= 5.0 / 111320.0
  AND ABS(f.target_lon - f.target_location_lon)
      <= 5.0 / (
          111320.0 * COS(RADIANS(f.target_location_lat))
      )
ORDER BY f.fire_time;