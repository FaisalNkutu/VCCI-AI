DELIMITER //

BEGIN NOT ATOMIC

-- Who fired at “EAGLE I11C” around December 3 2025 18:00?
DECLARE unit_object_name VarChar(100) DEFAULT "EAGLE I11C";
DECLARE unix_time_from BigInt(15) DEFAULT UNIX_TIMESTAMP('2025-12-03 17:55:00');
DECLARE unix_time_to BigInt(15) DEFAULT UNIX_TIMESTAMP('2025-12-03 18:05:00');

SELECT
    a.act_id AS fire_event_id,
    FROM_UNIXTIME(a.time / 1000) AS occurred_at,
    a.name_txt AS fire_type,
    firing.name_txt AS firing_entity,
    target.name_txt AS target_entity,
    fe.target_lat,
    fe.target_lon
FROM act a
JOIN fire_event fe
    ON fe.fire_event_id = a.act_id
JOIN obj_item firing
    ON firing.obj_item_id = a.rep_org_id
JOIN obj_item target
    ON target.obj_item_id = fe.target_oi_id
WHERE target.name_txt = unit_object_name
  AND a.name_txt IN ('Direct Fire', 'InDirect Fire')
  AND a.time BETWEEN
      (unix_time_from * 1000) - (5 * 60 * 1000)
      AND
      (unix_time_to * 1000) + (5 * 60 * 1000)
ORDER BY a.time;



END //

DELIMITER ;

