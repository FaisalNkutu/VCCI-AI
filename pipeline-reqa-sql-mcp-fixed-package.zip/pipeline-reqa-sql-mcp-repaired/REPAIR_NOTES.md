# REQA NL2SQL source repair — 2026-11-07

This archive is a full copy of the uploaded plan/ai#107 source with focused corrections.

## Changes
- Removed the old A2A 0.3 monkey patch and nonexistent create_text_message_object import.
- Fixed the duplicated uvicorn.Config application argument.
- Removed manual SDK route rewriting; preserve agent-card routing.
- Made init_asyncio callable without a positional argument.
- Prevented None.lower() in common_pipeline.get_pipeline_instance.
- Moved the A2A streaming DONE callback outside the per-chunk loop.

## Limitations
This is a static repair, NOT an end-to-end verified build. Live A2A SDK compatibility, the advertised agent card URL, Ollama reachability, and Docker health require testing on the actual runtime. No .env secrets are included.

## First verification
From the project root, run `docker compose up -d --build api app` then `docker compose ps`. Start the A2A agent separately using the project configuration and verify the agent card URL before running client evaluations.
