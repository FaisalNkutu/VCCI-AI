/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel.mixin;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 * @author rhans
 */
public abstract class UIOROMResultPointMixIn extends UIOBaseMixIn {

    @JsonProperty("numEnts")
    public abstract int getNumEnts();

    @JsonProperty("avgspeed")
    public abstract double getAvgSpeed();

    @JsonProperty("avgcumuldist")
    public abstract double geAvgCumul();
}
