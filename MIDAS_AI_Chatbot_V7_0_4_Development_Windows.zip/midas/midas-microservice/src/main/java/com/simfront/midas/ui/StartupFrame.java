/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.ui;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.formdev.flatlaf.FlatLightLaf;


import javax.swing.*;
import javax.swing.plaf.basic.BasicScrollBarUI;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;




public class StartupFrame extends JFrame {
    private static final Logger jLogger = Logger.getLogger(StartupFrame.class.getName());

    private static final String jBASE_URL = "http://127.0.0.1:10001";
    //private static final String jENDPOINT_DATABASES = "/omdbdata/databases";
    private static final String jENDPOINT_SELECT_DB = "/advmetrics/omdbdata/selectdb";
    private static final String jENDPOINT_DISCONNECT_DB = "/advmetrics/omdbdata/disconnectdb";
    private static final String jENDPOINT_STATUS = "/advmetrics/omdbdata/status";
    private static final String DB_USER = "vcci";
    private static final String DB_PASSWORD = "vcci";


    private String jSelectedDatabase;
    private final ObjectMapper jObjectMapper = new ObjectMapper();
    private JProgressBar jLoadingSpinner;
    private JTextField jHostField;
    private String jCurrentHost = "127.0.0.1";
    private List<JPanel> jRowPanels;
    private RoundedPanel jCardPanel;
    private ButtonGroup jDbGroup;
    private JButton jConnectButton;
    private SwingWorker<Void, Void> jDbLoadWorker;
    private boolean jIsConnected = false;
    private JCheckBox jLiveModeCheckbox;
    private JButton jLaunchButton;
    private JButton jRefreshButton;



    static {
        try {
            UIManager.setLookAndFeel(new FlatLightLaf());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public StartupFrame() {
        super("Military Data Analytics ");

        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

        Image icon = loadImage("/images/midas_icon.png");
        if (icon != null) {
            setIconImage(icon);
        }

        JMenuBar menuBar = new JMenuBar();
        JMenu aboutMenu = new JMenu("About");
        JMenuItem aboutItem = new JMenuItem("About");
        aboutItem.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "Military Data Analytics \nVersion 2.0", "About", JOptionPane.INFORMATION_MESSAGE));
        aboutMenu.add(aboutItem);

        JMenu helpMenu = new JMenu("Help");
        JMenuItem helpItem = new JMenuItem("Help");
        helpItem.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "For help, contact raj.hans@calian.com", "Help", JOptionPane.INFORMATION_MESSAGE));
        helpMenu.add(helpItem);

        menuBar.add(aboutMenu);
        menuBar.add(helpMenu);
        setJMenuBar(menuBar);

        setupUI();

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                sendDisconnectRequest();
                if (jSelectedDatabase != null) {
                    jLogger.info("\uD83D\uDED1 Application is closing. Database '" + jSelectedDatabase + "' — disconnect request sent.");
                } else {
                    jLogger.info("\uD83D\uDED1 Application is closing. Disconnect request sent — but no database was selected during session.");
                }
                dispose();
                System.exit(0);
            }
        });
    }

    private void setupUI() {
        jSelectedDatabase = null;
        jRowPanels = new ArrayList<>();

        Image backgroundImage = loadImage("/images/mil.jpg");
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        backgroundPanel.setLayout(new BorderLayout());

        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setOpaque(false);
        jCardPanel = new RoundedPanel();
        JPanel card = jCardPanel;
        card.setPreferredSize(new Dimension(500, 300));
        card.setLayout(new BorderLayout(20, 20));
        card.setBackground(new Color(0, 0, 0, 160));
        card.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 20));

        JPanel hostPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        hostPanel.setOpaque(false);

        JLabel hostLabel = new JLabel("Host:");
        hostLabel.setForeground(Color.WHITE);
        hostPanel.add(hostLabel);

        jHostField = new JTextField("127.0.0.1", 20);
        hostPanel.add(jHostField);

        jRefreshButton = new JButton("Refresh Databases");
        jRefreshButton.addActionListener(e -> {
            jCurrentHost = jHostField.getText().trim();
            reloadDatabaseList();
        });
        hostPanel.add(jRefreshButton);

        card.add(hostPanel, BorderLayout.NORTH);

        List<String> dbs = fetchDatabases(jCurrentHost);

        if (dbs.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No databases found.", "Warning", JOptionPane.WARNING_MESSAGE);
        }

        JPanel dbListPanel = new JPanel();
        dbListPanel.setLayout(new BoxLayout(dbListPanel, BoxLayout.Y_AXIS));
        dbListPanel.setOpaque(false);
        jDbGroup = new ButtonGroup();

        for (String db : dbs) {
            JPanel row = new JPanel(new BorderLayout());
            row.setOpaque(false);
            row.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.GRAY));

            JLabel label = new JLabel(db);
            label.setForeground(Color.WHITE);
            label.setFont(new Font("SansSerif", Font.PLAIN, 16));
            label.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));

            JRadioButton rb = new JRadioButton();
            rb.setOpaque(false);
            rb.setActionCommand(db);
            rb.setToolTipText("Click to select this database");
            jDbGroup.add(rb);

            rb.addActionListener(e -> {
                jConnectButton.setEnabled(true);
                jConnectButton.setToolTipText("Please connect to a database!");
            });

            row.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (jIsConnected) return;
                    rb.setSelected(true);
                    jConnectButton.setEnabled(true);
                    jConnectButton.setToolTipText("Please connect to a database!");
                }
            });

            row.add(label, BorderLayout.CENTER);
            row.add(rb, BorderLayout.EAST);
            dbListPanel.add(row);
            jRowPanels.add(row);
        }

        JScrollPane scrollPane = new JScrollPane(dbListPanel);
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.getVerticalScrollBar().setUI(new BasicScrollBarUI() {
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = new Color(120, 120, 120);
            }
        });

        card.add(scrollPane, BorderLayout.CENTER);

        // ---- BUTTON/CONTROL PANEL ----
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setOpaque(false);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        buttonPanel.setOpaque(false);


        // 1st row: Centered Connect button
        JPanel connectRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        connectRow.setOpaque(false);
        jConnectButton = new JButton("Connect");
        connectRow.add(jConnectButton);
        buttonPanel.add(connectRow);

        // 2nd row: Centered Enable Live Mode checkbox
        JPanel liveModeRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        liveModeRow.setOpaque(false);
        jLiveModeCheckbox = new JCheckBox("Enable Live Mode");
        jLiveModeCheckbox.setFont(new Font("SansSerif", Font.PLAIN, 11));
        jLiveModeCheckbox.setForeground(Color.LIGHT_GRAY);
        jLiveModeCheckbox.setOpaque(false);
        liveModeRow.add(jLiveModeCheckbox);
        buttonPanel.add(liveModeRow);

        // 3rd row: Extra vertical space before Configure Map/Launch Dashboard
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 18)));

        // 4th row: Centered Configure Map and Launch Dashboard side by side
        JPanel bottomRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0)); // 20px gap
        bottomRow.setOpaque(false);

        JButton configureMapButton = new JButton("Configure Map");
        configureMapButton.addActionListener(e -> {
            SimpleOGCDialog dialog = new SimpleOGCDialog(StartupFrame.this);
            dialog.setVisible(true);
        });
        bottomRow.add(configureMapButton);

        jLaunchButton = new JButton("Launch Dashboard");
        jLaunchButton.setBackground(new Color(148, 194, 244));
        jLaunchButton.setEnabled(false);
        jLaunchButton.addActionListener(e -> {
            try {
                Desktop.getDesktop().browse(new URL(jBASE_URL).toURI());
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Could not launch dashboard.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        bottomRow.add(jLaunchButton);

        buttonPanel.add(bottomRow);

        // Connect button logic
        jConnectButton.setToolTipText(null);
        jConnectButton.setEnabled(false);
        jConnectButton.addActionListener(e -> {
            if (!jIsConnected) {
                ButtonModel selectedModel = jDbGroup.getSelection();
                if (selectedModel != null) {
                    jSelectedDatabase = selectedModel.getActionCommand();
                    // --- Live Mode warning check ---
                    if (!jLiveModeCheckbox.isSelected()) {
                        int result = JOptionPane.showConfirmDialog(
                                this,
                                "You have not enabled Live Mode.\nAre you sure you want to continue without it?",
                                "Live Mode Not Enabled",
                                JOptionPane.YES_NO_OPTION,
                                JOptionPane.WARNING_MESSAGE
                        );
                        if (result != JOptionPane.YES_OPTION) {
                            // User chose NO, don't proceed
                            return;
                        }
                    }
                    confirmAndSelectDatabase(jSelectedDatabase);
                } else {
                    JOptionPane.showMessageDialog(this, "Please select a database.",
                            "Warning", JOptionPane.WARNING_MESSAGE);
                }

            } else {
                sendDisconnectRequest();
                jLogger.info("\uD83D\uDD0C User disconnected from database: " + jSelectedDatabase);
                clearSelection();
                jIsConnected = false;
                jConnectButton.setText("Connect");
                jConnectButton.setToolTipText(null);
                jConnectButton.setEnabled(false);
            }
        });

        // Spinner panel
        JPanel spinnerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        spinnerPanel.setOpaque(false);
        spinnerPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        jLoadingSpinner = new JProgressBar();
        jLoadingSpinner.setIndeterminate(true);
        jLoadingSpinner.setVisible(false);
        jLoadingSpinner.setStringPainted(true);
        jLoadingSpinner.setString("Loading database...");
        spinnerPanel.add(jLoadingSpinner);

        bottomPanel.add(buttonPanel, BorderLayout.NORTH);
        bottomPanel.add(spinnerPanel, BorderLayout.SOUTH);
        card.add(bottomPanel, BorderLayout.SOUTH);

        centerPanel.add(card);

        backgroundPanel.add(centerPanel, BorderLayout.CENTER);
        setContentPane(backgroundPanel);
        revalidate();
        repaint();
    }


    private void confirmAndSelectDatabase(String selectedDatabase) {
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to select " + selectedDatabase + "?",
                "Confirm Selection", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            for (JPanel row : jRowPanels) {
                for (Component comp : row.getComponents()) {
                    if (comp instanceof JRadioButton) {
                        ((JRadioButton) comp).setEnabled(false);
                    }
                }
            }

            jLoadingSpinner.setVisible(true);
            jConnectButton.setEnabled(false);

            jDbLoadWorker = new SwingWorker<>() {
                @Override
                protected Void doInBackground() {
                    try {
                        postSelectedDatabase(selectedDatabase);
                        boolean ready = false;
                        int retries = 20;
                        while (!ready && retries-- > 0) {
                            Thread.sleep(500);
                            ready = checkBackendReady();
                        }
                        return null;
                    } catch (Exception e) {
                        jLogger.warning("Failed to connect to database: '" + selectedDatabase + "'");
                        return null;
                    }
                }

                @Override
                protected void done() {
                    jLoadingSpinner.setVisible(false);
                    finalizeSelection(selectedDatabase);
                    jConnectButton.setText("Disconnect");
                    jConnectButton.setToolTipText("Please disconnect from the selected database!");
                    jConnectButton.setEnabled(true);
                    jIsConnected = true;
                    jRefreshButton.setEnabled(false);
                    jHostField.setEnabled(false);
                    jLiveModeCheckbox.setEnabled(false);
                    jLaunchButton.setEnabled(true); // ENABLE Launch Dashboard button
                    jLogger.info("Database '" + selectedDatabase + "' successfully connected");

                }
            };
            jDbLoadWorker.execute();
        }
    }

    private void finalizeSelection(String selectedDB) {
        for (JPanel row : jRowPanels) {
            for (Component comp : row.getComponents()) {
                if (comp instanceof JRadioButton) {
                    ((JRadioButton) comp).setEnabled(false);
                }
            }
            row.setOpaque(false);
            row.setBackground(null);
        }
        revalidate();
        repaint();
    }

    private void clearSelection() {
        jSelectedDatabase = null;
        jDbLoadWorker = null;
        for (JPanel row : jRowPanels) {
            row.setOpaque(false);
            row.setBackground(null);
            for (Component comp : row.getComponents()) {
                if (comp instanceof JRadioButton) {
                    JRadioButton rb = (JRadioButton) comp;
                    rb.setEnabled(true);
                    rb.setSelected(false);
                }
            }
        }
        jDbGroup.clearSelection();
        jConnectButton.setText("Connect");
        jConnectButton.setToolTipText(null);
        jConnectButton.setEnabled(false);
        jLiveModeCheckbox.setEnabled(true);
        jLiveModeCheckbox.setSelected(false);
        jLaunchButton.setEnabled(false);
        jRefreshButton.setEnabled(true);
        jHostField.setEnabled(true);
        revalidate();
        repaint();
    }

    private void postSelectedDatabase(String selectedDB) {
        try {
            URL url = new URL(jBASE_URL + jENDPOINT_SELECT_DB);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json");

            var payload = new java.util.HashMap<String, Object>();
            payload.put("name", selectedDB);
            payload.put("livemode", jLiveModeCheckbox.isSelected());
            payload.put("host", jHostField.getText().trim());

            try (OutputStream os = conn.getOutputStream()) {
                jObjectMapper.writeValue(os, payload);
            }

            if (conn.getResponseCode() != 200) {
                JOptionPane.showMessageDialog(this, "Failed to load database: " + selectedDB,
                        "Backend Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Could not connect to backend.",
                    "Connection Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void sendDisconnectRequest() {
        try {
            URL url = new URL(jBASE_URL + jENDPOINT_DISCONNECT_DB);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean checkBackendReady() {
        try {
            URL url = new URL(jBASE_URL + jENDPOINT_STATUS);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            if (conn.getResponseCode() == 200) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                    String response = reader.readLine();
                    return response != null && response.contains("\"ready\":true");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static void main(String[] args) {
        // Launch the UI
        SwingUtilities.invokeLater(() -> {
            StartupFrame frame = new StartupFrame();
            frame.setVisible(true);
        });
    }

    static class RoundedPanel extends JPanel {
        public RoundedPanel() {
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Shape round = new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 25, 25);
            g2.setColor(getBackground());
            g2.fill(round);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    private Image loadImage(String path) {
        try {
            URL url = getClass().getResource(path);
            if (url != null) {
                return new ImageIcon(url).getImage();
            } else {
                System.err.println("ERROR: Image not found at path: " + path);
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private void reloadDatabaseList() {
        List<String> dbs = fetchDatabases(jCurrentHost);

        if (dbs.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No databases found at host: " + jCurrentHost,
                    "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        JPanel dbListPanel = new JPanel();
        dbListPanel.setLayout(new BoxLayout(dbListPanel, BoxLayout.Y_AXIS));
        dbListPanel.setOpaque(false);
        jRowPanels.clear();
        jDbGroup.clearSelection();

        for (String db : dbs) {
            JPanel row = new JPanel(new BorderLayout());
            row.setOpaque(false);
            row.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.GRAY));

            JLabel label = new JLabel(db);
            label.setForeground(Color.WHITE);
            label.setFont(new Font("SansSerif", Font.PLAIN, 16));
            label.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));

            JRadioButton rb = new JRadioButton();
            rb.setOpaque(false);
            rb.setActionCommand(db);
            rb.setToolTipText("Click to select this database");
            jDbGroup.add(rb);

            rb.addActionListener(e -> {
                jConnectButton.setEnabled(true);
                jConnectButton.setToolTipText("Please connect to a database!");
            });

            row.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (jIsConnected) return;
                    rb.setSelected(true);
                    jConnectButton.setEnabled(true);
                    jConnectButton.setToolTipText("Please connect to a database!");
                }
            });

            row.add(label, BorderLayout.CENTER);
            row.add(rb, BorderLayout.EAST);
            dbListPanel.add(row);
            jRowPanels.add(row);
        }

        // Replace the scroll pane in the UI with the new one
        JScrollPane newScrollPane = new JScrollPane(dbListPanel);
        newScrollPane.setBorder(null);
        newScrollPane.setOpaque(false);
        newScrollPane.getViewport().setOpaque(false);
        newScrollPane.getVerticalScrollBar().setUI(new BasicScrollBarUI() {
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = new Color(120, 120, 120);
            }
        });

        RoundedPanel card = jCardPanel;

        // Remove existing center (scrollPane)
        for (Component comp : card.getComponents()) {
            if (comp instanceof JScrollPane) {
                card.remove(comp);
                break;
            }
        }

        card.add(newScrollPane, BorderLayout.CENTER);
        card.revalidate();
        card.repaint();
    }


    private List<String> fetchDatabases(String host) {
        List<String> databases = new ArrayList<>();
        String url = "jdbc:mysql://" + host + ":3306/?useSSL=false";

        try (Connection conn = DriverManager.getConnection(url, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SHOW DATABASES")) {

            while (rs.next()) {
                String db = rs.getString(1);
                if (!List.of("mysql", "information_schema", "performance_schema", "sys").contains(db)) {
                    databases.add(db);
                }
            }
        } catch (Exception e) {
            jLogger.severe("JDBC connection failed to host " + host + ": " + e.getMessage());
            JOptionPane.showMessageDialog(this,
                    "Failed to fetch databases from host " + host + ":\n" + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }

        return databases;
    }


}
