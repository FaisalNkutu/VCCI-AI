/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.ui;

import javax.swing.*;
import java.awt.*;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * SimpleOGCDialog provides a minimal dialog for user input of map service configuration.
 * The user can specify an alias, WMS/WMTS/CSW service URL, and type.
 * On submission, the dialog sends a JSON payload with these values to the backend /mapconfig endpoint.
 * This dialog is intended for quick, in-memory configuration—no database storage.
 */
public class SimpleOGCDialog extends JDialog {

    private final JTextField aliasField = new JTextField(20);
    private final JTextField urlField = new JTextField(30);
    private final JComboBox<String> typeBox = new JComboBox<>(new String[]{"WMS", "WMTS", "CSW"});

    public SimpleOGCDialog(Frame parent) {
        super(parent, "Configure Map Service", true);
        setLayout(new BorderLayout());

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // Padding between fields

        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.EAST;
        formPanel.add(new JLabel("Alias:"), gbc);

        gbc.gridx = 1; gbc.gridy = 0; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(aliasField, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("URL:"), gbc);

        gbc.gridx = 1; gbc.gridy = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(urlField, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Type:"), gbc);

        gbc.gridx = 1; gbc.gridy = 2; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(typeBox, gbc);

        // Submit button
        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(e -> sendMapConfig());


        // Add to dialog
        add(formPanel, BorderLayout.CENTER);
        add(submitButton, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(parent);
    }

    private void sendMapConfig() {
        String alias = aliasField.getText().trim();
        String url = urlField.getText().trim();
        String type = (String) typeBox.getSelectedItem();

        if (alias.isEmpty() || url.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Alias and URL are required.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            URL endpoint = new URL("http://127.0.0.1:10001/mapconfig");
            HttpURLConnection conn = (HttpURLConnection) endpoint.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json");

            String payload = String.format(
                    "{\"alias\":\"%s\",\"url\":\"%s\",\"type\":\"%s\"}",
                    alias, url, type
            );

            try (OutputStream os = conn.getOutputStream()) {
                os.write(payload.getBytes(StandardCharsets.UTF_8));
            }

            int code = conn.getResponseCode();
            if (code == 200) {
                JOptionPane.showMessageDialog(this, " Map config sent successfully.");
                dispose(); // Close dialog
            } else {
                JOptionPane.showMessageDialog(this, "Failed to send config. HTTP Code: " + code, "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Exception", JOptionPane.ERROR_MESSAGE);
        }
    }
}
