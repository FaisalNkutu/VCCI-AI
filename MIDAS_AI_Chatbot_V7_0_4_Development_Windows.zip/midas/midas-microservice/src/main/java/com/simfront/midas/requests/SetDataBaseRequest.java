/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.requests;

/**
 *
 * @author rhans
 */
public class SetDataBaseRequest extends JSONPostRequest {

    String name;
    boolean livemode = false;
    String host;

    public SetDataBaseRequest(
            String dbName,
            boolean liveMode, String host) {
        name = dbName;
        livemode = liveMode;
        this.host = host;

    }
    
    public SetDataBaseRequest() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isLivemode() {
        return livemode;
    }

    public void setLivemode(boolean islive) {
        livemode = islive;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }
}
