/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.processors;//package com.simfront.midas.processors;

import com.simfront.midas.CentralDispatch;
import com.simfront.midas.constants.MIDASConstants.E_REQUEST_STATUS;
import com.simfront.midas.utils.RequestResults;

import java.util.ArrayList;

public class EntityWatchLiveProcessor extends BaseProcessor {

    /**
     * Thin wrapper: delegate to CentralDispatch (no DB calls here).
     */
    public RequestResults getEntityWatchIds(ArrayList<Object> params) {
        try {
            return CentralDispatch.jCentralDispatch.getEntityWatchIds(params);
        } catch (Exception e) {
            return new RequestResults(E_REQUEST_STATUS.GENERAL_FAILURE);
        }
    }

    public RequestResults getEntityWatchResults(ArrayList<Object> params) {
        try {
            return CentralDispatch.jCentralDispatch.getEntityWatchResults(params);
        } catch (Exception e) {
            return new RequestResults(E_REQUEST_STATUS.GENERAL_FAILURE);
        }
    }
}
