/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel.mixin;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 * @author rhans
 */
public abstract class UIOROMMetricsSpecificationMixIn extends UIOBaseMixIn {

    @JsonProperty("endtime")
    public abstract long getEndTime();

    @JsonProperty("formattedendtime")
    public abstract String getFormattedEndTime();

    @JsonProperty("controlmeasureid")
    public abstract long getControlMeasureId();

    @JsonProperty("controlmeasurename")
    public abstract String getControllMeasureName();
}
