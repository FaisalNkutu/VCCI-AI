/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */
package com.simfront.midas.processors;

import com.simfront.midas.constants.MIDASConstants.E_REQUEST_STATUS;
import com.simfront.midas.managers.DBManager;
import com.simfront.midas.model.ControlMeasureInfo;
import com.simfront.midas.model.transfermodel.UIOBase;
import com.simfront.midas.model.transfermodel.UIOEnemyEngagementGraphPoint;
import com.simfront.midas.utils.MIDASUtils;
import com.simfront.midas.utils.RequestResults;
import com.calian.paradigm.core.bto.model.aobjs.AObjectItem;
import com.calian.paradigm.core.bto.model.gobjs.gen.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author rhans
 */
public class EnemyEngProcessor extends BaseProcessor {

    public EnemyEngProcessor() {

    }

    public RequestResults getEneEngControlMeasures() {
        System.err.println("Processing get Enemy Engagements control measures..");
        ArrayList<GEnemyEngagementMetricsResults> results
                = DBManager.jDBManager.getEnemyEngagementMetricsResults();
        ArrayList<Object> cms = new ArrayList();
        Set<Long> cmSeen = new HashSet();
        GEnemyEngagementMetricsResults eeRes;
        long cmId;
        for (Object r : results) {
            eeRes = (GEnemyEngagementMetricsResults) r;
            cmId = eeRes.getEnemyEngagementMetricsResultsControlMeasureId();
            if (!cmSeen.contains(cmId)) {
                ControlMeasureInfo info = new ControlMeasureInfo(
                        eeRes.getEnemyEngagementMetricsResultsControlMeasureName(),
                        cmId);
                // Get hostility
                info.setIsFriendly(DBManager.jDBManager.objectItemIsFriendly(cmId));
                cms.add(info);
                cmSeen.add(cmId);
            }
        }
        System.err.println("Returning " + cms.size() + " results...");
        return new RequestResults(cms, E_REQUEST_STATUS.SUCCESS);
    }

    public RequestResults getEnemyEngagementsByTime(ArrayList<Object> params) {
        Long startTime = (long) params.get(0);
        Long endTime = (long) params.get(1);
        String timeFormat = (String) params.get(2);
        Boolean isFriendly = (Boolean) params.get(3);
        List<Long> selectedCMS = (List<Long>) params.get(4);

        // Build set of control measure ids and deselected entities
        Set<Long> selectedCMIds = new HashSet();
        if (!selectedCMS.isEmpty()) {
            selectedCMIds.addAll(selectedCMS);
        }

        ArrayList<GEnemyEngagementMetricsResults> cmoccs
                = DBManager.jDBManager.getEnemyEngagementMetricsResults();

        // Process results
        GEnemyEngagementMetricsResults eeObj;
        long cmId;
        long numEnts;
        long numEngaged;
        long time;
        ArrayList<Object> results = new ArrayList();
        for (Object o : cmoccs) {
            eeObj = (GEnemyEngagementMetricsResults) o;
            cmId = eeObj.getEnemyEngagementMetricsResultsControlMeasureId();

            // Is this control measure info requested?
            if (!selectedCMIds.contains(cmId)) {
                continue;
            }

            time = eeObj.getMetricsResultsTime();
            // Does the time fall into requested range?
            if (time >= startTime && time <= endTime) {
                // Is the hostility correct?
                // Looking for friendly engaging hostile in friendly CM (caller
                // will pass isFriendly) OR hostile engaging friendly in hostile
                // CM (caller will pass not isFriendly)
                boolean cmIsFriendly = DBManager.jDBManager.objectItemIsFriendly(cmId);

                if (isFriendly && !cmIsFriendly || !isFriendly && cmIsFriendly) {
                    continue;
                }
                numEnts = eeObj.getEnemyEngagementMetricsResultsNumberEntities();
                numEngaged = eeObj.getEnemyEngagementMetricsResultsNumberEngaged();

                // Good record
                UIOEnemyEngagementGraphPoint pt
                        = new UIOEnemyEngagementGraphPoint(time,
                                MIDASUtils.applyTimeFormat(
                                        DBManager.jDBManager.getTimeFormat(timeFormat),
                                        time));
                pt.setEntityCount(numEnts);
                pt.setEngagedCount(numEngaged);
                results.add(pt);
            }
        }
        return new RequestResults(results, E_REQUEST_STATUS.SUCCESS);
    }

    public RequestResults getEnemyEngagementEntityDetails(ArrayList<Object> params) {
        Long time = (long) params.get(0);
        Boolean engaged = (Boolean) params.get(1);
        ArrayList<Long> selectedCMS = (ArrayList<Long>) params.get(2);
        HashMap<Long, UIOBase> targetEnts = new HashMap();
        Set<Long> selectedCMIds = new HashSet();
        selectedCMIds.addAll(selectedCMS);

        ArrayList<GEnemyEngagementMetricsResults> results
                = DBManager.jDBManager.getEnemyEngagementMetricsResults();

        for (GEnemyEngagementMetricsResults cpRes : results) {
            long cmId = cpRes.getEnemyEngagementMetricsResultsControlMeasureId();

            // Make sure this control measure is selected
            if (!selectedCMIds.contains(cmId)) {
                continue;
            }
            if (time == cpRes.getMetricsResultsTime()) {
                // Found requested point
                // Get either the engaged or occupying entities
                Set<Long> entSet = null;
                // This will be a comma delimited list of entities
                String entitiesList = engaged ? cpRes.getEnemyEngagementMetricsResultsEngagedEntities()
                        : cpRes.getEnemyEngagementMetricsResultsEntitiesList();
                if (entitiesList != null) {
                    if (!entitiesList.isEmpty()) {
                        entSet = Arrays.stream(entitiesList.split(",")).map(Long::valueOf)
                                .collect(Collectors.toSet());
                    }
                }
                if (entSet != null) {

                    for (Long id : entSet) {
                        UIOBase ei = new UIOBase("", id, 0, 0);
                        targetEnts.put(id, ei);
                    }
                }
            }
        }

        // Now get entity information so that we can set the name on our
        // returned objects
        if (!targetEnts.isEmpty()) {
            ArrayList<AObjectItem> res = DBManager.jDBManager.getEntities();
            for (AObjectItem aoi : res) {
                long id = aoi.getObjectItem().getObjectItemId();
                if (targetEnts.containsKey(id)) {
                    UIOBase ei = targetEnts.get(id);
                    ei.setName(aoi.getObjectItem().getObjectItemNameText());
                    ei.setMilSym(DBManager.jDBManager.getMilitarySymbol(id));
                    ei.setIsFriendly(DBManager.jDBManager.objectItemIsFriendly(id));
                }
            }
        }

        ArrayList<Object> ents = new ArrayList();
        ents.addAll(targetEnts.values());
        return new RequestResults(ents, E_REQUEST_STATUS.SUCCESS);
    }
}
