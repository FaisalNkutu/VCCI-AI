
/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.processors;

/**
 *
 * @author rhans
 */
public class BaseProcessor {
    
    protected static final String COLON = ":";
    
    public BaseProcessor() {
    }
}
