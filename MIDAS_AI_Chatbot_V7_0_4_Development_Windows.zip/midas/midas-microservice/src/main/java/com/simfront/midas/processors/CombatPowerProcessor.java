/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */
package com.simfront.midas.processors;

import com.simfront.midas.constants.MIDASConstants;
import com.simfront.midas.managers.DBManager;
import com.simfront.midas.model.analysis.CombatPowerRecord;
import com.simfront.midas.model.transfermodel.*;
import com.simfront.midas.utils.MIDASUtils;
import com.simfront.midas.utils.RequestResults;
import com.calian.paradigm.core.bto.model.dobjs.DMetricsTimeFormats;
import com.calian.paradigm.core.bto.model.gobjs.gen.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class CombatPowerProcessor extends BaseProcessor {

    public CombatPowerProcessor() {

    }

    public RequestResults getCombatPowerResults(ArrayList<Object> params) {
        System.err.println("Processing getCombatPowerResults");
        if (params.isEmpty()) {
            return new RequestResults(new ArrayList(), MIDASConstants.E_REQUEST_STATUS.GENERAL_FAILURE);
        }
        Map<Long, Boolean> uniqueTimes = new LinkedHashMap<>();

        String timeFormat = (String) params.get(0);
        Long startTime = (Long) params.get(1);
        Long endTime = (Long) params.get(2);
        // Boolean ignoreMinMix = (Boolean)params.get(3};
        Boolean ignoreMinMax = true;

        ArrayList<Long> selectedEnts = (ArrayList<Long>) params.get(3);
        if (selectedEnts == null || selectedEnts.isEmpty()) {
            return new RequestResults(new ArrayList(), MIDASConstants.E_REQUEST_STATUS.SUCCESS);
        }

        ArrayList<GCombatPowerMetricsResults> results
                = DBManager.jDBManager.getCombatPowerMetricsResults();

        if (results == null) {
            return new RequestResults(new ArrayList(), MIDASConstants.E_REQUEST_STATUS.SUCCESS);
        }
        long simTime;
        long objItemId;

        Set<Long> entSet = new HashSet();
        entSet.addAll(selectedEnts);
        ArrayList<Object> reqResults = new ArrayList();

        UIOCombatPowerResults fullResults = new UIOCombatPowerResults();
        double cpower;

        for (GCombatPowerMetricsResults cpr : results) {
            objItemId = cpr.getMetricsResultsObjectItemId();
            if (!entSet.contains(objItemId)) {
                continue;
            }

            // Is it within the requested time range
            simTime = cpr.getMetricsResultsTime();

            if (simTime >= startTime && simTime <= endTime) {
                cpower = cpr.getCombatPowerMetricsResultsCombatPower();
                fullResults.addPoint(
                        cpr.getMetricsResultsObjectItemId(),
                        DBManager.jDBManager.getEntityName(objItemId),
                        simTime,
                        MIDASUtils.applyTimeFormat(
                                DBManager.jDBManager.getTimeFormat(timeFormat),
                                simTime),
                        cpower);
                uniqueTimes.put(simTime, true);
            }
        }
        // Add the average
        fullResults.calcAverage();

        // And unique time array
        UIOTime uiot;
        ArrayList<UIOTime> tArray = new ArrayList();
        for (Long time : uniqueTimes.keySet()) {
            uiot = new UIOTime(time);
            uiot.setFormattedTime(MIDASUtils.applyTimeFormat(
                    DBManager.jDBManager.getTimeFormat(timeFormat),
                    time));
            tArray.add(uiot);
        }
        fullResults.setTimeArray(tArray);

        if (results != null) {
            System.err.println("Returning " + results.size() + " results...");
        }
        reqResults.add(fullResults);
        return new RequestResults(reqResults, MIDASConstants.E_REQUEST_STATUS.SUCCESS);
    }

    public RequestResults getCombatPowerDetails(ArrayList<Object> params) {
        System.err.println("Processing getCombatPowerDetails");
        if (params.isEmpty()) {
            return new RequestResults(new ArrayList(), MIDASConstants.E_REQUEST_STATUS.GENERAL_FAILURE);
        }

        String timeFormat = (String) params.get(0);
        Long time = (Long) params.get(1);
        Long entityId = (Long) params.get(2);

        ArrayList<Object> reqResults = new ArrayList();

        // Collect all required data - first the holdings for this entity
        //ArrayList<GHolding> allholdings = DBManager.jDBManager.getHoldings(entityId, time);
        List<GHolding> allholdings =
                DBManager.jDBManager.getCachedLatestHoldings(entityId, time);

        // Eliminate unimportant holdings
        ArrayList<GHolding> holdings = new ArrayList();

        for (GHolding h : allholdings) {
            GObjectType ot = DBManager.jDBManager.getObjectType(h.getHoldingObjectTypeId());
            if (ot == null) {
                continue;
            }
            if (ot instanceof GMaterielType) {
                GMaterielType mt = (GMaterielType) ot;

                String capabCatCode = mt.getMaterielTypeMaterielCapabilityCategoryCode();
                if (capabCatCode == null
                        || GMaterielType.MATERIEL_TYPE_MATERIEL_CAPABILITY_CATEGORY_CODE_NOS.equals(capabCatCode)) {
                    continue;
                }
                holdings.add(h);
            }
        }
        // Get combat power results for this entity
        ArrayList<GCombatPowerMetricsResults> cpResults
                = DBManager.jDBManager.getCombatPowerMetricsResults(entityId);
        // Get combat power metrics specs so we can get any user specified reference
        // quantities and possible exclusions
        ArrayList<GCombatPowerMetricsSpecification> specs
                = DBManager.jDBManager.getCombatPowerMetricsSpecs(entityId);

        // Get the combat power entry closest or just before the requested time
        long cpowerResultTime;
        long closestTime = 0;
        double cpower = 0;
        long currentDiff = Long.MAX_VALUE;
        for (GCombatPowerMetricsResults cpr : cpResults) {
            cpowerResultTime = cpr.getMetricsResultsTime();

            if (closestTime == 0) {
                closestTime = cpowerResultTime;
                cpower = cpr.getCombatPowerMetricsResultsCombatPower();
            } else {
                if (cpowerResultTime <= time) {
                    if (time - cpowerResultTime < currentDiff) {
                        currentDiff = time - closestTime;
                        closestTime = cpowerResultTime;
                        cpower = cpr.getCombatPowerMetricsResultsCombatPower();
                    }
                } else {
                    // Should be able to quit if the results are time-ordered
                    // Possible improvement if performance slow
                }
            }
        }

        UIOCombatPowerDetail cpd = new UIOCombatPowerDetail(
                entityId,
                DBManager.jDBManager.getEntityName(entityId));
        cpd.setCombatPower(cpower);
        cpd.setSimulationTime(time);
        cpd.setFormattedTime(MIDASUtils.applyTimeFormat(
                DBManager.jDBManager.getTimeFormat(timeFormat),
                time));

        // Cycle holdings, add type name, combat power and build return objects
        boolean include = true;
        long refQty = -1;
        for (GHolding h : holdings) {
            include = true;
            // Is there an applicable spec?
            GCombatPowerMetricsSpecification applicable = getApplicableSpec(
                    specs, time, h.getHoldingObjectTypeId());
            if (applicable != null) {
                String code = applicable.getCombatPowerMetricsSpecificationCategoryCode();
                refQty = applicable.getCombatPowerMetricsSpecificationReferenceQuantity();
                if (GCombatPowerMetricsSpecification.COMBAT_POWER_METRICS_SPECIFICATION_CATEGORY_CODE_EXCLUDE.equals(code)) {
                    include = false;
                }
            }
            if (!include) {
                continue;
            }

            // Get type name
            String typeName = "";
            GObjectType ot = DBManager.jDBManager.getObjectType(h.getHoldingObjectTypeId());
            if (ot != null) {
                typeName = ot.getObjectTypeNameText();
            }
            UIOHolding uioh = new UIOHolding();
            uioh.jEquipmentTypeName = typeName;
            if (ot instanceof GMaterielType) {
                GMaterielType mt = (GMaterielType) ot;
                uioh.jEquipmentTypeCatCode = mt.getMaterielTypeMaterielCapabilityCategoryCode();
            }
            uioh.jCurrentQty = h.getHoldingOperationalCount();
            uioh.jOriginalQty = h.getHoldingTotalQuantity();
            if (applicable != null) {
                uioh.jReferenceQty = refQty;
            }
            cpd.addHolding(uioh);
        }

        reqResults.add(cpd);
        //System.err.println("Returning " + results.size() + " results...");
        return new RequestResults(reqResults, MIDASConstants.E_REQUEST_STATUS.SUCCESS);
    }

    public RequestResults getCombatPowerGroupDetails(ArrayList<Object> params) {
        System.err.println("Processing getCombatPowerDetails");
        if (params.isEmpty()) {
            return new RequestResults(new ArrayList(), MIDASConstants.E_REQUEST_STATUS.GENERAL_FAILURE);
        }

        String timeFormat = (String) params.get(0);
        Long time = (Long) params.get(1);
        ArrayList<Long> selectedEnts = (ArrayList<Long>) params.get(2);
        if (selectedEnts == null || selectedEnts.isEmpty()) {
            return new RequestResults(new ArrayList(), MIDASConstants.E_REQUEST_STATUS.SUCCESS);
        }
        Set<Long> selEntSet = new HashSet();
        selEntSet.addAll(selectedEnts);

        ArrayList<Object> reqResults = new ArrayList();

        // Collect all required data - first the holdings for these entities
        //HashMap<Long, ArrayList<GHolding>> allholdings = DBManager.jDBManager.getHoldings(selectedEnts, time);
        Map<Long, List<GHolding>> allholdings =
                DBManager.jDBManager.getCachedLatestHoldings(selectedEnts, time);

        // Eliminate unimportant holdings for each entity
        HashMap<Long, ArrayList<GHolding>> finalHoldings = new HashMap();
        List<GHolding> holdings;
        ArrayList<GHolding> goodHoldings;

        for (long objItemId : allholdings.keySet()) {
            holdings = allholdings.get(objItemId);
            goodHoldings = new ArrayList();
            for (GHolding h : holdings) {
                GObjectType ot = DBManager.jDBManager.getObjectType(h.getHoldingObjectTypeId());
                if (ot == null) {
                    continue;
                }
                if (ot instanceof GMaterielType) {
                    GMaterielType mt = (GMaterielType) ot;

                    String capabCatCode = mt.getMaterielTypeMaterielCapabilityCategoryCode();
                    if (capabCatCode == null
                            || GMaterielType.MATERIEL_TYPE_MATERIEL_CAPABILITY_CATEGORY_CODE_NOS.equals(capabCatCode)) {
                        continue;
                    }
                    goodHoldings.add(h);
                }
            }
            if (!goodHoldings.isEmpty()) {
                finalHoldings.put(objItemId, goodHoldings);
            }
        }

        // Get combat power results
        ArrayList<GCombatPowerMetricsResults> cpResults
                = DBManager.jDBManager.getCombatPowerMetricsResults();
        // Hash on interested entities
        HashMap<Long, ArrayList<GCombatPowerMetricsResults>> cpHash = new HashMap();
        long objItemId;
        ArrayList<GCombatPowerMetricsResults> metrics;

        for (GCombatPowerMetricsResults cpr : cpResults) {
            objItemId = cpr.getMetricsResultsObjectItemId();

            if (cpHash.containsKey(objItemId)) {
                metrics = cpHash.get(objItemId);
            } else {
                metrics = new ArrayList();
                cpHash.put(objItemId, metrics);
            }
            metrics.add(cpr);
        }

        // Now cycle entities
        for (long entityId : selectedEnts) {
            // Get combat power metrics specs so we can get any user specified reference
            // quantities and possible exclusions
            ArrayList<GCombatPowerMetricsSpecification> specs
                    = DBManager.jDBManager.getCombatPowerMetricsSpecs(entityId);

            // Get combat power entries for this entity
            metrics = cpHash.get(entityId);

            // Get the combat power entry closest or just before the requested time
            long cpowerResultTime;
            long closestTime = 0;
            double cpower = 0;
            long currentDiff = Long.MAX_VALUE;
            if (metrics != null) {
                for (GCombatPowerMetricsResults cpr : metrics) {
                    cpowerResultTime = cpr.getMetricsResultsTime();

                    if (closestTime == 0) {
                        closestTime = cpowerResultTime;
                        cpower = cpr.getCombatPowerMetricsResultsCombatPower();
                    } else {
                        if (cpowerResultTime <= time) {
                            if (time - cpowerResultTime < currentDiff) {
                                currentDiff = time - closestTime;
                                closestTime = cpowerResultTime;
                                cpower = cpr.getCombatPowerMetricsResultsCombatPower();
                            }
                        } else {
                            // Should be able to quit if the results are time-ordered
                            // Possible improvement if performance slow
                        }
                    }
                }
            }

            UIOCombatPowerDetail cpd = new UIOCombatPowerDetail(
                    entityId,
                    DBManager.jDBManager.getEntityName(entityId));
            cpd.setCombatPower(cpower);
            cpd.setSimulationTime(time);
            cpd.setFormattedTime(MIDASUtils.applyTimeFormat(
                    DBManager.jDBManager.getTimeFormat(timeFormat),
                    time));

            // Cycle holdings, add type name, combat power and build return objects
            holdings = finalHoldings.get(entityId);

            if (holdings != null) {
                boolean include = true;
                long refQty = -1;
                for (GHolding h : holdings) {
                    include = true;
                    // Is there an applicable spec?
                    GCombatPowerMetricsSpecification applicable = getApplicableSpec(
                            specs, time, h.getHoldingObjectTypeId());
                    if (applicable != null) {
                        String code = applicable.getCombatPowerMetricsSpecificationCategoryCode();
                        refQty = applicable.getCombatPowerMetricsSpecificationReferenceQuantity();
                        if (GCombatPowerMetricsSpecification.COMBAT_POWER_METRICS_SPECIFICATION_CATEGORY_CODE_EXCLUDE.equals(code)) {
                            include = false;
                        }
                    }
                    if (!include) {
                        continue;
                    }

                    // Get type name
                    String typeName = "";
                    GObjectType ot = DBManager.jDBManager.getObjectType(h.getHoldingObjectTypeId());
                    if (ot != null) {
                        typeName = ot.getObjectTypeNameText();
                    }
                    UIOHolding uioh = new UIOHolding();
                    uioh.jEquipmentTypeName = typeName;
                    if (ot instanceof GMaterielType) {
                        GMaterielType mt = (GMaterielType) ot;
                        uioh.jEquipmentTypeCatCode = mt.getMaterielTypeMaterielCapabilityCategoryCode();
                    }
                    uioh.jCurrentQty = h.getHoldingOperationalCount();
                    uioh.jOriginalQty = h.getHoldingTotalQuantity();
                    if (applicable != null) {
                        uioh.jReferenceQty = refQty;
                    }
                    cpd.addHolding(uioh);
                }

                reqResults.add(cpd);
            }
        }
        //System.err.println("Returning " + results.size() + " results...");
        return new RequestResults(reqResults, MIDASConstants.E_REQUEST_STATUS.SUCCESS);
    }

    private GCombatPowerMetricsSpecification getApplicableSpec(
            ArrayList<GCombatPowerMetricsSpecification> specs,
            long simTime,
            long objTypeId) {
        GCombatPowerMetricsSpecification applicable = null;
        if (specs == null) {
            return null;
        }
        for (GCombatPowerMetricsSpecification s : specs) {
            if (s.getCombatPowerMetricsSpecificationObjectTypeId() == objTypeId) {
                if (applicable != null) {
                    // Is this a later one but still before time of holding
                    if (s.getCombatPowerMetricsSpecificationTime() <= simTime) {
                        if (s.getCombatPowerMetricsSpecificationTime()
                                > applicable.getMetricsSpecificationSimulationStartTime()) {
                            applicable = s;
                        }
                    }
                } else {
                    if (s.getCombatPowerMetricsSpecificationTime() <= simTime) {
                        applicable = s;
                    }
                }
            }
        }
        return applicable;
    }

    /**
     * Builds a time-series breakdown of equipment holdings by capability
     * category for the specified units over the given time range.
     *
     * Steps: 1) Parse & validate inputs. 2) Cache the time-format object once
     * for reuse. 3) Collect and filter all Combat-Power results in one pass. 4)
     * Extract the unique snapshot times. 5) Preload each unit’s specification
     * history, grouped by equipment type. 6) For each snapshot time,
     * batch-fetch all holdings for all units. 7) For each holding: a) Skip
     * non-materiel or “NOS” categories. b) Find the spec active at that time
     * and apply EXCLUDE or ref-qty overrides. c) Accumulate current & original
     * quantities into a nested map: equipmentType → (time →
     * UIOCombatPowerTypeBreakdown). 8) Flatten & sort the nested map into a
     * time-ordered list of breakdowns. 9) Log elapsed time for performance
     * monitoring.
     *
     * @param params [0]=timeFormat key, [1]=startTime, [2]=endTime,
     * [3]=List<Long> unit IDs
     * @return a RequestResults wrapping a List<UIOCombatPowerTypeBreakdown>
     * sorted by time
     */
    public static RequestResults getCombatPowerEquipmentTimeSeries(List<Object> params) {
        System.err.println("getCombatPowerEquipmentTimeSeries");
        try {
            String timeFormat = (String) params.get(0);
            long startTime = (Long) params.get(1);
            long endTime = (Long) params.get(2);
            @SuppressWarnings("unchecked")
            List<Long> entityIds = (List<Long>) params.get(3);

            if (entityIds.isEmpty()) {
                return new RequestResults(new ArrayList<>(), MIDASConstants.E_REQUEST_STATUS.SUCCESS);
            }

            DMetricsTimeFormats fmt = DBManager.jDBManager.getTimeFormat(timeFormat);
            Map<String, Map<Long, UIOCombatPowerTypeBreakdown>> resultMap = new HashMap<>();

            // fetch & filter CP results
            List<GCombatPowerMetricsResults> cpResults
                    = DBManager.jDBManager.getCombatPowerMetricsResults();

            List<GCombatPowerMetricsResults> filteredCpResults = cpResults.stream()
                    .filter(r -> entityIds.contains(r.getMetricsResultsObjectItemId())
                    && r.getMetricsResultsTime() >= startTime
                    && r.getMetricsResultsTime() <= endTime)
                    .collect(Collectors.toList());

            // distinct times
            Set<Long> uniqueTimes = filteredCpResults.stream()
                    .map(GCombatPowerMetricsResults::getMetricsResultsTime)
                    .collect(Collectors.toSet());

            // preload specs
            Map<Long, Map<Long, List<GCombatPowerMetricsSpecification>>> specMapByUnit = new HashMap<>();
            for (Long unitId : entityIds) {
                List<GCombatPowerMetricsSpecification> specs
                        = DBManager.jDBManager.getCombatPowerMetricsSpecs(unitId);
                specMapByUnit.put(unitId,
                        specs.stream().collect(Collectors.groupingBy(
                                GCombatPowerMetricsSpecification::getCombatPowerMetricsSpecificationObjectTypeId
                        )));
            }

            // time-series loop
            for (Long time : uniqueTimes) {
                Map<Long, List<GHolding>> holdingsByUnit
                        = DBManager.jDBManager.getCachedLatestHoldings(entityIds, time);

                for (Long unitId : entityIds) {
                    List<GHolding> holdings = holdingsByUnit.getOrDefault(unitId, Collections.emptyList());
                    if (holdings.isEmpty()) {
                        continue;
                    }

                    Map<Long, List<GCombatPowerMetricsSpecification>> specsByType = specMapByUnit.get(unitId);

                    for (GHolding h : holdings) {
                        long objTypeId = h.getHoldingObjectTypeId();
                        GObjectType ot = DBManager.jDBManager.getObjectType(objTypeId);
                        if (!(ot instanceof GMaterielType)) {
                            continue;
                        }

                        String capabCatCode = ((GMaterielType) ot)
                                .getMaterielTypeMaterielCapabilityCategoryCode();
                        if (capabCatCode == null
                                || GMaterielType.MATERIEL_TYPE_MATERIEL_CAPABILITY_CATEGORY_CODE_NOS.equals(capabCatCode)) {
                            continue;
                        }

                        GCombatPowerMetricsSpecification spec = getApplicableSpec(
                                specsByType.getOrDefault(objTypeId, Collections.emptyList()),
                                time
                        );
                        if (spec != null
                                && GCombatPowerMetricsSpecification.COMBAT_POWER_METRICS_SPECIFICATION_CATEGORY_CODE_EXCLUDE
                                        .equals(spec.getCombatPowerMetricsSpecificationCategoryCode())) {
                            continue;
                        }

                        long origQty = h.getHoldingTotalQuantity();
                        if (spec != null
                                && spec.getCombatPowerMetricsSpecificationReferenceQuantity() != -1) {
                            origQty = spec.getCombatPowerMetricsSpecificationReferenceQuantity();
                        }

                        UIOCombatPowerTypeBreakdown b = resultMap
                                .computeIfAbsent(capabCatCode, k -> new HashMap<>())
                                .computeIfAbsent(time, t -> {
                                    UIOCombatPowerTypeBreakdown x = new UIOCombatPowerTypeBreakdown();
                                    x.setTime(t);
                                    x.setFormattedTime(MIDASUtils.applyTimeFormat(fmt, t));
                                    x.setCurrentQuantity(0);
                                    x.setOriginalQuantity(0);
                                    x.setEquipmentType(capabCatCode);
                                    return x;
                                });

                        b.setCurrentQuantity(b.getCurrentQuantity() + h.getHoldingOperationalCount());
                        b.setOriginalQuantity(b.getOriginalQuantity() + origQty);
                    }
                }
            }

            // flatten & sort
            List<UIOCombatPowerTypeBreakdown> flat = resultMap.values().stream()
                    .flatMap(m -> m.values().stream())
                    .sorted(Comparator.comparingLong(UIOCombatPowerTypeBreakdown::getTime))
                    .collect(Collectors.toList());

            return new RequestResults(new ArrayList<>(flat), MIDASConstants.E_REQUEST_STATUS.SUCCESS);
        } catch (Exception e) {
            return new RequestResults(new ArrayList<>(), MIDASConstants.E_REQUEST_STATUS.GENERAL_FAILURE);
        }
    }

    /**
     * Builds a contribution breakdown of a single equipment category at a given
     * snapshot time.
     *
     * Steps: 1) Unpack & validate inputs. 2) Load all combat-power results
     * once. 3) Identify which units actually have a result at the requested
     * time. 4) Preload each active unit’s spec history, grouped by equipment
     * type. 5) Batch-fetch all holdings for those units at that snapshot. 6)
     * For each unit’s holdings: a) Skip non-materiel types. b) Filter to the
     * selected capability code. c) Lookup the spec active at this time and
     * apply EXCLUDE/ref-qty logic. d) Sum original & current quantities. 7)
     * Build one UIOCombatPowerContribution per unit & accumulate global totals.
     * 8) Format the time, sort by unit ID, and return.
     */
    public static RequestResults getCombatPowerEquipmentContribution(List<Object> params) {
        System.err.println("getCombatPowerEquipmentContribution");
        try {
            // 1) Unpack parameters
            String timeFormatKey = (String) params.get(0);
            DMetricsTimeFormats fmt = DBManager.jDBManager.getTimeFormat(timeFormatKey);
            long requestedTime = ((Number) params.get(1)).longValue();
            @SuppressWarnings("unchecked")
            List<Long> entityIds = (List<Long>) params.get(2);
            String selectedCapab = params.get(3).toString();

            if (entityIds.isEmpty()) {
                return new RequestResults(new ArrayList<>(), MIDASConstants.E_REQUEST_STATUS.SUCCESS);
            }

            // 2) Fetch all Combat-Power results
            List<GCombatPowerMetricsResults> allCp
                    = DBManager.jDBManager.getCombatPowerMetricsResults();

            // 3) Find latest CP time per unit
            Map<Long, Long> latestCPTimeByUnit = new HashMap<>();
            Map<Long, String> unitNames = new HashMap<>();
            for (GCombatPowerMetricsResults r : allCp) {
                long unitId = r.getMetricsResultsObjectItemId();
                long cpTime = r.getMetricsResultsTime();
                if (cpTime <= requestedTime && entityIds.contains(unitId)) {
                    Long prev = latestCPTimeByUnit.get(unitId);
                    if (prev == null || cpTime > prev) {
                        latestCPTimeByUnit.put(unitId, cpTime);
                        unitNames.put(unitId, DBManager.jDBManager.getEntityName(unitId));
                    }
                }
            }

            Set<Long> unitsWithResults = latestCPTimeByUnit.keySet();
            if (unitsWithResults.isEmpty()) {
                return new RequestResults(new ArrayList<>(), MIDASConstants.E_REQUEST_STATUS.SUCCESS);
            }

            // 4) Preload specs per unit/type
            Map<Long, Map<Long, List<GCombatPowerMetricsSpecification>>> specMapByUnit = new HashMap<>();
            for (Long unitId : unitsWithResults) {
                List<GCombatPowerMetricsSpecification> specs
                        = DBManager.jDBManager.getCombatPowerMetricsSpecs(unitId);
                specMapByUnit.put(unitId,
                        specs.stream().collect(Collectors.groupingBy(
                                GCombatPowerMetricsSpecification::getCombatPowerMetricsSpecificationObjectTypeId
                        ))
                );
            }

            // 5) **Use cache** to get latest holdings for each unit up to requestedTime
            Map<Long, List<GHolding>> holdingsByUnit
                    = DBManager.jDBManager.getCachedLatestHoldings(
                            new ArrayList<>(unitsWithResults),
                            requestedTime
                    );

            // 6) Accumulate contributions
            Map<Long, UIOCombatPowerContribution> contribs = new LinkedHashMap<>();
            long totalOrig = 0, totalCurr = 0;
            for (Long unitId : unitsWithResults) {
                List<GHolding> holdings = holdingsByUnit.getOrDefault(unitId, Collections.emptyList());
                if (holdings.isEmpty()) {
                    continue;
                }

                long origSum = 0, currSum = 0;
                Map<Long, List<GCombatPowerMetricsSpecification>> specsByType = specMapByUnit.get(unitId);

                for (GHolding h : holdings) {
                    long typeId = h.getHoldingObjectTypeId();
                    GObjectType ot = DBManager.jDBManager.getObjectType(typeId);
                    if (!(ot instanceof GMaterielType)) {
                        continue;
                    }

                    String code = ((GMaterielType) ot)
                            .getMaterielTypeMaterielCapabilityCategoryCode();
                    if (!selectedCapab.equals(code)) {
                        continue;
                    }

                    GCombatPowerMetricsSpecification spec = getApplicableSpec(
                            specsByType.getOrDefault(typeId, Collections.emptyList()),
                            requestedTime
                    );
                    if (spec != null
                            && GCombatPowerMetricsSpecification.COMBAT_POWER_METRICS_SPECIFICATION_CATEGORY_CODE_EXCLUDE
                                    .equals(spec.getCombatPowerMetricsSpecificationCategoryCode())) {
                        continue;
                    }

                    long hTotal = h.getHoldingTotalQuantity();
                    if (spec != null
                            && spec.getCombatPowerMetricsSpecificationReferenceQuantity() != -1) {
                        hTotal = spec.getCombatPowerMetricsSpecificationReferenceQuantity();
                    }

                    origSum += hTotal;
                    currSum += h.getHoldingOperationalCount();
                }

                if (origSum == 0 && currSum == 0) {
                    continue;
                }

                UIOCombatPowerContribution c = new UIOCombatPowerContribution(
                        requestedTime,
                        unitId,
                        unitNames.get(unitId),
                        origSum,
                        currSum
                );
                String milSym = DBManager.jDBManager.getMilitarySymbol(unitId);
                c.setMilSym(milSym);
                contribs.put(unitId, c);
                totalOrig += origSum;
                totalCurr += currSum;
            }

            // 7) Format, sort, and return
            String fmtTime = MIDASUtils.applyTimeFormat(fmt, requestedTime);
            List<UIOCombatPowerContribution> output = contribs.values().stream()
                    .peek(c -> c.setFormattedTime(fmtTime))
                    .sorted(Comparator.comparingLong(UIOCombatPowerContribution::getUnitId))
                    .collect(Collectors.toList());

            return new RequestResults(new ArrayList<>(output), MIDASConstants.E_REQUEST_STATUS.SUCCESS);

        } catch (Exception ex) {
            ex.printStackTrace();
            return new RequestResults(new ArrayList<>(), MIDASConstants.E_REQUEST_STATUS.GENERAL_FAILURE);
        }
    }

    //analysis
    public static RequestResults getCombatPowerRecord(List<Object> params) {
        System.err.println("getCombatPowerRecord");
        try {
            ArrayList<GCombatPowerMetricsResults> cpResults = DBManager.jDBManager.getCombatPowerMetricsResults();
            //System.out.println("Total CP Results fetched from DB: " + cpResults.size());
            ArrayList<CombatPowerRecord> records = new ArrayList<>();

            Map<Long, GObjectItem> unitCach = new HashMap<>();

            for (GCombatPowerMetricsResults result : cpResults) {
                long unitId = result.getMetricsResultsObjectItemId();
                long time = result.getMetricsResultsTime();
                double cpValue = result.getCombatPowerMetricsResultsCombatPower();

                GObjectItem unit = unitCach.computeIfAbsent(unitId, id -> DBManager.jDBManager.getObjectItem(id));
                if (unit == null) {
                    continue;
                }

                String unitName = unit.getObjectItemNameText();
                // Debug only for INF CO
//                if ("INF CO".equals(unitName)) {
//                    System.out.println("🔍 DEBUG: INF CO CP record -> time=" + time + ", CP=" + cpValue);
//                }

                CombatPowerRecord record = new CombatPowerRecord();
                record.setTime(time);
                record.setUnitName(unitName);
                record.setCombatPower(cpValue);
                record.setFormattedTime(
                        MIDASUtils.applyTimeFormat(DBManager.jDBManager.getTimeFormat("HH:mm"), time)
                );
                //System.out.println("📌 Record: " + unitName + " | Time: " + time + " | CP: " + cpValue);
                records.add(record);
            }
            return new RequestResults(new ArrayList<>(records), MIDASConstants.E_REQUEST_STATUS.SUCCESS);
        } catch (Exception e) {
            e.printStackTrace();
            return new RequestResults(new ArrayList<>(), MIDASConstants.E_REQUEST_STATUS.GENERAL_FAILURE);
        }
    }

    /**
     * From a list of specs for one equipment type, returns the one active at
     * snapshotTime: the spec with the greatest specTime ≤ snapshotTime.
     *
     * @param specs all specs for a given equipment type (may be unsorted)
     * @param snapshotTime the time at which we need the applicable spec
     * @return the spec whose specTime is the latest time ≤ snapshotTime, or
     * null if none apply
     */
    public static GCombatPowerMetricsSpecification getApplicableSpec(
            List<GCombatPowerMetricsSpecification> specs,
            long snapshotTime) {
        GCombatPowerMetricsSpecification best = null;
        for (GCombatPowerMetricsSpecification s : specs) {
            // 1) Read when this spec became active
            long specTime = s.getCombatPowerMetricsSpecificationTime();
            //2) Only consider specs configured at or before our snapshot
            if (specTime <= snapshotTime) {
                // 3) If we don't yet have a 'best', or this one is newer than the current best, pick it
                if (best == null || specTime > best.getCombatPowerMetricsSpecificationTime()) {
                    best = s;
                }
            }
        }
        // 4) Return the most‐recent valid spec (or null if none applied)
        return best;
    }


}
