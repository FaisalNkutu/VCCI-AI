/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */
package com.simfront.midas.processors;

import com.simfront.midas.constants.MIDASConstants.E_REQUEST_STATUS;
import com.simfront.midas.managers.DBManager;
import com.simfront.midas.model.transfermodel.UIOBase;
import com.simfront.midas.model.transfermodel.UIOHHourEntityInfo;
import com.simfront.midas.model.transfermodel.UIOHHourMetricsResult;
import com.simfront.midas.utils.RequestResults;
import com.calian.paradigm.core.bto.model.aobjs.AObjectItem;
import com.calian.paradigm.core.bto.model.dobjs.DObjectItemAssociation;
import com.calian.paradigm.core.bto.model.gobjs.gen.*;

import java.util.*;

/**
 * @author rhans
 */
public class HHourProcessor extends BaseProcessor {

    public HHourProcessor() {}

    public RequestResults getHHourEntities(ArrayList<Object> params) {
        System.err.println("Processing getHHourEntities");
        if (params.isEmpty()) {
            return new RequestResults(new ArrayList<>(), E_REQUEST_STATUS.GENERAL_FAILURE);
        }

        HashMap<Long, UIOBase> targetEntities = new HashMap<>();
        addAllEntities(targetEntities);

        long hhourid = (Long) params.get(0);
        String format = (String) params.get(1);

        long hhourTime = DBManager.jDBManager.getHHourTime(hhourid);
        ArrayList<Object> results =
                DBManager.jDBManager.getHHourMetricsResults(hhourid, format);

        for (Object o : results) {
            UIOHHourMetricsResult hhr = (UIOHHourMetricsResult) o;
            long id = hhr.getOMDBResult().getMetricsResultsObjectItemId();
            double crossingTime = hhr.getOMDBResult().getMetricsResultsTime();
            double diffInMinutes = (crossingTime - hhourTime) / 60000;

            UIOBase uioBase = targetEntities.get(id);
            if (uioBase != null) {
                UIOHHourEntityInfo ei = new UIOHHourEntityInfo(
                        uioBase.getName(),
                        id,
                        hhr.getOMDBResult().getHhourMetricsResultsLatitudeCoordinate(),
                        hhr.getOMDBResult().getHhourMetricsResultsLongitudeCoordinate(),
                        (long) diffInMinutes);
                ei.setMilSym(uioBase.getMilSym());
                ei.setIsFriendly(uioBase.isIsFriendly());
                ei.setParentId(uioBase.getParentId());
                targetEntities.put(id, ei);
            }
        }

        ArrayList<UIOBase> hhourEntities = new ArrayList<>(targetEntities.values());
        hhourEntities.sort(Comparator.comparing(UIOBase::getName));
        return new RequestResults(new ArrayList<>(hhourEntities), E_REQUEST_STATUS.SUCCESS);
    }

    private void addAllEntities(Map<Long, UIOBase> targetEnts) {
        ArrayList<AObjectItem> allEntities = DBManager.jDBManager.getEntities();
        for (AObjectItem aoi : allEntities) {
            String nameText = aoi.getObjectItem().getObjectItemNameText();
            long id = aoi.getObjectItem().getObjectItemId();
            UIOBase uio = new UIOBase(nameText, id);
            uio.setMilSym(DBManager.jDBManager.getMilitarySymbol(id));
            uio.setIsFriendly(DBManager.jDBManager.objectItemIsFriendly(id));
            GObjectItemPointLocation pointLocation = aoi.getObjectItemPointLocation();
            if (pointLocation != null) {
                uio.setLat(pointLocation.getObjectItemPointLocationLatitudeCoordinate());
                uio.setLon(pointLocation.getObjectItemPointLocationLongitudeCoordinate());
            } else {
                uio.setLat(0);
                uio.setLon(0);
            }
            targetEnts.put(id, uio);
        }

        LinkedList<DObjectItemAssociation> assocs =
                DBManager.jDBManager.getOrgOrgAssociations();
        for (DObjectItemAssociation oia : assocs) {
            long child = oia.getChildObjectItemId();
            long parent = oia.getParentObjectItemId();
            UIOBase uio = targetEnts.get(child);
            if (uio != null) {
                uio.setParentId(parent);
            }
        }
    }

    public RequestResults getHHourPercentage(ArrayList<Object> params) {
        System.err.println("Processing getHHourPercentage");
        if (params.isEmpty()) {
            return new RequestResults(new ArrayList(), E_REQUEST_STATUS.GENERAL_FAILURE);
        }

        long hhourid = (Long) params.get(0);
        long thresholdSetting = (Long) params.get(1);
        List<Long> unitIds = (List<Long>) params.get(2);

        double percentage = DBManager.jDBManager.getHHourPercentage(
                hhourid, thresholdSetting, unitIds);
        return new RequestResults(percentage, E_REQUEST_STATUS.SUCCESS);
    }

    public RequestResults getHHourSpecs(ArrayList<Object> params) {
        System.err.println("Processing getHHourSpecs");
        if (params.isEmpty()) {
            return new RequestResults(new ArrayList(), E_REQUEST_STATUS.GENERAL_FAILURE);
        }
        String format = (String) params.get(0);
        ArrayList<Object> results = DBManager.jDBManager.getHHourSpecs(format);
        if (results != null) {
            System.err.println("Returning " + results.size() + " results...");
        }
        return new RequestResults(results, E_REQUEST_STATUS.SUCCESS);
    }
}
