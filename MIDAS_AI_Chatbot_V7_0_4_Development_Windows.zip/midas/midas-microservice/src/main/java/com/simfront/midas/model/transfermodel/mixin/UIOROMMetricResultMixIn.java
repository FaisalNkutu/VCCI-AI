/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel.mixin;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 * @author rhans
 */
public abstract class UIOROMMetricResultMixIn extends UIOMetricsResultMixIn {

    @JsonProperty("speed")
    public abstract double getSpeedRate();

    @JsonProperty("cumulative")
    public abstract double getCumulativeDistance();
}
