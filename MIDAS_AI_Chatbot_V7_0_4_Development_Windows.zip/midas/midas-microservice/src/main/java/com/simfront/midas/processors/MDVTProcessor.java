package com.simfront.midas.processors;

import com.simfront.midas.constants.MIDASConstants;
import com.simfront.midas.managers.DBManager;
import com.simfront.midas.utils.RequestResults;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class MDVTProcessor {

    private static final Map<String, Function<DBManager.MDVTRecord, Object>> FIELDS = Map.of(
            "traineeId", DBManager.MDVTRecord::traineeName,
            "traineeName", DBManager.MDVTRecord::traineeName,
            "position", DBManager.MDVTRecord::position,
            "vehicleName", DBManager.MDVTRecord::vehicleName
    );

    private static final Set<String> NUMERIC_FIELDS = Set.of(
            "traineeId"
    );

    public RequestResults getAggregatedMDVTRecords(ArrayList<Object> params) {

        String metric = (String) params.get(0);

        @SuppressWarnings("unchecked")
        List<String> groupby = (List<String>) params.get(1);

        String method = ((String) params.get(2)).toUpperCase();

        String filters = (String) params.get(3);

        List<DBManager.MDVTRecord> records =
                DBManager.jDBManager.getMDVTRecords();

        Map<String, Set<String>> parsedFilters = parseFilters(filters);

        if (!Set.of("SUM", "AVG", "COUNT").contains(method)) {
            throw new IllegalArgumentException(
                    "method must be SUM, AVG, or COUNT");
        }

        if (!FIELDS.containsKey(metric)) {
            throw new IllegalArgumentException(
                    "Unknown metric: " + metric);
        }

        // AVG/SUM can only be used for numeric metrics
        if (!NUMERIC_FIELDS.contains(metric)
                && !"COUNT".equals(method)) {
            throw new IllegalArgumentException(
                    "String metrics only support COUNT");
        }

        records = records.stream()
                .filter(record -> {
                    for (var filter : parsedFilters.entrySet()) {
                        String value = String.valueOf(
                                FIELDS.get(filter.getKey()).apply(record));

                        if (!filter.getValue().contains(value)) {
                            return false;
                        }
                    }
                    return true;
                })
                .toList();

        Map<List<Object>, List<DBManager.MDVTRecord>> groups =
                records.stream()
                        .collect(Collectors.groupingBy(
                                record -> groupby.stream()
                                        .map(field ->
                                                FIELDS.get(field).apply(record))
                                        .toList()
                        ));

        ArrayList<Object> results = new ArrayList<>();

        for (Map.Entry<List<Object>, List<DBManager.MDVTRecord>> entry
                : groups.entrySet()) {

            List<Object> groupValues = entry.getKey();
            List<DBManager.MDVTRecord> groupRecords = entry.getValue();

            Map<String, Object> row = new LinkedHashMap<>();

            for (int i = 0; i < groupby.size(); i++) {
                row.put(groupby.get(i), groupValues.get(i));
            }

            switch (method) {
                case "COUNT":
                    row.put("count", groupRecords.size());
                    break;

                case "SUM":
                    double sum = groupRecords.stream()
                            .mapToDouble(record ->
                                    ((Number) FIELDS.get(metric)
                                            .apply(record))
                                            .doubleValue())
                            .sum();

                    row.put("sum", sum);
                    break;

                case "AVG":
                    double avg = groupRecords.stream()
                            .mapToDouble(record ->
                                    ((Number) FIELDS.get(metric)
                                            .apply(record))
                                            .doubleValue())
                            .average()
                            .orElse(0);

                    row.put("avg", avg);
                    break;

                default:
                    throw new IllegalArgumentException(
                            "Unsupported method: " + method);
            }

            results.add(row);
        }

        return new RequestResults(
                results,
                MIDASConstants.E_REQUEST_STATUS.SUCCESS
        );
    }

    private Map<String, Set<String>> parseFilters(String filters) {

        if (filters == null || filters.isBlank()) {
                return Map.of();
        }

        return Arrays.stream(filters.split(","))
                .map(filter -> filter.split(":", 2))
                .collect(Collectors.toMap(
                        parts -> parts[0],
                        parts -> Set.of(parts[1].split("\\|"))
                ));
    }
}