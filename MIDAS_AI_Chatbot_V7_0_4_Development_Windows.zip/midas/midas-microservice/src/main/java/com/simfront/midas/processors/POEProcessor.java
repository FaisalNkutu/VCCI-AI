/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */
package com.simfront.midas.processors;

import com.simfront.midas.constants.MIDASConstants.E_REQUEST_STATUS;
import com.simfront.midas.managers.DBManager;
import com.simfront.midas.model.ControlMeasureInfo;
import com.simfront.midas.model.transfermodel.UIOPictureOfEnemy;
import com.simfront.midas.utils.MIDASUtils;
import com.simfront.midas.utils.RequestResults;
import com.calian.paradigm.core.bto.model.aobjs.AObjectItem;
import com.calian.paradigm.core.bto.model.gobjs.gen.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author rhans
 */
public class POEProcessor extends BaseProcessor {

    public POEProcessor() {

    }

    /**
     * We have to process the results (which are for each control measure) into
     * a summary by time of all control measures in that time slot - one entry
     * for friendly, one for hostile (both may not exist)
     *
     * @param params
     * @return
     */
    public RequestResults getPOEResults(ArrayList<Object> params) {
        System.err.println("Processing getPOEResults");
        if (params.isEmpty()) {
            return new RequestResults(new ArrayList(), E_REQUEST_STATUS.GENERAL_FAILURE);
        }

        // Time is hash key
        LinkedHashMap<Long, UIOPictureOfEnemy> friendlyCount = new LinkedHashMap();
        LinkedHashMap<Long, UIOPictureOfEnemy> hostileCount = new LinkedHashMap();

        // So we only look up hostility once for each control feature
        HashMap<Long, Boolean> ctrlFeatIsFriendlyHash = new HashMap();

        String format = (String) params.get(0);
        ArrayList<Object> results = DBManager.jDBManager.getPOEMetricsResults();
        long cmId;
        long objItemId;
        boolean cmIsFriendly = false;
        long time;
        AObjectItem cfeatObj;
        ArrayList<Object> reqResults = new ArrayList();

        LinkedHashMap<Long, UIOPictureOfEnemy> targetHM;
        UIOPictureOfEnemy entry;

        // We will add all the opposite and offside counts for all friendly
        // control measures (by time) and for all hostile control measures. The
        // results from VCCI are separate entries for each control measure.
        GPictureOfEnemyMetricsResults r;
        for (Object obj : results) {
            r = (GPictureOfEnemyMetricsResults) obj;
            cmId = r.getPictureOfEnemyMetricsResultsControlMeasureId();
            objItemId = r.getMetricsResultsObjectItemId();
            if (ctrlFeatIsFriendlyHash.containsKey(cmId)) {
                cmIsFriendly = ctrlFeatIsFriendlyHash.get(cmId);
            } else {
                cfeatObj = DBManager.jDBManager.getAObjectItem(cmId);
                if (cfeatObj != null) {
                    GObjectItemStatus ois = cfeatObj.getObjectItemStatus();
                    if (ois != null) {
                        cmIsFriendly
                                = GObjectItemStatus.OBJECT_ITEM_STATUS_HOSTILITY_CODE_FR.equals(
                                        ois.getObjectItemStatusHostilityCode());
                        ctrlFeatIsFriendlyHash.put(cmId, cmIsFriendly);
                    }
                }
            }
            time = r.getMetricsResultsTime();
            targetHM = cmIsFriendly ? friendlyCount : hostileCount;

            if (targetHM.containsKey(time)) {
                entry = targetHM.get(time);
            } else {
                entry = new UIOPictureOfEnemy();
                targetHM.put(time, entry);
                entry.setFriendlyControlMeasure(cmIsFriendly);
                entry.setSimulationTime(time);
                entry.setFormattedTime(MIDASUtils.applyTimeFormat(
                        DBManager.jDBManager.getTimeFormat(format),
                        time));
            }
            entry.incrementOpposite(r.getPictureOfEnemyMetricsResultsNumberDetectedEntities());
            entry.incrementOffside(r.getPictureOfEnemyMetricsResultsTotalOffsideEntities());
        }

        // Build results - will already be time ordered
        reqResults.addAll(friendlyCount.values());
        reqResults.addAll(hostileCount.values());
        if (results != null) {
            System.err.println("Returning " + results.size() + " results...");
        }
        return new RequestResults(reqResults, E_REQUEST_STATUS.SUCCESS);
    }

    public RequestResults getFilteredPOEResults(ArrayList<Object> params) {
        System.err.println("Processing getFilteredPOEResults");
        if (params.isEmpty()) {
            return new RequestResults(new ArrayList(), E_REQUEST_STATUS.GENERAL_FAILURE);
        }

        // Time is hash key
        LinkedHashMap<Long, UIOPictureOfEnemy> friendlyCount = new LinkedHashMap();
        LinkedHashMap<Long, UIOPictureOfEnemy> hostileCount = new LinkedHashMap();

        // So we only look up hostility once for each control feature
        HashMap<Long, Boolean> ctrlFeatIsFriendlyHash = new HashMap();

        String format = (String) params.get(0);
        // Currently not doing anything with timeInterval (maybe can be done
        // faster in the dashboard?)

        int timeInterval = (int) params.get(1);
        long friendlyStartTime = (long) params.get(2);
        long friendlyEndTime = (long) params.get(3);
        long hostileStartTime = (long) params.get(4);
        long hostileEndTime = (long) params.get(5);

        ArrayList<Long> selectedCMS = (ArrayList<Long>) params.get(6);

        // if no CM is selected, return empty result
        if (selectedCMS.isEmpty()) {
            System.err.println("No control measures selected — returning empty POE results.");
            return new RequestResults(new ArrayList<>(), E_REQUEST_STATUS.SUCCESS);
        }

        Set<Long> selectedCMIds = new HashSet();
        selectedCMIds.addAll(selectedCMS);

        // If this array is empty, we just return everything
        boolean filterOnCMs = !selectedCMIds.isEmpty();

        ArrayList<Object> results
                = DBManager.jDBManager.getPOEMetricsResults();
        long cmId;
        long objItemId;
        boolean cmIsFriendly = false;
        long time;
        AObjectItem cfeatObj;
        ArrayList<Object> reqResults = new ArrayList();

        LinkedHashMap<Long, UIOPictureOfEnemy> targetHM;
        UIOPictureOfEnemy entry;

        // We will add all the opposite and offside counts for all friendly
        // control measures (by time) and for all hostile control measures. The
        // results from VCCI are separate entries for each control measure.
        GPictureOfEnemyMetricsResults r;
        for (Object obj : results) {
            r = (GPictureOfEnemyMetricsResults) obj;
            cmId = r.getPictureOfEnemyMetricsResultsControlMeasureId();

            if (ctrlFeatIsFriendlyHash.containsKey(cmId)) {
                cmIsFriendly = ctrlFeatIsFriendlyHash.get(cmId);
            } else {
                cfeatObj = DBManager.jDBManager.getAObjectItem(cmId);
                if (cfeatObj != null) {
                    GObjectItemStatus ois = cfeatObj.getObjectItemStatus();
                    if (ois != null) {
                        cmIsFriendly
                                = GObjectItemStatus.OBJECT_ITEM_STATUS_HOSTILITY_CODE_FR.equals(
                                        ois.getObjectItemStatusHostilityCode());
                        ctrlFeatIsFriendlyHash.put(cmId, cmIsFriendly);
                    }
                }
            }

            // Apply time filtering
            long t = r.getMetricsResultsTime();

            if (cmIsFriendly) {
                if (t < friendlyStartTime || t > friendlyEndTime) {
                    continue;
                }
            } else {
                if (t < hostileStartTime || t > hostileEndTime) {
                    continue;
                }
            }

            Set<Long> entSet = null;
            // This will be a comma delimited list of entities
            String entitiesList = r.getPictureOfEnemyMetricsResultsDetectionEntitiesList();
            if (entitiesList != null) {
                if (!entitiesList.isEmpty()) {
                    entSet = Arrays.stream(entitiesList.split(",")).map(Long::valueOf)
                            .collect(Collectors.toSet());
                }
            }

            // Check filters
            // Control measure filter
            if (filterOnCMs && !selectedCMIds.contains(cmId)) {
                continue;
            }

            time = r.getMetricsResultsTime();
            targetHM = cmIsFriendly ? friendlyCount : hostileCount;

            if (targetHM.containsKey(time)) {
                entry = targetHM.get(time);
            } else {
                entry = new UIOPictureOfEnemy();
                targetHM.put(time, entry);
                entry.setFriendlyControlMeasure(cmIsFriendly);
                entry.setSimulationTime(time);
                entry.setFormattedTime(MIDASUtils.applyTimeFormat(
                        DBManager.jDBManager.getTimeFormat(format),
                        time));
            }
            entry.incrementOpposite(r.getPictureOfEnemyMetricsResultsNumberDetectedEntities());
            entry.incrementOffside(r.getPictureOfEnemyMetricsResultsTotalOffsideEntities());
        }

        // Build results - will already be time ordered - would apply timeInterval
        // here by taking every nth element based on interval setting (if this is
        // difficult on the front end)
        reqResults.addAll(friendlyCount.values());
        reqResults.addAll(hostileCount.values());
        if (results != null) {
            System.err.println("Returning " + results.size() + " results...");
        }
        return new RequestResults(reqResults, E_REQUEST_STATUS.SUCCESS);
    }

    public RequestResults getPOEControlMeasures() {
        System.err.println("Processing get POE control measures..");
        ArrayList<Object> results = DBManager.jDBManager.getPOEMetricsResults();
        ArrayList<Object> cms = new ArrayList();
        Set<Long> cmSeen = new HashSet();
        GPictureOfEnemyMetricsResults poeRes;
        long cmId;
        for (Object r : results) {
            poeRes = (GPictureOfEnemyMetricsResults) r;
            cmId = poeRes.getPictureOfEnemyMetricsResultsControlMeasureId();
            if (!cmSeen.contains(cmId)) {
                ControlMeasureInfo cmInfo = new ControlMeasureInfo(
                        poeRes.getPictureOfEnemyMetricsResultsControlMeasureName(),
                        cmId
                );

                boolean isFriendly = DBManager.jDBManager.objectItemIsFriendly(cmId);
                cmInfo.setIsFriendly(isFriendly);
                cms.add(cmInfo);
                cmSeen.add(cmId);
            }
        }
        System.err.println("Returning " + cms.size() + " results...");
        return new RequestResults(cms, E_REQUEST_STATUS.SUCCESS);
    }

}
