/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */
package com.simfront.midas.processors;

import com.simfront.midas.constants.MIDASConstants.E_REQUEST_STATUS;
import com.simfront.midas.managers.DBManager;
import com.simfront.midas.model.transfermodel.UIOROMStats;
import com.simfront.midas.utils.RequestResults;
import java.util.*;

/**
 * @author rhans
 */
public class ROMProcessor extends BaseProcessor {

    public ROMProcessor() {

    }

    public RequestResults getROMSpecs(ArrayList<Object> params) {
        System.err.println("Processing getROMSpecs");
        if (params.isEmpty()) {
            return new RequestResults(new ArrayList(), E_REQUEST_STATUS.GENERAL_FAILURE);
        }
        String format = (String) params.get(0);
        ArrayList<Object> results = DBManager.jDBManager.getROMSpecs(format);
        if (results != null) {
            System.err.println("Returning " + results.size() + " results...");
        }
        return new RequestResults(results, E_REQUEST_STATUS.SUCCESS);
    }

    public RequestResults getROMStats(ArrayList<Object> params) {
        System.err.println("Processing getROMStats");
        if (params.isEmpty()) {
            return new RequestResults(new ArrayList<>(), E_REQUEST_STATUS.GENERAL_FAILURE);
        }
        long specId = (Long) params.get(0);
        long startTime = (Long) params.get(1);
        long endTime = (Long) params.get(2);
        List<Long> unitIds = (List<Long>) params.get(3);

        UIOROMStats romStats = DBManager.jDBManager.getRatesOfMovementsStats(
                specId, startTime, endTime, unitIds);
        ArrayList<Object> reqResult = new ArrayList<>();
        reqResult.add(romStats);
        return new RequestResults(reqResult, E_REQUEST_STATUS.SUCCESS);
    }

    public RequestResults getRatesOfMovementResults(ArrayList<Object> params) {
        System.err.println("Processing getROMResults");
        if (params.isEmpty()) {
            return new RequestResults(new ArrayList(), E_REQUEST_STATUS.GENERAL_FAILURE);
        }
        long romSpecId = (long) params.get(0);
        String timeFormat = (String) params.get(1);
        long startTime = (long) params.get(2);
        long endTime = (long) params.get(3);
        List<Long> selectedIds = (List<Long>) params.get(4);

        ArrayList<Object> results = DBManager.jDBManager
                .getRatesOfMovementsMetricsResults(
                        romSpecId, selectedIds, timeFormat, startTime, endTime);
        if (results != null) {
            System.err.println("Returning " + results.size() + " results...");
        }
        return new RequestResults(results, E_REQUEST_STATUS.SUCCESS);
    }
}
