/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */
package com.simfront.midas.processors;

import com.simfront.midas.constants.MIDASConstants;
import com.simfront.midas.constants.MIDASConstants.E_REQUEST_STATUS;
import com.simfront.midas.managers.DBManager;
import static com.simfront.midas.managers.DBManager.jDBManager;
import com.simfront.midas.model.ControlMeasureInfo;
import com.simfront.midas.model.transfermodel.UIOCMEntity;
import com.simfront.midas.model.transfermodel.UIOCMOccupation;
import com.simfront.midas.utils.MIDASUtils;
import com.simfront.midas.utils.RequestResults;
import com.calian.paradigm.core.bto.model.gobjs.gen.*;
import java.util.*;

/**
 * @author rhans
 */
public class CMOccupationProcessor extends BaseProcessor {

    public CMOccupationProcessor() {

    }

    public RequestResults getCMOccControlMeasures() {
        System.err.println("Processing get CMOccupations control measures..");
        ArrayList<Object> results = DBManager.jDBManager.getCMOccupationMetricsResults();
        ArrayList<Object> cms = new ArrayList();
        Set<Long> cmSeen = new HashSet();
        GControlMeasureOccupationMetricsResults occRes;
        long cmId;
        for (Object r : results) {
            occRes = (GControlMeasureOccupationMetricsResults) r;
            cmId = occRes.getControlMeasureOccupationMetricsResultsControlMeasureId();
            if (!cmSeen.contains(cmId)) {
                ControlMeasureInfo cmInfo = new ControlMeasureInfo(
                        occRes.getControlMeasureOccupationMetricsResultsControlMeasureName(),
                        cmId
                );
                boolean isFriendly = jDBManager.objectItemIsFriendly(cmId);
                cmInfo.setIsFriendly(isFriendly);
                cms.add(cmInfo);
                cmSeen.add(cmId);
            }
        }
        System.err.println("Returning " + cms.size() + " results...");
        return new RequestResults(cms, E_REQUEST_STATUS.SUCCESS);
    }

    public RequestResults getCMOccupationsByTime(ArrayList<Object> params) {
        Long startTime = (long) params.get(0);
        Long endTime = (long) params.get(1);
        ArrayList<Long> selectedCMS = (ArrayList<Long>) params.get(2);
        ArrayList<Long> deselectedEnts = (ArrayList<Long>) params.get(3);
        HashMap<Long, ArrayList<UIOCMEntity>> cmIdToEntityListHash = new HashMap();

        // Build set of control measure ids and deselected entities
        Set<Long> selectedCMIds = new HashSet();
        selectedCMIds.addAll(selectedCMS);

        Set<Long> deselectedEntIds = new HashSet();
        deselectedEntIds.addAll(deselectedEnts);

        ArrayList<Object> cmoccs = jDBManager.getCMOccupationMetricsResults();

        // Process results
        GControlMeasureOccupationMetricsResults cmObj;
        long cmId;
        long entId;
        long occEntryTime;
        long occExitTime;
        for (Object o : cmoccs) {
            cmObj = (GControlMeasureOccupationMetricsResults) o;
            cmId = cmObj.getControlMeasureOccupationMetricsResultsControlMeasureId();

            // Is this control measure info requested?
            if (!selectedCMIds.contains(cmId)) {
                continue;
            }

            entId = cmObj.getMetricsResultsObjectItemId();
            // Is this entity selected?
            if (deselectedEntIds.contains(entId)) {
                continue;
            }

            occEntryTime = cmObj.getMetricsResultsTime();
            occExitTime = cmObj.getControlMeasureOccupationMetricsResultsExitTime();
            // Does this entry and exit time put the entity within the current
            // start and end times set by user?
            boolean entityIsIn = false;
            if (occExitTime == -1){
                if (occEntryTime <= endTime) {
                    entityIsIn = true;
                }
            } else {
                if ((startTime <= occExitTime) && (occEntryTime <= endTime)) {
                    entityIsIn = true;
                }
            }
            if (entityIsIn) {
                // Good record
                ArrayList<UIOCMEntity> occupyingEnts;
                if (cmIdToEntityListHash.containsKey(cmId)) {
                    occupyingEnts = cmIdToEntityListHash.get(cmId);
                } else {
                    occupyingEnts = new ArrayList();
                    cmIdToEntityListHash.put(cmId, occupyingEnts);
                }
                String eName = DBManager.jDBManager.getEntityName(entId);
                String milSym = DBManager.jDBManager.getMilitarySymbol(entId);
                if (eName != null) {
                    UIOCMEntity entity = new UIOCMEntity(entId, eName, milSym);
                    occupyingEnts.add(entity);
                }
            }
        }
        ArrayList<Object> results = new ArrayList();
        results.add(cmIdToEntityListHash);
        return new RequestResults(results, E_REQUEST_STATUS.SUCCESS);
    }

    public RequestResults getCMOccupations(ArrayList<Object> params) {
        ArrayList<Long> selectedCMS = (ArrayList<Long>) params.get(0);
        String timeFormat = (String) params.get(1);

        // Using linked hashmap to preserve time based ordering of insertions
        LinkedHashMap<Long, UIOCMOccupation> occHM = new LinkedHashMap();

        // Build set of control measure ids 
        Set<Long> selectedCMIds = new HashSet();
        selectedCMIds.addAll(selectedCMS);

        ArrayList<Object> cmoccs = jDBManager.getCMOccupationMetricsResults();

        // Process results
        GControlMeasureOccupationMetricsResults cmObj;
        long cmId;
        long startTime = DBManager.jDBManager.getEarliestTime();
        // The first point for calculation will be this plus 1 minute
        long currentMinMS = startTime;
        long timeslot;
        long interval = MIDASConstants.MILLISECONDS_IN_MINUTE;

        UIOCMOccupation uiOcc;
        long incidentTime;

        for (Object o : cmoccs) {
            cmObj = (GControlMeasureOccupationMetricsResults) o;
            cmId = cmObj.getControlMeasureOccupationMetricsResultsControlMeasureId();

            if (!selectedCMIds.contains(cmId)) {
                continue;
            }
            incidentTime = cmObj.getMetricsResultsTime();

            // Calculate which time slot this event belongs in
            // Each timeslot is the length of an interval - the key is
            // the beginning time of the timeslot
            timeslot = ((incidentTime - startTime) / interval) + 1;

            // Have we seen any other incidents in this timeslot
            long startOfTimeSlot = startTime + ((timeslot - 1) * interval);

            if (occHM.containsKey(startOfTimeSlot)) {
                uiOcc = occHM.get(startOfTimeSlot);
            } else {
                uiOcc = new UIOCMOccupation();
                uiOcc.setSimulationTime(currentMinMS);
                uiOcc.setFormattedTime(
                        MIDASUtils.applyTimeFormat(
                                DBManager.jDBManager.getTimeFormat(timeFormat),
                                startOfTimeSlot));
                occHM.put(startOfTimeSlot, uiOcc);
            }
            uiOcc.incrementOccupation(cmId, DBManager.jDBManager.getEntityName(cmId), true);
        }
        ArrayList<Object> results = new ArrayList();
        results.add(occHM);
        return new RequestResults(results, E_REQUEST_STATUS.SUCCESS);
    }

    public RequestResults getCMOccupationResults(ArrayList<Object> params) {
        String timeFormat = (String) params.get(0);
        long startTime = (Long) params.get(1);
        long endTime = (Long) params.get(2);
        int mins = (Integer) params.get(3);
        List<Long> filterCMIds = (List<Long>) params.get(4);
        List<Long> deselectedEnts = (List<Long>) params.get(5);

        Set<Long> deselectedSet = new HashSet<>();
        if (deselectedEnts != null) {
            deselectedSet.addAll(deselectedEnts);
        }

        if (mins == -1) {
            mins = 1;
        }
        long interval = mins * MIDASConstants.MILLISECONDS_IN_MINUTE;

        // 1) Gather all control‐measure IDs & names
        Set<Long> cmIDsSet = new HashSet<>();
        HashMap<Long, String> cmNames = new HashMap<>();
//        RequestResults allCMS = getCMOccControlMeasures();
//        if (allCMS != null) {
//            for (Object o : allCMS.getResults()) {
//                ControlMeasureInfo info = (ControlMeasureInfo) o;
//                cmIDsSet.add(info.getId());
//                cmNames.put(
//                        info.getId(),
//                        DBManager.jDBManager.getEntityName(info.getId())
//                );
//            }
//        }
        if (filterCMIds != null && !filterCMIds.isEmpty()) {
            // Only include requested control measures
            for (Long cmId : filterCMIds) {
                cmIDsSet.add(cmId);
                String cmName = DBManager.jDBManager.getEntityName(cmId);
                cmNames.put(cmId, cmName);
            }
        }

        // 2) Prepare time‐ordered map of slots → UIOCMOccupation
        LinkedHashMap<Long, UIOCMOccupation> occHM = new LinkedHashMap<>();

        ArrayList<GControlMeasureOccupationMetricsResults> rows
                = (ArrayList) jDBManager.getCMOccupationMetricsResults();

        // 3) Process each event, with debug logging
        //System.err.println("=== PROCESSING ROWS ===");  
        for (GControlMeasureOccupationMetricsResults cmObj : rows) {
            long cmId = cmObj.getControlMeasureOccupationMetricsResultsControlMeasureId();
            if (!cmIDsSet.contains(cmId)) {
                continue;
            }
            long entryTime = cmObj.getMetricsResultsTime();
            long exitTime = cmObj.getControlMeasureOccupationMetricsResultsExitTime();
            long entId = cmObj.getMetricsResultsObjectItemId();
            // Skip if entity is in deselected list
            if (deselectedSet.contains(entId)) {
                continue;
            }
            //String entName = DBManager.jDBManager.getEntityName(entId);

            // debug: show raw times and decision
            boolean keep
                    = (entryTime < startTime && exitTime == -1)
                    || (entryTime >= startTime && entryTime <= endTime && exitTime == -1)
                    || (exitTime >= startTime && exitTime <= endTime);

//            // now log CM, CM-name, entity ID & name, times, and keep flag
//            System.err.printf(
//                    "CM %d [%s]  Entity %d [%s]: entry=%d exit=%d keep=%b%n",
//                    cmId, cmNames.get(cmId),
//                    entId, entName,
//                    entryTime, exitTime, keep
//            );
            if (!keep) {
                continue;
            }

            // compute slot range
            long firstSlot = ((Math.max(entryTime, startTime) - startTime) / interval) + 1;
            long lastSlot = (exitTime == -1
                    ? ((endTime - startTime) / interval) + 1
                    : ((Math.min(exitTime, endTime) - startTime) / interval) + 1);
            //System.err.printf("  → slots %d through %d%n", firstSlot, lastSlot);

            // bucket into each slot
            for (long slot = firstSlot; slot <= lastSlot; slot++) {
                long slotStart = startTime + (slot - 1) * interval;
                UIOCMOccupation uiOcc = occHM.computeIfAbsent(slotStart, k -> {
                    UIOCMOccupation u = new UIOCMOccupation();
                    u.setSimulationTime(k);
                    u.setFormattedTime(
                            MIDASUtils.applyTimeFormat(
                                    DBManager.jDBManager.getTimeFormat(timeFormat),
                                    k
                            )
                    );
                    return u;
                });
                uiOcc.incrementOccupation(
                        cmId,
                        cmNames.get(cmId),
                        true
                );
            }
        }

        // 4) Debug: dump slot counts before zero-padding (by name)
//        System.err.println("=== SLOT BUCKETS BEFORE ZERO-PADDING ===");
//        for (Map.Entry<Long, UIOCMOccupation> e : occHM.entrySet()) {
//            long slotStart = e.getKey();
//            UIOCMOccupation u = e.getValue();
//            System.err.print("slotStart=" + slotStart + " counts={");
//            for (Occupation occ : u.jOccupationsHM.values()) {
//                System.err.print(occ.getControlMeasureName() + ":" + occ.getEntityCount() + " ");
//            }
//            System.err.println("}");
//        }
        // Traverse all timeslots and insert zero entries for any control measures
        // that were not occupied at each interval
        for (long intervalTime : occHM.keySet()) {
            UIOCMOccupation uiOcc = occHM.get(intervalTime);
            uiOcc.ensureEntriesForAllControlMeasures(cmIDsSet, cmNames);
        }

        // 6) Return the result
        ArrayList<Object> results = new ArrayList<>();
        results.add(occHM);
        return new RequestResults(results, E_REQUEST_STATUS.SUCCESS);
    }
}
