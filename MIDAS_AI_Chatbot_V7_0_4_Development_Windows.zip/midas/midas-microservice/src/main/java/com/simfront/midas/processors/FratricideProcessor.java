/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */
package com.simfront.midas.processors;

import com.calian.common.lib.db.DBConstants;
import com.simfront.midas.constants.MIDASConstants;
import com.simfront.midas.constants.MIDASConstants.E_REQUEST_STATUS;
import com.simfront.midas.managers.DBManager;
import com.simfront.midas.model.transfermodel.UIOFratGraphPoint;
import com.simfront.midas.model.transfermodel.UIOFratricideIncident;
import com.simfront.midas.utils.MIDASUtils;
import com.simfront.midas.utils.RequestResults;
import com.calian.paradigm.core.bto.model.gobjs.gen.*;
import java.util.*;

/**
 * @author rhans
 */
public class FratricideProcessor extends BaseProcessor {

    public FratricideProcessor() {

    }

    public RequestResults getFratricideGraph(ArrayList<Object> params) {
        System.err.println("Processing getFratricideGraph");
        if (params.isEmpty()) {
            return new RequestResults(new ArrayList<>(), E_REQUEST_STATUS.GENERAL_FAILURE);
        }

        Long startTime = (Long) params.get(0);
        Long endTime = (Long) params.get(1);
        Long interval = (Long) params.get(2);
        String format = (String) params.get(3);

        // Passed interval is in minutes
        if (interval <= 0) {
            interval = 1000L;
        } else {
            interval *= MIDASConstants.MILLISECONDS_IN_MINUTE;
        }

        ArrayList<GFratricideMetricsResults> results =
                DBManager.jDBManager.getFratricideMetricsResults();

        ArrayList<Object> reqResults = new ArrayList<>();
        long incidentTime;

        // MAGI: Not currently being used for anything
        long simstarttime = 0;

        // Key for this hashmap will beginning time of each interval
        HashMap<Long, UIOFratGraphPoint> incidentsByTimeSlot = new HashMap<>();
        long timeslot;

        // If we have duplicate events, we will filter them here
        // Key: CATCODE:SRCENT:TIME:TARGETID:TARGETLON:TARGETLAST
        Set<String> seen = new HashSet<>();
        String fratKey;

        for (GFratricideMetricsResults r : results) {
            incidentTime = r.getMetricsResultsTime();
            if (simstarttime == 0) {
                simstarttime = r.getMetricsResultsSimulationStartTime();
            }
            // If incident is out of range - ignore
            if (incidentTime < startTime || incidentTime > endTime) {
                continue;
            }
            fratKey = genFratKey(r);

            if (seen.contains(fratKey)) {
                continue;
            }
            seen.add(fratKey);

            // Calculate which time slot this event belongs in
            // Each timeslot is the length of an interval - the key is
            // the beginning time of the timeslot
            timeslot = ((incidentTime - startTime) / interval) + 1;

            // Have we seen any other incidents in this timeslot
            UIOFratGraphPoint p = null;
            long startOfTimeSlot = startTime + ((timeslot - 1) * interval);
            if (incidentsByTimeSlot.containsKey(startOfTimeSlot)) {
                p = incidentsByTimeSlot.get(startOfTimeSlot);
            } else {
                p = new UIOFratGraphPoint(startOfTimeSlot,
                        MIDASUtils.applyTimeFormat(
                                DBManager.jDBManager.getTimeFormat(format),
                                startOfTimeSlot));
                incidentsByTimeSlot.put(startOfTimeSlot, p);
                reqResults.add(p);
            }
            p.incrementCount();
        }

        return new RequestResults(reqResults, E_REQUEST_STATUS.SUCCESS);
    }

    private String genFratKey(GFratricideMetricsResults r) {
        String fratKey = "";
        Long firerId = r.getMetricsResultsObjectItemId();
        fratKey += r.getFratricideMetricsResultsCategoryCode();
        fratKey += COLON;
        fratKey += firerId;
        fratKey += COLON;
        fratKey += r.getMetricsResultsTime();
        fratKey += COLON;
        fratKey += r.getFratricideMetricsResultsReceivingObjectItemId();
        fratKey += COLON;
        fratKey += r.getFratricideMetricsResultsTargetLongitude();
        fratKey += COLON;
        fratKey += r.getFratricideMetricsResultsTargetLatitude();
        return fratKey;
    }

    public RequestResults getFratricideIncidentsAtTime(ArrayList<Object> params) {
        System.err.println("Processing getFratricideResults");
        if (params.isEmpty()) {
            return new RequestResults(new ArrayList<>(), E_REQUEST_STATUS.GENERAL_FAILURE);
        }

        long time = (Long) params.get(0);
        // We add interval to the start time (just like we do in the request
        // to get graph points) so that the time here aligns with the graph call
        long interval = (Long) params.get(1);
        String format = (String) params.get(2);
        long startTime = (time < 0) ? 0 : time;
        long endTime = time + (interval * MIDASConstants.MILLISECONDS_IN_MINUTE);

        ArrayList<GFratricideMetricsResults> results =
                DBManager.jDBManager.getFratricideMetricsResults();

        ArrayList<Object> reqResults = new ArrayList<>();
        // If we have duplicate events, we will filter them here
        // Key: CATCODE:SRCENT:TIME:TARGETID:TARGETLON:TARGETLAST
        Set<String> seen = new HashSet<>();
        for (GFratricideMetricsResults r : results) {
            long incidentTime = r.getMetricsResultsTime();
            if (incidentTime < startTime || incidentTime > endTime) {
                continue;
            }

            String fratKey = genFratKey(r);
            if (seen.contains(fratKey)) {
                continue;
            }
            seen.add(fratKey);

            long firingEntityId = r.getMetricsResultsObjectItemId();
            long receivingEntityId = r.getFratricideMetricsResultsReceivingObjectItemId();
            long targetEntityId = r.getFratricideMetricsResultsTargetObjectItemId();
            String targetEntityName = null;
            String targetEntityMilSym = null;
            if (targetEntityId > 0 && DBManager.jDBManager.objectItemIsHostile(targetEntityId)) {
                targetEntityName = DBManager.jDBManager.getEntityName(targetEntityId);
                targetEntityMilSym = DBManager.jDBManager.getMilitarySymbol(targetEntityId);
            }

            UIOFratricideIncident fratIncident = new UIOFratricideIncident(
                    DBManager.jDBManager.getEntityName(firingEntityId),
                    r.getFratricideMetricsResultsFratricideMetricsResultId(),
                    r.getFratricideMetricsResultsFiringEntityLatitude(),
                    r.getFratricideMetricsResultsFiringEntityLongitude());
            fratIncident.setMilSym(DBManager.jDBManager.getMilitarySymbol(firingEntityId));
            fratIncident.setTime(incidentTime);
            fratIncident.setFormattedTime(
                    MIDASUtils.applyTimeFormat(
                            DBManager.jDBManager.getTimeFormat(format), time));
            fratIncident.setFireEventId(r.getFratricideMetricsResultsFireEventId());
            fratIncident.setFiringType(r.getFratricideMetricsResultsCategoryCode());
            fratIncident.setTargetEntityName(targetEntityName);
            fratIncident.setTargetEntityMilSym(targetEntityMilSym);
            fratIncident.setTargetLat(r.getFratricideMetricsResultsTargetLatitude());
            fratIncident.setTargetLon(r.getFratricideMetricsResultsTargetLongitude());
            fratIncident.setMunitionMaxLat(r.getFratricideMetricsResultsMunitionMaximumLatitude());
            fratIncident.setMunitionMaxLon(r.getFratricideMetricsResultsMunitionMaximumLongitude());
            fratIncident.setIntersectLat(r.getFratricideMetricsResultsIntersectLatitude());
            fratIncident.setIntersectLon(r.getFratricideMetricsResultsIntersectLongitude());
            fratIncident.setReceivingEntityName(DBManager.jDBManager.getEntityName(receivingEntityId));
            fratIncident.setReceivingEntityMilSym(DBManager.jDBManager.getMilitarySymbol(receivingEntityId));

            fratIncident.setFootprintPoints(
                    r.getFratricideMetricsResultsFootprintPoint1Latitude(),
                    r.getFratricideMetricsResultsFootprintPoint1Longitude(),
                    r.getFratricideMetricsResultsFootprintPoint2Latitude(),
                    r.getFratricideMetricsResultsFootprintPoint2Longitude(),
                    r.getFratricideMetricsResultsFootprintPoint3Latitude(),
                    r.getFratricideMetricsResultsFootprintPoint3Longitude(),
                    r.getFratricideMetricsResultsFootprintPoint4Latitude(),
                    r.getFratricideMetricsResultsFootprintPoint4Longitude());
            reqResults.add(fratIncident);
        }
        return new RequestResults(reqResults, E_REQUEST_STATUS.SUCCESS);
    }

    // Maybe UI could cache the results from previous call and just handle this 
    // one?
    public RequestResults getFratricideIncidentDetails(ArrayList<Object> params) {
        System.err.println("Processing getFratricideDetails");
        if (params.isEmpty()) {
            return new RequestResults(new ArrayList<>(), E_REQUEST_STATUS.GENERAL_FAILURE);
        }

        long fireEventId = (Long) params.get(0);
        String format = (String) params.get(1);

        ArrayList<GFratricideMetricsResults> results =
                DBManager.jDBManager.getFratricideMetricsResults();

        ArrayList<Object> reqResults = new ArrayList<>();

        for (GFratricideMetricsResults r : results) {
            if (r.getFratricideMetricsResultsFireEventId() == fireEventId) {
                long incidentTime = r.getMetricsResultsTime();
                long firingEntityId = r.getMetricsResultsObjectItemId();
                long receivingEntityId = r.getFratricideMetricsResultsReceivingObjectItemId();
                long targetEntityId = r.getFratricideMetricsResultsTargetObjectItemId();
                String targetEntityName = null;
                String targetEntityMilSym = null;
                if (targetEntityId > 0 && DBManager.jDBManager.objectItemIsHostile(targetEntityId)) {
                    targetEntityName = DBManager.jDBManager.getEntityName(targetEntityId);
                    targetEntityMilSym = DBManager.jDBManager.getMilitarySymbol(targetEntityId);
                }

                UIOFratricideIncident fratIncident = new UIOFratricideIncident(
                        DBManager.jDBManager.getEntityName(firingEntityId),
                        r.getFratricideMetricsResultsFratricideMetricsResultId(),
                        r.getFratricideMetricsResultsFiringEntityLatitude(),
                        r.getFratricideMetricsResultsFiringEntityLongitude());

                fratIncident.setMilSym(DBManager.jDBManager.getMilitarySymbol(firingEntityId));
                fratIncident.setTime(incidentTime);
                fratIncident.setFormattedTime(
                        MIDASUtils.applyTimeFormat(
                                DBManager.jDBManager.getTimeFormat(format), incidentTime));
                fratIncident.setFireEventId(fireEventId);
                fratIncident.setFiringType(r.getFratricideMetricsResultsCategoryCode());
                fratIncident.setTargetEntityName(targetEntityName);
                fratIncident.setTargetEntityMilSym(targetEntityMilSym);
                fratIncident.setTargetLat(r.getFratricideMetricsResultsTargetLatitude());
                fratIncident.setTargetLon(r.getFratricideMetricsResultsTargetLongitude());
                fratIncident.setMunitionMaxLat(r.getFratricideMetricsResultsMunitionMaximumLatitude());
                fratIncident.setMunitionMaxLon(r.getFratricideMetricsResultsMunitionMaximumLongitude());
                fratIncident.setIntersectLat(r.getFratricideMetricsResultsIntersectLatitude());
                fratIncident.setIntersectLon(r.getFratricideMetricsResultsIntersectLongitude());
                fratIncident.setReceivingEntityName(DBManager.jDBManager.getEntityName(receivingEntityId));
                fratIncident.setReceivingEntityMilSym(DBManager.jDBManager.getMilitarySymbol(receivingEntityId));

                fratIncident.setFootprintPoints(
                        r.getFratricideMetricsResultsFootprintPoint1Latitude(),
                        r.getFratricideMetricsResultsFootprintPoint1Longitude(),
                        r.getFratricideMetricsResultsFootprintPoint2Latitude(),
                        r.getFratricideMetricsResultsFootprintPoint2Longitude(),
                        r.getFratricideMetricsResultsFootprintPoint3Latitude(),
                        r.getFratricideMetricsResultsFootprintPoint3Longitude(),
                        r.getFratricideMetricsResultsFootprintPoint4Latitude(),
                        r.getFratricideMetricsResultsFootprintPoint4Longitude());
                reqResults.add(fratIncident);
            }
        }
        return new RequestResults(reqResults, E_REQUEST_STATUS.SUCCESS);
    }
}
