
/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.requests;

/**
 *
 * @author rhans
 */
public class JSONPostRequest {
    // Placeholder (and reminder to use non-j-starting variables in
    // derived classes
}
