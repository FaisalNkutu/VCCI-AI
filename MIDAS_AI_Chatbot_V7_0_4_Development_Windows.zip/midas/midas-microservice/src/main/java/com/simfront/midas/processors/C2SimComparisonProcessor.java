/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.processors;

import com.calian.common.lib.log.Log;
import com.simfront.midas.constants.MIDASConstants;
import com.simfront.midas.managers.DBManager;
import com.simfront.midas.model.transfermodel.UIOBase;
import com.simfront.midas.model.transfermodel.UIOC2SimContext;
import com.simfront.midas.utils.ObjectConverterUtil;
import com.simfront.midas.utils.RequestResults;
import com.calian.paradigm.core.bto.model.aobjs.AObjectItem;
import com.calian.paradigm.core.bto.model.aobjs.metrics.AMetObjectItem;
import com.calian.paradigm.core.bto.model.gobjs.gen.*;
import com.calian.paradigm.core.mapping.MilStd2525bGenerator;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

/**
 * @author p.kuczera
 */
public class C2SimComparisonProcessor extends BaseProcessor {

    private static final Logger jL = Log.getLogger(C2SimComparisonProcessor.class);

    private final HashMap<Long, GContext> jVcciContextCache = new HashMap<>();
    private final HashMap<Long, GMetContext> jMetContextCache = new HashMap<>();

    public C2SimComparisonProcessor() {}

    public RequestResults getContextInfo() {
        List<GContext> vcciContextInfo = DBManager.jDBManager.getVcciContextInfo();
        List<GMetContext> metContextInfo = DBManager.jDBManager.getMetContextInfo();
        if (vcciContextInfo != null && metContextInfo != null) {
            ArrayList<Object> uioContexts = new ArrayList<>();
            for (GContext context : vcciContextInfo) {
                UIOC2SimContext uioc2SimContext =
                        new UIOC2SimContext(
                                context.getContextId(),
                                context.getContextNameText(),
                                Objects.requireNonNullElse(context.getContextAlias(), ""),
                                ContextType.VCCI_DATA_TYPE.getText());
                uioContexts.add(uioc2SimContext);
                jVcciContextCache.put(context.getContextId(), context);
            }

            for (GMetContext context : metContextInfo) {
                UIOC2SimContext uioc2SimContext =
                        new UIOC2SimContext(
                                context.getMetContextContextId(),
                                context.getMetContextNameText(),
                                Objects.requireNonNullElse(context.getMetContextAlias(), ""),
                                ContextType.MET_DATA_TYPE.getText());
                uioContexts.add(uioc2SimContext);
                jMetContextCache.put(context.getMetContextContextId(), context);
            }

            return new RequestResults(uioContexts, MIDASConstants.E_REQUEST_STATUS.SUCCESS);
        } else {
            return new RequestResults(MIDASConstants.E_REQUEST_STATUS.GENERAL_FAILURE);
        }
    }

    public RequestResults getUnitLocations(ArrayList<Object> params) {
        if (params == null || params.size() != 3) {
            jL.warn("Failed to get Unit Locations. Invalid Parameters!");
            return new RequestResults(MIDASConstants.E_REQUEST_STATUS.GENERAL_FAILURE);
        }

        long timeOffsetMSec = (long) params.get(0);
        long contextId = (long) params.get(1);
        String contextType = (String) params.get(2);
        if (contextType != null) {
            long timeStampMSec = DBManager.jDBManager.getSimulationStartTime() + timeOffsetMSec;
            ContextType type = ContextType.fromString(contextType);
            if (ContextType.VCCI_DATA_TYPE.equals(type)) {
                return getVcciUnitLocations(timeStampMSec, contextId);
            } else if (ContextType.MET_DATA_TYPE.equals(type)) {
                return getMetUnitLocations(timeStampMSec, contextId);
            }
        }

        jL.warn("Failed to get Unit Locations. Invalid context type: " + contextType);
        return new RequestResults(MIDASConstants.E_REQUEST_STATUS.GENERAL_FAILURE);
    }

    private RequestResults getVcciUnitLocations(long timeStampMSec, long contextId) {
        GContext context = jVcciContextCache.get(contextId);
        if (context == null) {
            jL.warn("Failed to get vcci Unit Locations. Could not get GContext!");
            return new RequestResults(MIDASConstants.E_REQUEST_STATUS.GENERAL_FAILURE);
        }

        List<AObjectItem> vcciUnits = DBManager.jDBManager.getVcciUnits(timeStampMSec, context);
        if (vcciUnits != null) {
            ArrayList<Object> uioObjects = new ArrayList<>();
            for (AObjectItem aoi : vcciUnits) {

                GObjectItem objItem = aoi.getObjectItem();
                GObjectItemStatus status = aoi.getObjectItemStatus();
                GObjectItemPointLocation location = aoi.getObjectItemPointLocation();

                if (objItem != null && status != null && location != null) {
                    UIOBase uioBase = new UIOBase();
                    uioBase.setId(objItem.getObjectItemId());
                    uioBase.setName(objItem.getObjectItemNameText());
                    uioBase.setMilSym(getVcciMilStdCode(aoi));
                    uioBase.setIsFriendly(isVcciUnitFriendly(status));
                    uioBase.setLat(location.getObjectItemPointLocationLatitudeCoordinate());
                    uioBase.setLon(location.getObjectItemPointLocationLongitudeCoordinate());
                    uioObjects.add(uioBase);
                }
            }

            return new RequestResults(uioObjects, MIDASConstants.E_REQUEST_STATUS.SUCCESS);
        } else {
            return new RequestResults(MIDASConstants.E_REQUEST_STATUS.GENERAL_FAILURE);
        }
    }

    private String getVcciMilStdCode(AObjectItem aoi) {
        return MilStd2525bGenerator.getMS2525Code(aoi);
    }

    private boolean isVcciUnitFriendly(GObjectItemStatus status) {
        return GObjectItemStatus.OBJECT_ITEM_STATUS_HOSTILITY_CODE_FR.equals(
                status.getObjectItemStatusHostilityCode());
    }

    private RequestResults getMetUnitLocations(long timeStampMSec, long contextId) {
        GMetContext context = jMetContextCache.get(contextId);
        if (context == null) {
            jL.warn("Failed to get metric Unit Locations. Could not get GMetContext!");
            return new RequestResults(MIDASConstants.E_REQUEST_STATUS.GENERAL_FAILURE);
        }

        List<AMetObjectItem> metUnits = DBManager.jDBManager.getMetUnits(timeStampMSec, context);
        if (metUnits != null) {
            ArrayList<Object> uioObjects = new ArrayList<>();
            for (AMetObjectItem amoi : metUnits) {

                GMetObjectItem objItem = amoi.getMetObjectItem();
                GMetObjectItemStatus status = amoi.getMetObjectItemStatus();
                GMetObjectItemPointLocation location = amoi.getMetObjectItemPointLocation();

                if (objItem != null  && status != null && location != null) {
                    UIOBase uioBase = new UIOBase();
                    uioBase.setId(objItem.getMetObjectItemObjectItemId());
                    uioBase.setName(objItem.getMetObjectItemNameText());
                    uioBase.setMilSym(getMetMilStdCode(amoi));
                    uioBase.setIsFriendly(isMetUnitFriendly(status));
                    uioBase.setLat(location.getMetObjectItemPointLocationLatitudeCoordinate());
                    uioBase.setLon(location.getMetObjectItemPointLocationLongitudeCoordinate());
                    uioObjects.add(uioBase);
                }
            }

            return new RequestResults(uioObjects, MIDASConstants.E_REQUEST_STATUS.SUCCESS);
        } else {
            return new RequestResults(MIDASConstants.E_REQUEST_STATUS.GENERAL_FAILURE);
        }
    }

    private String getMetMilStdCode(AMetObjectItem amoi) {
        AObjectItem aoi = ObjectConverterUtil.convertAOI(amoi);
        if (aoi != null) {
            return MilStd2525bGenerator.getMS2525Code(aoi);
        }

        GObjectItemStatus ois = ObjectConverterUtil.convertOIStatus(amoi.getMetObjectItemStatus());
        if (ois != null) {
            return MilStd2525bGenerator.getMS2525Code(ois, MilStd2525bGenerator.DEFAULT_CODE);
        }

        return MilStd2525bGenerator.DEFAULT_CODE;
    }

    private boolean isMetUnitFriendly(GMetObjectItemStatus status) {
        return GMetObjectItemStatus.MET_OBJECT_ITEM_STATUS_HOSTILITY_CODE_FR.equals(
                status.getMetObjectItemStatusHostilityCode());
    }

    private enum ContextType {
        VCCI_DATA_TYPE("VCCI_DATA_TYPE"),
        MET_DATA_TYPE("MET_DATA_TYPE");

        private final String jText;

        ContextType(String text) {
            jText = text;
        }

        public String getText() {
            return jText;
        }

        public static ContextType fromString(String text) {
            for (ContextType type : ContextType.values()) {
                if (type.jText.equalsIgnoreCase(text)) {
                    return type;
                }
            }
            return null;
        }
    }

}
