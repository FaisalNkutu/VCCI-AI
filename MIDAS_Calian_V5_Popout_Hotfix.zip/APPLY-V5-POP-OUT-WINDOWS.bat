@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLY-V5-POP-OUT-WINDOWS.ps1"
if errorlevel 1 echo Hotfix did not complete. No unrelated programs were stopped.
echo.
pause
endlocal
