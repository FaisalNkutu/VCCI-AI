[CmdletBinding()]
param([string]$ProjectRoot='')
$ErrorActionPreference='Stop'
$here=Split-Path -Parent $MyInvocation.MyCommand.Path
$midasRel='midas\midas-frontend\src\app\components\calian-ai\midas-calian-copilot.component.ts'
$calianRel='Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\app.component.ts'
function ValidRoot([string]$folder) {
  return (Test-Path -LiteralPath (Join-Path $folder $midasRel)) -and (Test-Path -LiteralPath (Join-Path $folder $calianRel))
}
if (-not $ProjectRoot) {
  $candidates=@(Get-ChildItem -LiteralPath (Join-Path $env:USERPROFILE 'Downloads') -Recurse -Directory -Depth 5 -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -match 'V4_3' -and (ValidRoot $_.FullName) } |
    Sort-Object LastWriteTime -Descending)
  if ($candidates.Count -lt 1) {
    throw 'Cannot locate extracted V4.3 project under Downloads. Run this script with -ProjectRoot "C:\path\to\extracted\V4.3".'
  }
  $ProjectRoot=$candidates[0].FullName
}
$ProjectRoot=(Resolve-Path -LiteralPath $ProjectRoot).Path
if(-not (ValidRoot $ProjectRoot)) { throw "Invalid V4.3 source folder: $ProjectRoot" }
Write-Host 'Applying MIDAS-Calian V5 pop-out hotfix to:' -ForegroundColor Cyan
Write-Host $ProjectRoot -ForegroundColor White
$backupDir=Join-Path $ProjectRoot ('BACKUPS\V5-POPOUT-'+(Get-Date -Format yyyyMMdd-HHmmss))
New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
Copy-Item -LiteralPath (Join-Path $ProjectRoot $midasRel) -Destination (Join-Path $backupDir 'midas-calian-copilot.component.ts') -ErrorAction Stop
Copy-Item -LiteralPath (Join-Path $ProjectRoot $calianRel) -Destination (Join-Path $backupDir 'calian-app.component.ts') -ErrorAction Stop
Copy-Item -LiteralPath (Join-Path $here 'PATCH\midas-calian-copilot.component.ts') -Destination (Join-Path $ProjectRoot $midasRel) -Force
Copy-Item -LiteralPath (Join-Path $here 'PATCH\calian-app.component.ts') -Destination (Join-Path $ProjectRoot $calianRel) -Force
Write-Host 'V5 pop-out changes applied. The two source files were backed up to:' -ForegroundColor Green
Write-Host $backupDir
Write-Host 'Existing Angular watch servers should recompile automatically.'
Write-Host 'If they do not, restart only this V4.3 development instance using its startup script.' -ForegroundColor Yellow
