# MIDAS–Calian V5 Pop-out Hotfix (for an installed V4.3 project)

Extract the ZIP, then double-click `APPLY-V5-POP-OUT-WINDOWS.bat`.

The script searches for the extracted V4.3 project inside Downloads. It backs up the two affected TypeScript files, replaces them with V5 versions, and leaves existing MIDAS/Calian processes running. Angular watch mode should recompile the changed files; refresh both MIDAS and Calian tabs after recompilation.

If the project is outside Downloads or the script cannot find it, run from PowerShell:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\APPLY-V5-POP-OUT-WINDOWS.ps1" -ProjectRoot "C:\yourctual\V4.3\extractedolder"
```

For a clean installation on a new port group, use the **full V5 ZIP** instead. The hotfix does not change npm/pnpm lockfiles, Angular versions, or launcher ports.
