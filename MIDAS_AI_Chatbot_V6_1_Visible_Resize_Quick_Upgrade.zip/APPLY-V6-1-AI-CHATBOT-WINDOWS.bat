@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLY-V6-1-AI-CHATBOT-WINDOWS.ps1"
set "EC=%ERRORLEVEL%"
echo.
if not "%EC%"=="0" echo Upgrade failed. Please read the error above.
pause
exit /b %EC%
