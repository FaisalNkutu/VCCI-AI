# RabbitMQ integration status

`RabbitMQAgentDiscovery` now extends Calian `AIService`, using its existing
`RabbitMQComm`/`DTOProcessor` and DTO routing rather than guessing RabbitMQ
queue names or serializing an incompatible JSON envelope.

- The constructor of `AIService` initializes its transport.
- `discover()` sends a tracked `GetCommandsRequest` through `AIService.sendData()`.
- `completeList()` receives the correlated response and extracts command data and agent URLs.
- `ChatApp.refreshAgents()` invokes discovery in its background worker, merging results with Python agents.
- Set `AICORE_RABBITMQ_ENABLED=false` to disable RabbitMQ discovery; an optional
  `AICORE_REGISTRY_URL` HTTP fallback remains available.

## Important limitations

This is **source-integrated but not end-to-end tested**. It requires the Calian
`aiservice`, `aicoredata`, `RabbitMQComm`, and their transitive dependencies in
Maven, plus a correctly configured running RabbitMQ/AI Core environment.
The source previously supplied shows `DTOProcessor(this)` and public
`completeList(GetCommandsRequest)`, but the DTOProcessor implementation and
RabbitMQ connection configuration were not supplied. Their compatibility with
this subclass must be verified in the user's environment.

AI Core agents whose URLs are HTTP(S) are sent through the existing HTTP agent
execution path. Non-HTTP agent transports are not yet implemented.

No claim is made that the project was compiled or run against the proprietary
Calian dependencies in this container.
