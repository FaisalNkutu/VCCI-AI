# Standalone Swing AI Chatbot with Calian RabbitMQ agent discovery

Java 21 + Maven. Preserves the Python A2A 1.0 SSE integration and shared conversation context.

## Start

1. Ensure your Calian Paradigm/AI Service 5.2.0-SNAPSHOT artifacts and transitive
   dependencies are installed in your local Maven repository.
2. Start RabbitMQ and AI Core with the same configuration used by Calian AIService.
3. Start the Python AI Service (default `http://127.0.0.1:9999`).
4. Run `mvn clean compile exec:java` in this project directory.
5. Click **Refresh Agents**. Python and RabbitMQ-discovered AI Core agents are merged.

RabbitMQ discovery is enabled by default. Set `AICORE_RABBITMQ_ENABLED=false`
to disable it. `AICORE_REGISTRY_URL` can provide an optional HTTP fallback.

See `INTEGRATION_STATUS.md` for testing limitations and known requirements.
