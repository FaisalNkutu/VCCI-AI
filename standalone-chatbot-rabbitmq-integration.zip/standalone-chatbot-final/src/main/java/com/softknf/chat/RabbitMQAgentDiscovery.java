package com.softknf.chat;

import com.calian.aicoredata.GetCommandsRequest;
import com.calian.paradigm.service.aiservice.AIService;

import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/**
 * Uses Calian's existing RabbitMQComm transport and DTOProcessor via AIService.
 * No invented RabbitMQ exchange, queue, routing key or wire serialization.
 *
 * AIService's constructor starts RabbitMQComm and installs DTOProcessor(this).
 * DTOProcessor calls completeList() when the GetCommandsRequest response arrives.
 * Unlike AIService's default completeList(), this standalone bridge does not
 * require a Paradigm ComponentGroup or FeatureRequestResponse.
 */
public final class RabbitMQAgentDiscovery extends AIService {
    public record Result(Map<String, List<String>> commands, Map<String, String> urls) {}

    private final ConcurrentHashMap<String, CompletableFuture<Result>> pending =
            new ConcurrentHashMap<>();

    public RabbitMQAgentDiscovery() {
        super();
    }

    public Result discover(Duration timeout) throws Exception {
        GetCommandsRequest request = new GetCommandsRequest();
        String tracker = UUID.randomUUID().toString();
        request.setMessageTracker(tracker);
        CompletableFuture<Result> response = new CompletableFuture<>();
        pending.put(tracker, response);
        try {
            // AIService.sendData(BTO) uses the existing DTO header, target
            // 'aicore', targetSegment 'clientagent' and Calian RabbitMQComm.
            sendData(request);
            return response.get(timeout.toMillis(), TimeUnit.MILLISECONDS);
        } finally {
            pending.remove(tracker);
        }
    }

    @Override
    public void completeList(GetCommandsRequest response) throws IOException {
        if (response == null || response.getMessageTracker() == null) return;
        CompletableFuture<Result> future = pending.remove(response.getMessageTracker());
        if (future != null) {
            future.complete(new Result(
                    response.getCommandData() == null ? Map.of() : new java.util.LinkedHashMap<>(response.getCommandData()),
                    response.getAgentURLs() == null ? Map.of() : new java.util.LinkedHashMap<>(response.getAgentURLs())
            ));
        }
    }
}
