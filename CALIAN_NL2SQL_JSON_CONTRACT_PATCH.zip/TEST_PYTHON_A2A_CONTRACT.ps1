# Read-only NL2SQL integration smoke test. No Docker, Python, or Ollama file changes.
param(
  [string]$Endpoint = 'http://127.0.0.1:5022/',
  [string]$Question = 'SELECT * FROM contxt_oi_assoc LIMIT 1'
)
$ErrorActionPreference = 'Stop'
$inner = @{
  GenerateSQL = @{
    Request = 'GenerateSQL'; Query = $Question; options = @{debug = $false; force = $false}
  }
} | ConvertTo-Json -Depth 8 -Compress
$outer = @{
  jsonrpc = '2.0'
  id = [guid]::NewGuid().ToString()
  method = 'message/send'
  params = @{ message = @{
    role = 'user'
    messageId = [guid]::NewGuid().ToString()
    parts = @(@{kind = 'text'; text = $inner})
  }}
} | ConvertTo-Json -Depth 12 -Compress
Write-Host "Testing the original Python GenerateSQL contract at $Endpoint" -ForegroundColor Cyan
try {
  $response = Invoke-RestMethod -Uri $Endpoint -Method Post -Body $outer -ContentType 'application/json' -TimeoutSec 180
  if ($response.error) { throw ("JSON-RPC error: " + ($response.error | ConvertTo-Json -Depth 4 -Compress)) }
  $task = $response.result
  Write-Host "A2A task state: $($task.status.state)"
  $texts = @($task.artifacts | ForEach-Object { $_.parts } | ForEach-Object { $_.text } | Where-Object { $_ })
  if ($texts.Count -eq 0) { throw 'A2A returned no text artifact: cannot verify SQL pipeline.' }
  $body = $texts[-1] | ConvertFrom-Json
  Write-Host "SQL pipeline Success: $($body.Success)" -ForegroundColor $(if($body.Success){'Green'}else{'Yellow'})
  if ($body.Response) {
    Write-Host "SQL execution success: $($body.Response.success)"
    Write-Host "Rows: $($body.Response.row_count)"
    if ($body.Response.error) { Write-Host "Downstream error: $($body.Response.error)" -ForegroundColor Yellow }
  }
  if (-not $body.Success) { Write-Warning 'A2A input contract worked, but SQL generation/validation is still failing downstream.' }
} catch {
  Write-Host "A2A test failed: $($_.Exception.Message)" -ForegroundColor Red
  exit 1
}
