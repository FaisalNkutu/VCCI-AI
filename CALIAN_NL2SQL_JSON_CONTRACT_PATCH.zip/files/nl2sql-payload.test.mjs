// Run with Node >=22: node --experimental-strip-types --test tests/nl2sql-payload.test.mjs
import test from 'node:test';
import assert from 'node:assert/strict';
import {encodeNl2SqlMessage} from '../server/nl2sql-payload.ts';

test('encodes the exact Python NL2SQL GenerateSQL request contract', () => {
  const value = JSON.parse(encodeNl2SqlMessage('SELECT * FROM contxt_oi_assoc LIMIT 10'));
  assert.deepEqual(value, {
    GenerateSQL: {
      Request:'GenerateSQL',
      Query:'SELECT * FROM contxt_oi_assoc LIMIT 10',
      options:{debug:false, force:false}
    }
  });
});
test('preserves question and JSON special characters unchanged', () => {
  const question = 'Show "quotes" and \n newlines?';
  const value = JSON.parse(encodeNl2SqlMessage(question));
  assert.equal(value.GenerateSQL.Query,question);
});
test('rejects blank queries instead of sending malformed A2A text', () => {
  assert.throws(()=>encodeNl2SqlMessage('   '), /non-empty/);
});
