/**
 * Encode the application-level request required by the Python NL2SQL agent.
 * The outer A2A envelope remains JSON-RPC message/send. The A2A text part
 * is a JSON string whose top-level key must be "GenerateSQL".
 *
 * Contract verified against a2a_nl2sql_agent.py and a2a_nl2sql_client.py.
 * Neither the Ollama route nor any non-NL2SQL agent is modified.
 */
export function encodeNl2SqlMessage(query: string): string {
  if (typeof query !== 'string' || !query.trim()) {
    throw new Error('NL2SQL question must be a non-empty string');
  }
  return JSON.stringify({
    GenerateSQL: {
      Request: 'GenerateSQL',
      Query: query,
      options: {debug: false, force: false}
    }
  });
}
