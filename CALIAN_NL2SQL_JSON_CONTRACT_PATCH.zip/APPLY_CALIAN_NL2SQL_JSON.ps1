<#
.SYNOPSIS
Apply only the CALIAN.AI -> Python NL2SQL A2A JSON-text contract fix.
.PARAMETER ProjectRoot
The existing Standalone_Calian_AI_Chatbot folder, its CALIAN_AI_ELECTRON_THEMES
folder, or another folder containing that folder.
.NOTES
Does NOT modify the Python SQL Agent, Ollama, Docker, Java or .env.
Does NOT rebuild a packaged .exe. Restart the Node backend after the patch.
#>
param([string]$ProjectRoot = '')
$ErrorActionPreference = 'Stop'

function Resolve-CalianUi([string]$candidate) {
  if ([string]::IsNullOrWhiteSpace($candidate)) { return $null }
  $clean = $candidate.Trim().Trim('"', "'")
  foreach ($p in @($clean, (Join-Path $clean 'CALIAN_AI_ELECTRON_THEMES'), (Join-Path $clean 'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES'))) {
    if (Test-Path -LiteralPath (Join-Path $p 'server\index.ts') -PathType Leaf) {
      return (Resolve-Path -LiteralPath $p).Path
    }
  }
  return $null
}

$ui = $null
if ($ProjectRoot) {
  $ui = Resolve-CalianUi $ProjectRoot
  if (-not $ui) { throw "Could not find CALIAN_AI_ELECTRON_THEMES\server\index.ts under: $ProjectRoot" }
} else {
  $candidates = @(
    (Get-Location).Path,
    $PSScriptRoot,
    (Split-Path $PSScriptRoot -Parent),
    (Join-Path $HOME 'Downloads\Standalone_Calian_AI_Chatbot'),
    (Join-Path $HOME 'Desktop\Standalone_Calian_AI_Chatbot'),
    (Join-Path $HOME 'Documents\Standalone_Calian_AI_Chatbot')
  )
  $matches = @($candidates | ForEach-Object { Resolve-CalianUi $_ } | Where-Object { $_ } | Select-Object -Unique)
  if ($matches.Count -eq 1) { $ui = $matches[0] }
  if ($matches.Count -gt 1) {
    Write-Host 'Multiple CALIAN project folders found:' -ForegroundColor Yellow
    $matches | ForEach-Object { Write-Host " - $_" }
  }
  if (-not $ui) {
    $answer = Read-Host 'Paste the path to YOUR working Standalone_Calian_AI_Chatbot project folder'
    $ui = Resolve-CalianUi $answer
    if (-not $ui) { throw "Could not locate server\index.ts. No files were modified. Re-run with -ProjectRoot '<your-path>'." }
  }
}

$indexPath = Join-Path $ui 'server\index.ts'
$helperPath = Join-Path $ui 'server\nl2sql-payload.ts'
$testPath = Join-Path $ui 'tests\nl2sql-payload.test.mjs'
$kitHelper = Join-Path $PSScriptRoot 'files\nl2sql-payload.ts'
$kitTest = Join-Path $PSScriptRoot 'files\nl2sql-payload.test.mjs'
if (-not (Test-Path -LiteralPath $kitHelper)) { throw 'Patch ZIP not fully extracted: helper file missing.' }
if (-not (Test-Path -LiteralPath $kitTest)) { throw 'Patch ZIP not fully extracted: test file missing.' }

$orig = [System.IO.File]::ReadAllText($indexPath)
$importAnchor = "import { randomUUID } from 'node:crypto';"
$importLine = "import { encodeNl2SqlMessage } from './nl2sql-payload';"
$before = "parts: [{kind: 'text', text: message}]"
$after = "parts: [{kind: 'text', text: encodeNl2SqlMessage(message)}]"

# Require the real A2A JSON-RPC code path. Do not patch a different CALIAN version.
if (-not $orig.Contains("method: 'message/send'")) { throw 'This CALIAN source does not contain the known A2A message/send branch. Refusing to change it.' }
if (-not $orig.Contains('const isPythonA2A = parsed.port === a2aPort;')) { throw 'The expected Python A2A routing branch is missing. Refusing to change an unknown version.' }
$already = $orig.Contains($after) -and $orig.Contains($importLine)
if (-not $already) {
  if ($orig.Contains($after) -or $orig.Contains($importLine)) { throw 'A partial/modified NL2SQL patch is present; no changes made.' }
  if (-not $orig.Contains($importAnchor)) { throw 'Expected import anchor missing; no changes made.' }
  if (($orig.Split([string[]]@($before),[StringSplitOptions]::None).Count - 1) -ne 1) { throw 'Could not uniquely locate the A2A text-part expression; no changes made.' }
}

# Never overwrite a pre-existing, different helper/test.
if ((Test-Path -LiteralPath $helperPath) -and
    ([System.IO.File]::ReadAllText($helperPath) -ne [System.IO.File]::ReadAllText($kitHelper))) {
  throw 'An existing nl2sql-payload.ts differs from the patch. No changes made.'
}
if ((Test-Path -LiteralPath $testPath) -and
    ([System.IO.File]::ReadAllText($testPath) -ne [System.IO.File]::ReadAllText($kitTest))) {
  throw 'An existing nl2sql-payload.test.mjs differs from the patch. No changes made.'
}

Write-Host "CALIAN project: $ui" -ForegroundColor Cyan
if (-not $already) {
  $backupDir = Join-Path $ui 'CALIAN-A2A-backups'
  New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
  $backup = Join-Path $backupDir ("index-before-nl2sql-json-{0}.ts" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
  Copy-Item -LiteralPath $indexPath -Destination $backup -ErrorAction Stop
  $modified = $orig.Replace($importAnchor, "$importAnchor`n$importLine").Replace($before,$after)
  [System.IO.File]::WriteAllText($indexPath,$modified,[System.Text.UTF8Encoding]::new($false))
  Write-Host "Backup: $backup" -ForegroundColor Green
  Write-Host 'Patched only the Python A2A text-part encoding in server/index.ts.' -ForegroundColor Green
} else {
  Write-Host 'CALIAN A2A JSON contract already patched. No duplicate changes.' -ForegroundColor Green
}
if (-not (Test-Path -LiteralPath $helperPath)) { Copy-Item -LiteralPath $kitHelper -Destination $helperPath }
New-Item -ItemType Directory -Force -Path (Split-Path $testPath -Parent) | Out-Null
if (-not (Test-Path -LiteralPath $testPath)) { Copy-Item -LiteralPath $kitTest -Destination $testPath }

$node = Get-Command node -ErrorAction SilentlyContinue
if ($node) {
  $major = [int]((node --version).Trim().TrimStart('v').Split('.')[0])
  if ($major -ge 22) {
    Push-Location $ui
    try {
      & node --experimental-strip-types --test 'tests/nl2sql-payload.test.mjs'
      if ($LASTEXITCODE -ne 0) { throw 'NL2SQL contract tests failed; inspect backup before continuing.' }
    } finally { Pop-Location }
  } else { Write-Host "Node v$major detected; contract tests require Node >=22. Source change is installed." -ForegroundColor Yellow }
} else { Write-Host 'Node not found; static patch applied but local tests skipped.' -ForegroundColor Yellow }

Write-Host ''
Write-Host 'CALIAN source updated. Restart CALIAN backend to load it.' -ForegroundColor Green
Write-Host 'If using a portable CALIAN AI.exe, rebuild the EXE using your existing Windows build script; the installed EXE was not modified.'
Write-Host 'Python SQL Agent, Ollama, Docker, Java, and environment settings were NOT changed.'
