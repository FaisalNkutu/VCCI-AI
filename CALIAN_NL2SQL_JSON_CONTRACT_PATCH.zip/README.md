# CALIAN.AI -> Python NL2SQL: correct JSON contract

Source baseline: `Standalone_Calian_AI_Chatbot_A2A_DBAgent_Fix.zip` uploaded previously.

## Precisely what changed
- `CALIAN_AI_ELECTRON_THEMES/server/index.ts`: for A2A endpoints on the configured
  `CALIAN_A2A_EXECUTION_PORT` (default 5022), encode the text part using `encodeNl2SqlMessage(message)`.
  The outer JSON-RPC 2.0 `message/send` envelope is unchanged.
- `CALIAN_AI_ELECTRON_THEMES/server/nl2sql-payload.ts`: new helper preserving the
  **original** Python agent contract `{ "GenerateSQL": { "Request": "GenerateSQL", "Query": ...,
  "options": { "debug": false, "force": false } } }` as a serialized JSON string.
- `CALIAN_AI_ELECTRON_THEMES/tests/nl2sql-payload.test.mjs`: three local contract tests.

No Ollama source, Docker service, Python code, SQL validator, Java code, agent auto-selection,
model name, or configuration file is changed by this patch.

## Which endpoint receives the new contract?
Only the execution branch for an agent whose discovered endpoint uses the Python A2A
port (default 5022). If your discovered `DBAgent` endpoint points instead to Java AI Core
on port 8080, this particular branch is not used. Confirm the registered destination
before attributing a failed SQL request to this adapter.

The Python agent's reference client and `a2a_nl2sql_agent.py` both require a top-level
`GenerateSQL` key, not merely `{ "Request": "GenerateSQL", ... }`.

## Running from source
Extract the source ZIP to a separate folder and use its existing
`START-CALIAN-ELECTRON.bat`. Required dependencies must already be installed as for
previous CALIAN builds. Existing packaged `.exe` files are NOT automatically updated:
rebuild the desktop executable via the project's existing Windows build script if needed.

## Existing local working copy
Use `CALIAN_NL2SQL_JSON_CONTRACT_PATCH.zip` and run its installer in your existing
CALIAN project folder (or supply `-ProjectRoot 'C:\path\to\project'`). The installer
backs up only `server/index.ts`, changes one A2A payload expression and adds one helper,
and will not run `npm install`, pull Ollama models or modify Python/Docker.

## Test outcomes to look for
- HTTP 200 and A2A `task state: completed` confirm the protocol call returned.
- The nested A2A artifact has `Success: true` and `Response.success: true` only if SQL
  generation and database execution actually succeeded.
- `Success: false` with SQL validation/model errors is an **independent downstream issue**;
  do not treat it as an adapter regression.

## Restoring Fouad's code
This package does not touch `/app` in `reqa-a2a`, nor Ollama. The earlier A2A
compatibility modifications may remain in that running container. Restoring them requires
reviewing the original dated Docker backups and checking there have been no subsequent edits;
blindly restoring `/app/a2a_nl2sql_agent.py` risks losing other changes. Once the
client-side JSON contract is verified end-to-end, revert those server compatibility changes
from the original backup in a separate, reviewed step if desired.

## Optional direct endpoint test

After the Node backend is restarted, you may run `TEST_PYTHON_A2A_CONTRACT.ps1`
to send the exact structured request directly to the Python A2A service on port 5022.
This **runs** a read-only SQL query through the existing pipeline, but it does not change
Ollama settings or files. A `Success: false` result means the input format was accepted
but SQL generation or validation still needs separate attention.
