# Restore the most recent CALIAN index.ts backup created by APPLY_CALIAN_NL2SQL_JSON.ps1.
param([Parameter(Mandatory=$true)][string]$ProjectRoot)
$ErrorActionPreference = 'Stop'
$root = $ProjectRoot.Trim().Trim('"', "'")
if (Test-Path -LiteralPath (Join-Path $root 'CALIAN_AI_ELECTRON_THEMES\server\index.ts')) {
  $ui = Join-Path $root 'CALIAN_AI_ELECTRON_THEMES'
} elseif (Test-Path -LiteralPath (Join-Path $root 'server\index.ts')) {
  $ui = $root
} else { throw 'Provide the path to CALIAN_AI_ELECTRON_THEMES or its parent folder.' }
$backupDir = Join-Path $ui 'CALIAN-A2A-backups'
$backup = Get-ChildItem -LiteralPath $backupDir -Filter 'index-before-nl2sql-json-*.ts' -File | Sort-Object Name -Descending | Select-Object -First 1
if (-not $backup) { throw 'No CALIAN JSON-contract backup found.' }
$index = Join-Path $ui 'server\index.ts'
$preRollback = Join-Path $backupDir ("index-before-rollback-{0}.ts" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
Copy-Item -LiteralPath $index -Destination $preRollback
Copy-Item -LiteralPath $backup.FullName -Destination $index
Write-Host "Restored server/index.ts from $($backup.FullName)" -ForegroundColor Green
Write-Host 'Helper/test files are intentionally left untouched; unused files are harmless.'
Write-Host 'Restart CALIAN backend to use the restored source.'
