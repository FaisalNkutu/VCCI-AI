@echo off
setlocal EnableExtensions
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js is required & exit /b 1)
node --experimental-strip-types --import "./SETUP_SUPPORT/V7/register-ts-resolver.mjs" --test "SETUP_SUPPORT\V7\voice-v705.test.mjs" "SETUP_SUPPORT\V7\dbagent-v704.test.mjs" "SETUP_SUPPORT\V7\dbagent-v702.test.mjs" "SETUP_SUPPORT\V7\dbagent-v703.test.mjs" "SETUP_SUPPORT\V7\context-actions.test.mjs" "SETUP_SUPPORT\V7\critical-regressions.test.mjs" "Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\server\tests\midas-v7-tools.test.mjs" "Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\server\tests\agent-chain.test.mjs"
set "STATUS=%ERRORLEVEL%"
echo.
if %STATUS% neq 0 (echo V7 checks failed & pause & exit /b %STATUS%)
echo V7.0.5 source checks passed. These do not replace Windows browser and private registry testing.
pause
endlocal
