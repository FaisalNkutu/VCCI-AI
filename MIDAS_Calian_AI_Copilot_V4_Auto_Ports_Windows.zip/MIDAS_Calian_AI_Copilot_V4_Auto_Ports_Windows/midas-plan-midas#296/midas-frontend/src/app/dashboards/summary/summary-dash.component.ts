import { SummaryState } from '@/models/summary.model';
import { routes } from '@/utils/routes';
import { CommonModule } from '@angular/common';
import { Component, computed, input } from '@angular/core';
import { MatBadgeModule } from '@angular/material/badge';
import { MatCardModule } from '@angular/material/card';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatTooltipModule } from '@angular/material/tooltip';
import { RouterLink } from '@angular/router';

interface ProcessorStatus {
  name: string;
  active: boolean;
  reason: string;
}

@Component({
  selector: 'summary-dash',
  imports: [
    MatGridListModule,
    MatCardModule,
    MatListModule,
    CommonModule,
    MatIconModule,
    MatTooltipModule,
    RouterLink,
    MatBadgeModule,
  ],
  templateUrl: './summary-dash.component.html',
  styles: [
    `
      ::ng-deep .mdc-list-item {
        height: auto !important;
      }
    `,
  ],
})
export class SummaryDashComponent {
  summaryData = input.required<SummaryState>();
  statusData = input.required<ProcessorStatus[]>();

  activeCount = computed(() => this.statusData().filter((p) => p.active && !p.reason).length);
  warningCount = computed(() => this.statusData().filter((p) => p.active && p.reason).length);
  inactiveCount = computed(() => this.statusData().filter((p) => !p.active).length);

  routes = routes;

  constructor() {}
}
