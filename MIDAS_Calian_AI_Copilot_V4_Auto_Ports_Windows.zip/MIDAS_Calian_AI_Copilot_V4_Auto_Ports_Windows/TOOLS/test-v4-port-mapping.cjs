// Offline V4 configuration tests. Runs on Node.js alone, without npm install.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.resolve(__dirname,'..');
const midasSrc=fs.readFileSync(path.join(root,'midas-plan-midas#296/midas-frontend/src/assets/calian-embed-config.js'),'utf8');
const calianSrc=fs.readFileSync(path.join(root,'Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/public/midas-bridge-config.js'),'utf8');
const proxySrc=fs.readFileSync(path.join(root,'Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/proxy.conf.cjs'),'utf8');
function midas(port,hostname='127.0.0.1'){
 const window={location:{hostname,port:String(port)}};
 vm.runInNewContext(midasSrc,{window},{timeout:1000});
 return window.__MIDAS_CALIAN_EMBED_URL__;
}
function calian(port,hostname='127.0.0.1'){
 const location={hostname,port:String(port)};
 const window={};
 vm.runInNewContext(calianSrc,{location,window},{timeout:1000});
 return Array.from(window.__CALIAN_MIDAS_ALLOWED_ORIGINS__);
}
for(const n of [0,1,2,35,99]){
 assert.equal(midas(4200+n),`http://127.0.0.1:${4300+n}/`);
 assert.deepEqual(calian(4300+n),[`http://127.0.0.1:${4200+n}`,`http://localhost:${4200+n}`]);
}
for(const n of [4199,4300,5000])assert.equal(midas(n),'');
assert.equal(midas(4201,'remote.example'),'');
assert.deepEqual(calian(4301,'remote.example'),[]);
assert.deepEqual(calian(4400),[]);
function proxyFor(port){
 let result;
 const context={module:{exports:{}},process:{env:{CALIAN_BACKEND_PORT:String(port)}},Number,Error,require:(s)=>({config:()=>{}})};
 vm.runInNewContext(proxySrc,context,{timeout:1000});result=context.module.exports;
 return result;
}
for(const port of [8797,8798,8803,8896]){
 const proxy=proxyFor(port);
 assert.equal(proxy['/api'].target,`http://127.0.0.1:${port}`);
 assert.equal(proxy['/ws'].target,`http://127.0.0.1:${port}`);
 assert.equal(proxy['/ws'].ws,true);
}
const sock=fs.readFileSync(path.join(root,'Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/src/app/socket.service.ts'),'utf8');
assert.match(sock,/location\.host}\/{0,1}ws/);
assert.doesNotMatch(sock,/location\.port==='4300'/);
const launcher=fs.readFileSync(path.join(root,'SETUP-AND-RUN-WINDOWS.ps1'),'utf8');
assert.match(launcher,/ChoosePortFamily/);
assert.match(launcher,/PortFree/);
assert.match(launcher,/CALIAN_BACKEND_PORT=/);
assert.match(launcher,/CALIAN_UI_ORIGIN=/);
assert.doesNotMatch(launcher, /Stop-Process|taskkill|Stop-Service/i);
console.log('PASS: 21 local mapping/origin tests plus proxy and launcher invariants.');
