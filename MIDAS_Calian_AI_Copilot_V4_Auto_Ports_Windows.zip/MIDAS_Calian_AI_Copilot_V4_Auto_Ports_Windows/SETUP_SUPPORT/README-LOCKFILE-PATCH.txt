MIDAS pnpm lockfile migration notes, 2026-11-24.

Original lockfile: SETUP_SUPPORT/pnpm-lock.original-unmodified.yaml
Current lockfile: midas-plan-midas#296/midas-frontend/pnpm-lock.yaml

Changes:
- Removed exactly 12 explicit tarball URL fields referring to the legacy
  https://artifactory.ci.simfront.com/artifactory/api/npm/npmjs-org/ path.
- Preserved all package versions and all 712 SHA-512 integrity entries.
- No changes to package.json dependency constraints.
- Created a local MIDAS frontend .npmrc selecting the approved
  sf-npm-group repository for registry and @simfront scope.
- No credential, token, password, or certificate is included.

This is intended to resolve the specific URL mismatch seen in screenshots.
A remaining registry policy, missing credentials, or mismatched metadata may
still block frozen installation; do NOT bypass integrity checks.
