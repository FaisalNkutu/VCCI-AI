@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 (echo Python launcher missing. Install Python 3.13 x64. & pause & exit /b 1)
py -3.13 -c "import sys; print(sys.version)" >nul 2>&1
if errorlevel 1 (echo Python 3.13 x64 required for this build. Python 3.14 cannot be used with the installed PyInstaller. & pause & exit /b 1)
py -3.13 -m pip install -r "PYTHON_BACKEND\requirements-local.txt" pyinstaller
if errorlevel 1 (echo Python dependency installation failed & pause & exit /b 1)
py -3.13 -m PyInstaller --noconfirm --clean --onefile --name calian-router --distpath "python-router-dist" --workpath "python-router-build" --specpath "python-router-build" --paths "PYTHON_BACKEND" --collect-submodules uvicorn --collect-submodules fastapi "PYTHON_BACKEND\main.py"
if errorlevel 1 (echo Python packaging failed & pause & exit /b 1)
cd /d "%~dp0CALIAN_AI_ELECTRON_THEMES"
call npm install
if errorlevel 1 (echo npm install failed & pause & exit /b 1)
call npm run dist:win
if errorlevel 1 (echo Electron packaging failed & pause & exit /b 1)
echo BUILD COMPLETE: see CALIAN_AI_ELECTRON_THEMES\release
pause
