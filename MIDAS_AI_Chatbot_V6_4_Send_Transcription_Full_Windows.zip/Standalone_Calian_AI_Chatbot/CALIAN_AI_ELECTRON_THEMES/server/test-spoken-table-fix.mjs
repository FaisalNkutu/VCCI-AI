import {strict as assert} from 'node:assert';
import {resolveTable, schemaAwareTranslate, clearSchemaCache} from './schema-aware-sql.ts';

const database='vcci_aug_26_dbg_1';
const tables=[`${database}.contxt_oi_assoc`,`${database}.contxt_assoc`];
for (const spoken of ['contxt_oi_assoc','context_oi_assoc','context_ol_assoc','contxt_ol_assoc']) {
  const match=resolveTable(`Show me 10 records from table ${spoken}`,tables);
  assert.equal(match.name,`${database}.contxt_oi_assoc`,spoken);
}
assert.equal(resolveTable('Show 10 records from the context O I association table',tables).name,`${database}.contxt_oi_assoc`);
assert.throws(()=>resolveTable('Show 10 records from table xyz_no_such_table',tables),/not found/);
assert.throws(()=>resolveTable('Show ten records from table context_oo_assoc',
  [`${database}.contxt_oi_assoc`,`${database}.contxt_ol_assoc`]),/several tables/);
assert.throws(()=>resolveTable('Show ten records from table contxt_oi_assoc',
  [`${database}.contxt_oi_assoc`,'other_db.contxt_oi_assoc']),/several accessible databases/);
assert.throws(()=>resolveTable(`Show ten records from table other_db.contxt_oi_assoc`,tables),/does not exist/);

const statements=[];
const query=async sql=>{
  statements.push(sql);
  if(sql.startsWith('SELECT DATABASE()'))return {success:true,rows:[{current_database:database}],error:''};
  if(sql.includes('INFORMATION_SCHEMA.TABLES'))return {success:true,rows:[
    {schema_name:database,table_name:'contxt_oi_assoc'},
    {schema_name:database,table_name:'contxt_assoc'}
  ],error:''};
  return {success:true,rows:[],error:''};
};
const noOllama=async()=>{throw Error('Simple questions must not invoke Ollama');};
clearSchemaCache();
for(const spoken of ['Show 10 records from context_ol_assoc',
  'Show me ten records from the context O I association table']) {
  const result=await schemaAwareTranslate(spoken,query,noOllama,'spoken-table-fix');
  assert.equal(result.sql,`SELECT * FROM \`${database}\`.\`contxt_oi_assoc\` LIMIT 10;`);
}
const counted=await schemaAwareTranslate('How many records are in context_ol_assoc?',query,noOllama,'spoken-table-fix');
assert.equal(counted.sql,`SELECT COUNT(*) AS total_records FROM \`${database}\`.\`contxt_oi_assoc\`;`);
assert(statements.some(sql=>sql.includes(`TABLE_SCHEMA = '${database}'`)));
assert.equal(statements.filter(sql=>sql.includes('INFORMATION_SCHEMA.TABLES')).length,1);
console.log('PASS: spoken identifier repair, automatic selected database, SQL limits, count, cache, ambiguity safety');
