/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.utils;

import com.calian.paradigm.core.bto.model.aobjs.AObjectItem;
import com.calian.paradigm.core.bto.model.aobjs.AObjectItemType;
import com.calian.paradigm.core.bto.model.aobjs.metrics.AMetObjectItem;
import com.calian.paradigm.core.bto.model.aobjs.metrics.AMetObjectItemType;
import com.calian.paradigm.core.bto.model.gobjs.gen.*;

/**
 * @author p.kuczera
 */
public class ObjectConverterUtil {

    public static AObjectItem convertAOI(AMetObjectItem amoi) {
        GObjectItem oi = convertObjectItem(amoi.getMetObjectItem());
        if (oi != null) {
            GObjectItemStatus ois = convertOIStatus(amoi.getMetObjectItemStatus());
            GObjectItemPointLocation oipl = convertPointLocation(amoi.getMetObjectItemPointLocation());
            AObjectItemType aoit = convertAOIType(oi, amoi.getAMetObjectItemType());

            if (ois != null && oipl != null && aoit != null) {
                AObjectItem aoi = new AObjectItem();
                aoi.setObjectItem(oi);
                aoi.setObjectItemStatus(ois);
                aoi.setObjectItemPointLocation(oipl);
                aoi.setAObjectItemType(aoit);
                return aoi;
            }
        }

        return null;
    }

    private static AObjectItemType convertAOIType(GObjectItem oi, AMetObjectItemType amoit) {

        GObjectItemType oit = convertOIType(amoit.getMetObjectItemType());
        GObjectType ot = convertObjectType(amoit.getMetObjectType());

        if (oit != null && ot != null) {
            AObjectItemType aoit = new AObjectItemType();
            aoit.setObjectItem(oi);
            aoit.setObjectItemType(oit);
            aoit.setObjectType(ot);
            return aoit;
        }

        return null;
    }

    private static GObjectItem convertObjectItem(GMetObjectItem moi) {
        return switch (moi) {
            case GMetUnit unit -> convertUnit(unit);
            case GMetOrganisation org -> convertOrganisation(org);
            case null, default -> null;
        };
    }

    private static GUnit convertUnit(GMetUnit mu) {
        return new GUnit(
                mu.getMetUnitUnitId(),
                mu.getMetObjectItemSimReferenceId(),
                mu.getMetObjectItemNameText(),
                mu.getMetObjectItemContextId());
    }

    private static GOrganisation convertOrganisation(GMetOrganisation mo) {
        return new GOrganisation(
                mo.getMetOrganisationOrganisationId(),
                mo.getMetOrganisationCategoryCode(),
                mo.getMetObjectItemSimReferenceId(),
                mo.getMetObjectItemNameText(),
                mo.getMetObjectItemContextId());
    }

    public static GObjectType convertObjectType(GMetObjectType mot) {
        return switch (mot) {
            case GMetUnitType metUnitType -> convertUnitType(metUnitType);
            case GMetOrganisationType metOrgType -> convertOrganisationType(metOrgType);
            case null, default -> null;
        };
    }

    private static GUnitType convertUnitType(GMetUnitType mut) {
        return new GUnitType(
                mut.getMetUnitTypeUnitTypeId(),
                mut.getMetUnitTypeCategoryCode(),
                mut.getMetUnitTypeArmCategoryCode(),
                mut.getMetUnitTypeArmSpecialisationCode(),
                mut.getMetUnitTypeSupplementarySpecialisationCode(),
                mut.getMetUnitTypeGeneralMobilityCode(),
                mut.getMetUnitTypeQualifierCode(),
                mut.getMetUnitTypeSizeCode(),
                mut.getMetUnitTypePrincipalEquipmentTypeId(),
                mut.getMetUnitTypeSupportedMilitaryOrganisationTypeId(),
                mut.getMetUnitTypeMainActivityCode(),
                mut.getMetUnitTypeServiceCode(),
                mut.getMetOrganisationTypeCommandFunctionIndicatorCode(),
                mut.getMetOrganisationTypeCommandAndControlCategoryCode(),
                mut.getMetOrganisationTypeDescriptionText(),
                mut.getMetObjectTypeSimReferenceId(),
                mut.getMetObjectTypeDecoyIndicatorCode(),
                mut.getMetObjectTypeNameText(),
                mut.getMetObjectTypeCountry_code());
    }

    private static GOrganisationType convertOrganisationType(GMetOrganisationType mot) {
        return new GOrganisationType(
                mot.getMetOrganisationTypeOrganisationTypeId(),
                mot.getMetOrganisationTypeCategoryCode(),
                mot.getMetOrganisationTypeCommandFunctionIndicatorCode(),
                mot.getMetOrganisationTypeCommandAndControlCategoryCode(),
                mot.getMetOrganisationTypeDescriptionText(),
                mot.getMetObjectTypeSimReferenceId(),
                mot.getMetObjectTypeDecoyIndicatorCode(),
                mot.getMetObjectTypeNameText(),
                mot.getMetObjectTypeCountry_code());
    }

    public static GObjectItemStatus convertOIStatus(GMetObjectItemStatus mois) {
        if (mois == null) {
            return null;
        }

        if (mois instanceof GMetOrganisationStatus metOrgStatus) {
            return convertOrganisationStatus(metOrgStatus);
        } else {
            return null;
        }
    }

    private static GObjectItemType convertOIType(GMetObjectItemType moit) {
        if (moit == null) {
            return null;
        }

        return new GObjectItemType(
                moit.getMetObjectItemTypeObjectItemTypeIndex(),
                moit.getMetObjectItemTypeObjectItemId(),
                moit.getMetObjectItemTypeObjectTypeId(),
                moit.getMetObjectItemTypeTime(),
                moit.getMetObjectItemTypeSimulationOffsetTime());
    }

    private static GOrganisationStatus convertOrganisationStatus(GMetOrganisationStatus mos) {
        return new GOrganisationStatus(
                mos.getMetOrganisationStatusObjectItemStatusIndex(),
                mos.getMetOrganisationStatusOrganisationStatusId(),
                mos.getMetOrganisationStatusOperationalStatusCode(),
                mos.getMetOrganisationStatusOperationalStatusQualifierCode(),
                mos.getMetOrganisationStatusAvailabilityCode(),
                mos.getMetOrganisationStatusCommandAndControlRoleCode(),
                mos.getMetOrganisationStatusCommitmentStatusCode(),
                mos.getMetOrganisationStatusFireModeCode(),
                mos.getMetOrganisationStatusCbrnDressStateCode(),
                mos.getMetOrganisationStatusRadiationDoseQuantity(),
                mos.getMetOrganisationStatusReadinessCode(),
                mos.getMetOrganisationStatusReadinessDuration(),
                mos.getMetOrganisationStatusReinforcementCode(),
                mos.getMetOrganisationStatusReserveIndicatorCode(),
                mos.getMetOrganisationStatusTrainingCode(),
                mos.getMetOrganisationStatusUsageStatusCode(),
                mos.getMetOrganisationStatusIsDisaggregatedCode(),
                mos.getMetObjectItemStatusTime(),
                mos.getMetObjectItemStatusHostilityCode(),
                mos.getMetObjectItemStatusCountry_code(),
                mos.getMetObjectItemStatusOperationalStateCode(),
                mos.getMetObjectItemStatusStatusTypeCode(),
                mos.getMetObjectItemStatusSizeCode(),
                mos.getMetObjectItemStatusSuppressionCode(),
                mos.getMetObjectItemStatusSuppressionSubcategoryCode(),
                mos.getMetObjectItemStatusAffiliationColor(),
                mos.getMetObjectItemStatusFatigue(),
                mos.getMetObjectItemStatusSimulationOffsetTime(),
                mos.getMetObjectItemStatusCurrentName());
    }

    private static GObjectItemPointLocation convertPointLocation(GMetObjectItemPointLocation moipl) {
        if (moipl == null) {
            return null;
        }

        return new GObjectItemPointLocation(
                moipl.getMetObjectItemPointLocationObjectItemLocationIndex(),
                moipl.getMetObjectItemPointLocationObjectItemId(),
                moipl.getMetObjectItemPointLocationTime(),
                moipl.getMetObjectItemPointLocationBearingAngle(),
                moipl.getMetObjectItemPointLocationInclinationAngle(),
                moipl.getMetObjectItemPointLocationSpeedRate(),
                moipl.getMetObjectItemPointLocationMeaningCode(),
                moipl.getMetObjectItemPointLocationRelativeSpeedCode(),
                moipl.getMetObjectItemPointLocationAltitude(),
                moipl.getMetObjectItemPointLocationLatitudeCoordinate(),
                moipl.getMetObjectItemPointLocationLongitudeCoordinate(),
                moipl.getMetObjectItemPointLocationExternalReferenceTime(),
                moipl.getMetObjectItemPointLocationSimulationOffsetTime());
    }

}
