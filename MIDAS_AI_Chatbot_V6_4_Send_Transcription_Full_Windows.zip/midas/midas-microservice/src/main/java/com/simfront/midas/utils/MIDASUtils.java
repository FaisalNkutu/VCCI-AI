/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.utils;

import com.calian.common.lib.db.DBMSUtils;
import com.simfront.midas.constants.MIDASConstants;
import com.calian.paradigm.core.bto.model.dobjs.DMetricsTimeFormats;
import com.calian.paradigm.core.db.OMDB;
import com.calian.paradigm.core.db.OMUtils;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author rhans
 */
public class MIDASUtils {

    public final static String VCCI = "VCCI";
    private final static long HOUR_MILLISECS = 3600000;
    private final static long MIN_MILLISECS = 60000;

    public static ArrayList<String> buildDatabaseList(String host) {

        List<String> dbs = DBMSUtils.listAllDatabases("vcci", "vcci", host);
        if (dbs == null ) {
            return null;
        }
        ArrayList<String> results = new ArrayList();
        for (String db : dbs) {
            OMDB omdb = OMUtils.getExerciseDetails(host, db, "vcci", "vcci", null);
            if (omdb != null && omdb.jProduct != null) {
                results.add(db);
            }
        }

        return results;
    }

    /**
     * The time is based on the earliest time - that is, Day 1, Time 0 is synced
     * to the earliestTime and we calculate the pretty date starting from there.
     *
     * @param earliestTime
     * @param time
     * @return
     */
    public static String getPrettyExerciseDate(long earliestTime, long time) {
        long epochTime = time;
        long earliest = earliestTime;

        // The difference is our current time passed which we will need to
        // convert to day/hour/min/sec
        // (MAGI: @todo - Need to account for DDAY OFFSET)
        // Start is Day 1
        // This is the difference in milliseconds
        long difference = epochTime - earliest;
        // Do we have any days (zero time is day 1)
        int days = (int) (difference / (HOUR_MILLISECS * 24));
        long days_millisecs = days * 24 * HOUR_MILLISECS;
        // Hours
        int hours = (int) ((difference - days_millisecs) / (HOUR_MILLISECS));
        long hours_millisecs = hours * HOUR_MILLISECS;
        // Mins
        int mins = (int) ((difference - days_millisecs - hours_millisecs) / (MIN_MILLISECS));
        // Secs
        int secs = (int) ((difference - days_millisecs - hours_millisecs - (mins * MIN_MILLISECS)) / 1000);

        // We start with day zero so always add 1 here
        days += 1;
        String t = "Day " + days + " H:" + hours + " M:" + mins + " S:" + secs;
        return t;
    }

    /**
     * The time in local format.
     *
     * @param time
     * @return
     */
    public static String getPrettyLocalDate(long time) {
        LocalDateTime dateTime = LocalDateTime.ofInstant(
                Instant.ofEpochMilli(time),
                ZoneId.systemDefault());

        // Format and print the LocalDateTime object
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        String dateString = dateTime.format(formatter);
        return dateString;
    }

    /**
     * The simulation start time here is some real time in space. We just add
     * the offset to that time and generate a real date.
     *
     * @param simulationStartTime
     * @param simOffsetTime
     * @return a time in space
     */
    public static String convertSimTimeToTimeInSpace(long simulationStartTime, long simOffsetTime) {
        return getPrettyLocalDate(simulationStartTime + simOffsetTime);
    }

    public static String applyTimeFormat(DMetricsTimeFormats fmt, long offset) {

        // Figure out days
        int days = (int) (offset / MIDASConstants.MILLISECONDS_IN_DAY);

        // Always add 1 to the day (we are 1 based)
        days++;

        // Get hours
        // Since day is 1 based, we subtract one here to account for that
        int hours = (int) ((offset - ((days - 1)
                * MIDASConstants.MILLISECONDS_IN_DAY)) / MIDASConstants.MILLISECONDS_IN_HOUR);

        // Get mins
        int mins = (int) ((offset - ((days - 1)
                * MIDASConstants.MILLISECONDS_IN_DAY)
                - (hours * MIDASConstants.MILLISECONDS_IN_HOUR)) / MIDASConstants.MILLISECONDS_IN_MINUTE);

        // Get secs
        int secs = (int) ((offset - ((days - 1)
                * MIDASConstants.MILLISECONDS_IN_DAY)
                - (hours * MIDASConstants.MILLISECONDS_IN_HOUR)
                - (mins * MIDASConstants.MILLISECONDS_IN_MINUTE)) / 1000);

        // Apply format
        if (fmt != null) {
            days += fmt.getDayAdjustAmount();
            hours += fmt.getHourAdjustAmount();
            mins += fmt.getMinuteAdjustAmount();
            secs += fmt.getSecondAdjustAmount();
            return fmt.generateHumanReadableFormat(false, days, hours, mins, secs);
        }

        // Generate readable string
        String readable = "";

        readable += (" Day:  " + days);
        readable += (" H: " + hours);
        readable += (" M: " + mins);
        readable += (" S: " + secs);
        return readable;
    }
}
