package com.simfront.midas.ui;

import java.awt.*;
import java.awt.event.*;
import java.net.URI;
import java.net.URL;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import com.simfront.midas.managers.DBManager;

public class SysTray {
    private static SystemTray tray;
    private static TrayIcon trayIcon;
    private static MenuItem launchUIButton;
    private static MenuItem disconnectDBButton;

    private static final String ICON_PATH = "/images/midas_icon.png";
    private static final int TRAY_ICON_SIZE = 36;
    private static final String BASE_URL = "http://127.0.0.1:10001";
    private static final String ENDPOINT_DISCONNECT_DB = "/advmetrics/omdbdata/disconnectdb";
    private static final String ENDPOINT_SHUTDOWN = "/midas/shutdown";

    private static void sendPostRequest(String pattern) {
        try {
            URI uri = URI.create(BASE_URL + pattern);
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(uri)
                    .POST(HttpRequest.BodyPublishers.noBody())
                    .build();
            client.send(request, HttpResponse.BodyHandlers.ofString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void sendDisconnectRequest() {
        sendPostRequest(ENDPOINT_DISCONNECT_DB);
    }

    private static void sendShutdownRequest() {
        sendPostRequest(ENDPOINT_SHUTDOWN);
    }

    public static void initSysTray() {
        if (!SystemTray.isSupported()) {
            System.err.println("System tray is not supported on this platform.");
            return;
        }

        if (GraphicsEnvironment.isHeadless()) {
            System.setProperty("java.awt.headless", "false");
        }

        try {
            tray = SystemTray.getSystemTray();
            URL iconURL = SysTray.class.getResource(ICON_PATH);
            if (iconURL == null) {
                System.err.println("Icon not found at path: " + ICON_PATH);
                return;
            }
            Image image = Toolkit.getDefaultToolkit().getImage(iconURL);
            Image scaledImage = image.getScaledInstance(
                    TRAY_ICON_SIZE,
                    TRAY_ICON_SIZE,
                    Image.SCALE_SMOOTH
            );

            PopupMenu trayMenu = createPopupMenu();

            trayIcon = new TrayIcon(scaledImage, "MIDAS", trayMenu);
            trayIcon.setImageAutoSize(true);

            trayIcon.addActionListener(e -> {
                if (DBManager.jDBManager.isConnected()) {
                    openWebUI();
                } else {
                    trayIcon.displayMessage("Launch UI Disabled", "The UI is currently unavailable (No DB Connection).", TrayIcon.MessageType.WARNING);
                }
            });

            trayIcon.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseReleased(MouseEvent e) {
                    if (e.isPopupTrigger()) {
                        updateMenuState();
                    }
                }
            });

            tray.add(trayIcon);
            trayIcon.displayMessage("MIDAS Running", "Application is minimized to the system tray.", TrayIcon.MessageType.INFO);
        } catch (AWTException e) {
            System.err.println("TrayIcon could not be added. Microservice running without system tray.");
            e.printStackTrace();
        }
    }

    /**
     * Updates the enabled state and label of the dynamic menu items.
     * This should be called whenever the DB connection state changes.
     */
    public static void updateMenuState() {
        if (launchUIButton == null || disconnectDBButton == null) {
            return;
        }
        boolean isConnected = DBManager.jDBManager.isConnected();
        launchUIButton.setEnabled(isConnected);
        disconnectDBButton.setEnabled(isConnected);
        if (isConnected) {
            String dbName = DBManager.jDBManager.getDBName();
            disconnectDBButton.setLabel("Disconnect \"" + dbName + "\"");
        } else {
            disconnectDBButton.setLabel("Disconnect");
        }
    }

    /**
     * Creates and configures the right-click menu for the TrayIcon.
     */
    private static PopupMenu createPopupMenu() {
        PopupMenu menu = new PopupMenu();

        // Initial state determination
        boolean isConnected = DBManager.jDBManager.isConnected();
        String dbName = isConnected ? DBManager.jDBManager.getDBName() : "";

        // Launch UI Button
        launchUIButton = new MenuItem("Launch Dashboard");
        launchUIButton.addActionListener(e -> openWebUI());
        launchUIButton.setEnabled(isConnected);
        menu.add(launchUIButton);

        // Disconnect DB Button
        String disconnectLabel = isConnected ? "Disconnect \"" + dbName + "\"" : "Disconnect";
        disconnectDBButton = new MenuItem(disconnectLabel);
        disconnectDBButton.addActionListener(e -> {
            if  (!DBManager.jDBManager.isConnected()) {
                return;
            }
            String currentDBName = DBManager.jDBManager.getDBName();
            trayIcon.displayMessage("DB Disconnect", "Disconnecting \"" + currentDBName + "\"", TrayIcon.MessageType.WARNING);
            sendDisconnectRequest();
            updateMenuState();
        });
        disconnectDBButton.setEnabled(isConnected);
        menu.add(disconnectDBButton);

        menu.addSeparator();

        // Shutdown Button
        MenuItem shutdownItem = new MenuItem("Shutdown");
        shutdownItem.addActionListener(e -> {
            if (trayIcon != null && tray != null) {
                tray.remove(trayIcon);
            }
            sendShutdownRequest();
        });
        menu.add(shutdownItem);

        return menu;
    }

    /**
     * Utility method to open the server URL in the default browser.
     */
    private static void openWebUI() {
        if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
            try {
                Desktop.getDesktop().browse(new URI(BASE_URL));
            } catch (Exception ex) {
                trayIcon.displayMessage("Browser Error", "Could not open Dashboard. Please navigate to " + BASE_URL, TrayIcon.MessageType.ERROR);
            }
        } else {
            trayIcon.displayMessage("MIDAS Dashboard", "MIDAS is running. Navigate to " + BASE_URL + " manually.", TrayIcon.MessageType.INFO);
        }
    }
}