/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.utils;

import com.simfront.midas.constants.MIDASConstants.E_REQUEST_STATUS;
import java.util.ArrayList;

/**
 *
 * @author rhans
 */
public class RequestResults {

    ArrayList<Object> jResults = null;
    E_REQUEST_STATUS jStatus = E_REQUEST_STATUS.SUCCESS;
    Double jDoubleResult = 1.0;

    public RequestResults(ArrayList<Object> res, E_REQUEST_STATUS stat) {
        jResults = res;
        jStatus = stat;
    }

    public RequestResults(double result, E_REQUEST_STATUS stat) {
        jResults = new ArrayList<>();
        jStatus = stat;
        jDoubleResult = result;
    }

    public RequestResults(E_REQUEST_STATUS stat) {
        jStatus = stat;
    }

    public Double getDoubleResult() {
        return jDoubleResult;
    }

    public void setDoubleResult(Double doubleResult) {
        jDoubleResult = doubleResult;
    }
    
    public ArrayList<Object> getResults() {
        return jResults;
    }

    public E_REQUEST_STATUS getStatus() {
        return jStatus;
    }
    
    public boolean isSuccess() {
        return jStatus == E_REQUEST_STATUS.SUCCESS;
    }
}
