/** CALIAN regression test: spoken "Select ... records" must never go straight to execute_sql. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');

function loadTypescript(name, mocks={}) {
  const file = path.join(__dirname, name);
  const transpiled = ts.transpileModule(fs.readFileSync(file, 'utf8'), {
    fileName: file, reportDiagnostics:true,
    compilerOptions: { target: ts.ScriptTarget.ES2022, module:ts.ModuleKind.CommonJS }
  });
  const errors = (transpiled.diagnostics||[]).filter(x => x.category === ts.DiagnosticCategory.Error);
  assert.equal(errors.length,0,`TypeScript syntax diagnostics in ${name}: ${errors.map(e=>e.messageText).join(', ')}`);
  const module = {exports:{}};
  const localRequire=(id)=>Object.hasOwn(mocks,id)?mocks[id]:require(id);
  new Function('require','module','exports',transpiled.outputText)(localRequire,module,module.exports);
  return module.exports;
}

async function main(){
 const direct = loadTypescript('direct-sql.ts');
 const nl = loadTypescript('db-natural-language.ts',{'./direct-sql':direct});
 const schema = loadTypescript('schema-aware-sql.ts',{'./db-natural-language':nl});
 const questions=[
  'Select 10 records from the table contxt_oi_assoc',
  'Select 10 records from the table "contxt_oi_assoc"',
  'Select ten records from the context O I association table.',
  'Select the first 10 rows from the table contxt_oi_assoc',
  'Select all records from the table contxt_oi_assoc',
  'select records from the table contxt_oi_assoc',
  'How many records are in contxt_oi_assoc?',
  'Show me 10 records from contxt_oi_assoc'
 ];
 const sql=[
  'SELECT * FROM `vcci_aug_26_dbg_1`.`contxt_oi_assoc` LIMIT 10;',
  'select contxt_id FROM contxt_oi_assoc LIMIT 10;',
  'SELECT COUNT(*) AS total_records FROM contxt_oi_assoc;',
  'SELECT 10 FROM contxt_oi_assoc;',
  'WITH x AS (SELECT 1 AS id) SELECT * FROM x;'
 ];
 for(const question of questions){
  assert.equal(direct.classifyDbInput(question),'question',`Mistaken for SQL: ${question}`);
  assert.equal(nl.isDirectSql(question),false,`isDirectSql mismatch: ${question}`);
 }
 for(const statement of sql){
  assert.equal(direct.classifyDbInput(statement),'sql',`Literal SQL no longer recognized: ${statement}`);
  assert.equal(nl.isDirectSql(statement),true,`isDirectSql mismatch: ${statement}`);
 }
 for(const unsafe of ['DELETE FROM contxt_oi_assoc','DROP TABLE contxt_oi_assoc','SHOW TABLES','DESCRIBE contxt_oi_assoc']){
  assert.equal(direct.classifyDbInput(unsafe),'unsafe',`Unsafe statement was not blocked: ${unsafe}`);
  assert.equal(nl.isDirectSql(unsafe),true);
 }
 // Execute metadata against a stub, never Docker; prove the English request flows
 // through validated discovery into a qualified read-only SQL statement.
 const previous=process.env.CALIAN_SCHEMA_DATABASE;
 process.env.CALIAN_SCHEMA_DATABASE='vcci_aug_26_dbg_1';
 const intercepted=[];
 const execute=async statement=>{
   intercepted.push(statement);
   if (/INFORMATION_SCHEMA\.TABLES/i.test(statement))return {success:true,error:'',rows:[{schema_name:'vcci_aug_26_dbg_1',table_name:'contxt_oi_assoc'}]};
   throw new Error(`Unexpected SQL execution in translator: ${statement}`);
 };
 try{
  const result=await schema.schemaAwareTranslate('Select 10 records from the table contxt_oi_assoc',execute,()=>{throw Error('Unexpected Ollama call');},'test-select-english-routing');
  assert.equal(result.method,'schema-list');
  assert.equal(result.sql,'SELECT * FROM `vcci_aug_26_dbg_1`.`contxt_oi_assoc` LIMIT 10;');
  // Simulate Whisper confusing the final i/l and expanding 'contxt' to 'context'.
  for(const utterance of [
    'Select 10 records from the table contxt_ol_assoc',
    'Select 10 records from the table context_ol_assoc',
    'Select 10 records from the table context underscore O I underscore assoc'
  ]){
    const spoken=await schema.schemaAwareTranslate(utterance,execute,()=>{throw Error('Unexpected Ollama call');},'test-select-english-routing');
    assert.equal(spoken.sql, result.sql,`Mismatched transcription: ${utterance}`);
  }
  assert.ok(intercepted.every(x=>!x.startsWith('Select 10 records')));
 }finally{
  if(previous===undefined) delete process.env.CALIAN_SCHEMA_DATABASE;
  else process.env.CALIAN_SCHEMA_DATABASE=previous;
 }
 console.log(`PASS: ${questions.length} English inputs, ${sql.length} literal SELECT/CTE inputs, 4 blocked statements, schema-aware SQL translation`);
}
main().catch(e=>{console.error(e);process.exitCode=1;});
