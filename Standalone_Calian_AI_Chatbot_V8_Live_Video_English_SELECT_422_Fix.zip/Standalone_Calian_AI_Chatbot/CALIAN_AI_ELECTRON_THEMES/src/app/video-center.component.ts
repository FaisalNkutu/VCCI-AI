import {Component, ElementRef, ViewChild, OnDestroy, NgZone} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';

/** CALIAN V8 video modes: private local Ollama vision, and public guest-only WebRTC signaling. */
@Component({selector:'app-video-center',standalone:true,imports:[CommonModule,FormsModule],templateUrl:'./video-center.component.html',styleUrl:'./video-center.component.scss'})
export class VideoCenterComponent implements OnDestroy {
 @ViewChild('aiPreview') aiPreview?:ElementRef<HTMLVideoElement>;
 @ViewChild('hostPreview') hostPreview?:ElementRef<HTMLVideoElement>;
 @ViewChild('guestVideo') guestVideo?:ElementRef<HTMLVideoElement>;
 mode:'ai'|'call'='ai';
 busy=false;error='';notice=''; cameraOn=false; audioMuted=false; cameraMuted=false;
 aiQuestion='What can you see?';aiAnswer='';aiModel=''; autoObserve=false; autoSpeak=false; analyzing=false; dictating=false; voiceBusy=false;
 callInvite=''; callExpires=''; callStatus='Not connected'; pendingGuests:{id:string,name:string}[]=[]; inCall=false;
 private stream:MediaStream|null=null; private pc:RTCPeerConnection|null=null;private ws:WebSocket|null=null;
 private iceServers:RTCIceServer[]=[];private inviteSession='';private interval:ReturnType<typeof setInterval>|null=null;
 private voiceContext:AudioContext|null=null;private voiceProcessor:ScriptProcessorNode|null=null;private voiceSource:MediaStreamAudioSourceNode|null=null;private voiceStream:MediaStream|null=null;
 private voiceBuffers:Float32Array[]=[];private voiceSamples=0;private voiceStart=0;
 private candidateQueue:RTCIceCandidateInit[]=[];private speaking=false;
 private aiHistory:{question:string;answer:string}[]=[];
 constructor(private zone:NgZone){}
 ngOnDestroy():void {this.stopAll();}
 switchMode(mode:'ai'|'call') {if(this.mode===mode)return;this.stopAll();this.mode=mode;this.error='';this.notice='';}
 private async media(call:boolean){
  if(!navigator.mediaDevices?.getUserMedia)throw Error('Camera access requires HTTPS or the installed desktop app.');
  this.stream=await navigator.mediaDevices.getUserMedia({video:{width:{ideal:960},height:{ideal:540}},audio:call?{echoCancellation:true,noiseSuppression:true}:false});
  this.cameraOn=true;
  if(call){if(this.hostPreview)this.hostPreview.nativeElement.srcObject=this.stream;}
  else if(this.aiPreview)this.aiPreview.nativeElement.srcObject=this.stream;
 }
 async startCamera(){if(this.cameraOn)return;this.error='';try{await this.media(false);}catch(e){this.error=this.message(e);}}
 stopCamera(){this.stopObserve();this.stream?.getTracks().forEach(t=>t.stop());this.stream=null;this.cameraOn=false;if(this.aiPreview)this.aiPreview.nativeElement.srcObject=null;}
 private capture():string {
  const v=this.aiPreview?.nativeElement;
  if(!v||!this.stream||v.videoWidth===0)throw Error('Wait for the live camera preview before analyzing a frame.');
  const canvas=document.createElement('canvas');const ratio=Math.min(1,640/v.videoWidth);canvas.width=Math.round(v.videoWidth*ratio);canvas.height=Math.round(v.videoHeight*ratio);
  const ctx=canvas.getContext('2d');if(!ctx)throw Error('Camera capture unavailable');ctx.drawImage(v,0,0,canvas.width,canvas.height);
  return canvas.toDataURL('image/jpeg',0.68);
 }
 async askVision(){
  if(this.analyzing)return;this.error='';this.analyzing=true;
  try{
   const r=await fetch('/api/video/ai/inspect',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({image:this.capture(),question:this.aiQuestion.trim()||'Describe this camera frame.',history:this.aiHistory.slice(-3)})});
   const data=await r.json();if(!r.ok)throw Error(data.error||`Vision HTTP ${r.status}`);
   this.aiAnswer=data.answer;this.aiModel=data.model;this.aiHistory.push({question:this.aiQuestion.trim(),answer:data.answer});this.aiHistory=this.aiHistory.slice(-3);this.notice='Analyzed one camera frame; no video recording was saved.';
   if(this.autoSpeak)this.speakAnswer();
  }catch(e){this.error=this.message(e);}finally{this.analyzing=false;}
 }
 startObserve(){if(!this.cameraOn){this.error='Start the camera first.';return;}if(this.autoObserve)return;this.autoObserve=true;void this.askVision();this.interval=setInterval(()=>{if(this.autoObserve&&!this.analyzing)void this.askVision();},10000);}
 stopObserve(){this.autoObserve=false;if(this.interval){clearInterval(this.interval);this.interval=null;}}
 speakAnswer(){if(!this.aiAnswer||!('speechSynthesis' in window))return;window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(this.aiAnswer.slice(0,1800));u.rate=.96;window.speechSynthesis.speak(u);this.speaking=true;u.onend=()=>this.zone.run(()=>this.speaking=false);}
 stopSpeaking(){window.speechSynthesis?.cancel();this.speaking=false;}
 async toggleDictation(){if(this.dictating){await this.stopDictation();return;}if(this.voiceBusy)return;
  this.error='';this.voiceBusy=true;try{
   const status=await fetch('/api/speech/status').then(r=>r.json());if(!status.available)throw Error(status.install||'Run SETUP-ACCURATE-SPEECH-WINDOWS.bat on your Windows host.');
   this.voiceStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:false});
   const ctx=new AudioContext();this.voiceContext=ctx;
   this.voiceSource=ctx.createMediaStreamSource(this.voiceStream);
   this.voiceProcessor=ctx.createScriptProcessor(4096,1,1);
   this.voiceBuffers=[];this.voiceSamples=0;
   this.voiceProcessor.onaudioprocess=e=>{if(!this.dictating)return;const a=new Float32Array(e.inputBuffer.getChannelData(0));this.voiceBuffers.push(a);this.voiceSamples+=a.length;};
   this.voiceSource.connect(this.voiceProcessor);this.voiceProcessor.connect(ctx.destination);
   await ctx.resume();this.voiceStart=Date.now();this.dictating=true;this.notice='Recording question. Press Stop to transcribe with Whisper (up to 30 seconds).';
  }catch(e){this.error=this.message(e);this.cleanMic();}finally{this.voiceBusy=false;}
 }
 private cleanMic(){this.dictating=false;this.voiceProcessor?.disconnect();if(this.voiceProcessor)this.voiceProcessor.onaudioprocess=null;this.voiceProcessor=null;this.voiceSource?.disconnect();this.voiceSource=null;this.voiceStream?.getTracks().forEach(t=>t.stop());this.voiceStream=null;if(this.voiceContext)void this.voiceContext.close().catch(()=>{});this.voiceContext=null;}
 async stopDictation(){if(!this.dictating)return;const buffers=this.voiceBuffers;const count=this.voiceSamples;const rate=this.voiceContext?.sampleRate||48000;this.cleanMic();this.voiceBusy=true;
  try{if(Date.now()-this.voiceStart<350||count<rate/4)throw Error('Recording was too short.');
   const wav=this.encodeWav(buffers,count,rate);const r=await fetch('/api/speech/transcribe',{method:'POST',headers:{'Content-Type':'audio/wav','X-Calian-Speech-Mode':'natural'},body:wav});const data=await r.json();if(!r.ok)throw Error(data.error||'Whisper failed');
   if(!data.transcript?.trim())throw Error('No speech recognized');this.aiQuestion=data.transcript.trim();this.notice='Review your spoken question, then click Ask AI.';
  }catch(e){this.error=this.message(e);}finally{this.voiceBusy=false;}
 }
 private encodeWav(parts:Float32Array[],length:number,rate:number):ArrayBuffer {
  const input=new Float32Array(length);let k=0;for(const b of parts){input.set(b,k);k+=b.length;}
  const target=16000,count=Math.floor(length*target/rate);const buffer=new ArrayBuffer(44+count*2);const view=new DataView(buffer);
  const label=(p:number,s:string)=>{for(let i=0;i<s.length;i++)view.setUint8(p+i,s.charCodeAt(i));};
  label(0,'RIFF');view.setUint32(4,36+count*2,true);label(8,'WAVE');label(12,'fmt ');view.setUint32(16,16,true);view.setUint16(20,1,true);view.setUint16(22,1,true);view.setUint32(24,target,true);view.setUint32(28,target*2,true);view.setUint16(32,2,true);view.setUint16(34,16,true);label(36,'data');view.setUint32(40,count*2,true);
  const ratio=rate/target;for(let i=0;i<count;i++){const a=Math.floor(i*ratio),b=Math.min(input.length,Math.ceil((i+1)*ratio));let sum=0;for(let j=a;j<b;j++)sum+=input[j];const x=Math.max(-1,Math.min(1,sum/Math.max(1,b-a)));view.setInt16(44+i*2,Math.round(x*32767),true);}
  return buffer;
 }
 async createCall(){if(this.busy||this.callInvite)return;this.busy=true;this.error='';
  try{
   const configured=await fetch('/api/video/config').then(r=>r.json());
   if(!configured.callsConfigured)throw Error('Worldwide calls need the separate HTTPS video service. Run SETUP-CALIAN-VIDEO-HOST-WINDOWS.bat after deploying VIDEO_CALL_SERVICE.');
   await this.media(true);
   const r=await fetch('/api/video/rooms',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
   const data=await r.json();if(!r.ok)throw Error(data.error||`Video service HTTP ${r.status}`);
   this.callInvite=data.inviteUrl;this.callExpires=data.expiresAt;this.iceServers=data.iceServers||[];this.inviteSession=data.hostTicket;
   this.callStatus='Connecting to the video signaling service…';this.connectHost(data.wsUrl);
  }catch(e){this.error=this.message(e);this.closeCall(false);}finally{this.busy=false;}
 }
 private connectHost(wsUrl:string){
  this.ws=new WebSocket(wsUrl);
  this.ws.onopen=()=>this.send({type:'auth',ticket:this.inviteSession});
  this.ws.onmessage=e=>this.zone.run(()=>{void this.handleHostMessage(JSON.parse(e.data)).catch(err=>this.error=this.message(err));});
  this.ws.onclose=()=>this.zone.run(()=>{if(this.callInvite){this.closeCall(false);this.callStatus='Public signaling disconnected. Camera and microphone stopped.';}});
  this.ws.onerror=()=>this.zone.run(()=>this.error='Cannot connect to the public video service. Check HTTPS, DNS, and WebSockets.');
 }
 private send(msg:unknown){if(this.ws?.readyState===WebSocket.OPEN)this.ws.send(JSON.stringify(msg));}
 private async handleHostMessage(m:any){
  if(m.type==='ready')this.callStatus='Waiting for a guest. Share the invitation link.';
  if(m.type==='waiting'&&typeof m.guestId==='string'&&!this.pendingGuests.some(g=>g.id===m.guestId))this.pendingGuests.push({id:m.guestId,name:String(m.name||'Guest')});
  if(m.type==='admitted'){this.pendingGuests=[];this.callStatus=`Connecting to ${m.name||'guest'}…`;await this.offer();}
  if(m.type==='guest-left'){this.closePeer();this.callStatus='Guest left. Invitation remains available until it expires.';this.inCall=false;}
  if(m.type==='ended'){this.closeCall(false);this.callStatus='The call has ended.';}
  if(m.type==='error')this.error=m.error||'Video signaling error';
  if(m.type==='signal')await this.receiveSignal(m.data);
 }
 admit(guestId:string){this.send({type:'admit',guestId});this.callStatus='Admitting guest…';}
 deny(guestId:string){this.send({type:'deny',guestId});this.pendingGuests=this.pendingGuests.filter(g=>g.id!==guestId);}
 private createPeer(){
  if(this.pc)return this.pc;
  const p=new RTCPeerConnection({iceServers:this.iceServers});this.pc=p;
  for(const track of this.stream?.getTracks()||[])p.addTrack(track,this.stream!);
  p.ontrack=e=>{if(this.guestVideo)this.guestVideo.nativeElement.srcObject=e.streams[0];this.zone.run(()=>{this.inCall=true;this.callStatus='Call connected';});};
  p.onicecandidate=e=>{if(e.candidate)this.send({type:'signal',data:{kind:'candidate',candidate:e.candidate}});};
  p.onconnectionstatechange=()=>this.zone.run(()=>{if(['failed','disconnected'].includes(p.connectionState))this.callStatus='Media interrupted. Check TURN/network connectivity.';});
  return p;
 }
 private async offer(){const p=this.createPeer();const offer=await p.createOffer();await p.setLocalDescription(offer);this.send({type:'signal',data:{kind:'offer',sdp:offer.sdp}});}
 private async receiveSignal(data:any){if(!data)return;
  const p=this.createPeer();
  if(data.kind==='answer'){await p.setRemoteDescription({type:'answer',sdp:data.sdp});for(const c of this.candidateQueue)await p.addIceCandidate(c);this.candidateQueue=[];}
  if(data.kind==='candidate'&&data.candidate){if(!p.remoteDescription)this.candidateQueue.push(data.candidate);else await p.addIceCandidate(data.candidate);}
 }
 private closePeer(){this.pc?.close();this.pc=null;this.candidateQueue=[];this.inCall=false;if(this.guestVideo)this.guestVideo.nativeElement.srcObject=null;}
 closeCall(signal=true){if(signal)this.send({type:'end'});this.ws?.close();this.ws=null;this.closePeer();this.stream?.getTracks().forEach(t=>t.stop());this.stream=null;this.cameraOn=false;this.callInvite='';this.inviteSession='';this.pendingGuests=[];if(this.hostPreview)this.hostPreview.nativeElement.srcObject=null;}
 toggleMute(){const t=this.stream?.getAudioTracks()[0];if(t){t.enabled=!t.enabled;this.audioMuted=!t.enabled;}}
 toggleCamera(){const t=this.stream?.getVideoTracks()[0];if(t){t.enabled=!t.enabled;this.cameraMuted=!t.enabled;}}
 async copyInvite(){if(!this.callInvite)return;try{await navigator.clipboard.writeText(this.callInvite);this.notice='Invitation link copied.';}catch{this.notice='Select and copy the invitation URL shown above.';}}
 stopAll(){this.stopSpeaking();this.stopObserve();this.cleanMic();this.stopCamera();this.closeCall(true);}
 private message(e:unknown){return e instanceof Error?e.message:String(e);}
}
