const {app,BrowserWindow,dialog}=require('electron');
const {spawn}=require('node:child_process');
const net=require('node:net');
const {randomUUID}=require('node:crypto');
const path=require('node:path');
const fs=require('node:fs');
let backend;
let backendStartupError=null;
const startupLog=path.join(app.getPath('userData'),'backend-startup.log');
const dev=!app.isPackaged;
// Packaged CALIAN runs on its own free loopback port, rather than attaching to an
// older CALIAN process accidentally left on 8797.  Development keeps port 8797.
const instanceId=randomUUID();
function readConfig(file){
 if(!fs.existsSync(file))return {};
 const result={};
 for(const line of fs.readFileSync(file,'utf8').split(/\r?\n/)){
  const m=line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
  if(!m)continue;
  let value=m[2];if((value.startsWith('"')&&value.endsWith('"'))||(value.startsWith("'")&&value.endsWith("'")))value=value.slice(1,-1);
  result[m[1]]=value;
 }
 return result;
}
// electron-builder's Windows portable target extracts a temporary inner .exe.
// process.execPath points to that temporary executable, NOT necessarily to the
// original portable CALIAN AI 1.0.0.exe that the user double-clicked.
// PORTABLE_EXECUTABLE_DIR and PORTABLE_EXECUTABLE_FILE identify the real folder.
const portableExecutableDir = process.env.PORTABLE_EXECUTABLE_DIR ||
 (process.env.PORTABLE_EXECUTABLE_FILE ? path.dirname(process.env.PORTABLE_EXECUTABLE_FILE) : path.dirname(process.execPath));
const portableConfigFile = path.join(portableExecutableDir, 'calian.env');
const userDataConfigFile = path.join(app.getPath('userData'), 'calian.env');
// Explicit calian.env beside the ORIGINAL portable exe takes highest precedence
// for local app configuration, including CALIAN_SCHEMA_DATABASE.
// Preserve all existing config sources and custom environment values.
const config={
 ...readConfig(path.join(app.getAppPath(), '.env')),
 ...readConfig(path.join(path.dirname(process.execPath), 'calian.env')),
 ...readConfig(userDataConfigFile),
 ...process.env,
 ...readConfig(portableConfigFile)
};
const explicitlyConfiguredPort=config.PORT != null && config.PORT !== '';
const configuredPort=Number(config.PORT||8797);
if(!Number.isInteger(configuredPort)||configuredPort<1||configuredPort>65535)throw new Error('Invalid PORT');
const host='127.0.0.1';
function reserveAvailablePort(port){return new Promise((resolve,reject)=>{
 const test=net.createServer();
 test.once('error',reject);
 test.listen(port,host,()=>{
  const addr=test.address();
  const selected=addr&&typeof addr==='object'?addr.port:null;
  test.close(()=>selected?resolve(selected):reject(new Error('Unable to allocate CALIAN backend port')));
 });
});}
function startBackend(port){
 if(dev)return;
 const executable=process.execPath;
 const script=path.join(app.getAppPath(),'dist','backend.cjs');
 const staticDir=path.join(app.getAppPath(),'dist','calian','browser');
 // Preserve backend stderr/stdout so a real startup failure is diagnosable.
 fs.mkdirSync(path.dirname(startupLog),{recursive:true});
 const logFd=fs.openSync(startupLog,'w');
 fs.writeSync(logFd,`CALIAN backend startup; listening on ${host}:${port}\n`);
 fs.writeSync(logFd,`CALIAN configured schema: ${config.CALIAN_SCHEMA_DATABASE || '(auto-detect)'}\n`);
 try {
  backend=spawn(executable,[script],{env:{...config,ELECTRON_RUN_AS_NODE:'1',CALIAN_STATIC_DIR:staticDir,PORT:String(port),HOST:host,CALIAN_INSTANCE_ID:instanceId},stdio:['ignore',logFd,logFd],windowsHide:true});
 } finally { fs.closeSync(logFd); }
 backend.on('error',e=>{backendStartupError=e.message;});
 backend.on('exit',(code,signal)=>{backendStartupError=`Backend exited (code ${code}, signal ${signal||'none'})`;});
}
async function waitBackend(url){
 for(let i=0;i<80;i++){
  try{
   const r=await fetch(`${url}/api/health`,{signal:AbortSignal.timeout(1200)});
   if(r.ok){const health=await r.json();
    // The unique instance ID prevents attachment to any previously running CALIAN.
    // Require a V8 backend, but do not hardcode an individual feature release
    // (schema discovery, spoken answers, etc. change nlAdapterVersion).
    if(dev || (health.status==='ready' && health.instanceId===instanceId &&
      typeof health.nlAdapterVersion==='string' && health.nlAdapterVersion.startsWith('8-')))return;
   }
  }catch{}
  if(backendStartupError)throw new Error(`${backendStartupError}. Backend log: ${startupLog}`);
  await new Promise(r=>setTimeout(r,250));
 }
 throw new Error(`CALIAN backend did not become ready at ${url}. See backend log: ${startupLog}. The app will not attach to an older server.`);
}
app.whenReady().then(async()=>{try{
 // If PORT is not configured, use a fresh free port per packaged instance.
 // For a configured PORT, fail on collisions instead of silently reusing an old backend.
 const port=dev?configuredPort:await reserveAvailablePort(explicitlyConfiguredPort?configuredPort:0);
 const backendURL=`http://${host}:${port}`;
 startBackend(port);
 await waitBackend(backendURL);
 const win=new BrowserWindow({width:1440,height:920,minWidth:950,minHeight:650,backgroundColor:'#111827',webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}});
 await win.loadURL(dev?'http://127.0.0.1:4300':backendURL);
}catch(e){dialog.showErrorBox('CALIAN AI startup',String(e));app.quit();}});
app.on('window-all-closed',()=>app.quit());
app.on('before-quit',()=>{if(backend)backend.kill();});
