import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {randomBytes} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {WebSocket} from 'ws';

const key=randomBytes(40).toString('hex');
const port=19000+Math.floor(Math.random()*2000);
const base=`http://127.0.0.1:${port}`;
const child=spawn(process.execPath,['server.mjs'],{cwd:fileURLToPath(new URL('../',import.meta.url)),env:{...process.env,VIDEO_DEV_MODE:'1',VIDEO_ADMIN_KEY:key,VIDEO_PUBLIC_ORIGIN:base,VIDEO_PORT:String(port),VIDEO_BIND:'127.0.0.1'},stdio:['ignore','pipe','pipe']});
let err='';child.stderr.on('data',d=>err+=d.toString());
async function ready(){for(let i=0;i<50;i++){try{const r=await fetch(base+'/health');if(r.ok)return;}catch{}await new Promise(r=>setTimeout(r,70));}throw Error('Video service failed to start: '+err);}
async function json(url,options){const r=await fetch(base+url,options);return [r.status,await r.json()];}
function attach(ticket){return new Promise((resolve,reject)=>{const ws=new WebSocket(base.replace('http','ws')+'/signal');const events=[];ws.on('message',raw=>events.push(JSON.parse(raw.toString())));ws.on('error',reject);ws.on('open',()=>{ws.send(JSON.stringify({type:'auth',ticket}));resolve({ws,events});});});}
async function awaitEvent(client,type){for(let i=0;i<80;i++){const event=client.events.find(x=>x.type===type);if(event)return event;await new Promise(r=>setTimeout(r,25));}throw Error('Missing event '+type+': '+JSON.stringify(client.events));}
test('public guest service: only host creates, invitation, admission, isolated signaling, revoke',async()=>{
 await ready();
 try{
  const [status]=await json('/api/host/rooms',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});assert.equal(status,401);
  const [created,room]=await json('/api/host/rooms',{method:'POST',headers:{Authorization:'Bearer '+key,'Content-Type':'application/json'},body:'{}'});assert.equal(created,201);assert.match(room.inviteUrl,/\/i\//);assert.ok(room.hostTicket.length>30);
  assert.equal((await fetch(room.inviteUrl)).status,200);
  assert.equal((await fetch(base+'/api/agents')).status,404,'public gateway does not proxy CALIAN agents');
  const host=await attach(room.hostTicket);await awaitEvent(host,'ready');
  const [joined,guestInfo]=await json('/api/guest/join',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({invite:room.inviteUrl.split('/').pop(),name:'Testing Guest'})});assert.equal(joined,200);
  const guest=await attach(guestInfo.guestTicket);await awaitEvent(guest,'waiting-status');
  const waiting=await awaitEvent(host,'waiting');assert.equal(waiting.name,'Testing Guest');
  guest.ws.send(JSON.stringify({type:'signal',data:{kind:'offer',sdp:'should be blocked'}}));
  await new Promise(r=>setTimeout(r,100));assert.equal(host.events.some(e=>e.type==='signal'),false,'pending guest cannot signal');
  host.ws.send(JSON.stringify({type:'admit',guestId:waiting.guestId}));await awaitEvent(host,'admitted');await awaitEvent(guest,'admitted');
  guest.ws.send(JSON.stringify({type:'signal',data:{kind:'candidate',candidate:{candidate:'a'}}}));
  const forward=await awaitEvent(host,'signal');assert.equal(forward.data.kind,'candidate');
  host.ws.send(JSON.stringify({type:'end'}));await new Promise(r=>setTimeout(r,60));
  const [expired]=await json('/api/guest/join',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({invite:room.inviteUrl.split('/').pop(),name:'Other'})});assert.equal(expired,404);
  host.ws.close();guest.ws.close();
 }finally{child.kill('SIGTERM');}
});
