/** CALIAN public guest-only calling gateway: it never proxies to REQA, AI Core, Ollama or DBAgent. */
import http from 'node:http';
import {createHash, createHmac, randomBytes, timingSafeEqual} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {WebSocketServer, WebSocket} from 'ws';

const DEV = process.env.VIDEO_DEV_MODE === '1';
const PORT = Number(process.env.VIDEO_PORT || 9443);
const HOST = process.env.VIDEO_BIND || '127.0.0.1';
const PUBLIC = (process.env.VIDEO_PUBLIC_ORIGIN || '').replace(/\/+$/, '');
const ADMIN = process.env.VIDEO_ADMIN_KEY || '';
if (!PUBLIC || !(/^https:\/\/[^/?#]+$/i.test(PUBLIC) || (DEV && /^http:\/\/(?:localhost|127\.0\.0\.1)(?::\d+)?$/.test(PUBLIC))))
 throw Error('VIDEO_PUBLIC_ORIGIN must be a public https:// origin (http://localhost only in VIDEO_DEV_MODE=1)');
if (ADMIN.length < 32 || /replace|example|changeme/i.test(ADMIN)) throw Error('Set a random VIDEO_ADMIN_KEY of at least 32 characters');
if (!DEV && /\.example\.(com|net|org)$/i.test(new URL(PUBLIC).hostname))throw Error('Replace the example video domain before starting the public service');
let ICE;
try {ICE=JSON.parse(process.env.VIDEO_ICE_SERVERS || '[{"urls":["stun:stun.l.google.com:19302"]}]');}catch{throw Error('VIDEO_ICE_SERVERS must be a JSON array');}
if (!Array.isArray(ICE) || ICE.some(s=>!s || (typeof s.urls!=='string' && !Array.isArray(s.urls)))) throw Error('Invalid ICE servers');
const TURN_URLS=JSON.parse(process.env.VIDEO_TURN_URLS||'[]');
const TURN_SECRET=process.env.VIDEO_TURN_SHARED_SECRET||'';
if(!Array.isArray(TURN_URLS)||TURN_URLS.some(u=>typeof u!=='string'))throw Error('VIDEO_TURN_URLS must be a JSON string array');
const freshIce=()=>{
 const servers=[...ICE];
 if(TURN_URLS.length&&TURN_SECRET){const username=`${Math.floor(now()/1000)+3600}:calian`;const credential=createHmac('sha1',TURN_SECRET).update(username).digest('base64');servers.push({urls:TURN_URLS,username,credential});}
 return servers;
};
const sha=s=>createHash('sha256').update(s).digest('hex');
const rand=()=>randomBytes(32).toString('base64url');
const equal=(a,b)=>typeof a==='string'&&typeof b==='string'&&a.length===b.length&&timingSafeEqual(Buffer.from(a),Buffer.from(b));
const rooms=new Map();
const invites=new Map();
const tickets=new Map();
const rate=new Map();
const minute=60_000;
const now=()=>Date.now();
function cleanRoom(room){
 rooms.delete(room.id); invites.delete(room.inviteHash);
 for(const h of room.ticketHashes)tickets.delete(h);
 try{room.host?.close(1000,'Meeting closed');}catch{}
 for(const guest of room.guests.values())try{guest.ws?.close(1000,'Meeting closed');}catch{}
}
const cleanup=()=>{for(const r of rooms.values())if(r.expires<=now())cleanRoom(r);for(const [k,v] of rate)if(v.until<now())rate.delete(k);};
const cleanupTimer=setInterval(cleanup,60000);cleanupTimer.unref();
function throttle(req, route, max=15){const key=`${req.socket.remoteAddress}:${route}`;const t=now();let record=rate.get(key);if(!record||record.until<t){record={n:0,until:t+minute};rate.set(key,record);}record.n++;return record.n<=max;}
function respond(res,status,body){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(body));}
async function body(req, limit=8192){let text='';for await(const chunk of req){text+=chunk;if(text.length>limit)throw Error('Request body too large');}return JSON.parse(text||'{}');}
const file=(name)=>readFileSync(path.join(path.dirname(fileURLToPath(import.meta.url)),'public',name));
const security={"Cache-Control":"no-store","X-Content-Type-Options":"nosniff","Referrer-Policy":"no-referrer","Permissions-Policy":"camera=(self), microphone=(self)","Content-Security-Policy":"default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self' ws: wss:; media-src 'self' blob:; form-action 'none'; frame-ancestors 'none'; base-uri 'none'"};
const server=http.createServer(async(req,res)=>{
 try{
  const url=new URL(req.url||'/',PUBLIC);
  if(req.method==='GET'&&url.pathname==='/health'){return respond(res,200,{ready:true,role:'public-video-only'});}
  if(req.method==='GET'&&(url.pathname==='/' || /^\/i\/[A-Za-z0-9_-]{30,}$/.test(url.pathname))){res.writeHead(200,{...security,'Content-Type':'text/html; charset=utf-8'});return res.end(file('guest.html'));}
  if(req.method==='GET' && url.pathname==='/guest.js'){res.writeHead(200,{...security,'Content-Type':'application/javascript; charset=utf-8'});return res.end(file('guest.js'));}
  if(req.method==='GET' && url.pathname==='/guest.css'){res.writeHead(200,{...security,'Content-Type':'text/css; charset=utf-8'});return res.end(file('guest.css'));}
  if(req.method==='POST' && url.pathname==='/api/host/rooms'){
   if(!throttle(req,'host',30))return respond(res,429,{error:'Too many meetings'});
   if(!equal(req.headers.authorization?.replace(/^Bearer /,''), ADMIN))return respond(res,401,{error:'Host API key required'});
   if(rooms.size>=100)return respond(res,503,{error:'Maximum active meetings reached'});
   const id=rand();const invite=rand();const hostTicket=rand();const expires=now()+60*60*1000;
   const r={id,inviteHash:sha(invite),expires,host:null,guestAdmitted:null,guests:new Map(),ticketHashes:new Set([sha(hostTicket)])};
   rooms.set(id,r);invites.set(r.inviteHash,r);tickets.set(sha(hostTicket),{room:r,role:'host'});
   return respond(res,201,{roomId:id,inviteUrl:`${PUBLIC}/i/${invite}`,hostTicket,wsUrl:PUBLIC.replace(/^http/,'ws')+'/signal',iceServers:freshIce(),expiresAt:new Date(expires).toISOString()});
  }
  if(req.method==='POST' && url.pathname==='/api/guest/join'){
   if(!throttle(req,'guest-join',30))return respond(res,429,{error:'Please wait before trying again'});
   const b=await body(req);
   if(typeof b.invite!=='string'||!b.invite.match(/^[\w-]{30,}$/))return respond(res,400,{error:'Invalid invitation'});
   const room=invites.get(sha(b.invite));
   if(!room||room.expires<=now())return respond(res,404,{error:'Invitation expired or revoked'});
   if(room.guests.size>=12)return respond(res,429,{error:'Waiting room is full'});
   const name=String(b.name||'Guest').trim().slice(0,70);
   if(!name)return respond(res,400,{error:'Enter a display name'});
   const guestId=rand();const guestTicket=rand();
   const guest={id:guestId,name,ws:null,admitted:false};room.guests.set(guestId,guest);
   const hash=sha(guestTicket);room.ticketHashes.add(hash);tickets.set(hash,{room,role:'guest',guestId});
   return respond(res,200,{guestTicket,guestId,wsUrl:PUBLIC.replace(/^http/,'ws')+'/signal',iceServers:freshIce(),expiresAt:new Date(room.expires).toISOString()});
  }
  return respond(res,404,{error:'Not found'});
 }catch(e){return respond(res,400,{error:e.message||'Invalid request'});}
});
const wss=new WebSocketServer({noServer:true,maxPayload:24*1024,perMessageDeflate:false});
server.on('upgrade',(req,socket,head)=>{
 if(req.url!=='/signal'){socket.destroy();return;}
 if(!throttle(req,'websocket',60)){socket.destroy();return;}
 wss.handleUpgrade(req,socket,head,ws=>wss.emit('connection',ws,req));
});
const send=(ws,obj)=>{if(ws?.readyState===WebSocket.OPEN)ws.send(JSON.stringify(obj));};
wss.on('connection',(ws)=>{
 let room=null, role=null, guestId=null;
 const authenticationTimer=setTimeout(()=>{if(!role)ws.close(1008,'Authentication required');},8000);
 ws.on('message',(raw)=>{
  try {
   const m=JSON.parse(raw.toString());
   if(!role){
    if(m.type!=='auth'||typeof m.ticket!=='string')return ws.close(1008,'Invalid ticket');
    const info=tickets.get(sha(m.ticket));
    if(!info||info.room.expires<=now())return ws.close(1008,'Expired ticket');
    room=info.room;role=info.role;guestId=info.guestId||null;
    if(role==='host'){if(room.host&&room.host!==ws)room.host.close(1008,'Another host connected');room.host=ws;}
    else {const g=room.guests.get(guestId);if(!g)return ws.close(1008,'Invalid guest');if(g.ws&&g.ws!==ws)g.ws.close(1008,'Reconnected');g.ws=ws;}
    clearTimeout(authenticationTimer);
    send(ws,{type:'ready',role,roomId:room.id,expiresAt:new Date(room.expires).toISOString()});
    if(role==='host')for(const g of room.guests.values())if(!g.admitted&&g.ws)send(ws,{type:'waiting',guestId:g.id,name:g.name});
    if(role==='guest'){const g=room.guests.get(guestId);send(ws,{type:g.admitted?'admitted':'waiting-status'});if(!g.admitted)send(room.host,{type:'waiting',guestId:g.id,name:g.name});}
    return;
   }
   if(m.type==='admit'&&role==='host'){
    const g=room.guests.get(m.guestId);
    if(!g||!g.ws||room.guestAdmitted&&room.guestAdmitted!==g.id)return send(ws,{type:'error',error:'Only one connected guest may be admitted'});
    room.guestAdmitted=g.id;g.admitted=true;
    send(g.ws,{type:'admitted'});send(room.host,{type:'admitted',guestId:g.id,name:g.name});
    return;
   }
   if(m.type==='deny'&&role==='host'){
    const g=room.guests.get(m.guestId);if(g&&!g.admitted){send(g.ws,{type:'denied'});g.ws?.close(1000,'Denied');room.guests.delete(g.id);}return;
   }
   if(m.type==='signal'&&m.data&&['offer','answer','candidate'].includes(m.data.kind)){
    if(role==='host'){
     const g=room.guests.get(room.guestAdmitted);
     if(g?.admitted)send(g.ws,{type:'signal',data:m.data});
    }else if(room.guestAdmitted===guestId && room.guests.get(guestId)?.admitted){send(room.host,{type:'signal',data:m.data});}
    return;
   }
   if(m.type==='end'&&role==='host'){send(room.host,{type:'ended'});cleanRoom(room);return;}
  }catch{send(ws,{type:'error',error:'Invalid signaling message'});}
 });
 ws.on('close',()=>{
  clearTimeout(authenticationTimer);
  if(!room)return;
  if(role==='host'&&room.host===ws){room.host=null;for(const g of room.guests.values())send(g.ws,{type:'host-disconnected'});}
  if(role==='guest'){const g=room.guests.get(guestId);if(g?.ws===ws){room.guests.delete(guestId);if(room.guestAdmitted===guestId)room.guestAdmitted=null;send(room.host,{type:'guest-left',guestId});}}
 });
});
server.listen(PORT,HOST,()=>console.log(`CALIAN public video-only service listening on ${HOST}:${PORT}, public origin ${PUBLIC}`));
export {server,rooms,cleanRoom};
