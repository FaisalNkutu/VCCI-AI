'use strict';
const $=id=>document.getElementById(id);
let ws=null,pc=null,media=null,iceServers=[],pendingCandidates=[];
const invite=decodeURIComponent(location.pathname.split('/').pop()||'');
const status=s=>{$('status').textContent=s;};
const error=s=>{$('error').textContent=s;};
const send=data=>{if(ws?.readyState===WebSocket.OPEN)ws.send(JSON.stringify(data));};
function closeMedia(){media?.getTracks().forEach(t=>t.stop());media=null;pendingCandidates=[];if(pc){pc.close();pc=null;}$('localVideo').srcObject=null;$('remoteVideo').srcObject=null;}
async function startMedia(){
 if(!navigator.mediaDevices?.getUserMedia)throw Error('Camera and microphone require HTTPS and a compatible browser.');
 media=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true},video:{width:{ideal:960},height:{ideal:540}}});
 $('localVideo').srcObject=media;
}
async function initPc(){
 if(pc)return;
 pc=new RTCPeerConnection({iceServers});
 for(const track of media?.getTracks()||[])pc.addTrack(track,media);
 pc.ontrack=e=>{$('remoteVideo').srcObject=e.streams[0];};
 pc.onicecandidate=e=>{if(e.candidate)send({type:'signal',data:{kind:'candidate',candidate:e.candidate}});};
 pc.onconnectionstatechange=()=>{if(pc&&['failed','disconnected'].includes(pc.connectionState))status('Connection interrupted. Check the network or TURN server.');};
}
async function signal(data){
 if(!data||!['offer','answer','candidate'].includes(data.kind))return;
 await initPc();
 if(data.kind==='offer'){
  await pc.setRemoteDescription({type:'offer',sdp:data.sdp});
  for(const c of pendingCandidates)await pc.addIceCandidate(c);pendingCandidates=[];
  const answer=await pc.createAnswer();await pc.setLocalDescription(answer);
  send({type:'signal',data:{kind:'answer',sdp:answer.sdp}});
  status('Call connected.');
 }else if(data.kind==='candidate'&&data.candidate){try{if(!pc.remoteDescription)pendingCandidates.push(data.candidate);else await pc.addIceCandidate(data.candidate);}catch(e){console.warn('ICE candidate',e);}}
}
$('joinBtn').addEventListener('click',async()=>{
 $('joinBtn').disabled=true;error('');
 try{
  const name=$('displayName').value.trim();if(!name)throw Error('Enter your display name.');
  await startMedia();
  const response=await fetch('/api/guest/join',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({invite,name})});
  const b=await response.json();if(!response.ok)throw Error(b.error||`Join failed (${response.status})`);
  iceServers=b.iceServers;$('join').hidden=true;$('call').hidden=false;status('Waiting for host approval…');
  ws=new WebSocket(b.wsUrl);
  ws.onopen=()=>send({type:'auth',ticket:b.guestTicket});
  ws.onmessage=async e=>{try{const m=JSON.parse(e.data);if(m.type==='waiting-status')status('Waiting for the host to admit you…');else if(m.type==='admitted'){status('Admitted. Connecting media…');await initPc();}else if(m.type==='signal')await signal(m.data);else if(m.type==='denied')status('The host declined this request.');else if(m.type==='host-disconnected')status('Host disconnected. Waiting for reconnection…');else if(m.type==='ended'){status('The call has ended.');closeMedia();}else if(m.type==='error')error(m.error);}catch(x){error(x.message);}};
  ws.onclose=()=>{status('Call connection closed.');closeMedia();};
 }catch(e){error(e.message);closeMedia();$('joinBtn').disabled=false;}
});
$('muteBtn').addEventListener('click',()=>{const t=media?.getAudioTracks()[0];if(t){t.enabled=!t.enabled;$('muteBtn').textContent=t.enabled?'Mute microphone':'Unmute microphone';}});
$('cameraBtn').addEventListener('click',()=>{const t=media?.getVideoTracks()[0];if(t){t.enabled=!t.enabled;$('cameraBtn').textContent=t.enabled?'Turn camera off':'Turn camera on';}});
$('leaveBtn').addEventListener('click',()=>{ws?.close();closeMedia();status('You have left the call.');});
window.addEventListener('beforeunload',()=>{ws?.close();closeMedia();});
