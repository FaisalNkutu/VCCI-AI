$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$install = Join-Path $env:LOCALAPPDATA 'CalianAI\speech'
if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) { throw 'LOCALAPPDATA is missing.' }
New-Item -ItemType Directory -Force -Path $install | Out-Null
$exe = Join-Path $install 'whisper-cli.exe'
$model = Join-Path $install 'ggml-small.en.bin'
$tmp = Join-Path $env:TEMP ('calian-whisper-setup-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $tmp | Out-Null
try {
 if (-not (Test-Path $exe)) {
  # Official whisper.cpp b5454 Windows x64 CPU build (v1.9.5).
  $zipPath = Join-Path $tmp 'whisper.zip'
  Write-Host 'Downloading official whisper.cpp Windows x64 binary...'
  Invoke-WebRequest -UseBasicParsing -Uri 'https://github.com/ggml-org/whisper.cpp/releases/download/b5454/whisper-bin-x64.zip' -OutFile $zipPath
  $out = Join-Path $tmp 'bin'; Expand-Archive -Path $zipPath -DestinationPath $out -Force
  $cli = Get-ChildItem -Path $out -Recurse -Filter 'whisper-cli.exe' -File | Select-Object -First 1
  if ($null -eq $cli) { throw 'The official archive did not contain whisper-cli.exe.' }
  Copy-Item -Path (Join-Path $cli.Directory.FullName '*') -Destination $install -Recurse -Force
 }
 if (-not (Test-Path $model) -or (Get-Item $model).Length -lt 350000000) {
  $partial = Join-Path $tmp 'ggml-small.en.bin'
  Write-Host 'Downloading accurate English Whisper model (approximately 460 MB, one time)...'
  Invoke-WebRequest -UseBasicParsing -Uri 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.en.bin?download=true' -OutFile $partial
  if ((Get-Item $partial).Length -lt 350000000) { throw 'The Whisper model download was incomplete.' }
  Move-Item -Path $partial -Destination $model -Force
 }
 if (-not (Test-Path $exe)) { throw 'Could not install whisper-cli.exe.' }
 Write-Host 'SUCCESS. Local Whisper executable and model installed at:' -ForegroundColor Green
 Write-Host $install
 Write-Host 'The audio is now processed offline and is not sent to any third-party transcription API.'
} finally { Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $tmp }
