/** Offline speech recognition for CALIAN.AI using whisper.cpp on Windows.
 * No uploads to a remote service. The model and binary are installed separately
 * with the supplied one-time installer, never inside a Docker container.
 */
import type {Express, Request, Response} from 'express';
import express from 'express';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawn, type ChildProcessWithoutNullStreams} from 'node:child_process';
import {randomUUID} from 'node:crypto';

const MAX_WAV_BYTES=3_000_000;
const MAX_SECONDS=45;
const MODEL_NAMES=['ggml-small.en.bin','ggml-base.en.bin'];

function speechDirectory(){
 return process.env.CALIAN_WHISPER_DIR || path.join(process.env.LOCALAPPDATA || path.join(os.homedir(),'AppData','Local'),'CalianAI','speech');
}
function localEngine(){
 const directory=speechDirectory();
 const executable=path.join(directory,'whisper-cli.exe');
 const model=MODEL_NAMES.map(n=>path.join(directory,n)).find(p=>fs.existsSync(p) && fs.statSync(p).size>100_000_000);
 return fs.existsSync(executable)&&model?{directory,executable,model}:null;
}
export function verifySpeechWav(buffer:Buffer):string|null{
 if(buffer.length<44||buffer.length>MAX_WAV_BYTES)return 'Invalid audio size: recording must be 16 kHz PCM WAV, at most 45 seconds.';
 if(buffer.toString('ascii',0,4)!=='RIFF'||buffer.toString('ascii',8,12)!=='WAVE'||buffer.toString('ascii',12,16)!=='fmt ')
  return 'Invalid WAV header.';
 if(buffer.readUInt32LE(16)!==16||buffer.readUInt16LE(20)!==1||buffer.readUInt16LE(22)!==1||buffer.readUInt32LE(24)!==16000||buffer.readUInt16LE(34)!==16)
  return 'Unsupported audio format: expected mono, 16-bit PCM at 16 kHz.';
 if(buffer.toString('ascii',36,40)!=='data'||buffer.readUInt32LE(40)!==buffer.length-44||buffer.length%2!==0)
  return 'Invalid WAV audio length.';
 const seconds=(buffer.length-44)/32000;
 if(seconds<0.2||seconds>MAX_SECONDS+0.2)return 'Record between 0.2 and 45 seconds.';
 return null;
}
function transcribe(executable:string,model:string,wav:string,prefix:string):Promise<string>{
 return new Promise((resolve,reject)=>{
  const args=['-m',model,'-f',wav,'-l','en','-nt','-otxt','-of',prefix,'--prompt',
   'CALIAN AI, DBAgent, REQA, MariaDB, SQL, context_ol_assoc, execute_sql, Ollama.'];
  const child:ChildProcessWithoutNullStreams=spawn(executable,args,{windowsHide:true,stdio:['ignore','pipe','pipe']});
  let log='';let done=false;
  const timeout=setTimeout(()=>{child.kill();complete(new Error('Whisper transcription exceeded 120 seconds. Try a shorter recording or the base.en model.'));},120000);
  function complete(error?:Error){
   if(done)return;done=true;clearTimeout(timeout);
   if(error){reject(error);return;}
   try{
    const text=fs.readFileSync(prefix+'.txt','utf8').trim();
    if(!text)throw new Error('Whisper found no words. Check your microphone and speak closer to it.');
    resolve(text);
   }catch(e){reject(e instanceof Error?e:new Error(String(e)));}
  }
  child.stderr.setEncoding('utf8');
  child.stderr.on('data',(chunk:string)=>{log=(log+chunk).slice(-3000);});
  child.on('error',err=>complete(new Error('Whisper could not start: '+err.message)));
  child.on('close',code=>complete(code===0?undefined:new Error('Whisper failed: '+log.slice(-600))));
 });
}
let busy=false;
const sameOrigin=(req:Request)=>{
 const origin=req.headers.origin;
 if(!origin)return true;
 try{
  const url=new URL(origin);
  return url.protocol==='http:'&&['127.0.0.1','localhost'].includes(url.hostname)&&[String(req.socket.localPort),'4300'].includes(url.port);
 }catch{return false;}
};
export function registerWhisperSpeech(app:Express){
 app.get('/api/speech/status',(req,res)=>{
  if(!sameOrigin(req)){res.status(403).json({error:'Untrusted origin'});return;}
  const engine=localEngine();
  res.json({available:!!engine,engine:'Whisper (offline)',model:engine?path.basename(engine.model):null,
   setupNeeded:!engine,install:'Run SETUP-ACCURATE-SPEECH-WINDOWS.bat once from the extracted package.'});
 });
 app.post('/api/speech/transcribe',express.raw({type:'audio/wav',limit:'3mb'}),async(req:Request,res:Response)=>{
  if(!sameOrigin(req)){res.status(403).json({error:'Untrusted origin'});return;}
  const engine=localEngine();
  if(!engine){res.status(503).json({error:'Accurate speech is not set up. Run SETUP-ACCURATE-SPEECH-WINDOWS.bat from your extracted V8 package once, or use Windows voice typing (Win + H) in the message box.'});return;}
  if(busy){res.status(429).json({error:'Speech transcription is already running.'});return;}
  const wav=req.body;
  if(!Buffer.isBuffer(wav)){res.status(415).json({error:'Expected audio/wav body.'});return;}
  const problem=verifySpeechWav(wav);
  if(problem){res.status(400).json({error:problem});return;}
  busy=true;
  let temp='';
  try{
   temp=fs.mkdtempSync(path.join(os.tmpdir(),'calian-speech-'));
   const audio=path.join(temp,randomUUID()+'.wav');
   const out=path.join(temp,'text');
   fs.writeFileSync(audio,wav,{flag:'wx'});
   const text=await transcribe(engine.executable,engine.model,audio,out);
   // Cosmetic, conservative cleanup of a specific spoken table name only.
   const transcript=text.replace(/\bcontext[ _-]+(?:oh[ _-]+ell|o[ _-]*l|ol)[ _-]+assoc\b/gi,'context_ol_assoc');
   res.json({transcript,engine:'whisper.cpp',model:path.basename(engine.model)});
  }catch(e){res.status(502).json({error:e instanceof Error?e.message:String(e)});}
  finally{busy=false;if(temp)fs.rmSync(temp,{force:true,recursive:true});}
 });
}
