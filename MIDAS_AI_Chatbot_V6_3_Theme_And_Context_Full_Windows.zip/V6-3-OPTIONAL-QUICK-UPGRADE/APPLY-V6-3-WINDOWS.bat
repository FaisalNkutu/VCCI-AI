@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLY-V6-3-WINDOWS.ps1"
echo.
pause
