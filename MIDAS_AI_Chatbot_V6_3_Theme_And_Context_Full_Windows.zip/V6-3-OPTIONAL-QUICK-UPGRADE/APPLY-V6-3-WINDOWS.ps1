﻿param([string]$ProjectRoot = '')
$ErrorActionPreference = 'Stop'
$patchRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$old = @{
  'midas\midas-frontend\src\app\components\calian-ai\midas-calian-copilot.component.ts' = 'b1cf22fbc3e0363a91e72e21d23e6591123bb97d372e80e8a349c1f2078e8db9'
  'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\app.component.ts' = 'da8911eec1111317ea89208a68cc01df8eedee2ee73809b1a73837f0356bf42c'
  'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\app.component.html' = '71013ffd70e7d05777c3f6bf3adfc8f71bf531343aac9c81d9997c208cd0a65a'
  'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\app.component.scss' = '43691912cfb27b04124461e4806a550c1251371e5d7a2776ad5ff330e5b35693'
  'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\midas-bridge.ts' = 'dc3dbd169b425c6b6955b40f1d4c7752a428acfe719e5607b9221def2d497adc'
}
$new = @{
  'midas\midas-frontend\src\app\components\calian-ai\midas-calian-copilot.component.ts' = '007a3ee0066846f08f8f3652d3b96a18cd30472eb612eb2d8f592b3851267741'
  'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\app.component.ts' = '1c2aa1729caebd3d8581a78ccf2a10c57452ee2698881db3db807ecf2fdcff77'
  'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\app.component.html' = '8a86e26745095a43662491baba984ecf0925f742f3e79d37aceaad62712fc4cc'
  'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\app.component.scss' = '379d4380c34e6de5628f4de71f0e9818f32570b16347e8fbff253bcc4160815b'
  'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\midas-bridge.ts' = 'b9dc846eaf7b4b45368dc74eb302804df7a3e9644998b42c4f56c7e1a7c7dd51'
}
function IsProject([string]$path) {
  return ((Test-Path -LiteralPath (Join-Path $path 'midas\midas-frontend\package.json')) -and
          (Test-Path -LiteralPath (Join-Path $path 'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\package.json')))
}
Write-Host 'AI Chatbot V6.3 — MIDAS Theme and Selected Context' -ForegroundColor Cyan
if (-not $ProjectRoot) {
  $candidates = New-Object System.Collections.Generic.List[string]
  $download = Join-Path $env:USERPROFILE 'Downloads'
  # Search only folders at shallow depths; never traverse node_modules or private files.
  $top = @((Get-Item -LiteralPath $download))
  $one = @(Get-ChildItem -LiteralPath $download -Directory -ErrorAction SilentlyContinue)
  $two = @($one | ForEach-Object { Get-ChildItem -LiteralPath $_.FullName -Directory -ErrorAction SilentlyContinue })
  $three = @($two | ForEach-Object { Get-ChildItem -LiteralPath $_.FullName -Directory -ErrorAction SilentlyContinue })
  foreach ($entry in @($top) + @($one) + @($two) + @($three)) {
    if ($entry -and (IsProject $entry.FullName) -and (-not $candidates.Contains($entry.FullName))) { [void]$candidates.Add($entry.FullName) }
  }
  if ($candidates.Count -gt 0) {
    Write-Host 'Found these complete MIDAS + AI Chatbot source folders:' -ForegroundColor Yellow
    for ($i=0; $i -lt $candidates.Count; $i++) { Write-Host ('  {0}. {1}' -f ($i+1),$candidates[$i]) }
    $answer=Read-Host 'Choose the number of the currently running installation (or press Enter for a custom path)'
    $index=0
    if ([int]::TryParse($answer,[ref]$index) -and $index -ge 1 -and $index -le $candidates.Count) { $ProjectRoot=$candidates[$index-1] }
  }
  if (-not $ProjectRoot) { $ProjectRoot=Read-Host 'Enter full path to extracted MIDAS + AI Chatbot source folder' }
}
$ProjectRoot = $ProjectRoot.Trim('"').Trim()
if (-not (IsProject $ProjectRoot)) { throw "Not a MIDAS + AI Chatbot project root: $ProjectRoot" }
$pending = @()
foreach ($key in $old.Keys) {
  $dest = Join-Path $ProjectRoot $key
  $source = Join-Path $patchRoot ('PATCH_FILES\'+$key)
  if (-not (Test-Path -LiteralPath $source)) { throw "Patch file missing: $key" }
  if (-not (Test-Path -LiteralPath $dest)) { throw "Target source missing: $key" }
  $actual = (Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($actual -eq $new[$key]) { Write-Host "Already updated: $key" -ForegroundColor Gray; continue }
  if ($actual -ne $old[$key]) { throw "Unexpected local changes in $key. Update stopped to avoid overwriting edits. Please compare the source manually." }
  $pending += $key
}
if ($pending.Count -eq 0) { Write-Host 'All five source files are already updated.' -ForegroundColor Green; exit 0 }
Write-Host ("Project: " + $ProjectRoot) -ForegroundColor Cyan
Write-Host ("Files to update: " + $pending.Count)
if ((Read-Host 'Type APPLY to back up and update these files') -cne 'APPLY') { Write-Host 'Cancelled; no files changed.'; exit 0 }
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backup = Join-Path $ProjectRoot ('BACKUPS\AI_Chatbot_V6_3_' + $stamp)
foreach ($key in $pending) {
  $dest = Join-Path $ProjectRoot $key
  $backedUp = Join-Path $backup $key
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $backedUp) | Out-Null
  Copy-Item -LiteralPath $dest -Destination $backedUp -Force
}
foreach ($key in $pending) {
  $source = Join-Path $patchRoot ('PATCH_FILES\'+$key)
  $dest = Join-Path $ProjectRoot $key
  Copy-Item -LiteralPath $source -Destination $dest -Force
  if ((Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash.ToLowerInvariant() -ne $new[$key]) { throw "File verification failed: $key. Restore from $backup" }
  Write-Host ('UPDATED: '+$key) -ForegroundColor Green
}
Write-Host 'Complete. Existing processes were not stopped. Let Angular recompile, then refresh browser with Ctrl+Shift+R.' -ForegroundColor Green
Write-Host ('Backup location: '+$backup)
