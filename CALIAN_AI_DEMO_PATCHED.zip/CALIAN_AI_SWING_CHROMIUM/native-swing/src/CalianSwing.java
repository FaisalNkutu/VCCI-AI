import javax.swing.*;
import java.awt.*;
import java.net.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;

/** Native Swing frontend. Uses existing Calian backend; does not require Angular or Chromium. */
public final class CalianSwing {
  private static final String API = System.getProperty("calian.api", "http://127.0.0.1:8787");
  private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
  private final JFrame frame = new JFrame("CALIAN AI | Native Swing");
  private final JTextArea log = new JTextArea(), input = new JTextArea(4,50);
  private final JComboBox<Agent> selector = new JComboBox<>();
  private final JCheckBox selectionOnly = new JCheckBox("Test selection only", true);
  private final JLabel status = new JLabel("Ready");
  private final JButton send = new JButton("Send"), refresh = new JButton("Refresh agents");
  private final ExecutorService worker = Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"calian-http");t.setDaemon(true);return t;});
  private final List<Agent> agents = new ArrayList<>();
  private String contextId = UUID.randomUUID().toString();
  record Agent(String id,String name,String type,List<String> commands) {public String toString(){return name+" ["+type+"]";}}
  public static void main(String[] args) {SwingUtilities.invokeLater(()->new CalianSwing().start());}
  void start(){
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);frame.setSize(1000,730);frame.setMinimumSize(new Dimension(720,480));frame.setLocationRelativeTo(null);
    log.setEditable(false);log.setFont(new Font(Font.MONOSPACED,Font.PLAIN,13));log.setLineWrap(true);log.setWrapStyleWord(true);
    input.setLineWrap(true);input.setWrapStyleWord(true);
    JPanel top=new JPanel(new FlowLayout(FlowLayout.LEFT));top.add(new JLabel("Agent:"));top.add(selector);top.add(refresh);top.add(selectionOnly);
    JButton newSession=new JButton("New session");top.add(newSession);
    JPanel bottom=new JPanel(new BorderLayout(6,6));bottom.add(new JScrollPane(input),BorderLayout.CENTER);bottom.add(send,BorderLayout.EAST);
    JPanel foot=new JPanel(new BorderLayout());foot.add(bottom,BorderLayout.CENTER);foot.add(status,BorderLayout.SOUTH);
    frame.add(top,BorderLayout.NORTH);frame.add(new JScrollPane(log),BorderLayout.CENTER);frame.add(foot,BorderLayout.SOUTH);
    selector.addItem(new Agent("","Intelligent Auto Select","auto",List.of()));
    refresh.addActionListener(e->refresh());send.addActionListener(e->send());
    newSession.addActionListener(e->{contextId=UUID.randomUUID().toString();log.setText("");status.setText("New session");});
    frame.setVisible(true);refresh();
  }
  void busy(boolean b,String text){SwingUtilities.invokeLater(()->{send.setEnabled(!b);refresh.setEnabled(!b);status.setText(text);});}
  void append(String s){SwingUtilities.invokeLater(()->{log.append(s+"\n\n");log.setCaretPosition(log.getDocument().getLength());});}
  String request(String method,String path,String body)throws Exception{
    HttpRequest.Builder b=HttpRequest.newBuilder(URI.create(API+path)).timeout(Duration.ofSeconds(90));
    b.header("Accept","application/json");
    if(method.equals("POST"))b.header("Content-Type","application/json").POST(HttpRequest.BodyPublishers.ofString(body,StandardCharsets.UTF_8));else b.GET();
    HttpResponse<String> response=http.send(b.build(),HttpResponse.BodyHandlers.ofString());
    if(response.statusCode()/100!=2)throw new Exception("HTTP "+response.statusCode()+": "+response.body());return response.body();
  }
  void refresh(){busy(true,"Discovering agents...");worker.submit(()->{
    List<Agent> found=new ArrayList<>();StringBuilder errors=new StringBuilder();
    try{Object py=Json.parse(request("GET","/api/agents",null));Object entries=prop(py,"agents");if(entries instanceof List<?> list)for(Object o:list){String id=str(prop(o,"id"));if(!id.isBlank())found.add(new Agent(id,defaultName(prop(o,"name"),id),"north",List.of()));}}catch(Exception e){errors.append("Python: ").append(e.getMessage()).append(" ");}
    try{Object core=Json.parse(request("GET","/api/ai-core/agents",null));Object entries=prop(core,"agents");if(entries instanceof List<?> list){for(Object o:list){String id=defaultName(prop(o,"id"),str(prop(o,"name")));if(!id.isBlank())found.add(new Agent(id,defaultName(prop(o,"name"),id),"aicore",strings(prop(o,"commands"))));}
      }else if(entries instanceof Map<?,?> map){for(Object id:map.keySet())found.add(new Agent(str(id),str(id),"aicore",List.of()));}
      else {Object cmds=prop(core,"commandList"),urls=prop(core,"agentURLs");Set<String> ids=new LinkedHashSet<>();if(cmds instanceof Map<?,?> m)for(Object id:m.keySet())ids.add(str(id));if(urls instanceof Map<?,?> m)for(Object id:m.keySet())ids.add(str(id));for(String id:ids)found.add(new Agent(id,id,"aicore",strings(prop(cmds,id))));}
    }catch(Exception e){errors.append("AI Core: ").append(e.getMessage());}
    SwingUtilities.invokeLater(()->{agents.clear();agents.addAll(found);selector.removeAllItems();selector.addItem(new Agent("","Intelligent Auto Select","auto",List.of()));for(Agent a:found)selector.addItem(a);status.setText("Discovered "+found.size()+" agents. "+errors);send.setEnabled(true);refresh.setEnabled(true);});
  });}
  void send(){String message=input.getText().trim();if(message.isEmpty())return;Agent chosen=(Agent)selector.getSelectedItem();input.setText("");append("YOU: "+message);busy(true,"Routing...");worker.submit(()->{
    try{
      Agent selected=chosen;
      if(selected==null||selected.type.equals("auto")){
        List<Object> catalog=new ArrayList<>();for(Agent a:agents){Map<String,Object> row=new LinkedHashMap<>();row.put("id",a.id);row.put("name",a.name);row.put("type",a.type);row.put("commands",a.commands);catalog.add(row);}
        Map<String,Object> req=new LinkedHashMap<>();req.put("message",message);req.put("agents",catalog);req.put("contextId",contextId);
        Object result=Json.parse(request("POST","/api/router/select",Json.stringify(req)));
        Object agent=prop(result,"agent");if(!(agent instanceof Map<?,?>)){append("ROUTER: "+defaultName(prop(result,"reason"),"No agent selected"));return;}
        String method=defaultName(prop(result,"method"),"unspecified");append("ROUTER ["+method+"]: "+defaultName(prop(agent,"name"),str(prop(agent,"id")))+" — "+str(prop(result,"reason")));
        if(prop(result,"ollamaFallbackReason")!=null)append("OLLAMA FALLBACK: "+str(prop(result,"ollamaFallbackReason")));
        selected=new Agent(str(prop(agent,"id")),str(prop(agent,"name")),str(prop(agent,"type")),List.of());
      }
      if(selectionOnly.isSelected()){append("Selection-only mode: no agent executed.");return;}
      if(selected.type.equals("aicore")){
        Map<String,Object> req=Map.of("agentId",selected.id,"message",message,"contextId",contextId,"context",Map.of());
        append("AI CORE: "+request("POST","/api/ai-core/execute",Json.stringify(req)));
      }else{
        Map<String,Object> msg=new LinkedHashMap<>();msg.put("messageId",UUID.randomUUID().toString());msg.put("role","ROLE_USER");msg.put("contextId",contextId);msg.put("parts",List.of(Map.of("text",message)));msg.put("metadata",Map.of("agent_id",selected.id));
        Map<String,Object> req=Map.of("jsonrpc","2.0","id",UUID.randomUUID().toString(),"method","SendStreamingMessage","params",Map.of("message",msg));
        append("PYTHON / A2A: "+request("POST","/api/a2a",Json.stringify(req)));
      }
    }catch(Exception e){append("ERROR: "+e.getMessage());}finally{busy(false,"Ready");}
  });}
  static Object prop(Object o,String key){return o instanceof Map<?,?> m?m.get(key):null;}
  static String str(Object o){return o==null?"":String.valueOf(o);}
  static String defaultName(Object o,String fallback){String s=str(o);return s.isBlank()?fallback:s;}
  static List<String> strings(Object o){if(!(o instanceof List<?> l))return List.of();List<String> out=new ArrayList<>();for(Object v:l)out.add(str(v));return out;}
  static class Json{
    final String s;int i;Json(String s){this.s=s;}
    static Object parse(String s){Json p=new Json(s);Object v=p.val();p.ws();if(p.i!=s.length())throw new IllegalArgumentException("Invalid JSON trailing content");return v;}
    void ws(){while(i<s.length()&&Character.isWhitespace(s.charAt(i)))i++;}
    char peek(){ws();return i<s.length()?s.charAt(i):'\0';}
    void expect(char c){ws();if(i>=s.length()||s.charAt(i++)!=c)throw new IllegalArgumentException("Expected "+c);}
    Object val(){char c=peek();if(c=='"')return string();if(c=='{'){expect('{');Map<String,Object> m=new LinkedHashMap<>();if(peek()=='}'){i++;return m;}do{String k=string();expect(':');m.put(k,val());if(peek()=='}'){i++;return m;}expect(',');}while(true);}if(c=='['){expect('[');List<Object> l=new ArrayList<>();if(peek()==']'){i++;return l;}do{l.add(val());if(peek()==']'){i++;return l;}expect(',');}while(true);}if(s.startsWith("true",i)){i+=4;return true;}if(s.startsWith("false",i)){i+=5;return false;}if(s.startsWith("null",i)){i+=4;return null;}int start=i;while(i<s.length()&&"-+.0123456789eE".indexOf(s.charAt(i))>=0)i++;if(start==i)throw new IllegalArgumentException("Invalid JSON at "+i);return Double.parseDouble(s.substring(start,i));}
    String string(){expect('"');StringBuilder b=new StringBuilder();while(i<s.length()){char c=s.charAt(i++);if(c=='"')return b.toString();if(c=='\\'){if(i>=s.length())break;char e=s.charAt(i++);switch(e){case 'n'->b.append('\n');case 'r'->b.append('\r');case 't'->b.append('\t');case 'b'->b.append('\b');case 'f'->b.append('\f');case 'u'->{if(i+4>s.length())throw new IllegalArgumentException("Bad unicode");b.append((char)Integer.parseInt(s.substring(i,i+4),16));i+=4;}default->b.append(e);}}else b.append(c);}throw new IllegalArgumentException("Unterminated string");}
    static String stringify(Object o){if(o==null)return "null";if(o instanceof String s)return "\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r").replace("\t","\\t")+"\"";if(o instanceof Map<?,?> m){List<String> out=new ArrayList<>();for(var e:m.entrySet())out.add(stringify(String.valueOf(e.getKey()))+":"+stringify(e.getValue()));return "{"+String.join(",",out)+"}";}if(o instanceof Collection<?> l){List<String> out=new ArrayList<>();for(Object x:l)out.add(stringify(x));return "["+String.join(",",out)+"]";}return String.valueOf(o);}
  }
}
