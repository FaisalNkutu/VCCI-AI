@echo off
setlocal
cd /d "%~dp0"
echo CALIAN AI Demo - Starting backend and Angular
where npm >nul 2>nul || (echo ERROR: Node.js/npm not found & pause & exit /b 1)
where java >nul 2>nul || (echo ERROR: Java not found & pause & exit /b 1)
where mvn >nul 2>nul || (echo ERROR: Maven not found & pause & exit /b 1)
start "CALIAN BACKEND" cmd /k "cd /d "%~dp0calian-ai-angular-material" && npm run dev:server"
start "CALIAN ANGULAR" cmd /k "cd /d "%~dp0calian-ai-angular-material" && npm run dev:client"
echo Waiting for Angular to respond on port 4200...
powershell -NoProfile -Command "$ok=$false; for($i=0;$i -lt 90;$i++){try{$r=Invoke-WebRequest -UseBasicParsing 'http://127.0.0.1:4200' -TimeoutSec 2; if($r.StatusCode -eq 200){$ok=$true;break}}catch{};Start-Sleep -Seconds 2}; if(-not $ok){exit 1}"
if errorlevel 1 (echo ERROR: Angular did not start. Check CALIAN ANGULAR window. & pause & exit /b 1)
echo Angular ready. Starting embedded Chromium Swing host...
cd /d "%~dp0swing-host"
mvn clean compile exec:java
if errorlevel 1 (echo Swing host failed. Angular remains available at http://127.0.0.1:4200 & pause)
