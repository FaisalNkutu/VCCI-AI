@echo off
cd /d "%~dp0calian-ai-angular-material"
if not exist node_modules call npm install || exit /b 1
npm run dev
