# CALIAN AI — Swing Chromium host

This replaces the blank JavaFX WebView with embedded Chromium (JCEF via jcefmaven). The Angular application and its backend are unchanged.

## PowerShell (Windows, Java 21)

Terminal 1 (project root):

```powershell
cd calian-ai-angular-material
npm install
Copy-Item .env.example .env  # only if .env does not already exist
npm run dev
```

Verify http://127.0.0.1:4200 in Chrome.

Terminal 2 (project root):

```powershell
cd swing-host
mvn -U clean compile exec:java
```

First run may download the native Chromium runtime; allow time and network access. Requires Windows x64. Do not run the old JavaFX launcher. Existing AI services must also be running for agent calls.

This integration is not verified on your machine. If Maven reports an unresolved JCEF artifact or native-runtime error, send the complete first error message. Do not modify Angular or agent routing to address browser initialization errors.
