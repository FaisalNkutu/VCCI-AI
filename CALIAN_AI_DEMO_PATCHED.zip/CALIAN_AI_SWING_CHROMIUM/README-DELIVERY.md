# CALIAN AI — Angular + native Swing edition

## Native Swing (does not need Angular or Chromium)
1. Install Java JDK 17+ and Node.js 20+. Keep Ollama running with `llama3.2` available.
2. Start `RUN-BACKEND.bat` and leave the window open.
3. Start `native-swing/RUN-SWING.bat`. This compiles and launches the native Swing UI using only the JDK.
4. Click **Refresh agents** and send a message. Uncheck **Test selection only** to execute agents.

## Angular UI
Start `RUN-ANGULAR.bat` (instead of `RUN-BACKEND.bat`), then visit http://127.0.0.1:4200.

## Required external integrations
The backend expects a Python/A2A service at port 9999 and AI Core registry at port 9801 unless configured otherwise. Those external services and agents are not bundled. When they are offline, discovery/execution cannot succeed.

## Ollama routing
`.env` enables local Ollama at 127.0.0.1:11434 with `llama3.2`. Routing returns `method: ollama` when local model selection succeeds, and `method: metadata` for fallback. If Ollama errors, `ollamaFallbackReason` explains why. Candidate agents are matched against server-discovered agents.

## Limits
The Swing UI is a **native** desktop client, not a Chromium wrapper. Python/A2A streaming currently displays the raw upstream response after completion; advanced SSE rendering remains in the Angular UI. No live integration tests against your running AI Core or Python services have been performed here.
