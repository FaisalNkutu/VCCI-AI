import { Component, OnInit, ViewChild, ElementRef, AfterViewChecked, NgZone, OnDestroy } from '@angular/core';
import {isDatabaseRetrievalRequest} from './db-intent';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SocketService } from './socket.service';
import { VideoCenterComponent } from './video-center.component';
import { speechSummary } from './result-speech';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatTabsModule } from '@angular/material/tabs';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { Agent, Turn, SharedContext, normalizePythonAgents, normalizeCoreAgents, a2aRequest, coreText } from './protocol';
import { acceptV7Context, MidasV7Context } from './midas-v7-context';
import { interpretV7Action } from './midas-v7-natural-language';
import { MIDAS_BRIDGE_ID, MidasCapabilities, MidasContext, MidasRequest, parseMidasCommand, explainMidasCommand, suggestedActionFromAgent } from './midas-bridge';
@Component({selector:'app-root',standalone:true,imports:[VideoCenterComponent,CommonModule,FormsModule,MatToolbarModule,MatButtonModule,MatIconModule,MatCardModule,MatFormFieldModule,MatInputModule,MatListModule,MatTabsModule,MatCheckboxModule,MatProgressSpinnerModule,MatTooltipModule,MatSidenavModule,MatSnackBarModule],templateUrl:'./app.component.html',styleUrl:'./app.component.scss'})
export class AppComponent implements OnInit,AfterViewChecked,OnDestroy {
 // Popup controls must live IN the popup. Clicking sizing buttons in MIDAS
 // foregrounds the host and makes a separate chat window appear to disappear.
 readonly isMidasPopup = typeof window !== 'undefined' && window.parent === window && !!window.opener;
 popupSizeNotice = '';
 resizeThisPopup(mode: 'compact' | 'standard' | 'large'): void {
  if (!this.isMidasPopup) return;
  const dimensions = mode === 'compact' ? [900, 650] : mode === 'large' ? [1400, 900] : [1100, 800];
  const width = Math.min(dimensions[0], Math.max(400, window.screen.availWidth - 64));
  const height = Math.min(dimensions[1], Math.max(320, window.screen.availHeight - 96));
  try {
   window.resizeTo(width, height);
   this.popupSizeNotice = `Requested ${width} × ${height}. If blocked by Chrome/Edge, drag the window edges.`;
  } catch {
   this.popupSizeNotice = 'Browser prevented automatic resizing. Drag the window edges instead.';
  }
 }
 centerThisPopup(): void {
  if (!this.isMidasPopup) return;
  const targetX = Math.max(0, Math.round((window.screen.availWidth - window.outerWidth) / 2));
  const targetY = Math.max(0, Math.round((window.screen.availHeight - window.outerHeight) / 2));
  try {
   window.moveTo(targetX, targetY);
   this.popupSizeNotice = 'Center requested. If the browser restricts positioning, drag the title bar.';
  } catch { this.popupSizeNotice = 'Browser prevented automatic positioning. Drag the title bar instead.'; }
 }

 @ViewChild('messagesEnd') messagesEnd?:ElementRef<HTMLElement>;
 activeView:'chat'|'video'='chat';
 // Enlarged, scrollable reading view for agent replies. UI-only; no chat transfer.
 responseReadingMode = false;
 agents:Agent[]=[]; selected='auto'; search=''; history:Turn[]=[]; prompt=''; userContext=''; taskContext=''; systemInstructions=''; contextId: string = crypto.randomUUID(); previousAgentId:string|null=null; busy=false; discovering=false; error=''; notice=''; partial=''; inspectorOpen=true; mobileOpen=false; dark=true; theme:'corporate'|'royal'|'modern'|'classic'|'midas'='corporate'; lastRoute='No routing decision yet'; pythonOnline=false; selectionOnly=false; multiAgentEnabled=true; inspectorTab=0; lastTrace: {agentId:string;agentName:string;status:string;reason:string}[]=[];
 constructor(private socket:SocketService,private snack:MatSnackBar,private zone:NgZone){}
 midasConnected=false; midasShared=false; midasContext:MidasContext|null=null;

 // Database settings belong to DBAgent, not to the MIDAS datasource/context.
 databaseSchema=''; databaseSchemas:string[]=[]; databasePickerEnabled=false; databaseConfigMessage='';
 async loadDatabaseOptions():Promise<void>{
  try {
   const result=await this.get('/api/db/options');
   this.databasePickerEnabled=result?.enabled===true;
   this.databaseSchemas=Array.isArray(result?.schemas)?result.schemas.filter((v:unknown):v is string=>typeof v==='string'):[];
   const saved=localStorage.getItem('ai-chatbot-v7-database-schema')||'';
   const configured=String(result?.configured||'');
   this.databaseSchema=(saved&&this.databaseSchemas.includes(saved)?saved:configured);
   this.databaseConfigMessage=this.databasePickerEnabled
     ? (this.databaseSchemas.length?'Choose the database used by DBAgent queries.':'No databases are currently discoverable through REQA.')
     : 'Database selection is managed by the local backend configuration.';
  }catch(e){this.databaseConfigMessage='Database settings unavailable: '+(e instanceof Error?e.message:String(e));}
 }
 saveDatabaseChoice():void {
  if(this.databaseSchema && !this.databaseSchemas.includes(this.databaseSchema)){
   this.databaseConfigMessage='Please select an accessible database from the list.';return;
  }
  localStorage.setItem('ai-chatbot-v7-database-schema',this.databaseSchema);
  this.databaseConfigMessage=this.databaseSchema?'Selected database: '+this.databaseSchema:'Using the backend default database';
 }
 private isDatabaseQuery(text:string):boolean {
  return isDatabaseRetrievalRequest(text);
 }
 private async sendDatabaseQuery(message:string):Promise<void> {
  // The original request goes directly to the dedicated read-only DBAgent.
  // MIDAS context and model-generated plans must not rewrite raw SQL.
  try {
   const reply=await this.post('/api/ai-core/execute',{agentId:'DBAgent',message,contextId:this.contextId,
     ...(this.databaseSchema?{database:this.databaseSchema}:{})});
   const answer=coreText(reply);
   this.history.push({role:'assistant',name:'DBAgent',agentId:'DBAgent',content:answer||'The SQL executor returned no readable rows.',time:this.stamp()});
   this.lastRoute='DBAgent · direct read-only SQL (no multi-agent rewriting)';
  }catch(e){this.error=e instanceof Error?e.message:String(e);}
  finally{this.busy=false;this.scroll();}
 }

 midasV7Context:MidasV7Context|null=null; // opted-in UI selection metadata, not MIDAS data evidence
 midasCapabilities:MidasCapabilities|null=null; midasCommand=''; midasResult='';
 includeMidasInQueries=true; midasDataResult=''; autoFillMidasSelection=true;
  get v7DemoEnabled():boolean {return (window as Window & {__AI_CHATBOT_V7_FLAGS__?:{syntheticDemo?:boolean}}).__AI_CHATBOT_V7_FLAGS__?.syntheticDemo===true;}
  get v7NLActionsEnabled():boolean {return (window as Window & {__AI_CHATBOT_V7_FLAGS__?:{nlActions?:boolean}}).__AI_CHATBOT_V7_FLAGS__?.nlActions===true;}
  /** Explicit synthetic test workflow; cannot be mistaken for live MIDAS evidence. */
  async runV7SyntheticEvidence():Promise<void>{
    if(!this.v7DemoEnabled || this.busy)return;
    this.busy=true;
    try {
      const evidence=await this.post('/api/midas/v7/read',{tool:'compare_series',entityIds:[101,102],timeRange:{start:0,end:120}});
      if(evidence?.status!=='ok')throw new Error(String(evidence?.reason||'Synthetic read unavailable'));
      this.history.push({role:'assistant',name:'V7 SYNTHETIC Evidence Gateway',
        content:'TEST ONLY — NOT LIVE MIDAS DATA\nEvidence: '+evidence.evidenceId+'\n'+JSON.stringify(evidence.data,null,2),time:this.stamp()});
      this.scroll();
    }catch(error){this.error='V7 test data unavailable: '+(error instanceof Error?error.message:String(error));}
    finally{this.busy=false;}
  }
  async runV7SyntheticAgentDemo():Promise<void>{
    if(!this.v7DemoEnabled || this.busy)return;
    this.busy=true;this.error='';
    const message='Compare the two SYNTHETIC test entity series. State their changes, evidence reference, limitations and TEST ONLY designation.';
    this.history.push({role:'user',content:message,time:this.stamp()});
    try {
      const result=await this.post('/api/orchestration/execute',{message,contextId:this.contextId,context:this.context,
        midasV7Read:{tool:'compare_series',entityIds:[101,102],timeRange:{start:0,end:120}}});
      const provenance=String(result?.midasV7Evidence?.evidenceId||'No server-attested evidence identifier');
      this.history.push({role:'assistant',name:'V7 Multi-agent SYNTHETIC Demonstration',
        content:'TEST ONLY — NOT LIVE MIDAS DATA\nEvidence: '+provenance+'\n'+String(result?.answer||'No agent answer.'),time:this.stamp()});
      this.scroll();
    }catch(error){this.error='V7 synthetic multi-agent demo could not run: '+(error instanceof Error?error.message:String(error));}
    finally{this.busy=false;}
  }
 private lastMenuRoute=''; private lastSuggestedMidasCommand=''; private lastSelectedSnapshot='';
 private lastSelectionDraft='';
 private pendingReadTools=new Map<string,{resolve:(value:any)=>void; timer:ReturnType<typeof setTimeout>}>();
 fillChatPrompt(text:string):void { this.prompt=text; this.inspectorOpen=false; }
 private requestMidasTool(tool:'capabilities'|'dashboard_snapshot'|'compare_combat_power'|'report_data'):Promise<any> {
  if(!this.midasConnected||!this.midasShared||!this.midasToken) return Promise.resolve({status:'unavailable',reason:'Enable dashboard context sharing first.'});
  return new Promise(resolve=>{
   const id=crypto.randomUUID();
   const timer=setTimeout(()=>{this.pendingReadTools.delete(id);resolve({status:'unavailable',reason:'MIDAS did not answer the tool request.'});},7000);
   this.pendingReadTools.set(id,{resolve,timer});
   this.postMidas('TOOL_REQUEST',{token:this.midasToken,id,tool});
  });
 }
 async downloadMidasReport():Promise<void> {
  const result=await this.requestMidasTool('report_data');
  if(result?.status!=='ok') {this.midasDataResult=String(result?.reason||'No authorized data available.');return;}
  const report=['# MIDAS Evidence Snapshot',`Generated: ${result.generatedAt}`,`Dashboard: ${result.dashboard}`,
   'Source: authorized MIDAS store (not independently verified by AI)', '', '```json',JSON.stringify(result.data,null,2),'```',
   'No unsupported claims, forecasts or operational recommendations have been added.'].join('\n');
  const blob=new Blob([report],{type:'text/markdown;charset=utf-8'});
  const url=URL.createObjectURL(blob); const a=document.createElement('a');a.href=url;a.download='midas-evidence-report.md';a.click();
  setTimeout(()=>URL.revokeObjectURL(url),1000);this.midasDataResult='MIDAS evidence report exported.';
 }
 private enrichedAgentQuery(message:string, evidence:any):string {
  // The conversational user/task context is part of the actual search/query string
  // as well as the structured context object. MIDAS data is added only after opt-in.
  const lines=['USER QUESTION: '+message];
  if(this.userContext.trim()) lines.push('USER CONTEXT: '+this.userContext.slice(0,1200));
  if(this.taskContext.trim()) lines.push('TASK CONTEXT: '+this.taskContext.slice(0,1200));
  if(this.midasShared && this.midasContext && this.includeMidasInQueries){
   const info={dashboard:this.midasContext.route,activeDashboard:this.midasContext.activeDashboard,
    selectedMenu:this.midasContext.selectedMenuLabel,selectedValues:this.midasContext.selectedValues,
    dataSourceConnected:this.midasContext.dataSourceConnected,
    timeFormat:this.midasContext.selectedTimeFormat,
    selectedEntityIds:this.midasContext.cpSelectedEntityIds?.slice(0,25),
    timeframe:this.midasContext.cpTimeframe,grouping:this.midasContext.cpGrouping};
   lines.push('MIDAS USER-SELECTED UI CONTEXT (unverified observations): '+JSON.stringify(info));
   if(this.midasV7Context) lines.push('V7 VERSIONED MIDAS SELECTIONS (not data evidence or authorization): '+JSON.stringify(this.midasV7Context).slice(0,12000));
   if(evidence?.status==='ok') lines.push('MIDAS TOOL EVIDENCE (read-only): '+JSON.stringify(evidence.data).slice(0,10000));
   lines.push('Use MIDAS evidence only when available; do not invent missing observations. UI actions require host approval.');
  }
  return lines.length===1 ? message : lines.join('\n');
 }

 /** The user sees exactly which MIDAS values will be attached to the next query. */
 get midasSelectionPreview():string {
  const context=this.midasContext;
  if(!this.midasShared || !context) return '';
  const parts:string[]=[];
  const v=context.selectedValues;
  if(context.selectedMenuLabel) parts.push('Dashboard: '+context.selectedMenuLabel);
  if(v?.timeFormat) parts.push('Time format: '+v.timeFormat);
  if(v?.timeframe) parts.push('Range: '+v.timeframe.start+'–'+v.timeframe.end);
  if(v?.grouping && context.dataSourceConnected) parts.push('Grouping: '+v.grouping);
  if(v?.capture) parts.push('Capture: '+v.capture.name+' (#'+v.capture.id+')');
  if(v?.entities?.length) parts.push('Entities: '+v.entities.slice(0,8).map(e=>e.name+' (#'+e.id+')').join(', '));
  if(v?.selectedEntityIds?.length) parts.push('Entity IDs: '+v.selectedEntityIds.slice(0,8).join(', '));
  if(v?.controlMeasures?.length) parts.push('Measures: '+v.controlMeasures.slice(0,8).map(e=>e.name+' (#'+e.id+')').join(', '));
  if(!context.dataSourceConnected) parts.push('No MIDAS data source connected');
  return parts.join(' · ').slice(0,950);
 }
 private selectionPromptText():string {
  const v=this.midasContext?.selectedValues;
  if(!v) return '';
  const chosen=[] as string[];
  if(v.entities?.length) chosen.push('entities '+v.entities.slice(0,8).map(e=>e.name+' (ID '+e.id+')').join(', '));
  if(v.selectedEntityIds?.length) chosen.push('entity IDs '+v.selectedEntityIds.slice(0,8).join(', '));
  if(v.controlMeasures?.length) chosen.push('control measures '+v.controlMeasures.slice(0,8).map(e=>e.name).join(', '));
  if(v.capture) chosen.push('capture '+v.capture.name);
  if(v.timeFormat) chosen.push('time format '+v.timeFormat);
  if(v.timeframe) chosen.push('time range '+v.timeframe.start+' to '+v.timeframe.end);
  if(!chosen.length) return '';
  const dashboard=this.midasContext?.selectedMenuLabel||'current dashboard';
  const missingData=this.midasContext?.dataSourceConnected ? '' : ' MIDAS reports no connected data source; do not infer measured values.';
  return (`Analyze the current MIDAS ${dashboard} selection (${chosen.join('; ')}). Use only authorized available evidence; explain any missing data.`+missingData).slice(0,950);
 }
 insertMidasSelectionInPrompt():void {
  const suggested=this.selectionPromptText();
  if(!suggested) return;
  if(this.prompt.trim() && this.prompt!==this.lastSelectionDraft) return; // preserve user's draft
  this.prompt=suggested; this.lastSelectionDraft=suggested;
 }
 get hasMidasSelections():boolean { return !!this.selectionPromptText(); }
 private syncMidasDrafts():void {
  const context=this.midasContext;
  if(!context) return;
  const menu=context.selectedMenuCommand || '';
  const newRoute=context.route || '';
  // A navigation suggestion never submits or executes a MIDAS action.
  // Do not overwrite any manually edited control request.
  if(menu && newRoute!==this.lastMenuRoute && (!this.midasCommand.trim() || this.midasCommand===this.lastSuggestedMidasCommand)) {
   this.midasCommand=menu; this.lastSuggestedMidasCommand=menu;
  }
  this.lastMenuRoute=newRoute;
  const fingerprint=JSON.stringify({route:newRoute,values:context.selectedValues});
  if(fingerprint!==this.lastSelectedSnapshot) {
   this.lastSelectedSnapshot=fingerprint;
   if(this.autoFillMidasSelection && this.includeMidasInQueries) this.insertMidasSelectionInPrompt();
  }
 }
 get midasTimeFormats():string[] { return this.midasContext?.availableTimeFormats || []; }
 get midasEntities():{id:number;name:string}[] { return this.midasContext?.cpEntities || []; }
 fillMidasCommand(command:string):void { this.midasCommand=command; this.midasResult=''; }

 private midasToken:string|null=null; private midasParentOrigin:string|null=null;
 private allowedMidasOrigins():string[]{
  const raw=(window as Window & {__CALIAN_MIDAS_ALLOWED_ORIGINS__?:unknown}).__CALIAN_MIDAS_ALLOWED_ORIGINS__;
  return Array.isArray(raw)?raw.filter((v):v is string=>typeof v==='string'&&/^https?:\/\/[^/]+$/.test(v)):[];
 }
 private midasHost():Window|null {
  // Embedded iframe talks to window.parent; the native browser pop-out talks to its opener.
  return window.parent!==window ? window.parent : window.opener;
 }
 private postMidas(type:string, details:Record<string,unknown>={}):void {
  const host=this.midasHost();
  if(!host)return;
  const allowed=this.allowedMidasOrigins();
  // On first HELLO the opener may not supply document.referrer. Send only to
  // administrator-configured exact MIDAS origins, never to '*'.
  if(!this.midasParentOrigin && type==='HELLO') {
   if(window.parent!==window){
    try { const origin=new URL(document.referrer).origin; if(allowed.includes(origin))host.postMessage({bridge:MIDAS_BRIDGE_ID,type},origin); } catch { /* no trusted referrer */ }
   } else {
    for(const origin of allowed) host.postMessage({bridge:MIDAS_BRIDGE_ID,type},origin);
   }
   return;
  }
  if(!this.midasParentOrigin || !allowed.includes(this.midasParentOrigin))return;
  host.postMessage({bridge:MIDAS_BRIDGE_ID,type,...details},this.midasParentOrigin);
 }
 private onMidasMessage=(event:MessageEvent):void=>{
  if(event.source!==this.midasHost()||!this.allowedMidasOrigins().includes(event.origin))return;
  const data=event.data;
  if(!data||typeof data!=='object'||data.bridge!==MIDAS_BRIDGE_ID||typeof data.type!=='string')return;
  this.zone.run(()=>{
   if(data.type==='INIT'&&typeof data.token==='string'&&/^[a-f0-9-]{36}$/i.test(data.token)){
    this.midasParentOrigin=event.origin; this.midasToken=data.token;
    // INIT is origin-checked and contains the MIDAS host's session token.
    // Acknowledge it explicitly; the host may have reset its connection badge
    // on the iframe load event after our initial HELLO.
    this.midasCapabilities=data.capabilities as MidasCapabilities; this.midasConnected=true;
    this.postMidas('BRIDGE_READY',{token:this.midasToken});
    this.postMidas('CONTEXT_REQUEST',{token:this.midasToken}); return;
   }
   if(!this.midasToken||data.token!==this.midasToken)return;
   if(data.type==='CONTEXT_V2'){
    if(data.sharing!==true){ this.midasV7Context=null;return; }
    const accepted=acceptV7Context(data.context,this.midasV7Context);
    if(accepted && this.midasShared) this.midasV7Context=accepted;
    return;
   }
   if(data.type==='CONTEXT'){
    this.midasShared=data.sharing===true;
    if(!this.midasShared)this.midasV7Context=null;
    this.midasContext=this.midasShared && data.context && typeof data.context==='object' ? data.context as MidasContext : null;
    if(this.midasContext) this.syncMidasDrafts();
   }
   if(data.type==='TOOL_RESULT' && typeof data.id==='string') {
    const pending=this.pendingReadTools.get(data.id);
    if(pending) {clearTimeout(pending.timer);this.pendingReadTools.delete(data.id);pending.resolve(data.result);}
   }
   if(data.type==='ACTION_RESULT'){
    this.midasResult=String(data.message||'MIDAS responded.').slice(0,220);
    this.snack.open(this.midasResult,'Dismiss',{duration:4500});
   }
   if(data.type==='SESSION_EXPORT_REQUEST')this.exportMidasSession(data.id);
   if(data.type==='SESSION_IMPORT')this.importMidasSession(data.id,data.snapshot);

  });
 };
 /** One-time user-initiated in-memory conversation transfer. No storage or API tokens. */
 private exportMidasSession(id:unknown):void {
  if(typeof id!=='string'||!/^[a-f0-9-]{36}$/i.test(id))return;
  if(this.busy||this.voiceActive||this.voiceProcessing||this.activeView==='video'){
   this.postMidas('SESSION_EXPORT_ERROR',{token:this.midasToken,id,
    message:'Finish the current agent response, microphone recording, or video call before moving this chat.'});
   return;
  }
  const snapshot={version:1,contextId:this.contextId,previousAgentId:this.previousAgentId,
   history:this.history.slice(-100).map(t=>({ ...t, content:t.content.slice(0,8000) })),
   userContext:this.userContext.slice(0,6000),taskContext:this.taskContext.slice(0,6000),
   systemInstructions:this.systemInstructions.slice(0,6000),
   selected:this.selected, multiAgentEnabled:this.multiAgentEnabled,
   selectionOnly:this.selectionOnly, inspectorOpen:this.inspectorOpen,
   theme:this.theme,prompt:this.prompt.slice(0,4000),autoFillMidasSelection:this.autoFillMidasSelection};
  if(JSON.stringify(snapshot).length>200000){
   this.postMidas('SESSION_EXPORT_ERROR',{token:this.midasToken,id,message:'Chat history is too large to transfer safely. Export it first.'});return;
  }
  this.postMidas('SESSION_EXPORT_RESPONSE',{token:this.midasToken,id,snapshot});
 }
 private importMidasSession(id:unknown,value:unknown):void {
  if(typeof id!=='string'||!/^[a-f0-9-]{36}$/i.test(id))return;
  if(!value||typeof value!=='object'||Array.isArray(value))return;
  const s=value as Record<string,unknown>;
  if(s['version']!==1 || typeof s['contextId']!=='string' || !/^[a-f0-9-]{36}$/i.test(s['contextId']) || !Array.isArray(s['history']) || s['history'].length>100)return;
  if(this.busy||this.voiceActive||this.voiceProcessing||this.activeView==='video')return;
  if(JSON.stringify(s).length>210000)return;
  const turns:Turn[]=[];
  for(const t of s['history']){
   if(!t || typeof t!=='object' || !['user','assistant'].includes(t.role) || typeof t.content!=='string' || t.content.length>8000)return;
   turns.push({role:t.role,content:t.content,
    ...(typeof t.name==='string'?{name:t.name.slice(0,100)}:{}),
    ...(typeof t.agentId==='string'?{agentId:t.agentId.slice(0,100)}:{}),
    ...(typeof t.time==='string'?{time:t.time.slice(0,50)}:{}),
    ...(typeof t.speechText==='string'?{speechText:t.speechText.slice(0,8000)}:{}),
    ...(typeof t.speechFullText==='string'?{speechFullText:t.speechFullText.slice(0,8000)}:{})});
  }
  this.contextId=s['contextId'];this.history=turns;
  this.previousAgentId=typeof s['previousAgentId']==='string'?s['previousAgentId']:null;
  this.userContext=typeof s['userContext']==='string'?s['userContext'].slice(0,6000):'';
  this.taskContext=typeof s['taskContext']==='string'?s['taskContext'].slice(0,6000):'';
  this.systemInstructions=typeof s['systemInstructions']==='string'?s['systemInstructions'].slice(0,6000):'';
  this.selected=typeof s['selected']==='string'?s['selected']:'auto';
  this.multiAgentEnabled=s['multiAgentEnabled']!==false;
  this.selectionOnly=s['selectionOnly']===true;
  this.inspectorOpen=s['inspectorOpen']!==false;
  this.prompt=typeof s['prompt']==='string'?s['prompt'].slice(0,4000):'';
  this.autoFillMidasSelection=s['autoFillMidasSelection']!==false;
  if(['corporate','royal','modern','classic','midas'].includes(String(s['theme']||'')))this.setTheme(s['theme'] as typeof this.theme);
  this.midasResult='Conversation restored. Continue chatting here.';
  this.postMidas('SESSION_IMPORTED',{token:this.midasToken,id});
 }
 proposeMidasAction(request:MidasRequest):void {
  if(!this.midasConnected||!this.midasToken||!this.midasShared){this.midasResult='Open the MIDAS panel and enable Share dashboard context.';return;}
  this.midasResult='Proposed action sent to MIDAS. Approve or decline it in the host toolbar.';
  this.postMidas('ACTION_REQUEST',{token:this.midasToken,id:crypto.randomUUID(),...request});
 }
 proposeMidasCommand():void {
  if (!this.midasConnected || !this.midasToken) {
   this.midasResult='Waiting for a connection to MIDAS. Refresh MIDAS if this persists.';
   this.postMidas('HELLO');
   return;
  }
  if (!this.midasShared) {
   this.midasResult='Turn on Share dashboard context in the MIDAS toolbar first.';
   return;
  }
  const v7=this.v7NLActionsEnabled ? interpretV7Action(this.midasCommand,this.midasContext) : null;
  const action=v7?.kind==='proposal' ? v7.request : parseMidasCommand(this.midasCommand,this.midasContext,this.midasCapabilities);
  if(!action){this.midasResult=v7?.kind==='needs-input'||v7?.kind==='not-supported'?v7.message:explainMidasCommand(this.midasCommand,this.midasContext);return;}
  this.proposeMidasAction(action);
 }
 isMidasSuggestion(text:string):boolean { return this.midasShared && !!suggestedActionFromAgent(text); }
 proposeMidasSuggestion(text:string):void {
  const action=suggestedActionFromAgent(text);
  if(action)this.proposeMidasAction(action);
 }
 voiceActive=false; voiceProcessing=false; voiceStatus=''; voiceError=''; voiceTechnical=false;
 autoReadAnswers=false; speechPlaying=false; private speechToken=0;
 private voiceSessionId='';
 private voiceStream:MediaStream|null=null;
 private voiceContext:AudioContext|null=null;
 private voiceSource:MediaStreamAudioSourceNode|null=null;
 private voiceProcessor:ScriptProcessorNode|null=null;
 private voiceBuffers:Float32Array[]=[];
 private voiceSamples=0;
 private voiceStarted=0;
 private voiceAutoStop:ReturnType<typeof setTimeout>|null=null;
 ngOnDestroy(){window.removeEventListener('message', this.onMidasMessage);this.releaseMic();this.stopReadback();}

 /** Speak the result summary only after explicit user opt-in or Read click. */
 get canReadAloud():boolean {return typeof window!=='undefined' && 'speechSynthesis' in window && typeof SpeechSynthesisUtterance!=='undefined';}
 stopReadback():void {
  this.speechToken++;
  if(this.canReadAloud)window.speechSynthesis.cancel();
  this.speechPlaying=false;
 }
 readReply(turn:Turn,readMore=false):void {
  if(!this.canReadAloud){this.snack.open('This device does not provide a speech playback voice.','Dismiss',{duration:4000});return;}
  const text=((readMore&&turn.speechFullText)||turn.speechText||speechSummary(undefined,turn.content)).trim();
  if(!text)return;
  this.stopReadback();
  const token=++this.speechToken;
  const utterance=new SpeechSynthesisUtterance(text);
  utterance.lang=navigator.language?.startsWith('en')?navigator.language:'en-US';
  utterance.rate=0.96;
  const voices=window.speechSynthesis.getVoices();
  const voice=voices.find(v=>v.lang===utterance.lang) || voices.find(v=>v.lang.startsWith('en'));
  if(voice)utterance.voice=voice;
  utterance.onend=()=>this.zone.run(()=>{if(token===this.speechToken)this.speechPlaying=false;});
  utterance.onerror=()=>this.zone.run(()=>{if(token===this.speechToken){this.speechPlaying=false;this.snack.open('Speech playback was unavailable. Try the Read button again.','Dismiss',{duration:4500});}});
  try {window.speechSynthesis.speak(utterance);this.speechPlaying=true;}
  catch {this.speechPlaying=false;this.snack.open('Audio playback failed on this device.','Dismiss',{duration:4000});}
 }
 // Record first, transcribe only on stop using an offline Whisper model.
 // The recognized text remains editable: user must explicitly press Send.
 async toggleVoice(){
  if(this.voiceActive){void this.stopVoice();return;}
  if(this.busy||this.voiceProcessing)return;
  const sessionId=crypto.randomUUID();this.voiceSessionId=sessionId;
  this.voiceError='';this.voiceStatus='Checking accurate speech engine…';this.voiceProcessing=true;
  try{
   const statusResponse=await fetch('/api/speech/status');
   if(!statusResponse.ok)throw new Error('Speech engine status unavailable.');
   const status=await statusResponse.json() as {available?:boolean;install?:string;model?:string};
   if(!status.available)throw new Error(status.install||'Run SETUP-ACCURATE-SPEECH-WINDOWS.bat once.');
   this.voiceStatus='Allow microphone access if prompted…';
   if(!navigator.mediaDevices?.getUserMedia)throw new Error('Microphone capture is unavailable. On iPhone/Android, use HTTPS and allow microphone permission in the browser.');
   const stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true,channelCount:1},video:false});
   if(this.voiceSessionId!==sessionId){stream.getTracks().forEach(track=>track.stop());return;}
   this.voiceStream=stream;
   const context=new AudioContext();this.voiceContext=context;
   const source=context.createMediaStreamSource(stream);this.voiceSource=source;
   const processor=context.createScriptProcessor(4096,1,1);this.voiceProcessor=processor;
   this.voiceBuffers=[];this.voiceSamples=0;
   processor.onaudioprocess=event=>{
    if(this.voiceSessionId!==sessionId||!this.voiceActive)return;
    const samples=event.inputBuffer.getChannelData(0);
    this.voiceBuffers.push(new Float32Array(samples));this.voiceSamples+=samples.length;
   };
   source.connect(processor);processor.connect(context.destination);
   await context.resume();
   this.voiceActive=true;this.voiceStarted=Date.now();
   this.voiceStatus=`Recording… Speak naturally, then press Stop (maximum 45 seconds).`;
   this.voiceAutoStop=setTimeout(()=>{if(this.voiceSessionId===sessionId&&this.voiceActive)void this.stopVoice();},45000);
  }catch(e){
   if(this.voiceSessionId===sessionId){this.voiceError=e instanceof Error?e.message:String(e);this.voiceStatus='';}
   this.releaseMic();
  }finally{this.voiceProcessing=false;}
 }
 private releaseMic(){
  if(this.voiceAutoStop){clearTimeout(this.voiceAutoStop);this.voiceAutoStop=null;}
  if(this.voiceProcessor){this.voiceProcessor.onaudioprocess=null;this.voiceProcessor.disconnect();this.voiceProcessor=null;}
  this.voiceSource?.disconnect();this.voiceSource=null;
  this.voiceStream?.getTracks().forEach(track=>track.stop());this.voiceStream=null;
  const context=this.voiceContext;this.voiceContext=null;
  if(context)void context.close().catch(()=>{});
  this.voiceActive=false;
 }
 async stopVoice(){
  if(!this.voiceActive)return;
  const sessionId=this.voiceSessionId;
  const buffers=this.voiceBuffers;const sampleCount=this.voiceSamples;
  const sampleRate=this.voiceContext?.sampleRate||48000;
  this.releaseMic();
  this.voiceBuffers=[];this.voiceSamples=0;
  if(Date.now()-this.voiceStarted<350||sampleCount<sampleRate/4){this.voiceStatus='Recording was too short. Try again.';return;}
  this.voiceProcessing=true;this.voiceStatus='Transcribing locally with Whisper…';this.voiceError='';
  try{
   const wav=this.encodeVoiceWav(buffers,sampleCount,sampleRate);
   const response=await fetch('/api/speech/transcribe',{method:'POST',headers:{'Content-Type':'audio/wav','X-Calian-Speech-Mode':this.voiceTechnical?'technical':'natural'},body:wav});
   const result=await response.json() as {transcript?:string;error?:string;model?:string};
   if(!response.ok)throw new Error(result.error||`Transcription HTTP ${response.status}`);
   if(this.voiceSessionId!==sessionId)return;
   const text=result.transcript?.trim();
   if(!text){this.voiceStatus='Nothing intelligible was detected. Try again.';return;}
   this.prompt=this.prompt.trim()?`${this.prompt.trim()} ${text}`:text;
   this.voiceStatus=`Whisper (${result.model||'offline'}) transcribed your message. Review it, then press Send.`;
  }catch(e){if(this.voiceSessionId===sessionId)this.voiceError=e instanceof Error?e.message:String(e);}
  finally{this.voiceProcessing=false;}
 }
 private encodeVoiceWav(parts:Float32Array[],length:number,sourceRate:number):ArrayBuffer{
  const source=new Float32Array(length);let offset=0;
  for(const part of parts){source.set(part,offset);offset+=part.length;}
  const targetRate=16000;
  const count=Math.floor(source.length*targetRate/sourceRate);
  const bytes=new ArrayBuffer(44+count*2);
  const view=new DataView(bytes);const ascii=(at:number,text:string)=>{for(let i=0;i<text.length;i++)view.setUint8(at+i,text.charCodeAt(i));};
  ascii(0,'RIFF');view.setUint32(4,36+count*2,true);ascii(8,'WAVE');ascii(12,'fmt ');
  view.setUint32(16,16,true);view.setUint16(20,1,true);view.setUint16(22,1,true);
  view.setUint32(24,targetRate,true);view.setUint32(28,targetRate*2,true);view.setUint16(32,2,true);view.setUint16(34,16,true);
  ascii(36,'data');view.setUint32(40,count*2,true);
  const ratio=sourceRate/targetRate;
  for(let i=0;i<count;i++){
   // Weighted averaging over input samples avoids aliasing on 48kHz microphones.
   const a=i*ratio,b=Math.min(source.length,(i+1)*ratio);
   const first=Math.floor(a),last=Math.ceil(b);let sum=0,weight=0;
   for(let j=first;j<last;j++){
    const w=Math.max(0,Math.min(j+1,b)-Math.max(j,a));
    if(w>0){sum+=source[j]*w;weight+=w;}
   }
   const value=Math.max(-1,Math.min(1,weight?sum/weight:0));
   view.setInt16(44+i*2,value<0?Math.round(value*32768):Math.round(value*32767),true);
  }
  return bytes;
 }

 ngOnInit(){
  if(this.midasHost()){window.addEventListener('message', this.onMidasMessage);this.postMidas('HELLO');}
  const saved=localStorage.getItem('calian-ui-theme');
  if(saved && ['corporate','royal','modern','classic','midas'].includes(saved)) this.setTheme(saved as typeof this.theme);
  if(window.innerWidth<=1000) this.inspectorOpen=false;
  // Never cache API requests or interfere with Electron's local desktop installation.
  if(location.protocol==='https:' && 'serviceWorker' in navigator)
   window.addEventListener('load',()=>{void navigator.serviceWorker.register('/sw.js').catch(()=>{});},{once:true});
  void this.refresh();
  void this.loadDatabaseOptions();
 }
 setTheme(value:'corporate'|'royal'|'modern'|'classic'|'midas'){
  this.theme=value;
  this.dark=value!=='classic';
  localStorage.setItem('calian-ui-theme',value);
 }
 toggleBrightness(){this.setTheme(this.dark?'classic':'corporate');}
 ngAfterViewChecked(){ /* Scroll only after new turns or streaming updates, not on every change detection. */ }
 get pythonCount(){return this.agents.filter(a=>a.type==='north').length;}
 get coreCount(){return this.agents.filter(a=>a.type==='aicore').length;}
 get selectedAgent(){return this.agents.find(a=>`${a.type}:${a.id}`===this.selected);}
 get filteredAgents(){return this.agents.filter(a=>(a.name+' '+a.id+' '+a.type).toLowerCase().includes(this.search.toLowerCase()));}
 get context():SharedContext{
  // The MIDAS snapshot is opt-in, bounded, and does not convey credentials or raw DB records.
  const midas = this.midasShared && this.midasContext && this.includeMidasInQueries ?
    `\n[MIDAS READ-ONLY UI STATE]\n${JSON.stringify(this.midasContext)}\n` +
    'For a requested MIDAS UI change, you may propose one fenced ```midas-action JSON ``` with action/params. ' +
    'Actions: navigate {dashboard:"cp"|"summary"|...}, time_format {name}, cp_time_range {start,end}, cp_select_entity {id,selected}. ' +
    'Do not claim it ran: the user must explicitly propose it and approve the action in MIDAS.\n' : '';
  return {userContext:this.userContext,taskContext:this.taskContext + midas,systemInstructions:this.systemInstructions,conversationHistory:this.history.slice(-12).map(({role,content,agentId})=>({role,content,...(agentId?{agentId}:{})})),agentResults:[]};
 }
 private async get(path:string){return this.socket.request(path);}
 private async post(path:string,body:unknown){return this.socket.request(path,'POST',body);}
 private scroll(){setTimeout(()=>this.messagesEnd?.nativeElement.scrollIntoView({behavior:'smooth',block:'end'}),30);}
 private stamp(){return new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});}
 async refresh(){this.discovering=true;this.error='';const [py,core]=await Promise.allSettled([this.get('/api/agents'),this.get('/api/ai-core/agents')]);this.pythonOnline=py.status==='fulfilled';this.agents=[...(py.status==='fulfilled'?normalizePythonAgents(py.value):[]),...(core.status==='fulfilled'?normalizeCoreAgents(core.value):[])];if(py.status==='rejected')this.error=`Python service: ${String(py.reason)}`;if(core.status==='rejected')this.notice=`AI Core registry unavailable: ${String(core.reason)}`;this.discovering=false;}
 selectAgent(value:string){this.selected=value;this.mobileOpen=false;this.activeView='chat';}
 reset(){this.stopReadback();this.contextId=crypto.randomUUID();this.previousAgentId=null;this.history=[];this.partial='';this.error='';this.lastRoute='No routing decision yet';this.lastTrace=[];this.snack.open('New conversation created','Dismiss',{duration:2500});}
 exportTranscript(){const blob=new Blob([JSON.stringify({exportedAt:new Date().toISOString(),contextId:this.contextId,userContext:this.userContext,taskContext:this.taskContext,systemInstructions:this.systemInstructions,history:this.history},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`ai-chatbot-session-${this.contextId.slice(0,8)}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
 copyId(){void navigator.clipboard.writeText(this.contextId);this.snack.open('Session ID copied','Dismiss',{duration:2000});}
 onKeydown(event:KeyboardEvent){if(event.key==='Enter'&&!event.shiftKey&&!matchMedia('(pointer:coarse)').matches){event.preventDefault();void this.send();}}
 async send(){
  const message=this.prompt.trim();
  if(!message||this.busy||this.voiceActive||this.voiceProcessing)return;
  // V7 DBAgent routing: never augment SQL with unrelated MIDAS state or
  // pass it through multi-agent task planners. Keep the original user query.
  const dbIntent=this.isDatabaseQuery(message);
  if(dbIntent && !this.selectionOnly && (this.selected==='auto' || /db[\s_-]*agent/i.test(this.selectedAgent?.id||''))){
   this.stopReadback();this.busy=true;this.prompt='';this.error='';this.partial='';
   this.history.push({role:'user',content:message,time:this.stamp()});
   await this.sendDatabaseQuery(message);return;
  }
  // Explicit user chat commands may suggest an allowlisted MIDAS UI change.
  // The host app must still validate and approve it; agents never get direct UI access.
  if(this.midasConnected && this.midasShared){
   const v7=this.v7NLActionsEnabled ? interpretV7Action(message,this.midasContext) : null;
   const action=v7?.kind==='proposal' ? v7.request : parseMidasCommand(message,this.midasContext,this.midasCapabilities);
   if(action){
    this.prompt='';
    this.history.push({role:'user',content:message,time:this.stamp()});
    this.history.push({role:'assistant',name:'MIDAS Action Bridge',content:'I proposed this MIDAS interface action. Review and approve or decline it in the MIDAS panel toolbar.',time:this.stamp()});
    this.proposeMidasAction(action);
    this.scroll();
    return;
   }
  }
  // Recognized MIDAS UI intents with missing parameters need guidance, not an agent guess.
  if(this.midasConnected && this.midasShared && /^(?:set|change)(?: the)?(?: combat power)? time (?:range|frame)\b|^(?:set|change)(?: the)? time format\b|^(?:select|deselect) (?:unit|entity)\b/i.test(message)) {
   this.prompt='';
   this.history.push({role:'user',content:message,time:this.stamp()});
   this.history.push({role:'assistant',name:'MIDAS Action Bridge',content:explainMidasCommand(message,this.midasContext),time:this.stamp()});
   this.scroll();return;
  }
  this.stopReadback();this.busy=true;this.prompt='';this.error='';this.partial='';
  const context=this.context;this.history.push({role:'user',content:message,time:this.stamp()});this.scroll();let agent=this.selectedAgent;
  let evidence:any=null;
  const asksForEvidence=/\b(analy[sz]e|compar(?:e|ison)|report|summari[sz]e|trend|statistics|chart|dashboard data|metrics|changes)\b/i.test(message);
  if(asksForEvidence && this.midasShared && this.includeMidasInQueries){
   const tool=/\bcompar(?:e|ison)\b/i.test(message)?'compare_combat_power':/\breport\b/i.test(message)?'report_data':'dashboard_snapshot';
   evidence=await this.requestMidasTool(tool);
   if(evidence?.status!=='ok'){
    this.history.push({role:'assistant',name:'MIDAS Data Gateway',content:String(evidence?.reason||'MIDAS has no available authorized data.'),time:this.stamp()});
    this.busy=false;this.scroll();return;
   }
  }
  const agentQuery=this.enrichedAgentQuery(message,evidence);
 try{
 // CIMAO intelligent chain: default auto mode uses a single trusted server-side
 // orchestrator; manual agent calls and the selection-only diagnostics remain intact.
 if(this.selected==='auto' && this.multiAgentEnabled && !this.selectionOnly){
  const result=await this.post('/api/orchestration/execute',{message:agentQuery,contextId:this.contextId,context,
   ...(this.databaseSchema?{database:this.databaseSchema}:{})});
  const trace=Array.isArray(result.trace)?result.trace.filter((item:any)=>item&&typeof item.agentName==='string').map((item:any)=>({agentId:String(item.agentId||''),agentName:item.agentName,status:String(item.status||''),reason:String(item.reason||'')})):[];
  this.lastTrace=trace;
  this.lastRoute=`Intelligent agent chain · ${result.planningMethod||'automatic'} · ${trace.length} agent step(s) · ${result.stopReason||'completed'}`;
  this.previousAgentId=trace.length?trace[trace.length-1].agentId:null;
  const answer=String(result.answer||'No agent returned an answer.');
  const turn:Turn={role:'assistant',content:answer,agentId:'cimao',name:'AI Chatbot Multi-Agent Orchestrator',time:this.stamp(),agentTrace:trace,agentComplete:result.complete===true,agentStopReason:String(result.stopReason||''),speechText:speechSummary(undefined,answer),speechFullText:speechSummary(undefined,answer,10)};
  this.history.push(turn);
  if(this.autoReadAnswers)this.readReply(turn);
  return;
 }
 if(this.selected==='auto'){
  if(!this.agents.length)throw new Error('No discovered agents available. Refresh discovery.');
  const routed=await this.post('/api/router/select',{message:agentQuery,contextId:this.contextId,...(this.previousAgentId?{previousAgentId:this.previousAgentId}:{}),context,agents:this.agents.map(a=>({id:a.id,name:a.name,type:a.type,description:String(a.raw?.['description']||''),commands:a.commands||[]}))});
  if(!routed.agent)throw new Error(`No matching agent: ${routed.reason||'router returned no agent'}`);
  agent=this.agents.find(a=>a.id===routed.agent.id&&a.type===routed.agent.type);
  if(!agent)throw new Error('Router selected an agent not present in the discovered registry');
  this.lastRoute=`${agent.name} · Router: ${routed.method||'unknown'} · ${routed.reason||'Automatic selection'}${typeof routed.confidence==='number'?` · ${(routed.confidence*100).toFixed(0)}% confidence`:''}`;
  if(this.selectionOnly){const confidence=typeof routed.confidence==='number'?` (${(routed.confidence*100).toFixed(0)}% confidence)`:'';this.previousAgentId=agent.id;this.history.push({role:'assistant',content:`Auto-selected: ${agent.name}${confidence}\nSource: ${agent.type==='aicore'?'AI Core / Paradigm':'Python / A2A'}\nRouter: ${routed.method||'unknown'}\nReason: ${routed.reason||'Metadata match'}\nSelection only — agent execution was not attempted.`,agentId:agent.id,name:'Auto-selection result',time:this.stamp()});this.snack.open(`Routing successful: ${agent.name}`,'Dismiss',{duration:3500});return;}
 }else this.lastRoute=`Manual selection · ${agent?.name||'unknown'}`;
 if(!agent)throw new Error('Select an agent or refresh discovery');
 let answer='';
 let responsePayload:unknown;
 if(agent.id==='local-ollama' && agent.type==='north'){const response=await this.post('/api/ollama/chat',{message:agentQuery,contextId:this.contextId,context});answer=String(response.text||'');}
 else if(agent.type==='aicore'){const isDB=/^db[\s_-]*agent$/i.test(agent.id);responsePayload=await this.post('/api/ai-core/execute',{agentId:agent.id,message:isDB?message:agentQuery,contextId:this.contextId,context:isDB?{}:context,...(isDB&&this.databaseSchema?{database:this.databaseSchema}:{})});answer=coreText(responsePayload);}
 else {answer=await this.socket.a2a(a2aRequest(agent.id,agentQuery,this.contextId,context),text=>{this.partial=text;this.scroll();});}
 this.previousAgentId=agent.id;
 const completedTurn:Turn={role:'assistant',content:answer||'Agent returned no text response.',agentId:agent.id,name:agent.name,time:this.stamp(),speechText:speechSummary(responsePayload,answer),speechFullText:speechSummary(responsePayload,answer,10)};
 this.history.push(completedTurn);this.partial='';
 if(this.autoReadAnswers)this.readReply(completedTurn);
 }catch(e){this.error=e instanceof Error?e.message:String(e);this.partial='';}finally{this.busy=false;this.scroll();}}
}
