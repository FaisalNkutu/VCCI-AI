// Mobile-only shell caching. All API calls remain network-only; CALIAN needs the live backend.
const CACHE = 'calian-v8-mobile-shell-1';
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(['/','/index.html','/manifest.webmanifest','/icon-192.png','/icon-512.png'])).then(()=>self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key=>key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const req=event.request;
  const url=new URL(req.url);
  if(req.method!=='GET'||url.origin!==self.location.origin||url.pathname.startsWith('/api/')||url.pathname.startsWith('/ws'))return;
  if(req.mode==='navigate') {
    event.respondWith(fetch(req).then(response=>{if(response.ok){const copy=response.clone();void caches.open(CACHE).then(cache=>cache.put('/index.html',copy));}return response;}).catch(()=>caches.match('/index.html')));
    return;
  }
  // Assets contain build hashes. Cache only when successfully fetched; never cache failures.
  event.respondWith(caches.match(req).then(cached=>cached||fetch(req).then(response=>{if(response.ok){const copy=response.clone();void caches.open(CACHE).then(cache=>cache.put(req,copy));}return response;})));
});
