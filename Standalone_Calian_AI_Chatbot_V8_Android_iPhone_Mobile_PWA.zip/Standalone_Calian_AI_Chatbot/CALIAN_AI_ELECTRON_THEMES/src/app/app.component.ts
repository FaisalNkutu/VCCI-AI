import { Component, OnInit, ViewChild, ElementRef, AfterViewChecked, NgZone, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SocketService } from './socket.service';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatTabsModule } from '@angular/material/tabs';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { Agent, Turn, SharedContext, normalizePythonAgents, normalizeCoreAgents, a2aRequest, coreText } from './protocol';
@Component({selector:'app-root',standalone:true,imports:[CommonModule,FormsModule,MatToolbarModule,MatButtonModule,MatIconModule,MatCardModule,MatFormFieldModule,MatInputModule,MatListModule,MatTabsModule,MatCheckboxModule,MatProgressSpinnerModule,MatTooltipModule,MatSidenavModule,MatSnackBarModule],templateUrl:'./app.component.html',styleUrl:'./app.component.scss'})
export class AppComponent implements OnInit,AfterViewChecked,OnDestroy {
 @ViewChild('messagesEnd') messagesEnd?:ElementRef<HTMLElement>;
 agents:Agent[]=[]; selected='auto'; search=''; history:Turn[]=[]; prompt=''; userContext=''; taskContext=''; systemInstructions=''; contextId=crypto.randomUUID(); previousAgentId:string|null=null; busy=false; discovering=false; error=''; notice=''; partial=''; inspectorOpen=true; mobileOpen=false; dark=true; theme:'corporate'|'royal'|'modern'|'classic'='corporate'; lastRoute='No routing decision yet'; pythonOnline=false; selectionOnly=false; inspectorTab=0;
 constructor(private socket:SocketService,private snack:MatSnackBar,private zone:NgZone){}
 voiceActive=false; voiceProcessing=false; voiceStatus=''; voiceError='';
 private voiceSessionId='';
 private voiceStream:MediaStream|null=null;
 private voiceContext:AudioContext|null=null;
 private voiceSource:MediaStreamAudioSourceNode|null=null;
 private voiceProcessor:ScriptProcessorNode|null=null;
 private voiceBuffers:Float32Array[]=[];
 private voiceSamples=0;
 private voiceStarted=0;
 private voiceAutoStop:ReturnType<typeof setTimeout>|null=null;
 ngOnDestroy(){this.releaseMic();}

 // Record first, transcribe only on stop using an offline Whisper model.
 // The recognized text remains editable: user must explicitly press Send.
 async toggleVoice(){
  if(this.voiceActive){void this.stopVoice();return;}
  if(this.busy||this.voiceProcessing)return;
  const sessionId=crypto.randomUUID();this.voiceSessionId=sessionId;
  this.voiceError='';this.voiceStatus='Checking accurate speech engine…';this.voiceProcessing=true;
  try{
   const statusResponse=await fetch('/api/speech/status');
   if(!statusResponse.ok)throw new Error('Speech engine status unavailable.');
   const status=await statusResponse.json() as {available?:boolean;install?:string;model?:string};
   if(!status.available)throw new Error(status.install||'Run SETUP-ACCURATE-SPEECH-WINDOWS.bat once.');
   this.voiceStatus='Allow microphone access if prompted…';
   if(!navigator.mediaDevices?.getUserMedia)throw new Error('Microphone capture is unavailable. On iPhone/Android, use HTTPS and allow microphone permission in the browser.');
   const stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true,channelCount:1},video:false});
   if(this.voiceSessionId!==sessionId){stream.getTracks().forEach(track=>track.stop());return;}
   this.voiceStream=stream;
   const context=new AudioContext();this.voiceContext=context;
   const source=context.createMediaStreamSource(stream);this.voiceSource=source;
   const processor=context.createScriptProcessor(4096,1,1);this.voiceProcessor=processor;
   this.voiceBuffers=[];this.voiceSamples=0;
   processor.onaudioprocess=event=>{
    if(this.voiceSessionId!==sessionId||!this.voiceActive)return;
    const samples=event.inputBuffer.getChannelData(0);
    this.voiceBuffers.push(new Float32Array(samples));this.voiceSamples+=samples.length;
   };
   source.connect(processor);processor.connect(context.destination);
   await context.resume();
   this.voiceActive=true;this.voiceStarted=Date.now();
   this.voiceStatus=`Recording… Speak naturally, then press Stop (maximum 45 seconds).`;
   this.voiceAutoStop=setTimeout(()=>{if(this.voiceSessionId===sessionId&&this.voiceActive)void this.stopVoice();},45000);
  }catch(e){
   if(this.voiceSessionId===sessionId){this.voiceError=e instanceof Error?e.message:String(e);this.voiceStatus='';}
   this.releaseMic();
  }finally{this.voiceProcessing=false;}
 }
 private releaseMic(){
  if(this.voiceAutoStop){clearTimeout(this.voiceAutoStop);this.voiceAutoStop=null;}
  if(this.voiceProcessor){this.voiceProcessor.onaudioprocess=null;this.voiceProcessor.disconnect();this.voiceProcessor=null;}
  this.voiceSource?.disconnect();this.voiceSource=null;
  this.voiceStream?.getTracks().forEach(track=>track.stop());this.voiceStream=null;
  const context=this.voiceContext;this.voiceContext=null;
  if(context)void context.close().catch(()=>{});
  this.voiceActive=false;
 }
 async stopVoice(){
  if(!this.voiceActive)return;
  const sessionId=this.voiceSessionId;
  const buffers=this.voiceBuffers;const sampleCount=this.voiceSamples;
  const sampleRate=this.voiceContext?.sampleRate||48000;
  this.releaseMic();
  this.voiceBuffers=[];this.voiceSamples=0;
  if(Date.now()-this.voiceStarted<350||sampleCount<sampleRate/4){this.voiceStatus='Recording was too short. Try again.';return;}
  this.voiceProcessing=true;this.voiceStatus='Transcribing locally with Whisper…';this.voiceError='';
  try{
   const wav=this.encodeVoiceWav(buffers,sampleCount,sampleRate);
   const response=await fetch('/api/speech/transcribe',{method:'POST',headers:{'Content-Type':'audio/wav'},body:wav});
   const result=await response.json() as {transcript?:string;error?:string;model?:string};
   if(!response.ok)throw new Error(result.error||`Transcription HTTP ${response.status}`);
   if(this.voiceSessionId!==sessionId)return;
   const text=result.transcript?.trim();
   if(!text){this.voiceStatus='Nothing intelligible was detected. Try again.';return;}
   this.prompt=this.prompt.trim()?`${this.prompt.trim()} ${text}`:text;
   this.voiceStatus=`Whisper (${result.model||'offline'}) transcribed your message. Review it, then press Send.`;
  }catch(e){if(this.voiceSessionId===sessionId)this.voiceError=e instanceof Error?e.message:String(e);}
  finally{this.voiceProcessing=false;}
 }
 private encodeVoiceWav(parts:Float32Array[],length:number,sourceRate:number):ArrayBuffer{
  const source=new Float32Array(length);let offset=0;
  for(const part of parts){source.set(part,offset);offset+=part.length;}
  const targetRate=16000;
  const count=Math.floor(source.length*targetRate/sourceRate);
  const bytes=new ArrayBuffer(44+count*2);
  const view=new DataView(bytes);const ascii=(at:number,text:string)=>{for(let i=0;i<text.length;i++)view.setUint8(at+i,text.charCodeAt(i));};
  ascii(0,'RIFF');view.setUint32(4,36+count*2,true);ascii(8,'WAVE');ascii(12,'fmt ');
  view.setUint32(16,16,true);view.setUint16(20,1,true);view.setUint16(22,1,true);
  view.setUint32(24,targetRate,true);view.setUint32(28,targetRate*2,true);view.setUint16(32,2,true);view.setUint16(34,16,true);
  ascii(36,'data');view.setUint32(40,count*2,true);
  const ratio=sourceRate/targetRate;
  for(let i=0;i<count;i++){
   // Weighted averaging over input samples avoids aliasing on 48kHz microphones.
   const a=i*ratio,b=Math.min(source.length,(i+1)*ratio);
   const first=Math.floor(a),last=Math.ceil(b);let sum=0,weight=0;
   for(let j=first;j<last;j++){
    const w=Math.max(0,Math.min(j+1,b)-Math.max(j,a));
    if(w>0){sum+=source[j]*w;weight+=w;}
   }
   const value=Math.max(-1,Math.min(1,weight?sum/weight:0));
   view.setInt16(44+i*2,value<0?Math.round(value*32768):Math.round(value*32767),true);
  }
  return bytes;
 }

 ngOnInit(){
  const saved=localStorage.getItem('calian-ui-theme');
  if(saved && ['corporate','royal','modern','classic'].includes(saved)) this.setTheme(saved as typeof this.theme);
  if(window.innerWidth<=1000) this.inspectorOpen=false;
  // Never cache API requests or interfere with Electron's local desktop installation.
  if(location.protocol==='https:' && 'serviceWorker' in navigator)
   window.addEventListener('load',()=>{void navigator.serviceWorker.register('/sw.js').catch(()=>{});},{once:true});
  void this.refresh();
 }
 setTheme(value:'corporate'|'royal'|'modern'|'classic'){
  this.theme=value;
  this.dark=value!=='classic';
  localStorage.setItem('calian-ui-theme',value);
 }
 toggleBrightness(){this.setTheme(this.dark?'classic':'corporate');}
 ngAfterViewChecked(){ /* Scroll only after new turns or streaming updates, not on every change detection. */ }
 get pythonCount(){return this.agents.filter(a=>a.type==='north').length;}
 get coreCount(){return this.agents.filter(a=>a.type==='aicore').length;}
 get selectedAgent(){return this.agents.find(a=>`${a.type}:${a.id}`===this.selected);}
 get filteredAgents(){return this.agents.filter(a=>(a.name+' '+a.id+' '+a.type).toLowerCase().includes(this.search.toLowerCase()));}
 get context():SharedContext{return {userContext:this.userContext,taskContext:this.taskContext,systemInstructions:this.systemInstructions,conversationHistory:this.history.slice(-12).map(({role,content,agentId})=>({role,content,...(agentId?{agentId}:{})})),agentResults:[]};}
 private async get(path:string){return this.socket.request(path);}
 private async post(path:string,body:unknown){return this.socket.request(path,'POST',body);}
 private scroll(){setTimeout(()=>this.messagesEnd?.nativeElement.scrollIntoView({behavior:'smooth',block:'end'}),30);}
 private stamp(){return new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});}
 async refresh(){this.discovering=true;this.error='';const [py,core]=await Promise.allSettled([this.get('/api/agents'),this.get('/api/ai-core/agents')]);this.pythonOnline=py.status==='fulfilled';this.agents=[...(py.status==='fulfilled'?normalizePythonAgents(py.value):[]),...(core.status==='fulfilled'?normalizeCoreAgents(core.value):[])];if(py.status==='rejected')this.error=`Python service: ${String(py.reason)}`;if(core.status==='rejected')this.notice=`AI Core registry unavailable: ${String(core.reason)}`;this.discovering=false;}
 selectAgent(value:string){this.selected=value;this.mobileOpen=false;}
 reset(){this.contextId=crypto.randomUUID();this.previousAgentId=null;this.history=[];this.partial='';this.error='';this.lastRoute='No routing decision yet';this.snack.open('New conversation created','Dismiss',{duration:2500});}
 exportTranscript(){const blob=new Blob([JSON.stringify({exportedAt:new Date().toISOString(),contextId:this.contextId,userContext:this.userContext,taskContext:this.taskContext,systemInstructions:this.systemInstructions,history:this.history},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`calian-session-${this.contextId.slice(0,8)}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
 copyId(){void navigator.clipboard.writeText(this.contextId);this.snack.open('Session ID copied','Dismiss',{duration:2000});}
 onKeydown(event:KeyboardEvent){if(event.key==='Enter'&&!event.shiftKey&&!matchMedia('(pointer:coarse)').matches){event.preventDefault();void this.send();}}
 async send(){const message=this.prompt.trim();if(!message||this.busy||this.voiceActive||this.voiceProcessing)return;this.busy=true;this.prompt='';this.error='';this.partial='';const context=this.context;this.history.push({role:'user',content:message,time:this.stamp()});this.scroll();let agent=this.selectedAgent;
 try{
 if(this.selected==='auto'){
  if(!this.agents.length)throw new Error('No discovered agents available. Refresh discovery.');
  const routed=await this.post('/api/router/select',{message,contextId:this.contextId,...(this.previousAgentId?{previousAgentId:this.previousAgentId}:{}),context,agents:this.agents.map(a=>({id:a.id,name:a.name,type:a.type,description:String(a.raw?.['description']||''),commands:a.commands||[]}))});
  if(!routed.agent)throw new Error(`No matching agent: ${routed.reason||'router returned no agent'}`);
  agent=this.agents.find(a=>a.id===routed.agent.id&&a.type===routed.agent.type);
  if(!agent)throw new Error('Router selected an agent not present in the discovered registry');
  this.lastRoute=`${agent.name} · Router: ${routed.method||'unknown'} · ${routed.reason||'Automatic selection'}${typeof routed.confidence==='number'?` · ${(routed.confidence*100).toFixed(0)}% confidence`:''}`;
  if(this.selectionOnly){const confidence=typeof routed.confidence==='number'?` (${(routed.confidence*100).toFixed(0)}% confidence)`:'';this.previousAgentId=agent.id;this.history.push({role:'assistant',content:`Auto-selected: ${agent.name}${confidence}\nSource: ${agent.type==='aicore'?'AI Core / Paradigm':'Python / A2A'}\nRouter: ${routed.method||'unknown'}\nReason: ${routed.reason||'Metadata match'}\nSelection only — agent execution was not attempted.`,agentId:agent.id,name:'Auto-selection result',time:this.stamp()});this.snack.open(`Routing successful: ${agent.name}`,'Dismiss',{duration:3500});return;}
 }else this.lastRoute=`Manual selection · ${agent?.name||'unknown'}`;
 if(!agent)throw new Error('Select an agent or refresh discovery');
 let answer='';
 if(agent.id==='local-ollama' && agent.type==='north'){const response=await this.post('/api/ollama/chat',{message,contextId:this.contextId,context});answer=String(response.text||'');}
 else if(agent.type==='aicore'){answer=coreText(await this.post('/api/ai-core/execute',{agentId:agent.id,message,contextId:this.contextId,context}));}
 else {answer=await this.socket.a2a(a2aRequest(agent.id,message,this.contextId,context),text=>{this.partial=text;this.scroll();});}
 this.previousAgentId=agent.id;this.history.push({role:'assistant',content:answer||'Agent returned no text response.',agentId:agent.id,name:agent.name,time:this.stamp()});this.partial='';
 }catch(e){this.error=e instanceof Error?e.message:String(e);this.partial='';}finally{this.busy=false;this.scroll();}}
}
