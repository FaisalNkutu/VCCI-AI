package com.calian.desktop;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.io.File;
import javax.swing.*;
import me.friwi.jcefmaven.CefAppBuilder;
import me.friwi.jcefmaven.MavenCefAppHandlerAdapter;
import org.cef.CefApp;
import org.cef.CefClient;
import org.cef.browser.CefBrowser;
import org.cef.handler.CefLoadHandlerAdapter;
import org.cef.browser.CefFrame;
import org.cef.handler.CefLoadHandler.ErrorCode;

public class AngularSwingHost {
    private static final String URL = "http://127.0.0.1:4200/";
    public static void main(String[] args) throws Exception {
        System.setProperty("jcef.remote.allow", "true");
        CefAppBuilder builder = new CefAppBuilder();
        builder.setInstallDir(new File(System.getProperty("user.home"), ".calian-jcef"));
        builder.getCefSettings().windowless_rendering_enabled = false;
        builder.setAppHandler(new MavenCefAppHandlerAdapter() {});
        CefApp app = builder.build();
        CefClient client = app.createClient();
        CefBrowser browser = client.createBrowser("about:blank", false, false);
        client.addLoadHandler(new CefLoadHandlerAdapter() {
            @Override public void onLoadError(CefBrowser b, CefFrame frame, ErrorCode code, String text, String failedUrl) {
                if (frame.isMain()) {
                    System.err.println("Angular load error: " + code + " " + text + " URL=" + failedUrl);
                    SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(null,
                        "Angular could not load inside Chromium.\\n" + text + "\\n" + failedUrl,
                        "CALIAN AI - Loading error", JOptionPane.ERROR_MESSAGE));
                }
            }
        });
        SwingUtilities.invokeAndWait(() -> {
            JFrame frame = new JFrame("CALIAN AI | Angular Embedded in Swing");
            frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
            frame.setLayout(new BorderLayout());
            JLabel status = new JLabel("CALIAN AI | Loading Angular in embedded Chromium...");
            frame.add(status, BorderLayout.NORTH);
            frame.add(browser.getUIComponent(), BorderLayout.CENTER);
            frame.setMinimumSize(new Dimension(900, 650));
            frame.setSize(1280, 850);
            frame.setLocationRelativeTo(null);
            frame.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override public void windowClosed(java.awt.event.WindowEvent e) {
                    browser.close(true);
                    client.dispose();
                    app.dispose();
                    System.exit(0);
                }
            });
            frame.setVisible(true);
            new javax.swing.Timer(1500, e -> {
                ((javax.swing.Timer)e.getSource()).stop();
                browser.loadURL(URL);
                status.setText("CALIAN AI | Embedded Angular: " + URL);
            }).start();
        });
    }
}
