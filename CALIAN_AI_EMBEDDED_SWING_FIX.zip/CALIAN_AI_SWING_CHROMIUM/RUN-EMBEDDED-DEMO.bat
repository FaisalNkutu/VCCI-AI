@echo off
setlocal
cd /d "%~dp0"
title CALIAN AI Embedded Swing Demo
where npm >nul 2>nul || (echo ERROR: npm missing & pause & exit /b 1)
where mvn >nul 2>nul || (echo ERROR: Maven missing & pause & exit /b 1)
where java >nul 2>nul || (echo ERROR: Java missing & pause & exit /b 1)
cd /d "%~dp0calian-ai-angular-material"
if not exist node_modules (
 echo Installing Angular dependencies once...
 call npm install || (echo npm install failed & pause & exit /b 1)
)
echo Starting backend and Angular without extra windows...
powershell -NoProfile -Command "$p='%CD%'; Start-Process -FilePath 'cmd.exe' -ArgumentList ('/c cd /d \"'+$p+'\" && npm run dev:server ^> backend-demo.log 2^>^&1') -WindowStyle Hidden; Start-Process -FilePath 'cmd.exe' -ArgumentList ('/c cd /d \"'+$p+'\" && npm run dev:client ^> angular-demo.log 2^>^&1') -WindowStyle Hidden"
echo Waiting for Angular at 127.0.0.1:4200 ...
powershell -NoProfile -Command "$ok=$false; for($i=0;$i -lt 90;$i++){try{$r=Invoke-WebRequest -UseBasicParsing 'http://127.0.0.1:4200/' -TimeoutSec 2; if($r.StatusCode -eq 200){$ok=$true;break}}catch{}; Start-Sleep -Seconds 2}; if(-not $ok){exit 1}"
if errorlevel 1 (
 echo Angular failed to start. Read calian-ai-angular-material\angular-demo.log
 pause
 exit /b 1
)
echo Launching one embedded Swing window...
cd /d "%~dp0swing-host"
call mvn compile exec:java
if errorlevel 1 (echo Swing failed; review Maven output & pause)
