# MIDAS + Calian AI — V5.1 Bridge Status Fix

## What the screenshots confirm

* The side panel, expanded iframe, and independent movable/resizable browser window render successfully.
* MIDAS's toolbar sometimes says **Bridge disconnected** while Calian's Session Inspector shows **Context shared**.
* The source explains this: `frameLoaded()` resets `connected` to false; Calian can subsequently reply to `INIT` with a token-authenticated `CONTEXT_REQUEST` even if the initial `HELLO` was not observed after the reset. The toolbar was only restored by `HELLO`.

## Fix

V5.1 marks the endpoint connected when MIDAS receives *any* valid token-bearing message from the exact trusted iframe or pop-out window. Its existing origin, source and token checks remain in place. No authentication, cross-window permission, integrity or approval check is disabled.

## Fast path for the existing V5 hotfix installation

1. Extract `MIDAS_Calian_V5_1_Bridge_Status_Fix.zip`.
2. Double-click `APPLY-V5-1-BRIDGE-STATUS-WINDOWS.bat`.
3. If more than one MIDAS copy appears, choose the one you are actively using. The script backs up its `.ts` file before applying the patch.
4. The running Angular watch server should recompile. Refresh MIDAS and check the top toolbar.
5. Turn on **Share dashboard context**, enter `Open Combat Power` into the *MIDAS control request* field, click **Propose MIDAS action**, then approve the request in the MIDAS host toolbar. Ensure the field actually contains the command rather than its placeholder.

If an Angular recompile fails, restore the backup file listed by the script. The script does not stop processes or reinstall dependencies.

## Limitations

* The screenshots do not demonstrate a complete command approval cycle or live MIDAS analytics; MIDAS still reports **No Datasource Connected**.
* The bridge-status fix is source-level and testable locally. A full Windows browser integration run is not possible in the current environment.
* Pop-out chat transfer is constrained; active speech or video calls are not transferred.
* The full V5.1 ZIP is for clean installations and still requires authorized Simfront Artifactory packages and configured backend services.
