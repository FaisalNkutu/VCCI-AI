@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLY-V5-1-BRIDGE-STATUS.ps1"
set RESULT=%ERRORLEVEL%
echo.
if not "%RESULT%"=="0" echo Fix was not applied. Review the message above.
pause
exit /b %RESULT%
