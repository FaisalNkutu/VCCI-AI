# MIDAS Calian V5.1: repair false-disconnected bridge status.
# Does not stop servers, edit dependencies, modify credentials, or bypass authorization.
$ErrorActionPreference = 'Stop'
$needle = "if (data.token !== (source === 'frame' ? this.token : this.popupToken)) return;"
$marker = 'A valid origin, source window and session token prove the endpoint'
$insert = @'
    // A valid origin, source window and session token prove the endpoint
    // acknowledged INIT. The iframe load event can otherwise overwrite the
    // earlier HELLO status, leaving the badge incorrectly disconnected.
    if (source === 'frame' && !this.connected()) this.connected.set(true);
    if (source === 'popup' && !this.popoutConnected()) this.popoutConnected.set(true);
'@
Write-Host "MIDAS + Calian V5.1: bridge-status correction" -ForegroundColor Cyan
$roots = @()
foreach ($r in @((Join-Path $env:USERPROFILE 'Downloads'), (Get-Location).Path)) {
  if ((Test-Path -LiteralPath $r) -and -not ($roots -contains $r)) { $roots += $r }
}
$files = @()
foreach ($r in $roots) {
  $files += @(Get-ChildItem -LiteralPath $r -Recurse -File -Filter 'midas-calian-copilot.component.ts' -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -match '[\\/]midas-frontend[\\/]src[\\/]app[\\/]components[\\/]calian-ai[\\/]midas-calian-copilot\.component\.ts$' })
}
$files = @($files | Sort-Object FullName -Unique | Sort-Object LastWriteTime -Descending)
if ($files.Count -eq 0) { throw 'No extracted MIDAS copilot source found under Downloads or current folder. Extract V5 first.' }
Write-Host 'MIDAS projects found:'
for ($i=0; $i -lt $files.Count; $i++) { Write-Host ("  [{0}] {1}" -f ($i+1), $files[$i].FullName) }
if ($files.Count -eq 1) { $chosen=$files[0] } else {
  $answer = Read-Host 'Enter number of the MIDAS instance you are using (blank cancels)'
  if ($answer -notmatch '^\d+$' -or [int]$answer -lt 1 -or [int]$answer -gt $files.Count) { throw 'Cancelled: no files changed.' }
  $chosen=$files[[int]$answer-1]
}
$path=$chosen.FullName
$data=Get-Content -LiteralPath $path -Raw -Encoding UTF8
if ($data.Contains($marker)) { Write-Host 'V5.1 fix already present; no changes required.' -ForegroundColor Green; exit 0 }
if (-not $data.Contains($needle)) { throw 'Expected V5 handshake code not found. No changes made; please use the full V5.1 package.' }
$backup="$path.v5.1-backup-$(Get-Date -Format yyyyMMdd-HHmmss)"
Copy-Item -LiteralPath $path -Destination $backup -ErrorAction Stop
$updated=$data.Replace($needle, $needle+"`r`n"+$insert)
if ($updated -eq $data) { throw 'No replacement occurred.' }
[System.IO.File]::WriteAllText($path,$updated,[System.Text.UTF8Encoding]::new($false))
Write-Host 'Updated:' $path -ForegroundColor Green
Write-Host 'Backup:' $backup
Write-Host 'Angular watch mode should recompile automatically. Refresh MIDAS to retest.'
Write-Host 'No running instances have been stopped.'
