'use strict';
const $=id=>document.getElementById(id);
let ws=null,pc=null,media=null,iceServers=[],pendingCandidates=[];
let groupMode=false,groupRoom=null;const groupTiles=new Map();
const invite=decodeURIComponent(location.pathname.split('/').pop()||'');
const status=s=>{$('status').textContent=s;};
const error=s=>{$('error').textContent=s;};
const send=data=>{if(ws?.readyState===WebSocket.OPEN)ws.send(JSON.stringify(data));};
function closeMedia(){closeGroup();media?.getTracks().forEach(t=>t.stop());media=null;pendingCandidates=[];if(pc){pc.close();pc=null;}$('localVideo').srcObject=null;$('remoteVideo').srcObject=null;}
// LiveKit SFU is loaded only for approved group calls. The server delivers no group token to waiting guests.
function loadLiveKit(){return new Promise((resolve,reject)=>{
 if(window.LivekitClient)return resolve(window.LivekitClient);
 const script=document.createElement('script');script.src='/livekit-client.umd.min.js';
 script.onload=()=>window.LivekitClient?resolve(window.LivekitClient):reject(Error('LiveKit client unavailable'));
 script.onerror=()=>reject(Error('Cannot load the group video client. Check VIDEO_CALL_SERVICE dependencies.'));
 document.head.appendChild(script);
});}
function closeGroup(){groupRoom?.disconnect();groupRoom=null;for(const tile of groupTiles.values())tile.remove();groupTiles.clear();$('groupLocalVideo').srcObject=null;}
function removeGroupTile(id){const tile=groupTiles.get(id);tile?.remove();groupTiles.delete(id);}
function attachGroupTrack(track,participant,lk){
 let tile=groupTiles.get(participant.identity);
 if(!tile){tile=document.createElement('div');tile.className='group-tile';const label=document.createElement('small');label.textContent=participant.name||'Participant';tile.appendChild(label);$('groupRemoteTiles').appendChild(tile);groupTiles.set(participant.identity,tile);}
 const element=document.createElement(track.kind===lk.Track.Kind.Video?'video':'audio');element.autoplay=true;if(element.tagName==='VIDEO')element.playsInline=true;
 track.attach(element);tile.appendChild(element);
 element.play().catch(()=>{status('Connected. Tap Enable sound if remote audio is blocked.');});
}
async function connectGroup(url,token){
 if(groupRoom)return;
 const lk=await loadLiveKit();
 const room=new lk.Room({adaptiveStream:true,dynacast:true});groupRoom=room;
 room.on(lk.RoomEvent.TrackSubscribed,(track,pub,participant)=>attachGroupTrack(track,participant,lk));
 room.on(lk.RoomEvent.TrackUnsubscribed,track=>{for(const el of track.detach())el.remove();});
 room.on(lk.RoomEvent.ParticipantDisconnected,participant=>removeGroupTile(participant.identity));
 room.on(lk.RoomEvent.Disconnected,()=>{if(groupRoom===room)status('Group media disconnected. Check LiveKit connectivity.');});
 try{
  await room.connect(url,token);
  for(const track of media?.getTracks()||[])await room.localParticipant.publishTrack(track,{source:track.kind==='video'?lk.Track.Source.Camera:lk.Track.Source.Microphone});
  $('groupLocalVideo').srcObject=media;status('Group video connected. Other participants will appear here.');
 }catch(e){closeGroup();throw e;}
}
async function startMedia(){
 if(!navigator.mediaDevices?.getUserMedia)throw Error('Camera and microphone require HTTPS and a compatible browser.');
 media=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true},video:{width:{ideal:960},height:{ideal:540}}});
 $('localVideo').srcObject=media;
}
async function initPc(){
 if(pc)return;
 pc=new RTCPeerConnection({iceServers});
 for(const track of media?.getTracks()||[])pc.addTrack(track,media);
 pc.ontrack=e=>{$('remoteVideo').srcObject=e.streams[0];};
 pc.onicecandidate=e=>{if(e.candidate)send({type:'signal',data:{kind:'candidate',candidate:e.candidate}});};
 pc.onconnectionstatechange=()=>{if(pc&&['failed','disconnected'].includes(pc.connectionState))status('Connection interrupted. Check the network or TURN server.');};
}
async function signal(data){
 if(!data||!['offer','answer','candidate'].includes(data.kind))return;
 await initPc();
 if(data.kind==='offer'){
  await pc.setRemoteDescription({type:'offer',sdp:data.sdp});
  for(const c of pendingCandidates)await pc.addIceCandidate(c);pendingCandidates=[];
  const answer=await pc.createAnswer();await pc.setLocalDescription(answer);
  send({type:'signal',data:{kind:'answer',sdp:answer.sdp}});
  status('Call connected.');
 }else if(data.kind==='candidate'&&data.candidate){try{if(!pc.remoteDescription)pendingCandidates.push(data.candidate);else await pc.addIceCandidate(data.candidate);}catch(e){console.warn('ICE candidate',e);}}
}
$('joinBtn').addEventListener('click',async()=>{
 $('joinBtn').disabled=true;error('');
 try{
  const name=$('displayName').value.trim();if(!name)throw Error('Enter your display name.');
  await startMedia();
  const response=await fetch('/api/guest/join',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({invite,name})});
  const b=await response.json();if(!response.ok)throw Error(b.error||`Join failed (${response.status})`);
  iceServers=b.iceServers;groupMode=b.mode==='group';$('join').hidden=true;$('call').hidden=false;$('directVideos').hidden=groupMode;$('groupVideos').hidden=!groupMode;status('Waiting for host approval…');
  ws=new WebSocket(b.wsUrl);
  ws.onopen=()=>send({type:'auth',ticket:b.guestTicket});
  ws.onmessage=async e=>{try{const m=JSON.parse(e.data);if(m.type==='waiting-status')status('Waiting for the host to admit you…');else if(m.type==='admitted'){status('Admitted. Connecting media…');if(!groupMode)await initPc();}else if(m.type==='group-join'&&groupMode){await connectGroup(m.url,m.token);}else if(m.type==='signal')await signal(m.data);else if(m.type==='denied')status('The host declined this request.');else if(m.type==='removed'){closeMedia();ws?.close();status('The host removed you from the meeting.');}else if(m.type==='host-disconnected')status('Host disconnected. Waiting for reconnection…');else if(m.type==='ended'){status('The call has ended.');closeMedia();}else if(m.type==='error')error(m.error);}catch(x){error(x.message);}};
  ws.onclose=()=>{status('Call connection closed.');closeMedia();};
 }catch(e){error(e.message);closeMedia();$('joinBtn').disabled=false;}
});
$('muteBtn').addEventListener('click',()=>{const t=media?.getAudioTracks()[0];if(t){t.enabled=!t.enabled;$('muteBtn').textContent=t.enabled?'Mute microphone':'Unmute microphone';}});
$('cameraBtn').addEventListener('click',()=>{const t=media?.getVideoTracks()[0];if(t){t.enabled=!t.enabled;$('cameraBtn').textContent=t.enabled?'Turn camera off':'Turn camera on';}});
$('enableSoundBtn').addEventListener('click',async()=>{try{await groupRoom?.startAudio();for(const audio of document.querySelectorAll('audio'))await audio.play().catch(()=>{});}catch(e){error(e.message);}});
$('leaveBtn').addEventListener('click',()=>{ws?.close();closeMedia();status('You have left the call.');});
window.addEventListener('beforeunload',()=>{ws?.close();closeMedia();});
