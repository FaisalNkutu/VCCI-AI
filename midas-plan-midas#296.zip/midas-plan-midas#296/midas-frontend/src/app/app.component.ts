import { SidebarComponent } from '@/components/sidebar/sidebar.component';
import { StatusData } from '@/models';
import { sidebarActions } from '@/store/actions/sidebar.actions';
import {
  selectConnectedDB,
  selectSelectedTimeFormat,
  selectStatusData,
  selectTimeFormatNames,
} from '@/store/features/sidebar.feature';
import { customWidthExpandCollapse } from '@/utils/animate';
import { AsyncPipe } from '@angular/common';
import { Component, computed, inject, OnDestroy, OnInit } from '@angular/core';
import { NavigationEnd, Router, RouterOutlet } from '@angular/router';
import { Store } from '@ngrx/store';
import { filter, Subscription } from 'rxjs';
import { API_URL } from './app.config';
import { SseService } from './services/sse.service';
import { toSignal } from '@angular/core/rxjs-interop';
import { MidasAiComponent } from '@/components/midas-ai/midas-ai.component';

@Component({
  selector: 'app-root',
  standalone: true,
  animations: [customWidthExpandCollapse('translate', '200px', '60px')],
  imports: [RouterOutlet, SidebarComponent, AsyncPipe, MidasAiComponent],
  templateUrl: './app.component.html',
})
export class AppComponent implements OnInit, OnDestroy {
  private router = inject(Router);

  currentUrl = toSignal(
    this.router.events.pipe(filter(e => e instanceof NavigationEnd)),
    { initialValue: null }
  );
  advMetrics = computed(() => this.currentUrl()?.url.includes('advmetrics') ?? false);
  lvcts = computed(() => this.currentUrl()?.url.includes('lvcts') ?? false);


  timeFormats$ = this.store.select(selectTimeFormatNames);
  statusData$ = this.store.select(selectStatusData);
  connectedDB$ = this.store.select(selectConnectedDB);
  selectedTimeFormat$ = this.store.select(selectSelectedTimeFormat);
  private sseSubscription?: Subscription;

  constructor(private store: Store, private sseService: SseService) {
  }

  // on init, we need the overall time formats and start and end time of the exercise
  // we also need to subscribe to the status data from the server
  ngOnInit(): void {
    this.store.dispatch(sidebarActions.getTimeFormats());
    this.store.dispatch(sidebarActions.getMinMaxTime());
    this.store.dispatch(sidebarActions.getConnectedDB());
    this.store.dispatch(sidebarActions.getMapServerURL());

    this.sseSubscription = this.sseService
      .getServerSentEvents<StatusData>(`${API_URL}/advmetrics/sse/mstatus`)
      .subscribe((event) => {
        this.store.dispatch(sidebarActions.statusDataReceived(event));
      });
  }

  ngOnDestroy(): void {
    this.sseSubscription?.unsubscribe();
  }
}
