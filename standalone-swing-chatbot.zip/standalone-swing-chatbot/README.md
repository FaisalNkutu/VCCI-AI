# Standalone Java Swing AI Chatbot

## Requirements
- Java JDK 21
- Apache Maven 3.9+
- Python AI Service listening on http://127.0.0.1:9999

## Run on Windows
Open a terminal in this folder and run:

```powershell
mvn compile exec:java
```

Or double-click `run-windows.bat` if Maven is on PATH.

## Run on Linux/macOS
`./run-linux-macos.sh`

## Project files
- `pom.xml`: Maven project (Jackson dependency, Java 21)
- `src/main/java/com/softknf/chat/ChatApp.java`: user's original working Python A2A 1.0 / SSE Swing chatbot, unchanged
- `src/main/java/com/softknf/chat/AICoreAgentRegistry.java`: independent thread-safe AI Core agent URL cache, ready to connect to asynchronous Paradigm response

## Current behavior
- Python `GET /agents` populates the dropdown.
- Manual selection, Python `/router/select`, shared conversation context, and A2A 1.0 SSE are preserved.

## Paradigm / RabbitMQ status
**Not yet wired or tested.** The proprietary Paradigm dependencies, bootstrap configuration, and exact `retrieveAIAgents` / `processResponse` code are not included in the supplied `pom.xml` and sources. This package therefore does **not** retrieve AI Core agents yet. The cache class is a preparatory component, not an active integration. The standalone UI remains independent of VCCI.

## Troubleshooting
If `mvn` is not recognized, install Maven and add it to PATH. If the dropdown is empty or refresh fails, start the Python AI Service first and verify `http://127.0.0.1:9999/agents`.
