@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title MIDAS + Calian AI Copilot V4.3 - New Instance on Free Ports
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0SETUP-AND-RUN-WINDOWS.ps1"
if errorlevel 1 (
  echo.
  echo SETUP COULD NOT COMPLETE. See the error above and LOGS folder.
  echo Your existing MIDAS/Calian instances have NOT been stopped.
)
echo.
pause
endlocal
