import { Component, ElementRef, OnDestroy, OnInit, ViewChild, inject, signal } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { NavigationEnd, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Subscription, filter } from 'rxjs';
import { APP_PREF_KEY } from '@/app.guard';
import { sidebarActions } from '@/store/actions/sidebar.actions';
import { cpActions } from '@/store/actions/cp.actions';
import { selectMinMaxTime, selectSelectedTimeFormat, selectTimeFormatNames } from '@/store/features/sidebar.feature';
import { selectCpEntities, selectCpSelectedEntityIds, selectCpTimeframe } from '@/store/features/cp.feature';
import { routes as dashboardRoutes } from '@/utils/routes';
import { MidasCopilotUiState } from './midas-copilot-ui-state';

const BRIDGE = 'MIDAS_CALIAN_V1';
const dashboards: Record<string, string> = {
  summary: dashboardRoutes.SUM.route,
  'h-hour': dashboardRoutes.HH.route,
  rom: dashboardRoutes.ROM.route,
  poe: dashboardRoutes.POE.route,
  cm: dashboardRoutes.CM.route,
  fratricide: dashboardRoutes.FRAT.route,
  'enemy-engagement': dashboardRoutes.ENG.route,
  cp: dashboardRoutes.CP.route,
  'unit-watch': dashboardRoutes.UW.route,
  'holdings-rollup': dashboardRoutes.HR.route,
  c2: 'c2',
};

type ActionName = 'navigate' | 'time_format' | 'cp_time_range' | 'cp_select_entity';
interface ActionRequest {
  action: ActionName;
  params: Record<string, unknown>;
}
interface PendingRequest { id: string; request: ActionRequest; description: string; }

function configuredUrl(): string | null {
  const value = (window as Window & { __MIDAS_CALIAN_EMBED_URL__?: string }).__MIDAS_CALIAN_EMBED_URL__;
  if (typeof value !== 'string' || !value.trim()) return null;
  try {
    const u = new URL(value);
    const local = u.hostname === 'localhost' || u.hostname === '127.0.0.1';
    if (!(u.protocol === 'https:' || (local && u.protocol === 'http:'))) return null;
    if (u.username || u.password || u.hash || u.search) return null;
    return u.href;
  } catch { return null; }
}

@Component({
  selector: 'app-midas-calian-copilot',
  standalone: true,
  styles: [`
    :host { display: contents; }
    .midas-copilot { display:flex; flex-direction:column; flex:0 0 auto; width:min(44vw,650px); min-width:350px; height:100%; color:#f4f8fc; background:#0c182a; border-left:1px solid #334155; }
    .midas-copilot.maximized { width:100%; min-width:0; }
    .midas-copilot.closed { display:none; }
    .copilot-frame { width:100%; flex:1; min-height:0; border:0; background:#0c182a; }
    .copilot-toolbar { display:flex; align-items:center; gap:9px; padding:8px 12px; background:#17263c; flex-wrap:wrap; font-size:13px; }
    .copilot-toolbar button, .copilot-confirm button { border:1px solid #64748b; color:white; border-radius:5px; padding:5px 9px; background:#243751; cursor:pointer; }
    .copilot-toolbar button:focus-visible, .copilot-confirm button:focus-visible { outline:3px solid #38bdf8; }
    .copilot-confirm { padding:12px; border-bottom:1px solid #f59e0b; background:#3a2b19; font-size:13px; }
    .copilot-confirm p { margin:5px 0 10px; overflow-wrap:anywhere; }
    .copilot-confirm .accept { background:#115e59; }
    .badge { font-size:11px; opacity:.85; }
    .midas-fab { position:fixed; right:18px; top:14px; z-index:60; padding:9px 14px; background:#075b94; border:1px solid #7dd3fc; color:white; border-radius:6px; box-shadow:0 3px 12px #0005; }
    @media(max-width:900px){ .midas-copilot:not(.closed) { position:fixed; inset:0; z-index:70; width:100%; min-width:0; height:100dvh; } }
  `],
  template: `
    @if (!open() && !fullPage()) {
      <button type="button" class="midas-fab" (click)="show()" aria-label="Open Calian AI Copilot">Calian AI Copilot</button>
    }
    <aside class="midas-copilot" [class.closed]="!open() && !fullPage()" [class.maximized]="fullPage()" aria-label="Calian AI Copilot">
      <div class="copilot-toolbar">
        <strong>Calian AI · MIDAS Copilot</strong>
        <span class="badge" role="status">{{connected() ? 'Bridge connected' : 'Bridge disconnected'}}</span>
        <label title="Share only the current dashboard and control state with Calian agents">
          <input type="checkbox" [checked]="shareContext()" (change)="toggleSharing($event)" /> Share dashboard context
        </label>
        <button type="button" (click)="toggleFull()">{{ fullPage() ? 'Side panel' : 'Expand' }}</button>
        <button type="button" (click)="switchWorkspace()">Workspaces</button>
        <button type="button" (click)="close()" aria-label="Close Calian Copilot">Close</button>
      </div>
      @if (pending(); as item) {
        <section class="copilot-confirm" role="alertdialog" aria-label="Approve requested MIDAS action" aria-modal="false">
          <strong>Approve MIDAS change?</strong>
          <p>{{item.description}}</p>
          <button type="button" class="accept" (click)="approve()">Approve</button>
          <button type="button" (click)="reject()">Decline</button>
        </section>
      }
      @if (trustedUrl) {
        <iframe #frame class="copilot-frame" [src]="trustedUrl" (load)="frameLoaded()"
          title="Calian AI embedded chatbot" referrerpolicy="strict-origin-when-cross-origin"
          allow="camera; microphone; fullscreen; display-capture" allowfullscreen></iframe>
      } @else {
        <p style="padding:20px">Configure an administrator-approved Calian URL in assets/calian-embed-config.js.</p>
      }
    </aside>
  `
})
export class MidasCalianCopilotComponent implements OnInit, OnDestroy {
  @ViewChild('frame') frame?: ElementRef<HTMLIFrameElement>;
  private readonly store = inject(Store);
  private readonly router = inject(Router);
  private readonly sanitizer = inject(DomSanitizer);
  private readonly subscriptions = new Subscription();
  private readonly url = configuredUrl();
  private readonly targetOrigin = this.url ? new URL(this.url).origin : null;
  private readonly token = crypto.randomUUID();
  readonly trustedUrl: SafeResourceUrl | null = this.url ? this.sanitizer.bypassSecurityTrustResourceUrl(this.url) : null;
  private readonly uiState = inject(MidasCopilotUiState);
  readonly open = this.uiState.open;
  readonly fullPage = this.uiState.fullPage;
  readonly shareContext = signal(false); // User must opt in before any MIDAS state is shared.
  readonly connected = signal(false);
  readonly pending = signal<PendingRequest | null>(null);
  private lastRoute = '';

  ngOnInit(): void {
    this.routeChanged();
    this.subscriptions.add(this.router.events.pipe(filter(e => e instanceof NavigationEnd)).subscribe(() => {
      this.routeChanged();
      this.sendContext();
    }));
    // Each NgRx selector has its own observable type. Subscribing separately
    // avoids calling subscribe() on a union of incompatible overload signatures.
    this.subscriptions.add(this.store.select(selectSelectedTimeFormat).subscribe(() => this.sendContext()));
    this.subscriptions.add(this.store.select(selectTimeFormatNames).subscribe(() => this.sendContext()));
    this.subscriptions.add(this.store.select(selectCpTimeframe).subscribe(() => this.sendContext()));
    this.subscriptions.add(this.store.select(selectCpSelectedEntityIds).subscribe(() => this.sendContext()));
    this.subscriptions.add(this.store.select(selectCpEntities).subscribe(() => this.sendContext()));
    window.addEventListener('message', this.onMessage);
  }
  ngOnDestroy(): void {
    window.removeEventListener('message', this.onMessage);
    this.subscriptions.unsubscribe();
  }
  private routeChanged(): void {
    this.lastRoute = this.router.url.split('?')[0].split('#')[0];
    if (this.lastRoute === '/calian-ai') { this.fullPage.set(true); this.open.set(true); }
    else this.fullPage.set(false);
  }
  show(): void { this.open.set(true); this.sendContext(); }
  switchWorkspace(): void {
    this.fullPage.set(false);
    this.open.set(false);
    this.shareContext.set(false);
    this.pending.set(null);
    localStorage.removeItem(APP_PREF_KEY);
    void this.router.navigateByUrl('/');
    this.sendContext();
  }
  close(): void {
    this.pending.set(null);
    this.shareContext.set(false);
    this.open.set(false);
    if (this.fullPage()) {
      this.fullPage.set(false);
      localStorage.setItem(APP_PREF_KEY, 'advmetrics');
      void this.router.navigateByUrl('/advmetrics');
    }
    this.sendContext();
  }
  toggleFull(): void {
    if (this.fullPage()) {
      this.fullPage.set(false);
      if (this.lastRoute === '/calian-ai') {
        localStorage.setItem(APP_PREF_KEY, 'advmetrics');
        void this.router.navigateByUrl('/advmetrics');
      }
    } else { this.fullPage.set(true); this.open.set(true); }
  }
  toggleSharing(event: Event): void {
    this.shareContext.set((event.target as HTMLInputElement).checked);
    this.pending.set(null);
    this.sendContext();
  }
  private isVisible(): boolean { return this.open() || this.fullPage(); }
  private send(type: string, body: Record<string, unknown> = {}): void {
    if (!this.targetOrigin || !this.frame?.nativeElement.contentWindow) return;
    this.frame.nativeElement.contentWindow.postMessage({ bridge: BRIDGE, type, ...body }, this.targetOrigin);
  }
  frameLoaded(): void {
    this.connected.set(false);
    this.send('INIT', { token: this.token, capabilities: this.capabilities() });
    this.sendContext();
  }
  private capabilities(): Record<string, unknown> {
    return { dashboards: Object.keys(dashboards), actions: ['navigate','time_format','cp_time_range','cp_select_entity'], approvalRequired: true };
  }
  private context(): Record<string, unknown> | null {
    if (!this.shareContext() || !this.isVisible()) return null;
    const route = this.lastRoute === '/calian-ai' ? null : this.lastRoute;
    const onCP = route === '/advmetrics/cp';
    const entities = onCP ? this.store.selectSignal(selectCpEntities)().slice(0, 40).map(e => ({ id: e.id, name: e.name })) : [];
    return {
      route,
      selectedTimeFormat: this.store.selectSignal(selectSelectedTimeFormat)(),
      availableTimeFormats: this.store.selectSignal(selectTimeFormatNames)().slice(0, 40),
      ...(onCP ? {
        cpTimeframe: this.store.selectSignal(selectCpTimeframe)(),
        cpSelectedEntityIds: this.store.selectSignal(selectCpSelectedEntityIds)().slice(0, 100),
        cpEntities: entities,
      } : {}),
    };
  }
  private sendContext(): void {
    this.send('CONTEXT', { token: this.token, sharing: this.shareContext() && this.isVisible(), context: this.context() });
  }
  private onMessage = (event: MessageEvent): void => {
    if (!this.targetOrigin || event.origin !== this.targetOrigin || event.source !== this.frame?.nativeElement.contentWindow) return;
    const data = event.data;
    if (!data || typeof data !== 'object' || data.bridge !== BRIDGE || typeof data.type !== 'string') return;
    if (data.type === 'HELLO') {
      this.connected.set(true);
      this.send('INIT', { token: this.token, capabilities: this.capabilities() });
      this.sendContext();
      return;
    }
    if (data.token !== this.token) return;
    if (data.type === 'CONTEXT_REQUEST') { this.sendContext(); return; }
    if (data.type !== 'ACTION_REQUEST') return;
    if (!this.shareContext() || !this.isVisible()) { this.reply(String(data.id || ''), false, 'Turn on Share dashboard context first.'); return; }
    const id = data.id;
    if (typeof id !== 'string' || !/^[a-zA-Z0-9-]{1,80}$/.test(id)) return;
    const request = this.validateRequest(data.action, data.params);
    if (!request) { this.reply(id, false, 'Unsupported or invalid MIDAS action.'); return; }
    if (this.pending()) { this.reply(id, false, 'Another action is awaiting approval.'); return; }
    this.pending.set({ id, request, description: this.describe(request) });
  };
  private validateRequest(action: unknown, params: unknown): ActionRequest | null {
    if (!params || typeof params !== 'object' || Array.isArray(params)) return null;
    const p = params as Record<string, unknown>;
    if (action === 'navigate' && typeof p['dashboard'] === 'string' && Object.hasOwn(dashboards, p['dashboard'])) return { action, params: { dashboard: p['dashboard'] } };
    if (action === 'time_format' && typeof p['name'] === 'string' && this.store.selectSignal(selectTimeFormatNames)().includes(p['name'])) return { action, params: { name: p['name'] } };
    if (action === 'cp_time_range' && this.lastRoute === '/advmetrics/cp' && typeof p['start'] === 'number' && typeof p['end'] === 'number') {
      const minMax = this.store.selectSignal(selectMinMaxTime)();
      if (minMax && Number.isFinite(p['start']) && Number.isFinite(p['end']) && p['start'] >= minMax.minTime && p['end'] <= minMax.maxTime && p['start'] < p['end']) return { action, params: { start: p['start'], end: p['end'] } };
    }
    if (action === 'cp_select_entity' && this.lastRoute === '/advmetrics/cp' && typeof p['id'] === 'number' && Number.isSafeInteger(p['id'])) {
      if (this.store.selectSignal(selectCpEntities)().some(e => e.id === p['id'])) return { action, params: { id: p['id'], selected: p['selected'] !== false } };
    }
    return null;
  }
  private describe(r: ActionRequest): string {
    const p = r.params;
    if (r.action === 'navigate') return `Navigate MIDAS to the ${String(p['dashboard'])} dashboard.`;
    if (r.action === 'time_format') return `Set MIDAS time format to ${String(p['name'])}.`;
    if (r.action === 'cp_time_range') return `Set Combat Power timeframe to ${p['start']}–${p['end']} (MIDAS native time units).`;
    return `${p['selected'] ? 'Select' : 'Deselect'} Combat Power entity ${p['id']}.`;
  }
  private reply(id: string, ok: boolean, message: string): void { this.send('ACTION_RESULT', { token: this.token, id, ok, message }); }
  async approve(): Promise<void> {
    const item = this.pending();
    if (!item) return;
    this.pending.set(null);
    // Revalidate against the latest route and store state before applying changes.
    const request = this.validateRequest(item.request.action, item.request.params);
    if (!request || !this.isVisible() || !this.shareContext()) { this.reply(item.id, false, 'Action no longer valid.'); return; }
    const p = request.params;
    try {
      switch (request.action) {
        case 'navigate': {
          const success = await this.router.navigateByUrl(`/advmetrics/${dashboards[String(p['dashboard'])]}`);
          this.reply(item.id, success, success ? 'MIDAS navigated successfully.' : 'Navigation was rejected by the router.');
          break;
        }
        case 'time_format':
          this.store.dispatch(sidebarActions.timeFormatSelected(String(p['name'])));
          this.reply(item.id, true, 'MIDAS time format updated.');
          break;
        case 'cp_time_range':
          this.store.dispatch(cpActions.timeframeChange({ start: Number(p['start']), end: Number(p['end']) }));
          this.reply(item.id, true, 'Combat Power time range updated.');
          break;
        case 'cp_select_entity': {
          const id = Number(p['id']);
          const present = this.store.selectSignal(selectCpSelectedEntityIds)().includes(id);
          if (Boolean(p['selected']) !== present) this.store.dispatch(Boolean(p['selected']) ? cpActions.entitySelected(id) : cpActions.entityDeselected(id));
          this.reply(item.id, true, 'Combat Power entity selection updated.');
          break;
        }
      }
      this.sendContext();
    } catch {
      this.reply(item.id, false, 'MIDAS could not complete that action.');
    }
  }
  reject(): void {
    const item = this.pending();
    this.pending.set(null);
    if (item) this.reply(item.id, false, 'The MIDAS action was declined.');
  }
}
