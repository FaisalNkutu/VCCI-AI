<#
 MIDAS + CALIAN AI COPILOT V4.3: isolated local Windows development launcher.
 Windows PowerShell 5.1+; leaves ALL existing listeners/processes untouched.
 Each invocation selects free (4200+n, 4300+n, 8797+n), 0<=n<=99.
 Launch services in separate command windows with per-process port environment.
 No shared source/configuration files are modified at launch time.
 Private npm packages require the user's existing authorized Simfront credentials.
#>
[CmdletBinding()]
param(
  [switch]$InstallOnly,
  [switch]$NoOpenBrowser,
  [switch]$AlwaysInstall,
  [switch]$CheckOnly
)

$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$midas=Join-Path $root 'midas\midas-frontend'
$calian=Join-Path $root 'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES'
$logDir=Join-Path $root 'LOGS'
$runsDir=Join-Path $root 'RUNS'
$recordPath=$null
$record=$null
New-Item -ItemType Directory -Force -Path $logDir,$runsDir | Out-Null
$logPath=Join-Path $logDir ('setup-v4-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.log')

function Say([string]$message, [string]$color='Gray') {
  Write-Host $message -ForegroundColor $color
  # No secrets are collected or displayed by this launcher. Never record install command output.
  Add-Content -LiteralPath $logPath -Value $message
}
function Ensure([bool]$condition,[string]$message) {
  if (-not $condition) { throw $message }
}
function RequireCommand([string]$name,[string]$hint) {
  if (-not (Get-Command $name -ErrorAction SilentlyContinue)) {throw "Missing $name. $hint"}
}
function PortFree([int]$p) {
  $listener=$null
  try {
    $listener=[System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback,$p)
    $listener.Start()
    return $true
  } catch {return $false}
  finally {if($null -ne $listener){try{$listener.Stop()}catch{}}}
}
function ChoosePortFamily {
  for($offset=0;$offset -le 99;$offset++) {
    $mp=4200+$offset; $cp=4300+$offset; $bp=8797+$offset
    if((PortFree $mp) -and (PortFree $cp) -and (PortFree $bp)) {
      return @{offset=$offset;midas=$mp;calian=$cp;backend=$bp}
    }
  }
  throw 'No complete free port family within 4200-4299 / 4300-4399 / 8797-8896. Existing apps were not changed.'
}
function GetText([string]$url,[int]$timeoutSec=4) {
  try {return (Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec $timeoutSec -ErrorAction Stop).Content}
  catch {return $null}
}
function WaitText([string]$url,[int]$timeoutSeconds) {
  $end=(Get-Date).AddSeconds($timeoutSeconds)
  do {
    $result=GetText $url 3
    if($null -ne $result){return $result}
    Start-Sleep -Seconds 2
  } while((Get-Date) -lt $end)
  return $null
}
function InstallProject([string]$label,[string]$directory,[string]$command,[string[]]$arguments) {
  Say "Installing missing dependencies: $label" 'Cyan'
  Push-Location -LiteralPath $directory
  try {
    & $command @arguments
    if($LASTEXITCODE -ne 0){throw "$label installation failed with exit code $LASTEXITCODE. The install error above is authoritative."}
  } finally {Pop-Location}
}
function WriteServiceBat([string]$path,[string]$title,[string]$directory,[string[]]$variables,[string]$command) {
  $lines=@('@echo off', 'setlocal EnableExtensions', ('title '+$title), ('cd /d "'+$directory+'"'))
  foreach($variable in $variables){$lines+=('set "'+$variable+'"')}
  $lines+=('echo Starting '+$title),$command,'set "EXITCODE=%ERRORLEVEL%"','echo.',('echo '+$title+' exited with code %EXITCODE%.'),'pause','exit /b %EXITCODE%'
  [System.IO.File]::WriteAllLines($path,[string[]]$lines,[System.Text.Encoding]::ASCII)
}
function StartWindow([string]$label,[string]$directory,[string]$batPath) {
  Say "Starting $label" 'Cyan'
  # The shell window stays open to show Angular/Node build errors and runtime logs.
  $process=Start-Process -FilePath $env:ComSpec -WorkingDirectory $directory -ArgumentList ('/k call "'+$batPath+'"') -PassThru
  return $process.Id
}
function ShowRuns {
  Say 'Previously launched V4 instances from this folder:' 'Cyan'
  $records=Get-ChildItem -LiteralPath $runsDir -Filter 'instance.json' -Recurse -File -ErrorAction SilentlyContinue
  if (-not $records) {Say '  None recorded.';return}
  foreach($r in $records){
    try {
      $run=Get-Content -LiteralPath $r.FullName -Raw | ConvertFrom-Json
      $alive=($null -ne (GetText ("http://127.0.0.1:{0}/assets/calian-embed-config.js" -f $run.ports.midas) 2))
      Say ("  {0} | MIDAS {1} | Calian {2} | Backend {3} | MIDAS HTTP {4}" -f $run.id,$run.ports.midas,$run.ports.calian,$run.ports.backend,$alive)
    }catch{Say ('  Could not read '+$r.FullName) 'Yellow'}
  }
}

try {
  Say '============================================================' 'Cyan'
  Say ' MIDAS + CALIAN AI COPILOT V4.3 | AUTOMATIC FREE-PORT START' 'Cyan'
  Say '============================================================' 'Cyan'
  Say ('Package: '+$root)
  Ensure (Test-Path -LiteralPath (Join-Path $midas 'package.json')) 'MIDAS source missing: extract the entire ZIP.'
  Ensure (Test-Path -LiteralPath (Join-Path $calian 'package.json')) 'Calian source missing: extract the entire ZIP.'
  Ensure (-not ($root -match '#')) 'Extract V4.3 into a folder path WITHOUT # (hash), which Vite cannot reliably serve.'
  $ports=ChoosePortFamily
  Say ("Next FREE group: MIDAS http://127.0.0.1:{0} | Calian http://127.0.0.1:{1} | backend http://127.0.0.1:{2}" -f $ports.midas,$ports.calian,$ports.backend) 'Green'
  ShowRuns
  if($CheckOnly){Say 'Read-only diagnostic complete. No services stopped or started.' 'Green';exit 0}

  RequireCommand 'node' 'Install a supported Node.js release from https://nodejs.org/.'
  RequireCommand 'npm' 'Repair Node.js/npm then retry.'
  Say ('Node version: '+(& node --version)) 'Gray'
  if(-not(Get-Command pnpm -ErrorAction SilentlyContinue)) {
    Say 'pnpm not found. Installing pnpm 10 into the current user npm environment...' 'Yellow'
    & npm install --global pnpm@10
    if($LASTEXITCODE -ne 0){throw 'Unable to install pnpm. Ask IT to approve pnpm, then rerun.'}
  }
  RequireCommand 'pnpm' 'Install pnpm 10 from https://pnpm.io/installation.'
  Say ('pnpm version: '+(& pnpm --version)) 'Gray'
  $calianBin=Join-Path $calian 'node_modules\.bin\ng.cmd'
  Ensure (Test-Path -LiteralPath (Join-Path $midas 'pnpm-workspace.yaml')) 'MIDAS build approval file missing; fully extract V4.1 ZIP.'
  $midasBin=Join-Path $midas 'node_modules\.bin\ng.cmd'
  if($AlwaysInstall -or (-not (Test-Path -LiteralPath $calianBin))) {
    InstallProject 'Calian Angular + Node' $calian 'npm' @('install','--no-fund','--no-audit')
    Ensure (Test-Path -LiteralPath $calianBin) 'Calian installation completed without ng.cmd in node_modules.'
  } else {Say 'Calian dependencies present; skipping installation.' 'Green'}
  if($AlwaysInstall -or (-not (Test-Path -LiteralPath $midasBin))) {
    Say 'MIDAS private packages require your existing authorized corporate Artifactory access.' 'Yellow'
    try {InstallProject 'MIDAS Angular' $midas 'pnpm' @('install','--frozen-lockfile')}
    catch {
      Say 'MIDAS private registry/package installation failed. Existing apps are unchanged.' 'Red'
      Say '401/403: check approved credentials/VPN; 404: check private package/version; integrity or tarball mismatch: do not disable verification. ERR_PNPM_IGNORED_BUILDS: review pnpm-workspace.yaml build-script policy.' 'Yellow'
      Say 'The original unchanged lockfile is in SETUP_SUPPORT.' 'Gray'
      throw
    }
    Ensure (Test-Path -LiteralPath $midasBin) 'MIDAS install completed without ng.cmd in node_modules.'
  } else {Say 'MIDAS dependencies present; skipping installation.' 'Green'}

  Say 'Both frontend dependency sets are available.' 'Green'
  if($InstallOnly){Say 'InstallOnly requested. No services launched.' 'Green';exit 0}

  # Recheck after lengthy installs: ports could have become occupied.
  if(-not((PortFree $ports.midas) -and (PortFree $ports.calian) -and (PortFree $ports.backend))){
    Say 'The selected ports changed while dependencies were installing; selecting another free group.' 'Yellow'
    $ports=ChoosePortFamily
  }
  $id='v4-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+([guid]::NewGuid().ToString('N').Substring(0,6))
  $runDir=Join-Path $runsDir $id
  New-Item -ItemType Directory -Path $runDir | Out-Null
  $backendBat=Join-Path $runDir 'calian-backend.cmd'
  $frontendBat=Join-Path $runDir 'calian-ui.cmd'
  $midasBat=Join-Path $runDir 'midas-ui.cmd'
  $backendOrigin="http://127.0.0.1:$($ports.calian)"
  $midasOrigin="http://127.0.0.1:$($ports.midas)"
  WriteServiceBat $backendBat "CALIAN V4 BACKEND $($ports.backend)" $calian @(
    "PORT=$($ports.backend)","CALIAN_UI_ORIGIN=$backendOrigin", "CALIAN_EMBED_PARENT_ORIGIN=$midasOrigin", "CALIAN_INSTANCE_ID=$id") 'call npm run dev:server'
  WriteServiceBat $frontendBat "CALIAN V4 UI $($ports.calian)" $calian @("CALIAN_BACKEND_PORT=$($ports.backend)") (
    'call "'+(Join-Path $calian 'node_modules\.bin\ng.cmd')+'" serve --host 127.0.0.1 --port '+$ports.calian+' --proxy-config proxy.conf.cjs')
  WriteServiceBat $midasBat "MIDAS V4 UI $($ports.midas)" $midas @() (
    'call "'+(Join-Path $midas 'node_modules\.bin\ng.cmd')+'" serve --host 127.0.0.1 --port '+$ports.midas+' --prebundle=false')

  $record=@{
    id=$id
    started=(Get-Date).ToString('o')
    status='starting'
    ports=@{midas=$ports.midas;calian=$ports.calian;backend=$ports.backend}
    midasUrl="http://127.0.0.1:$($ports.midas)/calian-ai"
    calianUrl="http://127.0.0.1:$($ports.calian)/"
    processes=@{midasShellPid=$null;calianShellPid=$null;backendShellPid=$null}
  }
  $recordPath=Join-Path $runDir 'instance.json'
  $record|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $recordPath -Encoding UTF8

  $pidBackend=StartWindow "Calian backend on $($ports.backend)" $calian $backendBat
  $record.processes.backendShellPid=$pidBackend
  $record|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $recordPath -Encoding UTF8
  $backendText=WaitText "http://127.0.0.1:$($ports.backend)/api/health" 90
  if($null -eq $backendText){throw "Calian backend did not respond on $($ports.backend). Inspect its new console window."}
  $health=$backendText | ConvertFrom-Json
  Ensure ($health.status -eq 'ready' -and $health.instanceId -eq $id) 'A different backend answered the selected port; refusing to attach another instance.'

  $pidCalian=StartWindow "Calian UI on $($ports.calian)" $calian $frontendBat
  $record.processes.calianShellPid=$pidCalian
  $record|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $recordPath -Encoding UTF8
  $calianText=WaitText "http://127.0.0.1:$($ports.calian)/midas-bridge-config.js" 180
  Ensure ($null -ne $calianText -and $calianText.Contains('MIDAS-CALIAN-BRIDGE-V4')) 'Calian Angular did not serve the V4 bridge. Inspect its new console window.'

  $pidMidas=StartWindow "MIDAS UI on $($ports.midas)" $midas $midasBat
  $record.processes.midasShellPid=$pidMidas
  $record|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $recordPath -Encoding UTF8
  $midasText=WaitText "http://127.0.0.1:$($ports.midas)/assets/calian-embed-config.js" 180
  Ensure ($null -ne $midasText -and $midasText.Contains('MIDAS-CALIAN-BRIDGE-V4')) 'MIDAS Angular did not serve the V4 iframe config. Inspect its new console window.'

  $record.status='ready'
  $record|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $recordPath -Encoding UTF8
  Say ''
  Say 'SUCCESS: V4 instance is running on new, matching local ports.' 'Green'
  Say ('MIDAS COPILOT: '+$record.midasUrl) 'White'
  Say ('CALIAN WEB UI: '+$record.calianUrl) 'White'
  Say ("CALIAN BACKEND: http://127.0.0.1:$($ports.backend)/api/health") 'White'
  Say ('Run record: '+(Join-Path $runDir 'instance.json'))
  if(-not $NoOpenBrowser){Start-Process $record.midasUrl|Out-Null}
  Say 'Existing apps are untouched. The new three console windows must remain open.' 'Green'
  Say 'External AI agents, MIDAS datasets and video gateway may still use shared upstream services.' 'Yellow'
} catch {
  if($recordPath -and $record) {
    try {
      $record.status='failed'
      $record.failure=$_.Exception.Message
      $record|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $recordPath -Encoding UTF8
    } catch { }
  }
  Say ('SETUP BLOCKED: '+$_.Exception.Message) 'Red'
  Say ('See console windows and log: '+$logPath)
  Say 'Existing applications were never stopped or killed.' 'Yellow'
  exit 1
}
