import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {stripTypeScriptTypes} from 'node:module';
const root=new URL('../../Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/',import.meta.url);
const app=new URL('src/app/',root);
const helper=new URL('natural-voice.ts',app);
const commands=new URL('hands-free-commands.ts',app);
const {naturalVoiceRoute,stripVoiceWake,naturalVoiceMessages}=await import(helper.href);
const {voiceNoise,confirmationCommand}=await import(commands.href);
const source=readFileSync(new URL('app.component.ts',app),'utf8');
const server=readFileSync(new URL('server/index.ts',root),'utf8');
const html=readFileSync(new URL('app.component.html',app),'utf8');
const voiceMethods=source.slice(source.indexOf(' private async handleVoiceCommand('),source.indexOf(' private voiceSessionId='));
const sendMethod=source.slice(source.indexOf(' async send(){'),source.lastIndexOf('\n}'));
const harness=`import {voiceCommand,voiceNoise,confirmationCommand,replacementQuestion} from ${JSON.stringify(commands.href)};
import {naturalVoiceRoute,stripVoiceWake} from ${JSON.stringify(helper.href)};
import {isDatabaseRetrievalRequest} from ${JSON.stringify(new URL('db-intent.ts',app).href)};
const speechSummary=(_p,t)=>t;
export class Harness {
 handsFree=true;voiceWakeRequired=false;voiceNaturalConversation=true;voiceAutoSubmit=true;voicePending='';prompt='';lastVoicePlayback='';busy=false;voiceActive=false;voiceProcessing=false;speechPlaying=false;history=[];sent=[];said=[];calls=[];schedules=0;databaseSchema='a';selected='auto';voiceSessionId='session';voicePlaybackAttempt=0;lastVoiceQuestion='';lastVoiceQuestionAt=0;previousAgentId=null;multiAgentEnabled=true;selectionOnly=false;midasConnected=false;midasShared=false;includeMidasInQueries=false;contextId='ctx';lastTrace=[];agents=[];error='';
 sayVoice(s){this.said.push(s);this.scheduleVoice();} scheduleVoice(){this.schedules++;} stopHandsFree(){this.handsFree=false;this.voicePending='';}
 readReply(t){this.voicePlaybackAttempt++;this.said.push(t.content);} stopReadback(){} scroll(){} stamp(){return 'now';}
 get context(){return {conversationHistory:this.history.slice(-12),userContext:'',systemInstructions:'',taskContext:''};}
 isDatabaseQuery(q){return isDatabaseRetrievalRequest(q);} enrichedAgentQuery(q){return q;}
 async sendDatabaseQuery(message){this.calls.push({path:'db',body:{message,database:this.databaseSchema}});this.busy=false;}
 async post(path,body){this.calls.push({path,body});if(path==='/api/ollama/chat')return {text:'Life is a journey.'};if(path==='/api/orchestration/execute')return {answer:'Specialized result.',trace:[],complete:true};throw Error('unexpected endpoint '+path);}
 ${voiceMethods}
 ${sendMethod}
}`;
const {Harness}=await import('data:text/javascript;base64,'+Buffer.from(stripTypeScriptTypes(harness)).toString('base64'));
test('test conversation and ordinary questions route to local conversational assistant',()=>{for(const q of ['Start talking to me. Anything','Speak to me again','What do you think about life?','Tell me about friendship','How are you?','What is love?'])assert.equal(naturalVoiceRoute(q,null),true,q);});
test('specialized tasks and arithmetic do not take conversational shortcut',()=>{for(const q of ['Select all records from table contxt_oi_assoc','Translate hello into French','Roll two dice','What is 2 + 2?','Explain the MIDAS dashboard','Tell me the database schema','Create a social media post','What is the average of the records?','Tell me how to navigate to the dashboard'])assert.equal(naturalVoiceRoute(q,'local-ollama'),false,q);});
test('conversational continuation remains local only after a local response',()=>{assert.equal(naturalVoiceRoute('I think each step is a person','local-ollama'),true);assert.equal(naturalVoiceRoute('I think each step is a person',null),false);});
test('actual voice dispatch takes local path and supplies prior conversation only once',async()=>{const v=new Harness();await v.handleVoiceCommand('What do you think about life?');await v.handleVoiceCommand('I think each step is a person');assert.deepEqual(v.calls.map(c=>c.path),['/api/ollama/chat','/api/ollama/chat']);assert.equal(v.calls[1].body.conversationMode,'natural');assert.equal(v.calls[1].body.context.conversationHistory.length,2);assert.equal(v.calls[1].body.context.conversationHistory[0].content,'What do you think about life?');assert.equal(v.history.length,4);assert.match(v.lastRoute,/direct natural conversation/);});
test('actual voice dispatch preserves DBAgent and specialist paths',async()=>{const v=new Harness();await v.handleVoiceCommand('Select all records from table contxt_oi_assoc');await v.handleVoiceCommand('Translate hello into French');assert.deepEqual(v.calls.map(c=>c.path),['db','/api/orchestration/execute']);assert.equal(v.calls[0].body.database,'a');});
test('typed workflow and disabled natural mode retain orchestration',async()=>{for(const opts of [{handsFree:false},{voiceNaturalConversation:false}]){const v=Object.assign(new Harness(),opts);v.prompt='What do you think about life?';await v.send();assert.equal(v.calls[0].path,'/api/orchestration/execute');}});
test('natural message builder preserves conversation, avoids duplicate input and excludes tool context',()=>{const messages=naturalVoiceMessages('Go on',{taskContext:'PRIVATE MIDAS SNAPSHOT',conversationHistory:[{role:'user',content:'Life?'},{role:'assistant',content:'A journey.'},{role:'user',content:'Go on'}]});assert.equal(messages.filter(m=>m.content==='Go on').length,1);assert.match(messages[0].content,/1–3 sentences/);assert.match(messages[0].content,/metaphors/);assert.doesNotMatch(JSON.stringify(messages),/PRIVATE MIDAS SNAPSHOT/);assert.equal(messages[2].content,'A journey.');});
test('wake prefix handles punctuation and is anchored',()=>{assert.equal(stripVoiceWake('Hey, Chatbot, what is life?'),'what is life?');assert.equal(stripVoiceWake('Hey AI chat bot, Send.'),'Send.');assert.equal(stripVoiceWake('Say hey chatbot to start'),null);});
test('wake mode discards unrelated speech and requires addressed confirmation',async()=>{const v=new Harness();v.voiceWakeRequired=true;v.voiceAutoSubmit=false;await v.handleVoiceCommand('Someone else is talking');assert.equal(v.voicePending,'');await v.handleVoiceCommand('Hey Chatbot, what is life?');assert.equal(v.voicePending,'what is life?');await v.handleVoiceCommand('Send');assert.equal(v.calls.length,0);await v.handleVoiceCommand('Hey Chatbot, Send');assert.equal(v.calls.length,1);await v.handleVoiceCommand('Stop listening');assert.equal(v.handsFree,false);});
test('external confirmation chatter cannot submit a question',async()=>{const v=new Harness();v.voiceAutoSubmit=false;await v.handleVoiceCommand('What is life?');for(const q of ['I heard, something else. Say send to submit, cancel to discard','You can say send to submit or cancel to discard','Say send to submit, cancel to discard, or restate your question']){assert.ok(voiceNoise(q),q);assert.equal(confirmationCommand(q),null);await v.handleVoiceCommand(q);}assert.equal(v.calls.length,0);assert.equal(v.voicePending,'What is life?');await v.handleVoiceCommand('Send.');assert.equal(v.calls.length,1);});
test('new settings are visible and server uses dedicated prompt only for voice conversation',()=>{assert.match(html,/Natural conversation<\/mat-checkbox>/);assert.match(html,/Require Hey Chatbot<\/mat-checkbox>/);assert.match(server,/conversationMode==='natural'&&voiceProfile\?naturalVoiceMessages/);assert.match(source,/voiceQuietUntil=Date.now\(\)\+1800/);assert.match(source,/getUserMedia\(\{audio:\{echoCancellation:true,noiseSuppression:true/);});

test('V7.1.1: reported media caption and application error speech never dispatch',async()=>{
 const v=new Harness();for(const caption of ['(video plays)','[Video playing.]','(audio starts)','[audience cheering]','Request failed. Please review the error or try again.','Database request failed. Please review the error or try a different question.','The local conversational assistant is unavailable. Please try again.']){assert.ok(voiceNoise(caption),caption);await v.handleVoiceCommand(caption);}assert.equal(v.calls.length,0);assert.equal(v.history.length,0);assert.equal(v.voicePending,'');
});
test('V7.1.1: media questions remain valid and pending question survives noise',async()=>{
 const v=new Harness();v.voiceAutoSubmit=false;await v.handleVoiceCommand('What is life?');await v.handleVoiceCommand('(video plays)');assert.equal(v.voicePending,'What is life?');assert.equal(v.calls.length,0);await v.handleVoiceCommand('Send');assert.equal(v.calls.length,1);assert.equal(voiceNoise('Why does the video play?'),false);assert.equal(voiceNoise('Explain why the request failed'),false);
});
test('V7.1.1: bare Stop exits hands-free even with wake mode enabled',async()=>{const v=new Harness();v.voiceWakeRequired=true;v.voiceAutoSubmit=false;await v.handleVoiceCommand('Hey Chatbot, what is life?');await v.handleVoiceCommand('Stop.');assert.equal(v.handsFree,false);assert.equal(v.voicePending,'');assert.equal(v.calls.length,0);assert.equal(confirmationCommand('Stop the video'),null);});
test('V7.1.1: actual single-agent voice dispatch prevents automatic DBAgent guess',async()=>{
 const v=new Harness();v.multiAgentEnabled=false;v.agents=[{id:'DBAgent',name:'DBAgent',type:'aicore'}];v.post=async function(path,body){this.calls.push({path,body});if(path==='/api/router/select')return {agent:{id:'DBAgent',type:'aicore'}};throw Error('unexpected execution');};await v.handleVoiceCommand('A random phrase');assert.deepEqual(v.calls.map(c=>c.path),['/api/router/select']);assert.match(v.history.at(-1).content,/specify the table/);assert.equal(v.databaseSchema,'a');
 await v.handleVoiceCommand('Select all records from table contxt_oi_assoc');assert.equal(v.calls.at(-1).path,'db');
});
test('V7.1.1: automatic voice chain catalog excludes DBAgent only after explicit database route',()=>{const start=server.indexOf("if(isDatabaseRetrievalRequest(message)) {");const filter=server.indexOf('const available=voiceProfile?discovered.filter(a=>!isDatabaseAgent(a)):discovered;');assert.ok(start>=0&&filter>start);assert.match(server.slice(start,filter),/agentId:'DBAgent'/);});
