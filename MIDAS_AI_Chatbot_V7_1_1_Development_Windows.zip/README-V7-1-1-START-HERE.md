# MIDAS AI Chatbot V7.1.1 — Voice feedback and routing stabilization

Based on the complete V7.1.0 development package. Stop the previous version, extract this release into a new directory, and run START-V7-ISOLATED-WINDOWS.bat. No separate patch. Use the same authorized database configuration and existing local dependencies.

## Fixes
- Ignore the exact reported `(video plays)` caption and related media/noise captions, and known spoken application error messages, before they can be submitted. Ordinary questions about media/errors remain valid.
- If the automatic single-agent voice router guesses DBAgent without recognized retrieval intent, ask for clarification instead of executing. The automatic voice chain excludes DBAgent for non-retrieval requests. Explicit retrieval and manually selected agents retain their existing path. Ambiguous implicit database requests now require explicit table/record wording or manual agent selection. Typed routing is unchanged.
- Standalone `Stop` joins `Stop listening` and `Exit hands-free` as a voice stop command; this does not abort a database request already in flight.
- Preserve existing SQL generator, database selection, Whisper fallback, MIDAS approval and video sources.

## Live acceptance
Start with auto-submit OFF, Natural conversation ON, Require Hey Chatbot ON in shared/noisy spaces. Speak `Hey Chatbot, how are you?`, then `Hey Chatbot, send`. Confirm reply and resumption. Try media noise, `Request failed. Please review the error or try again`, and confirm no extra session turn. Say `Hey Chatbot, select all records from table contxt_oi_assoc`, then `Hey Chatbot, send`, and verify the selected schema and read-only result. Say `Stop` and verify Hands-free mode off. Test auto-submit separately in a quiet environment.

## Verification limitations
128 automated source tests passed (123 existing plus 5 new); includes mocked actual component methods and a static chain-catalog assertion. Strict helper type check and TypeScript transpile syntax checks passed. Full Angular build, live microphone, actual backend requests and one-hour endurance testing remain unverified. Noise filtering is not speaker identification; wake phrase and headphones mitigate other speakers. This does not guarantee rejection of every possible hallucinated caption.
