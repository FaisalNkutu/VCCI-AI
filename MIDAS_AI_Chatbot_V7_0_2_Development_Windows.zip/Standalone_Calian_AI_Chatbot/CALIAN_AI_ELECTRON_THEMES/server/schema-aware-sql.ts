/**
 * CALIAN-owned automatic MariaDB/MySQL schema discovery and speech-name matching.
 * The REQA and Fouad images are not modified. Metadata and final SELECT requests
 * use the SAME existing read-only execute_sql bridge as literal SQL.
 *
 * Supports any accessible table in the CURRENT database, not arbitrary servers.
 * Requires information_schema visibility and Docker's existing reqa-api bridge.
 */
import {compileReadOnlyPlan} from './db-natural-language';

export type DbRows = {success:boolean;rows:unknown[];error:string};
export type ExecuteSql = (sql:string)=>Promise<DbRows>;
export type PlanMaker = (question:string,table:string,columns:string[])=>Promise<unknown>;
export type Translation = {sql:string;method:'schema-count'|'schema-list'|'schema-ollama-plan';table:string;matchScore:number;catalogSize:number};

const VALID_NAME=/^[A-Za-z_][A-Za-z_0-9]{0,127}$/;
const DANGEROUS= /\b(?:delete|drop|truncate|insert|update|alter|replace|grant|revoke|erase|remove|overwrite|create|execute|call|shutdown)\b/i;
const cached=new Map<string,{time:number;tables:string[]}>();
const CACHE_MS=120000;
const PAGE=1000;
const MAX_TABLES=5000;
const MAX_LIMIT=100;
function quoteTable(name:string):string {
 const parts=name.split('.');
 if(parts.length<1||parts.length>2)return identifier(name); // identifier() fails closed
 return parts.map(identifier).join('.');
}

function identifier(name:string):string {
 if(!VALID_NAME.test(name))throw new Error(`Unsupported database identifier: ${name}`);
 return '`'+name+'`';
}
function getField(row:unknown, field:string):unknown {
 if(!row||typeof row!=='object'||Array.isArray(row))return undefined;
 const obj=row as Record<string,unknown>;
 const key=Object.keys(obj).find(k=>k.toLowerCase()===field.toLowerCase());
 return key?obj[key]:undefined;
}
function requireRows(value:DbRows,description:string):unknown[]{
 if(!value.success)throw new Error(`${description} failed: ${value.error||'Database rejected the query'}`);
 if(!Array.isArray(value.rows))throw new Error(`${description} returned invalid rows`);
 return value.rows;
}
/** Detect the default database for the SAME connection used by execute_sql.
 * The user's deliberate CALIAN_SCHEMA_DATABASE selection takes precedence.
 * If no default can be determined, stay conservative and surface ambiguity.
 */
export async function currentDatabase(execute:ExecuteSql,preferredDatabase?:string):Promise<string|null>{
 const configured=(preferredDatabase ?? process.env.CALIAN_SCHEMA_DATABASE ?? '').trim();
 if(configured){
  if(!VALID_NAME.test(configured))throw new Error('CALIAN_SCHEMA_DATABASE must be a safe database identifier');
  return configured;
 }
 try{
  const response=await execute('SELECT DATABASE() AS current_database;');
  if(response.success && Array.isArray(response.rows) && response.rows.length){
   const value=getField(response.rows[0],'current_database');
   if(typeof value==='string' && VALID_NAME.test(value))return value;
  }
 }catch{/* The read-only MCP may disallow DATABASE(); do not guess. */}
 return null;
}
/** Cache by connection + selected database. A changed default cannot reuse stale metadata. */
export async function discoverTables(execute:ExecuteSql,cacheKey='default',fresh=false,preferredDatabase?:string):Promise<string[]> {
 const selected=await currentDatabase(execute,preferredDatabase);
 const scopedCacheKey=cacheKey+'::'+(selected||'<unselected>');
 const hit=cached.get(scopedCacheKey);
 if(!fresh&&hit&&hit.time>Date.now())return [...hit.tables];
 const names=new Map<string,string>();
 for(let offset=0;offset<MAX_TABLES;offset+=PAGE){
  // The default database is not always unique among the user's permitted schemas.
  // Never choose another schema just because it has the same table name.
  const where=selected ? `TABLE_SCHEMA = '${selected}'` : "TABLE_SCHEMA NOT IN ('mysql','sys','information_schema','performance_schema')";
  const sql=`SELECT TABLE_SCHEMA AS schema_name, TABLE_NAME AS table_name FROM INFORMATION_SCHEMA.TABLES WHERE ${where} ORDER BY TABLE_SCHEMA, TABLE_NAME LIMIT ${PAGE} OFFSET ${offset};`;
  const rows=requireRows(await execute(sql),'Database schema discovery');
  for(const r of rows){
   const name=getField(r,'table_name');
   const schema=getField(r,'schema_name');
   if(typeof schema==='string'&&VALID_NAME.test(schema)&&typeof name==='string'&&VALID_NAME.test(name)){
    const full=`${schema}.${name}`;names.set(full.toLowerCase(),full);
   }
  }
  if(rows.length<PAGE)break;
 }
 if(!names.size)throw new Error(selected
  ? `No readable tables were found in the selected database '${selected}'. Check that CALIAN uses the same connection and database as your SQL client.`
  : 'No readable tables were found in accessible database metadata. Check the SQL connection and metadata permissions.');
 const tables=[...names.values()].sort();
 cached.set(scopedCacheKey,{time:Date.now()+CACHE_MS,tables});
 return tables;
}
export function clearSchemaCache(){cached.clear();}
const noise=new Set(['the','a','an','my','our','this','that','table','tables','database','records','record','rows','row','entries','entry','of','from','in','within','with','for','by','show','me','give','list','display','fetch','retrieve','first','top','latest','last','please','how','many','are','there','is','all','some','count','number','total','and','on','ten','five','two','one','three','four','six','seven','eight','nine','twenty','thirty','forty','fifty','hundred']);
// Generic linguistic abbreviations, not table-specific mappings or a fixed catalog.
const abbreviations:Record<string,string>={
 context:'contxt',contexts:'contxt',contxt:'contxt',
 association:'assoc',associated:'assoc',associations:'assoc',associate:'assoc',associates:'assoc',assoc:'assoc',
 organisation:'org',organization:'org',organisations:'org',organizations:'org',org:'org',
 information:'info',info:'info',identifier:'id',identification:'id',
 transaction:'txn',transactions:'txn',txn:'txn',
 reference:'ref',ref:'ref',configuration:'config',config:'config'
};
/** Spoken separators such as "underscore" are pronunciation cues, NOT literal
 * table-name components. Apply this normalization to user speech only; catalog
 * identifiers are preserved so that real tables named *_underscore_* still work.
 */
function chunks(raw:string,spoken=false):string[]{
 const words=(raw.toLowerCase().replace(/[`"']/g,' ').replace(/[._/-]/g,' ').match(/[a-z0-9]+/g)||[])
 .filter(t=>!noise.has(t));
 const cleaned:string[]=[];
 for(let i=0;i<words.length;i++){
  if(spoken){
   if(words[i]==='underscore'){continue;}
   if(words[i]==='under'&&words[i+1]==='score'){i++;continue;}
  }
  cleaned.push(words[i]);
 }
 const merged:string[]=[];
 for(let i=0;i<cleaned.length;i++){
  if(cleaned[i].length===1&&/^[a-z]$/.test(cleaned[i])){
   let w=cleaned[i];while(i+1<cleaned.length&&cleaned[i+1].length===1&&/^[a-z]$/.test(cleaned[i+1]))w+=cleaned[++i];
   merged.push(w);
  }else merged.push(cleaned[i]);
 }
 return merged.map(t=>abbreviations[t]||t);
}
function dice(a:string,b:string):number{
 if(a===b)return 1;
 if(a.length<2||b.length<2)return 0;
 const pairs=(s:string)=>{const bag=new Map<string,number>();for(let i=0;i<s.length-1;i++){const pair=s.slice(i,i+2);bag.set(pair,(bag.get(pair)||0)+1);}return bag;};
 const x=pairs(a),y=pairs(b);let hits=0;
 for(const [pair,count] of x)hits+=Math.min(count,y.get(pair)||0);
 return 2*hits/(a.length+b.length-2);
}
function matchingPhrase(question:string):string{
 // A named database table normally follows from/in/of/table. Avoid adding other
 // English instructions to the identifier comparison.
 const matches=[
  // Prefer locative phrases to "number OF records", which is not a table name.
  ...question.matchAll(/\b(?:from|within|in)\s+(?:the\s+)?(?:table\s+)?([^?.;]{2,120})/gi),
  ...question.matchAll(/\btable\s+(?:called\s+|named\s+)?([^?.;]{2,120})/gi),
  ...question.matchAll(/\bof\s+(?:the\s+)?(?:table\s+)?([^?.;]{2,120})/gi)
 ];
 for(const match of matches){
  let phrase=match[1].split(/\b(?:where|whose|which|with|having|ordered|sorted|limited|limit|containing|that)\b/i)[0];
  phrase=phrase.replace(/\s+(?:tables?|database)\b.*$/i,'').trim();
  if(phrase&&chunks(phrase,true).length)return phrase;
 }
 return question;
}
export type TableMatch={name:string;score:number;alternatives:string[]};
/**
 * Canonical form used only to resolve English/spoken table names. Generic
 * abbreviations are applied to the names discovered through metadata: there
 * are no table-specific mappings. Literal SQL never uses this resolver.
 */
function canonicalTableName(value:string,spoken=false):string {return chunks(value,spoken).join('_');}

/** A one-character insertion, deletion or substitution (e.g. oi -> ol).
 * This bound is deliberately strict: never guess a distant table name.
 */
function oneEditApart(a:string,b:string):boolean {
 if(Math.abs(a.length-b.length)>1||a===b)return false;
 let i=0,j=0,edits=0;
 while(i<a.length&&j<b.length){
  if(a[i]===b[j]){i++;j++;continue;}
  if(++edits>1)return false;
  if(a.length>b.length)i++;
  else if(b.length>a.length)j++;
  else{i++;j++;}
 }
 return edits+(a.length-i)+(b.length-j)===1;
}
function disambiguateTarget(target:string,candidates:string[],reason:string):never {
 throw new Error(`${reason} '${target}': ${candidates.slice(0,8).join(', ')}. Specify database.table or configure CALIAN_SCHEMA_DATABASE in calian.env. No SQL was executed.`);
}
export function resolveTable(question:string,tables:string[]):TableMatch{
 if(!tables.length)throw new Error('The schema catalog is empty');
 const explicit=(question.match(/[`"]([a-z_][a-z_0-9]+)[`"]|\b([a-z_][a-z_0-9]*_[a-z_0-9]+)\b/i)||[]);
 const namedSchema=question.match(/\b([a-z_][a-z_0-9]*)\.([a-z_][a-z_0-9]*)\b/i);
 const target=(namedSchema?`${namedSchema[1]}.${namedSchema[2]}`:explicit[1]||explicit[2]||'').toLowerCase();
 if(target){
  // Never silently redirect an explicitly qualified database.table name.
  const exact=tables.filter(t=>t.toLowerCase()===target||(!target.includes('.')&&t.split('.').pop()?.toLowerCase()===target));
  if(exact.length===1)return {name:exact[0],score:1,alternatives:[]};
  if(exact.length>1)disambiguateTarget(target,exact,'Several accessible databases contain table');
  if(target.includes('.'))throw new Error(`Table '${target}' does not exist in the selected database metadata. No SQL was executed.`);

  // A transcription often says "context_ol_assoc" for "contxt_oi_assoc".
  // Resolve only against LIVE database metadata, never a hardcoded alias.
  const normalized=canonicalTableName(target,true);
  const canonicalMatches=tables.filter(t=>canonicalTableName(t.split('.').pop()||t)===normalized);
  if(canonicalMatches.length===1)return {name:canonicalMatches[0],score:0.99,alternatives:[]};
  if(canonicalMatches.length>1)disambiguateTarget(target,canonicalMatches,'Several accessible tables match the normalized name');
  const nearMatches=normalized.length>=8?tables.filter(t=>oneEditApart(normalized,canonicalTableName(t.split('.').pop()||t))):[];
  if(nearMatches.length===1)return {name:nearMatches[0],score:0.94,alternatives:[]};
  if(nearMatches.length>1)disambiguateTarget(target,nearMatches,'The spoken table name could refer to several tables');
  throw new Error(`Table '${target}' was not found in accessible database metadata. No similarly named verified table was found; no SQL was executed.`);
 }
 const phrase=matchingPhrase(question);
 const tokens=chunks(phrase,true);
 if(!tokens.length)throw new Error('No table name was recognized. Say, for example, “show ten records from the context O I association table.”');
 // A fully normalized spoken name is more reliable than fuzzy similarity,
 // particularly when a database has many context/association tables.  Require
 // uniqueness against LIVE schema metadata before producing executable SQL.
 const normalizedSpoken=tokens.join('_');
 const exactCanonical=tables.filter(t=>canonicalTableName(t.split('.').pop()||t)===normalizedSpoken);
 if(exactCanonical.length===1)return {name:exactCanonical[0],score:0.99,alternatives:[]};
 if(exactCanonical.length>1)disambiguateTarget(normalizedSpoken,exactCanonical,'Several accessible tables match spoken name');
 const nearCanonical=normalizedSpoken.length>=8
  ? tables.filter(t=>oneEditApart(normalizedSpoken,canonicalTableName(t.split('.').pop()||t))) : [];
 if(nearCanonical.length===1)return {name:nearCanonical[0],score:0.94,alternatives:[]};
 if(nearCanonical.length>1)disambiguateTarget(normalizedSpoken,nearCanonical,'Spoken table name is ambiguous');
 const joined=tokens.join('');
 const ranked=tables.map(t=>{
  const ts=chunks(t.split('.').pop()||t);const tj=ts.join('');
  const intersect=ts.filter(w=>tokens.includes(w)).length;
  const containment=intersect/Math.max(ts.length,tokens.length);
  const sim=joined===tj?1:0.60*dice(joined,tj)+0.40*containment;
  return {name:t,score:sim};
 }).sort((a,b)=>b.score-a.score||a.name.localeCompare(b.name));
 const best=ranked[0],second=ranked[1];
 if(best.score<0.70||(second&&best.score-second.score<0.13)){
  const suggestions=ranked.slice(0,3).map(r=>r.name).join(', ');
  throw new Error(`Could not uniquely match spoken table name '${phrase.trim()}' to the current database. Closest tables: ${suggestions}. Please clarify; no SQL was executed.`);
 }
 return {name:best.name,score:best.score,alternatives:ranked.slice(1,4).map(r=>r.name)};
}

const namedNumbers:Record<string,string>={one:'1',two:'2',three:'3',four:'4',five:'5',six:'6',seven:'7',eight:'8',nine:'9',ten:'10',eleven:'11',twelve:'12',fifteen:'15',twenty:'20',thirty:'30',forty:'40',fifty:'50',hundred:'100'};
export function recognizeNumberWords(text:string):string{
 return text.replace(/\b(one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|fifteen|twenty|thirty|forty|fifty|hundred)\b/gi,w=>namedNumbers[w.toLowerCase()]||w);
}
/** Remove only phrases that bound the NUMBER of returned rows. A request for
 * the maximum VALUE of a column must still use schema-aware planning. */
export function normalizeRowLimitPhrases(question:string):string{
 return question
  .replace(/\b(?:a\s+)?(?:maximum|max)\s+(?:of\s+)?(?=\d{1,4}\s+(?:records?|rows?|entries?|items?)\b)/gi,'')
  .replace(/\b(?:up\s+to|at\s+most|no\s+more\s+than|not\s+more\s+than|only|just)\s+(?=\d{1,4}\s+(?:records?|rows?|entries?|items?)\b)/gi,'')
  .replace(/\b(\d{1,4}\s+(?:records?|rows?|entries?|items?))\s+only\b/gi,'$1');
}
function rowLimit(question:string):number{
 const match=question.match(/\b(?:show|list|fetch|display|give me|first|top|retrieve|select)\s+(?:me\s+)?(?:the\s+)?(\d{1,4})\b/i)
  ||question.match(/\b(\d{1,4})\s+(?:records?|rows?|entries?|items?)\b/i)
  ||question.match(/\b(?:limit\s+(?:to\s+)?)(\d{1,4})\b/i);
 return match?Math.max(1,Math.min(MAX_LIMIT,Number(match[1]))):20;
}
function isCount(q:string):boolean{return /\b(?:how many|count|number of|total number of)\b/i.test(q) && /\b(?:records?|rows?|entries?|items?)\b/i.test(q);}
function isList(q:string):boolean{return /\b(?:show|list|display|fetch|retrieve|give me|select)\b/i.test(q)&&/\b(?:records?|rows?|entries?|items?)\b/i.test(q);}
function hasConditions(q:string):boolean{return /\b(?:where|whose|having|matching|filter|group|per|by|for each|only|distinct|unique|latest|newest|oldest|last|with|without|sorted|ordered|average|sum|minimum|maximum)\b/i.test(q);}
async function tableColumns(execute:ExecuteSql,table:string):Promise<string[]>{
 const [schema,name]=table.split('.');
 if(!schema||!name)throw new Error('Schema-qualified table name required');
 identifier(schema);identifier(name);
 // Both names were returned from information_schema and restricted to safe identifiers.
 const sql=`SELECT COLUMN_NAME AS column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '${schema}' AND TABLE_NAME = '${name}' ORDER BY ORDINAL_POSITION LIMIT 1000;`;
 const rows=requireRows(await execute(sql),'Column metadata discovery');
 return [...new Set(rows.map(r=>getField(r,'column_name')).filter((x):x is string=>typeof x==='string'&&VALID_NAME.test(x)))];
}
/** Default: deterministic, verified, read-only queries; Ollama receives actual column names. */
export async function schemaAwareTranslate(question:string,execute:ExecuteSql,planMaker:PlanMaker,cacheKey='default',preferredDatabase?:string):Promise<Translation>{
 if(!question.trim()||question.length>4000)throw new Error('Database question must be 1–4000 characters');
 if(DANGEROUS.test(question))throw new Error('This assistant generates read-only SQL only. Database changes are blocked.');
 const catalog=await discoverTables(execute,cacheKey,false,preferredDatabase);
 let match:TableMatch;
 try{match=resolveTable(question,catalog);}
 catch(e){
  // A database model could have changed since the last request. Refresh once.
  if(catalog.length){
   const updated=await discoverTables(execute,cacheKey,true,preferredDatabase);
   match=resolveTable(question,updated);
  }else throw e;
 }
 const table=quoteTable(match.name);
 const normalized=normalizeRowLimitPhrases(recognizeNumberWords(question));
 if(isCount(normalized)&&!hasConditions(normalized)){
  return {sql:`SELECT COUNT(*) AS total_records FROM ${table};`,method:'schema-count',table:match.name,matchScore:match.score,catalogSize:catalog.length};
 }
 if(isList(normalized)&&!hasConditions(normalized)){
  return {sql:`SELECT * FROM ${table} LIMIT ${rowLimit(normalized)};`,method:'schema-list',table:match.name,matchScore:match.score,catalogSize:catalog.length};
 }
 const columns=await tableColumns(execute,match.name);
 if(!columns.length)throw new Error(`No columns could be discovered for ${match.name}. No speculative SQL was run.`);
 const plan=await planMaker(normalized,match.name,columns);
 return {sql:compileReadOnlyPlan(plan,match.name,columns),method:'schema-ollama-plan',table:match.name,matchScore:match.score,catalogSize:catalog.length};
}
