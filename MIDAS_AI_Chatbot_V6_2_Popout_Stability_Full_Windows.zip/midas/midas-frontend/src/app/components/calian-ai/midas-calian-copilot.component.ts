import { Component, ElementRef, OnDestroy, OnInit, ViewChild, inject, signal } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { NavigationEnd, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Subscription, filter } from 'rxjs';
import { APP_PREF_KEY } from '@/app.guard';
import { sidebarActions } from '@/store/actions/sidebar.actions';
import { cpActions } from '@/store/actions/cp.actions';
import { romActions } from '@/store/actions/rom.actions';
import { cmActions } from '@/store/actions/cm.actions';
import { selectMinMaxTime, selectSelectedTimeFormat, selectTimeFormatNames, selectConnectedDB } from '@/store/features/sidebar.feature';
import { selectCpEntities, selectCpSelectedEntityIds, selectCpTimeframe, selectCombatPowerDataGrouping, selectCpChartData } from '@/store/features/cp.feature';
import { selectSummaryState } from '@/store/features/summary.feature';
import { selectAllRomSpecs } from '@/store/features/rom.feature';
import { selectControlMeasures, selectSelectedControlMeasureIds } from '@/store/features/cm.feature';
import { routes as dashboardRoutes } from '@/utils/routes';
import { MidasCopilotUiState } from './midas-copilot-ui-state';
import { MIDAS_ACTION_CATALOGUE, MIDAS_DASHBOARDS, MIDAS_READ_TOOLS, ReadTool, ToolPayload, seriesStats } from './midas-tool-gateway';

const BRIDGE = 'MIDAS_CALIAN_V1';
const dashboards: Record<string, string> = {
  summary: dashboardRoutes.SUM.route,
  'h-hour': dashboardRoutes.HH.route,
  rom: dashboardRoutes.ROM.route,
  poe: dashboardRoutes.POE.route,
  cm: dashboardRoutes.CM.route,
  fratricide: dashboardRoutes.FRAT.route,
  'enemy-engagement': dashboardRoutes.ENG.route,
  cp: dashboardRoutes.CP.route,
  'unit-watch': dashboardRoutes.UW.route,
  'holdings-rollup': dashboardRoutes.HR.route,
  c2: 'c2',
};

type ActionName = 'navigate' | 'time_format' | 'cp_time_range' | 'cp_select_entity' | 'cp_grouping' | 'rom_time_range' | 'cm_time_range' | 'rom_select_capture' | 'cm_select_measure';
interface ActionRequest {
  action: ActionName;
  params: Record<string, unknown>;
}
type BridgeEndpoint = 'frame' | 'popup';
interface PendingRequest { id: string; request: ActionRequest; description: string; source: BridgeEndpoint; }
interface SessionHandoff { id: string; from: BridgeEndpoint; to: BridgeEndpoint; snapshot?: unknown; }


function configuredUrl(): string | null {
  const value = (window as Window & { __MIDAS_CALIAN_EMBED_URL__?: string }).__MIDAS_CALIAN_EMBED_URL__;
  if (typeof value !== 'string' || !value.trim()) return null;
  try {
    const u = new URL(value);
    const local = u.hostname === 'localhost' || u.hostname === '127.0.0.1';
    if (!(u.protocol === 'https:' || (local && u.protocol === 'http:'))) return null;
    if (u.username || u.password || u.hash || u.search) return null;
    return u.href;
  } catch { return null; }
}

@Component({
  selector: 'app-midas-calian-copilot',
  standalone: true,
  styles: [`
    :host { display: contents; }
    .midas-copilot { position:relative; display:flex; flex-direction:column; flex:0 0 auto; width:540px; min-width:350px; max-width:92vw; height:100%; color:#f4f8fc; background:#0c182a; border-left:1px solid #334155; }
    .midas-copilot.maximized { width:100%; max-width:none; min-width:0; }
    .midas-copilot.closed { display:none; }
    .popout-dock { position:fixed; bottom:18px; right:18px; z-index:100; background:#17263c; color:#f4f8fc; border:1px solid #64748b; border-radius:10px; box-shadow:0 8px 30px #0008; padding:12px; max-width:min(450px,94vw); display:flex; flex-wrap:wrap; gap:8px; align-items:center; font-size:13px; }
    .popout-dock button, .popout-approval button { border:1px solid #64748b; color:white; background:#243751; padding:5px 9px; border-radius:5px; cursor:pointer; }
    .popout-dock label { width:100%; }
    .popout-approval { position:fixed; z-index:120; bottom:125px; right:18px; max-width:min(460px,95vw); background:#3a2b19; color:white; padding:14px; border:2px solid #f59e0b; border-radius:8px; box-shadow:0 7px 26px #0008; font-size:14px; }
    .popout-approval p { overflow-wrap:anywhere; }
    .popout-approval button { margin-right:8px; }
    .popout-approval .accept { background:#115e59; }
    .popout-dock button:focus-visible, .popout-approval button:focus-visible { outline:3px solid #38bdf8; }
    .popout-note { font-size:12px; color:#fef3c7; width:100%; }

    .copilot-frame { width:100%; flex:1; min-height:0; border:0; background:#0c182a; }
    .copilot-toolbar { display:flex; align-items:center; gap:9px; padding:8px 12px; background:#17263c; flex-wrap:wrap; font-size:13px; }
    .copilot-resize-bar { display:flex; flex-wrap:wrap; align-items:center; gap:8px; padding:9px 12px; background:#0d4163; color:#ffffff; border-top:1px solid #25658b; border-bottom:2px solid #38bdf8; font-size:13px; }
    .copilot-resize-bar strong { white-space:nowrap; }
    .copilot-resize-bar label { display:flex; align-items:center; flex:1 1 165px; gap:7px; min-width:150px; }
    .copilot-resize-bar input[type=range] { flex:1; min-width:96px; max-width:260px; height:22px; accent-color:#7dd3fc; cursor:ew-resize; }
    .copilot-resize-bar button { color:#fff; border:1px solid #7dd3fc; background:#164b70; border-radius:6px; padding:5px 8px; cursor:pointer; font-weight:600; }
    .copilot-resize-bar button:focus-visible, .copilot-resize-grip:focus-visible { outline:3px solid #fbbf24; outline-offset:2px; }
    .copilot-resize-bar .resize-value { min-width:60px; text-align:center; font-variant-numeric:tabular-nums; font-weight:700; }
    .copilot-resize-grip { position:absolute; z-index:8; left:-9px; top:37%; width:18px; height:108px; display:flex; align-items:center; justify-content:center; background:#0369a1; color:white; border:2px solid #7dd3fc; border-radius:8px; cursor:col-resize; touch-action:none; user-select:none; box-shadow:0 3px 12px #0008; }
    .copilot-resize-grip:hover { background:#0284c7; }
    .copilot-resize-grip span { writing-mode:vertical-rl; letter-spacing:3px; }
    @media (max-width:900px) { .copilot-resize-grip { display:none; } .copilot-resize-bar .resize-mobile-note { display:inline; } }
    @media (min-width:901px) { .copilot-resize-bar .resize-mobile-note { display:none; } }
    .copilot-toolbar button, .copilot-confirm button { border:1px solid #64748b; color:white; border-radius:5px; padding:5px 9px; background:#243751; cursor:pointer; }
    .copilot-toolbar button:focus-visible, .copilot-confirm button:focus-visible { outline:3px solid #38bdf8; }
    .copilot-confirm { padding:12px; border-bottom:1px solid #f59e0b; background:#3a2b19; font-size:13px; }
    .copilot-confirm p { margin:5px 0 10px; overflow-wrap:anywhere; }
    .copilot-confirm .accept { background:#115e59; }
    .badge { font-size:11px; opacity:.85; }
    .midas-fab { position:fixed; right:18px; top:14px; z-index:60; padding:9px 14px; background:#075b94; border:1px solid #7dd3fc; color:white; border-radius:6px; box-shadow:0 3px 12px #0005; }
    @media(max-width:900px){ .midas-copilot:not(.closed) { position:fixed; inset:0; z-index:70; width:100%; min-width:0; height:100dvh; } }
  `],
  template: `
    @if (!open() && !fullPage() && !popoutActive()) {
      <button type="button" class="midas-fab" (click)="show()" aria-label="Open AI Chatbot">AI Chatbot</button>
    }
    <aside class="midas-copilot" [class.closed]="popoutActive() || (!open() && !fullPage())" [class.maximized]="fullPage()" [style.width.px]="fullPage() ? null : panelWidth()" aria-label="AI Chatbot">
      <div class="copilot-toolbar">
        <strong>AI Chatbot · MIDAS</strong>
        <span class="badge" role="status">{{connected() ? 'Bridge connected' : 'Bridge disconnected'}}</span>
        <label title="Share only the current dashboard and control state with AI Chatbot agents">
          <input type="checkbox" [checked]="shareContext()" (change)="toggleSharing($event)" /> Share dashboard context
        </label>
        <button type="button" (click)="toggleFull()">{{ fullPage() ? 'Side panel' : 'Expand' }}</button>
        <button type="button" (click)="popOut()" title="Open in a separate movable, resizable browser window">Pop out ↗</button>
        @if (popupNotice() && !popoutActive()) { <span class="popout-note" role="status">{{popupNotice()}}</span> }
        <button type="button" (click)="switchWorkspace()">Workspaces</button>
        <button type="button" (click)="close()" aria-label="Close AI Chatbot">Close</button>
      </div>
      @if (!fullPage()) {
        <section class="copilot-resize-bar" aria-label="Resize AI Chatbot" data-resize-version="6.1">
          <strong>↔ Resize AI Chatbot</strong>
          <button type="button" (click)="adjustWidth(-100)" aria-label="Narrower AI Chatbot">− Narrower</button>
          <label>Width
            <input type="range" aria-label="AI Chatbot width slider" min="350" max="1100" step="25" [value]="panelWidth()" (input)="resizePanel($event)" />
          </label>
          <button type="button" (click)="adjustWidth(100)" aria-label="Wider AI Chatbot">+ Wider</button>
          <button type="button" (click)="resetPanelWidth()" aria-label="Reset AI Chatbot width">Reset</button>
          <span class="resize-value" role="status">{{ panelWidth() }} px</span>
          <span class="resize-mobile-note">For a resizable separate window, use Pop out.</span>
        </section>
        <div class="copilot-resize-grip" role="separator" aria-label="Drag left or right to resize AI Chatbot" aria-orientation="vertical"
          [attr.aria-valuenow]="panelWidth()" aria-valuemin="350" aria-valuemax="1100" tabindex="0"
          title="Drag left to widen AI Chatbot. Use Left/Right arrow keys to adjust."
          (pointerdown)="beginPanelResize($event)" (keydown)="resizePanelWithKeys($event)"><span>•••</span></div>
      } @else {
        <section class="copilot-resize-bar" aria-label="AI Chatbot display mode">
          <strong>AI Chatbot is expanded.</strong>
          <button type="button" (click)="toggleFull()">Switch to side panel to resize</button>
          <span>Or use Pop out for a separately movable and resizable window.</span>
        </section>
      }
      @if (pending(); as item) {
        <section class="copilot-confirm" role="alertdialog" aria-label="Approve requested MIDAS action" aria-modal="false">
          <strong>Approve MIDAS change?</strong>
          <p>{{item.description}}</p>
          <button type="button" class="accept" (click)="approve()">Approve</button>
          <button type="button" (click)="reject()">Decline</button>
        </section>
      }
      @if (trustedUrl) {
        <iframe #frame class="copilot-frame" [src]="trustedUrl" (load)="frameLoaded()"
          title="AI Chatbot embedded application" referrerpolicy="strict-origin-when-cross-origin"
          allow="camera; microphone; fullscreen; display-capture" allowfullscreen></iframe>
      } @else {
        <p style="padding:20px">Configure an administrator-approved AI Chatbot URL in assets/calian-embed-config.js.</p>
      }
    </aside>
    @if (popoutActive()) {
      <section class="popout-dock" aria-label="AI Chatbot pop-out controls">
        <strong>AI Chatbot · Separate window</strong>
        <span class="badge" role="status">{{popoutConnected() ? 'Bridge connected' : 'Connecting…'}}</span>
        <label title="Opt in to share current MIDAS dashboard context">
          <input type="checkbox" [checked]="shareContext()" (change)="toggleSharing($event)" /> Share dashboard context
        </label>
        <button type="button" (click)="focusPopout()">Focus</button>
        <button type="button" (click)="resizePopout(900,650)">Compact</button>
        <button type="button" (click)="resizePopout(1100,800)">Standard</button>
        <button type="button" (click)="resizePopout(1400,900)">Large</button>
        <button type="button" (click)="centerPopout()">Center</button>
        <button type="button" (click)="dockPopout()">Dock in MIDAS</button>
        <span class="popout-note">The pop-out remains open if chat transfer fails. Only the browser Close control or a successful Dock will close it. Drag its title bar to move and its edges to resize.</span>
        @if (popupNotice()) { <span class="popout-note" role="status">{{popupNotice()}}</span> }
      </section>
      @if (pending(); as item) {
        <section class="popout-approval" role="alertdialog" aria-label="Approve MIDAS action from AI Chatbot pop-out" aria-modal="false">
          <strong>Approve MIDAS change?</strong><p>{{item.description}}</p>
          <button type="button" class="accept" (click)="approve()">Approve</button>
          <button type="button" (click)="reject()">Decline</button>
        </section>
      }
    }
  `
})
export class MidasCalianCopilotComponent implements OnInit, OnDestroy {
  @ViewChild('frame') frame?: ElementRef<HTMLIFrameElement>;
  private readonly store = inject(Store);
  private readonly router = inject(Router);
  private readonly sanitizer = inject(DomSanitizer);
  private readonly subscriptions = new Subscription();
  private readonly url = configuredUrl();
  private readonly targetOrigin = this.url ? new URL(this.url).origin : null;
  private readonly token = crypto.randomUUID();
  private readonly popupToken = crypto.randomUUID();
  private popupWindow: Window | null = null;
  private popupWatcher?: ReturnType<typeof setInterval>;
  private handoff?: SessionHandoff;
  private handoffTimeout?: ReturnType<typeof setTimeout>;
  private bridgeRetry?: ReturnType<typeof setInterval>;
  readonly popoutActive = signal(false);
  readonly popoutConnected = signal(false);
  readonly popupNotice = signal('');
  readonly trustedUrl: SafeResourceUrl | null = this.url ? this.sanitizer.bypassSecurityTrustResourceUrl(this.url) : null;
  private readonly uiState = inject(MidasCopilotUiState);
  readonly open = this.uiState.open;
  readonly fullPage = this.uiState.fullPage;
  readonly shareContext = signal(false); // User must opt in before any MIDAS state is shared.
  readonly connected = signal(false);
  readonly panelWidth = signal(this.loadPanelWidth());
  private panelDragOrigin: { x: number; width: number } | null = null;
  readonly pending = signal<PendingRequest | null>(null);
  private lastRoute = '';

  ngOnInit(): void {
    this.routeChanged();
    this.subscriptions.add(this.router.events.pipe(filter(e => e instanceof NavigationEnd)).subscribe(() => {
      this.routeChanged();
      this.sendContext();
    }));
    // Each NgRx selector has its own observable type. Subscribing separately
    // avoids calling subscribe() on a union of incompatible overload signatures.
    this.subscriptions.add(this.store.select(selectSelectedTimeFormat).subscribe(() => this.sendContext()));
    this.subscriptions.add(this.store.select(selectTimeFormatNames).subscribe(() => this.sendContext()));
    this.subscriptions.add(this.store.select(selectCpTimeframe).subscribe(() => this.sendContext()));
    this.subscriptions.add(this.store.select(selectCpSelectedEntityIds).subscribe(() => this.sendContext()));
    this.subscriptions.add(this.store.select(selectCpEntities).subscribe(() => this.sendContext()));
    this.subscriptions.add(this.store.select(selectConnectedDB).subscribe(() => this.sendContext()));
    this.subscriptions.add(this.store.select(selectCombatPowerDataGrouping).subscribe(() => this.sendContext()));
    window.addEventListener('message', this.onMessage);
  }
  ngOnDestroy(): void {
    this.panelPointerEnd();
    window.removeEventListener('message', this.onMessage);
    this.subscriptions.unsubscribe();
    if (this.popupWatcher) clearInterval(this.popupWatcher);
    if (this.bridgeRetry) clearInterval(this.bridgeRetry);
    if (this.handoffTimeout) clearTimeout(this.handoffTimeout);
    // A detached chat window can remain available if MIDAS is refreshed.
  }
  private routeChanged(): void {
    this.lastRoute = this.router.url.split('?')[0].split('#')[0];
    if (this.lastRoute === '/calian-ai' && !this.popoutActive()) { this.fullPage.set(true); this.open.set(true); }
    else this.fullPage.set(false);
  }
  show(): void { this.open.set(true); this.sendContext(); }
  switchWorkspace(): void {
    this.fullPage.set(false);
    this.open.set(false);
    this.shareContext.set(false);
    this.pending.set(null);
    localStorage.removeItem(APP_PREF_KEY);
    void this.router.navigateByUrl('/');
    this.sendContext();
  }
  close(): void {
    this.pending.set(null);
    this.shareContext.set(false);
    this.open.set(false);
    if (this.fullPage()) {
      this.fullPage.set(false);
      localStorage.setItem(APP_PREF_KEY, 'advmetrics');
      void this.router.navigateByUrl('/advmetrics');
    }
    this.sendContext();
  }
  toggleFull(): void {
    if (this.fullPage()) {
      this.fullPage.set(false);
      if (this.lastRoute === '/calian-ai') {
        localStorage.setItem(APP_PREF_KEY, 'advmetrics');
        void this.router.navigateByUrl('/advmetrics');
      }
    } else { this.fullPage.set(true); this.open.set(true); }
  }
  private loadPanelWidth(): number {
    try {
      const value = Number(localStorage.getItem('midas-ai-chatbot-panel-width'));
      return Number.isFinite(value) && value >= 350 && value <= 1100 ? value : 540;
    } catch { return 540; }
  }
  private setPanelWidth(value: number): void {
    const width = Math.max(350, Math.min(1100, Math.round(value / 25) * 25));
    this.panelWidth.set(width);
    try { localStorage.setItem('midas-ai-chatbot-panel-width', String(width)); } catch { /* storage may be disabled */ }
  }
  resizePanel(event: Event): void {
    this.setPanelWidth(Number((event.target as HTMLInputElement).value) || 540);
  }
  adjustWidth(delta: number): void {
    this.setPanelWidth(this.panelWidth() + delta);
  }
  resetPanelWidth(): void { this.setPanelWidth(540); }
  private readonly panelPointerMove = (event: PointerEvent): void => {
    if (this.panelDragOrigin) this.setPanelWidth(this.panelDragOrigin.width + this.panelDragOrigin.x - event.clientX);
  };
  private readonly panelPointerEnd = (): void => {
    this.panelDragOrigin = null;
    window.removeEventListener('pointermove', this.panelPointerMove);
    window.removeEventListener('pointerup', this.panelPointerEnd);
    window.removeEventListener('pointercancel', this.panelPointerEnd);
  };
  beginPanelResize(event: PointerEvent): void {
    if (event.button !== 0 || this.fullPage()) return;
    this.panelPointerEnd();
    this.panelDragOrigin = { x: event.clientX, width: this.panelWidth() };
    window.addEventListener('pointermove', this.panelPointerMove);
    window.addEventListener('pointerup', this.panelPointerEnd);
    window.addEventListener('pointercancel', this.panelPointerEnd);
    event.preventDefault();
  }
  resizePanelWithKeys(event: KeyboardEvent): void {
    if (event.key === 'ArrowLeft') { this.adjustWidth(25); event.preventDefault(); }
    else if (event.key === 'ArrowRight') { this.adjustWidth(-25); event.preventDefault(); }
  }
  toggleSharing(event: Event): void {
    this.shareContext.set((event.target as HTMLInputElement).checked);
    this.pending.set(null);
    this.sendContext();
  }
  private isVisible(): boolean { return this.open() || this.fullPage() || this.popoutActive(); }
  private postTo(endpoint: BridgeEndpoint, type: string, body: Record<string, unknown> = {}): void {
    if (!this.targetOrigin) return;
    const target = endpoint === 'frame' ? this.frame?.nativeElement.contentWindow : this.popupWindow;
    if (!target || (endpoint === 'popup' && target.closed)) return;
    target.postMessage({ bridge: BRIDGE, type, ...body, token: endpoint === 'frame' ? this.token : this.popupToken }, this.targetOrigin);
  }
  private send(type: string, body: Record<string, unknown> = {}): void {
    this.postTo('frame', type, body);
    if (this.popoutActive()) this.postTo('popup', type, body);
  }
  /** Browser popups must be opened synchronously from the user's click. */
  popOut(): void {
    if (this.popupWindow && !this.popupWindow.closed) { this.focusPopout(); return; }
    if (!this.url) { this.popupNotice.set('AI Chatbot URL not configured.'); return; }
    const left = Math.max(0, Math.round(window.screenX + 65));
    const top = Math.max(0, Math.round(window.screenY + 50));
    const features = `popup=yes,resizable=yes,scrollbars=yes,width=1100,height=800,left=${left},top=${top}`;
    const popup = window.open(this.url, `AIChatbot_${crypto.randomUUID().replaceAll('-', '')}`, features);
    if (!popup) { this.popupNotice.set('The browser blocked the pop-out. Allow pop-ups for MIDAS and try again.'); return; }
    this.popupWindow = popup;
    this.popoutConnected.set(false);
    this.popupNotice.set('Opening movable, resizable chat window…');
    this.popoutActive.set(true);
    this.open.set(false);
    this.fullPage.set(false);
    if (this.lastRoute === '/calian-ai') {
      localStorage.setItem(APP_PREF_KEY, 'advmetrics');
      void this.router.navigateByUrl('/advmetrics');
    }
    // Copy conversation/history only after the source agrees it is safe.
    if (this.connected()) this.beginHandoff('frame', 'popup');
    else this.popupNotice.set('New chat window opened. Embedded conversation was not connected for transfer.');
    popup.focus();
    if (this.popupWatcher) clearInterval(this.popupWatcher);
    this.popupWatcher = setInterval(() => {
      if (this.popupWindow?.closed) this.onPopoutClosed();
    }, 1000);
  }
  private onPopoutClosed(): void {
    if (this.popupWatcher) { clearInterval(this.popupWatcher); this.popupWatcher = undefined; }
    this.popupWindow = null;
    this.popoutActive.set(false);
    this.popoutConnected.set(false);
    this.cancelHandoff();
    this.pending.set(null);
    this.open.set(true);
    this.sendContext();
  }
  focusPopout(): void {
    if (!this.popupWindow || this.popupWindow.closed) { this.onPopoutClosed(); return; }
    this.popupWindow.focus();
  }
  resizePopout(width: number, height: number): void {
    if (!this.popupWindow || this.popupWindow.closed) { this.onPopoutClosed(); return; }
    try { this.popupWindow.resizeTo(width, height); this.popupWindow.focus(); }
    catch { this.popupNotice.set('Use the browser window edges to resize manually.'); }
  }
  centerPopout(): void {
    if (!this.popupWindow || this.popupWindow.closed) { this.onPopoutClosed(); return; }
    try {
      this.popupWindow.moveTo(Math.max(0,Math.round((screen.availWidth-1100)/2)), Math.max(0,Math.round((screen.availHeight-800)/2)));
      this.popupWindow.focus();
    } catch { this.popupNotice.set('Move the pop-out by dragging its title bar.'); }
  }
  dockPopout(): void {
    if (!this.popupWindow || this.popupWindow.closed) { this.onPopoutClosed(); return; }
    if (!this.popoutConnected()) {
      // V6.2 popout-keep-open: never destroy a user-opened window just because
      // the handshake is delayed. The user can retry docking later.
      this.popupNotice.set('The pop-out is still connecting. It stays open; focus it and try Dock again when connected.');
      return;
    }
    this.popupNotice.set('Moving the active chat back into MIDAS…');
    this.beginHandoff('popup', 'frame');
  }
  private beginHandoff(from: BridgeEndpoint, to: BridgeEndpoint): void {
    this.cancelHandoff();
    const id = crypto.randomUUID();
    this.handoff = { id, from, to };
    this.postTo(from, 'SESSION_EXPORT_REQUEST', { id });
    this.handoffTimeout = setTimeout(() => {
      if (this.handoff?.id === id) {
        const wasOpening = this.handoff.from === 'frame';
        this.cancelHandoff();
        // A timed-out export/import is not a request to close the new window.
        // Keep both windows alive; the embedded chat remains intact if the
        // first handoff failed. Only a completed user-requested Dock closes it.
        this.popupNotice.set(wasOpening
          ? 'Chat history transfer timed out. The pop-out stays open and the embedded conversation is unchanged.'
          : 'Docking timed out. The pop-out stays open; try Dock in MIDAS again.');
      }
    }, 12000);
  }
  private cancelHandoff(): void {
    this.handoff = undefined;
    if (this.handoffTimeout) { clearTimeout(this.handoffTimeout); this.handoffTimeout = undefined; }
  }
  private tryImportHandoff(): void {
    const transfer = this.handoff;
    if (!transfer || !transfer.snapshot) return;
    if (transfer.to === 'popup' && !this.popoutConnected()) return;
    if (transfer.to === 'frame' && !this.connected()) return;
    this.postTo(transfer.to, 'SESSION_IMPORT', { id: transfer.id, snapshot: transfer.snapshot });
  }
  frameLoaded(): void {
    // Calian sends a token-bearing BRIDGE_READY after processing INIT.
    // Retrying INIT briefly covers startup races between the iframe load
    // event and Angular's message listener initialization.
    this.connected.set(false);
    this.postTo('frame', 'INIT', { capabilities: this.capabilities() });
    this.sendContext();
    if (this.bridgeRetry) clearInterval(this.bridgeRetry);
    let retries = 0;
    this.bridgeRetry = setInterval(() => {
      if (this.connected() || ++retries > 8) {
        if (this.bridgeRetry) clearInterval(this.bridgeRetry);
        this.bridgeRetry = undefined;
      } else {
        this.postTo('frame', 'INIT', { capabilities: this.capabilities() });
      }
    }, 1250);
  }
  private capabilities(): Record<string, unknown> {
    return { dashboards: Object.keys(MIDAS_DASHBOARDS), dashboardLabels: MIDAS_DASHBOARDS, actions: [...MIDAS_ACTION_CATALOGUE], readTools: MIDAS_READ_TOOLS, approvalRequired: true };
  }
  private context(): Record<string, unknown> | null {
    if (!this.shareContext() || !this.isVisible()) return null;
    const route = this.lastRoute === '/calian-ai' ? null : this.lastRoute;
    const onCP = route === '/advmetrics/cp';
    const entities = onCP ? this.store.selectSignal(selectCpEntities)().slice(0, 40).map(e => ({ id: e.id, name: e.name })) : [];
    return {
      route,
      dataSourceConnected: this.store.selectSignal(selectConnectedDB)().connected === true,
      timeBounds: (() => { const b = this.store.selectSignal(selectMinMaxTime)(); return b ? {min:b.minTime,max:b.maxTime} : undefined; })(),
      activeDashboard: Object.entries(dashboards).find(([,value]) => '/advmetrics/'+value === route)?.[0] || null,
      cpGrouping: onCP ? this.store.selectSignal(selectCombatPowerDataGrouping)() : undefined,
      romCaptures: route === '/advmetrics/rom' ? this.store.selectSignal(selectAllRomSpecs)().slice(0,40).map(v => ({id:v.id,name:v.name})) : undefined,
      cmMeasures: route === '/advmetrics/cm' ? this.store.selectSignal(selectControlMeasures)().slice(0,40).map(v => ({id:v.id,name:v.cmname})) : undefined,
      selectedTimeFormat: this.store.selectSignal(selectSelectedTimeFormat)(),
      availableTimeFormats: this.store.selectSignal(selectTimeFormatNames)().slice(0, 40),
      ...(onCP ? {
        cpTimeframe: this.store.selectSignal(selectCpTimeframe)(),
        cpTimeBounds: (() => { const bounds = this.store.selectSignal(selectMinMaxTime)(); return bounds ? { min: bounds.minTime, max: bounds.maxTime } : undefined; })(),
        cpSelectedEntityIds: this.store.selectSignal(selectCpSelectedEntityIds)().slice(0, 100),
        cpEntities: entities,
      } : {}),
    };
  }
  private sendContext(): void {
    this.send('CONTEXT', { sharing: this.shareContext() && this.isVisible(), context: this.context() });
  }
  /** Read-only, bounded snapshots. No arbitrary URLs, APIs, DOM access or live commands. */
  private readTool(tool: ReadTool): ToolPayload {
    const connected = this.store.selectSignal(selectConnectedDB)().connected === true;
    const base: ToolPayload = { tool, generatedAt: new Date().toISOString(), dashboard: this.lastRoute, connected, status: 'unavailable' };
    if (tool === 'capabilities') return { ...base, status: 'ok', data: { dashboards: MIDAS_DASHBOARDS, actions: MIDAS_ACTION_CATALOGUE, readTools: MIDAS_READ_TOOLS } };
    if (!connected) return { ...base, reason: 'No MIDAS data source connected. Connect authorized MIDAS data before requesting analysis.' };
    const summary = this.store.selectSignal(selectSummaryState)();
    // Explicit numeric measurements only; no secrets, raw database rows or arbitrary state dumps.
    const summaryMetrics = {
      controlMeasuresMonitored: summary.CMO.controlMeasuresMonitored,
      movementMeasuresMonitored: summary.ROM.controlMeasuresMonitored,
      unitsBelow100: summary.CombatPower.unitsBelow100,
      hHourEntitiesCrossed: summary.HHour.entitiesCrossed,
      blueControlMeasures: summary.POE.bluforControlMeasures,
      redControlMeasures: summary.POE.opforControlMeasures,
      entitiesWatched: summary.EntityWatch.entitiesWatched,
      fratricideIncidentCount: summary.Fratricide.incidentCount,
      enemyEngagedCount: summary.EnemyEngagements.numberEngaged,
    };
    const data: Record<string,unknown> = {
      coverage: this.lastRoute === '/advmetrics/cp' || this.lastRoute === '/advmetrics/summary' ? 'Dashboard summary and available Combat Power series' : 'Cross-dashboard summary metrics only; no page-specific dataset available for this dashboard',
      route: this.lastRoute, timeFormat: this.store.selectSignal(selectSelectedTimeFormat)(),
      summaryMetrics, generatedFrom: 'MIDAS authenticated NgRx selectors',
    };
    if (this.lastRoute === '/advmetrics/cp' || tool === 'compare_combat_power') {
      const chart = this.store.selectSignal(selectCpChartData)();
      const series = (chart.chartData.datasets as unknown as Array<{label?:string;data?:unknown}>).slice(0,10)
        .map(item => ({name: String(item.label || 'Series').slice(0,80), statistics: seriesStats(item.data)}))
        .filter(item => item.statistics !== null);
      data['combatPower'] = {
        selectedEntityIds: this.store.selectSignal(selectCpSelectedEntityIds)().slice(0,40),
        timeframe: this.store.selectSignal(selectCpTimeframe)(),
        grouping: this.store.selectSignal(selectCombatPowerDataGrouping)(),
        series,
      };
      if (tool === 'compare_combat_power' && series.length < 2) return {
        ...base, reason: 'Comparison needs two or more loaded Combat Power series. Select authorized entities and load data.',
      };
    }
    return { ...base, status: 'ok', data };
  }
  private handleToolRequest(id: unknown, tool: unknown, source: BridgeEndpoint): void {
    if (typeof id !== 'string' || !/^[a-f0-9-]{36}$/i.test(id) || typeof tool !== 'string' || !MIDAS_READ_TOOLS.includes(tool as ReadTool)) return;
    if (!this.shareContext() || !this.isVisible()) {
      this.postTo(source, 'TOOL_RESULT', { id, result: { tool, status:'unavailable', reason:'Enable Share dashboard context in MIDAS first.' } });
      return;
    }
    const result = this.readTool(tool as ReadTool);
    // Bound payloads to prevent unbounded state transfer through postMessage.
    if (JSON.stringify(result).length > 18000) {
      this.postTo(source, 'TOOL_RESULT', { id, result: { tool, status:'unavailable', reason:'Snapshot exceeds the approved data limit.' } });
      return;
    }
    this.postTo(source, 'TOOL_RESULT', { id, result });
  }
  private onMessage = (event: MessageEvent): void => {
    if (!this.targetOrigin || event.origin !== this.targetOrigin) return;
    const source: BridgeEndpoint | null = event.source === this.frame?.nativeElement.contentWindow
      ? 'frame' : (this.popoutActive() && event.source === this.popupWindow ? 'popup' : null);
    if (!source) return;
    const data = event.data;
    if (!data || typeof data !== 'object' || data.bridge !== BRIDGE || typeof data.type !== 'string') return;
    if (data.type === 'HELLO') {
      if (source === 'popup') this.popoutConnected.set(true);
      else this.connected.set(true);
      this.postTo(source, 'INIT', { capabilities: this.capabilities() });
      this.sendContext();
      this.tryImportHandoff();
      return;
    }
    if (data.token !== (source === 'frame' ? this.token : this.popupToken)) return;
    // A valid origin, source window and session token prove the endpoint
    // acknowledged INIT. The iframe load event can otherwise overwrite the
    // earlier HELLO status, leaving the badge incorrectly disconnected.
    if (source === 'frame' && !this.connected()) this.connected.set(true);
    if (source === 'popup' && !this.popoutConnected()) this.popoutConnected.set(true);
    if (data.type === 'SESSION_EXPORT_ERROR' && this.handoff?.from === source && data.id === this.handoff.id) {
      const message = String(data.message || 'The current chat cannot be transferred.').slice(0,220);
      this.cancelHandoff();
      // Busy agents, microphones, and video can reject session export.
      // This is expected and must not force-close the pop-out.
      this.popupNotice.set(message + ' The pop-out stays open.');
      return;
    }
    if (data.type === 'SESSION_EXPORT_RESPONSE' && this.handoff?.from === source && data.id === this.handoff.id) {
      try {
        const raw = JSON.stringify(data.snapshot);
        if (raw.length > 210000 || !data.snapshot || typeof data.snapshot !== 'object') throw new Error('Snapshot too large or invalid');
        this.handoff.snapshot = data.snapshot as unknown;
        this.tryImportHandoff();
      } catch {
        this.popupNotice.set('Chat transfer payload could not be validated.');
        this.cancelHandoff();
      }
      return;
    }
    if (data.type === 'SESSION_IMPORTED' && this.handoff?.to === source && data.id === this.handoff.id) {
      const isDock = this.handoff.to === 'frame';
      this.cancelHandoff();
      if (isDock) {
        const popup = this.popupWindow;
        popup?.close();
        this.onPopoutClosed();
        this.popupNotice.set('Chat restored in MIDAS.');
      } else this.popupNotice.set('Chat session transferred to the pop-out.');
      return;
    }
    if (data.type === 'CONTEXT_REQUEST') { this.sendContext(); return; }
    if (data.type === 'TOOL_REQUEST') { this.handleToolRequest(data.id, data.tool, source); return; }
    if (data.type !== 'ACTION_REQUEST') return;
    if (!this.shareContext() || !this.isVisible()) { this.reply(String(data.id || ''), false, 'Turn on Share dashboard context first.', source); return; }
    const id = data.id;
    if (typeof id !== 'string' || !/^[a-zA-Z0-9-]{1,80}$/.test(id)) return;
    const request = this.validateRequest(data.action, data.params);
    if (!request) { this.reply(id, false, 'Unsupported or invalid MIDAS action.', source); return; }
    if (this.pending()) { this.reply(id, false, 'Another action is awaiting approval.', source); return; }
    this.pending.set({ id, request, source, description: this.describe(request) });
  };
  private validateRequest(action: unknown, params: unknown): ActionRequest | null {
    if (!params || typeof params !== 'object' || Array.isArray(params)) return null;
    const p = params as Record<string, unknown>;
    if (action === 'navigate' && typeof p['dashboard'] === 'string' && Object.hasOwn(dashboards, p['dashboard'])) return { action, params: { dashboard: p['dashboard'] } };
    if (action === 'time_format' && typeof p['name'] === 'string' && this.store.selectSignal(selectTimeFormatNames)().includes(p['name'])) return { action, params: { name: p['name'] } };
    if (action === 'cp_time_range' && this.lastRoute === '/advmetrics/cp' && typeof p['start'] === 'number' && typeof p['end'] === 'number') {
      const minMax = this.store.selectSignal(selectMinMaxTime)();
      if (minMax && Number.isFinite(p['start']) && Number.isFinite(p['end']) && p['start'] >= minMax.minTime && p['end'] <= minMax.maxTime && p['start'] < p['end']) return { action, params: { start: p['start'], end: p['end'] } };
    }
    if (action === 'rom_select_capture' && this.lastRoute === '/advmetrics/rom' && typeof p['id'] === 'number' && Number.isSafeInteger(p['id']) && this.store.selectSignal(selectAllRomSpecs)().some(v=>v.id===p['id'])) return {action,params:{id:p['id']}};
    if (action === 'cm_select_measure' && this.lastRoute === '/advmetrics/cm' && typeof p['id'] === 'number' && Number.isSafeInteger(p['id']) && this.store.selectSignal(selectControlMeasures)().some(v=>v.id===p['id'])) return {action,params:{id:p['id'],selected:p['selected']!==false}};
    if (action === 'cp_grouping' && this.lastRoute === '/advmetrics/cp' && (p['grouping'] === 'unit' || p['grouping'] === 'equipment')) return {action, params:{grouping:p['grouping']}};
    if ((action === 'rom_time_range' && this.lastRoute === '/advmetrics/rom' || action === 'cm_time_range' && this.lastRoute === '/advmetrics/cm') && typeof p['start']==='number' && typeof p['end']==='number') {
      const bounds = this.store.selectSignal(selectMinMaxTime)();
      if(bounds && Number.isFinite(p['start']) && Number.isFinite(p['end']) && p['start']>=bounds.minTime && p['end']<=bounds.maxTime && p['start']<p['end']) return {action,params:{start:p['start'],end:p['end']}};
    }
    if (action === 'cp_select_entity' && this.lastRoute === '/advmetrics/cp' && typeof p['id'] === 'number' && Number.isSafeInteger(p['id'])) {
      if (this.store.selectSignal(selectCpEntities)().some(e => e.id === p['id'])) return { action, params: { id: p['id'], selected: p['selected'] !== false } };
    }
    return null;
  }
  private describe(r: ActionRequest): string {
    const p = r.params;
    if (r.action === 'navigate') return `Navigate MIDAS to the ${String(p['dashboard'])} dashboard.`;
    if (r.action === 'time_format') return `Set MIDAS time format to ${String(p['name'])}.`;
    if (r.action === 'cp_time_range') return `Set Combat Power timeframe to ${p['start']}–${p['end']} (MIDAS native time units).`;
    if (r.action === 'rom_select_capture') return `Select Rate of Movement capture ${p['id']}.`;
    if (r.action === 'cm_select_measure') return `${p['selected'] ? 'Select' : 'Deselect'} Control Measure ${p['id']}.`;
    if (r.action === 'cp_grouping') return `Group Combat Power chart by ${p['grouping']}.`;
    if (r.action === 'rom_time_range') return `Set Rate of Movement timeframe to ${p['start']}–${p['end']}.`;
    if (r.action === 'cm_time_range') return `Set Control Measures timeframe to ${p['start']}–${p['end']}.`;
    return `${p['selected'] ? 'Select' : 'Deselect'} Combat Power entity ${p['id']}.`;
  }
  private reply(id: string, ok: boolean, message: string, source: BridgeEndpoint): void { this.postTo(source, 'ACTION_RESULT', { id, ok, message }); }
  async approve(): Promise<void> {
    const item = this.pending();
    if (!item) return;
    this.pending.set(null);
    // Revalidate against the latest route and store state before applying changes.
    const request = this.validateRequest(item.request.action, item.request.params);
    if (!request || !this.isVisible() || !this.shareContext()) { this.reply(item.id, false, 'Action no longer valid.', item.source); return; }
    const p = request.params;
    try {
      switch (request.action) {
        case 'navigate': {
          const target = `/advmetrics/${dashboards[String(p['dashboard'])]}`;
          // Navigating to the already open dashboard is a successful no-op.
          // Angular may return false when same-URL navigation is ignored.
          if (this.router.url.split('?')[0].split('#')[0] === target) {
            this.reply(item.id, true, 'This MIDAS dashboard is already open.', item.source);
            break;
          }
          const success = await this.router.navigateByUrl(target);
          this.reply(item.id, success, success ? 'MIDAS navigated successfully.' : 'Navigation was rejected by the router.', item.source);
          break;
        }
        case 'time_format':
          this.store.dispatch(sidebarActions.timeFormatSelected(String(p['name'])));
          this.reply(item.id, true, 'MIDAS time format updated.', item.source);
          break;
        case 'cp_time_range':
          this.store.dispatch(cpActions.timeframeChange({ start: Number(p['start']), end: Number(p['end']) }));
          this.reply(item.id, true, 'Combat Power time range updated.', item.source);
          break;
        case 'rom_select_capture': {
          const capture=this.store.selectSignal(selectAllRomSpecs)().find(v=>v.id===p['id']);
          if(!capture) {this.reply(item.id,false,'ROM capture no longer available.',item.source);break;}
          this.store.dispatch(romActions.captureSelected(capture));
          this.reply(item.id,true,'Rate of Movement capture updated.',item.source);
          break;
        }
        case 'cm_select_measure': {
          const id=Number(p['id']);
          const active=this.store.selectSignal(selectSelectedControlMeasureIds)().includes(id);
          if(Boolean(p['selected']) !== active) this.store.dispatch(Boolean(p['selected'])?cmActions.controlMeasureSelected(id):cmActions.controlMeasureDeselected(id));
          this.reply(item.id,true,'Control Measure selection updated.',item.source);
          break;
        }
        case 'cp_grouping':
          this.store.dispatch(cpActions.dataGroupingChanged(p['grouping'] as 'unit' | 'equipment'));
          this.reply(item.id, true, 'Combat Power grouping updated.', item.source);
          break;
        case 'rom_time_range':
          this.store.dispatch(romActions.timeframeChange({ start:Number(p['start']),end:Number(p['end']) }));
          this.reply(item.id, true, 'Rate of Movement time range updated.', item.source);
          break;
        case 'cm_time_range':
          this.store.dispatch(cmActions.timeframeChange({ start:Number(p['start']),end:Number(p['end']) }));
          this.reply(item.id, true, 'Control Measures time range updated.', item.source);
          break;
        case 'cp_select_entity': {
          const id = Number(p['id']);
          const present = this.store.selectSignal(selectCpSelectedEntityIds)().includes(id);
          if (Boolean(p['selected']) !== present) this.store.dispatch(Boolean(p['selected']) ? cpActions.entitySelected(id) : cpActions.entityDeselected(id));
          this.reply(item.id, true, 'Combat Power entity selection updated.', item.source);
          break;
        }
      }
      this.sendContext();
    } catch {
      this.reply(item.id, false, 'MIDAS could not complete that action.', item.source);
    }
  }
  reject(): void {
    const item = this.pending();
    this.pending.set(null);
    if (item) this.reply(item.id, false, 'The MIDAS action was declined.', item.source);
  }
}
