@echo off
setlocal
cd /d "%~dp0PYTHON_BACKEND"
set OLLAMA_ENABLED=true
set OLLAMA_URL=http://127.0.0.1:11434
set OLLAMA_MODEL=llama3.2:latest
set PORT=9999
python -m pip install -r requirements-local.txt
if errorlevel 1 (echo Dependency installation failed. & pause & exit /b 1)
python -m uvicorn main:app --host 127.0.0.1 --port 9999
if errorlevel 1 (echo Router exited with error. & pause)
