CALIAN AI Angular Electron — Ollama-first routing

1. Run START-PYTHON-ROUTER.bat (selection-only Ollama router on 9999).
2. Configure CALIAN_AI_ELECTRON_THEMES/.env if your actual Python A2A service runs elsewhere:
   PYTHON_SERVICE_URL=http://127.0.0.1:<your-existing-A2A-port>
   OLLAMA_ROUTER_URL=http://127.0.0.1:9999
   AI_CORE_REGISTRY_URL=<your-existing-registry>
3. Run START-CALIAN-ELECTRON.bat.
4. Enable Auto Select and inspect routing method. Only method=ollama confirms Ollama selection.

IMPORTANT: The bundled Python service is selection-only and exposes a placeholder local-ollama agent; it DOES NOT provide North A2A execution or your original North agent. To retain seven executable agents, point PYTHON_SERVICE_URL to your already-working original Python A2A service, and keep the Ollama router on its own port. Never treat the placeholder as an executable agent.

Fallback is metadata-based if Ollama is down or returns invalid agent. No existing backup is modified.
