@echo off
cd /d "%~dp0CALIAN_AI_ELECTRON_THEMES"
if not exist node_modules (call npm install || (pause & exit /b 1))
call npm run dev
pause
