# CALIAN AI — Four UI skins

In the Electron toolbar, choose **Appearance**: Corporate, Royal, Modern AI, or Classic. The choice is stored locally and restored on restart. The adjacent brightness button switches between Classic and Corporate.

## Start

```bat
npm install
npm run dev
```

The original project and backend routing are unchanged. This release only adds UI theming; agent execution still depends on your configured backend services.
