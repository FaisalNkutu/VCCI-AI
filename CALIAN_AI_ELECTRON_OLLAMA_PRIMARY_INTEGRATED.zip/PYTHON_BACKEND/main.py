"""Local Ollama routing service. No North SDK or credentials required.
AI Core agents are discovered separately by the existing Node bridge.
This service performs selection only; it does not execute North A2A agents.
"""
import logging
import os
from typing import Any
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from conversation_context import ConversationContext
from agent_router import AgentRouter
from router_models import RouterRequest, RouterAgent

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
app = FastAPI(title="CALIAN AI Local Router", version="1.2.0")
agent_router = AgentRouter()

# Optional local registry, compatible with the existing frontend's Python agent count.
# This is a routing identity, NOT a live North execution endpoint.
LOCAL_AGENTS = [{"id":"local-ollama","name":"Local Ollama Assistant",
    "description":"General-purpose local language model assistant",
    "type":"north","streaming":False,"configured":False,"active":False,
    "endpoint":"","skills":[]}]

@app.get("/health")
async def health():
    return {"status":"ok","service":"CALIAN AI Local Router","execution":"not configured"}

@app.get("/ready")
async def ready():
    return {"status":"ready","router":"ollama-with-metadata-fallback"}

@app.get("/agents")
async def agents():
    return {"agents":LOCAL_AGENTS,"count":len(LOCAL_AGENTS),"discovery":"local"}

@app.get("/router/health")
async def router_health():
    return {"status":"UP","router":"AgentRouter","llmRouterConfigured":agent_router.has_llm_router()}

@app.post("/router/select")
async def select_agent(payload:dict[str,Any]):
    message=str(payload.get("message") or "").strip()
    if not message:
        return JSONResponse(status_code=400,content={"agent":None,"confidence":0,"reason":"Message cannot be empty"})
    if len(message)>16000:
        raise HTTPException(status_code=413,detail="Message too long")
    supplied=payload.get("agents")
    candidates=supplied[:250] if isinstance(supplied,list) else LOCAL_AGENTS
    valid=[]
    for item in candidates:
        if not isinstance(item,dict):
            continue
        normalized=dict(item)
        normalized["id"]=str(item.get("id") or item.get("agentId") or "").strip()
        normalized["name"]=str(item.get("name") or normalized["id"]).strip()
        if normalized["id"] and normalized["name"]:
            valid.append(normalized)
    request=RouterRequest(message=message,contextId=payload.get("contextId"),
        previousAgentId=payload.get("previousAgentId"),
        context=ConversationContext.model_validate(payload.get("context") or {}),
        agents=[RouterAgent.model_validate(a) for a in valid])
    decision=await agent_router.route(request)
    selected=next((a for a in valid if a["id"]==decision.agentId),None)
    return {"agent":selected,"confidence":decision.confidence,"reason":decision.reason,
            "agentId":decision.agentId,"agentName":decision.agentName,"method":decision.method}

@app.post("/router/select/v2")
async def select_v2(request:RouterRequest):
    # This compatibility route accepts only selection metadata, never execution URLs.
    return await agent_router.route(request)

if __name__=="__main__":
    import uvicorn
    uvicorn.run(app,host="127.0.0.1",port=int(os.getenv("PORT","9999")))
