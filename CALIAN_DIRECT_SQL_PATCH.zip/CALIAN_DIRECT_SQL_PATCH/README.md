# CALIAN.AI direct SQL adapter (CALIAN-only change)

## Confirmed result
The user's existing `reqa-api` container executed `mcp_servers.database_server.call_tool('execute_sql',...)` successfully via `docker exec -i reqa-api python -` and returned real rows from `contxt_oi_assoc`.

## What this patch does
- Changes CALIAN's existing `server/index.ts` **only** for requests to **DBAgent** which begin with SQL `SELECT` or `WITH`.
- Uses a spawned Docker CLI process to call the existing REQA `mcp_servers.database_server` MCP tool. It sends SQL via stdin, not shell interpolation.
- Validates the input in the `reqa-api` container with sqlglot as **one SELECT-only statement** and rejects writes, administrative statements, locks, INTO, arbitrary SQL functions, and multiple statements. Caps output at 1000 rows.
- Natural language such as "Show the first 10 records..." still uses the existing `GenerateSQL` A2A contract.
- Preserves all other agents' behaviour.
- Does NOT change Fouad's Python code, Ollama, Ollama models, Docker, MariaDB, Java or `.env`.

## Important security conditions
- This local adapter assumes Docker and `reqa-api` run on the same Windows machine as the CALIAN backend.
- The backend listens on 127.0.0.1 in the existing source; do NOT expose it over the Internet.
- The REQA MCP `execute_sql` tool **does not itself enforce a read-only database privilege**. The CALIAN adapter adds input parsing, but defence in depth requires a **database user with SELECT-only privileges**. Confirm with Fouad/DBA before using this with sensitive databases.
- Only use for a trusted local machine. This is a local bridge, not a production-grade authenticated SQL execution service.
- To use a different container name, set `CALIAN_SQL_DOCKER_CONTAINER` on the CALIAN process (default: `reqa-api`).

## Installation
Extract the complete ZIP, open PowerShell in the extracted directory, and run:

`powershell -NoProfile -ExecutionPolicy Bypass -File .\APPLY_CALIAN_DIRECT_SQL.ps1`

It locates the active CALIAN project folder or prompts for it. It backs up `server/index.ts` to `CALIAN-A2A-backups` and refuses to overwrite unfamiliar source or different helper files. Node 22+ runs three local tests. Re-run is safe and idempotent.

Then restart the CALIAN source backend. A packaged Windows `.exe` is not changed by a source patch; rebuild using your existing Windows build script if needed.

## Verification
In CALIAN select DBAgent (manual selection recommended for this test) and enter:

`SELECT * FROM contxt_oi_assoc LIMIT 10`

Expected: `used_skill: execute_sql`, `Success: true`, and actual rows. The command bypasses the LLM SQL-generation step, not the database's SQL permissions.

Then enter a natural-language question: `Show the first 10 records from the contxt_oi_assoc table.`

Expected: `used_skill: GenerateSQL` through the existing JSON-formatted A2A request. It may still generate incorrect SQL: that is independent of this direct-SQL adapter.

## Rollback
Restore the dated `index-before-direct-sql-*.ts` from the project's `CALIAN-A2A-backups` folder to `server/index.ts`, then remove `server/direct-sql.ts` if no other code uses it. Restart/rebuild CALIAN. No changes to Docker or REQA need to be reverted.

## Validation scope
Local Node classifier tests: 3 pass. Embedded Python script: AST syntax checked. **Actual runtime integration on the user's Windows backend is not yet verified**; it depends on Docker CLI availability and permissions in CALIAN's environment.
