<#
Apply a CALIAN-only direct SELECT adapter using REQA's already-working MCP execute_sql.
This does NOT alter Docker containers, Ollama, Python source, or database settings.
#>
param([string]$ProjectRoot = '')
$ErrorActionPreference = 'Stop'

function Resolve-CalianUI([string]$candidate) {
  if ([string]::IsNullOrWhiteSpace($candidate)) { return $null }
  $clean = $candidate.Trim().Trim('"', "'")
  foreach ($p in @($clean, (Join-Path $clean 'CALIAN_AI_ELECTRON_THEMES'), (Join-Path $clean 'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES'))) {
    if (Test-Path -LiteralPath (Join-Path $p 'server\index.ts') -PathType Leaf) {
      return (Resolve-Path -LiteralPath $p).Path
    }
  }
  return $null
}

if ($ProjectRoot) {
  $ui = Resolve-CalianUI $ProjectRoot
  if (-not $ui) { throw "CALIAN server\index.ts not found under: $ProjectRoot" }
} else {
  $candidates = @(
    (Get-Location).Path,
    $PSScriptRoot,
    (Split-Path $PSScriptRoot -Parent),
    (Join-Path $HOME 'Downloads\Standalone_Calian_AI_Chatbot'),
    (Join-Path $HOME 'Desktop\Standalone_Calian_AI_Chatbot'),
    (Join-Path $HOME 'Documents\Standalone_Calian_AI_Chatbot')
  )
  $matches = @($candidates | ForEach-Object { Resolve-CalianUI $_ } | Where-Object { $_ } | Select-Object -Unique)
  if ($matches.Count -eq 1) { $ui = $matches[0] }
  else {
    if ($matches.Count -gt 1) { Write-Host 'Multiple project copies found:' -ForegroundColor Yellow; $matches | ForEach-Object { Write-Host " - $_" } }
    $answer = Read-Host 'Paste the path to your ACTIVE CALIAN project folder'
    $ui = Resolve-CalianUI $answer
    if (-not $ui) { throw 'CALIAN project not found. No files were changed.' }
  }
}

$indexPath = Join-Path $ui 'server\index.ts'
$helperPath = Join-Path $ui 'server\direct-sql.ts'
$testPath = Join-Path $ui 'tests\direct-sql.test.mjs'
$kitHelper = Join-Path $PSScriptRoot 'files\direct-sql.ts'
$kitTest = Join-Path $PSScriptRoot 'files\direct-sql.test.mjs'
if (-not (Test-Path -LiteralPath $kitHelper) -or -not (Test-Path -LiteralPath $kitTest)) { throw 'Extract the entire ZIP before running.' }

$original = [IO.File]::ReadAllText($indexPath)
$importAnchor = "import { encodeNl2SqlMessage } from './nl2sql-payload';"
$importLine = "import { classifyDbInput, executeReadOnlySql } from './direct-sql';"
$entryAnchor = " if(typeof agentId!=='string'||typeof message!=='string'||typeof contextId!=='string'){res.status(400).json({error:'Invalid request'});return;}"
$already = $original.Contains($importLine) -and $original.Contains('executeReadOnlySql(message)')
if (-not $original.Contains($importAnchor) -or -not $original.Contains('method: ''message/send''')) {
  throw 'The active CALIAN source does not match the previously patched JSON-contract version. Refusing to overwrite it.'
}
if (-not $already) {
  if ($original.Contains($importLine) -or $original.Contains('executeReadOnlySql(message)')) { throw 'Partial direct SQL patch detected. No changes made.' }
  if (($original.Split([string[]]@($entryAnchor),[StringSplitOptions]::None).Count - 1) -ne 1) {
    throw 'Expected DBAgent route could not be located uniquely. No changes made.'
  }
}
if ((Test-Path -LiteralPath $helperPath) -and ([IO.File]::ReadAllText($helperPath) -ne [IO.File]::ReadAllText($kitHelper))) {
  throw 'An existing direct-sql.ts differs from this patch. Refusing to overwrite it.'
}
if ((Test-Path -LiteralPath $testPath) -and ([IO.File]::ReadAllText($testPath) -ne [IO.File]::ReadAllText($kitTest))) {
  throw 'An existing direct-sql test differs from this patch. Refusing to overwrite it.'
}

$branch = @'
 // Literal SQL is already written; do not send it to NL2SQL/Ollama to be rewritten.
 // Natural-language requests keep the original registered DBAgent A2A path.
 if(agentId.trim().toLowerCase()==='dbagent'){
   const inputKind=classifyDbInput(message);
   if(inputKind==='unsafe'){res.status(400).json({error:'Only SELECT statements may be executed directly. Write/administrative SQL is blocked.'});return;}
   if(inputKind==='sql'){
     try{
       const result=await executeReadOnlySql(message);
       res.json({Success:result.success,used_skill:'execute_sql',
         Request:{Request:'execute_sql',Query:message,max_rows:1000},
         Response:{success:result.success,sql:message,rows:result.rows,
           row_count:result.rows.length,error:result.error,
           answer:result.success?`Returned ${result.rows.length} row(s), up to 1000.`:result.error}});
     }catch(error){fail(res,error);}
     return;
   }
 }
'@

Write-Host "CALIAN project: $ui" -ForegroundColor Cyan
if (-not $already) {
  $backupDir = Join-Path $ui 'CALIAN-A2A-backups'
  New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
  $backup = Join-Path $backupDir ("index-before-direct-sql-{0}.ts" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
  Copy-Item -LiteralPath $indexPath -Destination $backup -ErrorAction Stop
  $modified = $original.Replace($importAnchor, "$importAnchor`n$importLine").Replace($entryAnchor, "$entryAnchor`n$branch")
  try {
    [IO.File]::WriteAllText($indexPath,$modified,[Text.UTF8Encoding]::new($false))
    if (-not (Test-Path -LiteralPath $helperPath)) { Copy-Item -LiteralPath $kitHelper -Destination $helperPath }
    New-Item -ItemType Directory -Force -Path (Split-Path $testPath -Parent) | Out-Null
    if (-not (Test-Path -LiteralPath $testPath)) { Copy-Item -LiteralPath $kitTest -Destination $testPath }
  } catch {
    Copy-Item -LiteralPath $backup -Destination $indexPath -Force
    throw
  }
  Write-Host "Original server/index.ts backup: $backup" -ForegroundColor Green
  Write-Host 'CALIAN-only direct SQL adapter installed.' -ForegroundColor Green
} else {
  Write-Host 'Already patched: no duplicate modifications.' -ForegroundColor Green
}

$node=Get-Command node -ErrorAction SilentlyContinue
if ($node) {
  $version=[int]((node --version).Trim().TrimStart('v').Split('.')[0])
  if ($version -ge 22) {
    Push-Location $ui
    try { & node --experimental-strip-types --test 'tests/direct-sql.test.mjs'; if ($LASTEXITCODE -ne 0) { throw 'Contract tests failed; see backup.' } }
    finally { Pop-Location }
  } else { Write-Host 'Node <22: tests skipped, restart the existing backend to test.' -ForegroundColor Yellow }
} else { Write-Host 'Node not in PATH: tests skipped.' -ForegroundColor Yellow }

Write-Host ''
Write-Host 'Restart the CALIAN backend to load the updated SOURCE.' -ForegroundColor Green
Write-Host 'The installed portable EXE was NOT changed: rebuild it with your existing Windows build script if needed.' -ForegroundColor Yellow
Write-Host 'No Ollama/Python/MariaDB/Docker/Java files or settings were modified.'
Write-Host 'Run in CALIAN DBAgent: SELECT * FROM contxt_oi_assoc LIMIT 10'
