import test from 'node:test';
import assert from 'node:assert/strict';
import {classifyDbInput, executeReadOnlySql} from '../server/direct-sql.ts';

test('literal SQL SELECT is routed to MCP execution', () => {
  assert.equal(classifyDbInput('SELECT * FROM `contxt_oi_assoc` LIMIT 1000'), 'sql');
  assert.equal(classifyDbInput('  with c as (select 1) select * from c'), 'sql');
});
test('natural-language questions still use the existing GenerateSQL agent', () => {
  assert.equal(classifyDbInput('Show the first 10 records from contxt_oi_assoc'), 'question');
  assert.equal(classifyDbInput('How many users are there?'), 'question');
});
test('write and administrative SQL are refused', async () => {
  for (const value of ['DELETE FROM t','UPDATE t SET x=1','DROP TABLE t','INSERT INTO t VALUES(1)','CALL run_me()']) {
    assert.equal(classifyDbInput(value), 'unsafe');
    const result=await executeReadOnlySql(value);
    assert.equal(result.success, false);
  }
});
