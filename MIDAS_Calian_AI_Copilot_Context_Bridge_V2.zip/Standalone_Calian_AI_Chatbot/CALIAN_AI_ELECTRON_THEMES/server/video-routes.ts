import type {Express, Request, Response} from 'express';

/** Private CALIAN API bridge. No guest is routed here. No change to DBAgent / REQA routes. */
export function registerVideoRoutes(app:Express, options:{port:number,publicOrigin:string}) {
 const origin=(process.env.CALIAN_VIDEO_PUBLIC_ORIGIN||'').trim().replace(/\/+$/,'');
 const admin=(process.env.CALIAN_VIDEO_ADMIN_KEY||'').trim();
 const model=(process.env.CALIAN_VISION_MODEL||'llama3.2-vision').trim();
 const ollama=(process.env.OLLAMA_URL||'http://127.0.0.1:11434').replace(/\/+$/,'');
 let publicConfigured=false;
 try {
  if(origin){const u=new URL(origin);publicConfigured=(u.protocol==='https:'||process.env.CALIAN_VIDEO_ALLOW_HTTP_DEV==='true'&&u.protocol==='http:'&&['localhost','127.0.0.1'].includes(u.hostname))&&!u.pathname.replace(/\//g,'')&&!u.search&&!u.hash&&!u.username;}
 }catch{}
 const validOrigin=(req:Request)=>{
  const clientOrigin=req.get('origin');
  if(!clientOrigin)return true; // Electron and server-to-server calls may omit Origin.
  try {const u=new URL(clientOrigin);
   if(u.protocol==='http:'&&['localhost','127.0.0.1'].includes(u.hostname)&&[String(options.port),'4300'].includes(u.port))return true;
   return !!options.publicOrigin&&clientOrigin===options.publicOrigin;
  }catch{return false;}
 };
 const rejectOrigin=(req:Request,res:Response)=>{
  if(!validOrigin(req)){res.status(403).json({error:'Untrusted request origin'});return true;}return false;
 };
 app.get('/api/video/config',(_req,res)=>res.json({callsConfigured:publicConfigured&&admin.length>=32,visionModel:model,visionConfigured:!!model,security:'Guests can access only the separate public video service.'}));
 app.post('/api/video/rooms',async(req,res)=>{
  if(rejectOrigin(req,res))return;
  if(!publicConfigured||admin.length<32){res.status(503).json({error:'Video calls are not configured yet. Set CALIAN_VIDEO_PUBLIC_ORIGIN and CALIAN_VIDEO_ADMIN_KEY in the private Windows calian.env; deploy VIDEO_CALL_SERVICE to a public HTTPS address.'});return;}
  try{
   const requestedMode=req.body?.mode==='group'?'group':'direct';
   const name=typeof req.body?.name==='string'?req.body.name.trim().slice(0,70):'';
   const response=await fetch(origin+'/api/host/rooms',{method:'POST',headers:{Authorization:`Bearer ${admin}`,'Content-Type':'application/json'},body:JSON.stringify({mode:requestedMode,name}),signal:AbortSignal.timeout(10000)});
   const body:any=await response.json();
   if(!response.ok){res.status(502).json({error:`Public video service: ${String(body?.error||response.status).slice(0,200)}`});return;}
   if(typeof body?.hostTicket!=='string'||typeof body?.inviteUrl!=='string'||typeof body?.wsUrl!=='string')throw Error('Invalid video server response');
   if(requestedMode==='group'&&(body.mode!=='group'||body.maxParticipants!==10)){
    res.status(502).json({error:'The public video gateway is running the older one-to-one service. It did not confirm LiveKit group mode. Deploy and restart VIDEO_CALL_SERVICE from this package (npm install, npm start), then check /health for protocolVersion calian-livekit-group-v2 and groupCallsConfigured true.'});
    return;
   }
   // Return a short-lived host WebRTC ticket. Never return the long-lived admin credential.
   res.setHeader('Cache-Control','no-store');
   res.json({roomId:body.roomId,name:body.name,mode:body.mode,maxParticipants:body.maxParticipants,inviteUrl:body.inviteUrl,hostTicket:body.hostTicket,wsUrl:body.wsUrl,iceServers:body.iceServers,expiresAt:body.expiresAt});
  }catch(e){res.status(502).json({error:'Unable to create an invitation: '+(e instanceof Error?e.message:String(e))});}
 });
 app.post('/api/video/ai/inspect',async(req,res)=>{
  if(rejectOrigin(req,res))return;
  const {image,question,history}=req.body||{};
  if(typeof question!=='string'||question.length>1800||!question.trim()||typeof image!=='string'||image.length>800000||!/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(image)){
   res.status(400).json({error:'Provide a JPEG camera frame (max 600KB) and a short question'});return;
  }
  const base64=image.slice('data:image/jpeg;base64,'.length);
  const jpg=Buffer.from(base64,'base64');
  if(jpg.length<100||jpg.length>600000||jpg[0]!==0xff||jpg[1]!==0xd8||jpg.at(-2)!==0xff||jpg.at(-1)!==0xd9){res.status(400).json({error:'Invalid or oversized JPEG frame'});return;}
  try{
   const context=Array.isArray(history)?history.slice(-3).filter((h:any)=>typeof h?.question==='string'&&typeof h?.answer==='string').map((h:any)=>({question:h.question.slice(0,300),answer:h.answer.slice(0,400)})):[];
   const response=await fetch(ollama+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({model,stream:false,messages:[{role:'system',content:'You are the CALIAN.AI visual assistant. Explain only what is visible in the provided image, or say when you cannot tell. Do not assume the identity of a person. Be brief, concrete, and helpful. The image is a single selected camera frame, not continuous live video.'},...(context.length?[{role:'system',content:'Previous observations (context only, verify against current image): '+JSON.stringify(context)}]:[]),{role:'user',content:question.slice(0,1800),images:[base64]}],options:{temperature:0.2,num_predict:220}}),signal:AbortSignal.timeout(120000)});
   if(!response.ok){const err=(await response.text()).slice(0,400);res.status(502).json({error:`Ollama vision model ${model} returned HTTP ${response.status}. ${err}. Install it using: ollama pull ${model}`});return;}
   const body:any=await response.json();
   const answer=body?.message?.content;
   if(typeof answer!=='string'||!answer.trim())throw Error('Vision model returned no text');
   res.setHeader('Cache-Control','no-store');res.json({answer,model,frameOnly:true});
  }catch(e){res.status(502).json({error:'Local vision request failed: '+(e instanceof Error?e.message:String(e))});}
 });
}
