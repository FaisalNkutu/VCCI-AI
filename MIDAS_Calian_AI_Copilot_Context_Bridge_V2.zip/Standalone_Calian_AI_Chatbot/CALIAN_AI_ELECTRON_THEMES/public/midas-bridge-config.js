/* Admin-controlled MIDAS host origins. Leave production list empty until approved. */
window.__CALIAN_MIDAS_ALLOWED_ORIGINS__ = /^(127\.0\.0\.1|localhost)$/i.test(location.hostname)
  ? ['http://localhost:4200', 'http://127.0.0.1:4200']
  : [];
