# Read-only local availability smoke test; does not change project settings.
$checks = @(
    @{ Name = 'Calian Angular browser UI'; Url = 'http://127.0.0.1:4300/' },
    @{ Name = 'Calian backend health'; Url = 'http://127.0.0.1:8797/api/health' },
    @{ Name = 'MIDAS Calian route'; Url = 'http://127.0.0.1:4200/calian-ai' }
)
$failed = 0
foreach ($check in $checks) {
    try {
        $res = Invoke-WebRequest -Uri $check.Url -UseBasicParsing -TimeoutSec 8 -ErrorAction Stop
        if ($res.StatusCode -ge 200 -and $res.StatusCode -lt 400) {
            Write-Host ('PASS {0}: HTTP {1}' -f $check.Name, $res.StatusCode) -ForegroundColor Green
        } else {
            Write-Host ('FAIL {0}: HTTP {1}' -f $check.Name, $res.StatusCode) -ForegroundColor Red
            $failed++
        }
    } catch {
        Write-Host ('FAIL {0}: {1}' -f $check.Name, $_.Exception.Message) -ForegroundColor Red
        $failed++
    }
}
Write-Host ''
Write-Host 'Also verify chat replies, automatic agent routing, streaming and video permissions in the actual browser.'
if ($failed -gt 0) { exit 1 }
