# V5 NOTE — POP-OUT ENABLED

For the newest setup and popup controls, read **README-V5-POP-OUT-START-HERE.md** first. The earlier V4-era instructions below are retained as history.

# V4.2 — MIDAS Angular TypeScript compiler fix (24 Nov 2026)

V4.2 repairs the four compiler diagnostics in `src/app/components/calian-ai/midas-calian-copilot.component.ts` reported after a successful MIDAS dependency installation:

- TS2349: subscribe separately to each typed NgRx selector observable (instead of calling an overloaded method on a union of observables).
- TS2353: `cpActions.timeframeChange` expects `{ start, end }`, not `{ payload: { start, end } }`.
- TS2345 twice: `cpActions.entitySelected` and `cpActions.entityDeselected` expect a number ID, not `{ payload: id }`.

These fixes are grounded in `src/app/store/actions/cp.actions.ts` and the existing `cp-dash.component.ts` calls. No change to Calian chat, multi-agent routing, video, pnpm lockfile, package versions, install-script build approvals, or automatic port selection. Private Artifactory still requires authorized access.

**Fastest fix if V4.1 is already extracted and dependencies installed:** Run the separate `HOTFIX-V4-1-COMPILER-WINDOWS.ps1` from the same folder or the separately supplied PowerShell hotfix. It patches the V4.1 component in-place after making a backup; Angular watch mode should detect it. This avoids any need to reinstall dependencies or kill already-running services. The hotfix does not touch system settings or ports. If your source was changed independently, it fails safely rather than overwriting differences.

**Fresh install:** Fully extract the V4.2 ZIP into its own folder and run `START-EVERYTHING-WINDOWS.bat`. Automatic port selection remains on. If you extract fresh, node_modules must be installed on that new tree by the launcher.

**Verification:** Source declarations checked; offline TypeScript parse and action-shape assertions passed; packaged ZIP integrity checked. This environment cannot complete an Angular 21 build against private MIDAS dependencies or run the Windows launcher end to end. Check the actual compiler terminal for any further errors.

---

# V4.1 — Fix for ERR_PNPM_IGNORED_BUILDS (24 Nov 2026)

The previous V4 launcher stopped during `pnpm install --frozen-lockfile` because pnpm did not have explicit permission to execute lifecycle scripts for the four known build dependencies in the lockfile. The V4.1 package adds a narrowly scoped, **exact-version** policy at `midas/midas-frontend/pnpm-workspace.yaml`:

```
allowBuilds:
  '@parcel/watcher@2.5.6': true
  'esbuild@0.28.1': true
  'lmdb@3.5.1': true
  'msgpackr-extract@3.0.4': true
```

This is a conscious security decision: those four dependency installation scripts will execute on your computer. Only use this package if you trust the package supply chain and your organization permits these builds. No package version or lockfile integrity digest was changed in this V4.1 repair. `strictDepBuilds` stays enabled; the script does **not** use `dangerouslyAllowAllBuilds`, `--ignore-scripts`, or automatic approval of other packages. If pnpm reports a new package needing approval, do not automatically trust it; review the dependency and allow it explicitly.

**To use:** Fully extract **this V4.1 ZIP**, then run `START-EVERYTHING-WINDOWS.bat` from the extracted folder. Your previous V4 running processes remain untouched. The launcher selects a new free matching port group. Make sure Windows Node.js, npm, pnpm and valid Simfront Artifactory credentials/connectivity are available. The package contains source code, not node_modules, Node.js, a private npm cache, credentials, AI agents or a production video server. A full end-to-end Windows build is not verified in this environment.

**If a prior V4 folder already has partially installed dependencies:** use the fresh V4.1 extracted folder rather than copying over `node_modules` from V4.

---

# MIDAS + Calian AI Copilot V4 — Automatic Free-Port Windows Launch

## One double-click: START-EVERYTHING-WINDOWS.bat

1. Download and **fully extract** this V4 ZIP into its own folder. Do not run the BAT directly from a ZIP preview.
2. Double-click **`START-EVERYTHING-WINDOWS.bat`**. The PowerShell launcher installs missing dependencies automatically, without editing or deleting any existing port listeners or processes.
3. It chooses the **first completely free matched set of ports**:
   - MIDAS: 4200+n
   - Calian Angular: 4300+n
   - Calian Node/Express backend: 8797+n
   - `n` ranges from 0 to 99, so if any default port is occupied, all three services move together to the next completely free set. The output shows the actual URLs.
4. Wait for **SUCCESS**. The script opens the new MIDAS `http://127.0.0.1:<selected-midas-port>/calian-ai` URL in your browser. All three new service windows stay open.
5. If another MIDAS/Calian is already running on ports 4200/4300/8797, **leave it running**. V4 chooses new ports (typically 4201/4301/8798) rather than asking you to find or stop the other processes.

**Example only:** When 4200/4300/8797 are already occupied, V4 could use MIDAS `http://127.0.0.1:4201/calian-ai`, Calian UI `http://127.0.0.1:4301/` and backend `http://127.0.0.1:8798`. The actual ports are selected after scanning your machine and printed in the console. Do not assume the example ports are free.

## What V4 changes technically

- MIDAS iframe address derives its Calian UI port from **its own browser port**: MIDAS `4200+n` embeds Calian `4300+n`. The iframe is maintained when the persistent Copilot panel closes and reopens.
- Calian's API **and** WebSocket (`/api`, `/ws`) are proxied by its own Angular dev server to its chosen backend using `CALIAN_BACKEND_PORT`. Browser requests use the Calian UI's own host; no fixed backend port is hardcoded in its SocketService.
- Calian backend origin checks for WebSocket, voice and video accept only the **matching local Calian UI origin** from `CALIAN_UI_ORIGIN` (plus existing backend/mobile allowances). Calian's MIDAS context bridge accepts the **corresponding local MIDAS origin**. These are development settings, not production authentication.
- V4 creates private launch commands and an `instance.json` record under `RUNS/<id>/` to keep track of ports and newly created console process IDs. **The launcher does not kill, alter, or reuse existing processes.** Re-running `START-EVERYTHING-WINDOWS.bat` starts another local port group if ports are free.
- MIDAS Angular 21 and Calian Angular 19 remain separately installed and separately served. Existing navigation, authorized MIDAS action approval, AI orchestration and video source are retained.

## Diagnostic controls

- `CHECK-STATUS-WINDOWS.bat` — lists past V4 run records and shows next available group; does not start or stop services.
- `VERIFY-LAST-RUN-WINDOWS.bat` — checks that MIDAS and Calian serve the V4 configuration and that the Calian HTTP/WebSocket proxy reaches the backend with the matching instance ID. Requires the services to be running.
- `INSTALL-ONLY-WINDOWS.bat` — installs dependencies without launching the applications.
- `node TOOLS/test-v4-port-mapping.cjs` — offline checks for port mapping, bridge origin pairing, proxy selection and launcher invariants; needs Node.js but no npm dependencies.
- `LOGS/` and `RUNS/` are created automatically on your Windows computer during setup. `instance.json` stores ports and process IDs only; it does **not** store passwords or credentials.

## Requirements and limitations

- Windows 10/11; PowerShell 5.1+; Node.js and npm; pnpm is installed by the script if missing. Some newer Angular versions require a recent compatible Node.js release.
- Installed `node_modules` are **not** included: the script runs `npm install` for Calian and `pnpm install --frozen-lockfile` for MIDAS only when necessary. It never needs you to run these manually merely because the ZIP is new.
- Private `@simfront` packages still require the user's **existing, authorized** Simfront Artifactory credentials, approved registry and network/VPN access. No private package credentials or secrets are bundled. The original lockfile is in `SETUP_SUPPORT/`. The V3 package's targeted lockfile URL correction is retained; integrity checks are not disabled.
- **Services are isolated by local ports, not by data or identity.** Several launches may still share the same Ollama, Python A2A, AI Core, RabbitMQ, MIDAS microservices, database or video gateway. Do not assume user/session or persistent-data isolation.
- The Copilot bridge is still a local development prototype. For employee/external invitee production use, add SSO, server-side authorization, audit logging, HTTPS, exact frame policy, allowed origins and robust session controls before deployment.
- The public video gateway and LiveKit, microphone/camera permissions, and AI agent dependencies still need their usual environment/configuration. This V4 change does not automatically provision them.
- If the Windows package installation or Angular compilation fails, note the **first actual error**. The script doesn't bypass dependency integrity errors or modify existing apps.
- Running multiple Angular development servers against the same extracted source tree can increase memory and CPU use. For maximum reproducibility, extract a second V4 copy when testing substantially different code versions.

## Verify the MIDAS Copilot

Once your new URL opens: choose **Advance Metrics Application**, open Calian AI Copilot, enable **Share dashboard context**, then say **Open Combat Power**. Approve the proposed action on the MIDAS side. Confirm both applications remain active. Also verify ordinary chat messages, automatic multi-agent routing, HTTP, WebSockets and video on the new ports.

## Package layout

```text
MIDAS_Calian_AI_Copilot_V4_Auto_Ports_Windows/
  START-EVERYTHING-WINDOWS.bat      <-- double-click to start a NEW instance
  SETUP-AND-RUN-WINDOWS.ps1         <-- auto install, scan ports, launch
  CHECK-STATUS-WINDOWS.bat         <-- inspect, does not kill anything
  VERIFY-LAST-RUN-WINDOWS.bat      <-- HTTP/WebSocket smoke test
  INSTALL-ONLY-WINDOWS.bat
  TOOLS/test-v4-port-mapping.cjs
  TOOLS/verify-last-run.cjs
  LOGS/                              (created at runtime)
  RUNS/                              (created at runtime)
  SETUP_SUPPORT/
  midas/midas-frontend/
  Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/
  Standalone_Calian_AI_Chatbot/VIDEO_CALL_SERVICE/
```

**Verification:** V4 configuration and source syntax can be checked offline, but a successful three-service Windows startup cannot be verified in this environment. The script checks the actual service URLs and matching backend instance IDs on your Windows machine; run the provided `VERIFY-LAST-RUN-WINDOWS.bat` after startup for more detailed checks.
