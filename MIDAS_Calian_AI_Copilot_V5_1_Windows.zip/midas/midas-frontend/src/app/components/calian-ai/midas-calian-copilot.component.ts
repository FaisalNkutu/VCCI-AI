import { Component, ElementRef, OnDestroy, OnInit, ViewChild, inject, signal } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { NavigationEnd, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Subscription, filter } from 'rxjs';
import { APP_PREF_KEY } from '@/app.guard';
import { sidebarActions } from '@/store/actions/sidebar.actions';
import { cpActions } from '@/store/actions/cp.actions';
import { selectMinMaxTime, selectSelectedTimeFormat, selectTimeFormatNames } from '@/store/features/sidebar.feature';
import { selectCpEntities, selectCpSelectedEntityIds, selectCpTimeframe } from '@/store/features/cp.feature';
import { routes as dashboardRoutes } from '@/utils/routes';
import { MidasCopilotUiState } from './midas-copilot-ui-state';

const BRIDGE = 'MIDAS_CALIAN_V1';
const dashboards: Record<string, string> = {
  summary: dashboardRoutes.SUM.route,
  'h-hour': dashboardRoutes.HH.route,
  rom: dashboardRoutes.ROM.route,
  poe: dashboardRoutes.POE.route,
  cm: dashboardRoutes.CM.route,
  fratricide: dashboardRoutes.FRAT.route,
  'enemy-engagement': dashboardRoutes.ENG.route,
  cp: dashboardRoutes.CP.route,
  'unit-watch': dashboardRoutes.UW.route,
  'holdings-rollup': dashboardRoutes.HR.route,
  c2: 'c2',
};

type ActionName = 'navigate' | 'time_format' | 'cp_time_range' | 'cp_select_entity';
interface ActionRequest {
  action: ActionName;
  params: Record<string, unknown>;
}
type BridgeEndpoint = 'frame' | 'popup';
interface PendingRequest { id: string; request: ActionRequest; description: string; source: BridgeEndpoint; }
interface SessionHandoff { id: string; from: BridgeEndpoint; to: BridgeEndpoint; snapshot?: unknown; }


function configuredUrl(): string | null {
  const value = (window as Window & { __MIDAS_CALIAN_EMBED_URL__?: string }).__MIDAS_CALIAN_EMBED_URL__;
  if (typeof value !== 'string' || !value.trim()) return null;
  try {
    const u = new URL(value);
    const local = u.hostname === 'localhost' || u.hostname === '127.0.0.1';
    if (!(u.protocol === 'https:' || (local && u.protocol === 'http:'))) return null;
    if (u.username || u.password || u.hash || u.search) return null;
    return u.href;
  } catch { return null; }
}

@Component({
  selector: 'app-midas-calian-copilot',
  standalone: true,
  styles: [`
    :host { display: contents; }
    .midas-copilot { display:flex; flex-direction:column; flex:0 0 auto; width:min(44vw,650px); min-width:350px; height:100%; color:#f4f8fc; background:#0c182a; border-left:1px solid #334155; }
    .midas-copilot.maximized { width:100%; min-width:0; }
    .midas-copilot.closed { display:none; }
    .popout-dock { position:fixed; bottom:18px; right:18px; z-index:100; background:#17263c; color:#f4f8fc; border:1px solid #64748b; border-radius:10px; box-shadow:0 8px 30px #0008; padding:12px; max-width:min(450px,94vw); display:flex; flex-wrap:wrap; gap:8px; align-items:center; font-size:13px; }
    .popout-dock button, .popout-approval button { border:1px solid #64748b; color:white; background:#243751; padding:5px 9px; border-radius:5px; cursor:pointer; }
    .popout-dock label { width:100%; }
    .popout-approval { position:fixed; z-index:120; bottom:125px; right:18px; max-width:min(460px,95vw); background:#3a2b19; color:white; padding:14px; border:2px solid #f59e0b; border-radius:8px; box-shadow:0 7px 26px #0008; font-size:14px; }
    .popout-approval p { overflow-wrap:anywhere; }
    .popout-approval button { margin-right:8px; }
    .popout-approval .accept { background:#115e59; }
    .popout-dock button:focus-visible, .popout-approval button:focus-visible { outline:3px solid #38bdf8; }
    .popout-note { font-size:12px; color:#fef3c7; width:100%; }

    .copilot-frame { width:100%; flex:1; min-height:0; border:0; background:#0c182a; }
    .copilot-toolbar { display:flex; align-items:center; gap:9px; padding:8px 12px; background:#17263c; flex-wrap:wrap; font-size:13px; }
    .copilot-toolbar button, .copilot-confirm button { border:1px solid #64748b; color:white; border-radius:5px; padding:5px 9px; background:#243751; cursor:pointer; }
    .copilot-toolbar button:focus-visible, .copilot-confirm button:focus-visible { outline:3px solid #38bdf8; }
    .copilot-confirm { padding:12px; border-bottom:1px solid #f59e0b; background:#3a2b19; font-size:13px; }
    .copilot-confirm p { margin:5px 0 10px; overflow-wrap:anywhere; }
    .copilot-confirm .accept { background:#115e59; }
    .badge { font-size:11px; opacity:.85; }
    .midas-fab { position:fixed; right:18px; top:14px; z-index:60; padding:9px 14px; background:#075b94; border:1px solid #7dd3fc; color:white; border-radius:6px; box-shadow:0 3px 12px #0005; }
    @media(max-width:900px){ .midas-copilot:not(.closed) { position:fixed; inset:0; z-index:70; width:100%; min-width:0; height:100dvh; } }
  `],
  template: `
    @if (!open() && !fullPage() && !popoutActive()) {
      <button type="button" class="midas-fab" (click)="show()" aria-label="Open Calian AI Copilot">Calian AI Copilot</button>
    }
    <aside class="midas-copilot" [class.closed]="popoutActive() || (!open() && !fullPage())" [class.maximized]="fullPage()" aria-label="Calian AI Copilot">
      <div class="copilot-toolbar">
        <strong>Calian AI · MIDAS Copilot</strong>
        <span class="badge" role="status">{{connected() ? 'Bridge connected' : 'Bridge disconnected'}}</span>
        <label title="Share only the current dashboard and control state with Calian agents">
          <input type="checkbox" [checked]="shareContext()" (change)="toggleSharing($event)" /> Share dashboard context
        </label>
        <button type="button" (click)="toggleFull()">{{ fullPage() ? 'Side panel' : 'Expand' }}</button>
        <button type="button" (click)="popOut()" title="Open in a separate movable, resizable browser window">Pop out ↗</button>
        @if (popupNotice() && !popoutActive()) { <span class="popout-note" role="status">{{popupNotice()}}</span> }
        <button type="button" (click)="switchWorkspace()">Workspaces</button>
        <button type="button" (click)="close()" aria-label="Close Calian Copilot">Close</button>
      </div>
      @if (pending(); as item) {
        <section class="copilot-confirm" role="alertdialog" aria-label="Approve requested MIDAS action" aria-modal="false">
          <strong>Approve MIDAS change?</strong>
          <p>{{item.description}}</p>
          <button type="button" class="accept" (click)="approve()">Approve</button>
          <button type="button" (click)="reject()">Decline</button>
        </section>
      }
      @if (trustedUrl) {
        <iframe #frame class="copilot-frame" [src]="trustedUrl" (load)="frameLoaded()"
          title="Calian AI embedded chatbot" referrerpolicy="strict-origin-when-cross-origin"
          allow="camera; microphone; fullscreen; display-capture" allowfullscreen></iframe>
      } @else {
        <p style="padding:20px">Configure an administrator-approved Calian URL in assets/calian-embed-config.js.</p>
      }
    </aside>
    @if (popoutActive()) {
      <section class="popout-dock" aria-label="Calian AI pop-out controls">
        <strong>Calian AI · Separate window</strong>
        <span class="badge" role="status">{{popoutConnected() ? 'Bridge connected' : 'Connecting…'}}</span>
        <label title="Opt in to share current MIDAS dashboard context">
          <input type="checkbox" [checked]="shareContext()" (change)="toggleSharing($event)" /> Share dashboard context
        </label>
        <button type="button" (click)="focusPopout()">Focus</button>
        <button type="button" (click)="resizePopout(900,650)">Compact</button>
        <button type="button" (click)="resizePopout(1100,800)">Standard</button>
        <button type="button" (click)="resizePopout(1400,900)">Large</button>
        <button type="button" (click)="centerPopout()">Center</button>
        <button type="button" (click)="dockPopout()">Dock in MIDAS</button>
        <span class="popout-note">Drag the pop-out title bar to move it; drag its edges to resize. Browser window controls may restrict automatic repositioning.</span>
        @if (popupNotice()) { <span class="popout-note" role="status">{{popupNotice()}}</span> }
      </section>
      @if (pending(); as item) {
        <section class="popout-approval" role="alertdialog" aria-label="Approve MIDAS action from Calian pop-out" aria-modal="false">
          <strong>Approve MIDAS change?</strong><p>{{item.description}}</p>
          <button type="button" class="accept" (click)="approve()">Approve</button>
          <button type="button" (click)="reject()">Decline</button>
        </section>
      }
    }
  `
})
export class MidasCalianCopilotComponent implements OnInit, OnDestroy {
  @ViewChild('frame') frame?: ElementRef<HTMLIFrameElement>;
  private readonly store = inject(Store);
  private readonly router = inject(Router);
  private readonly sanitizer = inject(DomSanitizer);
  private readonly subscriptions = new Subscription();
  private readonly url = configuredUrl();
  private readonly targetOrigin = this.url ? new URL(this.url).origin : null;
  private readonly token = crypto.randomUUID();
  private readonly popupToken = crypto.randomUUID();
  private popupWindow: Window | null = null;
  private popupWatcher?: ReturnType<typeof setInterval>;
  private handoff?: SessionHandoff;
  private handoffTimeout?: ReturnType<typeof setTimeout>;
  readonly popoutActive = signal(false);
  readonly popoutConnected = signal(false);
  readonly popupNotice = signal('');
  readonly trustedUrl: SafeResourceUrl | null = this.url ? this.sanitizer.bypassSecurityTrustResourceUrl(this.url) : null;
  private readonly uiState = inject(MidasCopilotUiState);
  readonly open = this.uiState.open;
  readonly fullPage = this.uiState.fullPage;
  readonly shareContext = signal(false); // User must opt in before any MIDAS state is shared.
  readonly connected = signal(false);
  readonly pending = signal<PendingRequest | null>(null);
  private lastRoute = '';

  ngOnInit(): void {
    this.routeChanged();
    this.subscriptions.add(this.router.events.pipe(filter(e => e instanceof NavigationEnd)).subscribe(() => {
      this.routeChanged();
      this.sendContext();
    }));
    // Each NgRx selector has its own observable type. Subscribing separately
    // avoids calling subscribe() on a union of incompatible overload signatures.
    this.subscriptions.add(this.store.select(selectSelectedTimeFormat).subscribe(() => this.sendContext()));
    this.subscriptions.add(this.store.select(selectTimeFormatNames).subscribe(() => this.sendContext()));
    this.subscriptions.add(this.store.select(selectCpTimeframe).subscribe(() => this.sendContext()));
    this.subscriptions.add(this.store.select(selectCpSelectedEntityIds).subscribe(() => this.sendContext()));
    this.subscriptions.add(this.store.select(selectCpEntities).subscribe(() => this.sendContext()));
    window.addEventListener('message', this.onMessage);
  }
  ngOnDestroy(): void {
    window.removeEventListener('message', this.onMessage);
    this.subscriptions.unsubscribe();
    if (this.popupWatcher) clearInterval(this.popupWatcher);
    if (this.handoffTimeout) clearTimeout(this.handoffTimeout);
    // A detached chat window can remain available if MIDAS is refreshed.
  }
  private routeChanged(): void {
    this.lastRoute = this.router.url.split('?')[0].split('#')[0];
    if (this.lastRoute === '/calian-ai' && !this.popoutActive()) { this.fullPage.set(true); this.open.set(true); }
    else this.fullPage.set(false);
  }
  show(): void { this.open.set(true); this.sendContext(); }
  switchWorkspace(): void {
    this.fullPage.set(false);
    this.open.set(false);
    this.shareContext.set(false);
    this.pending.set(null);
    localStorage.removeItem(APP_PREF_KEY);
    void this.router.navigateByUrl('/');
    this.sendContext();
  }
  close(): void {
    this.pending.set(null);
    this.shareContext.set(false);
    this.open.set(false);
    if (this.fullPage()) {
      this.fullPage.set(false);
      localStorage.setItem(APP_PREF_KEY, 'advmetrics');
      void this.router.navigateByUrl('/advmetrics');
    }
    this.sendContext();
  }
  toggleFull(): void {
    if (this.fullPage()) {
      this.fullPage.set(false);
      if (this.lastRoute === '/calian-ai') {
        localStorage.setItem(APP_PREF_KEY, 'advmetrics');
        void this.router.navigateByUrl('/advmetrics');
      }
    } else { this.fullPage.set(true); this.open.set(true); }
  }
  toggleSharing(event: Event): void {
    this.shareContext.set((event.target as HTMLInputElement).checked);
    this.pending.set(null);
    this.sendContext();
  }
  private isVisible(): boolean { return this.open() || this.fullPage() || this.popoutActive(); }
  private postTo(endpoint: BridgeEndpoint, type: string, body: Record<string, unknown> = {}): void {
    if (!this.targetOrigin) return;
    const target = endpoint === 'frame' ? this.frame?.nativeElement.contentWindow : this.popupWindow;
    if (!target || (endpoint === 'popup' && target.closed)) return;
    target.postMessage({ bridge: BRIDGE, type, ...body, token: endpoint === 'frame' ? this.token : this.popupToken }, this.targetOrigin);
  }
  private send(type: string, body: Record<string, unknown> = {}): void {
    this.postTo('frame', type, body);
    if (this.popoutActive()) this.postTo('popup', type, body);
  }
  /** Browser popups must be opened synchronously from the user's click. */
  popOut(): void {
    if (this.popupWindow && !this.popupWindow.closed) { this.focusPopout(); return; }
    if (!this.url) { this.popupNotice.set('Calian URL not configured.'); return; }
    const left = Math.max(0, Math.round(window.screenX + 65));
    const top = Math.max(0, Math.round(window.screenY + 50));
    const features = `popup=yes,resizable=yes,scrollbars=yes,width=1100,height=800,left=${left},top=${top}`;
    const popup = window.open(this.url, `CalianAI_${crypto.randomUUID().replaceAll('-', '')}`, features);
    if (!popup) { this.popupNotice.set('The browser blocked the pop-out. Allow pop-ups for MIDAS and try again.'); return; }
    this.popupWindow = popup;
    this.popoutConnected.set(false);
    this.popupNotice.set('Opening movable, resizable chat window…');
    this.popoutActive.set(true);
    this.open.set(false);
    this.fullPage.set(false);
    if (this.lastRoute === '/calian-ai') {
      localStorage.setItem(APP_PREF_KEY, 'advmetrics');
      void this.router.navigateByUrl('/advmetrics');
    }
    // Copy conversation/history only after the source agrees it is safe.
    if (this.connected()) this.beginHandoff('frame', 'popup');
    else this.popupNotice.set('New chat window opened. Embedded conversation was not connected for transfer.');
    popup.focus();
    if (this.popupWatcher) clearInterval(this.popupWatcher);
    this.popupWatcher = setInterval(() => {
      if (this.popupWindow?.closed) this.onPopoutClosed();
    }, 1000);
  }
  private onPopoutClosed(): void {
    if (this.popupWatcher) { clearInterval(this.popupWatcher); this.popupWatcher = undefined; }
    this.popupWindow = null;
    this.popoutActive.set(false);
    this.popoutConnected.set(false);
    this.cancelHandoff();
    this.pending.set(null);
    this.open.set(true);
    this.sendContext();
  }
  focusPopout(): void {
    if (!this.popupWindow || this.popupWindow.closed) { this.onPopoutClosed(); return; }
    this.popupWindow.focus();
  }
  resizePopout(width: number, height: number): void {
    if (!this.popupWindow || this.popupWindow.closed) { this.onPopoutClosed(); return; }
    try { this.popupWindow.resizeTo(width, height); this.popupWindow.focus(); }
    catch { this.popupNotice.set('Use the browser window edges to resize manually.'); }
  }
  centerPopout(): void {
    if (!this.popupWindow || this.popupWindow.closed) { this.onPopoutClosed(); return; }
    try {
      this.popupWindow.moveTo(Math.max(0,Math.round((screen.availWidth-1100)/2)), Math.max(0,Math.round((screen.availHeight-800)/2)));
      this.popupWindow.focus();
    } catch { this.popupNotice.set('Move the pop-out by dragging its title bar.'); }
  }
  dockPopout(): void {
    if (!this.popupWindow || this.popupWindow.closed) { this.onPopoutClosed(); return; }
    if (!this.popoutConnected()) { this.popupWindow.close(); this.onPopoutClosed(); return; }
    this.popupNotice.set('Moving the active chat back into MIDAS…');
    this.beginHandoff('popup', 'frame');
  }
  private beginHandoff(from: BridgeEndpoint, to: BridgeEndpoint): void {
    this.cancelHandoff();
    const id = crypto.randomUUID();
    this.handoff = { id, from, to };
    this.postTo(from, 'SESSION_EXPORT_REQUEST', { id });
    this.handoffTimeout = setTimeout(() => {
      if (this.handoff?.id === id) {
        const aborted = this.handoff.from === 'frame';
        this.cancelHandoff();
        if (aborted) { this.popupWindow?.close(); this.onPopoutClosed(); }
        this.popupNotice.set(aborted
          ? 'The chat could not be transferred safely; the embedded conversation was preserved.'
          : 'Chat transfer did not complete. The pop-out remains available; no conversation was deleted.');
      }
    }, 12000);
  }
  private cancelHandoff(): void {
    this.handoff = undefined;
    if (this.handoffTimeout) { clearTimeout(this.handoffTimeout); this.handoffTimeout = undefined; }
  }
  private tryImportHandoff(): void {
    const transfer = this.handoff;
    if (!transfer || !transfer.snapshot) return;
    if (transfer.to === 'popup' && !this.popoutConnected()) return;
    if (transfer.to === 'frame' && !this.connected()) return;
    this.postTo(transfer.to, 'SESSION_IMPORT', { id: transfer.id, snapshot: transfer.snapshot });
  }
  frameLoaded(): void {
    this.connected.set(false);
    this.postTo('frame', 'INIT', { capabilities: this.capabilities() });
    this.sendContext();
  }
  private capabilities(): Record<string, unknown> {
    return { dashboards: Object.keys(dashboards), actions: ['navigate','time_format','cp_time_range','cp_select_entity'], approvalRequired: true };
  }
  private context(): Record<string, unknown> | null {
    if (!this.shareContext() || !this.isVisible()) return null;
    const route = this.lastRoute === '/calian-ai' ? null : this.lastRoute;
    const onCP = route === '/advmetrics/cp';
    const entities = onCP ? this.store.selectSignal(selectCpEntities)().slice(0, 40).map(e => ({ id: e.id, name: e.name })) : [];
    return {
      route,
      selectedTimeFormat: this.store.selectSignal(selectSelectedTimeFormat)(),
      availableTimeFormats: this.store.selectSignal(selectTimeFormatNames)().slice(0, 40),
      ...(onCP ? {
        cpTimeframe: this.store.selectSignal(selectCpTimeframe)(),
        cpSelectedEntityIds: this.store.selectSignal(selectCpSelectedEntityIds)().slice(0, 100),
        cpEntities: entities,
      } : {}),
    };
  }
  private sendContext(): void {
    this.send('CONTEXT', { sharing: this.shareContext() && this.isVisible(), context: this.context() });
  }
  private onMessage = (event: MessageEvent): void => {
    if (!this.targetOrigin || event.origin !== this.targetOrigin) return;
    const source: BridgeEndpoint | null = event.source === this.frame?.nativeElement.contentWindow
      ? 'frame' : (this.popoutActive() && event.source === this.popupWindow ? 'popup' : null);
    if (!source) return;
    const data = event.data;
    if (!data || typeof data !== 'object' || data.bridge !== BRIDGE || typeof data.type !== 'string') return;
    if (data.type === 'HELLO') {
      if (source === 'popup') this.popoutConnected.set(true);
      else this.connected.set(true);
      this.postTo(source, 'INIT', { capabilities: this.capabilities() });
      this.sendContext();
      this.tryImportHandoff();
      return;
    }
    if (data.token !== (source === 'frame' ? this.token : this.popupToken)) return;
    // A valid origin, source window and session token prove the endpoint
    // acknowledged INIT. The iframe load event can otherwise overwrite the
    // earlier HELLO status, leaving the badge incorrectly disconnected.
    if (source === 'frame' && !this.connected()) this.connected.set(true);
    if (source === 'popup' && !this.popoutConnected()) this.popoutConnected.set(true);
    if (data.type === 'SESSION_EXPORT_ERROR' && this.handoff?.from === source && data.id === this.handoff.id) {
      const aborted = this.handoff.from === 'frame';
      const message = String(data.message || 'The current chat cannot be transferred.').slice(0,220);
      this.cancelHandoff();
      if (aborted) { this.popupWindow?.close(); this.onPopoutClosed(); }
      this.popupNotice.set(message);
      return;
    }
    if (data.type === 'SESSION_EXPORT_RESPONSE' && this.handoff?.from === source && data.id === this.handoff.id) {
      try {
        const raw = JSON.stringify(data.snapshot);
        if (raw.length > 210000 || !data.snapshot || typeof data.snapshot !== 'object') throw new Error('Snapshot too large or invalid');
        this.handoff.snapshot = data.snapshot as unknown;
        this.tryImportHandoff();
      } catch {
        this.popupNotice.set('Chat transfer payload could not be validated.');
        this.cancelHandoff();
      }
      return;
    }
    if (data.type === 'SESSION_IMPORTED' && this.handoff?.to === source && data.id === this.handoff.id) {
      const isDock = this.handoff.to === 'frame';
      this.cancelHandoff();
      if (isDock) {
        const popup = this.popupWindow;
        popup?.close();
        this.onPopoutClosed();
        this.popupNotice.set('Chat restored in MIDAS.');
      } else this.popupNotice.set('Chat session transferred to the pop-out.');
      return;
    }
    if (data.type === 'CONTEXT_REQUEST') { this.sendContext(); return; }
    if (data.type !== 'ACTION_REQUEST') return;
    if (!this.shareContext() || !this.isVisible()) { this.reply(String(data.id || ''), false, 'Turn on Share dashboard context first.', source); return; }
    const id = data.id;
    if (typeof id !== 'string' || !/^[a-zA-Z0-9-]{1,80}$/.test(id)) return;
    const request = this.validateRequest(data.action, data.params);
    if (!request) { this.reply(id, false, 'Unsupported or invalid MIDAS action.', source); return; }
    if (this.pending()) { this.reply(id, false, 'Another action is awaiting approval.', source); return; }
    this.pending.set({ id, request, source, description: this.describe(request) });
  };
  private validateRequest(action: unknown, params: unknown): ActionRequest | null {
    if (!params || typeof params !== 'object' || Array.isArray(params)) return null;
    const p = params as Record<string, unknown>;
    if (action === 'navigate' && typeof p['dashboard'] === 'string' && Object.hasOwn(dashboards, p['dashboard'])) return { action, params: { dashboard: p['dashboard'] } };
    if (action === 'time_format' && typeof p['name'] === 'string' && this.store.selectSignal(selectTimeFormatNames)().includes(p['name'])) return { action, params: { name: p['name'] } };
    if (action === 'cp_time_range' && this.lastRoute === '/advmetrics/cp' && typeof p['start'] === 'number' && typeof p['end'] === 'number') {
      const minMax = this.store.selectSignal(selectMinMaxTime)();
      if (minMax && Number.isFinite(p['start']) && Number.isFinite(p['end']) && p['start'] >= minMax.minTime && p['end'] <= minMax.maxTime && p['start'] < p['end']) return { action, params: { start: p['start'], end: p['end'] } };
    }
    if (action === 'cp_select_entity' && this.lastRoute === '/advmetrics/cp' && typeof p['id'] === 'number' && Number.isSafeInteger(p['id'])) {
      if (this.store.selectSignal(selectCpEntities)().some(e => e.id === p['id'])) return { action, params: { id: p['id'], selected: p['selected'] !== false } };
    }
    return null;
  }
  private describe(r: ActionRequest): string {
    const p = r.params;
    if (r.action === 'navigate') return `Navigate MIDAS to the ${String(p['dashboard'])} dashboard.`;
    if (r.action === 'time_format') return `Set MIDAS time format to ${String(p['name'])}.`;
    if (r.action === 'cp_time_range') return `Set Combat Power timeframe to ${p['start']}–${p['end']} (MIDAS native time units).`;
    return `${p['selected'] ? 'Select' : 'Deselect'} Combat Power entity ${p['id']}.`;
  }
  private reply(id: string, ok: boolean, message: string, source: BridgeEndpoint): void { this.postTo(source, 'ACTION_RESULT', { id, ok, message }); }
  async approve(): Promise<void> {
    const item = this.pending();
    if (!item) return;
    this.pending.set(null);
    // Revalidate against the latest route and store state before applying changes.
    const request = this.validateRequest(item.request.action, item.request.params);
    if (!request || !this.isVisible() || !this.shareContext()) { this.reply(item.id, false, 'Action no longer valid.', item.source); return; }
    const p = request.params;
    try {
      switch (request.action) {
        case 'navigate': {
          const success = await this.router.navigateByUrl(`/advmetrics/${dashboards[String(p['dashboard'])]}`);
          this.reply(item.id, success, success ? 'MIDAS navigated successfully.' : 'Navigation was rejected by the router.', item.source);
          break;
        }
        case 'time_format':
          this.store.dispatch(sidebarActions.timeFormatSelected(String(p['name'])));
          this.reply(item.id, true, 'MIDAS time format updated.', item.source);
          break;
        case 'cp_time_range':
          this.store.dispatch(cpActions.timeframeChange({ start: Number(p['start']), end: Number(p['end']) }));
          this.reply(item.id, true, 'Combat Power time range updated.', item.source);
          break;
        case 'cp_select_entity': {
          const id = Number(p['id']);
          const present = this.store.selectSignal(selectCpSelectedEntityIds)().includes(id);
          if (Boolean(p['selected']) !== present) this.store.dispatch(Boolean(p['selected']) ? cpActions.entitySelected(id) : cpActions.entityDeselected(id));
          this.reply(item.id, true, 'Combat Power entity selection updated.', item.source);
          break;
        }
      }
      this.sendContext();
    } catch {
      this.reply(item.id, false, 'MIDAS could not complete that action.', item.source);
    }
  }
  reject(): void {
    const item = this.pending();
    this.pending.set(null);
    if (item) this.reply(item.id, false, 'The MIDAS action was declined.', item.source);
  }
}
