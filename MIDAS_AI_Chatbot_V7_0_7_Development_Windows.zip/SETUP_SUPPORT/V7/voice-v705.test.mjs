import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {stripTypeScriptTypes} from 'node:module';
const app=new URL('../../Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/src/app/',import.meta.url);
const helper=new URL('hands-free-commands.ts',app);
const {voiceNoise,confirmationCommand}=await import(helper.href);
const source=readFileSync(new URL('app.component.ts',app),'utf8');
// Execute actual component command methods in a minimal harness, without Angular or browser APIs.
const methods=source.slice(source.indexOf(' private async handleVoiceCommand('),source.indexOf(' private voiceSessionId='));
const harness=`import {voiceCommand,voiceNoise,confirmationCommand,replacementQuestion} from ${JSON.stringify(helper.href)};
export class VoiceHarness {
 handsFree=true;voicePending='';prompt='';lastVoicePlayback='';voiceAutoSubmit=false;busy=false;voiceActive=false;voiceProcessing=false;speechPlaying=false;history=[];sent=[];said=[];schedules=0;
 sayVoice(s){this.lastVoicePlayback=s;this.said.push(s);this.scheduleVoice();}
 scheduleVoice(){this.schedules++;} stopHandsFree(){this.handsFree=false;this.voicePending='';}
 readReply(t){this.sayVoice(t.content);}
 async send(){if(this.busy||this.voiceActive||this.voiceProcessing)return;this.sent.push(this.prompt);this.history.push({role:'user',content:this.prompt},{role:'assistant',content:'Returned 100 records.'});this.prompt='';}
 ${methods}
}`;
const {VoiceHarness}=await import('data:text/javascript;base64,'+Buffer.from(stripTypeScriptTypes(harness)).toString('base64'));
const query='Select all records from table contxt_oi_assoc.';
test('noise markers and playback prompts are ignored, but normal requests are not',()=>{
 for(const t of ['[Music playing]','♪ Music ♪','(silence)','[BLANK_AUDIO]','Thanks for watching.','I heard, select all records'])assert.ok(voiceNoise(t,'I heard: '+query));
 assert.equal(voiceNoise('Find music playing in the background'),false);
});
test('short commands allow punctuation and polite variations without accepting arbitrary phrases',()=>{
 for(const t of ['Send.','Please, send it.','Submit the query','Send now','Confirm and send'])assert.equal(confirmationCommand(t),'send');
 for(const t of ['Send me a message','Send all records','Sent','music playing'])assert.equal(confirmationCommand(t),null);
});
test('reported music loop retains the exact query and Send dispatches it once',async()=>{
 const v=new VoiceHarness();await v.handleVoiceCommand(query);await v.handleVoiceCommand('music playing');await v.handleVoiceCommand('random background words');
 assert.equal(v.prompt,query);assert.equal(v.voicePending,query);assert.deepEqual(v.sent,[]);
 await v.handleVoiceCommand('Send.');await v.handleVoiceCommand('Send.');assert.deepEqual(v.sent,[query]);assert.equal(v.voicePending,'');assert.ok(v.schedules>0);assert.ok(v.said.includes('Returned 100 records.'));
});
test('echo of entire confirmation is ignored',async()=>{const v=new VoiceHarness();await v.handleVoiceCommand(query);await v.handleVoiceCommand(v.lastVoicePlayback);assert.equal(v.prompt,query);assert.deepEqual(v.sent,[]);});
test('explicit replacement changes the pending question; cancel never submits',async()=>{const v=new VoiceHarness();await v.handleVoiceCommand(query);await v.handleVoiceCommand('Replace question Count records from table X');assert.equal(v.prompt,'Count records from table X');await v.handleVoiceCommand('Cancel.');assert.equal(v.prompt,'');assert.deepEqual(v.sent,[]);});
test('failed dispatch retains the pending question and can retry',async()=>{const v=new VoiceHarness();await v.handleVoiceCommand(query);const send=v.send;v.send=async()=>{};await v.handleVoiceCommand('Send');assert.equal(v.voicePending,query);v.send=send;await v.handleVoiceCommand('Send');assert.deepEqual(v.sent,[query]);});
test('auto-submit is opt-in, ignores music, and uses the same dispatcher',async()=>{const v=new VoiceHarness();v.voiceAutoSubmit=true;await v.handleVoiceCommand('[music playing]');await v.handleVoiceCommand(query);assert.deepEqual(v.sent,[query]);});
test('stop listening prevents pending submission',async()=>{const v=new VoiceHarness();await v.handleVoiceCommand(query);await v.handleVoiceCommand('Stop listening.');assert.equal(v.handsFree,false);assert.deepEqual(v.sent,[]);});
test('recovery guards present in capture/playback path',()=>{for(const guard of ['speechWatchdog','this.voiceAbort?.abort()','this.voiceSessionId===sessionId','this.voiceFailures>=3','this.voicePending?0.010:0.015','this.scheduleVoice();}else void this.stopVoice()'])assert.ok(source.includes(guard),guard);});
