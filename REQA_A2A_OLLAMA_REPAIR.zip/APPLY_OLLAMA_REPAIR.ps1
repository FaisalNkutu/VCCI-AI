$ErrorActionPreference = 'Stop'
$container = 'reqa-a2a'
$target = '/app/agent/llm/ollama_llm.py'
$root = $PSScriptRoot
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backupDir = Join-Path $HOME 'Downloads\REQA-A2A-Backups'
$out = Join-Path $HOME "Downloads\REQA_A2A_OLLAMA_REPAIR_$timestamp.txt"
New-Item -Path $backupDir -ItemType Directory -Force | Out-Null

function Step($description) { Write-Host "`n$description" -ForegroundColor Cyan }
function Invoke-DockerChecked([string[]]$Arguments) {
    & docker.exe @Arguments
    if ($LASTEXITCODE -ne 0) { throw "Docker command failed ($LASTEXITCODE): $($Arguments -join ' ')" }
}

try {
    Step '[1/5] Checking running A2A container'
    $running = (& docker inspect -f '{{.State.Running}}' $container 2>$null)
    if ($LASTEXITCODE -ne 0 -or $running -ne 'true') { throw 'reqa-a2a is not running; no files changed.' }

    Step '[2/5] Backing up current Ollama Python source'
    $backup = Join-Path $backupDir "ollama_llm-before-repair-$timestamp.py"
    Invoke-DockerChecked @('cp',"${container}:${target}",$backup)
    Write-Host "BACKUP SAVED: $backup" -ForegroundColor Green

    Step '[3/5] Repairing response variable and missing-model fallback'
    $patcher = Join-Path $root 'patch_ollama.py'
    if (-not (Test-Path $patcher)) { throw "Installer companion file not found: $patcher" }
    Invoke-DockerChecked @('cp',$patcher,"${container}:/tmp/reqa_patch_ollama.py")
    Invoke-DockerChecked @('exec',$container,'python','/tmp/reqa_patch_ollama.py')
    Invoke-DockerChecked @('exec',$container,'python','-m','py_compile',$target)
    Write-Host 'PATCH AND PYTHON SYNTAX: SUCCESS' -ForegroundColor Green

    Step '[4/5] Restarting A2A'
    Invoke-DockerChecked @('restart',$container)
    $ready = $false
    for ($i=0; $i -lt 20; $i++) {
        try {
            $null = Invoke-WebRequest -Uri 'http://127.0.0.1:5022/.well-known/agent-card.json' -UseBasicParsing -TimeoutSec 3
            $ready = $true; break
        } catch {
            if ($_.Exception.Response) { $ready = $true; break }
            Start-Sleep -Seconds 2
        }
    }
    if (-not $ready) { throw 'A2A server did not become reachable after restart. Backup retained.' }
    Write-Host 'A2A SERVER REACHABLE' -ForegroundColor Green

    Step '[5/5] Running read-only SQL test (may take up to 180 seconds)'
    $payload = @{
        jsonrpc='2.0'; id=[guid]::NewGuid().ToString(); method='message/send'
        params=@{message=@{role='user'; messageId=[guid]::NewGuid().ToString(); parts=@(@{kind='text'; text='SELECT * FROM contxt_oi_assoc LIMIT 1'})}}
    } | ConvertTo-Json -Depth 10
    $report = New-Object System.Collections.Generic.List[string]
    $report.Add("Generated: $(Get-Date -Format o)")
    $report.Add('Query: SELECT * FROM contxt_oi_assoc LIMIT 1')
    try {
        $r = Invoke-RestMethod -Uri 'http://127.0.0.1:5022/' -Method POST -ContentType 'application/json' -Body $payload -TimeoutSec 180
        $report.Add('HTTP: 200')
        $report.Add("A2A task state: $($r.result.status.state)")
        $message = $null
        foreach ($a in @($r.result.artifacts)) {
            foreach ($p in @($a.parts)) { if ($p.kind -eq 'text' -and $p.text) { $message = $p.text; break } }
            if ($message) { break }
        }
        if ($message) {
            try {
                $j = $message | ConvertFrom-Json
                $report.Add("Pipeline success: $($j.Success)")
                $report.Add("Rows returned: $($j.Response.row_count)")
                $report.Add("Pipeline error: $($j.Response.error)")
                $report.Add("Answer: $($j.Response.answer)")
                if ($j.Success -eq $true -or $j.Response.success -eq $true) {
                    Write-Host 'SUCCESS: SQL pipeline returned a successful result' -ForegroundColor Green
                } else {
                    Write-Host "A2A request completed, but SQL pipeline reported: $($j.Response.error)" -ForegroundColor Yellow
                }
            } catch {
                $report.Add('Response text (first 1000 chars): ' + $message.Substring(0,[Math]::Min(1000,$message.Length)))
            }
        } else {
            $report.Add('No text artifact in A2A result')
        }
    } catch {
        $report.Add("REQUEST ERROR: $($_.Exception.Message)")
        Write-Host "SQL test failed: $($_.Exception.Message)" -ForegroundColor Yellow
    }
    $report.Add('---- Relevant recent container diagnostics ----')
    $logLines = (& cmd.exe /d /c "docker logs --tail 120 reqa-a2a 2>&1" | Out-String).Split("`n")
    foreach ($ln in ($logLines | Where-Object { $_ -match 'SQL pipeline END|Configured Ollama model|Ollama request failed|not found|name .resp.|ERROR -|Traceback|model.*unavailable' } | Select-Object -Last 20)) {
        $report.Add($ln.TrimEnd())
    }
    $report | Out-File -FilePath $out -Encoding utf8
    Write-Host "RESULT FILE: $out" -ForegroundColor Green
} catch {
    Write-Host "FAILED: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host 'Your original Python source remains in Downloads\REQA-A2A-Backups.' -ForegroundColor Yellow
}
