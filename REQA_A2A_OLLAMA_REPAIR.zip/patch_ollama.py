"""Patch only the A2A container's Ollama backend, with a guarded fallback.

The PowerShell installer backs up the original source before invoking this file.
"""
from pathlib import Path
import ast
import re
import sys

TARGET = Path('/app/agent/llm/ollama_llm.py')
SENTINEL = 'REQA_MODEL_FALLBACK_FIX_V1'

FALLBACK = r'''
        # REQA_MODEL_FALLBACK_FIX_V1: use an already installed model if the
        # configured model has been removed or is unavailable on this server.
        if response.status_code == 404 and 'model' in response.text.lower():
            try:
                tags_url = self._url.rsplit('/api/chat', 1)[0] + '/api/tags'
                tags_response = requests.get(tags_url, timeout=12)
                tags_response.raise_for_status()
                available = {
                    m.get('name') for m in tags_response.json().get('models', [])
                    if isinstance(m, dict) and isinstance(m.get('name'), str)
                }
                # Prefer SQL-oriented models, then the proven local fallback.
                preference = (
                    'sqlcoder:latest', 'sqlcoder',
                    'codestral:latest', 'codestral',
                    'a-kore/Arctic-Text2SQL-R1-7B:latest',
                    'llama3.2:latest', 'llama3.2',
                    'llama3.1:8b', 'mistral:latest', 'mistral',
                )
                fallback_model = next((name for name in preference if name in available), None)
                if fallback_model is None and available:
                    fallback_model = sorted(available)[0]
                if fallback_model and fallback_model != self.model:
                    logger.warning('Configured Ollama model %s unavailable; retrying with installed model %s', self.model, fallback_model)
                    request_body['model'] = fallback_model
                    response = requests.post(self._url, json=request_body, timeout=400)
                    if response.ok:
                        self.model = fallback_model
                elif not available:
                    logger.error('Ollama reported no installed models; cannot recover missing model %s', self.model)
            except requests.RequestException as model_error:
                logger.error('Unable to discover available Ollama models: %s', model_error)
'''

def main():
    if not TARGET.is_file():
        raise SystemExit(f'ERROR: expected A2A Ollama source not present: {TARGET}')
    old = TARGET.read_text(encoding='utf-8')
    fixed = old
    if 'resp.status_code' not in fixed and SENTINEL not in fixed:
        raise SystemExit('ERROR: Source differs from inspected version. No changes made.')
    fixed = fixed.replace('resp.status_code', 'response.status_code')
    fixed = fixed.replace('resp.text[:1000]', 'response.text[:1000]')

    if SENTINEL not in fixed:
        # Match the first _complete HTTP call, before its response-processing try block.
        marker = re.search(r'(?m)^        response = requests\.post\(\s*$', fixed)
        if not marker:
            raise SystemExit('ERROR: HTTP call anchor not found. No changes made.')
        try_block = re.search(r'(?m)^        try:\s*$', fixed[marker.end():])
        if not try_block:
            raise SystemExit('ERROR: response handling anchor not found. No changes made.')
        insert = marker.end() + try_block.start()
        fixed = fixed[:insert] + FALLBACK + '\n' + fixed[insert:]

    try:
        ast.parse(fixed, filename=str(TARGET))
    except SyntaxError as e:
        raise SystemExit(f'ERROR: Patch did not pass syntax verification: {e}')
    if fixed != old:
        TARGET.write_text(fixed, encoding='utf-8')
        print('PATCH INSTALLED: model fallback + undefined response variable repaired')
    else:
        print('ALREADY INSTALLED: no changes necessary')
    print('SYNTAX VERIFIED: ' + str(TARGET))

if __name__ == '__main__':
    main()
