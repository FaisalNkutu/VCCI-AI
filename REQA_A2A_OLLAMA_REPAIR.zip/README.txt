REQA A2A Ollama model error repair, 2026-11-15

Fixes two problems observed in REQA_A2A_FOCUSED_TEST_RESULTS.txt:
1. In /app/agent/llm/ollama_llm.py the exception handler uses undefined variable resp.
2. The configured a-kore/Arctic-Text2SQL-R1-7B:latest Ollama model is unavailable.

The fix backs up the Python source, patches the undefined variable, and only on a
missing-model HTTP 404 automatically retries with an already-installed Ollama
model (preferring SQL models and then llama3.2). It restarts reqa-a2a and runs
a read-only A2A SQL query. It does NOT edit your .env, Java, Electron, or Git.

Extract the ZIP and in PowerShell run this command from the extracted folder:

powershell -NoProfile -ExecutionPolicy Bypass -File .\APPLY_OLLAMA_REPAIR.ps1

Watch the status messages. If the SQL pipeline still fails, upload the file
Downloads\REQA_A2A_OLLAMA_REPAIR_*.txt. Restoring source from the backup will
undo the hot patch; recreating the Docker container may also discard it.

Important: The original test SQL named context_ol_assoc; the schema evidence
instead uses contxt_oi_assoc. The installer tests that documented spelling.
