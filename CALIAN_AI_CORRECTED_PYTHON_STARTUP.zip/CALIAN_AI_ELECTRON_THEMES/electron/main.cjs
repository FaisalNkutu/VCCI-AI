const {app,BrowserWindow,dialog}=require('electron');
const {spawn}=require('node:child_process');
const path=require('node:path');
const fs=require('node:fs');
let backend;
let pythonRouter;
const dev=!app.isPackaged;
function startPythonRouter(){
 if(dev)return;
 const executable=path.join(process.resourcesPath,'python-router','calian-router.exe');
 if(!fs.existsSync(executable)){
  dialog.showErrorBox('Python router missing','This package does not contain python-router/calian-router.exe. Rebuild using BUILD-CALIAN-WINDOWS.bat.');
  throw new Error('Bundled Python router missing');
 }
 pythonRouter=spawn(executable,[],{cwd:path.dirname(executable),env:{...process.env,OLLAMA_ENABLED:'true',OLLAMA_URL:process.env.OLLAMA_URL||'http://127.0.0.1:11434',OLLAMA_MODEL:process.env.OLLAMA_MODEL||'llama3.2:latest',PORT:'9999'},windowsHide:true,stdio:'ignore'});
 pythonRouter.on('error',e=>dialog.showErrorBox('Python router startup failed',e.message));
}
function startBackend(){if(dev)return;
 const executable=process.execPath;
 const script=path.join(app.getAppPath(),'dist','backend.cjs');
 const staticDir=path.join(app.getAppPath(),'dist','calian','browser');
 backend=spawn(executable,[script],{env:{...process.env,ELECTRON_RUN_AS_NODE:'1',CALIAN_STATIC_DIR:staticDir,PORT:'8797'},stdio:'ignore',windowsHide:true});
 backend.on('error',e=>dialog.showErrorBox('Backend startup failed',e.message));
}
async function waitBackend(){for(let i=0;i<80;i++){try{const r=await fetch('http://127.0.0.1:8797/api/health');if(r.ok)return;}catch{}await new Promise(r=>setTimeout(r,250));}throw new Error('Backend did not start on port 8797');}
app.whenReady().then(async()=>{try{startPythonRouter();startBackend();await waitBackend();const win=new BrowserWindow({width:1440,height:920,minWidth:950,minHeight:650,backgroundColor:'#111827',webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}});await win.loadURL(dev?'http://127.0.0.1:4300':'http://127.0.0.1:8797');}catch(e){dialog.showErrorBox('CALIAN AI startup',String(e));app.quit();}});
app.on('window-all-closed',()=>app.quit());
app.on('before-quit',()=>{if(backend)backend.kill();if(pythonRouter)pythonRouter.kill();});
