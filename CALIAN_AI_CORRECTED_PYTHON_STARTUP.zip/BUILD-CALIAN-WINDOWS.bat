@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>&1 || (echo Python is required on the BUILD computer. & pause & exit /b 1)
python -m pip install -r "PYTHON_BACKEND\requirements-local.txt" pyinstaller || (pause & exit /b 1)
cd /d "%~dp0PYTHON_BACKEND"
python -m PyInstaller --noconfirm --clean --onefile --name calian-router --collect-all fastapi --collect-all uvicorn main.py || (pause & exit /b 1)
cd /d "%~dp0CALIAN_AI_ELECTRON_THEMES"
if not exist node_modules (call npm install || (pause & exit /b 1))
call npm run dist:win || (pause & exit /b 1)
echo SUCCESS: See CALIAN_AI_ELECTRON_THEMES\release
pause
