@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0CALIAN_AI_ELECTRON_THEMES" || (echo ERROR: Source folder missing. & pause & exit /b 1)
where node >nul 2>&1 || (echo ERROR: Node.js LTS is required on the BUILD PC only. & pause & exit /b 1)
where npm >nul 2>&1 || (echo ERROR: npm not found on the build PC. & pause & exit /b 1)

echo ==============================================
echo  CALIAN.AI V8 - SINGLE PORTABLE EXE BUILD
 echo  This build keeps existing video, speech and SQL fixes.
echo ==============================================
echo.
call npm install --no-audit --no-fund
if errorlevel 1 (echo ERROR: Dependency installation failed. & pause & exit /b 1)
echo Checking SQL-vs-English routing before building the executable...
node server\test-select-english-routing.cjs
if errorlevel 1 (echo ERROR: Speech-to-SQL routing regression. Build stopped to protect the working version. & pause & exit /b 1)
echo Checking multiple named rooms and single-room camera publishing...
node scripts\test-multi-room-management.cjs
if errorlevel 1 (echo ERROR: Multi-room checks failed. & pause & exit /b 1)
node scripts\test-multi-room-behavior.cjs
if errorlevel 1 (echo ERROR: Multi-room behavior checks failed. & pause & exit /b 1)
echo Checking 10-person group meeting integration...
node scripts\verify-group-call-routing.cjs
if errorlevel 1 (echo ERROR: Group meeting checks failed. & pause & exit /b 1)
echo Checking that an older public video gateway is rejected for group calls...
node scripts\test-group-gateway-compatibility.cjs
if errorlevel 1 (echo ERROR: Video gateway compatibility check failed. & pause & exit /b 1)
call npm run dist:win
if errorlevel 1 (echo ERROR: Windows executable build failed. & pause & exit /b 1)

set "DEST=%~dp0DELIVER_TO_FOUAD"
if not exist "!DEST!" mkdir "!DEST!"
if errorlevel 1 (echo ERROR: Cannot create distribution folder. & pause & exit /b 1)
if exist "!DEST!\CALIAN.AI.exe" del /f /q "!DEST!\CALIAN.AI.exe"
set "FOUND="
for %%F in ("release\*.exe") do (
 if exist "%%~fF" (
  copy /y "%%~fF" "!DEST!\CALIAN.AI.exe" >nul
  if errorlevel 1 (echo ERROR: Failed to copy executable. & pause & exit /b 1)
  set "FOUND=1"
 )
)
if not defined FOUND (echo ERROR: No Windows executable was produced. & pause & exit /b 1)
echo.
echo SUCCESS: Give Fouad ONLY this file:
echo   !DEST!\CALIAN.AI.exe
echo.
echo On first launch, CALIAN.AI.exe creates calian.env automatically
 echo next to the portable executable (or in AppData if that folder is read-only).
echo No .bat, .env, node_modules, or source code needs to accompany the EXE.
echo Note: Existing Docker/REQA/A2A/Ollama/Whisper and public video services
 echo must still be available separately where those features are used.
echo.
pause
endlocal
