const {app,BrowserWindow,dialog,ipcMain,Menu}=require('electron');
const {spawn}=require('node:child_process');
const net=require('node:net');
const {randomUUID}=require('node:crypto');
const path=require('node:path');
const fs=require('node:fs');

let backend;
let backendStartupError=null;
let settingsWindow=null;
const startupLog=path.join(app.getPath('userData'),'backend-startup.log');
const dev=!app.isPackaged;
const instanceId=randomUUID();

function readConfig(file){
 if(!fs.existsSync(file))return {};
 const result={};
 for(const line of fs.readFileSync(file,'utf8').split(/\r?\n/)){
  const m=line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
  if(!m)continue;
  let value=m[2];
  if((value.startsWith('"')&&value.endsWith('"'))||(value.startsWith("'")&&value.endsWith("'")))value=value.slice(1,-1);
  result[m[1]]=value;
 }
 return result;
}

// With electron-builder's portable target, process.execPath is the temporary
// extracted Electron executable. Store calian.env beside the ORIGINAL .exe.
const portableExecutableDir = process.env.PORTABLE_EXECUTABLE_DIR ||
 (process.env.PORTABLE_EXECUTABLE_FILE ? path.dirname(process.env.PORTABLE_EXECUTABLE_FILE) : path.dirname(process.execPath));
const portableConfigFile = path.join(portableExecutableDir,'calian.env');
const userDataConfigFile = path.join(app.getPath('userData'),'calian.env');
let activeConfigFile=null;

function defaultConfiguration(){
 return [
  '# CALIAN.AI V8 - created automatically by the portable EXE on first launch.',
  '# This file belongs to this machine. Do not share it if it contains credentials.',
  '# CALIAN_SCHEMA_DATABASE: leave blank to discover automatically, or choose a schema.',
  'CALIAN_SCHEMA_DATABASE=',
  'PYTHON_SERVICE_URL=http://127.0.0.1:9999',
  'OLLAMA_URL=http://127.0.0.1:11434',
  'REQA_API_URL=http://127.0.0.1:8080',
  'CALIAN_SQL_DOCKER_CONTAINER=reqa-api',
  '# A separate public HTTPS video service is necessary for worldwide guest calls.',
  'CALIAN_VIDEO_PUBLIC_ORIGIN=',
  '# Configure CALIAN_VIDEO_ADMIN_KEY only after deploying the separate video service.',
  'CALIAN_VIDEO_ADMIN_KEY=',
  ''
 ].join('\r\n');
}

function initializePortableConfig(){
 // Never overwrite someone's existing, working calian.env.
 if(fs.existsSync(portableConfigFile))return {file:portableConfigFile,created:false};
 if(fs.existsSync(userDataConfigFile))return {file:userDataConfigFile,created:false};
 const text=defaultConfiguration();
 try{
  fs.writeFileSync(portableConfigFile,text,{flag:'wx',mode:0o600});
  return {file:portableConfigFile,created:true};
 }catch(e){
  if(e.code==='EEXIST')return {file:portableConfigFile,created:false};
  if(!['EACCES','EPERM','EROFS','ENOENT'].includes(e.code))throw e;
 }
 // Program Files or other locked-down locations may not be writable.
 fs.mkdirSync(path.dirname(userDataConfigFile),{recursive:true});
 try{
  fs.writeFileSync(userDataConfigFile,text,{flag:'wx',mode:0o600});
  return {file:userDataConfigFile,created:true};
 }catch(e){
  if(e.code==='EEXIST')return {file:userDataConfigFile,created:false};
  throw e;
 }
}

function loadConfig(){
 // Portable config must take precedence over the temporary extracted copy.
 return {
  ...readConfig(path.join(app.getAppPath(),'.env')),
  ...readConfig(path.join(path.dirname(process.execPath),'calian.env')),
  ...readConfig(userDataConfigFile),
  ...process.env,
  ...readConfig(portableConfigFile)
 };
}

const editableKeys=[
 'CALIAN_SCHEMA_DATABASE','PYTHON_SERVICE_URL','OLLAMA_URL',
 'REQA_API_URL','CALIAN_SQL_DOCKER_CONTAINER',
 'CALIAN_VIDEO_PUBLIC_ORIGIN','CALIAN_VIDEO_ADMIN_KEY'
];
const editableSet=new Set(editableKeys);
function checkedSettings(input){
 if(!input || typeof input!=='object'||Array.isArray(input))throw new Error('Invalid settings');
 const clean={};
 for(const key of editableKeys){
  const v=input[key];
  if(typeof v!=='string'||v.length>1024||/[\r\n\0]/.test(v))throw new Error(`Invalid ${key}`);
  clean[key]=v.trim();
 }
 if(clean.CALIAN_SCHEMA_DATABASE && !/^[A-Za-z_][A-Za-z0-9_]{0,127}$/.test(clean.CALIAN_SCHEMA_DATABASE)){
  throw new Error('Database name must contain only letters, digits and underscores.');
 }
 for(const key of ['PYTHON_SERVICE_URL','OLLAMA_URL','REQA_API_URL']){
  try{
   const u=new URL(clean[key]);
   if(!['http:','https:'].includes(u.protocol)||u.username||u.password||u.hash)throw new Error();
  }catch{throw new Error(`Invalid ${key}: use a valid http:// or https:// URL.`);}
 }
 if(clean.CALIAN_VIDEO_PUBLIC_ORIGIN){
  try{
   const u=new URL(clean.CALIAN_VIDEO_PUBLIC_ORIGIN);
   const loopback=['localhost','127.0.0.1','[::1]'].includes(u.hostname);
   if((u.protocol!=='https:' && !(loopback&&u.protocol==='http:'))||u.username||u.password||u.hash||u.pathname!=='/')throw new Error();
  }catch{throw new Error('Public video URL must use HTTPS (HTTP only on localhost for testing).');}
 }
 if(!/^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,127}$/.test(clean.CALIAN_SQL_DOCKER_CONTAINER))throw new Error('Invalid Docker container name.');
 if(clean.CALIAN_VIDEO_ADMIN_KEY && clean.CALIAN_VIDEO_ADMIN_KEY.length<32)throw new Error('Video service admin key must be at least 32 characters.');
 return clean;
}

function writeSettings(file,newValues){
 // Preserve comments, credentials and every unknown setting in existing config.
 const values=checkedSettings(newValues);
 const seen=new Set();
 const original=fs.readFileSync(file,'utf8').split(/\r?\n/);
 const lines=[];
 for(const line of original){
  const match=line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=/);
  if(match && editableSet.has(match[1])){
   const key=match[1];
   if(seen.has(key))continue;
   seen.add(key);
   lines.push(`${key}=${values[key]}`);
  }else{lines.push(line);}
 }
 for(const key of editableKeys)if(!seen.has(key))lines.push(`${key}=${values[key]}`);
 const output=lines.join('\r\n').replace(/(?:\r?\n)*$/,'')+'\r\n';
 // Write atomically: do not truncate a working config on interrupted writes.
 const tmp=file+'.'+process.pid+'.tmp';
 try{
  fs.writeFileSync(tmp,output,{mode:0o600,flag:'wx'});
  fs.renameSync(tmp,file);
 }catch(e){try{fs.rmSync(tmp,{force:true});}catch{}throw e;}
}

function showSettingsWindow(isFirstRun=false,parent=null){
 if(settingsWindow){settingsWindow.focus();return Promise.resolve();}
 return new Promise(resolve=>{
  settingsWindow=new BrowserWindow({
   width:665,height:750,resizable:true,minWidth:530,minHeight:640,
   title:'CALIAN.AI — First-run configuration',
   backgroundColor:'#111827', ...(parent?{parent,modal:true}:{}),
   webPreferences:{
    nodeIntegration:false,contextIsolation:true,sandbox:true,
    preload:path.join(__dirname,'config-preload.cjs')
   }
  });
  settingsWindow.setMenuBarVisibility(false);
  const w=settingsWindow;
  w.webContents.setWindowOpenHandler(()=>({action:'deny'}));
  w.webContents.on('will-navigate',(ev,url)=>{if(url!==w.webContents.getURL())ev.preventDefault();});
  w.on('closed',()=>{settingsWindow=null;resolve();});
  w.loadFile(path.join(__dirname,'first-run.html'),{query:{first:isFirstRun?'1':'0'}})
   .catch(e=>{dialog.showErrorBox('CALIAN.AI configuration',String(e));w.close();});
 });
}

ipcMain.handle('calian:config:get',event=>{
 if(!settingsWindow||event.sender!==settingsWindow.webContents)throw new Error('Not a configuration window');
 const current={...readConfig(activeConfigFile||portableConfigFile)};
 const defaults={...Object.fromEntries(defaultConfiguration().split(/\r?\n/).map(x=>x.match(/^([A-Z_]+)=(.*)$/)).filter(Boolean).map(m=>[m[1],m[2]]))};
 return {values:Object.fromEntries(editableKeys.map(k=>[k,current[k]??defaults[k]??''])),path:activeConfigFile};
});
ipcMain.handle('calian:config:save',(event,values)=>{
 if(!settingsWindow||event.sender!==settingsWindow.webContents)throw new Error('Not a configuration window');
 if(!activeConfigFile)throw new Error('No configuration destination');
 writeSettings(activeConfigFile,values);
 return {ok:true,file:activeConfigFile};
});
ipcMain.handle('calian:config:close',event=>{
 if(!settingsWindow||event.sender!==settingsWindow.webContents)throw new Error('Not a configuration window');
 settingsWindow.close();
 return {ok:true};
});

const host='127.0.0.1';
function reserveAvailablePort(port){return new Promise((resolve,reject)=>{
 const test=net.createServer();
 test.once('error',reject);
 test.listen(port,host,()=>{
  const addr=test.address();
  const selected=addr&&typeof addr==='object'?addr.port:null;
  test.close(()=>selected?resolve(selected):reject(new Error('Unable to allocate CALIAN backend port')));
 });
});}
function startBackend(port,config){
 if(dev)return;
 const executable=process.execPath;
 const script=path.join(app.getAppPath(),'dist','backend.cjs');
 const staticDir=path.join(app.getAppPath(),'dist','calian','browser');
 fs.mkdirSync(path.dirname(startupLog),{recursive:true});
 const logFd=fs.openSync(startupLog,'w');
 fs.writeSync(logFd,`CALIAN backend startup; listening on ${host}:${port}\n`);
 fs.writeSync(logFd,`CALIAN configured schema: ${config.CALIAN_SCHEMA_DATABASE || '(auto-detect)'}\n`);
 fs.writeSync(logFd,`CALIAN config location: ${activeConfigFile || '(development)'}\n`);
 try{
  backend=spawn(executable,[script],{env:{...config,ELECTRON_RUN_AS_NODE:'1',CALIAN_STATIC_DIR:staticDir,PORT:String(port),HOST:host,CALIAN_INSTANCE_ID:instanceId},stdio:['ignore',logFd,logFd],windowsHide:true});
 }finally{fs.closeSync(logFd);}
 backend.on('error',e=>{backendStartupError=e.message;});
 backend.on('exit',(code,signal)=>{backendStartupError=`Backend exited (code ${code}, signal ${signal||'none'})`;});
}
async function waitBackend(url){
 for(let i=0;i<80;i++){
  try{
   const r=await fetch(`${url}/api/health`,{signal:AbortSignal.timeout(1200)});
   if(r.ok){const health=await r.json();
    if(dev||(health.status==='ready'&&health.instanceId===instanceId&&
      typeof health.nlAdapterVersion==='string'&&health.nlAdapterVersion.startsWith('8-')))return;
   }
  }catch{}
  if(backendStartupError)throw new Error(`${backendStartupError}. Backend log: ${startupLog}`);
  await new Promise(r=>setTimeout(r,250));
 }
 throw new Error(`CALIAN backend did not become ready at ${url}. See backend log: ${startupLog}. The app will not attach to an older server.`);
}
app.whenReady().then(async()=>{try{
 if(!dev){
  const generated=initializePortableConfig();
  activeConfigFile=generated.file;
  if(generated.created)await showSettingsWindow(true);
 }
 const config=loadConfig();
 const explicitlyConfiguredPort=config.PORT!=null&&config.PORT!=='';
 const configuredPort=Number(config.PORT||8797);
 if(!Number.isInteger(configuredPort)||configuredPort<1||configuredPort>65535)throw new Error('Invalid PORT');
 const port=dev?configuredPort:await reserveAvailablePort(explicitlyConfiguredPort?configuredPort:0);
 const backendURL=`http://${host}:${port}`;
 startBackend(port,config);
 await waitBackend(backendURL);
 const win=new BrowserWindow({width:1440,height:920,minWidth:950,minHeight:650,backgroundColor:'#111827',webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}});
 await win.loadURL(dev?'http://127.0.0.1:4300':backendURL);
 Menu.setApplicationMenu(Menu.buildFromTemplate([
  {label:'File',submenu:[{label:'Configure database and services…',click:()=>showSettingsWindow(false,win)},{type:'separator'},{role:'quit'}]},
  {label:'Edit',submenu:[{role:'undo'},{role:'redo'},{type:'separator'},{role:'cut'},{role:'copy'},{role:'paste'},{role:'selectAll'}]},
  {label:'View',submenu:[{role:'reload'},{role:'toggleDevTools'},{role:'resetZoom'},{role:'zoomIn'},{role:'zoomOut'}]},
  {label:'Window',submenu:[{role:'minimize'},{role:'close'}]}
 ]));
}catch(e){dialog.showErrorBox('CALIAN AI startup',String(e));app.quit();}});
app.on('window-all-closed',()=>app.quit());
app.on('before-quit',()=>{if(backend)backend.kill();});
