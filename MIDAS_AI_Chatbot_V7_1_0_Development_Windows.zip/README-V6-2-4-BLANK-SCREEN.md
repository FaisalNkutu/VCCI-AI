# AI Chatbot + MIDAS V6.2.4 — Workspaces / Close blank screen fix

## Failure reproduced from source

In V6.2.3, the MIDAS root template uses `[class.hidden]="calianAi()"` on the div containing `router-outlet`. This can leave the complete dashboard/chooser invisible if URL-derived state is stale. Your screenshot showing a black page with only an **AI Chatbot** button is consistent with the root content still being hidden while the overlay is closed.

## Targeted changes

- The router outlet is **only hidden when the user explicitly chooses AI Chatbot full-page mode**, not when the route status claims `/calian-ai`.
- **Workspaces** always clears full-page mode, resets the workspace preference and navigates to `/` to display MIDAS's workspace chooser.
- **Close** always restores the router outlet. If the active route is `/calian-ai`, it navigates to `/advmetrics/summary`; otherwise it **preserves the current dashboard**.
- Navigation failures are reported in the browser console instead of silently failing. Existing port selection, backend services, controls, agent selection, pop-out behavior, role restrictions and the approval bridge are untouched.

## Installing the V6.2.4 quick fix

1. Extract `MIDAS_AI_Chatbot_V6_2_4_Blank_Screen_Quick_Fix.zip` to a separate folder.
2. Double-click `APPLY-V6-2-4-WINDOWS.bat`. If several source copies are detected, choose the one currently serving your browser URL.
3. Confirm the backup. The script edits only `midas/midas-frontend/src/app/app.component.html` and `midas/midas-frontend/src/app/components/calian-ai/midas-calian-copilot.component.ts`.
4. Wait for the MIDAS Angular watch console to report `Application bundle generation complete`, then hard-refresh the **specific MIDAS port** using `Ctrl+Shift+R`.
5. On `/calian-ai`, click **Workspaces**: the MIDAS workspace chooser must display. Select Advance Metrics, navigate to Fratricide or Summary, open the chat side panel and click **Close**: the dashboard must remain visible. In Full Page, click **Close**: the Summary dashboard must display.
6. For a popup already open, `Close` on the embedded host does not close the separate browser popup. Use **Dock in MIDAS** to return a chat session, or close that browser popup manually.

## If it still goes black

Check **the address bar** and the Angular development-server terminal for the matching port. If the URL is `/` but Workspaces is blank, open DevTools (F12) → Console and look for Angular router errors. If a page in `/advmetrics/...` stays blank even after refresh, send its browser console error and the terminal's first error; this patch fixes root-content visibility but cannot fix missing MIDAS APIs or runtime faults in unrelated dashboard components.

**Verification:** source-level assertions and TypeScript syntax checks were performed in Linux. The complete MIDAS build and Windows browser click test could not be run without the private Simfront registry and your local services. Use a copy/backup in development, not production deployment, until verified on Windows.
