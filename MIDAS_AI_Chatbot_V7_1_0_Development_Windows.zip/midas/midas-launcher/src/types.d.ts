interface ConnectedDB {
  database: string;
  live: boolean;
  connected: boolean;
  host: string;
}

type MapType = 'WMS' | 'WMTS' | 'CSW'

interface MapConfigData {
  alias: string;
  url: string;
  type: MapType;
}

interface ProcessorStatus {
  name: string;
  active: boolean;
  reason: string;
}

interface StatusData {
  jMaxTime: number;
  jFormattedMaxTime: string;

  jHHourActive: boolean;
  jROMActive: boolean;
  jCMOccupationsActive: boolean;
  jPOEActive: boolean;
  jCPowerActive: boolean;
  jEnemyEngagementsActive: boolean;
  jFratricideActive: boolean;
  jEntityWatchActive: boolean;

  jHHourReason?: string;
  jROMReason?: string;
  jPOEReason?: string;
  jCMOccsReason?: string;
  jEneEngReason?: string;
  jEntWatchReason?: string;

  jROMEntryCount: number;
  jFratricideIncidentCount: number;
  jHHourCount: number;
}
