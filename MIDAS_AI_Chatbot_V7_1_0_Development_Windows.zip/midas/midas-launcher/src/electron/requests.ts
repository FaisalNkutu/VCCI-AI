import { api } from './api';
import { APP_LAYER_URL } from './config';
import logger from './logger';
import GlobalState from './state';

export async function getAvailableDatabases(host: string): Promise<string[]> {
  try {
    const response = await api.get<string[]>(`${APP_LAYER_URL}/advmetrics/omdbdata/databases?host=${host}`);
    return response.data;
  } catch (error) {
    logger.error('Error fetching available databases:', error);
    return [];
  }
}

export async function getSelectedDB(): Promise<ConnectedDB> {
  const defaultDb = {
    database: '',
    live: false,
    connected: false,
    host: GlobalState.getConnectedDB().host,
  };
  try {
    const response = await api.get<ConnectedDB>(
      `${APP_LAYER_URL}/advmetrics/omdbdata/selecteddb`
    );
    if (!response.data.connected) {
      response.data = defaultDb;
    }
    return response.data;
  } catch (error) {
    logger.error('Error fetching selected database:', error);
    return defaultDb;
  }
}

export async function connectDB(name: string, live: boolean, host: string): Promise<boolean> {
  try {
    await api.post(`${APP_LAYER_URL}/advmetrics/omdbdata/selectdb`, {
      name,
      livemode: live,
      host
    });
    return true;
  } catch (error) {
    logger.error('Error connecting to database:', error);
    return false;
  }
}

export async function disconnectDB(): Promise<boolean> {
  try {
    await api.post(`${APP_LAYER_URL}/advmetrics/omdbdata/disconnectdb`, {});
    return true;
  } catch (error) {
    logger.error('Error disconnecting from database:', error);
    return false;
  }
}

export async function getMapConfig(): Promise<MapConfigData> {
  const defaultMapConfig: MapConfigData = { alias: '', url: '', type: 'WMS' };
  try {
    const response = await api.get<MapConfigData>(`${APP_LAYER_URL}/advmetrics/mapconfig`);
    if (!response.data || !response.data.url) {
      return defaultMapConfig;
    }
    return response.data;
  } catch (error) {
    logger.error('Error fetching map configuration:', error);
    return defaultMapConfig;
  }
}

export async function configureMap(config: MapConfigData): Promise<boolean> {
  try {
    await api.post(`${APP_LAYER_URL}/advmetrics/mapconfig`, config);
    return true;
  } catch (error) {
    logger.error('Error configuring map:', error);
    return false;
  }
}
