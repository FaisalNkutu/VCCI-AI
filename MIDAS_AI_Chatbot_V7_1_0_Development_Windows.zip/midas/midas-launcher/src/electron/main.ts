import { app } from 'electron';
import { __appRoot } from './utils';
import { initBackend } from './init';
import { initIPC } from './ipc';
import GlobalState from './state';
import { createMainWindow, createSplashWindow, loadUIFile } from './window';
import logger from './logger';
import { terminateBackend } from './process';

/**
 * Initialize the application windows and backend
 */
async function initApp(): Promise<void> {
  // Create splash screen
  const splash = createSplashWindow();

  const lock = app.requestSingleInstanceLock();
  if (!lock) {
    app.quit();
    return;
  }

  // Initialize backend
  await initBackend();

  // Create main window
  let mainWindow = createMainWindow();

  // Prevent blank screen on load/reload
  mainWindow.webContents.on('did-fail-load', () => {
    if (!mainWindow) {
      mainWindow = createMainWindow();
    } else {
      loadUIFile(mainWindow, 'index.html');
    }
  });

  // Set up event handlers
  mainWindow.once('ready-to-show', () => {
    splash.destroy();
    if (mainWindow === null) {
      logger.error('Main window is null, exiting...');
      app.quit();
      return;
    }
    mainWindow.show();
  });

  mainWindow.on('closed', () => {
    GlobalState.resetMainWindow();
  });
}

// ===== Application Lifecycle =====
app.on('ready', () => {
  initIPC();
  initApp();
});

app.on('activate', () => {
  if (!GlobalState.mainWindow) {
    initApp();
  }
});

app.on('before-quit', async (e) => {
  if (GlobalState.isShutdownPending()) {
    return;
  }
  e.preventDefault();
  await terminateBackend();
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('second-instance', (event, commandLine, workingDirectory) => {
  // Someone tried to run a second instance, we should focus our window.
  if (GlobalState.mainWindow) {
    if (GlobalState.mainWindow.isMinimized())
      GlobalState.mainWindow.restore();
    GlobalState.mainWindow.focus();
  }
});
