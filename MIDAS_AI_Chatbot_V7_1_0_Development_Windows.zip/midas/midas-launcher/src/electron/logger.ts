import {createLogger, transports, format, type Logger } from 'winston';


class LoggerSingleton {
  private static instance: Logger;

  private constructor() {}

  public static getInstance(): Logger {
    if (!LoggerSingleton.instance) {
      // Create the logger instance only if it doesn't exist yet
      const logger = createLogger({
        format: format.combine(
          format.timestamp(),
          format.json()
        ),
        transports: [
          new transports.Console({
            level: 'debug',
            format: format.combine(
              format.colorize(),
              format.simple()
            )
          }),
          new transports.File({
            level: 'info',
            filename: 'launcher.log',
            dirname: 'logs',
            format: format.combine(
              format.timestamp(),
              format.errors({ stack: true }),
              format.json()
            )
          })
        ]
      });

      LoggerSingleton.instance = logger;
    }

    return LoggerSingleton.instance;
  }
}

export default LoggerSingleton.getInstance();
