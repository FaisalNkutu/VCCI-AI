import { join, resolve } from 'path';

export function getProgramDataPath(path: string): string {
  const programDataPath = process.env['PROGRAMDATA'];
  if (!programDataPath) {
    throw new Error('PROGRAMDATA environment variable not found');
  }
  const pdPath = join(programDataPath, path);
  return resolve(pdPath);
}

/**
 * Resolves a path relative to the application root directory
 */
export const __appRoot = (...paths: string[]): string =>
  join(__dirname, ...paths);

/**
 * Creates a delay for the specified number of milliseconds
 */
export function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function convertToProcessorStatus(
  data: StatusData
): ProcessorStatus[] {
  return [
        {
          name: 'H-Hour',
          active: data?.jHHourActive ?? false,
          reason: data?.jHHourReason || '',
        },
        {
          name: 'Rate of Movement',
          active: data?.jROMActive ?? false,
          reason: data?.jROMReason || '',
        },
        {
          name: 'Control Measure Occupations',
          active: data?.jCMOccupationsActive ?? false,
          reason: data?.jCMOccsReason || '',
        },
        {
          name: 'Picture of Enemy',
          active: data?.jPOEActive ?? false,
          reason: data?.jPOEReason || '',
        },
        {
          name: 'Fratricide',
          active: data?.jFratricideActive ?? false,
          reason: '',
        },
        {
          name: 'Enemy Engagements',
          active: data?.jEnemyEngagementsActive ?? false,
          reason: data?.jEneEngReason || '',
        },
        {
          name: 'Combat Power',
          active: data?.jCPowerActive ?? false,
          reason: '',
        },
        {
          name: 'Entity Watch',
          active: data?.jEntityWatchActive ?? false,
          reason: data?.jEntWatchReason || '',
        },
      ];
}
