import GlobalState from './state';
import { APP_LAYER_URL } from './config';
import { NetworkPoller } from './network-poll';
import { EventSource, ErrorEvent } from 'eventsource';
import logger from './logger';
import { launchBackend } from './process';
import { convertToProcessorStatus } from './utils';
import { getSelectedDB } from './requests';

export async function initBackend() {
  await launchBackend();

  const backendMonitor = new NetworkPoller(APP_LAYER_URL, 'advmetrics/omdbdata/status', 1000);

  logger.info('Start Polling for App Layer...');
  backendMonitor.startDetachedPolling(async (res) => {
    const db = await getSelectedDB();
    GlobalState.setConnectedDB(db);

    const newUrl = `${APP_LAYER_URL}/advmetrics/sse/mstatus`;
    connectToSSE(
      newUrl,
      (data) => {
        const statusData = JSON.parse(data) as StatusData;
        const processorStatus = convertToProcessorStatus(statusData);
        GlobalState.setStatus(processorStatus);
      },
      (err: ErrorEvent) => {
        logger.warn(
          `SSE connection ${
            err.message?.includes('closed') ? 'shutdown.' : 'ERROR!!!'
          } restarting poll...`
        );
        backendMonitor.restartDetachedPolling();
      }
    );
  });
}

function connectToSSE(
  url: string,
  onData: (data: string) => void,
  onError?: (err: ErrorEvent) => void
): EventSource | undefined {
  try {
    logger.info(`Connecting to SSE endpoint`);
    logger.debug(`SSE URL: ${url}`);
    const currentSSEConnection = new EventSource(url);

    currentSSEConnection.onmessage = (event) => {
      onData(event.data);
    };

    currentSSEConnection.onerror = (err) => {
      currentSSEConnection.close();
      if (onError) {
        onError(err);
      } else {
        logger.error('SSE connection error:', err);
        logger.debug(`SSE URL: ${url}`);
      }
    };

    return currentSSEConnection;
  } catch (err) {
    logger.error('Failed to connect to SSE:', err);
    return undefined;
  }
}
