import { shell, ipcMain } from 'electron';
import { WEBUI_URL } from './config';
import GlobalState from './state';
import { configureMap, connectDB, disconnectDB, getAvailableDatabases, getMapConfig } from './requests';

export function initIPC(): void {
  ipcMain.on('open-web-ui', () => {
    shell.openExternal(WEBUI_URL);
  });

  ipcMain.handle('get-available-dbs', async (e, host: string) => {
    return await getAvailableDatabases(host);
  });

  ipcMain.handle('get-connected-db', async (e) => {
    return GlobalState.getConnectedDB();
  });

  ipcMain.handle('get-status', async (e) => {
    return GlobalState.getStatus();
  });

  ipcMain.handle('connect-db', async (e, dbName: string, live: boolean, ip: string) => {
    const success = await connectDB(dbName, live, ip);
    if (!success) {
      return false;
    }
    GlobalState.setConnectedDB({ database: dbName, live, connected: success, host: GlobalState.getConnectedDB().host });
    return success;
  });

  ipcMain.handle('disconnect-db', async (e) => {
    const success = await disconnectDB();
    if (!success) {
      return false;
    }
    GlobalState.disconnectDB();
    return success;
  });

  ipcMain.handle(
    'configure-map',
    async (e, config: MapConfigData) => {
      return await configureMap(config);
    }
  );

  ipcMain.handle('get-map-config', async (e) => {
    return await getMapConfig();
  });
}
