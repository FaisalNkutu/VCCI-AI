import { spawn } from 'child_process';
import { api } from './api';
import { __appRoot } from './utils';
import { APP_LAYER_URL } from './config';
import GlobalState from './state';
import logger from './logger';
import { dirname } from 'path';
import { NetworkPoller } from './network-poll';

export async function launchBackend(): Promise<void> {
  // Wait for the App Layer to start, polling synchronously for 60 seconds
  const poll = new NetworkPoller(APP_LAYER_URL, 'advmetrics/omdbdata/status', 500);
  let result = await poll.startPolling(() => true, 1);

  if (result) {
    logger.info('App Layer is already running, skipping launch.');
    return;
  }

  const appLayerPath = process.defaultApp
    ? __appRoot('../..', 'midas-microservice', 'midas.bat')
    : __appRoot('../../../..', 'midas.exe');

  const launcherProcess = spawn(`"${appLayerPath}"`, [], {
    shell: true,
    detached: false,
    cwd: dirname(appLayerPath),
    env: process.env,
  });

  launcherProcess.stdout.on('data', (data) => {
    console.log(`[MIDAS_BACKEND]::STDOUT: ${data}`);
  });
  launcherProcess.stderr.on('data', (data) => {
    console.error(`[MIDAS_BACKEND]::STDERR: ${data}`);
  });
  launcherProcess.on('error', (error) => {
    console.error(`[MIDAS_BACKEND]::ERROR: ${error}`);
    GlobalState.killChildProcess();
  });

  result = await poll.startPolling(() => true, 120);

  if (!result) {
    GlobalState.killChildProcess();
    throw new Error('App Layer failed to start within expected time');
  }

  GlobalState.setChildProcess(launcherProcess);

  logger.info('App Layer started successfully');
}

export async function terminateBackend(): Promise<boolean> {
  logger.info('Terminating Midas Launcher...');
  GlobalState.setShutdownPending(true);
  try {
    await api.post(`${APP_LAYER_URL}/midas/shutdown`, {});
    logger.info('Midas Launcher shutdown successfully');
    return true;
  } catch (error) {
    logger.error('Failed to shutdown. Midas Launcher might still be running');
    return false;
  } finally {
    GlobalState.killChildProcess();
  }
}
