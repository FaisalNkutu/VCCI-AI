import { api, ApiResponse } from './api';
import { delay } from './utils';
import logger from './logger';

type ConnectResponse<T = any> = (res: ApiResponse<T>) => T | undefined;

export class NetworkPoller {
  private baseUrl: string;
  private pollingEndpoint: string;
  private pollingInterval: NodeJS.Timeout | undefined;
  private pollingIntervalMs: number;
  private onConnect: ConnectResponse | undefined;

  constructor(
    baseUrl: string,
    pollingEndpoint: string,
    pollingIntervalMs: number = 5000
  ) {
    this.baseUrl = baseUrl;
    this.pollingEndpoint = pollingEndpoint;
    this.pollingIntervalMs = pollingIntervalMs;
  }

  private get pollingUrl(): string {
    return `${this.baseUrl}/${this.pollingEndpoint}`;
  }

  private async pollStatus(): Promise<ApiResponse | undefined> {
    try {
      return await api.get(this.pollingUrl);
    } catch (err) {
      logger.debug(`Polling Error: ${err}`);
      return undefined;
    }
  }

  async startDetachedPolling(onConnect?: ConnectResponse): Promise<void> {
    this.onConnect = onConnect;
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
    }

    const detachedPoll = async () => {
      logger.debug(`Detached Polling ${this.pollingUrl}`);
      const response = await this.pollStatus();
      if (!response) {
        return;
      }
      logger.info('Poll Endpoint Online');
      logger.debug(`Poll Endpoint: ${this.pollingUrl}`);
      clearInterval(this.pollingInterval); // Stop polling after successful connection
      this.pollingInterval = undefined;
      return this.onConnect?.(response);
    };

    detachedPoll();
    this.pollingInterval = setInterval(detachedPoll, this.pollingIntervalMs);
  }

  async restartDetachedPolling(): Promise<void> {
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
      this.pollingInterval = undefined;
    }
    this.startDetachedPolling(this.onConnect);
  }

  async startPolling(onConnect?: ConnectResponse, maxRetries: number = 10) {
    logger.debug(
      `Synchronous Polling ${this.pollingUrl} for ${maxRetries} times`
    );
    this.onConnect = onConnect;

    for (let i = 0; i < maxRetries; i++) {
      const response = await this.pollStatus();
      if (!response) {
        logger.debug(`Polling Error: ${response}`);
        await delay(this.pollingIntervalMs);
        continue;
      }
      logger.info('Poll Endpoint Online');
      logger.debug(`Poll Endpoint: ${this.pollingUrl}`);
      return this.onConnect?.(response);
    }
  }

  async infinitePoll(onConnect?: ConnectResponse) {
    this.onConnect = onConnect;
    const poll = async () => {
      logger.debug(`Infinite Polling ${this.pollingUrl}`);
      const response = await this.pollStatus();
      if (!response) {
        return;
      }
      this.onConnect?.(response);
    };

    poll();
    this.pollingInterval = setInterval(poll, this.pollingIntervalMs);
  }
}
