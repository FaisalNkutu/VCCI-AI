export const APP_LAYER_URL = 'http://127.0.0.1:10001';
export const WEBUI_URL = 'http://localhost:10001';
