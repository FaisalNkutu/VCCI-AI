import url from 'url';
import { BrowserWindow } from 'electron';
import { __appRoot } from './utils';
import GlobalState from './state';

/**
 * Loads a UI file into the specified window
 * @param window - The BrowserWindow instance to load the file into
 * @param filePath - The path to the HTML file to load
 */
export function loadUIFile(window: BrowserWindow, ...filePath: string[]): void {
  window.loadURL(
    url.format({
      pathname: __appRoot('browser', ...filePath),
      protocol: 'file:',
      slashes: true,
    })
  );
}

/**
 * Creates the splash screen window
 */
export function createSplashWindow(): BrowserWindow {
  const splash = new BrowserWindow({
    width: 170,
    height: 170,
    transparent: true,
    frame: false,
    alwaysOnTop: true,
  });

  loadUIFile(splash, 'splash.html');

  return splash;
}

/**
 * Creates the main application window
 */
export function createMainWindow(): BrowserWindow {
  const window = new BrowserWindow({
    width: 1200,
    height: 800,
    icon: __appRoot('browser', 'favicon.ico'),
    webPreferences: {
      preload: __appRoot('preload.js'),
      webSecurity: true,
    },
    show: false,
  });

  loadUIFile(window, 'index.html');

  return GlobalState.setMainWindow(window);
}
