import { contextBridge, ipcRenderer, IpcRendererEvent } from 'electron';

const API: ElectronAPI = {
  send: (channel: ElectronReceiveChannel, ...data: any[]): void => {
    ipcRenderer.send(channel, ...data);
  },
  on: <T = any>(channel: ElectronPushChannel, callback: (data: T) => void): void => {
    ipcRenderer.on(channel, (_event: IpcRendererEvent, ...args: [T]): void =>
      callback(...args)
    );
  },
  invoke: <T = any>(channel: ElectronInvokeChannel, ...args: any[]): Promise<T> => {
    return ipcRenderer.invoke(channel, ...args);
  },
};

// Expose the typed API to the renderer process
contextBridge.exposeInMainWorld('electron', API);
