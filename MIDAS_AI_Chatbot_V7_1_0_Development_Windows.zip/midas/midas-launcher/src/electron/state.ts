import { ChildProcess } from 'child_process';

class GlobalState {
  private static instance: GlobalState;
  private _childProcess: ChildProcess | undefined;
  private _mainWindow: Electron.BrowserWindow | undefined;
  private _shutdownPending: boolean = false;

  private _connectedDB: ConnectedDB = { database: '', live: false, connected: false, host: '127.0.0.1' };
  private _status: ProcessorStatus[] = [];

  private constructor() {
    // Ensure this is a singleton
    if (GlobalState.instance) {
      return GlobalState.instance;
    }

    GlobalState.instance = this;
  }

  public static getInstance(): GlobalState {
    if (!GlobalState.instance) {
      GlobalState.instance = new GlobalState();
    }
    return GlobalState.instance;
  }

  // Getters
  get mainWindow(): Electron.BrowserWindow | undefined {
    return this._mainWindow;
  }

  // Setters
  setMainWindow(window: Electron.BrowserWindow): Electron.BrowserWindow {
    this._mainWindow = window;
    return this._mainWindow;
  }

  setChildProcess(child: ChildProcess): void {
    this._childProcess = child;
  }

  // Utility methods
  resetMainWindow(): void {
    this._mainWindow = undefined;
  }

  sendDataToWindow<T>(channel: ElectronPushChannel, data: T): void {
    if (this._mainWindow && !this._mainWindow.isDestroyed()) {
      this._mainWindow.webContents.send(channel, data);
    }
  }

  detachChildProcess(kill: boolean = false): void {
    if (!this._childProcess) return;

    if (kill) {
      this._childProcess.kill();
      this._childProcess = undefined;
      return;
    }
    this._childProcess.removeAllListeners();
    this._childProcess.unref();
    this._childProcess = undefined;
  }

  killChildProcess(): void {
    this.detachChildProcess(true);
  }

  getConnectedDB(): ConnectedDB {
    return this._connectedDB;
  }

  setConnectedDB(db: ConnectedDB): void {
    this._connectedDB = db;
    this.sendDataToWindow('update-connected-db', this._connectedDB);
  }

  disconnectDB(): void {
    this.setConnectedDB({ database: '', live: false, connected: false, host: this._connectedDB.host });
  }

  getStatus(): ProcessorStatus[] {
    return this._status;
  }

  setStatus(status: ProcessorStatus[]): void {
    this._status = status;
    this.sendDataToWindow('update-status', this._status);
  }

  isShutdownPending(): boolean {
    return this._shutdownPending;
  }
  setShutdownPending(pending: boolean): void {
    this._shutdownPending = pending;
  }
}

export default GlobalState.getInstance();
