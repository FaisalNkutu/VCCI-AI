import logger from './logger';

type FetchOptions = {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
  headers?: Record<string, string>;
  body?: any;
};

export type ApiResponse<T = any> = {
  data: T;
  status: number;
  statusText: string;
  headers: any;
};

async function fetchApi<T = any>(
  url: string,
  options: FetchOptions = {},
): Promise<ApiResponse<T>> {
  const { method = 'GET', headers = {}, body } = options;

  const fetchOptions: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...headers,
    },
  };

  if (body) {
    fetchOptions.body = JSON.stringify(body);
  }

  try {
    const response = await fetch(url, fetchOptions);
    const data = await response.json().catch((): T | null => null); // Handle cases where there is no body

    if (!response.ok) {
      logger.error(`API request failed: ${method} ${url}`, {
        status: response.status,
        statusText: response.statusText,
        data,
      });
      // Throw an error that resembles the Axios error structure for compatibility
      const error: any = new Error(
        `Request failed with status code ${response.status}`,
      );
      error.response = {
        status: response.status,
        statusText: response.statusText,
        data,
      };
      throw error;
    }

    // Mimic Axios response structure
    return {
      data,
      status: response.status,
      statusText: response.statusText,
      headers: response.headers,
    };
  } catch (error) {
    logger.debug(`API request error: ${method} ${url}`, error);
    throw error;
  }
}

export const api = {
  get: <T = any>(url: string, options?: FetchOptions): Promise<ApiResponse<T>> =>
    fetchApi<T>(url, { ...options, method: 'GET' }),
  post: <T = any>(url: string, body?: any, options?: FetchOptions): Promise<ApiResponse<T>> =>
    fetchApi<T>(url, { ...options, method: 'POST', body }),
  put: <T = any>(url: string, body?: any, options?: FetchOptions): Promise<ApiResponse<T>> =>
    fetchApi<T>(url, { ...options, method: 'PUT', body }),
  delete: <T = any>(url: string, options?: FetchOptions): Promise<ApiResponse<T>> =>
    fetchApi<T>(url, { ...options, method: 'DELETE' }),
};
