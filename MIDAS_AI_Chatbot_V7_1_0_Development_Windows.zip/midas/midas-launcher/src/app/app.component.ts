import { Component } from '@angular/core';
import { ConnectionManagerComponent } from './pages/connection-manager/connection-manager.component';
import { defaultDb, StateService } from './services/state.service';
import { Observable } from 'rxjs';
import { AsyncPipe } from '@angular/common';
import { LauncherService } from './services/launcher.service';

@Component({
  selector: 'app-root',
  imports: [AsyncPipe, ConnectionManagerComponent],
  templateUrl: './app.component.html',
})
export class AppComponent {
  databases$: Observable<string[]>;
  status$: Observable<ProcessorStatus[]>;
  selectedDB$: Observable<ConnectedDB>;

  defaultDb = defaultDb;

  constructor(private stateService: StateService, private launcherService: LauncherService) {
    this.databases$ = this.stateService.availableDBs$;
    this.status$ = this.stateService.status$;
    this.selectedDB$ = this.stateService.connectedDB$;
  }
}
