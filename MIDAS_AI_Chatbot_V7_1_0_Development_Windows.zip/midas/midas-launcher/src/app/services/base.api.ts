export abstract class BaseAPI {
  abstract openWebUI(): void;

  abstract loadDatabases(ip: string): Promise<string[]>;

  abstract connectDB(db: string, live: boolean, host: string): Promise<boolean>;

  abstract disconnectDB(): Promise<boolean>;

  abstract configureMap(config: MapConfigData): Promise<boolean>;

  abstract getMapConfig(): Promise<MapConfigData>;
}
