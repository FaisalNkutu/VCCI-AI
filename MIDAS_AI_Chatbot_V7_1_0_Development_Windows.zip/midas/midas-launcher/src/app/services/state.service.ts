import { Injectable } from '@angular/core';
import { BehaviorSubject, map } from 'rxjs';

export const defaultDb: ConnectedDB = { database: '', live: false, connected: false, host: '127.0.0.1' };

@Injectable({
  providedIn: 'root',
})
export class StateService {
  // BehaviorSubjects to store state with initial values
  private connectedDB = new BehaviorSubject<ConnectedDB>(defaultDb);
  private availableDBs = new BehaviorSubject<string[]>([]);
  private status = new BehaviorSubject<ProcessorStatus[]>([]);
  private mapConfig = new BehaviorSubject<MapConfigData>({ alias: '', url: '', type: 'WMS' });

  // Expose state as Observables
  connectedDB$ = this.connectedDB.asObservable();
  availableDBs$ = this.availableDBs
    .asObservable()
    .pipe(map((dbs) => dbs.sort()));
  status$ = this.status.asObservable();
  mapConfig$ = this.mapConfig.asObservable();

  // Update state methods
  updateConnectedDB(db: ConnectedDB) {
    this.connectedDB.next(db);
  }
  updateAvailableDBs(dbs: string[]) {
    this.availableDBs.next(dbs);
  }
  updateStatus(status: ProcessorStatus[]) {
    this.status.next(status);
  }
  updateIpAddress(ip: string) {
    this.connectedDB.next({ ...this.connectedDB.getValue(), host: ip });
  }
  updateMapConfig(config: MapConfigData) {
    this.mapConfig.next(config);
  }

  // Getters for current state values
  getCurrentConnectedDB(): ConnectedDB {
    return this.connectedDB.getValue();
  }
  getCurrentAvailableDBs(): string[] {
    return this.availableDBs.getValue();
  }
  getCurrentStatus(): ProcessorStatus[] {
    return this.status.getValue();
  }
  getCurrentHost(): string {
    return this.connectedDB.getValue().host;
  }
  getCurrentMapConfig(): MapConfigData {
    return this.mapConfig.getValue();
  }

  // Helper methods
  resetDbConnection() {
    this.updateConnectedDB(defaultDb);
  }
}
