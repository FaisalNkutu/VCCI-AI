import { inject, Injectable } from '@angular/core';
import { BaseAPI } from './base.api';
import { defaultDb, StateService } from './state.service';
import { dbList } from '../../test-data';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmationDialogComponent } from '../dialog/confirmation-dialog/confirmation-dialog.component';

@Injectable({
  providedIn: 'root',
})
export class MockService extends BaseAPI {
  private _stateService = inject(StateService);
  private _dialogService = inject(MatDialog);
  constructor() {
    super();
    this._stateService.updateAvailableDBs(dbList);
    this._stateService.updateStatus([
      { name: 'H-Hour', active: true, reason: '' },
      { name: 'Rate of Movement', active: true, reason: 'Mock reason' },
      { name: 'Control Measure Occupations', active: false, reason: '' },
    ]);
  }

  override openWebUI(): void {
    this._dialogService.open(ConfirmationDialogComponent, {
      data: {
        title: 'Web UI',
        message:
          'You are in DEV mode. Web UI is not available in the mock service.',
        confirmButton: 'OK',
        hideCancel: true,
      },
    });
  }

  override async loadDatabases(ip: string): Promise<string[]> {
    return dbList;
  }

  override async connectDB(db: string, live: boolean, host: string): Promise<boolean> {
    console.log(`Mock connect to DB: ${db}, live: ${live}, ip: ${host}`);
    this._stateService.updateConnectedDB({ database: db, live, connected: true, host: host });
    this._stateService.updateAvailableDBs(dbList);
    return true;
  }
  override async disconnectDB(): Promise<boolean> {
    console.log('Mock disconnect from DB');
    this._stateService.updateConnectedDB(defaultDb);
    this._stateService.updateAvailableDBs(dbList);
    return true;
  }
  override async configureMap(
    config: MapConfigData
  ): Promise<boolean> {
    this._dialogService.open(ConfirmationDialogComponent, {
      data: {
        title: 'Configure Map',
        message:
          'You are in DEV mode. Configure Map is not available in the mock service.',
        confirmButton: 'OK',
        hideCancel: true,
      },
    });
    return true;
  }

  override async getMapConfig(): Promise<MapConfigData> {
    return {
      alias: 'Default',
      url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
      type: 'WMS'
    };
  }
}
