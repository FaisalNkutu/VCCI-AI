import { inject, Injectable, isDevMode } from '@angular/core';
import { BaseAPI } from './base.api';
import { ElectronService } from './electron.service';
import { MockService } from './mock.service';

@Injectable({
  providedIn: 'root',
})
export class LauncherService extends BaseAPI {
  private _launchService: BaseAPI = isDevMode()
    ? inject(MockService)
    : inject(ElectronService);

  override openWebUI(): void {
    this._launchService.openWebUI();
  }

  override loadDatabases(ip: string): Promise<string[]> {
    return this._launchService.loadDatabases(ip);
  }

  override connectDB(db: string, live: boolean, host: string): Promise<boolean> {
    return this._launchService.connectDB(db, live, host);
  }
  override disconnectDB(): Promise<boolean> {
    return this._launchService.disconnectDB();
  }
  override configureMap(
    config: MapConfigData
  ): Promise<boolean> {
    return this._launchService.configureMap(config);
  }

  override getMapConfig(): Promise<MapConfigData> {
    return this._launchService.getMapConfig();
  }
}
