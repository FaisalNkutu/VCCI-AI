import { inject, Injectable } from '@angular/core';
import { StateService } from './state.service';
import { BaseAPI } from './base.api';

@Injectable({
  providedIn: 'root',
})
export class ElectronService extends BaseAPI {
  private _stateService = inject(StateService);

  constructor() {
    super();
    if (window.electron) {
      window.electron
        .invoke('get-available-dbs', this._stateService.getCurrentHost())
        .then((dbs: string[]) => {
          this._stateService.updateAvailableDBs(dbs);
        });
      window.electron.invoke('get-connected-db').then((db: ConnectedDB) => {
        this._stateService.updateConnectedDB(db);
      });
      window.electron.invoke('get-status').then((status: any) => {
        this._stateService.updateStatus(status);
      });
      window.electron.invoke('get-map-config').then((config: MapConfigData) => {
        this._stateService.updateMapConfig(config);
      });

      window.electron.on('update-available-dbs', (dbs: string[]) => {
        this._stateService.updateAvailableDBs(dbs);
      });

      window.electron.on('update-connected-db', (db: ConnectedDB) => {
        this._stateService.updateConnectedDB(db);
      });

      window.electron.on('update-status', (status: any) => {
        this._stateService.updateStatus(status);
      });
    }
  }

  private electronRunCommand(command: ElectronReceiveChannel, ...args: any[]) {
    if (window.electron) {
      window.electron.send(command, ...args);
    }
  }

  private async electronInvokeCommand(
    command: ElectronInvokeChannel,
    ...args: any[]
  ) {
    if (window.electron) {
      return window.electron.invoke(command, ...args);
    }
    return undefined;
  }

  override openWebUI() {
    this.electronRunCommand('open-web-ui');
  }

  override async loadDatabases(ip: string): Promise<string[]> {
    const dbs: string[] =
      (await this.electronInvokeCommand('get-available-dbs', ip)) || [];
    this._stateService.updateAvailableDBs(dbs);
    return dbs;
  }

  override async connectDB(
    db: string,
    live: boolean,
    host: string,
  ): Promise<boolean> {
    const result = await this.electronInvokeCommand(
      'connect-db',
      db,
      live,
      host,
    );
    return result ?? false;
  }

  override async disconnectDB(): Promise<boolean> {
    const result = await this.electronInvokeCommand('disconnect-db');
    return result ?? false;
  }

  override async configureMap(config: MapConfigData): Promise<boolean> {
    const result = await this.electronInvokeCommand('configure-map', config);
    return result ?? false;
  }

  override async getMapConfig(): Promise<MapConfigData> {
    const config = (await this.electronInvokeCommand(
      'get-map-config',
    )) as MapConfigData;
    return config;
  }
}
