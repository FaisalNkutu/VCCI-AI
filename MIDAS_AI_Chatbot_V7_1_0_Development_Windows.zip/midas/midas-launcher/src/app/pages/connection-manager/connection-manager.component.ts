import { CommonModule, NgOptimizedImage } from '@angular/common';
import { Component, computed, input, Input } from '@angular/core';
import {
  AbstractControl,
  FormControl,
  FormsModule,
  ReactiveFormsModule,
  ValidationErrors,
  Validators,
} from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatBadgeModule } from '@angular/material/badge';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTooltipModule } from '@angular/material/tooltip';
import { HelpDialogComponent } from '../../dialog/help-dialog/help-dialog.component';
import { AboutDialogComponent } from '../../dialog/about-dialog/about-dialog.component';
import { ConfigMapDialogComponent } from '../../dialog/config-map-dialog/config-map-dialog.component';
import { ConfirmationDialogComponent } from '../../dialog/confirmation-dialog/confirmation-dialog.component';
import { LauncherService } from '../../services/launcher.service';
import { defaultDb, StateService } from '../../services/state.service';
import { LoadingDialogComponent } from '../../dialog/loading-dialog/loading-dialog.component';

@Component({
  selector: 'connection-manager',
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatIconModule,
    NgOptimizedImage,
    MatSlideToggleModule,
    MatCardModule,
    MatListModule,
    MatInputModule,
    MatFormFieldModule,
    MatAutocompleteModule,
    MatTooltipModule,
    MatBadgeModule,
  ],
  templateUrl: './connection-manager.component.html',
  styles: [
    `
      ::ng-deep .mdc-list-item {
        height: auto !important;
      }

      /* Custom styling for invalid input */
      .mat-mdc-input-element.text-red-500 {
        color: #ef4444;
        caret-color: #ef4444;
      }

      /* Error message styling */
      .mat-mdc-form-field-error {
        color: #ef4444 !important;
      }

      .error {
        --mat-sys-primary: #e7000b;
        border: 2px solid #e7000b;
        color: #e7000b;
        background-color: #000;
      }

      .warn {
        --mat-sys-primary: #ffa726;
        border: 2px solid #ffa726;
        color: #ffa726;
      }

      .success {
        --mat-sys-primary: #16a34a;
        border: 2px solid #16a34a;
        color: #16a34a;
      }
    `,
  ],
})
export class ConnectionManagerComponent {
  @Input() databases: string[] = [];
  @Input() connectedDB: ConnectedDB = defaultDb;
  statusData = input.required<ProcessorStatus[]>();

  activeCount = computed(() => this.statusData().filter((p) => p.active && !p.reason).length);
  warningCount = computed(() => this.statusData().filter((p) => p.active && p.reason).length);
  inactiveCount = computed(() => this.statusData().filter((p) => !p.active).length);

  hostControl: FormControl;
  currentHost: string = '';

  constructor(
    private dialogService: MatDialog,
    private stateService: StateService,
    private launcherService: LauncherService
  ) {
    const currentHost = this.stateService.getCurrentHost();

    this.hostControl = new FormControl(currentHost, [
      Validators.required,
      this.hostValidator,
    ]);
    this.currentHost = currentHost;
  }

  private hostValidator(control: AbstractControl): ValidationErrors | null {
    if (!control.value) {
      return null; // Let required validator handle empty values
    }

    const value: string = control.value.toString().trim();

    const protocolPrefix = /(?:[a-zA-Z0-9\+\-\.]+:\/\/)/;

    const hostPattern =
      /(?:(?:[0-9]{1,3}\.){3}[0-9]{1,3}|(?:(?:[\w\-]+\.)+[a-zA-Z]{2,}|localhost))(?::\d{1,5})?/;

    const combinedPattern = new RegExp(
      `^${protocolPrefix.source}??${hostPattern.source}$`
    );

    if (!combinedPattern.test(value)) {
      return { invalid_format: true };
    }

    const hostPartWithPort =
      value.match(new RegExp(`${protocolPrefix.source}??(.*)$`))?.[1] || value;

    const parts = hostPartWithPort.split(':');
    const hostPart = parts[0];

    // Check the port if it exists (using the same check as before)
    if (parts.length > 1 && hostPartWithPort.match(/:(\d+)$/)) {
      const port = parseInt(parts.pop() as string, 10);
      if (port < 1 || port > 65535) {
        return { port_out_of_range: true };
      }
    }

    // Check if the hostPart looks like an IPv4 address
    const octets = hostPart.split('.');
    if (octets.length === 4) {
      for (const octet of octets) {
        const num = parseInt(octet, 10);
        // Check if octet is a number and within the valid range [0, 255]
        if (isNaN(num) || num < 0 || num > 255) {
          return { invalid_ip_octet: true };
        }
      }
    }

    return null;
  }

  isConnectedTo(db: string): boolean {
    return this.connectedDB.connected && this.connectedDB.database === db;
  }

  resetToDefault(): void {
    this.hostControl.setValue(defaultDb.host);
  }

  async configureMapDialog() {
    const config = await this.launcherService.getMapConfig();
    this.dialogService.open(ConfigMapDialogComponent, {
      data: {
        ...config,
        onConfirm: (data: MapConfigData) => {
          this.launcherService.configureMap(data);
        },
      },
    });
  }

  helpDialog(): void {
    this.dialogService.open(HelpDialogComponent);
  }

  aboutDialog(): void {
    this.dialogService.open(AboutDialogComponent);
  }

  launchDashboard(): void {
    this.launcherService.openWebUI();
  }

  async loadDatabases(): Promise<void> {
    let updateHost = true;
    if (this.hostControl.invalid) {
      this.hostControl.markAsTouched();
      return;
    }
    const dialog = this.dialogService.open(LoadingDialogComponent, {
      disableClose: true,
      data: {
        message: `Loading databases from "${this.hostControl.value}"...`,
      },
    });
    try {
      const dbs = await this.launcherService.loadDatabases(
        this.hostControl.value
      );
      if (dbs.length === 0) {
        this.dialogService.open(ConfirmationDialogComponent, {
          data: {
            title: 'No Databases Found',
            message: `No databases were found at "${this.hostControl.value}".`,
            confirmText: 'OK',
            hideCancel: true,
          },
        });
      }
    } catch {
      updateHost = false;
      this.dialogService.open(ConfirmationDialogComponent, {
        data: {
          title: 'Connection issue',
          message: 'Connection issue: Host unreachable, midas.exe failed to start locally or license is missing/expired.',
          confirmText: 'OK',
          hideCancel: true,
        },
      });
    }
    if (updateHost) {
      this.currentHost = this.hostControl.value;
    }
    dialog.close();
  }

  onConnectDb(db: string, live: boolean): void {
    if (this.connectedDB.connected) {
      this.dialogService.open(ConfirmationDialogComponent, {
        data: {
          title: 'Changing Databases',
          message:
            'Are you sure you want to change databases? Current dashboard and report data will be lost.',
          list: [
            `Disconnect ${this.connectedDB.database} (${
              this.connectedDB.live ? 'LIVE' : 'STATIC'
            })`,
            `Connect ${db} (${live ? 'LIVE' : 'STATIC'})`,
          ],
          confirmText: 'Confirm',
          onConfirm: async () => {
            await this.disconnectDatabase();
            await this.connectDatabase(db, live);
          },
        },
      });
    } else {
      this.connectDatabase(db, live);
    }
  }

  async connectDatabase(db: string, live: boolean): Promise<void> {
    const dialog = this.dialogService.open(LoadingDialogComponent, {
      disableClose: true,
      data: {
        message: `Connecting to ${db} in ${live ? 'LIVE' : 'STATIC'} mode...`,
      },
    });
    const connected = await this.launcherService.connectDB(
      db,
      live,
      this.currentHost
    );
    if (!connected) {
      dialog.close();
      this.dialogService.open(ConfirmationDialogComponent, {
        data: {
          title: 'Connection Failed',
          message: `Failed to connect to database ${db}. Please ensure the database exists and configured correctly.`,
          confirmText: 'OK',
          hideCancel: true,
        },
      });
      return;
    }
    dialog.close();
  }

  async disconnectDatabase(): Promise<void> {
    const dialog = this.dialogService.open(LoadingDialogComponent, {
      disableClose: true,
      data: { message: `Disconnecting from ${this.connectedDB.database}...` },
    });
    const connected = !(await this.launcherService.disconnectDB());
    if (connected) {
      dialog.close();
      this.dialogService.open(ConfirmationDialogComponent, {
        data: {
          title: 'Disconnection Failed',
          message: `Failed to disconnect from database ${this.connectedDB.database}. Please try again.`,
          confirmText: 'OK',
          hideCancel: true,
        },
      });
      return;
    }
    dialog.close();
  }
}
