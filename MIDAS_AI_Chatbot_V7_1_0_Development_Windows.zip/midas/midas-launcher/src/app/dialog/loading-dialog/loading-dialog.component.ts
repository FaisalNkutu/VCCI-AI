import { Component, Inject } from '@angular/core';
import { MatInputModule } from '@angular/material/input';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatProgressSpinner } from '@angular/material/progress-spinner';


@Component({
  selector: 'loading-dialog',
  imports: [
    MatInputModule,
    MatDialogModule,
    MatProgressSpinner
],
  templateUrl: './loading-dialog.component.html',
})
export class LoadingDialogComponent {
  constructor(@Inject(MAT_DIALOG_DATA) public data: { message: string, list?: string[] }) {}
}
