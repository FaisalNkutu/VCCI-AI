import { Component } from '@angular/core';
import { MatDialogContent } from "@angular/material/dialog";

@Component({
  selector: 'about-dialog',
  imports: [MatDialogContent],
  templateUrl: './about-dialog.component.html',
})
export class AboutDialogComponent {

}
