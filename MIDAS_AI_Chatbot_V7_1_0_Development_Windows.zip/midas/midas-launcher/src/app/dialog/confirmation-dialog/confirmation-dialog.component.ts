import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';

import { MatListModule } from "@angular/material/list";

export interface ConfirmationDialogData {
  title: string;
  message: string;
  list?: string[];
  confirmText?: string;
  cancelText?: string;
  hideCancel?: boolean;
  onConfirm: () => void | Promise<void>;
  onCancel?: () => void | Promise<void>;
}

@Component({
  selector: 'confirmation-dialog',
  imports: [MatDialogModule, MatButtonModule, MatListModule],
  templateUrl: './confirmation-dialog.component.html',
  styles: [
    `
      mat-dialog-actions {
        margin-bottom: 0;
        padding: 8px 24px;
      }
    `,
  ],
})
export class ConfirmationDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<ConfirmationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: ConfirmationDialogData,
  ) {}

  onConfirmClick(): void {
    if (this.data.onConfirm) {
      this.data.onConfirm();
    }
    this.dialogRef.close(true);
  }

  onCancelClick(): void {
    if (this.data.onCancel) {
      this.data.onCancel();
    }
    this.dialogRef.close(false);
  }
}
