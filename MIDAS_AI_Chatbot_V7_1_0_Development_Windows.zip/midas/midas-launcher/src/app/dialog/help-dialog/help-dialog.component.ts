import { Component } from '@angular/core';
import { MatDialogContent } from '@angular/material/dialog';

@Component({
  selector: 'help-dialog',
  imports: [MatDialogContent],
  templateUrl: './help-dialog.component.html',
})
export class HelpDialogComponent {

}
