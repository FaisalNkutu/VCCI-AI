
import { Component, Inject } from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MAT_DIALOG_DATA,
  MatDialogRef,
  MatDialogContent,
} from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';

@Component({
  selector: 'config-map-dialog',
  imports: [
    MatDialogContent,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatIconModule,
    MatSelectModule,
    MatButtonModule,
    MatInputModule
],
  templateUrl: './config-map-dialog.component.html',
})
export class ConfigMapDialogComponent {
  configForm: FormGroup;

  mapTypes = [
    { value: 'WMS', label: 'WMS (Web Map Service)' },
    { value: 'WMTS', label: 'WMTS (Web Map Tile Service)' },
    { value: 'CSW', label: 'CSW (Catalogue Service for the Web)' },
  ];

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<ConfigMapDialogComponent>,
    @Inject(MAT_DIALOG_DATA)
    public data: MapConfigData & { onConfirm: (data: MapConfigData) => void | Promise<void> }
  ) {
    this.configForm = this.fb.group({
      alias: [data?.alias || '', [Validators.required]],
      url: [data?.url || '', [Validators.required, this.urlValidator]],
      type: [data?.type || this.mapTypes[0].value, [Validators.required]],
    });
  }

  // Custom URL validator that accepts ports
  urlValidator(control: AbstractControl): { [key: string]: any } | null {
    if (!control.value) {
      return null; // Don't validate empty values, let required handle that
    }

    // Regex pattern that matches URLs with optional ports
    const urlPattern = /^https?:\/\/([\w\-]+(\.[\w\-]+)*)(:\d+)?(\/.*)?$/i;

    if (!urlPattern.test(control.value)) {
      return { invalidUrl: true };
    }

    return null;
  }

  get aliasControl() {
    return this.configForm.get('alias')!;
  }
  get urlControl() {
    return this.configForm.get('url')!;
  }
  get typeControl() {
    return this.configForm.get('type')!;
  }

  clearUrl(): void {
    this.urlControl.setValue('');
    this.urlControl.markAsTouched();
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  async onSave(): Promise<void> {
    if (this.configForm.valid) {
      const result: MapConfigData = this.configForm.value;
      await this.data.onConfirm(result);
      this.dialogRef.close();
    } else {
      // Mark all fields as touched to show validation errors
      this.configForm.markAllAsTouched();
    }
  }
}
