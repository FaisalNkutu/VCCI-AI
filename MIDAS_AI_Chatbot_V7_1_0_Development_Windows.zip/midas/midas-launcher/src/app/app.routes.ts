import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./pages/connection-manager/connection-manager.component').then(
        (m) => m.ConnectionManagerComponent
      ),
  },
  // {
  //   path: 'logs',
  //   loadComponent: () =>
  //     import('./pages/logs/logs.component').then((m) => m.LogsComponent),
  // },
  // {
  //   path: 'license',
  //   loadComponent: () =>
  //     import('./pages/license/license.component').then((m) => m.LogsComponent),
  // },
  // {
  //   path: 'about',
  //   loadComponent: () =>
  //     import('./pages/about/about.component').then((m) => m.LogsComponent),
  // },
];
