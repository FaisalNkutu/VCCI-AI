// Define types for the API exposed to the renderer
interface ElectronAPI {
  send: (channel: ElectronReceiveChannel, ...data: any) => void;
  invoke: <T = any>(channel: ElectronInvokeChannel, ...args: any[]) => Promise<T>;
  on: <T = any>(channel: ElectronPushChannel, callback: (data: T) => void) => void;
}
// Add global type declarations for TypeScript
interface Window {
  electron: ElectronAPI;
}

type ElectronInvokeChannel =
  | 'get-connected-db'
  | 'get-available-dbs'
  | 'get-status'
  | 'connect-db'
  | 'disconnect-db'
  | 'configure-map'
  | 'get-map-config'

  type ElectronReceiveChannel =
  | 'open-web-ui'

type ElectronPushChannel =
  | 'update-status'
  | 'update-connected-db'
  | 'update-available-dbs'
