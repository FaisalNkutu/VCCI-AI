/*------------------------------------------------------------------------------------
Top level Package Installer
------------------------------------------------------------------------------------*/
!addincludedir ".\target\common-installer\NSIS\"

!include "UI\MUI2_Simfront1.nsh"
; !include "UI\UMUI_Simfront1.nsh"
!include nsDialogs.nsh
!include "LogicLib.nsh"
!include "x64.nsh"

!include "project.nsh"
!include "Corporate.nsh"
!include "Config_3rdPartyInstaller.nsh"
!include "ServiceController.nsh"

;-------------------------------------------------------------------------------
; Variables
;-------------------------------------------------------------------------------
Var tmpInstallDir
Var Dialog
Var Label
Var exitcode
Var StdOutText
Var bAppInstalled

Var SFINSTALLDIR
Var SuiteDir
Var Suite_Folder_Exists


!define /date NOW "%H:%M:%S %d %b, %Y"
!define PROJECT_SUITE_REG_KEY "SOFTWARE\${SUITE_NAME}"
!define PROJECT_APP_REG_KEY "${PROJECT_SUITE_REG_KEY}\${PACKAGE_NAME}"
!define /redef MUI_ICON ${PACKAGE_NAME}.ico

;------------------------------------------------------------------------------------
;Interface Settings
;------------------------------------------------------------------------------------
Name "${PROJECT_NAME} Bundle"
#OutFile "${NSIS_OUTFILE}"

VIAddVersionKey ProductName ${PROJECT_NAME}
VIAddVersionKey ProductVersion ${PASSPORT_NUMVERSION}
VIAddVersionKey FileDescription "${PROJECT_NAME} Bundle"
VIProductVersion ${PASSPORT_NUMVERSION}

!define MUI_CUSTOMFUNCTION_ABORT "CleanUp"


;------------------------------------------------------------------------------------
; Dialog Pages and Sequencing
;------------------------------------------------------------------------------------
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_LICENSE "${PROJECT_BUILD_DIR}\dist\Calian_VTS_License_Agreement.rtf"
!define MUI_PAGE_CUSTOMFUNCTION_LEAVE LeaveComponentPage
!insertmacro MUI_PAGE_COMPONENTS
!define MUI_PAGE_CUSTOMFUNCTION_PRE Skip_DirectoryPage
!define MUI_PAGE_CUSTOMFUNCTION_LEAVE Leave_DirectoryPage
!insertmacro MUI_PAGE_DIRECTORY
Page custom UpdateSummaryText
Page custom DlgSummary
!insertmacro MUI_PAGE_INSTFILES

!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_LANGUAGE "English"

; This entry must be the first line written to the temp file, and must appear before including other .nsh scripts that use this macro. (MuiDescriptionText)
; It is only possible to have the BEGIN and END tags appear once in the final installer script.
; Therefore, writting to a temp file made is possible to make the parent nsi script as generic as possible and put all required values within their respective nsh scripts.
!system 'echo !insertmacro MUI_FUNCTION_DESCRIPTION_BEGIN > descs.nsh'

;-------------------------------------------------------------------------------
; Imports
;-------------------------------------------------------------------------------

!include "ThirdParty.nsh"
!include "CommonFunctions.nsh"
!include "DlgSummary.nsi"

;-------------------------------------------------------------------------------
; Begin Sections
;-------------------------------------------------------------------------------

!define /redef LICENSING_TOOLS_VERSION "${PASSPORT_LICENSING_TOOLS_VERSION}"
!include "LicenseServiceInstaller.nsi"

Section "${PROJECT_NAME}" SID_app
    
    SetOutPath $EXEDIR
	File ${PROJECT_BUILD_DIR}\${INSTALL_OUTFILE_NAME}.msi
    DetailPrint "Launching ${INSTALL_OUTFILE_NAME}.msi"
    ExecWait 'msiexec /i "$EXEDIR\${INSTALL_OUTFILE_NAME}.msi" SFINSTALLDIR="$SFINSTALLDIR" ADDLOCAL=ALL /norestart /quiet /passive'
  
SectionEnd

Section /o "-${PROJECT_NAME}_remove" SID_app_remove  
    
    SetOutPath $EXEDIR
	File ${PROJECT_BUILD_DIR}\${INSTALL_OUTFILE_NAME}.msi    
    DetailPrint "Launching ${INSTALL_OUTFILE_NAME}.msi"
    nsExec::ExecToStack 'msiexec /x "$EXEDIR\${INSTALL_OUTFILE_NAME}.msi" /quiet /passive /norestart'
  
SectionEnd

Section "-Log" SID_LOG	
	${LogText} "Creating Installation log file ${INSTALL_LOG_FILE}"	
	CopyFiles /silent "$INSTDIR\install.log" "${INSTALL_LOG_FILE}"
SectionEnd


;------------------------------------------------------------------------------------
; Section Descriptions
;------------------------------------------------------------------------------------

LangString DESC_SID_app ${LANG_ENGLISH} "The ${PROJECT_NAME} application"
!insertmacro MuiDescriptionText ${SID_app} $(DESC_SID_app)

; this entry must be the last line written to the temp file and must appear after including other .nsh scripts that use this macro.
!system 'echo !insertmacro MUI_FUNCTION_DESCRIPTION_END >> descs.nsh'
!include descs.nsh

;-------------------------------------------------------------------------------
; Callback Functions
;-------------------------------------------------------------------------------

Function .onInit
 
${PreventMultipleInstances}

# If INSTDIR is set at cmd line then skip setting INSTDIR here
${If} $INSTDIR == "" 
	${If} ${RunningX64}
	DetailPrint "Running on 64-bit host $INSTDIR=$PROGRAMFILES64"
	StrCpy $INSTDIR "$PROGRAMFILES64"
	${Else}
	DetailPrint "Running on 32-bit host $INSTDIR=$PROGRAMFILES"
	StrCpy $INSTDIR "$PROGRAMFILES"
	${EndIf}
${EndIf}

${If} ${RunningX64}
DetailPrint "Running on 64-bit host, set Reg64"
	SetRegView 64	
${Else}	
DetailPrint "Running on 32-bit host, set Reg32"
	SetRegView 32
${EndIf}

${LogSet} on #INSTDIR must be set before LogSet is called
${LogText} "Install Initializing..." 
        
    StrCpy $bAppInstalled "false"
    Call Init_INSTDIR	
	Call Check_InstalledApp	 

   
 
	StrCpy $tmpInstallDir "$TEMP\${PACKAGE_NAME}_tmp"
	CreateDirectory $tmpInstallDir
    
	!ifdef Enable_3rdparty
	Call 3rdPartyInit
	!endif
    
    Call LicenseServiceInstaller_init

    ${GetParameters} $R0 ;Get the full command line


FunctionEnd

Function .onInstSuccess

Call CleanUp

!ifdef Enable_3rdparty
    call 3rdPartySuccess
!endif

FunctionEnd

Function .onInstFailed
	Call CleanUp    
FunctionEnd


#-------------------------------------------------------------------------------
# Functions
#-------------------------------------------------------------------------------


Function LeaveComponentPage

!insertmacro UnSelectSection ${SID_app_remove}

DetailPrint "*Leaving Component Page..."
${If} ${SectionIsSelected} ${SID_app}
StrCpy $ForceSkipDirectoryPage false
${Else}
StrCpy $ForceSkipDirectoryPage true
    ${If} $bAppInstalled == "true"
        MessageBox MB_YESNO "Do you wish to completely remove ${PROJECT_NAME}" IDYES true IDNO false
        true:
        !insertmacro SelectSection ${SID_app_remove}
        false:
    ${EndIf}

${EndIf}

FunctionEnd


Function UpdateSummaryText
${ResetSummaryText}

${If} ${SectionIsSelected} ${SID_app_remove}
    ${AndIf} $bAppInstalled == "true"
    ${AddSummaryText} "Proceed to completely remove ${PROJECT_NAME}"
${EndIf}

${If} ${SectionIsSelected} ${SID_app}
${AddSummaryText} "Install Location: $SuiteDir\${PACKAGE_NAME}"
${AddSummaryText} "Component: ${PROJECT_NAME}"
${EndIf}

!ifdef Enable_LicenseService
${If} ${SectionIsSelected} ${SID_LicenseService}
${AddSummaryText} "Component: VTS License Service"
${EndIf}
!endif



FunctionEnd

Function CleanUp
DetailPrint "Cleaning up..."
SetOutPath $TEMP #SetOutPath must be changed before $tmpInstallDir can be removed
   RMDir /r $tmpInstallDir
   !ifdef Enable_3rdparty
   call 3rdPartyCleanup
   !endif
FunctionEnd

Function Init_INSTDIR
    
    StrCpy $SFINSTALLDIR "$INSTDIR"
    StrCpy $SuiteDir "$SFINSTALLDIR\${SUITE_NAME}"   
   
    ;if Suite path exists in registry, then re-set SuiteDir & SFINSTALLDIR
    ReadRegStr $0 HKLM "${PROJECT_SUITE_REG_KEY}" ""
    Push $0
    Call RemoveTrailingBackslash        
         Pop $0
        ${If} $0 != "" 
        ${AndIf} ${FileExists} '$0'
        StrCpy $Suite_Folder_Exists "true"
        StrCpy $SuiteDir "$0" #SuiteDir from registry
        Push '$0'
        Call GetParentFolder
        Pop $R0
        StrCpy $SFINSTALLDIR '$R0' #SFINSTALLDIR from SuiteDir Path             
        ${EndIf}        

FunctionEnd

Function Skip_DirectoryPage
${If} $Suite_Folder_Exists == "true"
${OrIf} $ForceSkipDirectoryPage == "true"
Abort ; dont allow to change directory install
${EndIf}
FunctionEnd

Function Leave_DirectoryPage 
 ${IfNot} ${Silent}
        StrCpy $SFINSTALLDIR "$INSTDIR"
        StrCpy $SuiteDir "$SFINSTALLDIR\${SUITE_NAME}"              
 ${EndIf}
FunctionEnd

Function Check_InstalledApp
DetailPrint "*Checking for installed application..."
    # Search to see if the Product is already installed.
    
    ReadRegStr $0 HKLM "${PROJECT_APP_REG_KEY}" ""
	
    ${If} $0 != ""
        ${AndIf} ${FileExists} "$0\*.*"
        StrCpy $bAppInstalled "true"
        !insertmacro UnselectSection ${SID_app_group}
    ${EndIf}
   
FunctionEnd

