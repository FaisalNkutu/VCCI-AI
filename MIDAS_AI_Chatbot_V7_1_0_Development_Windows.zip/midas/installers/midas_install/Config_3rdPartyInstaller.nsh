
/****************************** NOTE **************************************************************************************************************************************************************
- This file must be placed in the same folder as the parent installer project. Make sure to include this config file in the parent installer. example: !include ".\Config_3rdPartyInstaller.nsh"
- Setting values, when a component is NOT enabled, will do no harm.
- Not setting values when a component is enabled will cause error.

**************************************************************************************************************************************************************************************************/

/**************************** MariaDB Config - required when Enable_MariaDB ****************************/



/**************************** ENABLERS ***************************/
/*Enable desired components to be installed.*/

!define Enable_3rdparty ;Must be enabled if any subcomponent is enabled. 
; subcomponents will be appended to this file from the Dynamic Packaging Job