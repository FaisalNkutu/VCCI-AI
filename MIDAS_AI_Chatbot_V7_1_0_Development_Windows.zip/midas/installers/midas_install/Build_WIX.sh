#!/bin/bash

rm -f del $INSTALL_OUTFILE_NAME

mkdir "$PROJECT_BUILD_DIRECTORY/tmp"

wix build -intermediatefolder "$PROJECT_BUILD_DIRECTORY/tmp" -cc "$PROJECT_BUILD_DIRECTORY/tmp"  -dcl none -arch x64 -ext WixToolset.Util.wixext -ext WixToolset.UI.wixext -loc "$WIXDIR/UI/Simfront_en-us.wxl" $PROJECT_BUILD_DIRECTORY/wixlibs/midas_msm.wixlib "$PROJECT_BASEDIR/${PROJECT_ARTIFACT_ID}_Setup.wxs" -o "$PROJECT_BUILD_DIRECTORY/$INSTALL_OUTFILE_NAME.msi"

exit_code=$?
if [ $exit_code -ne 0 ]; then
  echo "WiX build failed with exit code $exit_code"
  exit $exit_code
fi 

rm -f $PROJECT_BUILD_DIRECTORY/null /Q
rm -f $PROJECT_BASEDIR/null /Q

   
