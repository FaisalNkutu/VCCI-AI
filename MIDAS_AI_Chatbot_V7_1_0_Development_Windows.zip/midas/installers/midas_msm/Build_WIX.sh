#!/bin/bash
# Builds wixlib (MergeModule)


mkdir "$PROJECT_BUILD_DIRECTORY/tmp"

wix build -intermediatefolder "$PROJECT_BUILD_DIRECTORY/tmp" -cc "$PROJECT_BUILD_DIRECTORY/tmp"  -bf -dcl none -arch x64 -ext WixToolset.Util.wixext -ext WixToolset.UI.wixext -loc "$WIXDIR/UI/Simfront_en-us.wxl"  $PROJECT_BASEDIR/$PROJECT_ARTIFACT_ID.wxs -o $PROJECT_BUILD_DIRECTORY/$PROJECT_ARTIFACT_ID.wixlib

exit_code=$?
if [ $exit_code -ne 0 ]; then
  echo "WiX build failed with exit code $exit_code"
  exit $exit_code
fi 
