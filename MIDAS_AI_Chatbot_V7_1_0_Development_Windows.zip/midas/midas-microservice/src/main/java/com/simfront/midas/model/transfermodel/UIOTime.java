/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */
package com.simfront.midas.model.transfermodel;

/**
 *
 * @author rhans
 */
public class UIOTime {

    long jTime = -1;
    String jFormattedTime;

    public UIOTime(long t) {
        jTime = t;
    }

    public long getTime() {
        return jTime;
    }

    public void setTime(long time) {
        jTime = time;
    }

    public String getFormattedTime() {
        return jFormattedTime;
    }

    public void setFormattedTime(String formattedTime) {
        jFormattedTime = formattedTime;
    }
}
