/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */
package com.simfront.midas.model.transfermodel;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author rhans
 */
public class UIOCombatPowerResults {

    ArrayList<UIOTime> jTimeArray = new ArrayList();
    HashMap<Long, ArrayList<UIOCPowerGraphPoint>> jEntCPHash = new HashMap();

    // The average will not have entity Id set
    ArrayList<UIOCPowerGraphPoint> jAverage = new ArrayList();

    public UIOCombatPowerResults() {

    }

    public ArrayList<UIOTime> getTimeArray() {
        return jTimeArray;
    }

    public void setTimeArray(ArrayList<UIOTime> timeArray) {
        jTimeArray = timeArray;
    }
    
    public HashMap<Long, ArrayList<UIOCPowerGraphPoint>> getEntCPHash() {
        return jEntCPHash;
    }

    public void setEntCPHash(HashMap<Long, ArrayList<UIOCPowerGraphPoint>> entCPHash) {
        jEntCPHash = entCPHash;
    }
    
    public ArrayList<UIOCPowerGraphPoint> getAverage() {
        return jAverage;
    }

    public void addPoint(
            long entityId,
            String entityName,
            long time,
            String formattedTime,
            double cpower) {
        UIOCPowerGraphPoint pt = new UIOCPowerGraphPoint(entityName, time, formattedTime, cpower);

        ArrayList<UIOCPowerGraphPoint> arr;
        if (jEntCPHash.containsKey(entityId)) {
            arr = jEntCPHash.get(entityId);
        } else {
            arr = new ArrayList();
            jEntCPHash.put(entityId, arr);
        }
        arr.add(pt);
    }

    public void calcAverage() {

        HashMap<Long, UIOCPowerGraphPoint> earliestPoint = new HashMap();
        HashMap<Long, ArrayList<UIOCPowerGraphPoint>> hCopy = null;
        HashMap<Long, Double> lastCPUsed = new HashMap();

        // Copy data so we can eliminate as we go
        hCopy = copyPoints();

        // Now caculate the average across all arrays
        long earliestTime = Long.MAX_VALUE;
        String earliestFormatted = null;

        UIOCPowerGraphPoint check;
        boolean done = false;

        int numEnts = hCopy.keySet().size();

        //  These will be the keys for all calcs
        Set<Long> selectedEnts = hCopy.keySet();

        while (!done) {
            // Find next points in lists that need them
            for (Long entId : selectedEnts) {
                if (hCopy.containsKey(entId)) {
                    ArrayList<UIOCPowerGraphPoint> arr = hCopy.get(entId);

                    if (!arr.isEmpty() && !earliestPoint.containsKey(entId)) {
                        earliestPoint.put(entId, arr.get(0));
                        // And remove from array
                        arr.remove(0);
                    }
                }
            }

            if (earliestPoint.isEmpty()) {
                done = true;
                break;
            }

            earliestTime = Long.MAX_VALUE;
            for (Long entId : earliestPoint.keySet()) {
                // Get earliest time among all these times
                check = earliestPoint.get(entId);
                if (check != null) {
                    if (check.jTime < earliestTime) {
                        earliestTime = check.jTime;
                        earliestFormatted = check.jFormattedTime;
                    }
                }
            }

            // Now check all points again to see if we have any at the same
            // time as earliest : if so, use those values as well, if not, use
            // the last CP used - if any
            double avg = 0.0;
            UIOCPowerGraphPoint pt;
            Set<Long> remove = new HashSet();
            for (Long entId : selectedEnts) {
                if (earliestPoint.containsKey(entId)) {
                    pt = earliestPoint.get(entId);
                    if (pt.jTime == earliestTime) {
                        avg += pt.jCombatPower;
                        lastCPUsed.put(entId, pt.jCombatPower);
                        remove.add(entId);
                    } else {
                        if (lastCPUsed.containsKey(entId)) {
                            avg += lastCPUsed.get(entId);
                        }
                    }
                } else {
                    if (lastCPUsed.containsKey(entId)) {
                        avg += lastCPUsed.get(entId);
                    }
                }
            }
            for (long id : remove) {
                // Make room for next point 
                earliestPoint.remove(id);
            }

            // Save average for this time
            if (earliestTime != Long.MAX_VALUE && numEnts > 0) {
                UIOCPowerGraphPoint avgPt = new UIOCPowerGraphPoint(
                        null, earliestTime, earliestFormatted, avg / numEnts);
                jAverage.add(avgPt);
            }
        }
    }


    private HashMap<Long, ArrayList<UIOCPowerGraphPoint>> copyPoints() {
        HashMap<Long, ArrayList<UIOCPowerGraphPoint>> hCopy = new HashMap();

        for (Long entId : jEntCPHash.keySet()) {
            ArrayList<UIOCPowerGraphPoint> arr = jEntCPHash.get(entId);
            ArrayList<UIOCPowerGraphPoint> arrCopy = new ArrayList();

            for (UIOCPowerGraphPoint p : arr) {
                arrCopy.add(p.clone());
            }
            hCopy.put(entId, arrCopy);
        }
        return hCopy;
    }
}
