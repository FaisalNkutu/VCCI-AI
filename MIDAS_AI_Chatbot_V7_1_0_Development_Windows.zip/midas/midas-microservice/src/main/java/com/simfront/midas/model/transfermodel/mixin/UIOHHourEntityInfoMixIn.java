/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel.mixin;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 * @author rhans
 */
public abstract class UIOHHourEntityInfoMixIn extends UIOBaseMixIn {

    @JsonProperty("deviation")
    public abstract long getDeviationMins();
}
