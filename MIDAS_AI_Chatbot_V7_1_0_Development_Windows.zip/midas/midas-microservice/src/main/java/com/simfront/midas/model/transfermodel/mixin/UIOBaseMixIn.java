/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel.mixin;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 * @author rhans
 */
public abstract class UIOBaseMixIn {

    @JsonProperty("name")
    public abstract String getName();

    @JsonProperty("id")
    public abstract long getId();

    @JsonProperty("lat")
    public abstract double getLat();

    @JsonProperty("lon")
    public abstract double getLon();

    @JsonProperty("time")
    public abstract long getTime();

    @JsonProperty("formattedtime")
    public abstract String getFormattedTime();

}
