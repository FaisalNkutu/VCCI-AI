/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.calian.paradigm.core.bto.model.gobjs.gen.*;

/**
 *
 * @author rhans
 */
public class UIOHHourMetricsResult extends UIOMetricResult {

    @JsonIgnore
    GHhourMetricsResults jResult = null;

    public UIOHHourMetricsResult(GHhourMetricsResults result) {
        jResult = result;
        // UIOBase
        super.setId(result.getHhourMetricsResultsLineOfDepartureId());
        super.setName(result.getHhourMetricsResultsLineOfDepartureName());
        super.setTime(result.getMetricsResultsTime());
        super.setLon(result.getHhourMetricsResultsLongitudeCoordinate());
        super.setLat(result.getHhourMetricsResultsLatitudeCoordinate());
        // UIOMetricResult
        super.setSpecId(result.getMetricsResultsMetricsSpecificationIndex());
        super.setObjectItemId(result.getMetricsResultsObjectItemId());
        super.setSimStartTime(result.getMetricsResultsSimulationStartTime());
    }
    
    public GHhourMetricsResults getOMDBResult() {
        return jResult;
    }
}
