/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

import io.micronaut.core.annotation.Introspected;
import com.fasterxml.jackson.annotation.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Transfer model representing a unit node in an ORBAT (Order of Battle) hierarchy.
 *
 * This class is serialized to JSON and sent to the frontend.
 * It supports nesting child units recursively through a list of UIOOrbatAssociation children.
 *
 * Each instance represents one unit in the hierarchy and includes:
 * - Unit ID
 * - Unit name
 * - Military symbol
 * - List of child units (if any)
 *
 * Metadata like parentId and internal names are excluded from JSON using @JsonIgnore.
 *
 * Example JSON:
 * {
 *   "id": ,
 *   "name": "",
 *   "symbol": "",
 *   "children": [ ... ]
 * }
 *
 * @author r.hassan
 */

@Introspected
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "id", "name", "symbol", "children" })
public class UIOOrbatAssociation {
    // --- backing fields (all ignored for JSON) ---
    @JsonIgnore private final long jParentId;
    @JsonIgnore private final long jChildId;
    @JsonIgnore private final String jChildName;

    // --- fields that do appear in your JSON ---
    private final String jSymbol;
    private final List<UIOOrbatAssociation> jChildren = new ArrayList<>();
    private boolean jIsFriendly;  // will be serialized as "isFriendly"

    /**
     * Constructor for a standalone node (e.g., orphan unit with no parent).
     *
     * @param childId   The ID of the unit
     * @param childName The name of the unit
     * @param symbol    The unit's military symbol
     */
    public UIOOrbatAssociation(long childId,
                               String childName,
                               String symbol) {
        this(0, childId, childName, symbol); // 0 = dummy parentId
    }

    /**
     * Constructor for a full association (used when building the ORBAT tree).
     *
     * @param parentId   The ID of the parent unit (not shown in JSON)
     * @param childId    The ID of this unit
     * @param childName  The name of this unit
     * @param symbol     Military symbol for this unit
     */
    public UIOOrbatAssociation(long parentId,
                               long childId,
                               String childName,
                               String symbol) {
        this.jParentId   = parentId;
        this.jChildId    = childId;
        this.jChildName  = childName;
        this.jSymbol     = symbol;
    }


    // --- JSON getters ---
    @JsonProperty("id")
    public long getId() {
        return jChildId ;
    }

    @JsonProperty("name")
    public String getName() {
        return jChildName ;
    }

    @JsonProperty("symbol")
    public String getSymbol() {
        return jSymbol;
    }

    @JsonProperty("children")
    public List<UIOOrbatAssociation> getChildren() {
        return jChildren;
    }

    @JsonProperty("isFriendly")
    public boolean isIsFriendly() { return jIsFriendly; }

    public void setIsFriendly(boolean isFriendly) { this.jIsFriendly = isFriendly; }


    // Used when assembling the tree
    public void addChild(UIOOrbatAssociation child) {
        jChildren.add(child);
    }

    @JsonIgnore
    public long getParentId() {
        return jParentId;
    }
}
