/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

/**
 *
 * @author rhans
 */
public class UIOHHourEntityInfo extends UIOBase {

    long jHHourDeviationMins;

    public UIOHHourEntityInfo(
            String name,
            long id,
            double lat,
            double lon,
            long deviation) {
        super(name, id, lat, lon);
        jHHourDeviationMins = deviation;
    }

    public long getDeviationMins() {
        return jHHourDeviationMins;
    }
}
