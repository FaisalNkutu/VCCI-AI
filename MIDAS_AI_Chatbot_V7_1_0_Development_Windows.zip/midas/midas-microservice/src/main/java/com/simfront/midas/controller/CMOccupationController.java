/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.controller;

import com.simfront.midas.CentralDispatch;
import com.simfront.midas.constants.MIDASConstants;
import com.simfront.midas.model.transfermodel.UIOCMEntity;
import com.simfront.midas.model.transfermodel.UIOCMOccupation;
import com.simfront.midas.utils.RequestResults;
import com.calian.paradigm.core.metrics.MetricsConstants;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.QueryValue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @author rhans This is the controller for the CM Occupations Dashboard. There
 * are mixins for all the returned objects
 */
@Controller("/advmetrics/cmocc")
public class CMOccupationController {

    /**
     * Based on the simulation time selected, the list of selected control
     * measures and the currently deselected entities, this endpoint returns a
     * hash (by control measure id) of the entities occupying those control
     * measures (and associated data of the occupation)
     *
     * @param startTime
     * @param endTime
     * @param selectedControlMeasures
     * @param deselectedEntities
     * @return hashmap<control-measure-id> --> array<entity-name>
     */
    @Get("/results-by-time")
    public HttpResponse<HashMap<Long, List<UIOCMEntity>>> getCMOccupationResultsByTime(
            @QueryValue long startTime,
            @QueryValue long endTime,
            @QueryValue List<Long> selectedControlMeasures,
            @QueryValue List<Long> deselectedEntities) {
        ArrayList<Object> params = new ArrayList();
        params.add(startTime);
        params.add(endTime);
        if (selectedControlMeasures == null) {
            selectedControlMeasures = new ArrayList();
        }
        if (deselectedEntities == null) {
            deselectedEntities = new ArrayList();
        }
        params.add(selectedControlMeasures);
        params.add(deselectedEntities);
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_CM_OCCUPATIONS_BY_TIME_RESULTS,
                params,
                false);

        ArrayList<Object> res = rr.getResults();
        HashMap<Long, List<UIOCMEntity>> obj = (HashMap<Long, List<UIOCMEntity>>) res.get(0);
        return HttpResponse.ok(obj);
    }

    /**
     * @param timeFormat
     * @param startTime
     * @param endTime
     * @param interval   - return results every "interval" (default is 1 minute)
     * @return hashmap<control-measure-id> --> int (count of entities)
     */
    @Get("/results")
    public HttpResponse<HashMap<Long, UIOCMOccupation>> getCMOccupationResults(
            @QueryValue String timeFormat,
            @QueryValue long startTime,
            @QueryValue long endTime,
            @QueryValue int interval,
            @QueryValue List<Long> cmOccIds,
            @QueryValue List<Long> deselectedEntities) {
        ArrayList<Object> params = new ArrayList();
        params.add(timeFormat);
        params.add(startTime);
        params.add(endTime);
        params.add(interval);
        params.add(cmOccIds);
        params.add(deselectedEntities);

        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_CM_OCCUPATIONS_RESULTS,
                params,
                false);

        ArrayList<Object> res = rr.getResults();
        HashMap<Long, UIOCMOccupation> obj = (HashMap<Long, UIOCMOccupation>) res.get(0);
        return HttpResponse.ok(obj);
    }

    /**
     * This request returns the count of entities in each selected control
     * measure for the entire exercise time.The results are returned by time
     * increments.
     *
     * @param selectedControlMeasures
     * @param timeFormat
     * @return hashmap<time> --> <UIOCMOccupation>
     */
    @Get("/cmoccupations")
    public HttpResponse<HashMap<Long, UIOCMOccupation>> getCMOccupationResults(
            @QueryValue List<Long> selectedControlMeasures,
            @QueryValue String timeFormat) {
        ArrayList<Object> params = new ArrayList();
        if (selectedControlMeasures == null) {
            selectedControlMeasures = new ArrayList();
        }
        params.add(selectedControlMeasures);
        params.add(timeFormat);
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_CM_OCCUPATIONS,
                params,
                false);

        ArrayList<Object> res = rr.getResults();
        HashMap<Long, UIOCMOccupation> obj = (HashMap<Long, UIOCMOccupation>) res.get(0);
        return HttpResponse.ok(obj);
    }

    /**
     * Gets all the entities associated with a capture
     *
     * @return UIOBase objects
     */
    @Get("/entities")
    public HttpResponse<List<Object>> getMetricsEntities(List<Long>cmOccIds) {
        ArrayList<Object> params = new ArrayList();
        params.add(MetricsConstants.E_METRIC.CM_OCCUPATIONS);
        params.add(cmOccIds);

        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_METRICS_ENTITIES,
                params,
                true);
        if (rr.isSuccess()) {
            ArrayList<Object> ents = rr.getResults();
            return HttpResponse.ok(ents);
        } else {
            return HttpResponse.serverError();
        }
    }

    /**
     * Gets the full list of control measures that were occupied
     *
     * @return ArrayList<ControlMeasureInfo>
     */
    @Get("/controlmeasures")
    public HttpResponse<List<Object>> getCMOccupationControlMeasures() {
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_CM_OCCUPATIONS_CMS,
                null,
                false);
        return HttpResponse.ok(rr.getResults());
    }
}
