/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.controller;

import com.simfront.midas.CentralDispatch;
import com.simfront.midas.constants.MIDASConstants;
import com.simfront.midas.utils.RequestResults;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.QueryValue;

import java.util.ArrayList;
import java.util.List;

/**
 * @author rhans This is the controller for the Fratricide Dashboard. There are
 * mixins for all the returned objects
 */
@Controller("/advmetrics/frat")
public class FratricideController {

    @Get("/graph")
    public HttpResponse<List<Object>> getFratricideGraph(
            @QueryValue long startTime,
            @QueryValue long endTime,
            @QueryValue long interval,
            @QueryValue String format) {
        ArrayList<Object> params = new ArrayList();
        params.add(startTime);
        params.add(endTime);
        params.add(interval);
        params.add(format);
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_FRATRICIDE_GRAPH,
                params,
                false);
        return HttpResponse.ok(rr.getResults());
    }

    @Get("/incidentsattime")
    public HttpResponse<List<Object>> getFratricideResults(
            @QueryValue long time,
            @QueryValue long interval,
            @QueryValue String format) {
        ArrayList<Object> params = new ArrayList();
        params.add(time);
        params.add(interval);
        params.add(format);
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_FRATRICIDE_INCIDENTS_AT_TIME,
                params,
                false);
        return HttpResponse.ok(rr.getResults());
    }

    // Can dashboard handle this one based on last call to get results
    // Just cache by ID and then look up (MAGI)
    /**
     *
     * @param fireEventId - this is the fire event id which may result in
     * multiple fratricide incidents returned
     * @param format
     * @return
     */
    @Get("/incidentdetails")
    public HttpResponse<List<Object>> getFratricideDetails(
            @QueryValue long fireEventId,
            @QueryValue String format) {
        ArrayList<Object> params = new ArrayList();
        params.add(fireEventId);
        params.add(format);
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_FRATRICIDE_INCIDENT_DETAILS,
                params,
                false);
        return HttpResponse.ok(rr.getResults());
    }
}
