/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */
package com.simfront.midas.model.transfermodel;

import java.util.ArrayList;

/**
 * @author rhans
 */
public class UIOCombatPowerDetail {

    long jEntityID;
    String jEntityName;
    long jSimulationTime;
    String jFormattedTime;
    double jCombatPower;

    public ArrayList<UIOHolding> jHoldings = new ArrayList();

    public UIOCombatPowerDetail(
            long entityId,
            String entityName) {
        jEntityID = entityId;
        jEntityName = entityName;
    }

    public String getEntityName() {
        return jEntityName;
    }

    public void setEntityName(String entityName) {
        jEntityName = entityName;
    }

    public double getCombatPower() {
        return jCombatPower;
    }

    public long getEntityID() {
        return jEntityID;
    }

    public ArrayList<UIOHolding> getHoldings() {
        return jHoldings;
    }

    public void setCombatPower(double combatPower) {
        jCombatPower = combatPower;
    }

    public void addHolding(UIOHolding h) {
        jHoldings.add(h);
    }

    public long getSimulationTime() {
        return jSimulationTime;
    }

    public void setSimulationTime(long t) {
        jSimulationTime = t;
    }

    public String getFormattedTime() {
        return jFormattedTime;
    }

    public void setFormattedTime(String ft) {
        jFormattedTime = ft;
    }
}
