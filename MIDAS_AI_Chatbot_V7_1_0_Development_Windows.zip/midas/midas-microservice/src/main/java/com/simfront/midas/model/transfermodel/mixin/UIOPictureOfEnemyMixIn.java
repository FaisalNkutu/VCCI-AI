/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel.mixin;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 * @author rhans
 */
public abstract class UIOPictureOfEnemyMixIn {

    @JsonProperty("time")
    public abstract long getSimulationTime();

    @JsonProperty("formattedtime")
    public abstract String getFormattedTime();

    @JsonProperty("oppositecount")
    public abstract long getOppositeCount();

    @JsonProperty("offsidecount")
    public abstract long getOffsideCount();

    @JsonProperty("friendlycm")
    public abstract boolean isFriendlyControlMeasure();

}
