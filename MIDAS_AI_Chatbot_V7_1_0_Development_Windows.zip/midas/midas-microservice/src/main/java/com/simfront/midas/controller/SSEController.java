/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.controller;

import com.simfront.midas.managers.DBManager;
import com.simfront.midas.model.transfermodel.UIOMetricsStatus;
import io.micronaut.http.MediaType;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import java.time.Duration;
import java.util.function.Supplier;

import reactor.core.publisher.Flux;

/**
 *
 * @author rhans
 */
@Controller("/advmetrics/sse")
public class SSEController {

    // Need rxjava or reactor-core 
//    @Get(value = "/notifications", produces = MediaType.TEXT_EVENT_STREAM)
//    public Publisher<UIOMetricsStatus> streamNotifications() {
//        UIOMetricsStatus stat = DBManager.jDBManager.getMetricsStatus();
//        return Flowable.interval(10, TimeUnit.SECONDS)
//                .map(tick -> stat);
//    }
    @Get(value = "/mstatus", produces = MediaType.TEXT_EVENT_STREAM)
    public Flux<UIOMetricsStatus> streamNotifications() {
        // A function to get the status, used for both the initial and interval calls
        Supplier<UIOMetricsStatus> statusSupplier = () -> {
            UIOMetricsStatus stat = DBManager.jDBManager.getMetricsStatus();
            if (stat != null) {
                System.err.println("Sending status: \n" + stat.toString());
                return stat;
            }
            return new UIOMetricsStatus();
        };

        // Initial execution: Get the status *once* immediately
        Flux<UIOMetricsStatus> initialStatus = Flux.just(statusSupplier.get());

        // Interval executions: Wait 10 seconds, then execute repeatedly
        Flux<UIOMetricsStatus> intervalStatus = Flux.interval(Duration.ofSeconds(10))
                .map(i -> statusSupplier.get());

        // Combine them: Emit the initial status immediately, then start the interval
        return Flux.concat(initialStatus, intervalStatus);
    }
}
