/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

/**
 *
 * @author rhans
 */
public class UIOFratricideIncident extends UIOBase {

    long jFireEventId;
    String jFiringType; // DF/IDF (Direct/Indirect)
    String jTargetEntityName;
    String jTargetEntityMilSym;
    double jTargetLat;
    double jTargetLon;
    double jMunitionMaxLat;
    double jMunitionMaxLon;
    double jIntersectLat; // For DF only
    double jIntersectLon; // For DF only
    String jReceivingEntityName;
    String jReceivingEntityMilSym;
    double jFootprintPoint1Lat;
    double jFootprintPoint1Lon;
    double jFootprintPoint2Lat;
    double jFootprintPoint2Lon;
    double jFootprintPoint3Lat;
    double jFootprintPoint3Lon;
    double jFootprintPoint4Lat;
    double jFootprintPoint4Lon;


    public UIOFratricideIncident(
            String name,
            long id,
            double lat,
            double lon) {
        super(name, id, lat, lon);
    }

    public long getFireEventId() {
        return jFireEventId;
    }

    public void setFireEventId(long fireEventId) {
        jFireEventId = fireEventId;
    }

    public String getFiringType() {
        return jFiringType;
    }

    public void setFiringType(String firingType) {
        jFiringType = firingType;
    }

    public String getTargetEntityName() {
        return jTargetEntityName;
    }

    public void setTargetEntityName(String name) {
        jTargetEntityName = name;
    }

    public String getTargetEntityMilSym() {
        return jTargetEntityMilSym;
    }

    public void setTargetEntityMilSym(String symbol) {
        jTargetEntityMilSym = symbol;
    }

    public double getTargetLat() {
        return jTargetLat;
    }

    public void setTargetLat(double targetLat) {
        jTargetLat = targetLat;
    }

    public double getTargetLon() {
        return jTargetLon;
    }

    public void setTargetLon(double targetLon) {
        jTargetLon = targetLon;
    }

    public double getMunitionMaxLat() {
        return jMunitionMaxLat;
    }

    public void setMunitionMaxLat(double munitionMaxLat) {
        jMunitionMaxLat = munitionMaxLat;
    }

    public double getMunitionMaxLon() {
        return jMunitionMaxLon;
    }

    public void setMunitionMaxLon(double munitionMaxLon) {
        jMunitionMaxLon = munitionMaxLon;
    }

    public String getReceivingEntityName() {
        return jReceivingEntityName;
    }

    public void setReceivingEntityName(String name) {
        jReceivingEntityName = name;
    }

    public String getReceivingEntityMilSym() {
        return jReceivingEntityMilSym;
    }

    public void setReceivingEntityMilSym(String symbol) {
        jReceivingEntityMilSym = symbol;
    }

    public double getIntersectLat() {
        return jIntersectLat;
    }

    public void setIntersectLat(double intersectLat) {
        jIntersectLat = intersectLat;
    }

    public double getIntersectLon() {
        return jIntersectLon;
    }

    public void setIntersectLon(double intersectLon) {
        jIntersectLon = intersectLon;
    }

    public void setFootprintPoints(
            double pt1Lat,
            double pt1Lon,
            double pt2Lat,
            double pt2Lon,
            double pt3Lat,
            double pt3Lon,
            double pt4Lat,
            double pt4Lon) {
        jFootprintPoint1Lat = pt1Lat;
        jFootprintPoint1Lon = pt1Lon;
        jFootprintPoint2Lat = pt2Lat;
        jFootprintPoint2Lon = pt2Lon;
        jFootprintPoint3Lat = pt3Lat;
        jFootprintPoint3Lon = pt3Lon;
        jFootprintPoint4Lat = pt4Lat;
        jFootprintPoint4Lon = pt4Lon;
    }

    public double getFootprintPoint1Lat() {
        return jFootprintPoint1Lat;
    }

    public double getFootprintPoint1Lon() {
        return jFootprintPoint1Lon;
    }

    public double getFootprintPoint2Lat() {
        return jFootprintPoint2Lat;
    }

    public double getFootprintPoint2Lon() {
        return jFootprintPoint2Lon;
    }

    public double getFootprintPoint3Lat() {
        return jFootprintPoint3Lat;
    }

    public double getFootprintPoint3Lon() {
        return jFootprintPoint3Lon;
    }

    public double getFootprintPoint4Lat() {
        return jFootprintPoint4Lat;
    }

    public double getFootprintPoint4Lon() {
        return jFootprintPoint4Lon;
    }


}
