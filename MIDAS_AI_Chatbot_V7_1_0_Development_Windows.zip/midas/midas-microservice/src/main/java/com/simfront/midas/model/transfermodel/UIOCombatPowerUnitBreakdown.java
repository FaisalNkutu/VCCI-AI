/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;


/**
 * Transfer model representing a breakdown of a specific equipment type within a unit.
 *
 * This class is used to return detailed combat power data for a given equipment type,
 * showing how much of it each unit holds at a specific simulation time.
 *
 * Fields:
 *  - unitName:        The name of the unit (e.g., "A Coy", "8151")
 *  - originalQuantity: Total number of the specified equipment type originally held
 *  - currentQuantity:  Number of the equipment type currently operational
 *
 * This model is typically returned by the /cpower-equipment-type-breakdown-detail POST endpoint.
 * @author r.hassan
 */

public class UIOCombatPowerUnitBreakdown {

    private String unitName;
    private long originalQuantity;
    private long currentQuantity;

    public UIOCombatPowerUnitBreakdown() {}

    public UIOCombatPowerUnitBreakdown(String unitName, long originalQuantity, long currentQuantity) {
        this.unitName = unitName;
        this.originalQuantity = originalQuantity;
        this.currentQuantity = currentQuantity;
    }

    public String getUnitName() {
        return unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    public long getOriginalQuantity() {
        return originalQuantity;
    }

    public void setOriginalQuantity(long originalQuantity) {
        this.originalQuantity = originalQuantity;
    }

    public long getCurrentQuantity() {
        return currentQuantity;
    }

    public void setCurrentQuantity(long currentQuantity) {
        this.currentQuantity = currentQuantity;
    }
}
