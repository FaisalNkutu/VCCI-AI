/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */
package com.simfront.midas.analytics.combatpower.processor;

import com.simfront.midas.CentralDispatch;
import com.simfront.midas.constants.MIDASConstants;
import com.simfront.midas.managers.DBManager;
import com.simfront.midas.utils.RequestResults;
import com.simfront.midas.analytics.combatpower.model.AnalysisResult;
import com.simfront.midas.model.transfermodel.UIOCombatPowerResults;
import com.simfront.midas.model.transfermodel.UIOCPowerGraphPoint;
import com.calian.paradigm.core.bto.model.gobjs.gen.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CombatPowerAnalyticsProcessor {

    /**
     * Analyze combat power for given entities and time range.
     * Calls CentralDispatch to fetch results, then runs Trend + Anomaly detection.
     */
    public static List<AnalysisResult> analyze(List<Long> entityIds, long fromTime, long toTime) {
        ArrayList<Object> params = new ArrayList<>();
        params.add("HH:mm");                // time format
        params.add(fromTime);
        params.add(toTime);
        params.add(new ArrayList<>(entityIds));

        // 1. Fetch combat power results via CentralDispatch
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_COMBAT_POWER_RESULTS,
                params,
                false
        );

        List<AnalysisResult> results = new ArrayList<>();
        if (rr == null || rr.getResults() == null) {
            return results;
        }

        // 2. Parse UIOCombatPowerResults
        for (Object o : rr.getResults()) {
            if (o instanceof UIOCombatPowerResults) {
                UIOCombatPowerResults cpResults = (UIOCombatPowerResults) o;

                // For each unit in the hash
                for (Map.Entry<Long, ArrayList<UIOCPowerGraphPoint>> entry : cpResults.getEntCPHash().entrySet()) {
                    long unitId = entry.getKey();
                    ArrayList<UIOCPowerGraphPoint> points = entry.getValue();

                    // 🔹 Fetch specs for this unit directly from DB
                    List<GCombatPowerMetricsSpecification> specs =
                            DBManager.jDBManager.getCombatPowerMetricsSpecs(unitId);

                    // keep previous value per unit
                    Double prevValue = null;

                    for (UIOCPowerGraphPoint pt : points) {
                        long time = pt.getTime();
                        if (time <= fromTime) {
                            continue;
                        }

                        double value = pt.getCombatPower();
                        String unitName = pt.getEntityName();

                        AnalysisResult ar = new AnalysisResult(unitId, unitName, time, value);

                        // ✅ First point of each unit/session is always stable (no anomaly)
                        if (prevValue == null) {
                            ar.setTrend("STABLE");
                            ar.setTrendMarker("→");
                            ar.setAnomaly(false);
                            ar.setReason("");
                            ar.setAnomalyMarker("");
                        } else {
                            // --- Trend detection ---
                            if (value > prevValue) {
                                ar.setTrend("UPWARD");
                                ar.setTrendMarker("↑");
                            } else if (value < prevValue) {
                                ar.setTrend("DOWNWARD");
                                ar.setTrendMarker("↓");
                            } else {
                                ar.setTrend("STABLE");
                                ar.setTrendMarker("→");
                            }

                            // --- Point-to-point anomaly detection ---
                            double delta = value - prevValue;
                            double deltaPct = (prevValue != 0) ? (delta / prevValue) * 100.0 : 0;

//                            // more sensitive thresholds: 15 absolute or 20% relative
//                            if (Math.abs(delta) > 15.0 || Math.abs(deltaPct) > 20.0) {
//                                ar.setAnomaly(true);
//                                ar.setReason(delta < 0 ? "DROP" : "SPIKE");
//                                ar.setAnomalyMarker("⚠️");
//                            }

                            // stricter threshold: anomaly only if > 60% relative change
                            if (Math.abs(deltaPct) > 60.0) {
                                ar.setAnomaly(true);
                                ar.setReason(delta < 0 ? "DROP" : "SPIKE");
                                ar.setAnomalyMarker("⚠️");
                            } else {
                                ar.setAnomaly(false);
                                ar.setReason("");
                                ar.setAnomalyMarker("");
                            }
                        }

                        // --- Check for spec change using DB specs ---
                        boolean specChanged = false;
                        if (specs != null) {
                            specChanged = specs.stream().anyMatch(
                                    s -> Math.abs(time - s.getCombatPowerMetricsSpecificationTime()) < 1000
                            );
                        }
                        if (specChanged) {
                            ar.setAnomaly(true);
                            ar.setReason("SPEC_CHANGE");
                            ar.setAnomalyMarker("⚑");
                        }

                        results.add(ar);

                        // update prevValue AFTER detection
                        prevValue = value;
                    }
                }
            }
        }

        return results;
    }
}
