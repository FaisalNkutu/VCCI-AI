/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 * @author rhans
 */
public abstract class GRatesOfMovementMetricsResultsMixIn {

    @JsonIgnore
    public abstract long getRatesOfMovementMetricsResultsRateOfMovementMetricsResultsIndex();
 
    @JsonProperty("objitemid")
    public abstract long getRatesOfMovementMetricsResultsObjectItemId();

    @JsonProperty("realtime")
    public abstract long getRatesOfMovementMetricsResultsTime();

    @JsonProperty("simtime")
    public abstract String getRatesOfMovementMetricsResultsExternalTimeReference();

    @JsonProperty("cumulative")
    public abstract long getRatesOfMovementMetricsResultsCumulativeDistance();

    @JsonProperty("lat")
    public abstract double getRatesOfMovementMetricsResultsLatitudeCoordinate();

    @JsonProperty("lon")
    public abstract double getRatesOfMovementMetricsResultsLongitudeCoordinate();
}
