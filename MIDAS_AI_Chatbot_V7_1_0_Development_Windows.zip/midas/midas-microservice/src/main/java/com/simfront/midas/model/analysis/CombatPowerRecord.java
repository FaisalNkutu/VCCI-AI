/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.analysis;

/**
 * A data model representing combat power metrics for a specific unit at a given time.
 */
public class CombatPowerRecord {
    private long unitId;
    private String unitName;
    private long time;
    private String formattedTime;
    private double combatPower;

    public CombatPowerRecord() {}

    public CombatPowerRecord(long unitId, String unitName, long time, String formattedTime, double combatPower) {
        this.unitId = unitId;
        this.unitName = unitName;
        this.time = time;
        this.formattedTime = formattedTime;
        this.combatPower = combatPower;
    }

    public long getUnitId() {
        return unitId;
    }

    public void setUnitId(long unitId) {
        this.unitId = unitId;
    }

    public String getUnitName() {
        return unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public String getFormattedTime() {
        return formattedTime;
    }

    public void setFormattedTime(String formattedTime) {
        this.formattedTime = formattedTime;
    }

    public double getCombatPower() {
        return combatPower;
    }

    public void setCombatPower(double combatPower) {
        this.combatPower = combatPower;
    }
}
