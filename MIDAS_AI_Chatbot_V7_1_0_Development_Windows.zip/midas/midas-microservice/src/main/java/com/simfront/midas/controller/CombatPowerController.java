/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */
package com.simfront.midas.controller;

import com.simfront.midas.CentralDispatch;
import com.simfront.midas.constants.MIDASConstants;
import com.simfront.midas.model.transfermodel.UIOBase;
import com.simfront.midas.model.transfermodel.UIOCombatPowerContribution;
import com.simfront.midas.model.transfermodel.UIOCombatPowerResults;
import com.simfront.midas.model.transfermodel.UIOCombatPowerTypeBreakdown;
import com.simfront.midas.utils.RequestResults;
import com.calian.paradigm.core.metrics.MetricsConstants;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author rhans This is the controller for the Combat Power Dashboard. There
 * are mixins for all the returned objects
 */
@Controller("/advmetrics/cp")
public class CombatPowerController {

    @Get("/entities")
    public HttpResponse<List<Object>> getMetricsEntities(
            @QueryValue Boolean ignoreZeroHundredValues) {

        // Step 1: Get flat list of valid entity IDs for Combat Power
        ArrayList<Object> params = new ArrayList<>();
        params.add(MetricsConstants.E_METRIC.COMBAT_POWER);
        params.add(ignoreZeroHundredValues);

        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_METRICS_ENTITIES,
                params,
                true
        );

        if (!rr.isSuccess()) {
            return HttpResponse.serverError();
        }

        // Step 2: Extract IDs from flat entity list (UIOBase → ID)
        List<Object> flatEntities = rr.getResults();
        Set<Long> entityIds = flatEntities.stream()
                .filter(o -> o instanceof UIOBase)
                .map(o -> ((UIOBase) o).getId())
                .collect(Collectors.toSet());

        // Step 3: Use those IDs to generate an ORBAT-style structure (tree + orphans)
        RequestResults orbatRr = CentralDispatch.jCentralDispatch.generateNestedStructure(entityIds, true);
        if (!orbatRr.isSuccess()) {
            return HttpResponse.serverError();
        }

        // Final response: ORBAT-style hierarchy for frontend rendering
        List<Object> orbatResponse = orbatRr.getResults();
        return HttpResponse.ok(orbatResponse);
    }

    /**
     *
     * @param timeFormat
     * @param startTime
     * @param endTime
     * @param selectedEntities - cannot be empty
     * @return ArrayList<UIOCombatPowerResults>
     */
    @Get("/cpower")
    public HttpResponse<UIOCombatPowerResults> getCombatPowerResults(
            @QueryValue String timeFormat,
            @QueryValue long startTime,
            @QueryValue long endTime,
            @QueryValue List<Long> selectedEntities) {
        ArrayList<Object> params = new ArrayList();
        params.add(timeFormat);
        params.add(startTime);
        params.add(endTime);
        params.add(selectedEntities);
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_COMBAT_POWER_RESULTS,
                params,
                false);

        ArrayList<Object> res = rr.getResults();
        if (res == null || res.isEmpty()) {
            return HttpResponse.ok(null);
        }
        UIOCombatPowerResults uio = (UIOCombatPowerResults) res.get(0);
        return HttpResponse.ok(uio);
    }

    /**
     *
     * @param timeFormat
     * @param time
     * @param entityId
     * @return
     */
    @Get("/cpower-details")
    public HttpResponse<Object> getCombatPowerDetails(
            @QueryValue String timeFormat,
            @QueryValue long time,
            @QueryValue long entityId) {
        ArrayList<Object> params = new ArrayList();
        params.add(timeFormat);
        params.add(time);
        params.add(entityId);
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_COMBAT_POWER_DETAILS,
                params,
                false);

        ArrayList<Object> res = rr.getResults();
        if (!res.isEmpty()) {
            return HttpResponse.ok(res.get(0));
        }
        return HttpResponse.ok(res);
    }

    /**
     *
     * @param timeFormat
     * @param time
     * @param selectedEntities
     * @return
     */
    @Get("/cpower-group")
    public HttpResponse<Object> getCombatPowerGroupDetails(
            @QueryValue String timeFormat,
            @QueryValue long time,
            @QueryValue List<Long> selectedEntities) {
        ArrayList<Object> params = new ArrayList();
        params.add(timeFormat);
        params.add(time);
        params.add(selectedEntities);
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_COMBAT_POWER_GROUP_DETAILS,
                params,
                false);

        ArrayList<Object> res = rr.getResults();
        return HttpResponse.ok(res);
    }

    /**
     * will add explanation later
     *    @author r.hassan
     */
    @Get("/cpower-equipment-breakdown")
    public HttpResponse<Map<String, Object>> getCombatPowerEquipmentTimeSeries(
            @QueryValue String timeFormat,
            @QueryValue long startTime,
            @QueryValue long endTime,
            @QueryValue List<Long> selectedEntities) {

        ArrayList<Object> params = new ArrayList<>();
        params.add(timeFormat);
        params.add(startTime);
        params.add(endTime);
        params.add(selectedEntities);

        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_COMBAT_POWER_EQUIPMENT_TIME_SERIES,
                params,
                false
        );

        if (rr == null || rr.getResults() == null) {
            return HttpResponse.serverError();
        }

        List<UIOCombatPowerTypeBreakdown> casted = rr.getResults().stream()
                .filter(o -> o instanceof UIOCombatPowerTypeBreakdown)
                .map(o -> (UIOCombatPowerTypeBreakdown) o)
                .collect(Collectors.toList());

        Map<String, List<UIOCombatPowerTypeBreakdown>> grouped =
                casted.stream().collect(Collectors.groupingBy(UIOCombatPowerTypeBreakdown::getEquipmentType));

        Map<String, Object> wrapped = new HashMap<>();
        wrapped.put("hlding_per_equipment_type", grouped);

        return HttpResponse.ok(wrapped);
    }

    /**
     * will add explanation later
     *    @author r.hassan
     */
    @Get("/cpower-equipment-contribution")
    public HttpResponse<List<UIOCombatPowerContribution>> getCombatPowerContributionBreakdown(
            @QueryValue String timeFormat,
            @QueryValue long time,
            @QueryValue String equipmentType,
            @QueryValue List<Long> selectedEntities) {

        ArrayList<Object> params = new ArrayList<>();
        params.add(timeFormat);
        params.add(time);
        params.add(selectedEntities);
        params.add(equipmentType);

        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_COMBAT_POWER_EQUIPMENT_CONTRIBUTION,
                params,
                false
        );

        if (rr == null || rr.getResults() == null) {
            return HttpResponse.serverError();
        }

        List<UIOCombatPowerContribution> casted = rr.getResults().stream()
                .filter(o -> o instanceof UIOCombatPowerContribution)
                .map(o -> (UIOCombatPowerContribution) o)
                .collect(Collectors.toList());

        return HttpResponse.ok(casted);
    }

}
