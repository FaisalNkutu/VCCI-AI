/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel.mixin;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.calian.paradigm.core.bto.model.gobjs.gen.*;

/**
 *
 * @author rhans
 */
public abstract class UIOHHourMetricsResultMixIn extends UIOBaseMixIn {
    @JsonIgnore
    public abstract GHhourMetricsResults getOMDBResult();
}
