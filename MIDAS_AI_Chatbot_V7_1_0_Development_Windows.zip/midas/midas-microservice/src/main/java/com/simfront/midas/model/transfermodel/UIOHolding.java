/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

/**
 * @author rhans
 */
public class UIOHolding {

    public String jEquipmentTypeCatCode = "";
    public String jEquipmentTypeName = "";
    public long jOriginalQty = 0;
    public long jCurrentQty = 0;
    public long jReferenceQty = 0;

    public UIOHolding() {
    }

}
