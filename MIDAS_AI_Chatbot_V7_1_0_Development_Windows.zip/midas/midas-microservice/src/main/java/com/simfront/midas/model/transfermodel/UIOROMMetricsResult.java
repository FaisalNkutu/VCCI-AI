/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

import com.calian.paradigm.core.bto.model.gobjs.gen.*;

/**
 *
 * @author rhans
 */
public class UIOROMMetricsResult extends UIOMetricResult {

    GRatesOfMovementMetricsResults jResult = null;

    public UIOROMMetricsResult(GRatesOfMovementMetricsResults result) {
        jResult = result;
        // UIOBase
        super.setId(result.getMetricsResultsMetricsResultId());
        super.setTime(result.getMetricsResultsTime());
        super.setLon(result.getRatesOfMovementMetricsResultsLongitudeCoordinate());
        super.setLat(result.getRatesOfMovementMetricsResultsLatitudeCoordinate());
        // UIOMetricResult
        super.setSpecId(result.getMetricsResultsMetricsSpecificationIndex());
        super.setObjectItemId(result.getMetricsResultsObjectItemId());
        super.setSimStartTime(result.getMetricsResultsSimulationStartTime());
    }

    public double getSpeedRate() {
        return jResult.getRatesOfMovementMetricsResultsSpeedRate();
    }

    public double getCumulativeDistance() {
        return jResult.getRatesOfMovementMetricsResultsCumulativeDistance();
    }
}
