/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.micronaut.core.annotation.Introspected;

/**
 * will add explanation later
 *    @author r.hassan
 */
@Introspected
public class UIOCombatPowerContribution {

    private long time;
    private String formattedTime;
    private Long unitId;
    private String unitName;
    private long originalQuantity;
    private long currentQuantity;
    @JsonIgnore
    private double combatPower;
    @JsonIgnore
    private double sharePercentage;
    private String milSym;

    public UIOCombatPowerContribution(long time, Long unitId, String unitName, long originalQty, long currentQty) {
        this.time = time;
        this.unitId = unitId;
        this.unitName = unitName;
        this.originalQuantity = originalQty;
        this.currentQuantity = currentQty;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public String getFormattedTime() {
        return formattedTime;
    }

    public void setFormattedTime(String formattedTime) {
        this.formattedTime = formattedTime;
    }

    public Long getUnitId() {
        return unitId;
    }

    public void setUnitId(Long unitId) {
        this.unitId = unitId;
    }


    public String getMilSym() {
        return milSym;
    }

    public void setMilSym(String milSym) {
        this.milSym = milSym;
    }

    public String getUnitName() {
        return unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    public long getOriginalQuantity() {
        return originalQuantity;
    }

    public void setOriginalQuantity(long originalQuantity) {
        this.originalQuantity = originalQuantity;
    }

    public long getCurrentQuantity() {
        return currentQuantity;
    }

    public void setCurrentQuantity(long currentQuantity) {
        this.currentQuantity = currentQuantity;
    }

    public double getCombatPower() {
        return combatPower;
    }

    public void setCombatPower(double combatPower) {
        this.combatPower = combatPower;
    }

    public double getSharePercentage() {
        return sharePercentage;
    }

    public void setSharePercentage(double sharePercentage) {
        this.sharePercentage = sharePercentage;
    }
}

