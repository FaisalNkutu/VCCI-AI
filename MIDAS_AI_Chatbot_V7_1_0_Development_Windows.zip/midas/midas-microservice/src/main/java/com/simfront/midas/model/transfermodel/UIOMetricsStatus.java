/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */
package com.simfront.midas.model.transfermodel;

/**
 *
 * @author rhans
 */
public class UIOMetricsStatus {

    // To handle time updates for live database
    public long jMaxTime = -1;
    public String jFormattedMaxTime = "";

    public boolean jHHourActive = false;
    public boolean jROMActive = false;
    public boolean jCMOccupationsActive = false;
    public boolean jPOEActive = false;
    public boolean jCPowerActive = false;
    public boolean jEnemyEngagementsActive = false;
    public boolean jFratricideActive = false;
    public boolean jEntityWatchActive = false;

    public String jHHourReason = null;
    public String jROMReason = null;
    public String jPOEReason = null;
    public String jCMOccsReason = null;
    public String jEneEngReason = null;
    public String jEntWatchReason = null;

    // Real time stats
    public long jROMEntryCount = 0;
    public long jFratricideIncidentCount = 0;
    public long jHHourCount = 0;
    // More to come

    public UIOMetricsStatus() {
    }

    public String toString() {
        String m = "";
        m += " HHOUR   ACTIVE : " + ((jHHourActive) ? "YES" : "NO") + "\n";
        m += " ROM     ACTIVE : " + ((jROMActive) ? "YES" : "NO") + "\n";
        m += " CMOCCS  ACTIVE : " + ((jCMOccupationsActive) ? "YES" : "NO") + "\n";
        m += " POE     ACTIVE : " + ((jPOEActive) ? "YES" : "NO") + "\n";
        m += " CPOWER  ACTIVE : " + ((jCPowerActive) ? "YES" : "NO") + "\n";
        m += " EN ENGS ACTIVE : " + ((jEnemyEngagementsActive) ? "YES" : "NO") + "\n";
        m += " FRAT    ACTIVE : " + ((jFratricideActive) ? "YES" : "NO") + "\n";
        m += " EWATCH  ACTIVE : " + ((jEntityWatchActive) ? "YES" : "NO") + "\n";
        m += " LATEST-TIME    : " + jMaxTime;

        if (jHHourReason != null) {
            m += "\n " + jHHourReason;
        }
        if (jROMReason != null) {
            m += "\n " + jROMReason;
        }
        if (jPOEReason != null) {
            m += "\n " + jPOEReason;
        }
        if (jCMOccsReason != null) {
            m += "\n " + jCMOccsReason;
        }
        if (jEneEngReason != null) {
            m += "\n " + jEneEngReason;
        }
        if (jEntWatchReason != null) {
            m += "\n " + jEntWatchReason;
        }
        return m;
    }
}
