/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */
package com.simfront.midas.controller;

import com.simfront.midas.CentralDispatch;
import com.simfront.midas.constants.MIDASConstants;
import com.simfront.midas.managers.DBManager;
import com.simfront.midas.model.transfermodel.UIOFormatTime;
import com.simfront.midas.model.transfermodel.UIOMinMaxTime;
import com.simfront.midas.requests.SetDataBaseRequest;
import com.simfront.midas.utils.MIDASUtils;
import com.simfront.midas.utils.RequestResults;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.MediaType;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.Post;
import io.micronaut.http.annotation.QueryValue;
import io.micronaut.scheduling.TaskExecutors;
import io.micronaut.scheduling.annotation.ExecuteOn;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 *
 * @author rhans
 */
@Controller("/advmetrics/omdbdata")
public class DataConfigurationController {

    /**
     * Returns the list of available databases.
     *
     * @return 200 OK with database list, or 204 No Content if empty.
     */
    @Get("/databases")
    public HttpResponse<List<String>> getDataBases(
            @QueryValue(defaultValue = "127.0.0.1") String host) {
        ArrayList<String> dbs = MIDASUtils.buildDatabaseList(host);
        if (dbs == null) {
            return HttpResponse.notFound(); // 404 Not Found
        }
        if (dbs.isEmpty()) {
            return HttpResponse.noContent(); // 204 No Content
        }
        return HttpResponse.ok(dbs);
    }

    /**
     * Gets the currently selected database name.
     *
     * @return 200 OK with database name, or 500 if none is selected.
     */
    //@Get("/selecteddb")
//    public HttpResponse<String> getSelectedDatabase() {
//        String selectedDB = DBManager.jDBManager.getDBName();
//        if (selectedDB != null) {
//            return HttpResponse.ok(selectedDB);
//        } else {
//            return HttpResponse.serverError("No database selected");
//        }
//    }
    @Get("/selecteddb")
    public HttpResponse<Map<String, Object>> getSelectedDatabase() {
        if (DBManager.jDBManager != null && DBManager.jDBManager.isConnected()) {
            return HttpResponse.ok(Map.of(
                    "connected", true,
                    "database", DBManager.jDBManager.getDBName(),
                    "host", DBManager.jDBManager.getHost(),
                    "live", DBManager.jDBManager.isLiveMode()
            ));
        }
        return HttpResponse.ok(Map.of("connected", false));
    }



    /**
     * Disconnects the currently active database connection.
     *
     * @return 200 OK with disconnect status message.
     */
    @Post("/disconnectdb")
    public HttpResponse<String> disconnectDatabase() {
        if (DBManager.jDBManager.isConnected()) {
            DBManager.jDBManager.resetDBConnection(); //
            return HttpResponse.ok("Database connection reset.");
        } else {
            return HttpResponse.ok("No active database to disconnect.");
        }
    }

    @Post(value = "/selectdb", consumes = {MediaType.APPLICATION_JSON})
    @ExecuteOn(TaskExecutors.BLOCKING)
    public HttpResponse<String> setDatabase(@Body SetDataBaseRequest req) {
        ArrayList<Object> params = new ArrayList();
        params.add(req.getHost());  // Instead of "localhost"
        params.add(req.getName());
        params.add("vcci");
        params.add("vcci");
        params.add(req.isLivemode() ? Boolean.TRUE : Boolean.FALSE);
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.SET_DATABASE,
                params,
                false);
        if (rr.isSuccess()) {
            return HttpResponse.ok(req.getName());
        } else {
            return HttpResponse.serverError("Failure to select database : "
                    + req.getName());
        }
    }

    @Get("/entities")
    public HttpResponse<List<Object>> getEntities() {
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_ENTITIES,
                null,
                true);
        if (rr.isSuccess()) {
            ArrayList<Object> ents = rr.getResults();
            return HttpResponse.ok(ents);
        } else {
            return HttpResponse.serverError();
        }
    }

    @Get("/orbat")
    public HttpResponse<List<Object>> getORBAT() {
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_ORBAT,
                null,
                true);
        if (rr.isSuccess()) {
            ArrayList<Object> ents = rr.getResults();
            return HttpResponse.ok(ents);
        } else {
            return HttpResponse.serverError();
        }
    }

    @Get("/formats")
    public HttpResponse<List<Object>> getTimeFormats() {
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_TIME_FORMATS,
                null,
                true);
        if (rr.isSuccess()) {
            ArrayList<Object> fmts = rr.getResults();
            return HttpResponse.ok(fmts);
        } else {
            return HttpResponse.serverError();
        }
    }

    /**
     * Returns the min and max exercise time (both in raw simulation offset and
     * in format applied versions)
     *
     * @param format
     * @return
     */
    @Get("/minmaxtime")
    public HttpResponse<Object> getMinMaxTime(@QueryValue String format) {
        ArrayList<Object> params = new ArrayList();
        params.add(format);
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_MIN_MAX_TIME,
                params,
                false);

        ArrayList<Object> results = rr.getResults();
        if (results == null || results.isEmpty()) {
            return HttpResponse.notFound("MinMaxTime not available.");
        }

        UIOMinMaxTime uio = null;
        if (results.size() == 1) {
            uio = (UIOMinMaxTime) results.get(0);
        }
        return HttpResponse.ok(uio);
    }

    /**
     * Returns the min and max exercise time (both in raw simulation offset and
     * in format applied versions)
     *
     * @param time
     * @param format
     * @return
     */
    @Get("/formattime")
    public HttpResponse<Object> formatTime(
            @QueryValue long time,
            @QueryValue String format) {
        ArrayList<Object> params = new ArrayList();
        params.add(time);
        params.add(format);
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.FORMAT_TIME,
                params,
                false);
        UIOFormatTime uio = null;
        ArrayList<Object> results = rr.getResults();
        if (results.size() == 1) {
            uio = (UIOFormatTime) results.get(0);
        }
        return HttpResponse.ok(uio);
    }

    /**
     * Checks if the backend is ready (DBManager initialized and cache loaded).
     *
     * @return HttpResponse with {"ready": true} if ready, else false.
     */
    @Get("/status")
    public HttpResponse<Map<String, Boolean>> checkStatus() {
        boolean ready = DBManager.jDBManager != null
                && DBManager.jDBManager.isConnected()
                && DBManager.jDBManager.isCacheReady();
        return HttpResponse.ok(Collections.singletonMap("ready", ready));
    }
}
