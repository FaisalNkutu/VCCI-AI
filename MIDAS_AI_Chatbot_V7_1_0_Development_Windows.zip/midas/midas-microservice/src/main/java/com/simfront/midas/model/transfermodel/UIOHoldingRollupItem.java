/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

/**
 * Data Transfer Object (DTO) representing a single equipment rollup entry for reporting.
 *
 * - Used to display time-series holdings data for equipment rollup graphs.
 * - Captures equipment name, type, snapshot time, quantities, and resupply delta.
 * - Populated in methods like getHoldingRollupResults() and returned in report APIs.
 */
public class UIOHoldingRollupItem {

    private String equipmentName;
    private long equipmentTypeId;
    private long time;                  // Raw simulation timestamp (numeric offset)
    private String formattedTime;
    private double totalQty;            // Total quantity of this equipment at snapshot
    private double operationalQty;      // Current quantity at snapshot
    private double delta;               // Change from resupply events (+ add, - remove)

    /**
     * Constructor to initialize a rollup item.
     *
     * @param equipmentName
     * @param equipmentTypeId
     * @param time
     * @param formattedTime
     * @param totalQty
     * @param operationalQty
     * @param delta
     */
    public UIOHoldingRollupItem(String equipmentName, long equipmentTypeId, long time, String formattedTime,
                                double totalQty, double operationalQty, double delta) {
        this.equipmentName = equipmentName;
        this.equipmentTypeId = equipmentTypeId;
        this.time = time;
        this.formattedTime = formattedTime;
        this.totalQty = totalQty;
        this.operationalQty = operationalQty;
        this.delta = delta;
    }

    // --- Getters & Setters ---
    public String getEquipmentName() {
        return equipmentName;
    }
    public void setEquipmentName(String equipmentName) {
        this.equipmentName = equipmentName;
    }

    public long getEquipmentTypeId() { return equipmentTypeId; }

    public void setEquipmentTypeId(long equipmentTypeId) {
        this.equipmentTypeId = equipmentTypeId;
    }

    public long getTime() { return time; }
    public void setTime(long time) {
        this.time = time;
    }

    public String getFormattedTime() {
        return formattedTime;
    }
    public void setFormattedTime(String formattedTime)
    {
        this.formattedTime = formattedTime;
    }

    public double getTotalQty()
    {
        return totalQty;
    }
    public void setTotalQty(double totalQty) {
        this.totalQty = totalQty;
    }

    public double getOperationalQty() {
        return operationalQty;
    }

    public void setOperationalQty(double operationalQty) {
        this.operationalQty = operationalQty;
    }

    public double getDelta() {
        return delta;
    }
    public void setDelta(double delta) {
        this.delta = delta;
    }
}
