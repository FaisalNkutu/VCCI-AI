/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

/**
 *
 * @author rhans
 */
public class UIOPictureOfEnemy {

    long jSimulationTime;
    String jFormattedTime = null;
    long jOppositeCount = 0;// opposite of friendly control measure, (bottom red line)
    long jOffsideCount = 0; //total count, (top red line)
    boolean jFriendlyControlMeasure; //is friend? blue:red

    public UIOPictureOfEnemy() {
    }

    public long getSimulationTime() {
        return jSimulationTime;
    }

    public void setSimulationTime(long t) {
        jSimulationTime = t;
    }

    public String getFormattedTime() {
        return jFormattedTime;
    }

    public void setFormattedTime(String ft) {
        jFormattedTime = ft;
    }

    public long getOppositeCount() {
        return jOppositeCount;
    }

    public void setOppositeCount(long count) {
        jOppositeCount = count;
    }

    public long getOffsideCount() {
        return jOffsideCount;
    }

    public void setOffsideCount(long count) {
        jOffsideCount = count;
    }

    public boolean isFriendlyControlMeasure() {
        return jFriendlyControlMeasure;
    }

    public void setFriendlyControlMeasure(boolean isFriendlyCM) {
        jFriendlyControlMeasure = isFriendlyCM;
    }

    public void incrementOpposite(long c) {
        jOppositeCount += c;
    }

    public void incrementOffside(long c) {
        jOffsideCount += c;
    }
}
