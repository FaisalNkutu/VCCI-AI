/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */
package com.simfront.midas.model.transfermodel;

/**
 *
 * @author rhans
 */
public class UIOCPowerGraphPoint {

    long jTime = -1;
    String jFormattedTime = "";
    double jCombatPower = 0;
    String jEntityName = null;

    public UIOCPowerGraphPoint(
            String entityName,
            long time,
            String formattedTime,
            double cp) {
        jEntityName = entityName;
        jTime = time;
        jFormattedTime = formattedTime;
        jCombatPower = cp;
    }

    public String getEntityName() {
        return jEntityName;
    }

    public void setEntityName(String entityName) {
        jEntityName = entityName;
    }

    public double getCombatPower() {
        return jCombatPower;
    }

    public void setCombatPower(double combatPower) {
        jCombatPower = combatPower;
    }

    public long getTime() {
        return jTime;
    }

    public void setTime(long t) {
        jTime = t;
    }

    public String getFormattedTime() {
        return jFormattedTime;
    }

    public void setFormattedTime(String t) {
        jFormattedTime = t;
    }

    public UIOCPowerGraphPoint clone() {
        return new UIOCPowerGraphPoint(jEntityName, jTime, jFormattedTime, jCombatPower);
    }

}
