/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */
package com.simfront.midas.controller;

import com.calian.common.lib.log.Log;
import com.simfront.midas.CentralDispatch;
import com.simfront.midas.constants.MIDASConstants;
import com.simfront.midas.utils.RequestResults;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.PathVariable;
import io.micronaut.http.annotation.QueryValue;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * @author rhans
 */
@Controller("/advmetrics/hhour")
public class HHourController {

    private static final Logger jL = Log.getLogger(HHourController.class);

    @Get("/specs")
    public HttpResponse<List<Object>> getHHourSpecs(@QueryValue String format) {
        ArrayList<Object> params = new ArrayList();
        params.add(format);
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_HHOUR_SPECS,
                params,
                false);
        return HttpResponse.ok(rr.getResults());
    }

    @Get("/lod-loc/{id}")
    public HttpResponse<List<Object>> getLineOfDepartureLocs(@PathVariable long id) {
        ArrayList<Object> params = new ArrayList();
        params.add(id);
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_LINE_OF_DEPARTURE_LOCATIONS,
                params,
                false);
        if (rr.isSuccess()) {
            return HttpResponse.ok(rr.getResults());
        } else {
            switch (rr.getStatus()) {
                case FAILURE_DB_NOT_CONNECTED:
                    return HttpResponse.status(HttpStatus.PRECONDITION_FAILED);
                default:
                    return HttpResponse.serverError();
            }
        }
    }

    @Get("/entities")
    public HttpResponse<List<Object>> getMetricsEntities(
            @QueryValue long hhourid,
            @QueryValue String format) {
        ArrayList<Object> params = new ArrayList<>();
        params.add(hhourid);
        params.add(format);

        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_HHOUR_ENTITIES,
                params,
                true);
        if (rr.isSuccess()) {
            return HttpResponse.ok(rr.getResults());
        } else {
            return HttpResponse.serverError();
        }
    }

    @Get("/xpercentage")
    public HttpResponse<Double> getHHourPercentage(
            @QueryValue long hhourid,
            @QueryValue long threshold,
            @QueryValue List<Long> selectedEntities) {
        ArrayList<Object> params = new ArrayList();
        params.add(hhourid);
        params.add(threshold);
        if (selectedEntities == null) {
            selectedEntities = new ArrayList<>();
        }
        params.add(selectedEntities);

        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_HHOUR_PERCENTAGE,
                params,
                false);
        return HttpResponse.ok(rr.getDoubleResult());
    }
}
