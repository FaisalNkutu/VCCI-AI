/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

/**
 * @author p.kuczera
 */
public class UIOC2SimContext {

    private final long id;
    private final String name;
    private final String alias;
    private final String type;

    public UIOC2SimContext(long id, String name, String alias, String type) {
        this.id = id;
        this.name = name;
        this.alias = alias;
        this.type = type;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAlias() {
        return alias;
    }

    public String getType() {
        return type;
    }
    
}
