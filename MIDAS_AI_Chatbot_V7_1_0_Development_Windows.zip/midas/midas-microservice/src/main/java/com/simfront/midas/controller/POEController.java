/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.controller;

import com.simfront.midas.CentralDispatch;
import com.simfront.midas.constants.MIDASConstants;
import com.simfront.midas.utils.RequestResults;
import com.calian.paradigm.core.metrics.MetricsConstants;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.QueryValue;

import java.util.ArrayList;
import java.util.List;

/**
 * @author rhans This is the controller for the Picture of Enemy Dashboard.
 * There are mixins for all the returned objects
 */
@Controller("/advmetrics/poe")
public class POEController {

    /**
     * This request returns the count of entities (opposite side and offside)
     * for all areas of interest, named areas of interest and targeted areas of
     * interest
     *
     * @param timeFormat
     * @return ArrayList<UIOPictureOfEnemy>
     */
    @Get("/results")
    public HttpResponse<ArrayList<Object>> getPOEResults(
            @QueryValue String timeFormat) {
        ArrayList<Object> params = new ArrayList();
        params.add(timeFormat);
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_PICTURE_OF_ENEMY_RESULTS,
                params,
                false);

        ArrayList<Object> res = rr.getResults();
        return HttpResponse.ok(res);
    }

    /**
     * This request returns the count of entities (opposite side and offside)
     * for all areas of interest, named areas of interest and targeted areas of
     * interest (filtered by selected control measures/entities and according to
     * the specified time interval)
     *
     * @param timeFormat
     * @param timeInterval - in minutes
     * @param friendlyStartTime
     * @param friendlyEndTime
     * @param hostileStartTime
     * @param hostileEndTime
     * @param selectedControlMeasures - if list is empty - all are returned
     * @param selectedEntities - if list is empty - all entities are considered
     * @return ArrayList<UIOPictureOfEnemy>
     */
    @Get("/filtered-results")
    public HttpResponse<ArrayList<Object>> getFilteredPOEResults(
            @QueryValue String timeFormat,
            @QueryValue int timeInterval,
            @QueryValue long friendlyStartTime,
            @QueryValue long friendlyEndTime,
            @QueryValue long hostileStartTime,
            @QueryValue long hostileEndTime,
            @QueryValue List<Long> selectedControlMeasures) {
        ArrayList<Object> params = new ArrayList();
        params.add(timeFormat);
        params.add(timeInterval);
        params.add(friendlyStartTime);
        params.add(friendlyEndTime);
        params.add(hostileStartTime);
        params.add(hostileEndTime);
        params.add(selectedControlMeasures);

        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_FILTERED_PICTURE_OF_ENEMY_RESULTS,
                params,
                false);

        ArrayList<Object> res = rr.getResults();
        return HttpResponse.ok(res);
    }

    /**
     * Gets the full list of control measures that were occupied
     *
     * @return ArrayList<ControlMeasureInfo>
     */
    @Get("/controlmeasures")
    public HttpResponse<List<Object>> getCMOccupationControlMeasures() {
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_PICTURE_OF_ENEMY_CMS,
                null,
                false);
        return HttpResponse.ok(rr.getResults());
    }

    /**
     * Gets all the entities associated with a capture
     *
     * @return UIOBase objects
     */
    @Get("/entities")
    public HttpResponse<List<Object>> getMetricsEntities() {
        ArrayList<Object> params = new ArrayList();
        params.add(MetricsConstants.E_METRIC.PICTURE_OF_ENEMY);

        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_METRICS_ENTITIES,
                params,
                true);
        if (rr.isSuccess()) {
            ArrayList<Object> ents = rr.getResults();
            return HttpResponse.ok(ents);
        } else {
            return HttpResponse.serverError();
        }
    }
}
