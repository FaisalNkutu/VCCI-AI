/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

import io.micronaut.core.annotation.Introspected;

/**
 * will add explanation later
 *    @author r.hassan
 */
@Introspected
public class UIOCombatPowerTypeBreakdown {
    private long time;
    private long originalQuantity;
    private long currentQuantity;
    private String formattedTime;
    private String equipmentType;

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public long getOriginalQuantity() {
        return originalQuantity;
    }

    public void setOriginalQuantity(long originalQuantity) {
        this.originalQuantity = originalQuantity;
    }

    public long getCurrentQuantity() {
        return currentQuantity;
    }

    public void setCurrentQuantity(long currentQuantity) {
        this.currentQuantity = currentQuantity;
    }

    public String getFormattedTime() {
        return formattedTime;
    }

    public void setFormattedTime(String formattedTime) {
        this.formattedTime = formattedTime;
    }
    public String getEquipmentType() {
        return equipmentType;
    }

    public void setEquipmentType(String equipmentType) {
        this.equipmentType = equipmentType;
    }
}