/*
 * Copyright 2026 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

/**
 * @author p.kuczera
 */
public class UIOROMStats {

    public double jAverage = 0.0;
    public double jMin = 0.0;
    public double jMax = 0.0;
    public double jStaticEntityPercentage = 0.0;

    public UIOROMStats() {}

    public double getAverage() {
        return jAverage;
    }

    public void setAverage(double jAverage) {
        this.jAverage = jAverage;
    }

    public double getMin() {
        return jMin;
    }

    public void setMin(double jMin) {
        this.jMin = jMin;
    }

    public double getMax() {
        return jMax;
    }

    public void setMax(double jMax) {
        this.jMax = jMax;
    }

    public double getStaticEntityPercentage() {
        return jStaticEntityPercentage;
    }

    public void setStaticEntityPercentage(double jStaticEntityPercentage) {
        this.jStaticEntityPercentage = jStaticEntityPercentage;
    }
}
