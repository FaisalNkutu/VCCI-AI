/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.simfront.midas.CentralDispatch;
import com.simfront.midas.managers.DBManager;
import io.micronaut.http.MediaType;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.QueryValue;
import reactor.core.publisher.Flux;

import java.time.Duration;
import java.util.*;
import java.util.function.Supplier;

@Controller("/advmetrics/summary")
public class SummaryController {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    /**
     * SSE endpoint: streams summary values for all processors,
     * but only sends a new event if the summary actually changed.
     */
    @Get(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM)
    public Flux<String> streamSummary(
            @QueryValue(defaultValue = "0") long fromTime,
            @QueryValue(defaultValue = "0") long toTime) {

        /*
         * Stores the last summary sent to the client.
         * Used to compare against the newly generated summary
         * so we can suppress duplicate SSE events.
         * Without storing the previous snapshot there was no way to detect duplicate updates.
         */
        final Map<String, Object>[] lastSentSummary = new Map[]{null};

        Supplier<Flux<String>> summaryGenerator = () -> {
            try {
                /*
                 * Skip polling until the database connection is fully initialized.
                 * Without this guard the SSE stream could attempt metric queries
                 * during startup and produce empty or invalid summaries.
                 *
                 */
                if (DBManager.jDBManager == null || !DBManager.jDBManager.isConnected()) {
                    return Flux.empty();
                }

                ArrayList<Object> params = new ArrayList<>();
                params.add(fromTime);
                params.add(toTime);

                Map<String, Object> summary = new HashMap<>();

                // --- 1. Combat Power ---
                summary.put("CombatPower", safeCastMap(CentralDispatch.jCentralDispatch.getCombatPowerSummary(params).getResults()));
                // --- 2. Control Measure Occupations ---
                summary.put("CMO", safeCastMap(CentralDispatch.jCentralDispatch.getCMOSummary(params).getResults()));
                // --- 3. Picture of Enemy ---
                summary.put("POE", safeCastMap(CentralDispatch.jCentralDispatch.getPOESummary(params).getResults()));
                // --- 4. Fratricide ---
                summary.put("Fratricide", safeCastMap(CentralDispatch.jCentralDispatch.getFratricideSummary(params).getResults()));
                // --- 5. Enemy Engagements ---
                summary.put("EnemyEngagements", safeCastMap(CentralDispatch.jCentralDispatch.getEnemyEngagementSummary(params).getResults()));
                // --- 6. Rates of Movement ---
                summary.put("ROM", safeCastMap(CentralDispatch.jCentralDispatch.getROMSummary(params).getResults()));
                // --- 7. Entity Watch ---
                summary.put("EntityWatch", safeCastMap(CentralDispatch.jCentralDispatch.getEntityWatchSummary(params).getResults()));
                // --- H-Hour ---
                summary.put("HHour", safeCastMap(CentralDispatch.jCentralDispatch.getHHourSummary(params).getResults()));

                // --- check if summary changed ---
                /*
                 * Only emit a new SSE event if the summary actually changed.
                 *
                 * Previously the stream emitted identical payloads every polling cycle,
                 * which caused unnecessary UI refreshes and extra network traffic.
                 * This check ensures the dashboard only receives updates when metric
                 * values actually change.
                 */
                if (!summary.equals(lastSentSummary[0])) {
                    lastSentSummary[0] = new HashMap<>(summary);

                    Map<String, Object> payload = new HashMap<>();
                    payload.put("time", System.currentTimeMillis());
                    payload.put("summary", summary);

                    String json = toJson(payload);

                    return Flux.just("data: " + json + "\n\n");
                }

                return Flux.empty();
            } catch (Exception e) {
                System.err.println("[SSE] Error generating summary");
                e.printStackTrace();
                return Flux.empty();
            }
        };

//        Flux<String> dataFlux = Flux.interval(Duration.ofSeconds(5)).flatMap(tick -> summaryGenerator.get());
        /**
         * Poll the summary periodically.
         *
         * Flux.interval() alone would wait for the first timer tick before producing data,
         * which caused the dashboard to appear empty for several seconds after a client
         * connected to the SSE stream.
         *
         * By merging Flux.just(0L), we trigger the summary generation immediately when
         * the SSE connection opens. This ensures the dashboard receives an initial
         * snapshot right away instead of waiting for the first polling interval.
         */

        Flux<String> dataFlux =
                Flux.merge(
                        Flux.just(0L),                 // immediate first emission
                        Flux.interval(Duration.ofSeconds(5))
                ).flatMap(tick -> summaryGenerator.get());

        /*
         * Long-running SSE connections were sometimes closed by network infrastructure.
         * Heartbeat event to keep the SSE connection alive.
         * Some proxies and load balancers terminate idle HTTP streams.
         * Sending a periodic heartbeat prevents the connection from closing.
         */
        Flux<String> heartbeatFlux =
                Flux.interval(Duration.ofSeconds(30))
                        .map(t -> "event: heartbeat\ndata: {\"status\":\"alive\"}\n\n");

        return Flux.merge(dataFlux, heartbeatFlux);
    }

    // --- Helpers ---
    private Map<String, Object> safeCastMap(Object obj) {
        if (obj instanceof List<?>) {
            List<?> list = (List<?>) obj;
            if (!list.isEmpty() && list.get(0) instanceof Map<?, ?>) {
                @SuppressWarnings("unchecked")
                Map<String, Object> map = (Map<String, Object>) list.get(0);
                return map;
            }
        } else if (obj instanceof Map<?, ?>) {
            @SuppressWarnings("unchecked")
            Map<String, Object> map = (Map<String, Object>) obj;
            return map;
        }
        return new HashMap<>();
    }

    private String toJson(Object obj) {
        try {
            return OBJECT_MAPPER.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            return "{}";
        }
    }
}
