/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.analysis.trend_analysis;

import com.simfront.midas.model.analysis.CombatPowerRecord;
import java.util.*;

public class CombatPowerTrendAnalyzer {

    public static Map<String, List<String>> generateRuleBasedReport(List<CombatPowerRecord> data) {
        final int WINDOW_SIZE = 5;
        final double CRITICAL_THRESHOLD = 60.0;

        Map<String, LinkedHashMap<Long, Double>> unitMap = new HashMap<>();

        for (CombatPowerRecord record : data) {
            unitMap.computeIfAbsent(record.getUnitName(), k -> new LinkedHashMap<>())
                    .put(record.getTime(), record.getCombatPower());
        }

        List<String> gradualDecreaseList = new ArrayList<>();
        List<String> gradualIncreaseList = new ArrayList<>();
        List<String> lowCPList = new ArrayList<>();
        List<String> anomalyList = new ArrayList<>();

        for (Map.Entry<String, LinkedHashMap<Long, Double>> entry : unitMap.entrySet()) {
            String unit = entry.getKey();
            LinkedHashMap<Long, Double> timeSeries = entry.getValue();
            List<Long> times = new ArrayList<>(timeSeries.keySet());
            List<Double> values = new ArrayList<>(timeSeries.values());

            if (values.stream().allMatch(v -> v == 0.0)) continue;

            gradualDecreaseList.addAll(analyzeGradualDecrease(unit, times, values, WINDOW_SIZE));
            gradualIncreaseList.addAll(analyzeGradualIncrease(unit, times, values, WINDOW_SIZE));
            lowCPList.addAll(analyzeLowCombatPower(unit, times, values, CRITICAL_THRESHOLD));
            anomalyList.addAll(analyzeAnomalies(unit, times, values));
        }

        Map<String, List<String>> result = new HashMap<>();
        result.put("gradual_decrease", gradualDecreaseList);
        result.put("gradual_increase", gradualIncreaseList);
        result.put("low_cp", lowCPList);
        result.put("anomalies", anomalyList);
        return result;
    }

    private static List<String> analyzeGradualDecrease(String unit, List<Long> times, List<Double> values, int window) {
        List<String> result = new ArrayList<>();
        for (int i = 0; i <= values.size() - window; i++) {
            boolean decreasing = true;
            for (int j = 0; j < window - 1; j++) {
                if (values.get(i + j) <= values.get(i + j + 1)) {
                    decreasing = false;
                    break;
                }
            }
            if (decreasing) {
                double startCP = values.get(i);
                double endCP = values.get(i + window - 1);
                StringBuilder msg = new StringBuilder();
                msg.append("Unit: ").append(unit).append("\n");
                msg.append("Status Changed: ")
                        .append(getStatusLabel(startCP)).append(" → ").append(getStatusLabel(endCP)).append("\n");
                msg.append("CP Drop Sequence:\n");
                for (int j = 0; j < window; j++) {
                    msg.append("  • ")
                            .append(String.format("%.1f", values.get(i + j)))
                            .append(" at ").append(times.get(i + j)).append("\n");
                }
                msg.append("\nDrop Summary: Dropped ")
                        .append(String.format("%.1f", startCP - endCP))
                        .append(" points (").append(String.format("%.1f", startCP)).append(" → ")
                        .append(String.format("%.1f", endCP)).append(") over ")
                        .append(window).append(" timestamps");
                result.add(msg.toString());
                i += window - 1; // skip overlapping
            }
        }
        return result;
    }

    private static List<String> analyzeGradualIncrease(String unit, List<Long> times, List<Double> values, int window) {
        List<String> result = new ArrayList<>();
        for (int i = 0; i <= values.size() - window; i++) {
            boolean increasing = true;
            for (int j = 0; j < window - 1; j++) {
                if (values.get(i + j) >= values.get(i + j + 1)) {
                    increasing = false;
                    break;
                }
            }
            if (increasing) {
                double startCP = values.get(i);
                double endCP = values.get(i + window - 1);
                StringBuilder msg = new StringBuilder();
                msg.append("Unit: ").append(unit).append("\n");
                msg.append("Recovery Detected: ")
                        .append(getStatusLabel(startCP)).append(" → ").append(getStatusLabel(endCP)).append("\n");
                msg.append(" CP Increase Sequence:\n");
                for (int j = 0; j < window; j++) {
                    msg.append("  • ")
                            .append(String.format("%.1f", values.get(i + j)))
                            .append(" at ").append(times.get(i + j)).append("\n");
                }
                msg.append("\nRecovery Summary: Gained ")
                        .append(String.format("%.1f", endCP - startCP))
                        .append(" CP over ").append(window).append(" timestamps");
                result.add(msg.toString());
                i += window - 1;
            }
        }
        return result;
    }

    private static List<String> analyzeLowCombatPower(String unit, List<Long> times, List<Double> values, double threshold) {
        List<String> result = new ArrayList<>();
        for (int i = 0; i < values.size(); i++) {
            double cp = values.get(i);
            if (cp > 0 && cp < threshold) {
                String msg = String.format(
                        "Unit: %s\n🇯 Status: %.1f (%s)\n🕒 Time: %d",
                        unit,
                        cp,
                        getStatusLabel(cp),
                        times.get(i)
                );
                result.add(msg);
                break;
            }
        }
        return result;
    }

    public static List<String> analyzeAnomalies(String unit, List<Long> times, List<Double> values) {
        final double SUDDEN_CHANGE_THRESHOLD = 0.5;
        List<String> result = new ArrayList<>();

        for (int i = 0; i < values.size() - 1; i++) {
            double prev = values.get(i);
            double curr = values.get(i + 1);
            if (prev == 0.0) continue;

            double ratio = Math.abs(curr - prev) / prev;

            if (ratio >= SUDDEN_CHANGE_THRESHOLD) {
                String direction = (curr > prev) ? "🔺 Sudden Surge" : "🔻 Sudden Drop";
                String msg = String.format(
                        "Unit: %s\n%s Detected between time %d → %d\n  • %.1f → %.1f (%.1f%%)",
                        unit,
                        direction,
                        times.get(i),
                        times.get(i + 1),
                        prev,
                        curr,
                        100 * (curr - prev) / prev
                );
                result.add(msg);
            }
        }

        return result;
    }

    private static String getStatusLabel(double cp) {
        if (cp >= 81) return "🟢 Fully Combat Effective";
        else if (cp >= 71) return "🟡 Limited Combat Effectiveness";
        else if (cp >= 61) return "🔴 Combat Ineffective";
        else return "⚫ Defeated";
    }
}
