/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.calian.paradigm.core.bto.model.gobjs.gen.*;

/**
 *
 * @author rhans
 */
public class UIOHHourMetricsSpecification extends UIOBase {

    @JsonIgnore
    GHhourMetricsSpecification jSpec = null;

    public UIOHHourMetricsSpecification(GHhourMetricsSpecification spec) {
        jSpec = spec;
        super.setId(spec.getHhourMetricsSpecificationId());
        super.setName((spec.getMetricsSpecificationIdentifier()));
        super.setTime(spec.getHhourMetricsSpecificationTime());
    }

    public GHhourMetricsSpecification getOMDBSpec() {
        return jSpec;
    }

    public long getLineOfDepartureId() {
        return jSpec.getHhourMetricsSpecificationLineOfDepartureId();
    }

    public long getThreshold() {
        return jSpec.getHhourMetricsSpecificationThreshold();
    }
    
    public String getLineOfDepatureName() {
        return jSpec.getHhourMetricsSpecificationLineOfDepartureName();
    }
}
