/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.controller;

import com.simfront.midas.CentralDispatch;
import com.simfront.midas.constants.MIDASConstants;
import com.simfront.midas.utils.RequestResults;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.QueryValue;

import java.util.ArrayList;
import java.util.List;

/**
 * @author rhans
 */
@Controller("/advmetrics/eneeng")
public class EnemyEngagementsController {

    /**
     * Based on the simulation time selected, the list of selected control
     * measures and the currently deselected entities, this endpoint returns a a
     * list of points for two graphs - one graph for detections, the second for
     * actual enemy engagements
     *
     * @param startTime
     * @param endTime
     * @param timeFormat
     * @param isFriendly
     * @param selectedControlMeasures
     * @return
     */
    @Get("/results-by-time")
    public HttpResponse<ArrayList<Object>> getEnemyEngagementsResultsByTime(
            @QueryValue long startTime,
            @QueryValue long endTime,
            @QueryValue String timeFormat,
            @QueryValue Boolean isFriendly,
            @QueryValue List<Long> selectedControlMeasures) {
        ArrayList<Object> params = new ArrayList();
        params.add(startTime);
        params.add(endTime);
        params.add(timeFormat);
        params.add(isFriendly);
        if (selectedControlMeasures == null) {
            selectedControlMeasures = new ArrayList();
        }
        params.add(selectedControlMeasures);

        RequestResults rr = CentralDispatch.jCentralDispatch.
                processRequest(MIDASConstants.E_REQUEST.GET_ENEENG_BY_TIME_RESULTS,
                        params,
                        false);

        ArrayList<Object> res = rr.getResults();
        return HttpResponse.ok(res);
    }

    /**
     * Gets all the entities that are either engaged or occupying the passed
     * control measures
     *
     * @param time
     * @param engaged
     * @param selectedControlMeasures
     * @return UIOBase objects
     */
    @Get("/entity-details")
    public HttpResponse<List<Object>> getMetricsEntities(
            @QueryValue long time,
            @QueryValue Boolean engaged,
            @QueryValue List<Long> selectedControlMeasures) {
        ArrayList<Object> params = new ArrayList();

        params.add(time);
        params.add(engaged);
        if (selectedControlMeasures == null) {
            selectedControlMeasures = new ArrayList();
        }
        params.add(selectedControlMeasures);

        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_ENEENG_ENTITY_DETAILS,
                params,
                true);
        if (rr.isSuccess()) {
            ArrayList<Object> ents = rr.getResults();
            return HttpResponse.ok(ents);
        } else {
            return HttpResponse.serverError();
        }
    }

    /**
     * Gets the full list of control measures that were occupied
     *
     * @return ArrayList<ControlMeasureInfo>
     */
    @Get("/controlmeasures")
    public HttpResponse<List<Object>> getEnemyEngagementsControlMeasures() {
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_ENEENG_CONTROL_MEASURES,
                null,
                false);
        return HttpResponse.ok(rr.getResults());
    }
}
