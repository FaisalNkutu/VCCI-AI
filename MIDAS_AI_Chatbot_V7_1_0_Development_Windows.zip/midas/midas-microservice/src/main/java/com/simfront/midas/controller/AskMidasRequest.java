package com.simfront.midas.controller;

import io.micronaut.core.annotation.Introspected;

@Introspected
public class AskMidasRequest {

    private String question;

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }
}