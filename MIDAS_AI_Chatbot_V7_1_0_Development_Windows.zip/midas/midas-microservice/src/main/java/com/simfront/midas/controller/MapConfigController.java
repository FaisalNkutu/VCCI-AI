/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.controller;

import io.micronaut.http.annotation.*;
import io.micronaut.http.HttpResponse;
import jakarta.inject.Singleton;

import java.util.Map;

/**
 * MapConfigController handles configuration for map layers (WMS, WMTS, CSW).
 * It receives configuration via POST (from the desktop MIDAS LAUNCHER ) and stores the latest config in memory.
 * The most recent config is available to frontend clients (e.g., a Leaflet map) via a simple GET request.
 * No persistent storage is used; the config is replaced on every new POST.
 */

@Singleton
@Controller("/advmetrics/mapconfig")
public class MapConfigController {

    // In-memory latest config (replaced on every new POST)
    private String latestAlias;
    private String latestUrl;
    private String latestType;

    @Post
    public HttpResponse<String> receiveMapConfig(@Body Map<String, String> payload) {
        // Extract fields from JSON
        this.latestAlias = payload.get("alias");
        this.latestUrl = payload.get("url");
        this.latestType = payload.get("type");

        // Log it (visible in console)
        System.out.printf("📡 Map Config Received:\nAlias: %s\nURL: %s\nType: %s\n",
                latestAlias, latestUrl, latestType);

        // Send 200 OK back to client
        return HttpResponse.ok("Map config received.");
    }

    @Get
    public Map<String, String> getMapConfig() {
        // Return latest values for frontend map (Leaflet, etc.)
        return Map.of(
                "alias", latestAlias != null ? latestAlias : "",
                "url", latestUrl != null ? latestUrl : "",
                "type", latestType != null ? latestType : ""
        );
    }
}
