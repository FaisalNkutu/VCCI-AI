/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.analytics.combatpower.model;

public enum TrendType {
    UPWARD,
    DOWNWARD,
    STABLE
}
