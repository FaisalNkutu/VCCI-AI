/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

/**
 *
 * @author rhans
 */
public class UIOBase {

    String jName = null;
    long jId = -1;
    double jLat = -1;
    double jLon = -1;
    long jTime = -1;
    String jFormattedTime;
    String jMilSym = null;
    boolean jIsFriendly = true;
    long jParentId;

    public UIOBase() {
    }

    public UIOBase(
            String name,
            long id) {
        jName = name;
        jId = id;
    }

    public UIOBase(String name,
            long id,
            double lat,
            double lon) {
        jName = name;
        jId = id;
        jLat = lat;
        jLon = lon;
    }

    public long getParentId() {
        return jParentId;
    }

    public void setParentId(long parentId) {
        jParentId = parentId;
    }

    public void setMilSym(String symbol) {
        jMilSym = symbol;
    }

    public String getMilSym() {
        return jMilSym;
    }

    public String getName() {
        return jName;
    }

    public void setName(String n) {
        jName = n;
    }

    public long getId() {
        return jId;
    }

    public void setId(long id) {
        jId = id;
    }

    public void setLat(double lat) {
        jLat = lat;
    }

    public void setLon(double lon) {
        jLon = lon;
    }

    public double getLat() {
        return jLat;
    }

    public double getLon() {
        return jLon;
    }

    public long getTime() {
        return jTime;
    }

    public void setTime(long t) {
        jTime = t;
    }

    public String getFormattedTime() {
        return jFormattedTime;
    }

    public void setFormattedTime(String t) {
        jFormattedTime = t;
    }

    public boolean isIsFriendly() {
        return jIsFriendly;
    }

    public void setIsFriendly(boolean isFriendly) {
        jIsFriendly = isFriendly;
    }
}
