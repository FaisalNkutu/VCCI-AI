/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel.mixin;

/**
 * @author n.hans
 */
public class Occupation {

    long jControlMeasureId;
    int jEntityCount = 0;
    String jControlMeasureName;

    public Occupation() {
    }

    public Occupation(
            long cmid,
            int entCount,
            String cmName) {
        jControlMeasureId = cmid;
        jEntityCount = entCount;
        jControlMeasureName = cmName;
    }

    public long getControlMeasureId() {
        return jControlMeasureId;
    }

    public void setControlMeasureId(long cmid) {
        jControlMeasureId = cmid;
    }

    public int getEntityCount() {
        return jEntityCount;
    }

    public void setEntityCount(int count) {
        jEntityCount = count;
    }

    public void incrementCount() {
        jEntityCount++;
    }

    public String getControlMeasureName() {
        return jControlMeasureName;
    }

    public void setControlMeasureName(String controlMeasureName) {
        jControlMeasureName = controlMeasureName;
    }
}
