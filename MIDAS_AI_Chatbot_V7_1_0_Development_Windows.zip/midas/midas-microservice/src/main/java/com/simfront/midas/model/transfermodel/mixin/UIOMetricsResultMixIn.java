/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel.mixin;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 * @author rhans
 */
public abstract class UIOMetricsResultMixIn extends UIOBaseMixIn {

    @JsonProperty("specid")
    public abstract long getSpecId();

    @JsonProperty("simstarttime")
    public abstract long getSimStartTime();

    @JsonProperty("objectitemid")
    public abstract long getObjectItemId();
}
