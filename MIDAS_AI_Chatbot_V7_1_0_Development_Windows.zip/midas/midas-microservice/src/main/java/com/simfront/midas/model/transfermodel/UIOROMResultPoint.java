/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

/**
 * @author rhans
 */
public class UIOROMResultPoint extends UIOBase {

    int jNumEnts;
    double jAvgSpeed;
    double jAvgCumul;

    public UIOROMResultPoint(
            int numEnts,
            long time,
            double speed,
            double cumul) {
        jNumEnts = numEnts;
        jAvgSpeed = speed;
        jAvgCumul = cumul;
        super.setTime(time);
    }

    public int getNumEnts() {
        return jNumEnts;
    }

    public double getAvgSpeed() {
        return jAvgSpeed;
    }

    public double geAvgCumul() {
        return jAvgCumul;
    }
}
