/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.controller;

import io.micronaut.core.io.ResourceLoader;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.MediaType;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;

import java.io.InputStream;
import java.util.Optional;

/**
 * @author Ian Lambert <i.lambert@simfront.com>
 * @company SimFront
 * Created on 5/9/2025, 11:25 AM
 */
@Controller
public class SpaController {
    private final ResourceLoader resourceLoader;

    public SpaController(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;
    }

    @Get(uri = "/{path:^(?!.*\\.\\w+$).*$}", produces = MediaType.TEXT_HTML)
    public HttpResponse<?> index() {
        Optional<InputStream> indexHtml = resourceLoader.getResourceAsStream("classpath:static/browser/index.html");
        return indexHtml.map(HttpResponse::ok)
                .orElse(HttpResponse.notFound());
    }
}
