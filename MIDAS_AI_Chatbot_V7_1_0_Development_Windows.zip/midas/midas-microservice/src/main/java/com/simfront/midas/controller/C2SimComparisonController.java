/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.controller;

import com.simfront.midas.CentralDispatch;
import com.simfront.midas.constants.MIDASConstants;
import com.simfront.midas.utils.RequestResults;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.QueryValue;

import java.util.ArrayList;
import java.util.List;

/**
 * @author p.kuczera
 */
@Controller("/advmetrics/c2sim-comparison")
public class C2SimComparisonController {

    @Get("/context-info")
    public HttpResponse<List<Object>> getContextInfo() {
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_C2SIM_CONTEXT_INFO,
                null,
                false);
        return HttpResponse.ok(rr.getResults());
    }

    @Get("/unit-locations")
    public HttpResponse<List<Object>> getUnitLocations(
            @QueryValue long timeStamp,
            @QueryValue long contextId,
            @QueryValue String contextType) {
        ArrayList<Object> params = new ArrayList<>();
        params.add(timeStamp);
        params.add(contextId);
        params.add(contextType);
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_C2SIM_UNIT_LOCATIONS,
                params,
                true);
        return HttpResponse.ok(rr.getResults());
    }

}
