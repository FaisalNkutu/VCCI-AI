/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel.mixin;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.calian.paradigm.core.bto.model.gobjs.gen.*;

/**
 *
 * @author rhans
 */
public abstract class UIOHHourMetricsSpecificationMixIn extends UIOBaseMixIn {

    @JsonProperty("lineofdepid")
    public abstract long getLineOfDepartureId();

    @JsonProperty("threshold")
    public abstract long getThreshold();

    @JsonProperty("lineofdepname")
    public abstract String getLineOfDepatureName();

    @JsonIgnore
    public abstract GHhourMetricsSpecification getOMDBSpec();
}
