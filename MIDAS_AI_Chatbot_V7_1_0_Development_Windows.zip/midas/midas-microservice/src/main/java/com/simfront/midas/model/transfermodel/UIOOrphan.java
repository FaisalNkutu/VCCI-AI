/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;


import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Represents a standalone unit (orphan) that does not participate in any active
 * CMDCTL (command-control) relationship in the ORBAT hierarchy.
 *
 * These units are displayed as top-level nodes in the frontend ORBAT view
 * with no parent or children.
 *
 * Each orphan contains:
 * - A unique ID
 * - A name (label)
 * - A military symbol (INF, ARMR, ARTY, etc.)
 *
 * Example JSON:
 * {
 *   "id": ,
 *   "name": "",
 *   "milSym": ""
 * }
 *
 * @author r.hassan
 */


public class UIOOrphan {
    private final long jId;
    private final String jName;
    private final String jMilSym;

    private boolean jIsFriendly;

    public UIOOrphan(long id, String name, String symbol) {
        this.jId = id;
        this.jName = name;
        this.jMilSym = symbol;
    }

    public long getId() {
        return jId;
    }
    public String getName() {
        return jName;
    }
    public String getMilSym() {
        return jMilSym;
    }

    @JsonProperty("isFriendly")
    public boolean isIsFriendly() {
        return jIsFriendly;
    }

    public void setIsFriendly(boolean isFriendly) {
        this.jIsFriendly = isFriendly;
    }
}
