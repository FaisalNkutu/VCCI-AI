/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.controller;

import com.simfront.midas.managers.DBManager;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Post;
import io.micronaut.scheduling.TaskExecutors;
import io.micronaut.scheduling.annotation.ExecuteOn;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author rhans
 */
@Controller("/midas")
public class MIDASController {

    @Post(value = "/shutdown")
    @ExecuteOn(TaskExecutors.BLOCKING)
    public HttpResponse<String> shutdown() {
        initiateShutdownSequence();
        return HttpResponse.ok("MIDAS");
    }

    private void initiateShutdownSequence() {
        new Thread(new MIDASDown()).start();
    }

    private class MIDASDown implements Runnable {

        @Override
        public void run() {
            if (DBManager.jDBManager.isConnected()) {
                DBManager.jDBManager.resetDBConnection();
            }
            try {
                Thread.sleep(2000);
            } catch (InterruptedException ex) {
                Logger.getLogger(MIDASController.class.getName()).
                        log(Level.SEVERE, null, ex);
            }
            System.exit(0);
        }
    }
}

