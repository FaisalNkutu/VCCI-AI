/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

/**
 *
 * @author rhans
 */
public class UIOFormatTime {

    long jTime = -1;
    String jFormattedTime = "";
    String jTimeFormat;

    public UIOFormatTime() {
    }

    public String getTimeFormat() {
        return jTimeFormat;
    }

    public void setTimeFormat(String timeFormat) {
        jTimeFormat = timeFormat;
    }

    public String getFormattedTime() {
        return jFormattedTime;
    }

    public void setFormattedTime(String formattedTime) {
        jFormattedTime = formattedTime;
    }
  
    public long getTime() {
        return jTime;
    }

    public void setTime(long time) {
        jTime = time;
    }
}
