package com.simfront.midas.client;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.micronaut.context.annotation.Value;
import jakarta.inject.Singleton;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Translates A2A tasks to the existing MIDAS chat polling contract. */
@Singleton
public class ExplainitClient {
    public static final String JOB_PREFIX = "explainit-";
    private final URI origin;
    private final String apiKey;
    private final ObjectMapper mapper;
    private final HttpClient http;

    public ExplainitClient(@Value("${explainit.url:`http://localhost:8091`}") String url,
                           @Value("${explainit.api-key:}") String apiKey,
                           ObjectMapper mapper) {
        URI configured = URI.create(url.trim().replaceAll("/+$", ""));
        if (!("http".equals(configured.getScheme()) || "https".equals(configured.getScheme()))
                || configured.getHost() == null || configured.getRawUserInfo() != null
                || !(configured.getPath().isEmpty() || "/a2a".equals(configured.getPath()))
                || configured.getQuery() != null || configured.getFragment() != null) {
            throw new IllegalArgumentException("explainit.url must be an HTTP server URL, optionally ending in /a2a");
        }
        this.origin = configured.resolve("/");
        this.apiKey = apiKey;
        this.mapper = mapper;
        this.http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(3)).build();
    }

    public Map<String, Object> start(Map<String, Object> request) {
        Map<String, Object> card = exchange("GET", "/.well-known/agent-card.json", null);
        // SDK 1.0 discovery uses supportedInterfaces. Keep the current 0.3 wire
        // transport through Explainit's explicitly published compatibility card.
        if (card.containsKey("supportedInterfaces")) {
            card = exchange("GET", "/.well-known/agent.json", null);
        }
        if (!"0.3.0".equals(card.get("protocolVersion"))
                || !"JSONRPC".equals(card.get("preferredTransport"))) {
            throw new IllegalStateException("Explainit must support A2A 0.3.0 JSONRPC");
        }
        Map<String, Object> message = Map.of("kind", "message", "role", "user",
                "messageId", UUID.randomUUID().toString(),
                "parts", List.of(Map.of("kind", "data", "data", payload(request))));
        Map<String, Object> task = rpc("message/send", Map.of("message", message,
                "configuration", Map.of("blocking", false)));
        String id = text(task.get("id"));
        if (id.isBlank() || !"task".equals(task.get("kind"))) {
            throw new IllegalStateException("Explainit returned no A2A task ID");
        }
        return Map.of("job_id", JOB_PREFIX + id);
    }

    public Map<String, Object> status(String jobId) {
        if (!jobId.startsWith(JOB_PREFIX) || jobId.length() == JOB_PREFIX.length()) {
            throw new IllegalArgumentException("Invalid Explainit job ID");
        }
        return translateTask(rpc("tasks/get", Map.of("id", jobId.substring(JOB_PREFIX.length()))));
    }

    public Map<String, Object> health() {
        Map<String, Object> result = new LinkedHashMap<>(exchange("GET", "/health", null));
        result.put("provider", "explainit");
        result.put("transport", "a2a");
        result.put("render_model", result.getOrDefault("model", ""));
        return result;
    }

    public Map<String, Object> query(String question) {
        String id = text(start(Map.of("question", question)).get("job_id"));
        long deadline = System.nanoTime() + Duration.ofSeconds(600).toNanos();
        while (System.nanoTime() < deadline) {
            Map<String, Object> result = status(id);
            if (!"running".equals(result.get("status"))) return object(result.get("result"));
            try { Thread.sleep(1000); }
            catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
                throw new IllegalStateException("Explainit request interrupted", exception);
            }
        }
        throw new IllegalStateException("Explainit exceeded 600 seconds");
    }

    static Map<String, Object> payload(Map<String, Object> request) {
        Map<String, Object> result = new LinkedHashMap<>();
        String question = text(request.get("question"));
        // Angular supplies a contextualized question and the original current turn.
        Map<String, Object> options = object(request.get("options"));
        Map<String, Object> help = object(options.get("processor_help"));
        String current = text(help.get("question"));
        if (current.isBlank()) {
            int marker = question.lastIndexOf("Current user request:");
            current = marker >= 0 ? question.substring(marker + "Current user request:".length()).trim() : question;
        }
        result.put("question", current);
        Object processor = request.getOrDefault("processor", options.get("processor"));
        if (processor instanceof String && !((String) processor).isBlank()) result.put("processor", processor);
        Object combatPower = request.getOrDefault("combat_power", options.get("combat_power"));
        if (combatPower instanceof Map) result.put("combat_power", combatPower);
        List<Map<String, Object>> history = new ArrayList<>();
        Object supplied = request.getOrDefault("history", help.get("history"));
        if (supplied instanceof List<?> turns) {
            for (Object turn : turns.subList(Math.max(0, turns.size() - 12), turns.size())) {
                if (turn instanceof String value) history.add(Map.of("role", "user", "content", value));
                else if (turn instanceof Map) history.add(object(turn));
            }
        }
        result.put("history", history);
        return result;
    }

    static Map<String, Object> translateTask(Map<String, Object> task) {
        String state = text(object(task.get("status")).get("state"));
        Map<String, Object> stage = Map.of("stage", object(task.get("metadata")).getOrDefault("stage", state));
        if (List.of("submitted", "working").contains(state)) {
            return Map.of("status", "running", "stage", stage);
        }
        Map<String, Object> result = null;
        if (task.get("artifacts") instanceof List<?> artifacts) {
            for (Object artifact : artifacts) {
                Object parts = object(artifact).get("parts");
                if (!(parts instanceof List<?>)) continue;
                for (Object item : (List<?>) parts) {
                    Map<String, Object> part = object(item);
                    Map<String, Object> data = object(part.get("data"));
                    if ("data".equals(part.get("kind")) && data.get("success") instanceof Boolean
                            && data.get("answer") instanceof String && data.get("rows") instanceof List<?>) {
                        result = new LinkedHashMap<>(data);
                    }
                }
            }
        }
        if (!"completed".equals(state) || result == null) {
            if (result == null) {
                result = new LinkedHashMap<>(Map.of("answer", "Explainit could not complete this request (" + state + ").",
                        "sql", "", "rows", List.of(), "row_count", 0, "attempts", 0));
            }
            result.put("success", false);
            result.putIfAbsent("error", "explainit_" + state);
        }
        boolean success = Boolean.TRUE.equals(result.get("success"));
        return Map.of("status", success ? "done" : "error", "stage", stage, "result", result);
    }

    private Map<String, Object> rpc(String method, Map<String, Object> params) {
        String id = UUID.randomUUID().toString();
        Map<String, Object> envelope = exchange("POST", "/a2a", Map.of("jsonrpc", "2.0", "id", id,
                "method", method, "params", params));
        if (!"2.0".equals(envelope.get("jsonrpc")) || !id.equals(envelope.get("id"))
                || envelope.containsKey("error") || !(envelope.get("result") instanceof Map)) {
            throw new IllegalStateException("Explainit returned an invalid or failed A2A response");
        }
        return object(envelope.get("result"));
    }

    private Map<String, Object> exchange(String method, String path, Map<String, Object> body) {
        try {
            HttpRequest.Builder builder = HttpRequest.newBuilder(origin.resolve(path))
                    .timeout(Duration.ofSeconds(10)).header("Accept", "application/json");
            if (apiKey != null && !apiKey.isBlank()) builder.header("X-API-Key", apiKey);
            if ("POST".equals(method)) builder.header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body)));
            else builder.GET();
            HttpResponse<String> response = http.send(builder.build(), HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new IllegalStateException("Explainit HTTP " + response.statusCode());
            }
            return mapper.readValue(response.body(), new TypeReference<Map<String, Object>>() {});
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Explainit request interrupted", exception);
        } catch (java.io.IOException exception) {
            throw new IllegalStateException("Cannot reach Explainit", exception);
        }
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> object(Object value) {
        return value instanceof Map ? (Map<String, Object>) value : Map.of();
    }

    private static String text(Object value) { return value instanceof String ? (String) value : ""; }
}
