package com.simfront.midas.controller;

import com.simfront.midas.client.DbAgentClient;
import com.simfront.midas.client.ExplainitClient;
import io.micronaut.context.annotation.Value;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.MediaType;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.PathVariable;
import io.micronaut.http.annotation.Post;
import io.micronaut.scheduling.TaskExecutors;
import io.micronaut.scheduling.annotation.ExecuteOn;

import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

@Controller("/midas/ai")
@ExecuteOn(TaskExecutors.BLOCKING)
public class MidasAiController {

    private static final Logger LOGGER =
            Logger.getLogger(MidasAiController.class.getName());

    private final DbAgentClient dbAgentClient;

    private final ExplainitClient explainitClient;
    private final boolean useExplainit;

    public MidasAiController(DbAgentClient dbAgentClient, ExplainitClient explainitClient,
                             @Value("${midas-ai.provider:db-agent}") String provider) {
        this.dbAgentClient = dbAgentClient;
        this.explainitClient = explainitClient;
        if (!"explainit".equals(provider) && !"db-agent".equals(provider)) {
            throw new IllegalArgumentException("midas-ai.provider must be db-agent or explainit");
        }
        this.useExplainit = "explainit".equals(provider);
    }

    @Post(value = "/ask", produces = MediaType.TEXT_PLAIN)
    public HttpResponse<String> ask(@Body AskMidasRequest request) {
        String question = request.getQuestion();

        if (question == null || question.isBlank()) {
            return HttpResponse.badRequest("Question is required.");
        }

        try {
            Map<String, Object> result = useExplainit ? explainitClient.query(question) : dbAgentClient.query(request);

            if (!Boolean.TRUE.equals(result.get("success"))) {
                return HttpResponse.<String>status(HttpStatus.BAD_GATEWAY)
                        .body("The configured agent could not answer the question.");
            }

            Object answer = result.get("answer");

            if (!(answer instanceof String)) {
                return HttpResponse.<String>status(HttpStatus.BAD_GATEWAY)
                        .body("The configured agent returned an invalid answer.");
            }

            return HttpResponse.ok((String) answer);
        } catch (RuntimeException exception) {
            LOGGER.log(Level.WARNING, "Agent query failed", exception);

            return HttpResponse.<String>status(HttpStatus.BAD_GATEWAY)
                    .body("Agent request failed.");
        }
    }

    @Post("/query/start")
    public HttpResponse<Map<String, Object>> start(
            @Body Map<String, Object> request) {

        Object question = request.get("question");

        if (!(question instanceof String)
                || ((String) question).isBlank()) {
            return HttpResponse.badRequest(
                    Map.of("error", "Question is required."));
        }

        try {
            return HttpResponse.ok(useExplainit ? explainitClient.start(request) : dbAgentClient.start(request));
        } catch (RuntimeException exception) {
            return upstreamFailure("Could not start the configured agent query.", exception);
        }
    }

    @Get("/query/status/{jobId}")
    public HttpResponse<Map<String, Object>> status(
            @PathVariable String jobId) {

        try {
            return HttpResponse.ok(jobId.startsWith(ExplainitClient.JOB_PREFIX)
                    ? explainitClient.status(jobId) : dbAgentClient.status(jobId));
        } catch (RuntimeException exception) {
            return upstreamFailure("Could not retrieve query status.", exception);
        }
    }

    @Get("/health")
    public HttpResponse<Map<String, Object>> health() {
        try {
            return HttpResponse.ok(useExplainit ? explainitClient.health() : dbAgentClient.health());
        } catch (RuntimeException exception) {
            return upstreamFailure("Could not reach the configured agent.", exception);
        }
    }

    private HttpResponse<Map<String, Object>> upstreamFailure(
            String message, RuntimeException exception) {

        LOGGER.log(Level.WARNING, message, exception);

        return HttpResponse.<Map<String, Object>>status(HttpStatus.BAD_GATEWAY)
                .body(Map.of("error", message));
    }
}