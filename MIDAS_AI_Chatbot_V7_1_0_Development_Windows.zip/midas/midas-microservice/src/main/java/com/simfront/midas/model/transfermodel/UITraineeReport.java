package com.simfront.midas.model.transfermodel;

import java.util.List;

/**
 * @author Ian Lambert <ian.lambert@calian.com>
 * @company Calian Learning Technologies and Innovation
 * Created on 4/13/2026, 9:43 AM
 */
public class UITraineeReport {
    private String jTrainee;
    private String jPosition;
    private String jBtsCompleted;
    private String jTrainingLevel;
    private String jTimeOfFirstContact;
    private String jAttackStart;
    private String jAttackEnd;
    private String jConsolidationStart;
    private String jConsolidationEnd;
    private int jFriendlyPersonnelCasualties;
    private int jFriendlyVehicleCasualties;
    private int jEnemyPersonnelCasualties;
    private int jEnemyVehicleCasualties;
    private String jTimeInOrv;
    private String jTimeInAttackPosn;
    private String jResult;
    private String jScenarioOutcome;
    private int jKmsDriven;
    private String jTimeInVehicle;
    private String jTimeInMotion;
    private String jTimeInPlace;
    private int jShotsFired;
    private int jHits;
    private int jMissed;
    private String jAccuracy;
    private int jAimingDeviation;
    private List<UITargetTiming> jTargetTimings;

    public String getTrainee() { return jTrainee; }
    public void setTrainee(String jTrainee) { this.jTrainee = jTrainee; }

    public String getPosition() { return jPosition; }
    public void setPosition(String jPosition) { this.jPosition = jPosition; }

    public String getBtsCompleted() { return jBtsCompleted; }
    public void setBtsCompleted(String jBtsCompleted) { this.jBtsCompleted = jBtsCompleted; }

    public String getTrainingLevel() { return jTrainingLevel; }
    public void setTrainingLevel(String jTrainingLevel) { this.jTrainingLevel = jTrainingLevel; }

    public String getTimeOfFirstContact() { return jTimeOfFirstContact; }
    public void setTimeOfFirstContact(String jTimeOfFirstContact) { this.jTimeOfFirstContact = jTimeOfFirstContact; }

    public String getAttackStart() { return jAttackStart; }
    public void setAttackStart(String jAttackStart) { this.jAttackStart = jAttackStart; }

    public String getAttackEnd() { return jAttackEnd; }
    public void setAttackEnd(String jAttackEnd) { this.jAttackEnd = jAttackEnd; }

    public String getConsolidationStart() { return jConsolidationStart; }
    public void setConsolidationStart(String jConsolidationStart) { this.jConsolidationStart = jConsolidationStart; }

    public String getConsolidationEnd() { return jConsolidationEnd; }
    public void setConsolidationEnd(String jConsolidationEnd) { this.jConsolidationEnd = jConsolidationEnd; }

    public int getFriendlyPersonnelCasualties() { return jFriendlyPersonnelCasualties; }
    public void setFriendlyPersonnelCasualties(int jFriendlyPersonnelCasualties) { this.jFriendlyPersonnelCasualties = jFriendlyPersonnelCasualties; }

    public int getFriendlyVehicleCasualties() { return jFriendlyVehicleCasualties; }
    public void setFriendlyVehicleCasualties(int jFriendlyVehicleCasualties) { this.jFriendlyVehicleCasualties = jFriendlyVehicleCasualties; }

    public int getEnemyPersonnelCasualties() { return jEnemyPersonnelCasualties; }
    public void setEnemyPersonnelCasualties(int jEnemyPersonnelCasualties) { this.jEnemyPersonnelCasualties = jEnemyPersonnelCasualties; }

    public int getEnemyVehicleCasualties() { return jEnemyVehicleCasualties; }
    public void setEnemyVehicleCasualties(int jEnemyVehicleCasualties) { this.jEnemyVehicleCasualties = jEnemyVehicleCasualties; }

    public String getTimeInOrv() { return jTimeInOrv; }
    public void setTimeInOrv(String jTimeInOrv) { this.jTimeInOrv = jTimeInOrv; }

    public String getTimeInAttackPosn() { return jTimeInAttackPosn; }
    public void setTimeInAttackPosn(String jTimeInAttackPosn) { this.jTimeInAttackPosn = jTimeInAttackPosn; }

    public String getResult() { return jResult; }
    public void setResult(String jResult) { this.jResult = jResult; }

    public String getScenarioOutcome() { return jScenarioOutcome; }
    public void setScenarioOutcome(String jScenarioOutcome) { this.jScenarioOutcome = jScenarioOutcome; }

    public int getKmsDriven() { return jKmsDriven; }
    public void setKmsDriven(int jKmsDriven) { this.jKmsDriven = jKmsDriven; }

    public String getTimeInVehicle() { return jTimeInVehicle; }
    public void setTimeInVehicle(String jTimeInVehicle) { this.jTimeInVehicle = jTimeInVehicle; }

    public String getTimeInMotion() { return jTimeInMotion; }
    public void setTimeInMotion(String jTimeInMotion) { this.jTimeInMotion = jTimeInMotion; }

    public String getTimeInPlace() { return jTimeInPlace; }
    public void setTimeInPlace(String jTimeInPlace) { this.jTimeInPlace = jTimeInPlace; }

    public int getShotsFired() { return jShotsFired; }
    public void setShotsFired(int jShotsFired) { this.jShotsFired = jShotsFired; }

    public int getHits() { return jHits; }
    public void setHits(int jHits) { this.jHits = jHits; }

    public int getMissed() { return jMissed; }
    public void setMissed(int jMissed) { this.jMissed = jMissed; }

    public String getAccuracy() { return jAccuracy; }
    public void setAccuracy(String jAccuracy) { this.jAccuracy = jAccuracy; }

    public int getAimingDeviation() { return jAimingDeviation; }
    public void setAimingDeviation(int jAimingDeviation) { this.jAimingDeviation = jAimingDeviation; }

    public List<UITargetTiming> getTargetTimings() { return jTargetTimings; }
    public void setTargetTimings(List<UITargetTiming> jTargetTimings) { this.jTargetTimings = jTargetTimings; }

    public static class UITargetTiming {

        private String jTargetId;
        private String jTimeObsToLrf;
        private String jTimeLrfToFirstShot;
        private String jTimeFirstShotToEliminated;

        public String getTargetId() { return jTargetId; }
        public void setTargetId(String jTargetId) { this.jTargetId = jTargetId; }

        public String getTimeObsToLrf() { return jTimeObsToLrf; }
        public void setTimeObsToLrf(String jTimeObsToLrf) { this.jTimeObsToLrf = jTimeObsToLrf; }

        public String getTimeLrfToFirstShot() { return jTimeLrfToFirstShot; }
        public void setTimeLrfToFirstShot(String jTimeLrfToFirstShot) { this.jTimeLrfToFirstShot = jTimeLrfToFirstShot; }

        public String getTimeFirstShotToEliminated() { return jTimeFirstShotToEliminated; }
        public void setTimeFirstShotToEliminated(String jTimeFirstShotToEliminated) { this.jTimeFirstShotToEliminated = jTimeFirstShotToEliminated; }
    }
}
