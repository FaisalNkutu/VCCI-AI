/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */
package com.simfront.midas.controller;

import com.simfront.midas.CentralDispatch;
import com.simfront.midas.constants.MIDASConstants;
import com.simfront.midas.model.transfermodel.UIOROMStats;
import com.simfront.midas.utils.RequestResults;
import com.calian.paradigm.core.metrics.MetricsConstants;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.QueryValue;

import java.util.ArrayList;
import java.util.List;

/**
 * @author rhans This is the controller for the Rates Of Movement Dashboard.
 * There are mixins for all the returned objects
 */
@Controller("/advmetrics/rom")
public class ROMController {

    /**
     * Gets the ROM results data for a single Capture.
     *
     * @param romSpecId the ID of the Rates Of Movement Specification
     * @param timeFormat
     * @param startTime
     * @param endTime
     * @param selectedIds the entities for which data is requested
     * @return ROMResultPoint[] for requested entities with speed/distance
     * averaged for all entities available at that time point
     */
    @Get("/rom-results")
    public HttpResponse<List<Object>> getRatesOfMovementResults(
            @QueryValue long romSpecId,
            @QueryValue String timeFormat,
            @QueryValue long startTime,
            @QueryValue long endTime,
            @QueryValue List<Long> selectedIds) {
        ArrayList<Object> params = new ArrayList<>();
        params.add(romSpecId);
        params.add(timeFormat);
        params.add(startTime);
        params.add(endTime);
        params.add(selectedIds);
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_RATES_OF_MOVEMENT_RESULTS,
                params,
                false);
        return HttpResponse.ok(rr.getResults());
    }

    /**
     * Gets all the entities associated with a capture
     *
     * @param romSpecId the id of the ROM spec
     * @return UIOBase object
     */
    @Get("/entities")
    public HttpResponse<List<Object>> getMetricsEntities(
            @QueryValue long romSpecId) {
        ArrayList<Object> params = new ArrayList<>();
        params.add(MetricsConstants.E_METRIC.RATES_OF_MOVEMENT);
        params.add(romSpecId);

        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_METRICS_ENTITIES,
                params,
                true);
        if (rr.isSuccess()) {
            ArrayList<Object> ents = rr.getResults();
            return HttpResponse.ok(ents);
        } else {
            return HttpResponse.serverError();
        }
    }

    /**
     * Gets the full list of available captures
     *
     * @param format
     * @return DROMMetricsSpecification, it's all the captures.
     */
    @Get("/specs")
    public HttpResponse<List<Object>> getROMSpecs(
            @QueryValue String format
    ) {
        ArrayList<Object> params = new ArrayList<>();
        params.add(format);
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_RATES_OF_MOVEMENT_SPECS,
                params,
                false);
        return HttpResponse.ok(rr.getResults());
    }

    @Get("/stats")
    public HttpResponse<Object> getStats(
            @QueryValue long romSpecId,
            @QueryValue long startTime,
            @QueryValue long endTime,
            @QueryValue List<Long> selectedIds) {
        ArrayList<Object> params = new ArrayList<>();
        params.add(romSpecId);
        params.add(startTime);
        params.add(endTime);
        params.add(selectedIds);
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_RATES_OF_MOVEMENT_STATS,
                params,
                false);

        ArrayList<Object> results = rr.getResults();
        if (results == null || results.isEmpty()) {
            return HttpResponse.notFound("ROM Stats not available.");
        }

        UIOROMStats uio = null;
        if (results.size() == 1) {
            uio = (UIOROMStats) results.get(0);
        }
        return HttpResponse.ok(uio);
    }
}
