package com.simfront.midas.model.transfermodel;

/**
 * @author Ian Lambert <ian.lambert@calian.com>
 * @company Calian Learning Technologies and Innovation
 * Created on 4/16/2026, 5:34 PM
 */
public class UITraineeId {
    private String jId;
    private String jName;

    public UITraineeId() {

    }

    public UITraineeId(String jId, String jName) {
        this.jId = jId;
        this.jName = jName;
    }

    public String getId() { return jId; }
    public void setId(String jId) { this.jId = jId; }

    public String getName() { return jName; }
    public void setName(String jName) { this.jName = jName; }
}
