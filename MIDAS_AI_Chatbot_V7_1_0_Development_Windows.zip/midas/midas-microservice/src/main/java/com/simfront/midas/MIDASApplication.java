/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */
package com.simfront.midas;

import com.calian.common.lib.lc.runtime.validation.ILifecycleHandler;
import com.calian.common.lib.lc.runtime.validation.LifecycleManager;
import com.calian.common.lib.lc.runtime.validation.LifecycleMonitor;
import com.calian.common.lib.lc.runtime.validation.records.ApplicationRecord;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.calian.common.lib.log.Log;
import com.simfront.midas.model.GRatesOfMovementMetricsResultsMixIn;
import com.simfront.midas.model.transfermodel.*;
import com.simfront.midas.model.transfermodel.UIOC2SimContext;
import com.simfront.midas.model.transfermodel.mixin.*;
import com.simfront.midas.ui.SysTray;
import com.calian.paradigm.core.bto.model.gobjs.gen.*;
import com.calian.common.lib.serialization.ProductVersion;
import io.micronaut.context.ApplicationContext;
import io.micronaut.context.annotation.Context;
import io.micronaut.context.event.BeanCreatedEvent;
import io.micronaut.context.event.BeanCreatedEventListener;
import io.micronaut.runtime.Micronaut;
import jakarta.inject.Singleton;
import com.simfront.midas.ui.StartupFrame;
import org.slf4j.Logger;

import javax.swing.*;

/**
 * @author rhans
 */
@Context
public class MIDASApplication implements ILifecycleHandler {

    public static final String VERSION_FILE = "/cottsversion.properties";
    private LifecycleMonitor jLifecycleMonitor = null;
    private volatile boolean jExpiryNoticeIssued = false;
    private static final Logger jL = Log.getLogger(MIDASApplication.class);
    private static ApplicationContext jContext;

    public MIDASApplication() {
        new CentralDispatch();
    }

    private void initialize() {
        ProductVersion cottsVersionInfo = getProductVersion();

        SysTray.initSysTray();

        String name = null;
        String version = null;
        if (cottsVersionInfo == null) {
            jL.error("Unable to determine product version.");
        } else {
            // TODO : We need to use product name but its currently set to NUMBERS
            name = LifecycleManager.md5("MIDAS");
            version = LifecycleManager.md5(cottsVersionInfo.getVersion());
        }
        jLifecycleMonitor = LifecycleManager.createMonitor(this, new ApplicationRecord(name, version));
        // Wait here for the first license check to finish.
        try {
            jLifecycleMonitor.waitForFeatureList(5000);
        } catch (InterruptedException ex) {
            jL.error("Unable to obtain feature list.  Plugins will not function.");
        }
    }

    private static ProductVersion getProductVersion() {
        try {
            return new ProductVersion(MIDASApplication.class.getResourceAsStream(VERSION_FILE));
        } catch (Exception ex) {
            jL.error("Failed to determine product version.", ex);
            return null;
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        jContext = Micronaut.run(MIDASApplication.class, args);
        jContext.getBean(MIDASApplication.class).initialize();
        launchUI();
    }

    private static void launchUI() {
        // Start UI
        SwingUtilities.invokeLater(() -> {
            new StartupFrame().setVisible(true);
        });
    }

    @Override
    public void handleApplicationLicenseExpiry(byte code) {
        final String title;
        final String message;
        if (code == LifecycleManager.COMMS_ERROR) {
            title = "Error";
            message = "There was a communications failure between the application and the license service.  Refer to the User Guide for troubleshooting.";
        } else if (code == LifecycleManager.APP_NOT_FOUND) {
            title = "License Expired";
            message = "No valid license found.  Refer to the User Guide for troubleshooting.";
        } else if (code == LifecycleManager.BAD_VERSION) {
            title = "License Mismatch";
            message = "The current license is not valid for this version of the application.  Refer to the User Guide for troubleshooting.";
        } else {
            // This should not be currently possible... --SS
            title = "Error";
            message = "There was an unexpected error validating the software license.  Refer to the User Guide for troubleshooting.";
        }
        // Kind of a silly check but the expiry message keeps firing so we need this to prevent multiple windows from popping up.
        if (!jExpiryNoticeIssued) {
            if (jContext != null) {
                jContext.stop();
            }
            jExpiryNoticeIssued = true;
            SwingUtilities.invokeLater(() -> {
                JOptionPane.showConfirmDialog(
                        null,
                        message,
                        title,
                        JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.WARNING_MESSAGE);
                System.exit(0);
            });
        }
    }

    @Override
    public void handleFeatureLicenseExpiry(String s) {
        // No support for now.  No features to individually expire.
    }

    @Singleton
    static class ObjectMapperBeanEventListener implements BeanCreatedEventListener<ObjectMapper> {

        @Override
        public ObjectMapper onCreated(BeanCreatedEvent<ObjectMapper> event) {
            final ObjectMapper mapper = event.getBean();

            // Default settings...
//            mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
//            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
//            mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
            //           mapper.setDefaultMergeable(true);
            // Add mixin here...
            mapper.addMixIn(GRatesOfMovementMetricsResults.class, GRatesOfMovementMetricsResultsMixIn.class);

            // --- Common Objects
            mapper.addMixIn(UIOBase.class, UIOBaseMixIn.class);
            // --- HHOUR Objects
            mapper.addMixIn(UIOHHourEntityInfo.class, UIOHHourEntityInfoMixIn.class);
            mapper.addMixIn(UIOHHourMetricsSpecification.class, UIOHHourMetricsSpecificationMixIn.class);
            mapper.addMixIn(UIOHHourMetricsResult.class, UIOHHourMetricsResultMixIn.class);
            // --- ROM Objects
            mapper.addMixIn(UIOROMMetricsSpecification.class, UIOROMMetricsSpecificationMixIn.class);
            mapper.addMixIn(UIOROMResultPoint.class, UIOROMResultPointMixIn.class);

            // --- CM Occupation Objects
            // MAGI: TO DO
            // --- POE Objects
            mapper.addMixIn(UIOPictureOfEnemy.class, UIOPictureOfEnemyMixIn.class);

            // --- Combat Power Objects
            mapper.addMixIn(UIOCombatPowerDetail.class, UIOCombatPowerDetailMixIn.class);

            // --- C2Sim Comparison Objects
            mapper.addMixIn(UIOC2SimContext.class, UIOC2SimContextMixIn.class);

            return mapper;
        }
    }
}
