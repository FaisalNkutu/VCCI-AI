package com.simfront.midas.controller;

import com.simfront.midas.model.transfermodel.UITraineeId;
import com.simfront.midas.model.transfermodel.UITraineeReport;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.QueryValue;

import java.util.ArrayList;
import java.util.List;

@Controller("/lvcts/trainee")
public class TraineeReportController {

    @Get()
    public HttpResponse<List<UITraineeId>> getTrainees() {
        List<UITraineeId> traineeIds = new ArrayList<>();
        traineeIds.add(new UITraineeId("1", "John Doe"));
        traineeIds.add(new UITraineeId("2", "Roger Smith"));
        traineeIds.add(new UITraineeId("3", "Jim Bob"));
        return HttpResponse.ok(traineeIds);
    }

    @Get("/report")
    public HttpResponse<UITraineeReport> getTraineeReport(@QueryValue String traineeId) {

        UITraineeReport.UITargetTiming target1 = new UITraineeReport.UITargetTiming();
        target1.setTargetId("BMP_001");
        target1.setTimeObsToLrf("00:00:05");
        target1.setTimeLrfToFirstShot("00:00:09");
        target1.setTimeFirstShotToEliminated("00:00:10");

        UITraineeReport.UITargetTiming target2 = new UITraineeReport.UITargetTiming();
        target2.setTargetId("BMP_002");
        target2.setTimeObsToLrf("00:00:25");
        target2.setTimeLrfToFirstShot("00:00:04");
        target2.setTimeFirstShotToEliminated("00:00:10");

        UITraineeReport traineeReport = new UITraineeReport();
        traineeReport.setTrainee(traineeId);
        traineeReport.setPosition("Gunner");
        traineeReport.setBtsCompleted("Gagetown range");
        traineeReport.setTrainingLevel("TL3");
        traineeReport.setTimeOfFirstContact("00:03:26");
        traineeReport.setAttackStart("00:03:42");
        traineeReport.setAttackEnd("00:04:12");
        traineeReport.setConsolidationStart("00:06:27");
        traineeReport.setConsolidationEnd("00:07:10");
        traineeReport.setFriendlyPersonnelCasualties(0);
        traineeReport.setFriendlyVehicleCasualties(0);
        traineeReport.setEnemyPersonnelCasualties(7);
        traineeReport.setEnemyVehicleCasualties(2);
        traineeReport.setTimeInOrv("00:02:08");
        traineeReport.setTimeInAttackPosn("00:00:36");
        traineeReport.setResult("pass");
        traineeReport.setScenarioOutcome("success");
        traineeReport.setKmsDriven(0);
        traineeReport.setTimeInVehicle("00:07:40");
        traineeReport.setTimeInMotion("00:06:53");
        traineeReport.setTimeInPlace("00:00:47");
        traineeReport.setShotsFired(18);
        traineeReport.setHits(13);
        traineeReport.setMissed(5);
        traineeReport.setAccuracy("72.22%");
        traineeReport.setAimingDeviation(30);
        traineeReport.setTargetTimings(List.of(target1, target2));

        return HttpResponse.ok(traineeReport);
    }

}
