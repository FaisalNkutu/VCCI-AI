/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.analytics.combatpower.detectors;

import com.simfront.midas.analytics.combatpower.model.AnomalyType;
import java.util.ArrayList;
import java.util.List;

public class CombatPowerAnomalyDetector {

    /**
     * Finds anomalies in a time series by checking sudden % changes.
     *
     * @param values list of combat power values (in time order)
     * @param thresholdPct percentage change threshold (e.g., 20.0 = 20%)
     * @return list of anomaly types per index
     */
    public static List<AnomalyType> findAnomalies(List<Double> values, double thresholdPct) {
        List<AnomalyType> anomalies = new ArrayList<>();

        if (values == null || values.size() < 2) {
            return anomalies; // nothing to analyze
        }

        for (int i = 1; i < values.size(); i++) {
            double prev = values.get(i - 1);
            double curr = values.get(i);

            if (prev == 0) {
                anomalies.add(AnomalyType.NONE);
                continue;
            }

            double changePct = ((curr - prev) / prev) * 100.0;

            if (changePct >= thresholdPct) {
                anomalies.add(AnomalyType.SPIKE);
            } else if (changePct <= -thresholdPct) {
                anomalies.add(AnomalyType.DROP);
            } else {
                anomalies.add(AnomalyType.NONE);
            }
        }

        return anomalies;
    }
}
