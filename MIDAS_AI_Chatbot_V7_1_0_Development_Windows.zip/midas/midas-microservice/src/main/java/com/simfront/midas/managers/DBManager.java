/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */
package com.simfront.midas.managers;

import com.calian.common.lib.db.DBConn;
import com.calian.common.lib.db.DBConstants;
import com.calian.common.lib.db.exceptions.DB_TxnFailedException;
import com.calian.common.lib.db.txns.TxnRawSQL;
import com.calian.common.lib.db.txns.TxnSelect;
import com.calian.paradigm.core.bto.model.gobjs.gen.*;
import com.calian.paradigm.core.dbtxns.*;
import com.calian.paradigm.core.dbtxns.gen.*;
import com.simfront.midas.model.transfermodel.*;
import com.simfront.midas.utils.MIDASUtils;
import com.calian.paradigm.core.DBReader;
import com.calian.paradigm.core.bto.model.aobjs.AObjectItem;
import com.calian.paradigm.core.bto.model.aobjs.AObjectItemLocation;
import com.calian.paradigm.core.bto.model.aobjs.AObjectItemType;
import com.calian.paradigm.core.bto.model.aobjs.metrics.AMetObjectItem;
import com.calian.paradigm.core.bto.model.aobjs.metrics.AMetObjectItemType;
import com.calian.paradigm.core.bto.model.dobjs.DCorridorArea;
import com.calian.paradigm.core.bto.model.dobjs.DEllipse;
import com.calian.paradigm.core.bto.model.dobjs.DFanArea;
import com.calian.paradigm.core.bto.model.dobjs.DLine;
import com.calian.paradigm.core.bto.model.dobjs.DLinePoint;
import com.calian.paradigm.core.bto.model.dobjs.DMetricsTimeFormats;
import com.calian.paradigm.core.bto.model.dobjs.DObjectItemAssociation;
import com.calian.paradigm.core.bto.model.dobjs.DOrbitArea;
import com.calian.paradigm.core.bto.model.dobjs.DPolyarcArea;
import com.calian.paradigm.core.bto.model.dobjs.DPolygonArea;
import com.calian.paradigm.core.bto.model.dobjs.DTrackArea;
import com.calian.paradigm.core.bto.requests.readreq.GetHoldingsRequest;
import com.calian.paradigm.core.bto.requests.readreq.GetLocationsRequest;
import com.calian.paradigm.core.bto.requests.readreq.GetMetricsSpecificationsRequest;
import com.calian.paradigm.core.bto.requests.readreq.GetMetricsTimeFormatsRequest;
import com.calian.paradigm.core.bto.requests.readreq.GetObjectItemAssociationsRequest;
import com.calian.paradigm.core.bto.requests.readreq.GetObjectItemStatusesRequest;
import com.calian.paradigm.core.bto.requests.readreq.GetObjectItemTypesRequest;
import com.calian.paradigm.core.bto.requests.readreq.GetObjectItemsRequest;
import com.calian.paradigm.core.bto.requests.readreq.GetSimulationStartTimeRequest;
import com.calian.paradigm.core.bto.requests.readreq.GetTimeRequest;
import com.calian.paradigm.core.cache.DBCache;
import com.calian.paradigm.core.cache.DBCacheLoader;
import com.calian.paradigm.core.cache.GObjectItemDataCache;
import com.calian.paradigm.core.cache.metrics.GMetObjectItemDataCache;
import com.calian.paradigm.core.cache.metrics.MetObjectDBCache;
import com.calian.paradigm.core.db.OMConn;
import com.calian.paradigm.core.dbobjs.gen.DB_GFratricideMetricsResults;
import com.calian.paradigm.core.dbobjs.gen.DB_GHhourMetricsResults;
import com.calian.paradigm.core.dbobjs.gen.DB_GLocation;
import com.calian.paradigm.core.dbobjs.gen.DB_GObjectItemLocation;
import com.calian.paradigm.core.dbobjs.gen.DB_GRatesOfMovementMetricsResults;
import com.calian.paradigm.core.dbtxns.metrics.GetMetObjectItemPointLocationsByTimeTxn;
import com.calian.paradigm.core.mapping.MilStd2525bGenerator;
import com.calian.paradigm.core.metrics.MetricsConstants;
import com.calian.paradigm.core.metrics.MetricsConstants.E_METRIC;

import static org.reflections.Reflections.log;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * @author rhans
 */
public class DBManager {

    public static DBManager jDBManager;
    private long jEarliestTime = 0;
    private long jLatestTime = 0; // Will change in live mode
    private String jLastFormat = null;
    protected DBReader jDBReader = null;

    private boolean jConnected = false;
    private boolean jCacheReady = false;

    // --- Add these fields at the top of DBManager ---
    private String jHost = null;
    private boolean jLiveMode = false;

    MIDASDBCache jCache = null;
    Thread jInitCacheThread = null;
    Thread jLiveDataBasePollingThread = null;
    Thread jStatusThread = null;
    int jPollingIntervalSeconds = 60;
    int jStatusIntervalSeconds = 10;
    long jSimulationStartTime = DBConstants.INVALID_TIME;
    boolean jAllowPolling = true;
    public static final String DEFAULT_CODE = "SUZP-----------";
    private static final String RESUPPLY = "RESUPPLY";
    // Acceptable difference between a resupply event and a holding change
    // being registered (to account for sims that might have a small timestep
    // or are running in real time) where the holdings change might happen
    // slightly after the resupply event
    private static final int ACCEPTABLE_RESUPPLY_DELTA_MILLISECS = 5000;
    HashMap<String, DMetricsTimeFormats> jTimeFormatCache = new HashMap();
    // Hashmap of symbols by object item id
    HashMap<Long, String> jMilitarySymbolsHM = new HashMap();

    // Some status values to assist user
    UIOMetricsStatus jMetricsStatus = null;

    public DBManager() {
        jDBManager = this;
    }


    public record MDVTRecord(
            int trainingSession,
            String traineeName,
            String position,
            long positionTimeOccupied,
            String targetName,
            String targetType,
            long fireId,
            long fireTime,
            int fireHit,
            int fireTargetDestroyed,
            long fireTargetHitToElim,
            String vehicleName,
            String vehicleType,
            long vehicleMoveTime,
            long vehicleStaticTime,
            long LRFTime,
            long OBSTime
    ){}

    // This is data that we will push to the front end at regular intervals
    // if the user is connected in live mode. It will provide information to
    // let user know about metrics configurations and maybe eventually a
    // live dashboard for realtime results. This is set by our status thread.
    public synchronized void setPushData(UIOMetricsStatus stat) {
        jMetricsStatus = stat;
        jMetricsStatus.jMaxTime = jLatestTime;
        jMetricsStatus.jFormattedMaxTime = MIDASUtils.applyTimeFormat(
                DBManager.jDBManager.getTimeFormat(jLastFormat),
                jLatestTime
        );
        if (stat != null) {
            //System.err.println(stat);
        }
    }

    public UIOMetricsStatus getMetricsStatus() {
        return jMetricsStatus;
    }

    public long getSimulationStartTime() {
        return jSimulationStartTime;
    }

    public long getEarliestTime() {
        return jEarliestTime;
    }

    public long getLatestTime() {
        return jLatestTime;
    }

    public void suspendPolling() {
        jAllowPolling = false;
    }

    public void resumePolling() {
        jAllowPolling = true;
    }

    public void resetDBConnection() {
        if (jCache != null) {
            jCache = null;
        }
        if (jDBReader != null) {
            jDBReader.disconnect();
            jDBReader = null;
        }
        if (jInitCacheThread != null) {
            if (jInitCacheThread.isAlive()) {
                jInitCacheThread.interrupt();
            }
        }
        if (jLiveDataBasePollingThread != null) {
            if (jLiveDataBasePollingThread.isAlive()) {
                jLiveDataBasePollingThread.interrupt();
            }
        }
        if (jStatusThread != null) {
            if (jStatusThread.isAlive()) {
                jStatusThread.interrupt();
            }
        }
        jConnected = false;
        jCacheReady = false;
        jHost = null;
        jLiveMode = false;
        jInitCacheThread = null;
        jStatusThread = null;
        jLiveDataBasePollingThread = null;
        // Reset database dependent data
        jTimeFormatCache = new HashMap();
        jMilitarySymbolsHM = new HashMap();
        jSimulationStartTime = DBConstants.INVALID_TIME;
        jEarliestTime = 0;
        jLatestTime = 0;
        jMetricsStatus = null;
    }

    public String getDBName() {
        if (jDBReader != null) {
            return jDBReader.getDBName();
        }
        return null;
    }

    // --- Getter for host ---
    public String getHost() {
        return jHost;
    }

    // --- Getter for live mode ---
    public boolean isLiveMode() {
        return jLiveMode;
    }

    public boolean isConnected() {
        return jConnected;
    }

    public boolean isCacheReady() {
        return jCacheReady;
    }

    public void waitForCache() {
        while (!isCacheReady()) {
            try {
                System.err.println("Waiting for cache...");
                Thread.sleep(2000);

            } catch (InterruptedException ex) {
                Logger.getLogger(DBManager.class
                        .getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public boolean configureDB(
            String host,
            String db,
            String user,
            String pwd,
            boolean isLive) {
        jDBReader = new DBReader(null);
        jDBReader.setConnectionParameters(host, db, user, pwd);
        this.jHost = host;        // store host
        this.jLiveMode = isLive;  // store live mode choice

        if (jDBReader.verifyConnected()) {
            jConnected = true;
            jInitCacheThread = new Thread(new DBCacheInit());
            jInitCacheThread.start();
            // To not return until cache is ready so caller can show busy
            waitForCache();
            if (isLive) {
                jLiveDataBasePollingThread = new Thread(new LiveDataBasePoller());
                jLiveDataBasePollingThread.start();

            }
            jStatusThread = new Thread(new StatusThread());
            jStatusThread.start();
            return true;
        }
        return false;
    }

    public GObjectItem getObjectItem(long id) {
        return jCache.getObjectItemByID("" + id);
    }

    public GObjectType getObjectType(long id) {
        return jCache.findGObjectType("" + id);
    }

    public AObjectItem getAObjectItem(long id) {
        return jCache.getAObjectItem(id);
    }

    public String getEntityName(long id) {
        GObjectItem goi = getObjectItem(id);
        if (goi != null) {
            return goi.getObjectItemNameText();
        }
        return null;
    }

    public boolean objectItemIsFriendly(long id) {
        AObjectItem aoi = getAObjectItem(id);
        if (aoi != null) {
            GObjectItemStatus stat = aoi.getObjectItemStatus();
            if (stat != null) {
                String hostility = stat.getObjectItemStatusHostilityCode();
                if (GObjectItemStatus.OBJECT_ITEM_STATUS_HOSTILITY_CODE_FR.equals(hostility)) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean objectItemIsHostile(long id) {
        AObjectItem aoi = getAObjectItem(id);
        if (aoi != null) {
            GObjectItemStatus stat = aoi.getObjectItemStatus();
            if (stat != null) {
                String hostility = stat.getObjectItemStatusHostilityCode();
                if (GObjectItemStatus.OBJECT_ITEM_STATUS_HOSTILITY_CODE_HO.equals(hostility)) {
                    return true;
                }
            }
        }
        return false;
    }

    public String getMilitarySymbol(long id) {
        if (jMilitarySymbolsHM.containsKey(id)) {
            return (jMilitarySymbolsHM.get(id));
        }
        return DEFAULT_CODE;
    }

    public ArrayList<AObjectItem> getEntities() {
        waitForCache();
        GetObjectItemsRequest oir = new GetObjectItemsRequest(
                true, true, true, false, false, false, false, false, true, false);
        oir = jCache.getObjectItemsRequest(oir);
        ArrayList<AObjectItem> ents = new ArrayList();
        ents.addAll(oir.getUnits());
        ents.addAll(oir.getMateriel());
        // no persons
        return ents;
    }

    public List<GContext> getVcciContextInfo() {
        return jCache.getContextInfo();
    }

    public List<AObjectItem> getVcciUnits(long timeStampMSec, GContext context) {
        Map<Long, GObjectItemPointLocation> pointLocations = loadPointLocationsByTime(timeStampMSec);
        if (pointLocations != null) {
            Map<Long, GObjectItem> unitObjItemsMap = jCache.getUnitObjItemsByContext(context);
            if (unitObjItemsMap != null) {
                synchronized (unitObjItemsMap) {
                    List<AObjectItem> units = new ArrayList<>();
                    for (Map.Entry<Long, GObjectItem> e : unitObjItemsMap.entrySet()) {
                        long objItemId = e.getKey();
                        GObjectItem objItem = e.getValue();
                        AObjectItem vcciUnit = createVcciUnit(objItemId, objItem, pointLocations, timeStampMSec);
                        if (vcciUnit != null) {
                            units.add(vcciUnit);
                        }
                    }
                    return units;
                }
            } else {
                System.err.println("Could not find vcci unit obj items for context: " + context.getContextNameText());
            }
        }

        return null;
    }

    private Map<Long, GObjectItemPointLocation> loadPointLocationsByTime(long timeStampMSec) {
        GetObjectItemPointLocationsByTimeTxn txn =
                new GetObjectItemPointLocationsByTimeTxn(jDBReader, timeStampMSec);
        if (txn.run()) {
            Map<Long, GObjectItemPointLocation> result = txn.getPointLocationHashResult();
            if (result == null) {
                System.err.println("Failed to load vcci point locations by time: " + timeStampMSec + " (msec). Null data received.");
            }
            return result;
        }

        System.err.println("Failed to load vcci point locations by time: " + timeStampMSec  + " (msec). Txn error.");
        return null;
    }

    private AObjectItem createVcciUnit(
            long objItemId,
            GObjectItem objItem,
            Map<Long, GObjectItemPointLocation> pointLocations,
            long timeStampMSec) {
        String objItemName = objItem.getObjectItemNameText();
        GObjectItemPointLocation location = pointLocations.get(objItemId);
        if (location != null) {
            GObjectItemDataCache cache = jCache.getOICache("" + objItemId);
            if (cache != null) {
                GObjectItemStatus status = getObjectItemStatusByTime(objItemId, objItemName, cache, timeStampMSec);
                AObjectItemType type = getObjectItemTypeByTime(objItemId, objItemName, cache, timeStampMSec);
                if (status != null && type != null) {
                    AObjectItem unit = new AObjectItem();
                    unit.setObjectItem(objItem);
                    unit.setObjectItemStatus(status);
                    unit.setAObjectItemType(type);
                    unit.setObjectItemPointLocation(location);
                    return unit;
                }
            } else {
                System.err.println("Failed to get GObjectItemDataCache for vcci unit with ID: " + objItemId + " & name: " + objItemName);
            }
        } else {
            System.err.println("Failed to get GObjectItemPointLocation for vcci unit with ID: " + objItemId + " & name: " + objItemName);
        }

        return null;
    }

    private GObjectItemStatus getObjectItemStatusByTime(
            long objItemId,
            String objItemName,
            GObjectItemDataCache cache,
            long timeStampMSec) {
        LinkedList<GObjectItemStatus> statuses = cache.getStatuses();
        synchronized (statuses) {
            if (!statuses.isEmpty()) {
                Iterator<GObjectItemStatus> statusIterator = statuses.descendingIterator();
                while (statusIterator.hasNext()) {
                    GObjectItemStatus status = statusIterator.next();
                    if (status.getObjectItemStatusTime() <= timeStampMSec) {
                        return status;
                    }
                }
            }
        }

        System.err.println("Failed to get GObjectItemStatus for vcci unit with ID: " + objItemId + " & name: " + objItemName);
        return null;
    }

    private AObjectItemType getObjectItemTypeByTime(
            long objItemId,
            String objItemName,
            GObjectItemDataCache cache,
            long timeStampMSec) {
        LinkedList<AObjectItemType> types = cache.getTypes();
        synchronized (types) {
            if (!types.isEmpty()) {
                Iterator<AObjectItemType> typeIterator = types.descendingIterator();
                while (typeIterator.hasNext()) {
                    AObjectItemType type = typeIterator.next();
                    if (type.getObjectItemType().getObjectItemTypeTime() <= timeStampMSec) {
                        return type;
                    }
                }
            }
        }

        System.err.println("Failed to get AObjectItemType for vcci unit with ID: " + objItemId + " & name: " + objItemName);
        return null;
    }

    public List<GMetContext> getMetContextInfo() {
        return jCache.jMetObjectDBCache.getMetContextInfo();
    }

    public List<AMetObjectItem> getMetUnits(long timeStampMSec, GMetContext context) {
        Map<Long, GMetObjectItemPointLocation> pointLocations = loadMetPointLocationsByTime(timeStampMSec);
        if (pointLocations != null) {
            Map<Long, GMetObjectItem> unitObjItemsMap = jCache.jMetObjectDBCache.getMetUnitObjItemsByContext(context);
            if (unitObjItemsMap != null) {
                synchronized (unitObjItemsMap) {
                    List<AMetObjectItem> units = new ArrayList<>();
                    for (Map.Entry<Long, GMetObjectItem> e : unitObjItemsMap.entrySet()) {
                        long objItemId = e.getKey();
                        GMetObjectItem objItem = e.getValue();
                        AMetObjectItem metUnit = createMetUnit(objItemId, objItem, pointLocations, timeStampMSec);
                        if (metUnit != null) {
                            units.add(metUnit);
                        }
                    }
                    return units;
                }
            } else {
                System.err.println("Could not find metric unit obj items for context: " + context.getMetContextNameText());
            }
        }

        return null;
    }

    private Map<Long, GMetObjectItemPointLocation> loadMetPointLocationsByTime(long timeStampMSec) {
        GetMetObjectItemPointLocationsByTimeTxn txn =
                new GetMetObjectItemPointLocationsByTimeTxn(jDBReader, timeStampMSec);
        if (txn.run()) {
            Map<Long, GMetObjectItemPointLocation> result = txn.getMetPointLocationHashResult();
            if (result == null) {
                System.err.println("Failed to load metric point locations by time: " + timeStampMSec + " (msec). Null data received.");
            }
            return result;
        }

        System.err.println("Failed to load metric point locations by time: " + timeStampMSec  + " (msec). Txn error.");
        return null;
    }

    private AMetObjectItem createMetUnit(
            long objItemId,
            GMetObjectItem objItem,
            Map<Long, GMetObjectItemPointLocation> pointLocations,
            long timeStampMSec) {
        String objItemName = objItem.getMetObjectItemNameText();
        GMetObjectItemPointLocation location = pointLocations.get(objItemId);
        if (location != null) {
            GMetObjectItemDataCache cache = jCache.jMetObjectDBCache.getMetOICache(objItemId);
            if (cache != null) {
                GMetObjectItemStatus status = getMetObjectItemStatusByTime(objItemId, objItemName, cache, timeStampMSec);
                AMetObjectItemType type = getMetObjectItemTypeByTime(objItemId, objItemName, cache, timeStampMSec);
                if (status != null && type != null) {
                    AMetObjectItem unit = new AMetObjectItem();
                    unit.setMetObjectItem(objItem);
                    unit.setMetObjectItemStatus(status);
                    unit.setAMetObjectItemType(type);
                    unit.setMetObjectItemPointLocation(location);
                    return unit;
                }
            } else {
                System.err.println("Failed to get GMetObjectItemDataCache for metric unit with ID: " + objItemId + " & name: " + objItemName);
            }
        } else {
            System.err.println("Failed to get GMetObjectItemPointLocation for metric unit with ID: " + objItemId + " & name: " + objItemName);
        }

        return null;
    }

    private GMetObjectItemStatus getMetObjectItemStatusByTime(
            long objItemId,
            String objItemName,
            GMetObjectItemDataCache cache,
            long timeStampMSec) {
        LinkedList<GMetObjectItemStatus> statuses = cache.getStatuses();
        synchronized (statuses) {
            if (!statuses.isEmpty()) {
                Iterator<GMetObjectItemStatus> statusIterator = statuses.descendingIterator();
                while (statusIterator.hasNext()) {
                    GMetObjectItemStatus status = statusIterator.next();
                    if (status.getMetObjectItemStatusTime() <= timeStampMSec) {
                        return status;
                    }
                }
            }
        }

        System.err.println("Failed to get GMetObjectItemStatus for metric unit with ID: " + objItemId + " & name: " + objItemName);
        return null;
    }

    private AMetObjectItemType getMetObjectItemTypeByTime(
            long objItemId,
            String objItemName,
            GMetObjectItemDataCache cache,
            long timeStampMSec) {
        LinkedList<AMetObjectItemType> types = cache.getTypes();
        synchronized (types) {
            if (!types.isEmpty()) {
                Iterator<AMetObjectItemType> typeIterator = types.descendingIterator();
                while (typeIterator.hasNext()) {
                    AMetObjectItemType type = typeIterator.next();
                    if (type.getMetObjectItemType().getMetObjectItemTypeTime() <= timeStampMSec) {
                        return type;
                    }
                }
            }
        }

        System.err.println("Failed to get AMetObjectItemType for metric unit with ID: " + objItemId + " & name: " + objItemName);
        return null;
    }

    public ArrayList<GEntityWatchMetricsSpecification> getEntityWatchSpecs() {
        ArrayList<GEntityWatchMetricsSpecification> out = new ArrayList<>();
        try {
            GetEntityWatchMetricsSpecificationSimpleTxn txn
                    = new GetEntityWatchMetricsSpecificationSimpleTxn(jDBReader);
            if (!txn.loadGEntityWatchMetricsSpecificationObjects()) {
                return out; // empty on failure (consistent with other getters)
            }
            @SuppressWarnings("unchecked")
            java.util.LinkedList<Object> rows = txn.getLinkedList();
            for (Object o : rows) {
                if (o instanceof GEntityWatchMetricsSpecification) {
                    out.add((GEntityWatchMetricsSpecification) o);
                }
            }
        } catch (Exception ignore) {
            // keep behavior consistent with other getters (no throw; return empty)
        }
        return out;
    }

    /**
     * Returns filtered Entity Watch metrics results.
     */
    public ArrayList<GEntityWatchMetricsResults> getEntityWatchMetricsResults() {
        GetEntityWatchMetricsResultsSimpleTxn txn
                = new GetEntityWatchMetricsResultsSimpleTxn(jDBReader);

        if (!txn.loadGEntityWatchMetricsResultsObjects()) {
            return new ArrayList<>();
        }

        @SuppressWarnings("unchecked")
        LinkedList<GEntityWatchMetricsResults> objs = txn.getLinkedList();
        return new ArrayList<>(objs);
    }

    public GCombatPowerMetricsResults findCombatPowerById(long metricsResultId) {
        for (GCombatPowerMetricsResults r : getCombatPowerMetricsResults()) {
            if (r.getCombatPowerMetricsResultsCombatPowerMetricsResultId() == metricsResultId) {
                return r;
            }
        }
        return null;
    }

    /**
     * Look through all cached holdings (all times, all entities) and return the
     * GHolding that matches a given holdingId (metrics_result_id).
     */
    public GHolding findHoldingById(long holdingId) {
        Map<Long, Map<Long, List<GHolding>>> all = getAllHoldingsFromCache();
        if (all != null) {
            for (Map<Long, List<GHolding>> entityMap : all.values()) {
                for (List<GHolding> holdings : entityMap.values()) {
                    for (GHolding h : holdings) {
                        if (h.getHoldingIndex() == holdingId) {
                            return h;
                        }
                    }
                }
            }
        }
        return null;
    }


    public String findItemTypeById(long typeId) {
        String typeIdString = Long.toString(typeId);
        Set<String> typeIds = jCache.getAllObjectTypeIds();
        LinkedList<GObjectType> types = jCache.getAllObjectTypes();
        String match = null;
        long matchIndex = 0;
        for(String tId : typeIds){
            if(typeIdString.equals(tId)){
                match = tId;
                break;
            }
            matchIndex++;
        }
        if(match != null) {
            return types.get((int)matchIndex).getObjectTypeNameText();
        }
        return null;
    }


    /**
     * Find a single Enemy Engagement result by metricsResultId.
     */
    public GEnemyEngagementMetricsResults findEnemyEngagementById(long metricsResultId) {
        for (GEnemyEngagementMetricsResults r : getEnemyEngagementMetricsResults()) {
            if (r.getEnemyEngagementMetricsResultsEnemyEngagementMetricsResultId() == metricsResultId) {
                return r;
            }
        }
        return null;
    }

    /**
     * Returns all Enemy Engagement metrics results (unfiltered).
     */
    public ArrayList<GEnemyEngagementMetricsResults> getAllEnemyEngagementMetricsResults() {
        ArrayList<GEnemyEngagementMetricsResults> list = new ArrayList<>();
        ArrayList<GEnemyEngagementMetricsResults> raws = getEnemyEngagementMetricsResults();
        if (raws != null) {
            list.addAll(raws);
        }
        return list;
    }


    public GFratricideMetricsResults findFratricideById(long metricsResultId) {
        for (GFratricideMetricsResults r : getFratricideMetricsResults()) {
            if (r.getFratricideMetricsResultsFratricideMetricsResultId() == metricsResultId) {
                return r;
            }
        }
        return null;
    }

    /**
     * Returns all Action records (unfiltered).
     */
    public ArrayList<GAction> getAllActions() {
        GetActionSimpleTxn txn = new GetActionSimpleTxn(jDBReader);
        if (!txn.loadGActionObjects()) {
            return new ArrayList<>();
        }
        LinkedList<GAction> objs = txn.getLinkedList();
        return new ArrayList<>(objs);
    }

    /**
     * Find a single Action by its id (assoc_obj_id from EntityWatch).
     */
    public GAction findActionById(long actionId) {
        for (GAction a : getAllActions()) { // implement getAllActions() like other getters
            if (a.getActionId() == actionId) {
                return a;
            }
        }
        return null;
    }

    /**
     * Returns all HHour metrics results (unfiltered).
     */
    public ArrayList<GHhourMetricsResults> getAllHHourMetricsResults() {
        GetHhourMetricsResultsSimpleTxn txn = new GetHhourMetricsResultsSimpleTxn(jDBReader);
        if (!txn.loadGHhourMetricsResultsObjects()) {
            return new ArrayList<>();
        }
        LinkedList<GHhourMetricsResults> objs = txn.getLinkedList();
        return new ArrayList<>(objs);
    }

    /**
     * Find a single HHour result by metricsResultId.
     */
    public GHhourMetricsResults findHHourById(long metricsResultId) {
        for (GHhourMetricsResults r : getAllHHourMetricsResults()) {
            if (r.getHhourMetricsResultsHhourMetricsResultId() == metricsResultId) {
                return r;
            }
        }
        return null;
    }

    public long getHHourTime(long hhourid) {
        ArrayList<Object> specs = getHHourSpecs(null);
        if (specs == null) {
            return -1;
        }

        UIOHHourMetricsSpecification spec;
        for (Object o : specs) {
            spec = (UIOHHourMetricsSpecification) o;

            if (spec.getOMDBSpec().getHhourMetricsSpecificationId() == hhourid) {
                return (spec.getOMDBSpec().getHhourMetricsSpecificationTime());
            }
        }
        return -1;
    }

    /**
     * Gets the HHour results for given hhourid specification and the passed
     * threshold (which could be less than the threshold specified in the actual
     * specification) - we just recalculate here for the passed threshold.If
     * passed threshold == -1, we just use the threshold from the specification
     *
     * @param hhourid
     * @param timeFormat
     * @return
     */
    public ArrayList<Object> getHHourMetricsResults(
            long hhourid,
            String timeFormat) {
        ArrayList<Object> specs = getHHourSpecs(timeFormat);
        if (specs == null) {
            return new ArrayList<>();
        }

        GetHhourMetricsResultsSimpleTxn txn = new GetHhourMetricsResultsSimpleTxn(jDBReader);
        if (!txn.loadGHhourMetricsResultsObjects()) {
            return null;
        }

        ArrayList<Object> results = new ArrayList<>();
        for (GHhourMetricsResults hhRes : (LinkedList<GHhourMetricsResults>) txn.getLinkedList()) {
            if (hhRes.getHhourMetricsResultsHhourMetricsSpecificationIndex() == hhourid) {
                UIOHHourMetricsResult uioRes = new UIOHHourMetricsResult(hhRes);
                DMetricsTimeFormats fmt = getTimeFormat(timeFormat);
                uioRes.setFormattedTime(
                        MIDASUtils.applyTimeFormat(
                                fmt, hhRes.getMetricsResultsTime()));
                if (jSimulationStartTime != DBConstants.INVALID_ID) {
                    uioRes.setTime(jSimulationStartTime + uioRes.getTime());
                }
                results.add(uioRes);
            }
        }
        return new ArrayList<>(results);
    }

    /**
     * Gets the HHour results for given hhourid specification and the threshold
     * in the spec. We check how many entities in total made the crossing
     * according to the threshold in the spec and then calculate which ones
     * would not if the threshold was equal to the passed thresholdSetting
     *
     * @param hhourid
     * @param thresholdSetting
     * @param unitIds
     * @return hhour percentage
     */
    public double getHHourPercentage(
            long hhourid,
            long thresholdSetting,
            List<Long> unitIds) {
        if (unitIds.isEmpty()) {
            return 0;
        }

        ArrayList<Object> specs = getHHourSpecs(null);
        if (specs == null) {
            return 0.0;
        }

        // Get time information of requested hhour
        long hhourTime = -1;
        UIOHHourMetricsSpecification spec;
        for (Object o : specs) {
            spec = (UIOHHourMetricsSpecification) o;
            if (spec.getOMDBSpec().getHhourMetricsSpecificationId() == hhourid) {
                hhourTime = spec.getOMDBSpec().getHhourMetricsSpecificationTime();
                break;
            }
        }

        GetHhourMetricsResultsSimpleTxn txn = new GetHhourMetricsResultsSimpleTxn(jDBReader);
        if (!txn.loadGHhourMetricsResultsObjects()) {
            return 0.0;
        }

        thresholdSetting *= (60 * 1000);
        long resultTime, diff;
        double totalThresholdCrossings = 0;

        for (Object o : txn.getLinkedList()) {
            GHhourMetricsResults hhRes = (GHhourMetricsResults) o;
            if (hhRes.getHhourMetricsResultsHhourMetricsSpecificationIndex() == hhourid) {
                if (unitIds.contains(hhRes.getMetricsResultsObjectItemId())) {
                    // Get result time
                    resultTime = hhRes.getMetricsResultsTime();
                    diff = Math.abs(resultTime - hhourTime);
                    // Keep track of total crossings according to the threshold on
                    // the spec
                    if (diff <= thresholdSetting) {
                        // And track based on user threshold setting
                        totalThresholdCrossings += 1;
                    }
                }
            }
        }

        return (double) (100 * (totalThresholdCrossings / unitIds.size()));
    }

    public ArrayList<Object> getHHourSpecs(String timeFormat) {
        GetHhourMetricsSpecificationSimpleTxn txn = new GetHhourMetricsSpecificationSimpleTxn(jDBReader);
        if (!txn.loadGHhourMetricsSpecificationObjects()) {
            return null;
        }
        ArrayList<UIOHHourMetricsSpecification> results = new ArrayList<>();
        for (GHhourMetricsSpecification spec : (List<GHhourMetricsSpecification>) txn.getLinkedList()) {
            UIOHHourMetricsSpecification specUIO = new UIOHHourMetricsSpecification(spec);
            specUIO.setFormattedTime(
                    MIDASUtils.applyTimeFormat(
                            getTimeFormat(timeFormat),
                            spec.getHhourMetricsSpecificationTime()));
            results.add(specUIO);
        }

        return new ArrayList<>(results);
    }

    public ArrayList<Object> getROMSpecs(String timeFormat) {
        GetRatesOfMovementMetricsSpecificationSimpleTxn txn = new GetRatesOfMovementMetricsSpecificationSimpleTxn(jDBReader);
        if (!txn.loadGRatesOfMovementMetricsSpecificationObjects()) {
            return null;
        }
        GRatesOfMovementMetricsSpecification spec;
        UIOROMMetricsSpecification uioSpec;

        ArrayList<UIOROMMetricsSpecification> results = new ArrayList();
        for (Object obj : txn.getLinkedList()) {
            spec = (GRatesOfMovementMetricsSpecification) obj;
            uioSpec = new UIOROMMetricsSpecification(spec);
            DMetricsTimeFormats fmt = getTimeFormat(timeFormat);
            uioSpec.setFormattedTime(
                    MIDASUtils.applyTimeFormat(
                            fmt,
                            spec.getRatesOfMovementMetricsSpecificationStartTime()));
            uioSpec.setFormattedEndTime(
                    MIDASUtils.applyTimeFormat(
                            fmt,
                            spec.getRatesOfMovementMetricsSpecificationEndTime()));
            results.add(uioSpec);
        }

        return new ArrayList(results);
    }

    /**
     * Returns
     *
     * @param romSpecId
     * @return ArrayList<GRatesOfMovementMetricsResults>
     */
    public ArrayList<Object> getRatesOfMovementsMetricsResults(long romSpecId) {
        GetRatesOfMovementMetricsResultsSimpleTxn txn = new GetRatesOfMovementMetricsResultsSimpleTxn(jDBReader);
        if (!txn.loadGRatesOfMovementMetricsResultsObjects()) {
            return null;
        }
        LinkedList<Object> objs = txn.getLinkedList();
        GRatesOfMovementMetricsResults romRes;
        ArrayList<Object> results = new ArrayList();
        for (Object o : objs) {
            romRes = (GRatesOfMovementMetricsResults) o;
            // Make sure that this rate of movement was calculated for the passed spec
            if (romRes.getRatesOfMovementMetricsResultsRatesOfMovementMetricsSpecificationIndex() == romSpecId) {
                // Now make sure that we only return those results that fall within
                // this threshold
                results.add(o);
            }
        }
        return new ArrayList(results);
    }

    /**
     * @param romSpecId
     * @param selectedIds
     * @param timeFormat
     * @return ArrayList<ROMResultPoint>
     */
    public ArrayList<Object> getRatesOfMovementsMetricsResults(
            long romSpecId,
            List<Long> selectedIds,
            String timeFormat,
            long startTime,
            long endTime) {
        GetRatesOfMovementMetricsResultsSimpleTxn txn =
                new GetRatesOfMovementMetricsResultsSimpleTxn(jDBReader);
        if (!txn.loadGRatesOfMovementMetricsResultsObjects()) {
            return null;
        }
        // Convert entities to hash for quick lookup
        Set<Long> uniqueIds = new HashSet<>(selectedIds);

        // Organize results by exact time since we need to take the average distance
        // and speed at those times
        HashMap<Long, ArrayList<GRatesOfMovementMetricsResults>> timeHash = new HashMap<>();
        ArrayList<GRatesOfMovementMetricsResults> sameTimeResults;
        for (Object o : txn.getLinkedList()) {
            GRatesOfMovementMetricsResults romRes = (GRatesOfMovementMetricsResults) o;
            // Make sure that this rate of movement was calculated for the passed spec
            if (romRes.getRatesOfMovementMetricsResultsRatesOfMovementMetricsSpecificationIndex() == romSpecId) {
                long entId = romRes.getMetricsResultsObjectItemId();
                if (uniqueIds.contains(entId)) {
                    // Get time
                    long t = romRes.getMetricsResultsTime();
                    if (t >= startTime && t <= endTime) {
                        if (timeHash.containsKey(t)) {
                            sameTimeResults = timeHash.get(t);
                        } else {
                            sameTimeResults = new ArrayList<>();
                            timeHash.put(t, sameTimeResults);
                        }
                        sameTimeResults.add(romRes);
                    }
                }
            }
        }

        // Now run the average calculations and build results
        ArrayList<Object> results = new ArrayList();
        double avgSpeed;
        double avgCumul;
        double speed;
        int numRecs;
        for (Long t : timeHash.keySet()) {
            sameTimeResults = timeHash.get(t);
            numRecs = sameTimeResults.size();
            if (numRecs > 0) {
                avgSpeed = 0;
                avgCumul = 0;
                for (GRatesOfMovementMetricsResults r : sameTimeResults) {
                    // Speed here is km/h
                    speed = r.getRatesOfMovementMetricsResultsSpeedRate();
                    avgSpeed += speed;

                    avgCumul += r.getRatesOfMovementMetricsResultsCumulativeDistance();
                }
                avgSpeed /= numRecs;
                avgCumul /= numRecs;
                UIOROMResultPoint p = new UIOROMResultPoint(numRecs, t, avgSpeed, avgCumul);
                // Apply time format
                DMetricsTimeFormats fmt = getTimeFormat(timeFormat);
                p.setFormattedTime(MIDASUtils.applyTimeFormat(fmt, t));

                // Now apply simulation start time to the offset so that the
                // resulting time is reasonalbe
                if (jSimulationStartTime != DBConstants.INVALID_ID) {
                    p.setTime(jSimulationStartTime + p.getTime());
                }
                results.add(p);
            }
        }

        return new ArrayList(results);
    }

    /**
     * Returns
     *
     * @param romSpecId
     * @return percentage
     */
    public UIOROMStats getRatesOfMovementsStats(
            long romSpecId,
            long startTime,
            long endTime,
            List<Long> unitIds) {
        UIOROMStats uio = new UIOROMStats();
        GetRatesOfMovementMetricsResultsSimpleTxn txn =
                new GetRatesOfMovementMetricsResultsSimpleTxn(jDBReader);
        if (txn.loadGRatesOfMovementMetricsResultsObjects()) {

            HashMap<Long, List<Double>> entitySpeedsMap = new HashMap<>();
            HashSet<Long> nonZeroSpeedEnts = new HashSet<>();
            HashSet<Long> uniqueEnts = new HashSet<>();

            for (Object o : txn.getLinkedList()) {
                GRatesOfMovementMetricsResults romRes = (GRatesOfMovementMetricsResults) o;
                if (romRes.getRatesOfMovementMetricsResultsRatesOfMovementMetricsSpecificationIndex() == romSpecId) {
                    long time = romRes.getMetricsResultsTime();
                    if (time > startTime && time < endTime) {
                        long objItemId = romRes.getMetricsResultsObjectItemId();
                        if (unitIds.contains(objItemId)) {
                            uniqueEnts.add(objItemId);
                            double speed = romRes.getRatesOfMovementMetricsResultsSpeedRate();
                            if (speed > 0) {
                                nonZeroSpeedEnts.add(objItemId);
                            }

                            List<Double> entitySpeeds = entitySpeedsMap.computeIfAbsent(
                                    objItemId, k -> new ArrayList<>());
                            entitySpeeds.add(speed);
                        }
                    }
                }
            }

            double totalCount = uniqueEnts.size();
            if (totalCount > 0) {
                double staticCount = totalCount - nonZeroSpeedEnts.size();
                uio.setStaticEntityPercentage(staticCount * 100 / totalCount);

                double totalAverageSpeed = 0.0;
                double minEntityAverageSpeed = Double.MAX_VALUE;
                double maxEntityAverageSpeed = Double.MIN_VALUE;
                for (List<Double> speedValues : entitySpeedsMap.values()) {
                    double entityAverageSpeed = calculateEntityAverageSpeed(speedValues);
                    if (entityAverageSpeed < minEntityAverageSpeed) {
                        minEntityAverageSpeed = entityAverageSpeed;
                    }

                    if (entityAverageSpeed > maxEntityAverageSpeed) {
                        maxEntityAverageSpeed = entityAverageSpeed;
                    }
                    totalAverageSpeed += entityAverageSpeed;
                }
                uio.setAverage(totalAverageSpeed / entitySpeedsMap.size());
                uio.setMin(minEntityAverageSpeed);
                uio.setMax(maxEntityAverageSpeed);
            }
        }

        return uio;
    }

    private double calculateEntityAverageSpeed(List<Double> speedValues) {
        double speedSum = 0;
        for (double speed : speedValues) {
            speedSum += speed;
        }
        return speedSum / speedValues.size();
    }

    /**
     * Returns
     *
     * @return ArrayList<GControlMeasureOccupationMetricsResults>
     */
    public ArrayList<Object> getCMOccupationMetricsResults() {
        GetControlMeasureOccupationMetricsResultsSimpleTxn txn
                = new GetControlMeasureOccupationMetricsResultsSimpleTxn(jDBReader);
        if (!txn.loadGControlMeasureOccupationMetricsResultsObjects()) {
            return null;
        }
        LinkedList<Object> objs = txn.getLinkedList();
        return new ArrayList(objs);
    }

    /**
     * Returns
     *
     * @return ArrayList<GPictureOfEnemyMetricsResults>
     */
    public ArrayList<Object> getPOEMetricsResults() {
        GetPictureOfEnemyMetricsResultsSimpleTxn txn
                = new GetPictureOfEnemyMetricsResultsSimpleTxn(jDBReader);
        if (!txn.loadGPictureOfEnemyMetricsResultsObjects()) {
            return null;
        }
        LinkedList<GPictureOfEnemyMetricsResults> objs = txn.getLinkedList();
        return new ArrayList(objs);
    }

    /**
     * Returns
     *
     * @return ArrayList<GFratricideMetricsResults>
     */
    public ArrayList<GFratricideMetricsResults> getFratricideMetricsResults() {
        GetFratricideMetricsResultsSimpleTxn txn
                = new GetFratricideMetricsResultsSimpleTxn(jDBReader);
        if (!txn.loadGFratricideMetricsResultsObjects()) {
            return null;
        }
        LinkedList<GFratricideMetricsResults> objs = txn.getLinkedList();
        return new ArrayList(objs);
    }

    /**
     * Returns
     *
     * @return ArrayList<GCombatPowerMetricsResults>
     */
    public ArrayList<GCombatPowerMetricsResults> getCombatPowerMetricsResults() {
        GetCombatPowerMetricsResultsSimpleTxn txn
                = new GetCombatPowerMetricsResultsSimpleTxn(jDBReader);
        if (!txn.loadGCombatPowerMetricsResultsObjects()) {
            return null;
        }
        LinkedList<GCombatPowerMetricsResults> objs = txn.getLinkedList();
        return new ArrayList(objs);
    }

    /**
     * Returns
     *
     * @return ArrayList<EnemyEngagementMetricsResults>
     */
    public ArrayList<GEnemyEngagementMetricsResults> getEnemyEngagementMetricsResults() {
        GetEnemyEngagementMetricsResultsSimpleTxn txn
                = new GetEnemyEngagementMetricsResultsSimpleTxn(jDBReader);
        if (!txn.loadGEnemyEngagementMetricsResultsObjects()) {
            return null;
        }
        LinkedList<GPictureOfEnemyMetricsResults> objs = txn.getLinkedList();
        return new ArrayList(objs);
    }

    public ArrayList<GCombatPowerMetricsResults> getCombatPowerMetricsResults(long objectItemId) {
        return jDBReader.getCombatPowerResultsByObjectItemId(objectItemId);
    }

    public ArrayList<GCombatPowerMetricsSpecification> getCombatPowerMetricsSpecs(long objectItemId) {
        return jDBReader.getCombatPowerSpecificationsByObjectItemId(objectItemId);
    }

    public LinkedList<DObjectItemAssociation> getOrgOrgAssociations() {
        GetObjectItemAssociationsRequest req
                = new GetObjectItemAssociationsRequest(true, false, false);

        req = jDBReader.getObjectItemAssociationsRequest(req, jCache);
        return (req.jOIOrgAssocs);
    }

    /**
     * @param objectItemId
     * @param time
     * @return
     */
    public ArrayList<GHolding> getHoldings(
            long objectItemId,
            long time) {

        HashMap<Long, GHolding> closestByTypeId = new HashMap();
        GetHoldingsRequest req = new GetHoldingsRequest(objectItemId);
        req = jDBReader.getHoldingsRequest(req);
        long holdingTime;
        long objTypeId;
        GHolding check;

        LinkedList<GHolding> allHoldings = req.getResults();

        for (GHolding h : allHoldings) {
            holdingTime = h.getHoldingSimulationOffsetTime();
            objTypeId = h.getHoldingObjectTypeId();

            if (closestByTypeId.containsKey(objTypeId)) {
                check = closestByTypeId.get(objTypeId);

                // If the new time is closer but not after our target, 
                // replace existing record
                if ((holdingTime > check.getHoldingSimulationOffsetTime())
                        && (holdingTime <= time)) {
                    // Replace record by closer record
                    closestByTypeId.put(objTypeId, h);
                }

            } else {
                closestByTypeId.put(objTypeId, h);
            }
        }
        // At this point the hashmap will have all the holdings for this
        // entity right at or before the time requested
        return (new ArrayList(closestByTypeId.values()));
    }

    public HashMap<Long, ArrayList<GHolding>> getHoldings(
            ArrayList<Long> objItemIds,
            long time) {

        // First key is object item id
        HashMap<Long, HashMap<Long, GHolding>> entityHMs = new HashMap();
        HashMap<Long, GHolding> closestByTypeId = null;
        GetHoldingsRequest req = new GetHoldingsRequest(new LinkedList(objItemIds));
        req = jDBReader.getHoldingsRequest(req);
        long holdingTime;
        long objTypeId;
        GHolding check;
        long objItemId;
        HashMap<Long, ArrayList<GHolding>> results = new HashMap();

        LinkedList<GHolding> allHoldings = req.getResults();

        for (GHolding h : allHoldings) {
            holdingTime = h.getHoldingSimulationOffsetTime();
            objTypeId = h.getHoldingObjectTypeId();
            objItemId = h.getHoldingObjectItemId();

            // Find list for this item
            if (entityHMs.containsKey(objItemId)) {
                closestByTypeId = entityHMs.get(objItemId);
            } else {
                closestByTypeId = new HashMap();
                entityHMs.put(objItemId, closestByTypeId);
            }
            if (closestByTypeId.containsKey(objTypeId)) {
                check = closestByTypeId.get(objTypeId);

                // If the new time is closer but not after our target, 
                // replace existing record
                if ((holdingTime > check.getHoldingSimulationOffsetTime())
                        && (holdingTime <= time)) {
                    // Replace record by closer record
                    closestByTypeId.put(objTypeId, h);
                }

            } else {
                closestByTypeId.put(objTypeId, h);
            }
        }
        // At this point the hashmap will have all the holdings for these
        // entities right at or before the time requested 
        for (long id : entityHMs.keySet()) {
            closestByTypeId = entityHMs.get(id);
            results.put(id, new ArrayList(closestByTypeId.values()));
        }
        return results;
    }

    /**
     * Wrapper class for holding latest and previous GHolding entries.
     */
    public static class HoldingWithPrevious {

        public GHolding jLatest;
        public GHolding jPrevious;

        public HoldingWithPrevious(GHolding latest, GHolding previous) {
            this.jLatest = latest;
            this.jPrevious = previous;
        }
    }

    public Map<Long, HoldingWithPrevious> getHoldingsWithPreviousFromCache(long unitId, long simTime) {
        return jCache.getHoldingsWithPreviousFromCache(unitId, simTime);
    }

    public List<GHolding> getCachedLatestHoldings(long unitId, long simTime) {
        return jCache.getLatestHoldingsFromCache(unitId, simTime);
    }

    /**
     * In-memory equivalent of getHoldings(list, time): returns, for each unit
     * in the list, its latest GHolding records up to simTime.
     */
    public HashMap<Long, List<GHolding>> getCachedLatestHoldings(
            List<Long> unitIds,
            long simTime) {
        HashMap<Long, List<GHolding>> result = new HashMap<>();
        for (Long id : unitIds) {
            result.put(id, jCache.getLatestHoldingsFromCache(id, simTime));
        }
        return result;
    }

    public Map<Long, Map<Long, List<GHolding>>> getAllHoldingsFromCache() {

        return jCache.jHoldingsCache;
    }

    public List<MDVTRecord> getMDVTRecords(){
        return jCache.jMDVTRecords;
    }

    /**
     * @return : returns a map(orgId) -> map(holdingId, holdingDelta) - this
     * provides for each organization, the delta either added or subtracted by
     * the holding change due to a RESUPPLY event
     */
    public HashMap<Long, Map<Long, Double>> generateResupplyEvents() {
        // Get all RESUPPLY action events
        // Note reporting org and simulation time
        // Get all holdings for each reporting org
        // Find holdings change at same time as RESUPPLY event
        // Check if it is RESUPPLY TO representing an addition or
        //    RESUPPLY FROM representing a subtraction
        // For each org, generate a list of holding ids along with if it
        // was a plus or minus representing each RESUPPLY

        // First get resupply events
        GetActionSimpleTxn txn = new GetActionSimpleTxn(jDBReader);
        if (!txn.loadGActionObjects()) {
            return new HashMap();
        }

        LinkedList actions = txn.getLinkedList();
        // Keep track of resupply events by reporting org
        HashMap<Long, ArrayList<GAction>> resupplies = new HashMap();
        GAction a;
        String action;
        Long k;
        for (Object o : actions) {
            a = (GAction) o;
            action = a.getActionNameText();
            if (action.contains(RESUPPLY)) {
                k = a.getActionReportingOrganisationId();
                if (k > 0) {
                    resupplies.computeIfAbsent(k, key -> new ArrayList<>()).add(a);
                }
            }
        }

        // Next step - align resupply events with holdings records
        // Return orgid -> map <holding id, holdingDelta> : so for this organization,
        // for these holdings it was either resupply from (-) or resupply to (+)
        HashMap<Long, Map<Long, Double>> resupplyPoints = new HashMap();

        ArrayList<GAction> resupplyEvents;
        for (Long orgId : resupplies.keySet()) {
            // Get resupply events
            resupplyEvents = resupplies.get(orgId);

            for (GAction event : resupplyEvents) {
                long resupplyTime = event.getActionSimulationOffsetTime();

                // Get holdings at this time plus the previous one - the
                // return is by holding type
                Map<Long, HoldingWithPrevious> holdingInfo = jCache.getHoldingsWithPreviousFromCache(orgId, resupplyTime);

                // Set data to show that for a specific unit (orgId), whether
                // a holding as a result of a RESUPPLY is an addition or
                // subtraction. Set the delta by looking at the same previous
                // holding type value.
                for (Long holdingType : holdingInfo.keySet()) {
                    HoldingWithPrevious hwp = holdingInfo.get(holdingType);
                    GHolding resupplyTimeHolding = hwp.jLatest;
                    // Get this same holding from the previous time
                    GHolding previousHolding = hwp.jPrevious;

                    if (resupplyTimeHolding != null && previousHolding != null) {
                        long holdingTime = resupplyTimeHolding.getHoldingSimulationOffsetTime();

                        // Make sure we are very close to the resupply time
                        if (Math.abs(holdingTime - resupplyTime) <= ACCEPTABLE_RESUPPLY_DELTA_MILLISECS) {
                            // RESUPPLY (TO) would mean positive
                            // RESUPPLY (FROM) would be negative
                            double delta = resupplyTimeHolding.getHoldingOperationalCount()
                                    - previousHolding.getHoldingOperationalCount();
                            resupplyPoints.computeIfAbsent(orgId, k2 -> new HashMap<>())
                                    .put(resupplyTimeHolding.getHoldingIndex(), delta);
                        }
                    }
                }
            }
        }
        return resupplyPoints;
    }

    public ArrayList<Object> getControlFeatureLocation(long id) {
        waitForCache();
        ArrayList<Object> lodGeoList = new ArrayList();
        GetObjectItemsRequest oir = new GetObjectItemsRequest(
                false, false, false, true, false, false, false, false, false, true);
        oir.setTargetId(id);
        oir = jCache.getObjectItemsRequest(oir);
        LinkedList<AObjectItem> objs = oir.getControlFeatures();
        if (!objs.isEmpty()) {
            AObjectItem aoi = objs.getFirst();
            AObjectItemLocation aoil = aoi.getObjectItemLocation();
            if (aoil != null) {
                GLocation lodLoc = aoil.getLocation();
                if (lodLoc != null) {
                    if (lodLoc instanceof DLine) {
                        DLine dl = (DLine) lodLoc;
                        LinkedList<DLinePoint> lpts = dl.getLinePoints();
                        UIOBase o;
                        for (int i = 0; i < lpts.size(); i++) {
                            o = new UIOBase();
                            o.setLat(lpts.get(i).getGGeographicPoint().getGeographicPointLatitudeCoordinate());
                            o.setLon(lpts.get(i).getGGeographicPoint().getGeographicPointLongitudeCoordinate());
                            lodGeoList.add(o);
                        }
                    }
                }
            }
        }
        return lodGeoList;
    }

    public DMetricsTimeFormats getTimeFormat(String formatName) {
        if (jTimeFormatCache.containsKey(formatName)) {
            return jTimeFormatCache.get(formatName);
        }
        return null;
    }

    public ArrayList<UIOBase> getTimeFormats() {
        // Formats are loaded during database init
        ArrayList<UIOBase> res = new ArrayList();
        UIOBase o;
        for (DMetricsTimeFormats f : jTimeFormatCache.values()) {
            o = new UIOBase();
            o.setName(f.getMetricsTimeFormatsFormatName());
            o.setId(f.getMetricsTimeFormatsMetricsTimeFormatId());
            res.add(o);
            // Set IVs
            f.parseFormat();
        }
        return res;
    }

    public UIOMinMaxTime getMinMaxTime(String formatName) {
        UIOMinMaxTime uio = new UIOMinMaxTime();
        GetTimeRequest req = new GetTimeRequest(true, true, null);
        req.setUseSimTime(true);
        req = jDBReader.getTimeRequest(req);
        uio.setMinTime(req.getEarliestDate());
        uio.setMaxTime(req.getLatestDate());
        jLatestTime = req.getLatestDate();
        String formattedEarliest = MIDASUtils.applyTimeFormat(
                getTimeFormat(formatName),
                req.getEarliestDate());
        String formattedLatest = MIDASUtils.applyTimeFormat(
                getTimeFormat(formatName),
                req.getLatestDate());
        uio.setFormattedMinTime(formattedEarliest);
        uio.setFormattedMaxTime(formattedLatest);
        return uio;
    }

    private class DBCacheInit implements Runnable {

        @Override
        public void run() {
            try {
                long t1 = System.currentTimeMillis();

                // Get earliest/latest times in database
                GetTimeRequest gtr = new GetTimeRequest(true, true, null);
                gtr.setUseSimTime(true);
                gtr = jDBReader.getTimeRequest(gtr);

                if (gtr.isSuccessful()) {
                    jEarliestTime = gtr.jEarliestDate;
                    jLatestTime = gtr.jLatestDate;
                } else {
                    Logger.getLogger(DBManager.class.getName())
                            .log(Level.INFO, null, "Unable to get database earliest time!");
                }
                System.err.println("Initializing cache ...");
                jCache = new MIDASDBCache();
                jCache.initialize();

                // Add null check before generating symbols
                if (jCache != null) {
                    jCache.generateMilitarySymbols();
                    jCache.checkUpdateControlFeatures();
                } else {
                    System.out.println("Cache is null — aborting military symbol generation.");
                    return; // Optionally stop execution if cache init failed
                }

                // Get metrics formats
                if (!loadMetricsTimeFormats()) {
                    Logger.getLogger(DBManager.class.getName())
                            .log(Level.INFO, null, "Unable to load metrics time formats!");
                }

                // Get simulation start time
                GetSimulationStartTimeRequest req = new GetSimulationStartTimeRequest();
                GetSimulationStartTimeTxn checkTxn = new GetSimulationStartTimeTxn((OMConn) jDBReader, req);
                if (!checkTxn.run()) {
                    Logger.getLogger(DBManager.class.getName())
                            .log(Level.INFO, null, "Unable to read simulation start time : defaulting to current!");
                }
                jSimulationStartTime = req.getSimulationStartTime();

                System.err.println("Finished initializing cache ... time:"
                        + (System.currentTimeMillis() - t1));
                jCacheReady = true;

            } catch (Exception ex) {
                // Silently ignore - should only happen if we interrupt
                Logger.getLogger(DBManager.class.getName()).log(Level.INFO, null, ex);
            }
        }

        private boolean loadMetricsTimeFormats() {
            GetMetricsTimeFormatsRequest req = new GetMetricsTimeFormatsRequest();
            req = jDBReader.getMetricsTimeFormatsRequest(req);
            if (!req.isSuccessful()) {
                return false;
            }
            ArrayList<DMetricsTimeFormats> fmts = req.getFormats();
            for (DMetricsTimeFormats f : fmts) {
                // Set IVs
                f.parseFormat();
                jTimeFormatCache.put(f.getMetricsTimeFormatsFormatName(), f);
            }
            return true;
        }
    }

    private class LiveDataBasePoller implements Runnable {

        boolean jRunning = true;

        public void setRunning(boolean running) {
            jRunning = running;
        }

        @Override
        public void run() {
            while (jRunning) {
                try {
                    Thread.sleep(jPollingIntervalSeconds * 1000);
                    if (jAllowPolling) {
                        jCache.updateCache();
                        // TEMPORARY FOR TESTING ONLY 
                        generateResupplyEvents();
                    }
                    if (jDBReader != null && jAllowPolling) {
                        System.err.println("Polling ... " + jDBReader.getDBName());
                    }
                } catch (InterruptedException ex) {
                    // Silently ignore - should only happen if we interrupt
                    Logger.getLogger(DBManager.class.getName()).log(Level.INFO, null, ex);
                }
            }
        }
    }

    private class StatusThread implements Runnable {

        boolean jRunning = true;
        HashMap<MetricsConstants.E_METRIC, Boolean> jMetricsConfigured = new HashMap();

        // Some status values to assist user
        public boolean jNeedMetricsProcessorUpdate = true;
        public boolean jROMCapturesSpecified = false;
        public boolean jHHOURsSpecified = false;
        public boolean jEntityWatchSpecified = false;

        // Possible realtime variables 
        long jROMEntryCount = 0;
        long jFratricideIncidentCount = 0;
        long jHHourCount = 0;

        public StatusThread() {
            initMetricsStatus();
        }

        public void setRunning(boolean running) {
            jRunning = running;
        }

        @Override
        public void run() {
            while (jRunning) {
                try {
                    Thread.sleep(jStatusIntervalSeconds * 1000);
                    if (jAllowPolling) {
                        updateMetricsProcessorState();
                        updateRealTimeStats();
                    }
                    if (jDBReader != null && jAllowPolling) {
                        //System.err.println("Status update ... " + jDBReader.getDBName());
                        UIOMetricsStatus stat = checkMetricsStatus();
                        DBManager.jDBManager.setPushData(stat);
                    }

                } catch (InterruptedException ex) {
                    // Silently ignore - should only happen if we interrupt
                    Logger.getLogger(DBManager.class.getName()).log(Level.INFO, null, ex);
                }
            }
        }

        private void initMetricsStatus() {
            List<E_METRIC> metrics = E_METRIC.getPossibleMetrics();

            // Initialize all to false
            for (E_METRIC m : metrics) {
                jMetricsConfigured.put(m, false);
            }

            jNeedMetricsProcessorUpdate = true;
            jROMCapturesSpecified = false;
            jHHOURsSpecified = false;
            jEntityWatchSpecified = false;
        }

        public UIOMetricsStatus checkMetricsStatus() {
            List<E_METRIC> metrics = E_METRIC.getPossibleMetrics();
            UIOMetricsStatus sObj = new UIOMetricsStatus();

            boolean active = false;
            for (E_METRIC m : metrics) {
                active = isMetricActivated(m);
                switch (m) {
                    case HHOUR:
                        sObj.jHHourActive = active;
                        if (active) {
                            sObj.jHHourReason = getConfigurationMissingMessage(m);
                        }
                        break;
                    case RATES_OF_MOVEMENT:
                        sObj.jROMActive = active;
                        if (active) {
                            sObj.jROMReason = getConfigurationMissingMessage(m);
                        }
                        break;
                    case CM_OCCUPATIONS:
                        sObj.jCMOccupationsActive = active;
                        if (active) {
                            sObj.jCMOccsReason = getConfigurationMissingMessage(m);
                        }
                        break;
                    case PICTURE_OF_ENEMY:
                        sObj.jPOEActive = active;
                        if (active) {
                            sObj.jPOEReason = getConfigurationMissingMessage(m);
                        }
                        break;
                    case COMBAT_POWER:
                        sObj.jCPowerActive = active;
                        break;
                    case ENEMY_ENGAGEMENTS:
                        sObj.jEnemyEngagementsActive = active;
                        if (active) {
                            sObj.jEneEngReason = getConfigurationMissingMessage(m);
                        }
                        break;
                    case FRATRICIDE:
                        sObj.jFratricideActive = active;
                        break;
                    case ENTITY_WATCH:
                        sObj.jEntityWatchActive = active;
                        if (active) {
                            sObj.jEntWatchReason = getConfigurationMissingMessage(m);
                        }
                        break;
                }
            }

            // Real time stats
            sObj.jROMEntryCount = jROMEntryCount;
            sObj.jHHourCount = jHHourCount;
            sObj.jFratricideIncidentCount = jFratricideIncidentCount;
            return sObj;
        }

        public boolean isMetricActivated(E_METRIC metric) {
            return jMetricsConfigured.get(metric);
        }

        public String getConfigurationMissingMessage(E_METRIC metric) {
            switch (metric) {
                case HHOUR:
                    if (!jHHOURsSpecified) {
                        return "H Hours have not been specified.";
                    }
                    break;
                case RATES_OF_MOVEMENT:
                    if (!jROMCapturesSpecified) {
                        return "Rates of Movement captures not specified.";
                    }
                    break;
                case PICTURE_OF_ENEMY:
                    if (!jCache.isNAIDefined() && !jCache.isTAIDefined() && !jCache.isAOIDefined()) {
                        return "No areas, named areas or target areas of interest defined.";
                    }
                    break;
                case CM_OCCUPATIONS:
                    if (!jCache.isNAIDefined() && !jCache.isTAIDefined() && !jCache.isAOIDefined()) {
                        return "No areas, named areas or target areas of interest defined.";
                    }
                    break;
                case ENEMY_ENGAGEMENTS:
                    if (!jCache.isFriendlyControlFeaturesDefined() || !jCache.isEnemyControlFeaturesDefined()) {
                        return "Both friendly and hostile control features may not be defined.";
                    }
                    break;
                case ENTITY_WATCH:
                    if (!jEntityWatchSpecified) {
                        return "No entities are currently being watched.";
                    }
                    break;
            }
            return null;
        }

        private void updateRealTimeStats() {
            jROMEntryCount = getTableCount(DB_GRatesOfMovementMetricsResults.TABLE);
            jFratricideIncidentCount = getTableCount(DB_GFratricideMetricsResults.TABLE);
            jHHourCount = getTableCount(DB_GHhourMetricsResults.TABLE);
        }

        public void updateMetricsProcessorState() {
            if (!jNeedMetricsProcessorUpdate) {
                return;
            }
            GetMetricsSpecificationsRequest req = new GetMetricsSpecificationsRequest();
            GetMetricsSpecificationTxn txn = new GetMetricsSpecificationTxn(jDBReader, req, null);

            if (!txn.run()) {
                Logger.getLogger(DBManager.class.getName()).log(
                        Level.WARNING, null, "Error updating metrics specifications.");
                return;
            }
            Set<String> active = req.getActiveMetrics();
            ArrayList check;
            for (String m : active) {
                if (null != m) {
                    E_METRIC met = E_METRIC.toEnum(m);
                    switch (met) {
                        case HHOUR:
                            jMetricsConfigured.put(E_METRIC.HHOUR, true);
                            check = req.getHHourSpecs();
                            if (!check.isEmpty()) {
                                jHHOURsSpecified = true;
                            }
                            break;
                        case RATES_OF_MOVEMENT:
                            jMetricsConfigured.put(E_METRIC.RATES_OF_MOVEMENT, true);
                            check = req.getRatesOfMovementSpecs();
                            if (!check.isEmpty()) {
                                jROMCapturesSpecified = true;
                            }
                            break;
                        case CM_OCCUPATIONS:
                            jMetricsConfigured.put(E_METRIC.CM_OCCUPATIONS, true);
                            break;
                        case FRATRICIDE:
                            jMetricsConfigured.put(E_METRIC.FRATRICIDE, true);
                            break;
                        case PICTURE_OF_ENEMY:
                            jMetricsConfigured.put(E_METRIC.PICTURE_OF_ENEMY, true);
                            break;
                        case ENEMY_ENGAGEMENTS:
                            jMetricsConfigured.put(E_METRIC.ENEMY_ENGAGEMENTS, true);
                            break;
                        case COMBAT_POWER:
                            jMetricsConfigured.put(E_METRIC.COMBAT_POWER, true);
                            break;
                        case ENTITY_WATCH:
                            jMetricsConfigured.put(E_METRIC.ENTITY_WATCH, true);
                            check = req.getEntityWatchSpecs();
                            if (!check.isEmpty()) {
                                jEntityWatchSpecified = true;
                            }
                            break;
                        default:
                            break;
                    }
                }
            }
            if (jMetricsConfigured.values().stream().allMatch(b -> Boolean.TRUE.equals(b))) {
                if (jHHOURsSpecified && jROMCapturesSpecified && jEntityWatchSpecified) {
                    // All definable attributes have been set so stop checking this
                    jNeedMetricsProcessorUpdate = false;
                }
            }
        }

        private long getTableCount(String table) {
            String query = "select count(*) from " + table;
            TxnRawSQL txn = new TxnRawSQL(jDBReader, query, false);
            long count = 0;

            try {
                txn.run();
                ResultSet rs = txn.getResultSet();
                if (rs != null) {
                    if (rs.next()) {
                        count = rs.getLong(1);
                    }
                }
            } catch (Exception ex) {
                Logger.getLogger(DBManager.class.getName()).log(
                        Level.INFO, null, "Unable to get size of " + table);
            }
            return count;
        }
    }

    /**
     * DBCache is overloaded so that we can update the cache after each polling
     * interval to see if any new objects of interest have been added to the
     * database (live mode only). We use some of the methods from the parent
     * cache directly because they check if objects exist before caching them.
     * Some we have had to add new handling for since they were adding to the
     * cache without checking (ok for parent cache because that is only done
     * once at init - not ok for us because we are constantly polling)
     */
    private class MIDASDBCache extends DBCache {

        private DBCacheLoader jDBCacheLoader;
        private MetObjectDBCache jMetObjectDBCache;
        private final Map<Long, Map<Long, GObjectItem>> jVcciUnitObjItemsByContext = new ConcurrentHashMap<>(); // ContextID -> ObjItemID -> GObjectItem

        // Thread-safe cache: maps simulationOffset -> (unitId -> List of GHolding)
        private final Map<Long, Map<Long, List<GHolding>>> jHoldingsCache = new ConcurrentHashMap<>();
        private final Map<Long, GHolding> holdingIndexMap = new ConcurrentHashMap<>();
        private final List<MDVTRecord> jMDVTRecords = new CopyOnWriteArrayList<>();
        // Tracks the highest simulation offset time currently in cache
        private long holdingsCacheMaxTime = Long.MIN_VALUE;
        //private volatile long jLastCacheTimestamp;

        // To increase performance when checking for special control features
        Set<Long> jNotControlFeaturesSet = new HashSet();
        public boolean jNAIDefined = false;
        public boolean jTAIDefined = false;
        public boolean jAOIDefined = false;
        public boolean jFriendlyControlFeaturesDefined = false;
        public boolean jEnemyControlFeaturesDefined = false;

        public MIDASDBCache() {
            super(null, null, jDBReader);
        }

        @Override
        public boolean initialize() {
            jDBCacheLoader = DBCacheLoader.createSimpleLoader(this, jReader);
            jMetObjectDBCache = new MetObjectDBCache(jReader);
            try {
                // Load standard caches and verify success
                if (!jDBCacheLoader.loadCache() || !jMetObjectDBCache.initMetObjectData()) {
                    throw new IllegalStateException("Base cache load failed");
                }
                // Load all holdings into in-memory cache (throws on failure)
                loadAllHoldingsIntoCacheOrThrow();

                // Record “now” as the start of our next window(not needed)
                //jLastCacheTimestamp = System.currentTimeMillis();

                // Load temp data into MDVT records
                loadTempMDVTRecords();

                return true;
            } catch (Exception ex) {
                log.error("Cache init failed", ex);
                return false;
            }

        }

        private void loadTempMDVTRecords(){
            MDVTRecord rec = new MDVTRecord(12,"Joe Bloggins","driver",600000L,"","",0L,0L,0,0,0L,"LAV3 Alpha","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"Ken Keith","gunner",600000L,"","",0L,0L,0,0,0L,"LAV3 Alpha","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"Harry Houdini","commander",600000L,"","",0L,0L,0,0,0L,"LAV3 Alpha","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"","",0L,0L,0,0,0L,"LAV3 Alpha","LAV3",450000L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"","",0L,0L,0,0,0L,"LAV3 Alpha","LAV3",0L,150000L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"BTR-80 Alpha","BTR-80",0L,0L,0,0,0L,"LAV3 Alpha","LAV3",0L,0L,0L,100000L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"BTR-80 Alpha","BTR-80",0L,0L,1,0,0L,"LAV3 Alpha","LAV3",0L,0L,110000L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"BTR-80 Alpha","BTR-80",1L,112000L,0,0,0L,"LAV3 Alpha","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"BTR-80 Alpha","BTR-80",3L,116000L,1,0,0L,"LAV3 Alpha","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"BTR-80 Alpha","BTR-80",5L,120000L,1,0,0L,"LAV3 Alpha","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"BTR-80 Alpha","BTR-80",7L,124000L,0,0,0L,"LAV3 Alpha","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"BTR-80 Alpha","BTR-80",9L,128000L,0,0,0L,"LAV3 Alpha","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"URAL truck Bravo","URAL truck",0L,0L,0,0,0L,"LAV3 Alpha","LAV3",0L,0L,0L,115000L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"URAL truck Bravo","URAL truck",0L,0L,1,0,0L,"LAV3 Alpha","LAV3",0L,0L,117000L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"URAL truck Bravo","URAL truck",11L,140000L,0,0,0L,"LAV3 Alpha","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"URAL truck Bravo","URAL truck",13L,142000L,1,0,0L,"LAV3 Alpha","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"URAL truck Bravo","URAL truck",15L,144000L,1,0,0L,"LAV3 Alpha","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"URAL truck Bravo","URAL truck",17L,146000L,0,0,0L,"LAV3 Alpha","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"URAL truck Bravo","URAL truck",19L,148000L,1,0,0L,"LAV3 Alpha","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"URAL truck Bravo","URAL truck",21L,150000L,1,1,0L,"LAV3 Alpha","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"URAL truck Bravo","URAL truck",23L,152000L,0,0,12000L,"LAV3 Alpha","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"","",0L,0L,0,0,0L,"Coyote Bravo","Coyote",540000L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"","",0L,0L,0,0,0L,"Coyote Bravo","Coyote",0L,210000L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"BTR-80 Alpha","BTR-80",0L,0L,0,0,0L,"Coyote Bravo","Coyote",0L,0L,100000L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"BTR-80 Alpha","BTR-80",0L,0L,1,0,0L,"Coyote Bravo","Coyote",0L,0L,0L,96000L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"BTR-80 Alpha","BTR-80",2L,111000L,0,0,0L,"Coyote Bravo","Coyote",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"BTR-80 Alpha","BTR-80",4L,115000L,0,0,0L,"Coyote Bravo","Coyote",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"BTR-80 Alpha","BTR-80",6L,119000L,0,0,0L,"Coyote Bravo","Coyote",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"BTR-80 Alpha","BTR-80",8L,123000L,1,0,0L,"Coyote Bravo","Coyote",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"BTR-80 Alpha","BTR-80",10L,127000L,1,1,0L,"Coyote Bravo","Coyote",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"BTR-80 Alpha","BTR-80",12L,131000L,0,0,20000L,"Coyote Bravo","Coyote",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"URAL truck Bravo","URAL truck",0L,0L,0,0,0L,"Coyote Bravo","Coyote",0L,0L,0L,138000L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"URAL truck Bravo","URAL truck",0L,0L,1,0,0L,"Coyote Bravo","Coyote",0L,0L,141000L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"URAL truck Bravo","URAL truck",14L,143000L,1,0,0L,"Coyote Bravo","Coyote",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"URAL truck Bravo","URAL truck",16L,145000L,0,0,0L,"Coyote Bravo","Coyote",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"URAL truck Bravo","URAL truck",18L,147000L,0,0,0L,"Coyote Bravo","Coyote",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"URAL truck Bravo","URAL truck",20L,149000L,0,0,0L,"Coyote Bravo","Coyote",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(12,"","",0L,"URAL truck Bravo","URAL truck",22L,151000L,0,0,0L,"Coyote Bravo","Coyote",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"","",0L,0L,0,0,0L,"Coyote Bravo","Coyote",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"Oliver Oscar","driver",720000L,"","",0L,0L,0,0,0L,"LAV3 Charlie","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"Josh Jackson","gunner",720000L,"","",0L,0L,0,0,0L,"LAV3 Charlie","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"Joe Bloggins","commander",720000L,"","",0L,0L,0,0,0L,"LAV3 Charlie","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"","",0L,0L,0,0,0L,"LAV3 Charlie","LAV3",600000L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"","",0L,0L,0,0,0L,"LAV3 Charlie","LAV3",0L,120000L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"BTR-80 Delta","BTR-80",0L,0L,0,0,0L,"LAV3 Charlie","LAV3",0L,0L,0L,200000L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"BTR-80 Delta","BTR-80",0L,0L,1,0,0L,"LAV3 Charlie","LAV3",0L,0L,210000L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"BTR-80 Delta","BTR-80",1L,212000L,0,0,0L,"LAV3 Charlie","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"BTR-80 Delta","BTR-80",3L,216000L,1,0,0L,"LAV3 Charlie","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"BTR-80 Delta","BTR-80",5L,220000L,1,0,0L,"LAV3 Charlie","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"BTR-80 Delta","BTR-80",7L,224000L,0,0,0L,"LAV3 Charlie","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"BTR-80 Delta","BTR-80",9L,228000L,0,0,0L,"LAV3 Charlie","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"GAZ Charlie","GAZ",0L,0L,0,0,0L,"LAV3 Charlie","LAV3",0L,0L,0L,215000L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"GAZ Charlie","GAZ",0L,0L,1,0,0L,"LAV3 Charlie","LAV3",0L,0L,217000L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"GAZ Charlie","GAZ",11L,240000L,0,0,0L,"LAV3 Charlie","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"GAZ Charlie","GAZ",13L,242000L,1,0,0L,"LAV3 Charlie","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"GAZ Charlie","GAZ",15L,244000L,1,0,0L,"LAV3 Charlie","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"GAZ Charlie","GAZ",17L,246000L,0,0,0L,"LAV3 Charlie","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"GAZ Charlie","GAZ",19L,248000L,1,0,0L,"LAV3 Charlie","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"GAZ Charlie","GAZ",21L,250000L,1,1,0L,"LAV3 Charlie","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"GAZ Charlie","GAZ",23L,252000L,0,0,12000L,"LAV3 Charlie","LAV3",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"","",0L,0L,0,0,0L,"Coyote Bravo","Coyote",540000L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"","",0L,0L,0,0,0L,"Coyote Bravo","Coyote",0L,210000L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"BTR-80 Delta","BTR-80",0L,0L,0,0,0L,"Coyote Bravo","Coyote",0L,0L,200000L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"BTR-80 Delta","BTR-80",0L,0L,1,0,0L,"Coyote Bravo","Coyote",0L,0L,0L,196000L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"BTR-80 Delta","BTR-80",2L,211000L,0,0,0L,"Coyote Bravo","Coyote",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"BTR-80 Delta","BTR-80",4L,215000L,0,0,0L,"Coyote Bravo","Coyote",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"BTR-80 Delta","BTR-80",6L,219000L,0,0,0L,"Coyote Bravo","Coyote",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"BTR-80 Delta","BTR-80",8L,223000L,1,0,0L,"Coyote Bravo","Coyote",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"BTR-80 Delta","BTR-80",10L,227000L,1,1,0L,"Coyote Bravo","Coyote",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"BTR-80 Delta","BTR-80",12L,231000L,0,0,20000L,"Coyote Bravo","Coyote",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"GAZ Charlie","GAZ",0L,0L,0,0,0L,"Coyote Bravo","Coyote",0L,0L,0L,238000L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"GAZ Charlie","GAZ",0L,0L,1,0,0L,"Coyote Bravo","Coyote",0L,0L,241000L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"GAZ Charlie","GAZ",14L,243000L,1,0,0L,"Coyote Bravo","Coyote",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"GAZ Charlie","GAZ",16L,245000L,0,0,0L,"Coyote Bravo","Coyote",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"GAZ Charlie","GAZ",18L,247000L,0,0,0L,"Coyote Bravo","Coyote",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);
            rec = new MDVTRecord(19,"","",0L,"GAZ Charlie","GAZ",20L,249000L,0,0,0L,"Coyote Bravo","Coyote",0L,0L,0L,0L);
            jCache.jMDVTRecords.add(rec);

        }

        public boolean isNAIDefined() {
            return jNAIDefined;
        }

        public boolean isTAIDefined() {
            return jTAIDefined;
        }

        public boolean isAOIDefined() {
            return jAOIDefined;
        }

        public boolean isFriendlyControlFeaturesDefined() {
            return jFriendlyControlFeaturesDefined;
        }

        public boolean isEnemyControlFeaturesDefined() {
            return jEnemyControlFeaturesDefined;
        }

        public void updateCache() {
            // All these check existence before adding so can be
            // called any number of times

            // Update holdings incrementally
            loadNewHoldingsIntoCache();
            if (!jDBCacheLoader.loadUnitTypes()) {
                Logger.getLogger(DBManager.class.getName()).log(
                        Level.WARNING, null, "Error updating unit types cache.");
            }
            if (!jDBCacheLoader.loadFeatureTypes()) {
                Logger.getLogger(DBManager.class.getName()).log(
                        Level.WARNING, null, "Error updating feature types cache.");
            }
            if (!jDBCacheLoader.loadFacilityTypes()) {
                Logger.getLogger(DBManager.class.getName()).log(
                        Level.WARNING, null, "Error updating facility types cache.");
            }
            if (!jDBCacheLoader.loadUnits()) {
                Logger.getLogger(DBManager.class.getName()).log(
                        Level.WARNING, null, "Error updating units cache.");
            }
            if (!jDBCacheLoader.loadMateriel()) {
                Logger.getLogger(DBManager.class.getName()).log(
                        Level.WARNING, null, "Error updating materiel cache.");
            }
            if (!jDBCacheLoader.loadPersons()) {
                Logger.getLogger(DBManager.class.getName()).log(
                        Level.WARNING, null, "Error updating persons cache.");
            }
            if (!jDBCacheLoader.loadPointsOfInterest()) {
                Logger.getLogger(DBManager.class.getName()).log(
                        Level.WARNING, null, "Error updating points of interest cache.");
            }
            if (!jDBCacheLoader.loadFacilities()) {
                Logger.getLogger(DBManager.class.getName()).log(
                        Level.WARNING, null, "Error updating facilities cache.");
            }
            if (!jDBCacheLoader.loadFeatures()) {
                Logger.getLogger(DBManager.class.getName()).log(
                        Level.WARNING, null, "Error updating features cache.");
            }

            // Rewritten methods that check to see if these already exist else
            // will get out of memory exception (base cache does not check)
            if (!checkAndAppendObjectItemTypes()) {
                Logger.getLogger(DBManager.class.getName()).log(
                        Level.WARNING, null, "Error appending to object item type cache.");
            }
            if (!checkAndAppendObjectItemStatus()) {
                Logger.getLogger(DBManager.class.getName()).log(
                        Level.WARNING, null, "Error appending to object item status cache.");
            }

            if (!jMetObjectDBCache.updateMetObjectData()) {
                Logger.getLogger(DBManager.class.getName()).log(
                        Level.WARNING, null, "Error updating metric cache data.");
            }

            // And update latest time
            GetTimeRequest gtr = new GetTimeRequest(true, true, null);
            gtr.setUseSimTime(true);
            gtr = jDBReader.getTimeRequest(gtr);

            if (gtr.isSuccessful()) {
                jLatestTime = gtr.jLatestDate;
            } else {
                Logger.getLogger(DBManager.class.getName())
                        .log(Level.INFO, null, "Unable to get database latest time!");
            }
            // And update symbols
            generateMilitarySymbols();

            checkUpdateControlFeatures();
        }

        @Override
        protected void cacheObjectItem(GObjectItem objItem) {
            super.cacheObjectItem(objItem);
            if (objItem instanceof GUnit) {
                long objItemId = objItem.getObjectItemId();
                long contextId = objItem.getObjectItemContextId();
                Map<Long, GObjectItem> idToUnitMap =
                        jVcciUnitObjItemsByContext.computeIfAbsent(
                                contextId, k -> new HashMap<>());
                synchronized (idToUnitMap) {
                    if (!idToUnitMap.containsKey(objItemId)) {
                        idToUnitMap.put(objItemId, objItem);
                    }
                }
            }
        }

        private Map<Long, GObjectItem> getUnitObjItemsByContext(GContext context) {
            return jVcciUnitObjItemsByContext.get(context.getContextId());
        }

        /**
         * Loads all holdings into cache, grouped by simOffsetTime and unitId,
         * and updates the cache watermark to the latest simOffsetTime.
         */
        private void loadAllHoldingsIntoCacheOrThrow() {
            try {
                // Get all unit IDs from the object cache
                List<Long> allUnitIds = jObjectItems.keySet()
                        .stream()
                        .map(Long::valueOf)
                        .collect(Collectors.toList());

                // Request holdings for all units
                GetHoldingsRequest req = new GetHoldingsRequest(new LinkedList<>(allUnitIds));
                req = jDBReader.getHoldingsRequest(req);
                List<GHolding> allHoldings = req.getResults();

                // Clear any previous data
                jHoldingsCache.clear();
                holdingIndexMap.clear();
                long maxSimTime = Long.MIN_VALUE;

                // Populate cache: time → unitId → list of holdings
                for (GHolding h : allHoldings) {
                    long time = h.getHoldingSimulationOffsetTime();
                    long unitId = h.getHoldingObjectItemId();
                    maxSimTime = Math.max(maxSimTime, time);

                    jHoldingsCache
                            .computeIfAbsent(time, t -> new ConcurrentHashMap<>())
                            .computeIfAbsent(unitId, u -> new ArrayList<>())
                            .add(h);

                    holdingIndexMap.put(h.getHoldingIndex(), h);// store for quick index lookup
                }
                // Update watermark or reset if no data found
                if (maxSimTime == Long.MIN_VALUE) {
                    holdingsCacheMaxTime = 0L;
                } else {
                    holdingsCacheMaxTime = maxSimTime;
                }

            } catch (Exception ex) {
                throw new RuntimeException("Failed to load initial holdings cache", ex);
            }
        }

        /**
         * Fetches and merges holdings newer than the cache watermark, skips
         * older/duplicate records, updates caches, and logs units with new
         * data.
         */
        private void loadNewHoldingsIntoCache() {
            try {
                // Define fetch window: from last cached time to no upper limit
                long windowStart = holdingsCacheMaxTime;
                long windowEnd = DBConstants.INVALID_TIME;
                // Get all active unit IDs
                List<Long> allUnitIds = jObjectItems.keySet().stream()
                        .map(Long::valueOf)
                        .collect(Collectors.toList());

                // Request holdings within the fetch window
                GetHoldingsRequest req = new GetHoldingsRequest(windowStart, windowEnd, new LinkedList<>(allUnitIds));
                req = jDBReader.getHoldingsRequest(req);

                // Flag to know if any new records were merged
                boolean didMerge = false;
                long maxSimTime = holdingsCacheMaxTime;
                int merged = 0, skipped = 0;

                // Track which units got new holdings
                Set<Long> unitsWithNewHoldings = new HashSet<>();

                for (GHolding h : req.getResults()) {
                    long time = h.getHoldingSimulationOffsetTime();
                    long unitId = h.getHoldingObjectItemId();
                    long idx = h.getHoldingIndex();

                    // Skip if older than watermark or already cached
                    if (time < holdingsCacheMaxTime || holdingIndexMap.containsKey(idx)) {
                        skipped++;
                        continue;
                    }

                    // Insert into the nested cache:
                    // holdingsCache maps time → (unitId → List<GHolding>)
                    jHoldingsCache
                            .computeIfAbsent(time, t -> new ConcurrentHashMap<>())
                            .computeIfAbsent(unitId, u -> new ArrayList<>())
                            .add(h);

                    // Add to holdingIndexMap for fast lookup by index
                    holdingIndexMap.put(idx, h);
                    merged++;
                    didMerge = true;
                    unitsWithNewHoldings.add(unitId);
                    if (time > maxSimTime) {
                        maxSimTime = time;// track latest simOffsetTime
                    }
                }

                // Update watermark if new data merged
                if (didMerge && maxSimTime > holdingsCacheMaxTime) {
                    holdingsCacheMaxTime = maxSimTime;
                }
                // Log merged units
//                if (!unitsWithNewHoldings.isEmpty()) {
//                    log.info("New holdings merged for units: " + unitsWithNewHoldings +
//                            " | merged=" + merged + ", skipped=" + skipped +
//                            ", newWatermark=" + holdingsCacheMaxTime);
//                }

            } catch (Exception ex) {
                log.error("Failed to update holdings cache", ex);
            }
        }

        /**
         * Find the latest GHolding per (unit, type) at or before simTime, using
         * the in-memory holdingsCache.
         */
        public List<GHolding> getLatestHoldingsFromCache(long unitId, long simTime) {
            // 1) Gather all snapshot times in the cache that are <= the requested simulation time,
            //    then sort them oldest → newest.
            List<Long> times = jHoldingsCache.keySet().stream()
                    .filter(t -> t <= simTime)
                    .sorted()
                    .collect(Collectors.toList());

            // 2) Map to hold, for each equipment type ID, the freshest GHolding seen so far.
            //    Key = objectTypeId, Value = GHolding instance from the latest time bucket.
            Map<Long, GHolding> latestByType = new HashMap<>();
            for (Long t : times) {
                // 3a) Get the per-unit map at this timestamp: unitId → List<GHolding>
                Map<Long, List<GHolding>> unitMap = jHoldingsCache.get(t);
                if (unitMap == null) {
                    continue;
                }
                // 3b) Pull the list of holdings for our specific unit
                List<GHolding> list = unitMap.get(unitId);
                if (list == null) {
                    // this unit had no holdings recorded at time t
                    continue;
                }

                // 3c) For each GHolding in that list, update the map entry for its type.
                //     Because we iterate times oldest→newest, each put() overwrites
                //     any earlier snapshot of the same type, leaving only the latest.
                for (GHolding h : list) {
                    latestByType.put(h.getHoldingObjectTypeId(), h);
                }
            }
            // 4) Return the collection of “latest per-type” holdings as a List.
            //    The order of entries is unspecified;
            return new ArrayList<>(latestByType.values());
        }

        public Map<Long, HoldingWithPrevious> getHoldingsWithPreviousFromCache(long unitId, long simTime) {
            // Result map: equipmentTypeId → HoldingWithPrevious
            Map<Long, HoldingWithPrevious> result = new HashMap<>();

            // Step 1: Gather all snapshot times ≤ simTime (oldest → newest)
            List<Long> times = jHoldingsCache.keySet().stream()
                    .filter(t -> t <= simTime)
                    .sorted()
                    .collect(Collectors.toList());

            // Step 2: Iterate through each snapshot time
            for (Long time : times) {
                Map<Long, List<GHolding>> unitMap = jHoldingsCache.get(time);
                if (unitMap == null) {
                    continue;
                }

                List<GHolding> holdings = unitMap.get(unitId);
                if (holdings == null) {
                    continue;
                }

                // Step 3: Process holdings for this snapshot
                for (GHolding h : holdings) {
                    long eqType = h.getHoldingObjectTypeId();
                    HoldingWithPrevious entry = result.get(eqType);

                    if (entry == null) {
                        // First time seeing this equipment type → initialize
                        result.put(eqType, new HoldingWithPrevious(h, null));
                    } else {
                        // Always shift: Previous <- Latest, Latest <- New
                        entry.jPrevious = entry.jLatest;
                        entry.jLatest = h;
                    }
                }
            }

            return result;
        }

        protected void generateMilitarySymbols() {
            GetObjectItemsRequest oir = new GetObjectItemsRequest(
                    true, true, true, false, false, false, true, true, false, false);
            oir = jCache.getObjectItemsRequest(oir);
            ArrayList<AObjectItem> ents = new ArrayList();
            ents.addAll(oir.getUnits());
            ents.addAll(oir.getMateriel());
            String symbol;
            long id;
            GObjectItem oi;
            for (AObjectItem aoi : ents) {
                oi = aoi.getObjectItem();
                if (oi != null) {
                    id = oi.getObjectItemId();
                    symbol = MilStd2525bGenerator.getMS2525Code(aoi);
                    jMilitarySymbolsHM.put(id, symbol);
                }
            }
        }

        /**
         * Since parent cache method simply adds all statuses that are loaded to
         * the list, we use this method to append to the object item status
         * information if that status object does not already exist
         */
        protected boolean checkAndAppendObjectItemStatus() {
            GetObjectItemStatusesRequest req
                    = new GetObjectItemStatusesRequest(
                    true, // includeOrgs
                    true, // includeMats
                    true, // includePersons
                    true, // includeControlFeatures
                    true, // includeGeographicFeatures
                    true // includeFacilities
            );

            GetObjectItemStatusesTxn txn = new GetObjectItemStatusesTxn(jReader, req);
            if (!txn.run()) {
                return false;
            }

            LinkedList<GObjectItemStatus> objs = req.getResults();
            String oiKey;
            GObjectItemDataCache cacheEntry;
            for (GObjectItemStatus obj : objs) {
                oiKey = Long.toString(obj.getObjectItemStatusObjectItemId());
                cacheEntry = checkCreateEntry(oiKey);
                LinkedList<GObjectItemStatus> statuses = cacheEntry.getStatuses();
                synchronized (statuses) {
                    int listSize = statuses.size();
                    long objItemStatId = obj.getObjectItemStatusObjectItemId();
                    boolean found = false;
                    for (int x = 0; !found && x < listSize; x++) {
                        if (statuses.get(x).getObjectItemStatusIndex() == objItemStatId) {
                            found = true;
                        }
                    }
                    if (!found) {
                        statuses.add(obj);
                    }
                }
            }
            return true;
        }

        protected boolean checkAndAppendObjectItemTypes() {
            GetObjectItemTypesRequest req = new GetObjectItemTypesRequest();
            GetObjectItemTypesTxn txn = new GetObjectItemTypesTxn(jReader, req);
            if (!txn.run()) {
                return false;
            }

            LinkedList<GObjectItemType> v = req.getResults();

            // Now set type/instance references
            AObjectItemType aoit;
            long typeId;
            long itemId;
            GObjectType type = null;
            GObjectItem item = null;
            long objItemTypeId;
            for (GObjectItemType oit : v) {
                aoit = new AObjectItemType();
                aoit.setObjectItemType(oit);
                typeId = oit.getObjectItemTypeObjectTypeId();
                itemId = oit.getObjectItemTypeObjectItemId();
                synchronized (jObjectTypes) {
                    type = jObjectTypes.get(Long.toString(typeId));
                }
                synchronized (jObjectItems) {
                    item = jObjectItems.get(Long.toString(itemId));
                }

                if (type == null) {
                    jL.warn("DBManager : Could not find type with id = " + typeId);
                    continue;
                }
                if (item == null) {
                    jL.warn("DBManager : Could not find item with id = " + itemId);
                    continue;
                }
                aoit.setObjectItem(item);
                aoit.setObjectType(type);

                // Currently do not care about object type alias handling
                //synchronized (jObjectTypeAlias) {
                //    aoit.setObjectTypeAlias(jObjectTypeAlias.get("" + typeId));
                //}
                // Need to see if this exists before adding - to make this faster
                // we will check the cache entry first (which is hashed by object 
                // item id)
                objItemTypeId = oit.getObjectItemTypeIndex();
                String cacheKey = Long.toString(itemId);
                GObjectItemDataCache cacheEntry = checkCreateEntry(cacheKey);
                boolean found;

                if (cacheEntry != null) {
                    LinkedList<AObjectItemType> types = cacheEntry.getTypes();
                    found = false;
                    int listSize = types.size();
                    for (int x = 0; !found && x < listSize; x++) {
                        if (types.get(x).getObjectItemType().getObjectItemTypeIndex() == objItemTypeId) {
                            found = true;
                        }
                    }

                    if (!found) {
                        synchronized (jOITypeLinkedList) {
                            jOITypeLinkedList.add(aoit);
                        }
                        synchronized (types) {
                            types.add(aoit);
                        }
                    }
                }
            }

            return true;
        }

        /**
         * Checking here if the user has specified control features required to
         * activate specific metrics. This will allow us to warn user to add
         * them so that metrics will be gathered. Here we also make sure that
         * any control features without locations (new ones) are updated with
         * their location. We need to do this because we are not caching new
         * locations as VCCI does. In most cases, positions that we need are
         * part of the metrics results which we get right from the database.
         */
        public void checkUpdateControlFeatures() {
            LinkedList<GObjectItem> objs = null;
            synchronized (jObjectItems) {
                objs = new LinkedList(jObjectItems.values());
            }

            for (GObjectItem oi : objs) {
                String stringOIId = String.valueOf(oi.getObjectItemId());
                long oid = oi.getObjectItemId();

                if (jNotControlFeaturesSet.contains(oid)) {
                    continue;
                }

                if (oi instanceof GControlFeature) {
                    GObjectItemDataCache cache = getOICache(stringOIId);
                    AObjectItemType aot = null;
                    GObjectItemStatus ois = null;
                    AObjectItemLocation loc = null;

                    if (cache != null) {
                        if (cache.getStatuses().size() > 0) {
                            ois = (cache.getStatuses().get(cache.getStatuses().size() - 1));
                        }

                        if (cache.getTypes().size() > 0) {
                            aot = (cache.getTypes().get(cache.getTypes().size() - 1));
                        }
                        loc = cache.getLatestLocation();
                    }

                    if (aot != null) {
                        GObjectType ot = aot.getObjectType();
                        if (ot != null && ot instanceof GControlFeatureType) {
                            GControlFeatureType cft = (GControlFeatureType) ot;
                            String cftCatCode = cft.getControlFeatureTypeCategoryCode();

                            if (GControlFeatureType.CONTROL_FEATURE_TYPE_CATEGORY_CODE_NAMAIN.equals(cftCatCode)) {
                                jNAIDefined = true;
                            } else if (GControlFeatureType.CONTROL_FEATURE_TYPE_CATEGORY_CODE_TGTAOI.equals(cftCatCode)) {
                                jTAIDefined = true;
                            } else if (GControlFeatureType.CONTROL_FEATURE_TYPE_CATEGORY_CODE_AOI.equals(cftCatCode)) {
                                jAOIDefined = true;
                            }
                        }
                    }
                    // Check for both friendly and hostile control features
                    if (ois != null) {
                        String hostility = ois.getObjectItemStatusHostilityCode();

                        if (hostility.equals(GObjectItemStatus.OBJECT_ITEM_STATUS_HOSTILITY_CODE_HO)) {
                            jEnemyControlFeaturesDefined = true;
                        } else if (hostility.equals(GObjectItemStatus.OBJECT_ITEM_STATUS_HOSTILITY_CODE_FR)) {
                            jFriendlyControlFeaturesDefined = true;
                        }
                    }

                    // And now make sure this control feature has a location
                    if (loc == null) {
                        // Check database
                        loc = loadControlFeatureLocation(oid);
                        if (cache != null && loc != null) {
                            cache.setLatestAObjectItemLocation(loc);
                        }
                    }
                } else {
                    jNotControlFeaturesSet.add(oid);
                }
            }
        }

        private AObjectItemLocation loadControlFeatureLocation(long objItemId) {

            // Now get the fac feat locations
            // Here's the order (separate queries)
            // 1) Get Facility Feature Locations joined with Location
            // 2) Get Point hierarchy
            // 3) Get Line hierarchy
            // 4) Get PolygonAreas
            // 5) Get PolyarcAreas
            // 6) Get OrbitAreas
            // 7) Get TrackAreas
            // 8) Get FanAreas
            // 9) Get Ellipses
            // Process fac feat list and link to the correct location hierarchy
            LinkedList<AObjectItemLocation> oils = getOILS(objItemId);
            if (oils == null) {
                return null;
            }

            GetLocationsRequest locationsRequest = new GetLocationsRequest(
                    true,
                    true,
                    true,
                    true,
                    true,
                    true,
                    true,
                    true,
                    true,
                    true,
                    null);

            GetLocationsTxn locationsTxn = new GetLocationsTxn(jDBReader, locationsRequest);
            if (!locationsTxn.run()) {
                return null;
            }

            // The following are all hashed on location id
            LinkedHashMap<String, GGeographicPoint> points = locationsRequest.jPoints;
            LinkedHashMap<String, DLine> lines = locationsRequest.jLines;
            LinkedHashMap<String, DPolygonArea> polygonAreas = locationsRequest.jPolygonAreas;
            LinkedHashMap<String, DPolyarcArea> polyarcAreas = locationsRequest.jPolyarcAreas;
            LinkedHashMap<String, DOrbitArea> orbitAreas = locationsRequest.jOrbitAreas;
            LinkedHashMap<String, DTrackArea> trackAreas = locationsRequest.jTrackAreas;
            LinkedHashMap<String, DFanArea> fanAreas = locationsRequest.jFanAreas;
            LinkedHashMap<String, DCorridorArea> corridorAreas = locationsRequest.jCorridorAreas;
            LinkedHashMap<String, DEllipse> ellipses = locationsRequest.jEllipses;

            // Now put the data together and add to request object
            // Traverse object item locations
            GLocation gloc;
            String code;
            long locId;

            for (AObjectItemLocation oil : oils) {
                gloc = oil.getLocation();

                // Get type
                code = gloc.getLocationCategoryCode();
                locId = gloc.getLocationId();

                String locIdKey = String.valueOf(locId);

                if (code.equals(GLocation.LOCATION_CATEGORY_CODE_PT)) {
                    // Find and set the point
                    if (points.containsKey(locIdKey)) {
                        oil.setLocation(points.get(locIdKey));
                    }
                } else if (code.equals(GLocation.LOCATION_CATEGORY_CODE_LN)) {
                    // Find the line
                    if (lines.containsKey(locIdKey)) {
                        oil.setLocation(lines.get(locIdKey));
                    }
                } else if (code.equals(GLocation.LOCATION_CATEGORY_CODE_PLYGAR)) {
                    // Find polygon areas
                    if (polygonAreas.containsKey(locIdKey)) {
                        DPolygonArea area = polygonAreas.get(locIdKey);

                        // Find and set the bounding line
                        long boundingLineId = area.getPolygonAreaBoundingLineId();
                        String boundingLineIdKey = String.valueOf(boundingLineId);
                        if (lines.containsKey(boundingLineIdKey)) {
                            area.setBoundingLine(lines.get(boundingLineIdKey));
                        }
                        oil.setLocation(area);
                    }
                } else if (code.equals(GLocation.LOCATION_CATEGORY_CODE_PLYAAR)) {
                    // Find polyarc areas
                    if (polyarcAreas.containsKey(locIdKey)) {
                        DPolyarcArea area = polyarcAreas.get(locIdKey);

                        // Find and set the lines
                        long definingLineId = area.getPolyarcAreaDefiningLineId();
                        long bearingOriginPointId = area.getPolyarcAreaBearingOriginPointId();
                        String dlKey = String.valueOf(definingLineId);
                        String bopKey = String.valueOf(bearingOriginPointId);
                        if (lines.containsKey(dlKey)) {
                            area.setDefiningLine(lines.get(dlKey));
                        }
                        if (points.containsKey(bopKey)) {
                            area.setBearingOriginPoint(points.get(bopKey));
                        }
                        oil.setLocation(area);
                    }
                } else if (code.equals(GLocation.LOCATION_CATEGORY_CODE_ORBTAR)) {
                    if (orbitAreas.containsKey(locIdKey)) {
                        DOrbitArea area = orbitAreas.get(locIdKey);

                        // Find and set the points
                        long firstPointId = area.getOrbitAreaFirstPointId();
                        long secondPointId = area.getOrbitAreaSecondPointId();

                        String firstId = String.valueOf(firstPointId);
                        String secondId = String.valueOf(secondPointId);
                        if (points.containsKey(firstId)) {
                            area.setOrbitAreaFirstPoint(points.get(firstId));
                        }
                        if (points.containsKey(secondId)) {
                            area.setOrbitAreaSecondPoint(points.get(secondId));
                        }
                        oil.setLocation(area);
                    }
                } else if (code.equals(GLocation.LOCATION_CATEGORY_CODE_TRCKAR)) {
                    if (trackAreas.containsKey(locIdKey)) {
                        DTrackArea area = trackAreas.get(locIdKey);

                        // Find and set the points
                        long firstPointId = area.getTrackAreaBeginPointId();
                        long secondPointId = area.getTrackAreaEndPointId();

                        String firstId = String.valueOf(firstPointId);
                        String secondId = String.valueOf(secondPointId);
                        if (points.containsKey(firstId)) {
                            area.setTrackAreaBeginPoint(points.get(firstId));
                        }
                        if (points.containsKey(secondId)) {
                            area.setTrackAreaEndPoint(points.get(secondId));
                        }
                        oil.setLocation(area);
                    }
                } else if (code.equals(GLocation.LOCATION_CATEGORY_CODE_FA)) {
                    if (fanAreas.containsKey(locIdKey)) {
                        DFanArea area = fanAreas.get(locIdKey);

                        // Find and set the vertex point
                        long vPointId = area.getFanAreaVertexPointId();
                        String pointId = String.valueOf(vPointId);

                        if (points.containsKey(pointId)) {
                            area.setFAVertexPoint(points.get(pointId));
                        }
                        oil.setLocation(area);
                    }
                } else if (code.equals(GLocation.LOCATION_CATEGORY_CODE_ELLPSE)) {
                    if (ellipses.containsKey(locIdKey)) {
                        DEllipse ellipse = ellipses.get(locIdKey);

                        // Find and set the lines
                        long centerPoint = ellipse.getEllipseCentrePointId();
                        long point1 = ellipse.getEllipseFirstConjugateDiameterPointId();
                        long point2 = ellipse.getEllipseSecondConjugateDiameterPointId();
                        String key = String.valueOf(centerPoint);
                        String key1 = String.valueOf(point1);
                        String key2 = String.valueOf(point2);
                        if (points.containsKey(key)) {
                            ellipse.setCentrePoint(points.get(key));
                        }
                        if (points.containsKey(key1)) {
                            ellipse.setFirstConjugateDiameterPoint(points.get(key1));
                        }
                        if (points.containsKey(key2)) {
                            ellipse.setSecondConjugateDiameterPoint(points.get(key2));
                        }
                        oil.setLocation(ellipse);
                    }
                } else if (code.equals(GLocation.LOCATION_CATEGORY_CODE_CORDAR)) {
                    if (corridorAreas.containsKey(locIdKey)) {
                        DCorridorArea area = corridorAreas.get(locIdKey);
                        String lineId = String.valueOf(area.getCorridorAreaCentreLineId());
                        if (lines.containsKey(lineId)) {
                            area.setCentreLine(lines.get(lineId));
                        }
                        oil.setLocation(area);
                    }
                } else {
                    DBConn.getLogger().warn("Unhandled location category code : " + code);
                }
            }
            // Return latest one - probably only one
            if (oils.isEmpty()) {
                return null;
            }
            return oils.get(oils.size() - 1);
        }

        private LinkedList<AObjectItemLocation> getOILS(long objItemId) {
            TxnSelect txn = new TxnSelect(jDBReader);
            LinkedList<AObjectItemLocation> oils = new LinkedList<>();

            try {
                DB_GObjectItemLocation.addObjectAttributesToTxn(txn);
                DB_GLocation.addObjectAttributesToTxn(txn);

                txn.addConstraint(DB_GObjectItemLocation.TABLE,
                        DB_GObjectItemLocation.OBJECT_ITEM_LOCATION_LOCATION_ID, " = ",
                        DB_GLocation.TABLE,
                        DB_GLocation.LOCATION_ID);

                txn.addConstraint(DB_GObjectItemLocation.TABLE,
                        DB_GObjectItemLocation.OBJECT_ITEM_LOCATION_OBJECT_ITEM_ID, " = ",
                        "" + objItemId);

                txn.orderBy(DB_GObjectItemLocation.TABLE,
                        DB_GObjectItemLocation.OBJECT_ITEM_LOCATION_TIME);

                txn.run();

                while (txn.next()) {
                    AObjectItemLocation aoil = new AObjectItemLocation();
                    GObjectItemLocation oil = DB_GObjectItemLocation.buildObjectFromTxn(txn);

                    GLocation loc = DB_GLocation.buildObjectFromTxn(txn);
                    aoil.setObjectItemLocation(oil);
                    aoil.setLocation(loc);
                    oils.add(aoil);
                }
            } catch (SQLException | DB_TxnFailedException e) {
                Logger.getLogger(DBManager.class.getName()).log(
                        Level.SEVERE, null, e.getMessage());
                return null;
            }
            return oils;
        }
    }
}
