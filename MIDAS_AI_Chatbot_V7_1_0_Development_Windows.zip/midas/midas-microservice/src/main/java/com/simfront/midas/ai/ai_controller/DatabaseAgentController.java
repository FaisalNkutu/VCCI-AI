/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.ai.ai_controller;

import com.simfront.midas.ai.ai_agent.DatabaseAgentService;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.*;
import io.micronaut.scheduling.annotation.ExecuteOn;
import io.micronaut.scheduling.TaskExecutors;

import jakarta.inject.Inject;

@Controller("/ai")
public class DatabaseAgentController {

    @Inject
    private DatabaseAgentService databaseAgentService;

    @Get("/ask-db")
    @ExecuteOn(TaskExecutors.BLOCKING)
    public HttpResponse<String> askDB(@QueryValue String q) {
        String llmOutput = databaseAgentService.queryCombatPowerTable(q);
        return HttpResponse.ok(llmOutput);
    }
}
