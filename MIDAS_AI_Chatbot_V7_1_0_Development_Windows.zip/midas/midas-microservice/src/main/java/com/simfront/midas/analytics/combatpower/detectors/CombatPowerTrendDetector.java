/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.analytics.combatpower.detectors;

import com.simfront.midas.analytics.combatpower.model.TrendType;
import java.util.List;

public class CombatPowerTrendDetector {

    /**
     * Detects the trend using the last 2 values only.
     */
    public static TrendType detectTrend(List<Double> values, double threshold) {
        if (values == null || values.size() < 2) {
            return TrendType.STABLE;
        }

        double last = values.get(values.size() - 1);
        double prev = values.get(values.size() - 2);
        double delta = last - prev;

        if (delta > threshold) return TrendType.UPWARD;
        if (delta < -threshold) return TrendType.DOWNWARD;
        return TrendType.STABLE;
    }
}
