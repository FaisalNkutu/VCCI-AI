package com.simfront.midas.client;

import com.simfront.midas.controller.AskMidasRequest;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.Header;
import io.micronaut.http.annotation.PathVariable;
import io.micronaut.http.annotation.Post;
import io.micronaut.http.client.annotation.Client;

import java.util.Map;

@Client("${db-agent.url}")
@Header(name = "X-API-Key", value = "${db-agent.api-key:}")
public interface DbAgentClient {

    @Post("/query")
    Map<String, Object> query(@Body AskMidasRequest request);

    @Post("/query/start")
    Map<String, Object> start(@Body Map<String, Object> request);

    @Get("/query/status/{jobId}")
    Map<String, Object> status(@PathVariable String jobId);

    @Get("/health")
    Map<String, Object> health();
}