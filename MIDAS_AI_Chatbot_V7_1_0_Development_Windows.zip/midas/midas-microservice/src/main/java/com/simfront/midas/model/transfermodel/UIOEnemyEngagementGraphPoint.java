/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

/**
 *
 * @author rhans
 */
public class UIOEnemyEngagementGraphPoint {

    long jTime = -1;
    String jFormattedTime = "";
    long jEntityCount = 0;
    long jEngagedCount = 0;

    public UIOEnemyEngagementGraphPoint(
            long time,
            String formattedTime) {
        jTime = time;
        jFormattedTime = formattedTime;
    }

    public long getEngagedCount() {
        return jEngagedCount;
    }

    public void setEngagedCount(long engagedCount) {
        jEngagedCount = engagedCount;
    }

    public long getEntityCount() {
        return jEntityCount;
    }

    public void setEntityCount(long dCount) {
        jEntityCount = dCount;
    }

    public long getTime() {
        return jTime;
    }

    public void setTime(long t) {
        jTime = t;
    }

    public String getFormattedTime() {
        return jFormattedTime;
    }

    public void setFormattedTime(String t) {
        jFormattedTime = t;
    }
}
