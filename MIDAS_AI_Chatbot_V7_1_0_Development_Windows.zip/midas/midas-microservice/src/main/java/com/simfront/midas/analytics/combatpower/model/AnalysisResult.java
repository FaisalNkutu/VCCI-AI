/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.analytics.combatpower.model;

public class AnalysisResult {
    private long unitId;
    private String unitName;
    private long time;
    private double value;
    private String trend;
    private boolean anomaly;
    private String reason;

    // ✅ NEW MARKERS
    private String trendMarker;   // "↑", "↓", "→"
    private String anomalyMarker; // "⚠️" or "⚑"

    public AnalysisResult(long unitId, String unitName, long time, double value) {
        this.unitId = unitId;
        this.unitName = unitName;
        this.time = time;
        this.value = value;

        this.anomaly = false;
        this.reason = "";

        // defaults
        this.trend = "STABLE";
        this.trendMarker = "→";   // stable by default
        this.anomalyMarker = "";  // no anomaly by default
    }

    // --- Getters & Setters ---
    public long getUnitId() { return unitId; }
    public void setUnitId(long unitId) { this.unitId = unitId; }

    public String getUnitName() { return unitName; }
    public void setUnitName(String unitName) { this.unitName = unitName; }

    public long getTime() { return time; }
    public void setTime(long time) { this.time = time; }

    public double getValue() { return value; }
    public void setValue(double value) { this.value = value; }

    public String getTrend() { return trend; }
    public void setTrend(String trend) { this.trend = trend; }

    public boolean isAnomaly() { return anomaly; }
    public void setAnomaly(boolean anomaly) { this.anomaly = anomaly; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    // --- Markers ---
    public String getTrendMarker() { return trendMarker; }
    public void setTrendMarker(String trendMarker) { this.trendMarker = trendMarker; }

    public String getAnomalyMarker() { return anomalyMarker; }
    public void setAnomalyMarker(String anomalyMarker) { this.anomalyMarker = anomalyMarker; }
}
