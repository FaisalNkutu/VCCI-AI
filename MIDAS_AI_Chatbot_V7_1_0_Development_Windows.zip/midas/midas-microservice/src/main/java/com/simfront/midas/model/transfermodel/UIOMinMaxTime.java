/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

/**
 *
 * @author rhans
 */
public class UIOMinMaxTime {

    long jMinTime = -1;
    long jMaxTime = -1;
    String jFormattedMinTime;
    String jFormattedMaxTime;

    public UIOMinMaxTime() {
    }

    public long getMinTime() {
        return jMinTime;
    }

    public void setMinTime(long minTime) {
        jMinTime = minTime;
    }

    public long getMaxTime() {
        return jMaxTime;
    }

    public void setMaxTime(long maxTime) {
        jMaxTime = maxTime;
    }

    public String getFormattedMinTime() {
        return jFormattedMinTime;
    }

    public void setFormattedMinTime(String formattedMinTime) {
        jFormattedMinTime = formattedMinTime;
    }

    public String getFormattedMaxTime() {
        return jFormattedMaxTime;
    }

    public void setFormattedMaxTime(String formattedMaxTime) {
        jFormattedMaxTime = formattedMaxTime;
    }
}
