/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.controller;

import com.simfront.midas.CentralDispatch;
import com.simfront.midas.constants.MIDASConstants;
import com.simfront.midas.model.transfermodel.UIOBase;
import com.simfront.midas.model.transfermodel.UIOHoldingRollupItem;
import com.simfront.midas.utils.RequestResults;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.*;


import java.util.*;
import java.util.stream.Collectors;


/**
 * ReportController
 *
 * Provides REST endpoints for reporting and visualization data in the MIDAS application.
 *
 * Key responsibilities:
 *  - Fetch ORBAT entities (units) for metrics dashboards.
 *  - Retrieve equipment types (materiel) associated with selected units.
 *  - Generate rollup (time-series) holdings data for graph displays.
 *  - Provide drilldown (unit-level contribution) for selected equipment at a given time.
 *
 * Delegates request processing to CentralDispatch, which handles the business logic and
 * data retrieval from DBManager and caches.
 */

@Controller("/advmetrics/report")
public class ReportController {


    /**
     * Fetch ORBAT entities for metrics dashboards.
     * Delegates to CentralDispatch with GET_METRICS_ENTITIES request.
     * @return List of organizational entities (e.g., units) available in the ORBAT.
     */
    @Get("/entities")
    public HttpResponse<List<Object>> getMetricsEntities() {
        ArrayList<Object> params = new ArrayList<>();

        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_METRICS_ENTITIES, params, true);

        if (!rr.isSuccess()) {
            return HttpResponse.serverError();
        }
        // Step 2: extract IDs from the flat list
        List<Object> flat = rr.getResults();
        Set<Long> entityIds = flat.stream()
                .filter(o -> o instanceof UIOBase)
                .map(o -> ((UIOBase) o).getId())
                .collect(Collectors.toSet());

        // Step 3: build ORBAT-style hierarchy (tree + orphans)
        RequestResults orbat = CentralDispatch.jCentralDispatch.generateNestedStructure(entityIds, true);
        if (!orbat.isSuccess()) {
            return HttpResponse.serverError();
        }

        return HttpResponse.ok(orbat.getResults());
    }

    /**
     * Retrieve equipment types for the selected entities.
     * Filters out NOS (Not Otherwise Specified) and includes materiel only.

     * @param selectedEntities List of entity (unit) IDs.
     * @return List of equipment (id, name, symbol) linked to selected entities.
     */
    @Get("/equipment-types")
    public HttpResponse<List<Map<String, Object>>> getEquipmentTypes(
            @QueryValue List<Long> selectedEntities) {

        ArrayList<Object> params = new ArrayList<>();
        params.add(selectedEntities);

        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_EQUIPMENT_TYPES, params, false);

        if (!rr.isSuccess()) {
            return HttpResponse.serverError();
        }

        List<Map<String, Object>> response = (List<Map<String, Object>>) (List<?>) rr.getResults();
        return HttpResponse.ok(response);
    }


    @Get("/rollup/holdings")
    public HttpResponse<Map<Long, List<UIOHoldingRollupItem>>> getHoldingRollups(
            @QueryValue List<Long> selectedEntities,
            @QueryValue List<Long> equipmentTypeIds,
            @QueryValue long startTime,
            @QueryValue long endTime) {

        ArrayList<Object> params = new ArrayList<>();
        params.add(selectedEntities);
        params.add(equipmentTypeIds);
        params.add(startTime);
        params.add(endTime);

        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_HOLDING_ROLLUP_RESULTS, params, false);

        if (!rr.isSuccess()) {
            return HttpResponse.serverError();
        }

        @SuppressWarnings("unchecked")
        Map<Long, List<UIOHoldingRollupItem>> response =
                (Map<Long, List<UIOHoldingRollupItem>>) ((List<?>) rr.getResults()).get(0);

        return HttpResponse.ok(response);
    }

    /**
     * Drilldown: Equipment contribution per unit at a given snapshot time.
     * Breaks down how each selected unit contributes to a specific equipment.
     * @param timeFormat Format for displaying time (e.g., D+HH:mm).
     * @param time Snapshot time for the contribution breakdown.
     * @param equipmentTypeId Equipment type being analyzed.
     * @param selectedEntities Units included in the contribution check.
     * @return List of unit-level contributions for the given equipment.
     */
    @Get("/rollup/holdings/contribution")
    public HttpResponse<List<Map<String, Object>>> getHoldingContribution(
            @QueryValue String timeFormat,
            @QueryValue long time,
            @QueryValue long equipmentTypeId,
            @QueryValue List<Long> selectedEntities) {

        ArrayList<Object> params = new ArrayList<>();
        params.add(timeFormat);
        params.add(time);
        params.add(equipmentTypeId);
        params.add(selectedEntities);

        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_HOLDING_CONTRIBUTION, params, false);

        if (!rr.isSuccess()) {
            return HttpResponse.serverError();
        }

        List<Map<String, Object>> response = (List<Map<String, Object>>) (List<?>) rr.getResults();
        return HttpResponse.ok(response);
    }
}
