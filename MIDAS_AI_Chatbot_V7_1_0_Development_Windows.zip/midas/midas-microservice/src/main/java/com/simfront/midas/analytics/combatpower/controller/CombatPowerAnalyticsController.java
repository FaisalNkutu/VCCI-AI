/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.analytics.combatpower.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.simfront.midas.analytics.combatpower.model.AnalysisResult;
import com.simfront.midas.analytics.combatpower.processor.CombatPowerAnalyticsProcessor;
import io.micronaut.http.MediaType;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.QueryValue;
import reactor.core.publisher.Flux;

import java.time.Duration;
import java.util.List;

@Controller("/analytics/combat-power")
public class CombatPowerAnalyticsController {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @Get(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM)
    public Flux<String> streamCombatPower(
            @QueryValue List<Long> entityIds,
            @QueryValue(defaultValue = "0") long fromTime,
            @QueryValue(defaultValue = "0") long toTime) {

        // Track the last time we already sent data
        final long[] lastSentTime = { fromTime };

        // Emit every 5 seconds
        Flux<String> dataFlux = Flux.interval(Duration.ofSeconds(5))
                .flatMap(tick -> {
                    try {
                        // Only fetch data newer than lastSentTime
                        List<AnalysisResult> analysis =
                                CombatPowerAnalyticsProcessor.analyze(entityIds, lastSentTime[0], toTime);

                        if (analysis.isEmpty()) {
                            return Flux.empty(); // nothing new
                        }

                        // Update lastSentTime to latest we just sent
                        long maxTimeSeen = lastSentTime[0];
                        for (AnalysisResult ar : analysis) {
                            if (ar.getTime() > maxTimeSeen) {
                                maxTimeSeen = ar.getTime();
                            }
                        }
                        lastSentTime[0] = maxTimeSeen;

                        // Convert to JSON
                        String json = OBJECT_MAPPER.writeValueAsString(analysis);
                        return Flux.just("data: " + json + "\n\n");
                    } catch (JsonProcessingException e) {
                        return Flux.just("data: {\"error\":\"serialization failed\"}\n\n");
                    }
                });

        // Heartbeat every 30s
        Flux<String> heartbeat = Flux.interval(Duration.ofSeconds(30))
                .map(t -> "event: heartbeat\ndata: {\"status\":\"alive\"}\n\n");

        return Flux.merge(dataFlux, heartbeat);
    }
}
