/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.ai.ai_agent;

import io.micronaut.http.HttpRequest;
import io.micronaut.http.client.BlockingHttpClient;
import io.micronaut.http.client.HttpClient;
import io.micronaut.http.client.annotation.Client;
import jakarta.inject.Singleton;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

@Singleton
public class DatabaseAgentService {

    private final BlockingHttpClient client;

    public DatabaseAgentService(@Client("ollama") HttpClient baseClient) {
        this.client = baseClient.toBlocking(); // convert only once here
    }

    public String queryCombatPowerTable(String userQuestion) {
        try {
            // 1. Build prompt
            String prompt = "You are a MySQL expert. The user asks: \"" + userQuestion + "\". " +
                    "Generate ONLY the SQL query using the table 'combat_power_metrics_results' " +
                    "which has columns: cpower_metrics_result_id, cpower.";

            // 2. Prepare payload
            Map<String, Object> payload = new HashMap<>();
            payload.put("model", "llama3");
            payload.put("prompt", prompt);
            payload.put("stream", false);

            // 3. Call Ollama (no extra .toBlocking())
            String llmResponse = client.retrieve(
                    HttpRequest.POST("/api/generate", payload)
                            .contentType("application/json")
            );

            // 4. Extract SQL
            String sql = extractSQL(llmResponse);
            if (!sql.trim().toUpperCase().startsWith("SELECT")) {
                return "⚠️ The LLM did not return a valid SELECT query. Response was:\n" + sql;
            }

            return runSQL(sql);

        } catch (Exception e) {
            return "❌ Error: " + e.getMessage();
        }
    }

    private String extractSQL(String response) {
        for (String line : response.split("\n")) {
            String trimmed = line.trim();
            if (trimmed.toUpperCase().startsWith("SELECT")) {
                return trimmed.replace(";", "");
            }
        }
        return "SELECT cpower_metrics_result_id, cpower FROM combat_power_metrics_results";
    }

    private String runSQL(String sql) throws SQLException {
        String url = "jdbc:mysql://localhost:3306/charlie";
        String user = "vcci";
        String password = "vcci";

        StringBuilder result = new StringBuilder();

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            ResultSetMetaData meta = rs.getMetaData();
            int cols = meta.getColumnCount();

            while (rs.next()) {
                for (int i = 1; i <= cols; i++) {
                    result.append(meta.getColumnName(i)).append(": ")
                            .append(rs.getString(i)).append(" | ");
                }
                result.append("\n");
            }
        }

        return result.toString().isEmpty() ? "⚠️ No results found." : result.toString();
    }
}
