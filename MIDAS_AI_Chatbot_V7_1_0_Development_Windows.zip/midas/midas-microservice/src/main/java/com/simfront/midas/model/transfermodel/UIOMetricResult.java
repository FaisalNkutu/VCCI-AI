/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

/**
 *
 * @author rhans
 */
public class UIOMetricResult extends UIOBase {

    // Spec that this result is generated from (if any)
    long jSpecId;
    long jSimStartTime;
    long jObjectItemId;

    public UIOMetricResult() {
    }

    public long getSpecId() {
        return jSpecId;
    }

    public void setSpecId(long specId) {
        jSpecId = specId;
    }

    public long getSimStartTime() {
        return jSimStartTime;
    }

    public void setSimStartTime(long simStartTime) {
        jSimStartTime = simStartTime;
    }

    public long getObjectItemId() {
        return jObjectItemId;
    }

    public void setObjectItemId(long objectItemId) {
        jObjectItemId = objectItemId;
    }
}
