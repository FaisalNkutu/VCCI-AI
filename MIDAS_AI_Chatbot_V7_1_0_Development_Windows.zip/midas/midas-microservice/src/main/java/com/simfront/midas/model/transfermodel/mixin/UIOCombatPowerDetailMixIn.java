/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel.mixin;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.simfront.midas.model.transfermodel.UIOHolding;
import java.util.ArrayList;

/**
 * @author rhans
 */
public abstract class UIOCombatPowerDetailMixIn {

    @JsonProperty("combatpower")
    public abstract double getCombatPower();

    @JsonIgnore()
    public abstract ArrayList<UIOHolding> getHoldings();

    @JsonProperty("time")
    public abstract long getSimulationTime();

    @JsonProperty("formattedtime")
    public abstract String getFormattedTime();

    @JsonProperty("entityid")
    public abstract long getEntityID();

}
