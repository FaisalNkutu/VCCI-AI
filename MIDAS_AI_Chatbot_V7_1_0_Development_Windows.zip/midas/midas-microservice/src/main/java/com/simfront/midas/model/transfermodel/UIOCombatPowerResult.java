/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

/**
 *
 * @author rhans
 */
public class UIOCombatPowerResult {

    long jEntityId = -1;
    long jTime = -1;
    String jFormattedTime = "";
    double jCombatPower = 0;

    public UIOCombatPowerResult(
            long entityId,
            long time,
            String formattedTime,
            double cpower) {
        jEntityId = entityId;
        jTime = time;
        jFormattedTime = formattedTime;
        jCombatPower = cpower;
    }

    public double getCombatPower() {
        return jCombatPower;
    }

    public long getEntityId() {
        return jEntityId;
    }

    public void setEntityId(long entityId) {
        jEntityId = entityId;
    }

    public long getTime() {
        return jTime;
    }

    public void setTime(long t) {
        jTime = t;
    }

    public String getFormattedTime() {
        return jFormattedTime;
    }

    public void setFormattedTime(String t) {
        jFormattedTime = t;
    }
}
