/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.analysis.trend_controller;

import com.simfront.midas.CentralDispatch;
import com.simfront.midas.analysis.trend_analysis.CombatPowerTrendAnalyzer;
import com.simfront.midas.constants.MIDASConstants;
import com.simfront.midas.utils.RequestResults;
import com.simfront.midas.model.analysis.CombatPowerRecord;

import io.micronaut.http.annotation.*;
import io.micronaut.http.HttpResponse;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller("/cp/analysis")
public class CombatPowerAnalysisController {

//    @Get("/simple-combat-power")
//    public HttpResponse<List<CombatPowerRecord>> getSimpleCombatPowerData() {
//
//        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
//                MIDASConstants.E_REQUEST.GET_SIMPLE_COMBAT_POWER_DATA,
//                new ArrayList<>(), // no params needed
//                false
//        );
//
//        if (rr == null || rr.getResults() == null || rr.getResults().isEmpty()) {
//            return HttpResponse.serverError();
//        }
//
//        @SuppressWarnings("unchecked")
//        List<CombatPowerRecord> results = (List<CombatPowerRecord>) (List<?>) rr.getResults();
//
//        return HttpResponse.ok(results);
//    }

    @Get("/rule-based-report")
    public HttpResponse<Map<String, List<String>>> getRuleBasedReport() {
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_SIMPLE_COMBAT_POWER_DATA,
                new ArrayList<>(),
                false
        );

        if (rr == null || rr.getResults() == null || rr.getResults().isEmpty()) {
            return HttpResponse.serverError();
        }

        @SuppressWarnings("unchecked")
        List<CombatPowerRecord> records = (List<CombatPowerRecord>) (List<?>) rr.getResults();

        Map<String, List<String>> report = CombatPowerTrendAnalyzer.generateRuleBasedReport(records);

        return HttpResponse.ok(report);
    }

}



