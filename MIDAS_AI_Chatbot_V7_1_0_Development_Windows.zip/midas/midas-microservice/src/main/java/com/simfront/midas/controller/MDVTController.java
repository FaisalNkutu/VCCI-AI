package com.simfront.midas.controller;

import com.simfront.midas.CentralDispatch;
import com.simfront.midas.constants.MIDASConstants.E_REQUEST;
import com.simfront.midas.utils.RequestResults;
import io.micronaut.core.annotation.Nullable;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.QueryValue;

import java.util.ArrayList;
import java.util.List;

@Controller("/mdvt")
public class MDVTController {
    
    @Get("/aggregate")
    public Object getAggregatedMDVTRecords(
            @QueryValue String metric,
            @QueryValue List<String> groupby,
            @QueryValue String method,
            @Nullable @QueryValue String filters) {

        ArrayList<Object> params = new ArrayList<>();

        params.add(metric);
        params.add(groupby);
        params.add(method);
        params.add(filters);

        RequestResults results =
                CentralDispatch.jCentralDispatch.processRequest(
                        E_REQUEST.GET_MDVT_AGGREGATE,
                        params,
                        true
                );

        return results.getResults();
    }
}
