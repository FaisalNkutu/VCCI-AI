/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

/**
 * Represents a single entity occupying a control measure at a given time.
 * Used for detailed CM Occupation results with symbology.
 *
 * @author r.hassan
 */
public class UIOCMEntity {

    private long entityId;
    private String entityName;
    private String milSym;

    public UIOCMEntity(long entityId, String entityName, String milSym) {
        this.entityId = entityId;
        this.entityName = entityName;
        this.milSym = milSym;
    }

    public long getEntityId() { return entityId; }
    public void setEntityId(long entityId) { this.entityId = entityId; }

    public String getEntityName() { return entityName; }
    public void setEntityName(String entityName) { this.entityName = entityName; }

    public String getMilSym() {
        return milSym;
    }
    public void setMilSym(String milSym) {
        this.milSym = milSym;
    }
}
