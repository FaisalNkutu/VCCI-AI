/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

/**
 *
 * @author rhans
 */
public class UIOFratGraphPoint {

    long jTime = -1;
    String jFormattedTime = "";
    int jFratIncidentCount = 0;

    public UIOFratGraphPoint(
            long time,
            String formattedTime) {
        jTime = time;
        jFormattedTime = formattedTime;
    }

    public void incrementCount() {
        jFratIncidentCount++;
    }

    public int getFratIncidentCount() {
        return jFratIncidentCount;
    }

    public void setFratIncidentCount(int fratIncidentCount) {
        jFratIncidentCount = fratIncidentCount;
    }

    public long getTime() {
        return jTime;
    }

    public void setTime(long t) {
        jTime = t;
    }

    public String getFormattedTime() {
        return jFormattedTime;
    }

    public void setFormattedTime(String t) {
        jFormattedTime = t;
    }
}
