/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model;

/**
 *
 * @author rhans
 */
public class ControlMeasureInfo {

    String jCMName = null;
    long jId;
    boolean jIsFriendly = true;

    public ControlMeasureInfo(
            String name,
            long id) {
        jId = id;
        jCMName = name;
    }

    public String getCMName() {
        return jCMName;
    }

    public long getId() {
        return jId;
    }

    public boolean isIsFriendly() {
        return jIsFriendly;
    }

    public void setIsFriendly(boolean isFriendly) {
        jIsFriendly = isFriendly;
    }
}
