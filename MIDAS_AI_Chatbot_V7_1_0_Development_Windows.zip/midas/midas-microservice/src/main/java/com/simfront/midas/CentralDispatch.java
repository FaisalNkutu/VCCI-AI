/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */
package com.simfront.midas;

import com.calian.paradigm.core.bto.model.gobjs.gen.*;
import com.simfront.midas.constants.MIDASConstants.E_REQUEST;
import com.simfront.midas.constants.MIDASConstants.E_REQUEST_STATUS;
import com.simfront.midas.managers.DBManager;
import com.simfront.midas.model.transfermodel.*;
import com.simfront.midas.processors.*;
import com.simfront.midas.utils.MIDASUtils;
import com.simfront.midas.utils.RequestResults;
import com.calian.paradigm.core.bto.model.aobjs.AObjectItem;
import java.util.function.Supplier;


import java.util.*;
import java.util.stream.Collectors;

import com.calian.paradigm.core.bto.model.dobjs.DObjectItemAssociation;
import com.calian.paradigm.core.metrics.MetricsConstants.E_METRIC;
import jakarta.inject.Singleton;

/**
 * Class that is responsible for arbitrating among all other classes
 *
 * @author rhans
 */
@Singleton
public class CentralDispatch {

    public static CentralDispatch jCentralDispatch;
    private DBManager jDBManager = null;
    protected HHourProcessor jHHourProcessor = new HHourProcessor();
    protected ROMProcessor jROMProcessor = new ROMProcessor();
    protected CMOccupationProcessor jCMOccProcessor = new CMOccupationProcessor();
    protected POEProcessor jPOEProcessor = new POEProcessor();
    protected FratricideProcessor jFratProcessor = new FratricideProcessor();
    protected EnemyEngProcessor jEnemyEngProcessor = new EnemyEngProcessor();
    protected CombatPowerProcessor jCombatPowerProcessor = new CombatPowerProcessor();
    protected EntityWatchLiveProcessor jEntityWatchLiveProcessor = new EntityWatchLiveProcessor();
    protected C2SimComparisonProcessor jC2SimComparisonProcessor = new C2SimComparisonProcessor();
    protected MDVTProcessor jMDVTProcessor = new MDVTProcessor();

    public CentralDispatch() {
        jCentralDispatch = this;
        jDBManager = new DBManager();
    }

    public RequestResults processRequest(
            E_REQUEST req,
            ArrayList<Object> params,
            boolean requiresCache) {
        if (req == E_REQUEST.SET_DATABASE) {
            return processSetDatabaseRequest(params);
        }

        if (!DBManager.jDBManager.isConnected()) {
            return new RequestResults(E_REQUEST_STATUS.FAILURE_DB_NOT_CONNECTED);
        }
        if (requiresCache) {
            if (!DBManager.jDBManager.isCacheReady()) {
                DBManager.jDBManager.waitForCache();
            }
        }

        RequestResults rr = null;
        DBManager.jDBManager.suspendPolling();
        switch (req) {
            case FORMAT_TIME:
                rr = formatTime(params);
                break;
            case GET_ENTITIES:
                rr = getEntities();
                break;
            case GET_METRICS_ENTITIES:
                rr = getMetricsEntities(params);
                break;
            case GET_TIME_FORMATS:
                rr = getTimeFormats();
                break;
            case GET_ORBAT:
                rr = getORBAT();
                break;
            case GET_EQUIPMENT_TYPES:
                rr = getEquipmentTypes(params);
                break;
            case GET_HOLDING_ROLLUP_RESULTS:
                rr = getHoldingRollupResults(params);
                break;
            case GET_HOLDING_CONTRIBUTION:
                rr = getHoldingContribution(params);
                break;
            case GET_HHOUR_SPECS:
                rr = jHHourProcessor.getHHourSpecs(params);
                break;
            case GET_HHOUR_ENTITIES:
                rr = jHHourProcessor.getHHourEntities(params);
                break;
            case GET_HHOUR_PERCENTAGE:
                rr = jHHourProcessor.getHHourPercentage(params);
                break;
            case GET_LINE_OF_DEPARTURE_LOCATIONS:
                rr = getControlFeatureLocation(params);
                break;
            case GET_MIN_MAX_TIME:
                rr = getMinMaxTime(params);
                break;
            case GET_RATES_OF_MOVEMENT_RESULTS:
                rr = jROMProcessor.getRatesOfMovementResults(params);
                break;
            case GET_RATES_OF_MOVEMENT_SPECS:
                rr = jROMProcessor.getROMSpecs(params);
                break;
            case GET_RATES_OF_MOVEMENT_STATS:
                rr = jROMProcessor.getROMStats(params);
                break;
            case GET_CM_OCCUPATIONS_CMS:
                rr = jCMOccProcessor.getCMOccControlMeasures();
                break;
            case GET_CM_OCCUPATIONS_BY_TIME_RESULTS:
                rr = jCMOccProcessor.getCMOccupationsByTime(params);
                break;
            case GET_CM_OCCUPATIONS:
                rr = jCMOccProcessor.getCMOccupations(params);
                break;
            case GET_CM_OCCUPATIONS_RESULTS:
                rr = jCMOccProcessor.getCMOccupationResults(params);
                break;
            case GET_PICTURE_OF_ENEMY_RESULTS:
                rr = jPOEProcessor.getPOEResults(params);
                break;
            case GET_PICTURE_OF_ENEMY_CMS:
                rr = jPOEProcessor.getPOEControlMeasures();
                break;
            case GET_FILTERED_PICTURE_OF_ENEMY_RESULTS:
                rr = jPOEProcessor.getFilteredPOEResults(params);
                break;
            case GET_FRATRICIDE_INCIDENTS_AT_TIME:
                rr = jFratProcessor.getFratricideIncidentsAtTime(params);
                break;
            case GET_FRATRICIDE_GRAPH:
                rr = jFratProcessor.getFratricideGraph(params);
                break;
            case GET_FRATRICIDE_INCIDENT_DETAILS:
                rr = jFratProcessor.getFratricideIncidentDetails(params);
                break;
            case GET_COMBAT_POWER_RESULTS:
                rr = jCombatPowerProcessor.getCombatPowerResults(params);
                break;
            case GET_COMBAT_POWER_DETAILS:
                rr = jCombatPowerProcessor.getCombatPowerDetails(params);
                break;
            case GET_COMBAT_POWER_GROUP_DETAILS:
                rr = jCombatPowerProcessor.getCombatPowerGroupDetails(params);
                break;
            case GET_COMBAT_POWER_EQUIPMENT_TIME_SERIES:
                rr = jCombatPowerProcessor.getCombatPowerEquipmentTimeSeries(params);
                break;
            case GET_COMBAT_POWER_EQUIPMENT_CONTRIBUTION:
                rr = jCombatPowerProcessor.getCombatPowerEquipmentContribution(params);
                break;
            case GET_SIMPLE_COMBAT_POWER_DATA:
                rr = jCombatPowerProcessor.getCombatPowerRecord(params);
                break;
            case GET_ENEENG_CONTROL_MEASURES:
                rr = jEnemyEngProcessor.getEneEngControlMeasures();
                break;
            case GET_ENEENG_BY_TIME_RESULTS:
                rr = jEnemyEngProcessor.getEnemyEngagementsByTime(params);
                break;
            case GET_ENEENG_ENTITY_DETAILS:
                rr = jEnemyEngProcessor.getEnemyEngagementEntityDetails(params);
                break;
            case GET_ENTITY_WATCH_IDS:
                rr = jEntityWatchLiveProcessor.getEntityWatchIds(params);
                break;
            case GET_ENTITY_WATCH_RESULTS:
                rr = jEntityWatchLiveProcessor.getEntityWatchResults(params);
                break;
            case GET_C2SIM_CONTEXT_INFO:
                rr = jC2SimComparisonProcessor.getContextInfo();
                break;
            case GET_C2SIM_UNIT_LOCATIONS:
                rr = jC2SimComparisonProcessor.getUnitLocations(params);
                break;
            case GET_MDVT_AGGREGATE:
                rr = jMDVTProcessor.getAggregatedMDVTRecords(params);
                break;
        }
        DBManager.jDBManager.resumePolling();
        if (rr != null) {
            return rr;
        }
        return new RequestResults(E_REQUEST_STATUS.UNKNOWN_REQUEST);
    }

    // GENERAL REQUESTS OR REQUESTS FOR ALL METRICS -----------------------------
    public RequestResults processSetDatabaseRequest(ArrayList<Object> params) {
        String host = (String) params.get(0);
        String db = (String) params.get(1);
        String user = (String) params.get(2);
        String pwd = (String) params.get(3);
        Boolean isLive = (Boolean) (params.get(4));
        // Reset the database if we are connected to a different one
        // than the one being requested
        String currentDB = jDBManager.getDBName();
        if (currentDB != null) {
            if (!currentDB.equals(db)) {
                System.err.println("Disconnecting from " + currentDB);
                jDBManager.resetDBConnection();
            } else {
                // Same database so still good
                return new RequestResults(E_REQUEST_STATUS.SUCCESS);
            }
        }

        if (!DBManager.jDBManager.configureDB(host, db, user, pwd, isLive)) {
            return new RequestResults(E_REQUEST_STATUS.FAILURE_DB_NOT_CONNECTED);
        }
        return new RequestResults(E_REQUEST_STATUS.SUCCESS);
    }

    public RequestResults getEntities() {
        System.err.println("Processing getEntities()..");
        ArrayList<AObjectItem> results = DBManager.jDBManager.getEntities();
        ArrayList<Object> ents = new ArrayList();
        UIOBase o;
        for (AObjectItem aoi : results) {
            o = new UIOBase(
                    aoi.getObjectItem().getObjectItemNameText(),
                    aoi.getObjectItem().getObjectItemId());
            o.setMilSym(DBManager.jDBManager.getMilitarySymbol(
                    aoi.getObjectItem().getObjectItemId()));
            ents.add(o);
        }
        System.err.println("Returning " + ents.size() + " results...");
        return new RequestResults(ents, E_REQUEST_STATUS.SUCCESS);
    }

    public RequestResults getORBAT() {
        System.err.println("Processing getORBAT()..");
        ArrayList<AObjectItem> results = DBManager.jDBManager.getEntities();
        ArrayList<Object> ents = new ArrayList();
        UIOBase o;
        HashMap<Long, UIOBase> entsHM = new HashMap();

        for (AObjectItem aoi : results) {
            o = new UIOBase(
                    aoi.getObjectItem().getObjectItemNameText(),
                    aoi.getObjectItem().getObjectItemId());
            o.setMilSym(DBManager.jDBManager.getMilitarySymbol(
                    aoi.getObjectItem().getObjectItemId()));
            ents.add(o);
            entsHM.put(o.getId(), o);
        }

        // Now get org assocs
        LinkedList<DObjectItemAssociation> assocs = DBManager.jDBManager.getOrgOrgAssociations();

        long child;
        long parent;
        for (DObjectItemAssociation oia : assocs) {
            child = oia.getChildObjectItemId();
            parent = oia.getParentObjectItemId();

            // Find child
            o = entsHM.get(child);
            if (o != null) {
                o.setParentId(parent);
            }
        }

        System.err.println("Returning " + ents.size() + " results...");
        return new RequestResults(ents, E_REQUEST_STATUS.SUCCESS);
    }


    public RequestResults getEntityWatchIds(ArrayList<Object> params) {
        try {
            // 1) Read watch specs → collect IDs
            java.util.ArrayList<com.calian.paradigm.core.bto.model.gobjs.gen.GEntityWatchMetricsSpecification> specs =
                    com.simfront.midas.managers.DBManager.jDBManager.getEntityWatchSpecs();

            java.util.List<java.util.Map<String, Object>> entities = new java.util.ArrayList<>();

            if (specs != null) {
                for (com.calian.paradigm.core.bto.model.gobjs.gen.GEntityWatchMetricsSpecification s : specs) {
                    long id = s.getEntityWatchMetricsSpecificationObjectItemId();

                    String name = com.simfront.midas.managers.DBManager.jDBManager.getEntityName(id);
                    String symbol = com.simfront.midas.managers.DBManager.jDBManager.getMilitarySymbol(id);
                    Boolean isFriendly = com.simfront.midas.managers.DBManager.jDBManager.objectItemIsFriendly(id);

                    java.util.Map<String, Object> row = new java.util.HashMap<>();
                    row.put("id", id);
                    row.put("name", name != null ? name : "");
                    row.put("isFriendly", isFriendly != null ? isFriendly : false);
                    row.put("milSym", symbol != null ? symbol : com.simfront.midas.managers.DBManager.DEFAULT_CODE);

                    entities.add(row);
                }
            }

            // 2) Return the list directly (not wrapped in "watchedIds")
            return new RequestResults(new java.util.ArrayList<>(entities),
                    com.simfront.midas.constants.MIDASConstants.E_REQUEST_STATUS.SUCCESS);

        } catch (Exception e) {
            return new RequestResults(com.simfront.midas.constants.MIDASConstants.E_REQUEST_STATUS.GENERAL_FAILURE);
        }
    }


    public RequestResults getEntityWatchResults(ArrayList<Object> params) {
        try {
            @SuppressWarnings("unchecked")
            List<Long> entityIds = (List<Long>) params.get(0);
            // long fromTime = (long) params.get(1);
            // long toTime   = (long) params.get(2);

            List<GEntityWatchMetricsResults> raws =
                    DBManager.jDBManager.getEntityWatchMetricsResults();

            if (raws == null) {
                return new RequestResults(new ArrayList<>(),
                        com.simfront.midas.constants.MIDASConstants.E_REQUEST_STATUS.SUCCESS);
            }

            List<Map<String, Object>> out = new ArrayList<>();
            Set<String> seen = new HashSet<>(); //
            Map<Long, Double> lastCpMap = new HashMap<>();

            for (GEntityWatchMetricsResults ew : raws) {
                long entId = ew.getMetricsResultsObjectItemId();
                String cat = ew.getEntityWatchMetricsResultsCategoryCode();

                // Skip if entity is not in the requested list
                if (entityIds != null && !entityIds.isEmpty() && !entityIds.contains(entId)) {
                    continue;
                }

                // --- Create base row (common fields) ---
                Map<String, Object> row = new HashMap<>();
                long simTime = ew.getMetricsResultsTime();
//                String formattedTime = MIDASUtils.applyTimeFormat(
//                        DBManager.jDBManager.getTimeFormat("D+HH:mm"),
//                        simTime
//                );
                long currentTime = System.currentTimeMillis();
                row.put("entityId", entId);
                row.put("entityName", DBManager.jDBManager.getEntityName(entId));
                row.put("time", currentTime);
                row.put("simTime", simTime);
                //row.put("time", simTime);
                // real-world current epoch time
                //row.put("realTime", System.currentTimeMillis());
                //row.put("formattedTime", formattedTime);
                row.put("category", cat);

                String detail = null;
                long recordId = ew.getEntityWatchMetricsResultsEntityWatchMetricsResultId();

                try{
                    if (GEntityWatchMetricsResults.ENTITY_WATCH_METRICS_RESULTS_CATEGORY_CODE_ACT.equals(cat)) {
                        long actionId = ew.getEntityWatchMetricsResultsAssociatedObjectId();
                        GAction act = DBManager.jDBManager.findActionById(actionId);

                        if (act != null && act.getActionReportingOrganisationId() == entId) {
                            detail = act.getActionDescriptionText();
                            if (detail != null) {
                                detail = row.get("entityName") + " performed action: " + detail;
                            } else {
                                detail = "No Action description";
                            }
                        }
                    } else if (GEntityWatchMetricsResults.ENTITY_WATCH_METRICS_RESULTS_CATEGORY_CODE_HOLDING.equals(cat)) {
                        long holdingId = ew.getEntityWatchMetricsResultsAssociatedObjectId();
                        GHolding h = DBManager.jDBManager.findHoldingById(holdingId);
                        detail = h != null ? DBManager.jDBManager.findItemTypeById(h.getHoldingObjectTypeId()) +
                                ", Total quantity = " + h.getHoldingTotalQuantity() +
                                ", Operational quantity= " + h.getHoldingOperationalCount()
                                : "No Holding data";
                    } else if (GEntityWatchMetricsResults.ENTITY_WATCH_METRICS_RESULTS_CATEGORY_CODE_HHOUR.equals(cat)) {
                        long hhourId = ew.getEntityWatchMetricsResultsMetricResultId();
                        GHhourMetricsResults hh = DBManager.jDBManager.findHHourById(hhourId);

                        if (hh != null) {
                            long simTimeCross = hh.getMetricsResultsTime();

                            String formattedTime = MIDASUtils.applyTimeFormat(
                                    DBManager.jDBManager.getTimeFormat("D+HH:mm"),
                                    simTimeCross
                            );

                            detail = row.get("entityName") + " crossed H-Hour line at " + formattedTime +
                                    " (simTime=" + simTimeCross + ")";
                        } else {
                            detail = "No H-Hour crossing data";
                        }
                    } else if (GEntityWatchMetricsResults.ENTITY_WATCH_METRICS_RESULTS_CATEGORY_CODE_CPOWER.equals(cat)) {
                        long cpId = ew.getEntityWatchMetricsResultsMetricResultId();
                        GCombatPowerMetricsResults cp = DBManager.jDBManager.findCombatPowerById(cpId);

                        if (cp != null) {
                            double current = cp.getCombatPowerMetricsResultsCombatPower();
                            Double previous = lastCpMap.get(entId);

                            if (previous != null) {
                                double diff = current - previous;
                                String trend = diff > 0 ? "increased" : diff < 0 ? "decreased" : "no change";

                                detail = String.format(
                                        "Current Combat Power = %.2f | Previous Combat Power = %.2f (%s by %.2f)",
                                        current, previous, trend, Math.abs(diff)
                                );
                            } else {
                                detail = String.format("Current Combat Power = %.2f | Previous Combat Power = N/A (first value)", current);
                            }

                            // update memory for next iteration
                            lastCpMap.put(entId, current);
                        } else {
                            detail = "No CP data";
                        }
                    } else if (GEntityWatchMetricsResults.ENTITY_WATCH_METRICS_RESULTS_CATEGORY_CODE_ENGAGE.equals(cat)) {
                        long eeId = ew.getEntityWatchMetricsResultsMetricResultId();
                        GEnemyEngagementMetricsResults ee = DBManager.jDBManager.findEnemyEngagementById(eeId);

                        if (ee != null) {
                            long simTimeEng = ee.getMetricsResultsTime();
                            String formattedTime = MIDASUtils.applyTimeFormat(
                                    DBManager.jDBManager.getTimeFormat("D+HH:mm"),
                                    simTimeEng
                            );

                            long engaged = ee.getEnemyEngagementMetricsResultsNumberEngaged();
                            long total = ee.getEnemyEngagementMetricsResultsNumberEntities();
                            String cmName = ee.getEnemyEngagementMetricsResultsControlMeasureName();

                            detail = "Enemy engagement at " + formattedTime +
                                    " in control measure [" + cmName + "]: " +
                                    engaged + "/" + total + " entities engaged";
                        } else {
                            detail = "No Enemy Engagement data";
                        }
                    } else if (GEntityWatchMetricsResults.ENTITY_WATCH_METRICS_RESULTS_CATEGORY_CODE_FRAT.equals(cat)) {
                        long fratId = ew.getEntityWatchMetricsResultsMetricResultId();
                        GFratricideMetricsResults frat = DBManager.jDBManager.findFratricideById(fratId);

                        if (frat != null) {
                            long simTimeFrat = frat.getMetricsResultsTime();
                            String formattedTime = MIDASUtils.applyTimeFormat(
                                    DBManager.jDBManager.getTimeFormat("D+HH:mm"),
                                    simTimeFrat
                            );

                            // Identify type
                            String type = frat.getFratricideMetricsResultsCategoryCode();
                            String typeStr;
                            if (GFratricideMetricsResults.FRATRICIDE_METRICS_RESULTS_CATEGORY_CODE_DF.equals(type)) {
                                typeStr = "Direct Fire";
                            } else if (GFratricideMetricsResults.FRATRICIDE_METRICS_RESULTS_CATEGORY_CODE_IDF.equals(type)) {
                                typeStr = "Indirect Fire";
                            } else {
                                typeStr = "Unknown";
                            }

                            detail = "Fratricide (" + typeStr + ") at " + formattedTime;
                        } else {
                            detail = "No Fratricide data";
                        }
                    }
                } catch(Exception e) {
                    detail = "Error in processing record " + recordId;
                }
                if (detail != null) {
                    row.put("detail", detail);

                    // Build composite key
                    //String key = entId + "|" + cat + "|" + detail + "|" + row.get("time");
                    String key = entId + "|" + cat + "|" + detail + "|" + simTime;

                    // Add only if unique
                    if (seen.add(key)) {
                        out.add(row);
                    }
                }
            }
            return new RequestResults(new ArrayList<>(out),
                    com.simfront.midas.constants.MIDASConstants.E_REQUEST_STATUS.SUCCESS);

        } catch (Exception e) {
            return new RequestResults(
                    com.simfront.midas.constants.MIDASConstants.E_REQUEST_STATUS.GENERAL_FAILURE);
        }
    }


    /**
     * Retrieves unique equipment types (Materiel only) associated with selected entities.
     *
     * - Fetches latest holdings for each selected unit at the given end time.
     * - Filters out NOS (Not Otherwise Specified) categories.
     * - Deduplicates equipment types using a "seen" set so each type appears once.
     *
     * @param params [0]: endTime (snapshot time), [1]: selectedEntities (list of unit IDs)
     * @return RequestResults containing a list of equipment maps (typeId, name).
     */

    private RequestResults getEquipmentTypes(ArrayList<Object> params) {
        List<Long> selectedEntities = (List<Long>) params.get(0);

        // Set to track unique equipment type IDs
        Set<Long> seenEquipmentTypes = new HashSet<>();
        List<List<Map<String, Object>>> response = new ArrayList<>();
        List<Map<String, Object>> materiel = new ArrayList<>();
        List<Map<String, Object>> commodities = new ArrayList<>();

        // Loop through entire holding cache (no time filter)
        for (Map<Long, List<GHolding>> snapshot : DBManager.jDBManager.getAllHoldingsFromCache().values()) {
            for (Long entityId : selectedEntities) {
                List<GHolding> holdings = snapshot.get(entityId);
                if (holdings == null){
                    continue;
                }

                for (GHolding h : holdings) {
                    long typeId = h.getHoldingObjectTypeId();
                    if (seenEquipmentTypes.contains(typeId)) {
                        continue;
                    }

                    GObjectType objType = DBManager.jDBManager.getObjectType(typeId);
                    if (objType instanceof GMaterielType) {
                        GMaterielType mt = (GMaterielType) objType;
                        String capabCatCode = mt.getMaterielTypeMaterielCapabilityCategoryCode();

                        Map<String, Object> map = new HashMap<>();
                        // Split based on holdings type
                        if (capabCatCode == null ||
                                GMaterielType.MATERIEL_TYPE_MATERIEL_CAPABILITY_CATEGORY_CODE_NOS.equals(capabCatCode)) {//commodities
                            map.put("equipmentTypeId", typeId);
                            map.put("equipmentName", objType.getObjectTypeNameText());
                            commodities.add(map);
                        } else {//materiel

                            map.put("equipmentTypeId", typeId);
                            map.put("equipmentName", objType.getObjectTypeNameText());
                            materiel.add(map);
                        }

                        // Record this equipment type
                        seenEquipmentTypes.add(typeId);

                    }
                }
            }
        }
        response.add(materiel);
        response.add(commodities);

        return new RequestResults(new ArrayList<>(response), E_REQUEST_STATUS.SUCCESS);
    }


    public RequestResults getHoldingRollupResults(ArrayList<Object> params) {
        // --- 1. Extract parameters ---
        List<Long> selectedEntities = (List<Long>) params.get(0);
        List<Long> selectedEquipmentTypes = (List<Long>) params.get(1);
        long startTime = (long) params.get(2);
        long endTime = (long) params.get(3);

        List<UIOHoldingRollupItem> rollupResults = new ArrayList<>();

        // --- 2. Get precomputed resupply deltas ---
        Map<Long, Map<Long, Double>> resupplyDeltas = DBManager.jDBManager.generateResupplyEvents();

        // --- 3. Get all holding snapshots from cache ---
        Map<Long, Map<Long, List<GHolding>>> allSnapshots = DBManager.jDBManager.getAllHoldingsFromCache();

        // --- 4. Find all relevant snapshot times ---
        TreeSet<Long> validTimes = new TreeSet<>();
        for (Long time : allSnapshots.keySet()) {
            Map<Long, List<GHolding>> entityHoldings = allSnapshots.get(time);

            if (time != -1 && (time < startTime || time > endTime)) {
                continue;
            }

            boolean relevant = false;
            for (Long entityId : selectedEntities) {
                List<GHolding> holdings = entityHoldings.get(entityId);
                if (holdings == null) {
                    continue;
                }

                for (GHolding h : holdings) {
                    if (selectedEquipmentTypes.contains(h.getHoldingObjectTypeId())) {
                        relevant = true;
                        break;
                    }
                }
                if (relevant) {
                    break;
                }
            }

            if (relevant || time == -1) {
                validTimes.add(time);
            }
        }

        // --- 5. Prepare "last known values" for forward-fill ---
        Map<Long, Map<Long, double[]>> lastKnownPerEntity = new HashMap<>();
        for (Long entityId : selectedEntities) {
            lastKnownPerEntity.put(entityId, new HashMap<>());
        }

        // --- 6. Process each snapshot in time order ---
        for (long timeRaw : validTimes) {
            long time = (timeRaw == -1) ? 0 : timeRaw;
            Map<Long, List<GHolding>> holdingsByEntity = allSnapshots.get(timeRaw);

            // Step 6a: Update last known values
            if (holdingsByEntity != null) {
                for (Long entityId : selectedEntities) {
                    List<GHolding> holdings = holdingsByEntity.get(entityId);
                    if (holdings == null) {
                        continue;
                    }

                    Map<Long, double[]> lastKnownEquipments = lastKnownPerEntity.get(entityId);

                    for (GHolding h : holdings) {
                        long eqTypeId = h.getHoldingObjectTypeId();
                        if (!selectedEquipmentTypes.contains(eqTypeId)) {
                            continue;
                        }

                        // Skip NOS category
//                        GObjectType eqType = DBManager.jDBManager.getObjectType(eqTypeId);
//                        if (eqType instanceof GMaterielType) {
//                            String capabCat = ((GMaterielType) eqType)
//                                    .getMaterielTypeMaterielCapabilityCategoryCode();
//                            if (capabCat == null ||
//                                    GMaterielType.MATERIEL_TYPE_MATERIEL_CAPABILITY_CATEGORY_CODE_NOS
//                                            .equals(capabCat)) {
//                                continue;
//                            }
//                        }

                        lastKnownEquipments.put(eqTypeId, new double[]{
                                h.getHoldingTotalQuantity(),
                                h.getHoldingOperationalCount()
                        });
                    }
                }
            }

            // Step 6b: Aggregate totals across all selected entities
            Map<Long, double[]> aggregated = new HashMap<>();
            for (Long entityId : selectedEntities) {
                Map<Long, double[]> lastKnownEquipments = lastKnownPerEntity.get(entityId);
                for (Long eqTypeId : lastKnownEquipments.keySet()) {
                    if (!selectedEquipmentTypes.contains(eqTypeId)) continue;

                    double[] lastKnownValues = lastKnownEquipments.get(eqTypeId);
                    double[] agg = aggregated.computeIfAbsent(eqTypeId, k -> new double[3]);
                    agg[0] += lastKnownValues[0]; // total
                    agg[1] += lastKnownValues[1]; // operational
                }
            }

            // Step 6c: Apply resupply deltas
            if (holdingsByEntity != null) {
                for (Long entityId : selectedEntities) {
                    Map<Long, Double> deltaMap = resupplyDeltas.get(entityId);
                    if (deltaMap == null) {
                        continue;
                    }

                    List<GHolding> holdings = holdingsByEntity.get(entityId);
                    if (holdings == null) {
                        continue;
                    }

                    for (GHolding h : holdings) {
                        long eqTypeId = h.getHoldingObjectTypeId();
                        if (!selectedEquipmentTypes.contains(eqTypeId)) {
                            continue;
                        }

                        Double delta = deltaMap.get(h.getHoldingIndex());
                        if (delta != null) {
                            aggregated.computeIfAbsent(eqTypeId, k -> new double[3])[2] += delta;
                        }
                    }
                }
            }
            String formatted = MIDASUtils.applyTimeFormat(
                    DBManager.jDBManager.getTimeFormat("default"),
                    time
            );

            // Step 6d: Output rows
            for (Long eqTypeId : aggregated.keySet()) {
                double[] values = aggregated.get(eqTypeId);
                GObjectType eqType = DBManager.jDBManager.getObjectType(eqTypeId);

                rollupResults.add(new UIOHoldingRollupItem(
                        eqType.getObjectTypeNameText(),
                        eqTypeId,
                        time,
                        formatted,
                        values[0],
                        values[1],
                        values[2]
                ));
            }
        }

        // --- 7. Sort and return ---
        rollupResults.sort(Comparator.comparingLong(UIOHoldingRollupItem::getTime));

        // --- 8. Group by equipmentTypeId ---
        Map<Long, List<UIOHoldingRollupItem>> groupedByType = new HashMap<>();
        for (UIOHoldingRollupItem item : rollupResults) {
            groupedByType
                    .computeIfAbsent(item.getEquipmentTypeId(), k -> new ArrayList<>())
                    .add(item);
        }
        ArrayList<Object> wrapped = new ArrayList<>();
        wrapped.add(groupedByType);

        return new RequestResults(wrapped, E_REQUEST_STATUS.SUCCESS);
    }


    /**
     * Retrieves equipment contribution per unit (hover drilldown) for a given snapshot time.
     *
     * - For a specific equipment type and time, it lists how much each selected unit contributes.
     * - Uses latest holdings for each unit at the given time.
     * - Computes delta using resupply events only (no fallback to snapshot difference).
     * - Filters out invalid equipment or NOS capability category.
     *
     * @param params [0]: timeFormat (string for formatting time),
     *                [1]: time (snapshot time offset),
     *                [2]: equipmentTypeId (equipment type to analyze),
     *                [3]: selectedEntities (list of unit IDs).
     * @return RequestResults containing a list of unit-level contribution maps.
     */
    private RequestResults getHoldingContribution(ArrayList<Object> params) {
        // Params: [timeFormat, time, equipmentTypeId, selectedEntities]
        String timeFormat = (String) params.get(0);
        long time = (long) params.get(1);
        long equipmentTypeId = (long) params.get(2);
        List<Long> selectedEntities = (List<Long>) params.get(3);

        List<Map<String, Object>> contributionList = new ArrayList<>();

        // Generate resupply deltas map (orgId -> (holdingId -> delta))
        HashMap<Long, Map<Long, Double>> resupplyEvents = DBManager.jDBManager.generateResupplyEvents();

        // Validate that the equipmentTypeId is valid Materiel and NOT NOS
        GObjectType eqType = DBManager.jDBManager.getObjectType(equipmentTypeId);

//        if (!(eqType instanceof GMaterielType)) {
//            return new RequestResults(new ArrayList<>(contributionList), E_REQUEST_STATUS.SUCCESS);
//        }
//        String capabCatCode = ((GMaterielType) eqType).getMaterielTypeMaterielCapabilityCategoryCode();
//        if (capabCatCode == null ||
//                GMaterielType.MATERIEL_TYPE_MATERIEL_CAPABILITY_CATEGORY_CODE_NOS.equals(capabCatCode)) {
//            return new RequestResults(new ArrayList<>(contributionList), E_REQUEST_STATUS.SUCCESS);
//        }

        // For each selected entity, fetch latest holdings
        for (Long entityId : selectedEntities) {
            Map<Long, DBManager.HoldingWithPrevious> holdingInfo =
                    DBManager.jDBManager.getHoldingsWithPreviousFromCache(entityId, time);

            if (holdingInfo.containsKey(equipmentTypeId)) {
                DBManager.HoldingWithPrevious hwp = holdingInfo.get(equipmentTypeId);
                GHolding latest = hwp.jLatest;

                if (latest != null) {
                    // Compute delta: ONLY use resupply events
                    double delta = 0.0;
                    if (resupplyEvents.containsKey(entityId)) {
                        Map<Long, Double> holdingDeltaMap = resupplyEvents.get(entityId);
                        if (holdingDeltaMap.containsKey(latest.getHoldingIndex())) {
                            delta = holdingDeltaMap.get(latest.getHoldingIndex());
                        }
                    }
                    //  No fallback to snapshot comparison here

                    // Build contribution record
                    Map<String, Object> record = new HashMap<>();
                    record.put("unitId", entityId);
                    record.put("unitName", DBManager.jDBManager.getEntityName(entityId));
                    record.put("equipmentName", eqType.getObjectTypeNameText());
                    record.put("milSym", DBManager.jDBManager.getMilitarySymbol(entityId));
                    //record.put("time", latest.getHoldingSimulationOffsetTime());
                    //record.put("formattedTime", MIDASUtils.applyTimeFormat(
                    //DBManager.jDBManager.getTimeFormat(timeFormat), latest.getHoldingSimulationOffsetTime()));
                    record.put("totalQty", latest.getHoldingTotalQuantity());
                    record.put("operationalQty", latest.getHoldingOperationalCount());
                    record.put("delta", delta);

                    contributionList.add(record);
                }
            }
        }

        return new RequestResults(new ArrayList<>(contributionList), E_REQUEST_STATUS.SUCCESS);
    }

    /*
     * Wrapper used by all summary endpoints to guarantee a stable SSE response.
     *
     * Problem before this change:
     * Some summary methods could throw exceptions or return null results.
     * When that happened, the SSE controller received either GENERAL_FAILURE
     * or a null payload, which caused the dashboard summary stream to break.
     * In practice this resulted in the dashboard suddenly showing zeros
     * or stopping updates until a manual refresh.
     *
     * Solution implemented here:
     * - Execute the summary calculation inside a controlled wrapper.
     * - If the supplier returns null, replace it with an empty map.
     * - If any exception occurs, catch it and still return an empty summary.
     *
     * Result:
     * The SSE stream always receives a valid JSON structure:
     *
     *      [ { ...summary values... } ]
     *
     * This guarantees the dashboard remains stable even if a processor fails.
     */
    private RequestResults safeSummary(Supplier<Map<String,Object>> supplier) {
        try {
            Map<String,Object> result = supplier.get();
            if (result == null) {
                result = new HashMap<>();
            }
            ArrayList<Object> wrapped = new ArrayList<>();
            wrapped.add(result);
            return new RequestResults(wrapped, E_REQUEST_STATUS.SUCCESS);
        } catch (Exception e) {
            e.printStackTrace();
            Map<String,Object> empty = new HashMap<>();
            ArrayList<Object> wrapped = new ArrayList<>();
            wrapped.add(empty);
            return new RequestResults(wrapped, E_REQUEST_STATUS.SUCCESS);
        }
    }


    /*
     * All summary calculations are now executed through safeSummary().
     *
     * Previously each summary method manually constructed its own response
     * and error handling. If any exception occurred or a null value was
     * returned, the SSE controller could receive an invalid payload.
     *
     * By routing all summary calculations through safeSummary():
     * - Error handling becomes centralized
     * - Null results are automatically converted to empty summaries
     * - The SSE stream always receives a valid JSON response
     *
     * This change fixes the issue where the dashboard summaries would
     * suddenly reset to zero or stop updating due to failed summary calls.
     */

    /*
     * Why this refactor was necessary:
     *
     * The summary SSE endpoint periodically calls multiple summary methods
     * (CombatPower, POE, Fratricide, ROM, etc.). If any one of these methods
     * returned GENERAL_FAILURE or threw an exception, the SSE payload became
     * incomplete. The frontend interpreted the missing values as zero,
     * causing the dashboard summary panel to suddenly drop to zero.
     *
     * Using safeSummary() ensures every summary always returns a valid
     * structure even if the underlying processor fails temporarily.
     *
     * As a result:
     * - SSE stream never breaks
     * - Dashboard summaries remain stable
     * - Temporary processor errors no longer reset values to zero
     */

    // Count number of entities crossed H-Hour
    public RequestResults getHHourSummary(ArrayList<Object> params) {
        return safeSummary(() -> {
            List<GHhourMetricsResults> results =
                    DBManager.jDBManager.getAllHHourMetricsResults();

            int crossed = results != null ? results.size() : 0;

            Map<String,Object> summary = new HashMap<>();
            summary.put("entitiesCrossed", crossed);
            return summary;
        });
    }

     // Count number of units with combat power between 0 and 100
    public RequestResults getCombatPowerSummary(ArrayList<Object> params) {
        return safeSummary(()->{
            List<GCombatPowerMetricsResults> results =
                    DBManager.jDBManager.getCombatPowerMetricsResults();

            if (results == null) {
                results = Collections.emptyList();
            }

            long below100 = results.stream()
                    .filter(cp -> {
                        double val = cp.getCombatPowerMetricsResultsCombatPower();
                        return val > 0 && val < 100;
                    })
                    .count();

            Map<String, Object> summary = new HashMap<>();
            summary.put("unitsBelow100", below100);

            return summary;
        });
    }

    // Count distinct monitored control measures
    public RequestResults getCMOSummary(ArrayList<Object> params) {
        return safeSummary(()->{

            List<Object> results = DBManager.jDBManager.getCMOccupationMetricsResults();

            Set<Long> uniqueCMs = new HashSet<>();
            if (results != null) {
                for (Object o : results) {
                    if (o instanceof GControlMeasureOccupationMetricsResults) {
                        GControlMeasureOccupationMetricsResults cmo =
                                (GControlMeasureOccupationMetricsResults) o;
                        uniqueCMs.add(cmo.getControlMeasureOccupationMetricsResultsControlMeasureId());
                    }

                }
            }

            Map<String, Object> summary = new HashMap<>();
            summary.put("controlMeasuresMonitored", uniqueCMs.size());

            return summary;

        });
    }

    // Count distinct BLUFOR and OPFOR control measures
    public RequestResults getPOESummary(ArrayList<Object> params) {
        long fromTime = (long) params.get(0);
        long toTime   = (long) params.get(1);
        return safeSummary(()->{

            List<GPictureOfEnemyMetricsResults> results =
                    (List<GPictureOfEnemyMetricsResults>)(List<?>) DBManager.jDBManager.getPOEMetricsResults();

            if (results == null) {
                results = Collections.emptyList();
            }

            int bluforCount = 0;
            int opforCount = 0;

            // Track distinct control measures so we don’t double-count
            Set<Long> seenCMs = new HashSet<>();

            for (GPictureOfEnemyMetricsResults poe : results) {
                long time = poe.getMetricsResultsTime();
                if (time < fromTime || (toTime > 0 && time > toTime)) {
                    continue;
                }

                long cmId = poe.getPictureOfEnemyMetricsResultsControlMeasureId();
                if (seenCMs.contains(cmId)) {
                    continue; // already counted this control measure
                }
                seenCMs.add(cmId);

                // Fetch AObjectItem to access status
                AObjectItem cmItem = DBManager.jDBManager.getAObjectItem(cmId);
                if (cmItem == null) {
                    continue;
                }

                GObjectItemStatus cmStatus = cmItem.getObjectItemStatus();
                if (cmStatus == null) {
                    continue;
                }

                String hostility = cmStatus.getObjectItemStatusHostilityCode();
                if (hostility == null) {
                    continue;
                }

                if (DBManager.jDBManager.objectItemIsFriendly(cmId)) {
                    bluforCount++;
                } else if (GObjectItemStatus.OBJECT_ITEM_STATUS_HOSTILITY_CODE_HO.equals(hostility)) {
                    opforCount++;
                }
            }

            Map<String, Object> summary = new HashMap<>();
            summary.put("bluforControlMeasures", bluforCount);
            summary.put("opforControlMeasures", opforCount);
            return summary;
        });
    }

    // Count distinct fratricide incidents
    public RequestResults getFratricideSummary(ArrayList<Object> params) {
        return safeSummary(()->{
            List<GFratricideMetricsResults> results =
                    DBManager.jDBManager.getFratricideMetricsResults();
            if (results == null) {
                results = Collections.emptyList();
            }

            Set<String> seen = new HashSet<>();

            int incidentCount = 0;

            for (GFratricideMetricsResults r : results) {
                String fratKey = genFratKey(r);
                if (seen.add(fratKey)) {
                    incidentCount++;
                }
            }

            Map<String, Object> summary = new HashMap<>();
            summary.put("incidentCount", incidentCount);

            return summary;

        });
    }
    private String genFratKey(GFratricideMetricsResults r) {
        return r.getFratricideMetricsResultsCategoryCode() + ":" +
                r.getMetricsResultsObjectItemId() + ":" +
                r.getMetricsResultsTime() + ":" +
                r.getFratricideMetricsResultsReceivingObjectItemId() + ":" +
                r.getFratricideMetricsResultsTargetLongitude() + ":" +
                r.getFratricideMetricsResultsTargetLatitude();
    }

    // Return latest engagement with entities and names
    public RequestResults getEnemyEngagementSummary(ArrayList<Object> params) {
        return safeSummary(()->{
            List<GEnemyEngagementMetricsResults> results  =
                    DBManager.jDBManager.getEnemyEngagementMetricsResults();
            if (results == null) {
                results = Collections.emptyList();
            }

            long latestResultId = -1;
            GEnemyEngagementMetricsResults latestResult = null;

            // find latest record where numberEngaged > 0
            for (GEnemyEngagementMetricsResults ee : results) {
                if (ee.getEnemyEngagementMetricsResultsNumberEngaged() > 0 &&
                        ee.getEnemyEngagementMetricsResultsEnemyEngagementMetricsResultId() > latestResultId) {
                    latestResultId = ee.getEnemyEngagementMetricsResultsEnemyEngagementMetricsResultId();
                    latestResult = ee;
                }
            }

            Map<String, Object> summary = new HashMap<>();
            if (latestResult != null) {
                summary.put("controlMeasureId", latestResult.getEnemyEngagementMetricsResultsControlMeasureId());
                summary.put("controlMeasureName", latestResult.getEnemyEngagementMetricsResultsControlMeasureName());
                summary.put("numberEngaged", latestResult.getEnemyEngagementMetricsResultsNumberEngaged());

                // resolve engaged entity IDs → names
                String engagedEntities = latestResult.getEnemyEngagementMetricsResultsEngagedEntities();
                if (engagedEntities != null && !engagedEntities.isEmpty()) {
                    List<String> names = new ArrayList<>();
                    for (String idStr : engagedEntities.split(",")) {
                        try {
                            long entId = Long.parseLong(idStr.trim());
                            String name = DBManager.jDBManager.getEntityName(entId);
                            if (name != null) {
                                names.add(name);
                            }
                        } catch (NumberFormatException ignored) {}
                    }
                    summary.put("engagedEntityNames", names);
                } else {
                    summary.put("engagedEntityNames", Collections.emptyList());
                }
            }

            return summary;

        });
    }

    // Count active ROM control measures within current simulation time
    public RequestResults getROMSummary(ArrayList<Object> params) {
        return safeSummary(()->{
            List<Object> romSpecs = DBManager.jDBManager.getROMSpecs(null);

            long currentSimTime = DBManager.jDBManager.getLatestTime(); // use latest sim time

            int activeCount = 0;
            List<String> activeCMNames = new ArrayList<>();

            if (romSpecs != null) {
                for (Object o : romSpecs) {
                    if (o instanceof UIOROMMetricsSpecification spec) {
                        long start = spec.getTime();      // inherited from UIOBase
                        long end   = spec.getEndTime();

                        if (currentSimTime >= start && currentSimTime <= end) {
                            activeCount++;
                            activeCMNames.add(spec.getControllMeasureName());
                        }
                    }
                }
            }

            Map<String, Object> summary = new HashMap<>();
            summary.put("controlMeasuresMonitored", activeCount);
            summary.put("activeControlMeasureNames", activeCMNames);

            return summary;

        });
    }

    /*
     * EntityWatch specifications may be updated asynchronously while the
     * backend cache is still stabilizing. Reading the count immediately
     * could produce temporary fluctuations (e.g., partial list loads).
     *
     * This method repeatedly reads the count until two consecutive reads
     * return the same value, indicating the cache has stabilized.
     *
     * This prevents the UnitWatch summary from briefly reporting incorrect
     * values in the SSE dashboard.
     */
    private int getStableEntityWatchCount() {

        int previous = -1;
        int current;

        while (true) {

            List<GEntityWatchMetricsSpecification> specs =
                    DBManager.jDBManager.getEntityWatchSpecs();

            current = (specs != null) ? specs.size() : 0;

            System.out.println("[UnitWatch] current count = " + current);

            if (current == previous) {
                System.out.println("[UnitWatch] stable count detected: " + current);
                return current;
            }

            previous = current;

            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return current;
            }
        }
    }

    public RequestResults getEntityWatchSummary(ArrayList<Object> params) {

        return safeSummary(() -> {

            int count = getStableEntityWatchCount();

            Map<String,Object> summary = new HashMap<>();
            summary.put("entitiesWatched", count);

            return summary;
        });
    }




    /**
     * Constructs the ORBAT (Order of Battle) hierarchy and orphan list for frontend consumption.
     *
     * This method:
     * 1. Retrieves all CMDCTL (command-control) associations from the database.
     * 2. Filters only active associations — those with a START status and without an END status.
     * 3. Builds a tree structure of command relationships using UIOOrbatAssociation nodes.
     * 4. Identifies relevant entities that are not part of any active CMDCTL association as orphans.
     * 5. Returns either a hierarchical structure (with children) or a flattened list depending on the flag.
     *
     * @param relevantEntityIds The entity IDs to be included in the ORBAT and orphan scan.
     * @param returnOrbatStyle  If true, returns nested ORBAT hierarchy; otherwise, a flattened list.
     * @return RequestResults containing a combined list of UIOOrbatAssociation (tree nodes) and UIOOrphan objects,
     *         or a flattened UIOBase list for UI display, wrapped in SUCCESS status.
     */

    public RequestResults generateNestedStructure(Set<Long> relevantEntityIds, boolean returnOrbatStyle) {
        System.err.println("Processing ORBAT or Flat List…");

        // STEP 1: Fetch all org-org associations and filter only CMDCTL (command-control) ones
        List<DObjectItemAssociation> assocs = DBManager.jDBManager
                .getOrgOrgAssociations()
                .stream()
                .filter(a -> GObjectItemAssociation.OBJECT_ITEM_ASSOCIATION_CATEGORY_CODE_CMDCTL
                        .equals(a.getObjectItemAssociationCategoryCode()))
                .collect(Collectors.toList());
        // Sets to track child and parent object IDs that are part of active associations
        Set<Long> activeChildIds = new HashSet<>();
        Set<Long> activeParentIds = new HashSet<>();

        // A map of objectId → UIOOrbatAssociation (tree node)
        Map<Long, UIOOrbatAssociation> nodeMap = new HashMap<>();

        // STEP 2: Analyze each association for active status and populate the node map
        for (DObjectItemAssociation assoc : assocs) {
            long parentId = assoc.getParentObjectItemId();
            long childId = assoc.getChildObjectItemId();


            // Skips associations where neither the parent nor child is part of the relevant entity set.
            if (!relevantEntityIds.contains(parentId) && !relevantEntityIds.contains(childId)) {
                continue;
            }

            LinkedList<GObjectItemAssociationStatus> stats = assoc.getStatusLinkedList();
            boolean isActive = false;
            //Scans the status timeline to determine if the association is currently active (started but not ended).
            for (GObjectItemAssociationStatus s : stats) {
                if (assoc.isStart(s)) {
                    isActive = true;
                }
                if (assoc.isEnd(s)) {
                    isActive = false;
                }
            }
            if (!isActive) {
                continue;
            }


            // Record the parent and child as being part of an active CMDCTL association
            activeChildIds.add(childId);
            activeParentIds.add(parentId);

            // Extract unit names and military symbols
            String pName = assoc.getParentObjectItem().getObjectItemNameText();
            String cName = assoc.getChildObjectItem().getObjectItemNameText();
            String parentSym = DBManager.jDBManager.getMilitarySymbol(parentId);
            String childSym = DBManager.jDBManager.getMilitarySymbol(childId);

            boolean parentFriendly = DBManager.jDBManager.objectItemIsFriendly(parentId);
            boolean childFriendly = DBManager.jDBManager.objectItemIsFriendly(childId);

            // Ensure parent and child are both present in nodeMap
            nodeMap.computeIfAbsent(parentId, pid -> {
                UIOOrbatAssociation n = new UIOOrbatAssociation(pid, pName, parentSym);
                n.setIsFriendly(parentFriendly); //
                return n;
            });

            nodeMap.computeIfAbsent(childId, cid -> {
                UIOOrbatAssociation n = new UIOOrbatAssociation(parentId, cid, cName, childSym);
                n.setIsFriendly(childFriendly); //
                return n;
            });
        }

        // STEP 3: Construct the hierarchy by linking child nodes under their parent nodes
        List<UIOOrbatAssociation> roots = new ArrayList<>();
        for (UIOOrbatAssociation node : nodeMap.values()) {
            UIOOrbatAssociation parent = nodeMap.get(node.getParentId());
            if (parent != null && parent.getId() != node.getId()) {
                parent.addChild(node);
            } else {
                roots.add(node);
            }
        }

        // STEP 4: Identify orphans = relevant entities not involved in any active CMDCTL relationship
        List<UIOOrphan> orphanList = new ArrayList<>();

        for (Long id : relevantEntityIds) {
            if (!activeChildIds.contains(id) && !activeParentIds.contains(id)) {
                String name = DBManager.jDBManager.getEntityName(id);
                String symbol = DBManager.jDBManager.getMilitarySymbol(id);
                boolean isFriendly = DBManager.jDBManager.objectItemIsFriendly(id);
                UIOOrphan orphan = new UIOOrphan(id, name, symbol);
                orphan.setIsFriendly(isFriendly); //
                orphanList.add(orphan);
            }
        }

        // STEP 5: Combine results based on output style flag
        ArrayList<Object> combined = new ArrayList<>();
        if (returnOrbatStyle) {
            // Return full hierarchical structure + orphans
            combined.addAll(roots);
            combined.addAll(orphanList);
        } else {
            // Return flattened list for simplified UI display
            for (UIOOrbatAssociation root : roots) {
                flattenOrbat(root, combined);
            }
            for (UIOOrphan orphan : orphanList) {
                combined.add(new UIOBase(orphan.getName(), orphan.getId(), 0, 0));
            }
        }

        return new RequestResults(combined, E_REQUEST_STATUS.SUCCESS);
    }

    /**
     * Recursively flattens a UIOOrbatAssociation tree into a list of UIOBase objects.
     * This is used when returnOrbatStyle is false.
     */
    private void flattenOrbat(UIOOrbatAssociation node, List<Object> flatList) {
        flatList.add(new UIOBase(node.getName(), node.getId(), 0, 0));
        for (UIOOrbatAssociation child : node.getChildren()) {
            flattenOrbat(child, flatList);
        }
    }


    public RequestResults getControlFeatureLocation(ArrayList<Object> params) {
        long dbId = (Long) params.get(0);
        return new RequestResults(DBManager.jDBManager.getControlFeatureLocation(dbId),
                E_REQUEST_STATUS.SUCCESS);
    }

    public RequestResults getMetricsEntities(ArrayList<Object> params) {
        E_METRIC met = (params != null && !params.isEmpty() && params.get(0) instanceof E_METRIC)
                ? (E_METRIC) params.get(0)
                : null;

        HashMap<Long, UIOBase> targetEnts = new HashMap();
        if (met == null) {
            addAllEntities(targetEnts);
            return okSorted(targetEnts);
        } else {
            switch (met) {
                case RATES_OF_MOVEMENT: {
                    // Get metrics results for specified rom spec id
                    long romSpecId = (Long) params.get(1);
                    GRatesOfMovementMetricsResults romr;
                    ArrayList<Object> results
                            = DBManager.jDBManager.getRatesOfMovementsMetricsResults(romSpecId);
                    for (Object o : results) {
                        romr = (GRatesOfMovementMetricsResults) o;
                        long id = romr.getMetricsResultsObjectItemId();

                        UIOBase ei = new UIOBase("", id,
                                romr.getRatesOfMovementMetricsResultsLatitudeCoordinate(),
                                romr.getRatesOfMovementMetricsResultsLongitudeCoordinate());
                        targetEnts.put(id, ei);
                    }
                    break;
                }
                case CM_OCCUPATIONS: {
                    // param(1) = control measure occupation ID
                    List<Long> selectedOccIds = (List<Long>) params.get(1);
                    GControlMeasureOccupationMetricsResults cmRes;
                    ArrayList<Object> results
                            = DBManager.jDBManager.getCMOccupationMetricsResults();
                    for (Object o : results) {
                        cmRes = (GControlMeasureOccupationMetricsResults) o;
                        long occId = cmRes.getControlMeasureOccupationMetricsResultsControlMeasureId();
                        if (selectedOccIds.contains(occId)) {
                            long id = cmRes.getMetricsResultsObjectItemId();
                            UIOBase ei = new UIOBase("", id, 0, 0);
                            targetEnts.put(id, ei);
                        }
                    }
                    break;
                }
                case PICTURE_OF_ENEMY: {
                    GPictureOfEnemyMetricsResults poeRes;
                    ArrayList<Object> results
                            = DBManager.jDBManager.getPOEMetricsResults();
                    for (Object o : results) {
                        poeRes = (GPictureOfEnemyMetricsResults) o;
                        long id = poeRes.getMetricsResultsObjectItemId();

                        UIOBase ei = new UIOBase("", id, 0, 0);
                        targetEnts.put(id, ei);

                        // In addition we also have to get the list of detected entities
                        String detectedEnts = poeRes.getPictureOfEnemyMetricsResultsDetectionEntitiesList();

                        if (detectedEnts != null) {
                            String[] entIds = detectedEnts.split(",");
                            for (String e : entIds) {
                                try {
                                    Long dId = Long.valueOf(e);
                                    if (!targetEnts.containsKey(dId)) {
                                        ei = new UIOBase("", dId, 0, 0);
                                        targetEnts.put(dId, ei);
                                    }
                                } catch (NumberFormatException ignored) {

                                }

                            }
                        }
                    }
                    break;
                }
                case COMBAT_POWER: {
                    Boolean ignoreMinMax = true;
                    if (params.size() == 2) {
                        ignoreMinMax = (Boolean) params.get(1);
                    }
                    ArrayList<GCombatPowerMetricsResults> results
                            = DBManager.jDBManager.getCombatPowerMetricsResults();
                    double cpower;
                    boolean add = false;

                    for (GCombatPowerMetricsResults cpRes : results) {
                        add = false;
                        long id = cpRes.getMetricsResultsObjectItemId();
                        cpower = cpRes.getCombatPowerMetricsResultsCombatPower();

                        if (ignoreMinMax) {
                            if (cpower != 0 && cpower != 100) {
                                add = true;
                            }
                        } else {
                            add = true;
                        }

                        if (add) {
                            UIOBase ei = new UIOBase("", id, 0, 0);
                            targetEnts.put(id, ei);
                        }
                    }
                    break;
                }
                default:
                    break;
            }
        }

        // Now get entity information so that we can set the name on our
        // returned objects
        if (!targetEnts.isEmpty()) {
            ArrayList<AObjectItem> results = DBManager.jDBManager.getEntities();
            for (AObjectItem aoi : results) {
                long id = aoi.getObjectItem().getObjectItemId();
                if (targetEnts.containsKey(id)) {
                    UIOBase ei = targetEnts.get(id);
                    ei.setName(aoi.getObjectItem().getObjectItemNameText());
                    ei.setMilSym(DBManager.jDBManager.getMilitarySymbol(id));
                    ei.setIsFriendly(DBManager.jDBManager.objectItemIsFriendly(id));
                }
            }
        }

        ArrayList<UIOBase> uioEnts = new ArrayList();
        uioEnts.addAll(targetEnts.values());
        Collections.sort(uioEnts, Comparator.comparing(e -> e.getName()));

        ArrayList<Object> ents = new ArrayList(uioEnts);
        return new RequestResults(ents, E_REQUEST_STATUS.SUCCESS);
    }

    private void addAllEntities(Map<Long, UIOBase> targetEnts) {
        ArrayList<AObjectItem> allEntities = DBManager.jDBManager.getEntities();
        for (AObjectItem aoi : allEntities) {
            long id = aoi.getObjectItem().getObjectItemId();
            UIOBase ei = new UIOBase(aoi.getObjectItem().getObjectItemNameText(), id, 0, 0);
            ei.setMilSym(DBManager.jDBManager.getMilitarySymbol(id));
            ei.setIsFriendly(DBManager.jDBManager.objectItemIsFriendly(id));
            targetEnts.put(id, ei);
        }
    }

    private RequestResults okSorted(Map<Long, UIOBase> targetEnts) {
        List<UIOBase> list = new ArrayList<>(targetEnts.values());
        list.sort(Comparator.comparing(
                e -> e.getName() == null ? "" : e.getName(),
                String::compareToIgnoreCase
        ));
        return new RequestResults(new ArrayList<>(list), E_REQUEST_STATUS.SUCCESS);
    }



    public RequestResults getTimeFormats() {
        System.err.println("Processing getTimeFormats()..");
        ArrayList<UIOBase> fmts = DBManager.jDBManager.getTimeFormats();
        ArrayList<Object> results = (ArrayList<Object>) (ArrayList<?>) fmts;
        return new RequestResults(results, E_REQUEST_STATUS.SUCCESS);
    }

    public RequestResults getMinMaxTime(ArrayList<Object> params) {
        String format = (String) params.get(0);
        UIOMinMaxTime res = DBManager.jDBManager.getMinMaxTime(format);
        ArrayList<Object> results = new ArrayList();
        results.add(res);
        return new RequestResults(results, E_REQUEST_STATUS.SUCCESS);
    }

    public RequestResults formatTime(ArrayList<Object> params) {
        Long time = (Long) params.get(0);
        String format = (String) params.get(1);

        String fmtTime = MIDASUtils.applyTimeFormat(
                DBManager.jDBManager.getTimeFormat(format),
                time);

        UIOFormatTime res = new UIOFormatTime();
        res.setTime(time);
        res.setFormattedTime(fmtTime);
        res.setTimeFormat(format);

        ArrayList<Object> results = new ArrayList();
        results.add(res);
        return new RequestResults(results, E_REQUEST_STATUS.SUCCESS);
    }

}
