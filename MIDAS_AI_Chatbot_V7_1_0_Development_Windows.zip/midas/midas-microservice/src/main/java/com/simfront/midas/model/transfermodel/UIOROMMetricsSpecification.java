/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

import com.calian.paradigm.core.bto.model.gobjs.gen.*;

/**
 *
 * @author rhans
 */
public class UIOROMMetricsSpecification extends UIOBase {

    GRatesOfMovementMetricsSpecification jSpec = null;
    String jFormattedEndTime = null;

    public UIOROMMetricsSpecification(GRatesOfMovementMetricsSpecification spec) {
        jSpec = spec;
        super.setId(spec.getMetricsSpecificationId());
        super.setName((spec.getMetricsSpecificationIdentifier()));
        super.setTime(spec.getRatesOfMovementMetricsSpecificationStartTime());
    }

    public long getEndTime() {
        return jSpec.getRatesOfMovementMetricsSpecificationEndTime();
    }

    public void setFormattedEndTime(String t) {
        jFormattedEndTime = t;
    }

    public String getFormattedEndTime() {
        return jFormattedEndTime;
    }

    public long getControlMeasureId() {
        return jSpec.getRatesOfMovementMetricsSpecificationControlMeasureId();
    }
    
    public String getControllMeasureName() {
        return jSpec.getRatesOfMovementMetricsSpecificationControlMeasureName();
    }
}
