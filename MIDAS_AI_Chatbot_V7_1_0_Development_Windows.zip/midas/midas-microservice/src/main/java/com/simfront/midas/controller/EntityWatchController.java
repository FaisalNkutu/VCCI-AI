/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.simfront.midas.CentralDispatch;
import com.simfront.midas.constants.MIDASConstants;
import com.simfront.midas.utils.RequestResults;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.MediaType;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.QueryValue;
import reactor.core.publisher.Flux;

import java.time.Duration;
import java.util.*;

@Controller("/advmetrics/entity-watch")
public class EntityWatchController {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    /**
     * Snapshot endpoint: returns a one-time list of entities currently being watched.
     */
    @Get("/ids")
    public HttpResponse<List<Map<String, Object>>> getWatchedIdsSnapshot() {
        ArrayList<Object> params = new ArrayList<>();
        RequestResults rr = CentralDispatch.jCentralDispatch.processRequest(
                MIDASConstants.E_REQUEST.GET_ENTITY_WATCH_IDS,
                params,
                false
        );

        List<Map<String, Object>> out = safeCastListOfMaps(rr != null ? rr.getResults() : null);
        return HttpResponse.ok(out);
    }


    /**
     * SSE endpoint: streams updates for one or more watched entities
     */
    @Get(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM)
    public Flux<String> streamWatchedEntities(
            @QueryValue List<Long> entityIds,
            @QueryValue(defaultValue = "0") long fromTime,
            @QueryValue(defaultValue = "0") long toTime) {

        final long[] lastSentTime = {
                fromTime
        };

        Flux<String> dataFlux = Flux.interval(Duration.ofSeconds(5))
                .flatMap(tick -> {
                    ArrayList<Object> params = new ArrayList<>();
                    params.add(entityIds);
                    params.add(lastSentTime[0]); // moving lower bound
                    params.add(toTime);

                    RequestResults rr = CentralDispatch.jCentralDispatch.getEntityWatchResults(params);
                    List<Map<String, Object>> allEvents =
                            safeCastListOfMaps(rr != null ? rr.getResults() : null);

                    List<Map<String, Object>> newEvents = new ArrayList<>();
                    long maxTimeSeen = lastSentTime[0];

                    if (tick == 0) {
                        // First snapshot: send everything
                        newEvents.addAll(allEvents);
                        // Advance lastSentTime immediately
                        for (Map<String, Object> ev : allEvents) {
                            //long eventTime = (long) ev.get("time");
                            long eventTime = (long) ev.get("simTime");
                            if (eventTime > maxTimeSeen) {
                                maxTimeSeen = eventTime;
                            }
                        }
                        lastSentTime[0] = maxTimeSeen;
                    } else {
                        // Subsequent ticks: only deltas
                        for (Map<String, Object> event : allEvents) {
                            //long eventTime = (long) event.get("time");
                            long eventTime = (long) event.get("simTime");
                            if (eventTime > lastSentTime[0]) {
                                newEvents.add(event);
                                if (eventTime > maxTimeSeen) {
                                    maxTimeSeen = eventTime;
                                }
                            }
                        }
                        lastSentTime[0] = maxTimeSeen;
                    }

                    if (newEvents.isEmpty()) {
                        return Flux.empty(); // no emission if nothing new
                    } else {
                        // send "time" (latest event time) 
                        String json = toJson(Map.of("time", lastSentTime[0], "results", newEvents));
                        return Flux.just("data: " + json + "\n\n");
                    }
                });

        // Heartbeat to keep connection alive
        Flux<String> heartbeatFlux = Flux.interval(Duration.ofSeconds(30))
                .map(t -> "event: heartbeat\ndata: {\"status\":\"alive\"}\n\n");

        return Flux.merge(dataFlux, heartbeatFlux);
    }

    // Helper to safely cast
    private List<Map<String, Object>> safeCastListOfMaps(Object obj) {
        List<Map<String, Object>> out = new ArrayList<>();
        if (obj instanceof List<?>) {
            for (Object o : (List<?>) obj) {
                if (o instanceof Map) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> row = (Map<String, Object>) o;
                    out.add(row);
                }
            }
        }
        return out;
    }

    // JSON serialization with safe fallback
    private String toJson(Object obj) {
        try {
            return OBJECT_MAPPER.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            return "{}"; // safe fallback instead of throwing
        }
    }
}
