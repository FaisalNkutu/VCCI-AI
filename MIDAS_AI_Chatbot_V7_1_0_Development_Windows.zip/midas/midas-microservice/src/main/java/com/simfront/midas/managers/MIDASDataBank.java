/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */
package com.simfront.midas.managers;

import com.calian.paradigm.core.bto.BTO;
import com.calian.paradigm.core.bto.model.aobjs.AObjectItem;
import com.calian.paradigm.core.bto.model.aobjs.AObjectItemType;
import com.calian.paradigm.core.bto.model.gobjs.gen.*;
import com.calian.paradigm.core.bto.notifications.ObjectItemCreateNotification;
import com.calian.paradigm.core.bto.requests.readreq.GetObjectItemsRequest;
import com.calian.paradigm.core.bto.requests.readreq.GetObjectTypesRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Set;

/**
 *
 * @author rhans - CURRENTLY NOT BEING USED - MAY BE DELETED
 */
public class MIDASDataBank {

    public static MIDASDataBank jDataBank = null;
    private final HashMap<String, AObjectItem> jUnitsHash = new LinkedHashMap<>();
    private final HashMap<String, AObjectItem> jMaterielHash = new LinkedHashMap<>();
    private final HashMap<String, AObjectItem> jPersonsHash = new LinkedHashMap<>();
    private final HashMap<String, AObjectItem> jControlFeaturesHash = new LinkedHashMap<>();
    private final HashMap<String, AObjectItem> jFacilitiesHash = new LinkedHashMap<>();
    private final HashMap<String, AObjectItem> jObjsHash = new LinkedHashMap<>();
    private final HashMap<Long, GObjectType> jObjectTypeHash = new HashMap<>();

    public MIDASDataBank() {
        jDataBank = this;
    }

    public Set<String> getUnitKeys() {
        return jUnitsHash.keySet();
    }

    public Set<String> getMaterielKeys() {
        return jMaterielHash.keySet();
    }

    public Set<String> getPersonsKeys() {
        return jPersonsHash.keySet();
    }

    public Set<String> getControlFeaturesKeys() {
        return jControlFeaturesHash.keySet();
    }

    public Set<String> getFacilitiesKeys() {
        return jFacilitiesHash.keySet();
    }

    public Set<String> getAllObjectKeys() {
        return jObjsHash.keySet();
    }

    public AObjectItem getItem(String id) {
        return jObjsHash.get(id);
    }

    public ArrayList<AObjectItem> getControlFeatures() {
        return new ArrayList(jControlFeaturesHash.values());
    }

    public ArrayList<AObjectItem> getUnits() {
        return new ArrayList(jUnitsHash.values());
    }

    public ArrayList<AObjectItem> getPersons() {
        return new ArrayList(jPersonsHash.values());
    }

    public ArrayList<AObjectItem> getFacilties() {
        return new ArrayList(jFacilitiesHash.values());
    }

    public ArrayList<GObjectType> getObjectTypes() {
        return new ArrayList(jObjectTypeHash.values());
    }

    public boolean isUnit(String id) {
        return jUnitsHash.containsKey(id);
    }

    public boolean isMateriel(String id) {
        return jMaterielHash.containsKey(id);
    }

    public boolean isPerson(String id) {
        return jPersonsHash.containsKey(id);
    }

    public boolean isControlFeature(String id) {
        return jControlFeaturesHash.containsKey(id);
    }

    public boolean isFacility(String id) {
        return jFacilitiesHash.containsKey(id);
    }

    public void processObjectItems(GetObjectItemsRequest req) {
        String id;

        // Units
        for (AObjectItem aoi : req.getUnits()) {
            GObjectItem goi = aoi.getObjectItem();
            id = String.valueOf(goi.getObjectItemId());
            jUnitsHash.put(id, aoi);
            jObjsHash.put(id, aoi);
        }

        // Materiel
        for (AObjectItem aoi : req.getMateriel()) {
            GObjectItem goi = aoi.getObjectItem();
            id = String.valueOf(goi.getObjectItemId());
            jMaterielHash.put(id, aoi);
            jObjsHash.put(id, aoi);
        }

        // Persons
        for (AObjectItem aoi : req.getPersons()) {
            GObjectItem goi = aoi.getObjectItem();
            id = String.valueOf(goi.getObjectItemId());
            jPersonsHash.put(id, aoi);
            jObjsHash.put(id, aoi);
        }

        // Control Features
        for (AObjectItem aoi : req.getControlFeatures()) {
            GObjectItem goi = aoi.getObjectItem();
            id = String.valueOf(goi.getObjectItemId());
            jControlFeaturesHash.put(id, aoi);
            jObjsHash.put(id, aoi);
        }

        // Facilities
        for (AObjectItem aoi : req.getFacilities()) {
            GObjectItem goi = aoi.getObjectItem();
            id = String.valueOf(goi.getObjectItemId());
            jFacilitiesHash.put(id, aoi);
            jObjsHash.put(id, aoi);
        }
    }

    public void processObjectTypes(GetObjectTypesRequest req) {
        for (GObjectType t : req.getObjectTypes()) {
            this.jObjectTypeHash.put(t.getObjectTypeId(), t);
        }
    }

    public void processNotification(BTO obj) {
        if (obj instanceof ObjectItemCreateNotification) {
            ObjectItemCreateNotification oicn = (ObjectItemCreateNotification) obj;
            GObjectItem oi = oicn.getObjectItem();
            if (oi != null) {
                String id = String.valueOf(oi.getObjectItemId());
                jObjsHash.put(id, oicn);
                if (oi instanceof GUnit) {
                    jUnitsHash.put(id, oicn);
                } else if (oi instanceof GMateriel) {
                    jMaterielHash.put(id, oicn);
                } else if (oi instanceof GPerson) {
                    jPersonsHash.put(id, oicn);
                } else if (oi instanceof GControlFeature) {
                    jControlFeaturesHash.put(id, oicn);
                } else if (oi instanceof GFacility) {
                    jFacilitiesHash.put(id, oicn);
                }

                // Cache type if it is new
                AObjectItemType aoit = oicn.getAObjectItemType();
                if (aoit != null) {
                    long typeId = aoit.getObjectType().getObjectTypeId();
                    if (!jObjectTypeHash.containsKey(typeId)) {
                        jObjectTypeHash.put(typeId, aoit.getObjectType());
                    }
                }
            }
        }
    }
}
