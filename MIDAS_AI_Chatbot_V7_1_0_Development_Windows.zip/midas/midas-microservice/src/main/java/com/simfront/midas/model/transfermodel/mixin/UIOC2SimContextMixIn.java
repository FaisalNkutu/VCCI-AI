/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel.mixin;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author p.kuczera
 */
public abstract class UIOC2SimContextMixIn {

    @JsonProperty("id")
    public abstract long getId();

    @JsonProperty("name")
    public abstract String getName();

    @JsonProperty("alias")
    public abstract String getAlias();

    @JsonProperty("type")
    public abstract String getType();

}
