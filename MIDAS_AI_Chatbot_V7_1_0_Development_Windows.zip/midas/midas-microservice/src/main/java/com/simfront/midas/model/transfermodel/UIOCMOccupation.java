/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

package com.simfront.midas.model.transfermodel;

import com.simfront.midas.model.transfermodel.mixin.*;

import java.util.HashMap;
import java.util.Set;

/**
 * @author rhans
 */
public class UIOCMOccupation {

    long jSimulationTime;
    String jFormattedTime;

    public HashMap<Long, Occupation> jOccupationsHM = new HashMap();

    public UIOCMOccupation() {
    }

    /**
     * Method just makes sure that we have an entry for every control measure at
     * this time (zero entries are added for any missing control measure)
     *
     * @param selectedCMIds
     */
    public void ensureEntriesForAllControlMeasures(
            Set<Long> selectedCMIds,
            HashMap<Long, String> names) {
        for (Long cmId : selectedCMIds) {
            // Is there already an entry for this one?
            if (!jOccupationsHM.containsKey(cmId)) {
                // Need to add one (entity count defaults to zero)
                Occupation occ = new Occupation();
                occ.setControlMeasureId(cmId);
                String name = names.get(cmId);
                occ.setControlMeasureName(name);
                jOccupationsHM.put(cmId, occ);
            }
        }
    }

    public void incrementOccupation(
            long cmId,
            String cmName,
            boolean doIncrement) {
        Occupation occ = null;
        if (jOccupationsHM.containsKey(cmId)) {
            occ = jOccupationsHM.get(cmId);
        } else {
            occ = new Occupation();
            occ.setControlMeasureId(cmId);
            occ.setControlMeasureName(cmName);
            jOccupationsHM.put(cmId, occ);
        }
        if (doIncrement) {
            occ.incrementCount();
        }
    }

    public long getSimulationTime() {
        return jSimulationTime;
    }

    public void setSimulationTime(long t) {
        jSimulationTime = t;
    }

    public String getFormattedTime() {
        return jFormattedTime;
    }

    public void setFormattedTime(String ft) {
        jFormattedTime = ft;
    }


}
