 start "MIDAS" java -Xms4096M -Xmx12288M ^
-Djava.net.preferIPv4Stack=true ^
-Dlogback.configurationFile=config/logging.xml ^
-cp target/*;target/dependency/* ^
com.simfront.midas.MIDASApplication