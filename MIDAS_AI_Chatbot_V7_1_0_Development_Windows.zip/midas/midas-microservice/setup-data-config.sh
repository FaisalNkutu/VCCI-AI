#!/bin/sh
#################################################################
# This script is to be run from the product directory that contains
# the target directory.
# It is assumed that the build has been completed successfully
# before running this script.
#################################################################

PRODUCT_RUN_DIR="`pwd`"
PRODUCT_TARGET_DIR="target"
PRODUCT_TARGET_DEPENDENCY_DIR="target/assembly"
PRODUCT_TARGET_TMP_DIR="$PRODUCT_TARGET_DIR/tmp"

if [ ! -d $PRODUCT_TARGET_DIR ]; then
	echo "You must build the project once to grab the required dependencies."
	read junk
	exit 1
fi


####################################################################
# create the directory that will contain the updated files
####################################################################
mkdir data
mkdir config
mkdir data/debug_data
mkdir doc
mkdir ../downloads


#####################################################################
# in case the "tmp" directory exists, delete it.
####################################################################
rm -rf $PRODUCT_TARGET_TMP_DIR


####################################################################
# Get the list of zip data files from target and target/lib 
# directories.
####################################################################
dependency_zips="`ls $PRODUCT_TARGET_DEPENDENCY_DIR/`"
	echo "Target Dependency Zips"
        echo "$dependency_zips"
        echo ""

target_zips="`ls $PRODUCT_TARGET_DIR/*datafiles.zip`"
	echo "Target Zips"
        echo "$target_zips"
        echo ""

expand_zip() {
zips=$@
####################################################################
# For each zip file that exists,
# Expand the file into the tmp directory
# Extract the data and/or config directory and move the content to 
# product runtime directory
####################################################################
for zip in $zips; do
	echo "Processing $zip"
	mkdir $PRODUCT_TARGET_TMP_DIR
	unzip -q -d $PRODUCT_TARGET_TMP_DIR $zip
	
	################################################################
	# the data and/or config directory is contained in a directory
	# whose name is determined by the module that builds it.
	# Only directory exists at this level.
	################################################################
	MODULE_DIR="$PRODUCT_TARGET_TMP_DIR/*"
	for dir in `ls $MODULE_DIR`; do
		# copy instead of move command so that we can merge the dirs
		mkdir "$PRODUCT_RUN_DIR/$dir/"
		cp -r $MODULE_DIR/$dir/* "$PRODUCT_RUN_DIR/$dir/"
		
	done
	
	rm -rf $PRODUCT_TARGET_TMP_DIR
done
}

copy_folders() {
folders=$@
####################################################################
# For each folder file that exists,
# Expand the file into the tmp directory
# Extract the data and/or config directory and move the content to
# product runtime directory
####################################################################
for sub_folder in $folders; do
	echo "Processing $sub_folder"
	ls "$PRODUCT_TARGET_DEPENDENCY_DIR/$sub_folder"

	################################################################
	# the data and/or config directory is contained in a directory
	# whose name is determined by the module that builds it.
	# Only directory exists at this level.
	################################################################
	MODULE_DIR="$PRODUCT_TARGET_DEPENDENCY_DIR/$sub_folder"
	for dir in `ls $MODULE_DIR`; do
		# copy instead of move command so that we can merge the dirs
		echo "copping content from $MODULE_DIR/$dir/* to $PRODUCT_RUN_DIR/$dir/"
		mkdir "$PRODUCT_RUN_DIR/$dir/"
		cp -r $MODULE_DIR/$dir/* "$PRODUCT_RUN_DIR/$dir/"

	done

done
}

copy_folders $dependency_zips
expand_zip $target_zips


####################################################################
# Configure RED
####################################################################
# IP_ADDRESS=`ipconfig | grep "IPv4 Address" | cut -d ":" -f 2`
# echo "hostname = $IP_ADDRESS" > config/red_host_info.txt

####################################################################
# Place copy of doc resources on runtime path
# FIXME: these should be bundled in the vcci jar instead.
####################################################################
# RHans: DO WE NEED THIS --> cp src/main/admin/vcci_prodinfo.html "$PRODUCT_RUN_DIR/doc"
