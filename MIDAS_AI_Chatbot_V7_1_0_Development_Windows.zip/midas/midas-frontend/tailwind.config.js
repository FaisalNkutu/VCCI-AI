/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,ts}",],
  theme: {
    extend: {
      colors:
        {
          'curious-blue': {
            '50': '#f2f8fd',
            '100': '#e4effa',
            '200': '#c2def5',
            '300': '#8dc4ec',
            '400': '#3c9cdd',
            '500': '#298bce',
            '600': '#1a6eaf',
            '700': '#16578e',
            '800': '#164b76',
            '900': '#184062',
            '950': '#102841',
          },
          cyan: {
            50: '#E0F7FA',
            100: '#B2EBF2',
            200: '#80DEEA',
            300: '#4DD0E1',
            400: '#26C6DA',
            500: '#00BCD4',
            600: '#00ACC1',
            700: '#0097A7',
            800: '#00838F',
            900: '#006064',
          },
          orange: {
            50: '#FFF3E0',
            100: '#FFE0B2',
            200: '#FFCC80',
            300: '#FFB74D',
            400: '#FFA726',
            500: '#FF9800',
            600: '#FB8C00',
            700: '#F57C00',
            800: '#EF6C00',
            900: '#E65100',
          },
          matDark: {
            900: '#101415'
          }

        }
    }
    ,
  },
  plugins: [],
}

