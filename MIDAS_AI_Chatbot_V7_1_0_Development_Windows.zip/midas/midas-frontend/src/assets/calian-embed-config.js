/* MIDAS-CALIAN-BRIDGE-V4: isolated local port families, without shared runtime file edits. */
/* For development MIDAS 4200+n embeds CALIAN 4300+n, where 0 <= n <= 99.
 * Production remains administrator-configured: this file intentionally defaults to no iframe URL.
 * Never put credentials in this publicly served configuration file.
 */
(() => {
  const hostname = window.location.hostname;
  const local = hostname === '127.0.0.1' || hostname === 'localhost';
  const midasPort = Number(window.location.port);
  const offset = midasPort - 4200;
  window.__MIDAS_CALIAN_EMBED_URL__ =
    local && Number.isInteger(offset) && offset >= 0 && offset <= 99
      ? `http://127.0.0.1:${4300 + offset}/`
      : '';
})();

// V7 opt-in rollout. Keep disabled until testing with synthetic data completes.
window.__MIDAS_V7_FLAGS__ = { contextV2: false, typedActions: false };
