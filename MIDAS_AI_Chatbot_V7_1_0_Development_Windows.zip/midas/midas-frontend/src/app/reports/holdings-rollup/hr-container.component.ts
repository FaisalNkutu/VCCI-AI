import { Component, OnInit } from '@angular/core';
import { HoldingsRollupComponent } from './holdings-rollup.component';
import { Store } from '@ngrx/store';
import {
  selectEntities,
  selectEquipment,
  selectCommodities,
  selectSelectedEntityIds,
  selectSelectedEquipmentIds,
  selectTimeframe,
  selectReportData,
  selectHrEntityFilters,
} from '@/store/features/hr.feature';
import { AsyncPipe } from '@angular/common';
import { hrActions } from '@/store/actions/hr.actions';
import { selectMinMaxTime } from '@/store/features/sidebar.feature';

@Component({
  selector: 'hr-container',
  imports: [HoldingsRollupComponent, AsyncPipe],
  template: `
    <holdings-rollup-report
      [entities]="(entities$ | async) || []"
      [equipment]="(equipment$ | async) || []"
      [commodities]="(commodities$ | async) || []"
      [timeframe]="(timeframe$ | async) || { start: 0, end: 0 }"
      [selectedEntities]="(selectedEntities$ | async) || []"
      [selectedEquipment]="(selectedEquipment$ | async) || []"
      [reportData]="(reportData$ | async) || {}"
      [timeRange]="(timeRange$ | async) || undefined"
      [entityFilters]="(entityFilters$ | async) || []"
    />
  `,
})
export class HRContainerComponent implements OnInit {
  entities$ = this.store.select(selectEntities);
  equipment$ = this.store.select(selectEquipment);
  commodities$ = this.store.select(selectCommodities);
  timeframe$ = this.store.select(selectTimeframe);
  selectedEntities$ = this.store.select(selectSelectedEntityIds);
  selectedEquipment$ = this.store.select(selectSelectedEquipmentIds);
  reportData$ = this.store.select(selectReportData);
  timeRange$ = this.store.select(selectMinMaxTime);
  entityFilters$ = this.store.select(selectHrEntityFilters);

  constructor(private store: Store) {}

  ngOnInit() {
    this.store.dispatch(hrActions.getEntities());
  }
}
