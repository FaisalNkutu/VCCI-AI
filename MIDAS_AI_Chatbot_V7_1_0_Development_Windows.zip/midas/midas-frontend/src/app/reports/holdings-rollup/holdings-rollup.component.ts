import {
  ChartClickEventData,
  ChartComponent,
} from '@/chart-v3/chart-v3.component';
import { DataViewComponent } from '@/components/data-view/data-view.component';
import { EntitySelectorComponent, FilterStatus } from '@/components/entity-selector/entity-selector.component';
import { GlobalTimeSelectorComponent } from '@/components/time-selector/global-time-selector.component';
import {
  Equipment,
  EquipmentRollupHolding,
  SimEntity,
  Timeframe,
  TimeMinMax,
} from '@/models';
import { hrActions } from '@/store/actions/hr.actions';
import { StepperSelectionEvent } from '@angular/cdk/stepper';

import { Component, computed, input, Input, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatCheckbox } from '@angular/material/checkbox';
import { MatChipsModule } from '@angular/material/chips';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatStepper, MatStepperModule } from '@angular/material/stepper';
import { Store } from '@ngrx/store';
import { SFTreeMetaData } from '@simfront/common-libs';
import { HoldingRollupTableDialog } from './hr-table-dialog.component';

@Component({
  selector: 'holdings-rollup-report',
  imports: [
    EntitySelectorComponent,
    MatButtonModule,
    MatStepperModule,
    MatCardModule,
    MatChipsModule,
    DataViewComponent,
    MatIconModule,
    GlobalTimeSelectorComponent,
    MatCheckbox,
    ChartComponent
],
  templateUrl: './holdings-rollup.component.html',
})
export class HoldingsRollupComponent {
  entities = input.required<SimEntity[]>();
  equipment = input.required<Equipment[]>();
  commodities = input.required<Equipment[]>();
  selectedEntities = input.required<number[]>();
  selectedEquipment = input.required<number[]>();
  @Input() timeframe: Timeframe = { start: 0, end: 0 };
  @Input() reportData: any;
  @Input() timeRange: TimeMinMax | undefined;
  @Input() entityFilters: FilterStatus[] = [];

  @ViewChild('stepper') stepper!: MatStepper;

  currentStepIndex = 0;
  totalSteps = 4;

  allSelectedEquipment = computed(() =>
    this.equipment().every((eq) =>
      this.selectedEquipment().includes(eq.equipmentTypeId)
    )
  );

  selectedEquipmentCount = computed(
    () =>
      this.equipment().filter((eq) =>
        this.selectedEquipment().includes(eq.equipmentTypeId)
      ).length
  );

  allSelectedCommodities = computed(() =>
    this.commodities().every((eq) =>
      this.selectedEquipment().includes(eq.equipmentTypeId)
    )
  );

  selectedCommoditiesCount = computed(
    () =>
      this.commodities().filter((eq) =>
        this.selectedEquipment().includes(eq.equipmentTypeId)
      ).length
  );

  constructor(private store: Store, private dialog: MatDialog) {}

  chartAdaptor = (item: any) => ({
    label: item.equipmentName,
    xValue: item.time,
    yValue: item.operationalQty,
    xLabel: item.formattedTime,
  });

  trackByEquipment(index: number, item: Equipment): string {
    return item.equipmentTypeId.toString();
  }

  onEntitySelectionChange({
    selected,
    items,
  }: {
    selected: boolean;
    items: SimEntity[];
  }) {
    this.store.dispatch(hrActions.entitySelected({ selected, items }));
  }

  onEquipmentSelectionChange({
    selected,
    items,
  }: {
    selected: boolean;
    items: Equipment[];
  }) {
    this.store.dispatch(hrActions.equipmentSelected({ selected, items }));
  }

  onStepChange(event: StepperSelectionEvent) {
    this.currentStepIndex = event.selectedIndex;

    if (event.selectedIndex > event.previouslySelectedIndex) {
      switch (event.selectedIndex) {
        case 1:
          this.store.dispatch(hrActions.getEquipment());
          break;
        case 2:
          if (this.timeframe.end === 0) {
            this.store.dispatch(
              hrActions.timeframeChange({
                start: this.timeRange?.minTime || 0,
                end: this.timeRange?.maxTime || 0,
              })
            );
          }
          break;
        case 3:
          this.store.dispatch(hrActions.generateReport());
          break;
        default:
          break;
      }
    }
  }

  toggleAllEquipment(selected: boolean) {
    this.onEquipmentSelectionChange({
      selected,
      items: this.equipment(),
    });
  }

  toggleAllCommodities(selected: boolean) {
    this.onEquipmentSelectionChange({
      selected,
      items: this.commodities(),
    });
  }

  onChartClicked(event: ChartClickEventData<EquipmentRollupHolding>) {
    this.store.dispatch(
      hrActions.holdingsContributionSelected({
        equipmentId: event.point.equipmentTypeId,
        time: event.point.time,
      })
    );
    this.dialog.open(HoldingRollupTableDialog, {
      data: { ...event.point },
    });
  }

  onTimeframeChange(timeframe: Timeframe) {
    this.store.dispatch(hrActions.timeframeChange(timeframe));
  }

  nextStep() {
    if (this.stepper && this.currentStepIndex < this.totalSteps - 1) {
      this.stepper.next();
    }
  }

  previousStep() {
    if (this.stepper && this.currentStepIndex > 0) {
      this.stepper.previous();
    }
  }

  resetStepper() {
    if (this.stepper) {
      this.stepper.reset();
      this.currentStepIndex = 0;
      this.store.dispatch(hrActions.resetState());
    }
  }

  isCurrentStepValid(index: number): boolean {
    // Add your validation logic here based on current step
    switch (index) {
      case 0:
        return this.selectedEntities().length > 0;
      case 1:
        return this.selectedEquipment().length > 0;
      default:
        return true;
    }
  }

  metaData: SFTreeMetaData<SimEntity, string> = {
    controlTrackBy: (n) => `${n.id}`,
    children: (n) => n.children,
    childrenProp: 'children',
    label: (n) => n.name,
  };

  onEntityFilterChange(filters: FilterStatus[]) {
    this.store.dispatch(hrActions.entityFilterChange(filters));
  }
}
