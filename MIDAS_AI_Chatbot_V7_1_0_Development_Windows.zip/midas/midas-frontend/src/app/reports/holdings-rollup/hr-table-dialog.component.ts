import {
  ChartDialogColumn,
  ChartDialogComponent,
} from '@/components/dialog/chart-dialog/chart-dialog.component';
import { EquipmentRollupHolding } from '@/models';
import { selectHoldingsContribution } from '@/store/features/hr.feature';
import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';

@Component({
  selector: 'hr-table-dialog',
  imports: [ChartDialogComponent],
  template: `<chart-dialog
    dialogTitle="Holding Contribution Details"
    [subTitle]="data.equipmentName"
    subTitleDescription="Eqipuipment Name"
    [time]="data.formattedTime"
    [data]="dataSource"
    [columns]="columns"
  /> `,
})
export class HoldingRollupTableDialog implements OnInit, OnDestroy {
  columns: ChartDialogColumn<EquipmentRollupHolding>[] = [
    {
      header: 'Symbol',
      cell: (e) => e.milSym,
      symbol: true,
    },
    {
      header: 'Entity Name',
      cell: (e) => e.unitName,
    },
    {
      header: 'Total Quantity',
      cell: (e) => e.totalQty,
    },
    {
      header: 'Operational Quantity',
      cell: (e) => e.operationalQty,
    },
    {
      header: 'Delta',
      cell: (e) => e.delta,
    },
  ];
  subscription: Subscription = new Subscription();
  dataSource: EquipmentRollupHolding[] = [];

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: EquipmentRollupHolding,
    private store: Store
  ) {}

  ngOnInit(): void {
    this.subscription = this.store
      .select(selectHoldingsContribution)
      .subscribe((data) => {
        this.dataSource = data;
      });
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
