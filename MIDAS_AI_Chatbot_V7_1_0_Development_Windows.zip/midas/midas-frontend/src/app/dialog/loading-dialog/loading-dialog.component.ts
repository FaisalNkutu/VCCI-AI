import { Component, Inject, Input } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogContent } from '@angular/material/dialog';
import { MatProgressSpinner } from '@angular/material/progress-spinner';

@Component({
    selector: 'app-loading-dialog',
    imports: [
        MatDialogContent,
        MatProgressSpinner
    ],
    templateUrl: './loading-dialog.component.html'
})
export class LoadingDialogComponent {
  constructor(@Inject(MAT_DIALOG_DATA) public data: { text: string }) {
  }
}
