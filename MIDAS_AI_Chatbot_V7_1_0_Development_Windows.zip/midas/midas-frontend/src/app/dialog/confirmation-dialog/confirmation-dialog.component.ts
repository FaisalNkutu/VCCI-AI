import { Component } from '@angular/core';
import { MatListOption, MatSelectionList } from '@angular/material/list';
import { MatDialogActions, MatDialogContent, MatDialogTitle } from '@angular/material/dialog';
import { MatButton } from '@angular/material/button';
import { HttpClient } from '@angular/common/http';
import { NgForOf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Store } from '@ngrx/store';
import { sidebarActions } from '@/store/actions/sidebar.actions';

@Component({
  selector: 'app-confirmation-dialog',
  standalone: true,
  imports: [
    MatSelectionList,
    MatListOption,
    MatDialogContent,
    MatDialogTitle,
    MatDialogActions,
    MatButton,
    NgForOf,
    FormsModule
  ],
  templateUrl: './confirmation-dialog.component.html'
})
export class ConfirmationDialogComponent {
  databases: string[] = [];
  selectedDB: [string] = [''];

  constructor(private _httpClient: HttpClient, private store: Store) {
    this._httpClient.get<string[]>('http://127.0.0.1:10001/advmetrics/omdbdata/databases').subscribe(dbs => {
      this.databases = dbs;
    });
  }

  onSelectionChange(event: any): void {
    console.log(this.selectedDB);
  }


  onDatabaseSelected(): void {
    const db = this.selectedDB[0];
    this.store.dispatch(sidebarActions.getMinMaxTime());
    this._httpClient.post('http://127.0.0.1:10001/advmetrics/omdbdata/selectdb', db).subscribe(console.log);
  }


}
