import { FilterStatus } from '@/components/entity-selector/entity-selector.component';
import { HHourSpecs, LodLocation, payload, Unit } from '@/models';
import { createActionGroup, emptyProps, props } from '@ngrx/store';

export const hhourActions = createActionGroup({
  source: 'HHour',
  events: {
    'Units Loaded': props<{ units: Unit[]; hHour: HHourSpecs | null }>(),
    'Get HHour Data': emptyProps(),
    'HHour Data Loaded': props<{ data: HHourSpecs[]; id: number }>(),
    'HHour Selection': payload<{ hHour: HHourSpecs }>(),
    'Batch Unit Selection': payload<{
      unitIds: number[];
      selection: boolean;
    }>(),
    'LOD Info Loaded': props<{ lod: LodLocation[] }>(),
    'Threshold Changed': props<{
      threshold: number;
      hHour: HHourSpecs;
      entityIds: number[];
    }>(),
    'Achieved HHour Loaded': payload<number>(),
    'Entity Filter Change': payload<FilterStatus[]>()
  },
});
