import { FilterStatus } from '@/components/entity-selector/entity-selector.component';
import { SimEntity, UnitWatchResults, UpdateCategory } from '@/models';
import { createActionGroup, emptyProps } from '@ngrx/store';
import { payload } from '@simfront/common-libs';

export const unitWatchActions = createActionGroup({
  source: 'unit-watch',
  events: {
    'Get Units': emptyProps(),
    'Units Loaded': payload<SimEntity[]>(),
    'Unit Watch Event Received': payload<UnitWatchResults>(),
    'Clear Unit Watch Events': emptyProps(),
    'Unit Selected': payload<number>(),
    'Unit Deselected': payload<number>(),
    'Batch Unit Selection': payload<{
      unitIds: number[];
      selection: boolean;
    }>(),
    'Set Category Filter Selected': payload<UpdateCategory>(),
    'Set Category Filter Deselected': payload<UpdateCategory>(),
    'Entity Filter Change': payload<FilterStatus[]>(),
  },
});
