import {
  EnemyEngagementControlMeasure,
  EnemyEngagementPoint,
  EnemyEngagementUnit,
  payload,
  Timeframe
} from '@/models';
import { createActionGroup, emptyProps } from '@ngrx/store';

export const enemyEngagementActions = createActionGroup({
  source: 'Enemy Engagement',
  events: {
    'Get Control Measures': emptyProps(),
    'Control Measures Loaded': payload<EnemyEngagementControlMeasure[]>(),
    'Get Entity Details': emptyProps(),
    'Entity Details Loaded': payload<EnemyEngagementUnit[]>(),
    'Blue Timeframe Changed': payload<Timeframe>(),
    'Red Timeframe Changed': payload<Timeframe>(),
    'Red Engagement Results Loaded': payload<EnemyEngagementPoint[]>(),
    'Blue Engagement Results Loaded': payload<EnemyEngagementPoint[]>(),
    'Blue Control Measure Selected': payload<EnemyEngagementControlMeasure>(),
    'Red Control Measure Selected': payload<EnemyEngagementControlMeasure>(),
    'Chart Point Selected': payload<{
      cmID: number;
      isBlue: boolean;
      index: number;
      datasetIndex: number;
      isEngaged: boolean;
    }>(),
  },
});
