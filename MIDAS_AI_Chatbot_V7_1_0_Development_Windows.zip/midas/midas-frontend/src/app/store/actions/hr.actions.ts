import { FilterStatus } from '@/components/entity-selector/entity-selector.component';
import { Equipment, payload, SimEntity, Timeframe } from '@/models';
import { createActionGroup, emptyProps } from '@ngrx/store';

export const hrActions = createActionGroup({
  source: 'Holdings Rollup',
  events: {
    'Get Entities': emptyProps(),
    'Entities Loaded': payload<SimEntity[]>(),
    'Entity Selected': payload<{ selected: boolean; items: SimEntity[] }>(),
    'Get Equipment': emptyProps(),
    'Equipment Loaded': payload<Equipment[][]>(),
    'Commodities Loaded': payload<Equipment[][]>(),
    'Equipment Selected': payload<{ selected: boolean; items: Equipment[] }>(),
    'Timeframe Change': payload<Timeframe>(),
    'Generate Report': emptyProps(),
    'Report Generated': payload<any>(),
    'Holdings Contribution Selected': payload<{
      equipmentId: number;
      time: number;
    }>(),
    'Holdings Contribution Loaded': payload<any>(),
    'Reset State': emptyProps(),
    'Entity Filter Change': payload<FilterStatus[]>()
  },
});
