import {
  ConnectedDB,
  payload,
  StatusData,
  TimeFormat,
  TimeMinMax,
} from '@/models';
import { WMTSOptions } from '@/services/tile-layer-wmts';
import { createActionGroup, emptyProps } from '@ngrx/store';

export const sidebarActions = createActionGroup({
  source: 'Sidebar',
  events: {
    'Get Time Formats': emptyProps(),
    'Time Formats Loaded': payload<TimeFormat[]>(),
    'Time Format Selected': payload<string>(),
    'Get Min Max Time': emptyProps(),
    'Min Max Time Loaded': payload<TimeMinMax>(),
    'Status Data Received': payload<StatusData>(),
    'Get Map Server URL': emptyProps(),
    'Map Server URL Loaded': payload<string>(),
    'Resolved Map URL Loaded': payload<{
      url: string;
      wmtsOptions: WMTSOptions | undefined;
    }>(),
    'Resize Panel Drag End': emptyProps(),
    'Get Connected DB': emptyProps(),
    'Connected DB Loaded': payload<ConnectedDB>(),
  },
});
