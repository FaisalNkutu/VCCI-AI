import { payload } from '@/models';
import { createActionGroup } from '@ngrx/store';

export const summaryActions = createActionGroup({
  source: 'Summary',
  events: {
    'Data Received': payload<any>(),
  },
});
