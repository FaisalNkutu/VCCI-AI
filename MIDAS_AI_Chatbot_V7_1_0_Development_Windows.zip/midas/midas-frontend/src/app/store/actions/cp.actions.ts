import { FilterStatus } from '@/components/entity-selector/entity-selector.component';
import {
  CombatPowerDataGrouping,
  CombatPowerEntityDetails,
  CombatPowerEquipmentDetails,
  CombatPowerEquipmentTableData,
  CombatPowerTableData,
  payload,
  SimEntity,
  Timeframe,
} from '@/models';
import { createActionGroup, emptyProps } from '@ngrx/store';

export const cpActions = createActionGroup({
  source: 'cp',
  events: {
    'Get Entities': emptyProps,
    'Entities Loaded': payload<SimEntity[]>(),
    'Entity Selected': payload<number>(),
    'Entity Deselected': payload<number>(),
    'Timeframe Change': payload<Timeframe>(),
    'Entity Details Loaded': payload<CombatPowerEntityDetails>(),
    'Entity Equipment Details Loaded': payload<CombatPowerEquipmentDetails>(),
    'Combat Power Point Selected': payload<{
      entityId: number;
      time: number;
    }>(),
    'Combat Power Equipment Point Selected': payload<{
      equipmentType: string;
      time: number;
    }>(),
    'Combat Power Data Loaded': payload<CombatPowerTableData>(),
    'Combat Power Equipment Data Loaded':
      payload<CombatPowerEquipmentTableData[]>(),
    'Include All Changed': payload<boolean>(),
    'Data Grouping Changed': payload<CombatPowerDataGrouping>(),
    'Batch Entity Selection': payload<{
      entityIds: number[];
      selected: boolean;
    }>(),
    'Entity Filter Change': payload<FilterStatus[]>(),
  },
});
