import { FilterStatus } from '@/components/entity-selector/entity-selector.component';
import {payload, ROMEntity, ROMEntityDetails, ROMSpec, ROMStats, Timeframe} from '@/models';
import { createActionGroup, emptyProps } from '@ngrx/store';

export const romActions = createActionGroup({
  source: 'rom',
  events: {
    'Get Data': emptyProps(),
    'Data Loaded': payload<ROMSpec[]>(),
    'Capture Selected': payload<ROMSpec>(),
    'Capture Loaded': payload<ROMSpec>(),
    'Stats Loaded': payload<ROMStats>(),
    'Entities Loaded': payload<ROMEntity[]>(),
    'Entity Selected': payload<number>(),
    'Entity Deselected': payload<number>(),
    'Batch Entity Selection': payload<{
      entityIds: number[];
      selected: boolean;
    }>(),
    'Entity Details Loaded': payload<ROMEntityDetails[]>(),
    'Ref Threshold Changed': payload<number>(),
    'Entity Query': payload<string | null>(),
    'Entity Filter Change': payload<FilterStatus[]>(),
    'Timeframe Change': payload<Timeframe>(),
  },
});
