import { FilterStatus } from '@/components/entity-selector/entity-selector.component';
import {
  CmChartData,
  CMEntity,
  ControlMeasure,
  payload,
  SFMap,
  SimEntity,
  Timeframe,
} from '@/models';
import { createActionGroup, emptyProps } from '@ngrx/store';

export const cmActions = createActionGroup({
  source: 'CMOC',
  events: {
    'Get Entities': emptyProps,
    'Entities Loaded': payload<SimEntity[]>(),
    'Get Control Measures': emptyProps(),
    'Control Measures Loaded': payload<ControlMeasure[]>(),
    'Selected Control Measures Loaded': payload<SFMap<CMEntity[]>>(),
    'Timeframe Change': payload<Timeframe>(),
    'Chart Data Loaded': payload<SFMap<CmChartData>>(),
    'Control Measure Selected': payload<number>(),
    'Control Measure Deselected': payload<number>(),
    'Unit Selected': payload<number>(),
    'Unit Deselected': payload<number>(),
    'Batch Unit Selection': payload<{
      unitIds: number[];
      selection: boolean;
    }>(),
    'Get Occupying Units': payload<{ cmId: number; time: number }>(),
    'Occupying Units Loaded': payload<{
      cmId: number;
      time: number;
      units: SimEntity[];
    }>(),
    'Entity Filter Change': payload<FilterStatus[]>(),
  },
});
