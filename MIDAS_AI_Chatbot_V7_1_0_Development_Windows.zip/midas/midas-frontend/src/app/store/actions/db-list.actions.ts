import { createActionGroup, emptyProps, props } from '@ngrx/store';


export const databaseActions = createActionGroup({
  source: 'Database Select',
  events: {
    'Chosen': props<{ name: string }>(),
    'Chosen Database Loaded': props<{ name: string }>(),
    'Load': emptyProps(),
    'Databases Loaded': props<{ databases: string[] }>()
  }
});


