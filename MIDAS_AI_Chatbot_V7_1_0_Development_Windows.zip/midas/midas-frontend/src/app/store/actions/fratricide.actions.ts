import {
  FratIncident,
  FratricideGraphPoint,
  payload,
  Timeframe
} from '@/models';
import { createActionGroup, emptyProps } from '@ngrx/store';

export const fratricideActions = createActionGroup({
  source: 'fratricide',
  events: {
    'Get Results': emptyProps(),
    'Results Loaded': payload<FratricideGraphPoint[]>(),
    'Timeframe Change': payload<Timeframe>(),
    'Get Incidents at Time': payload<number>(),
    'Incidents at Time Loaded': payload<FratIncident[]>(),
    'Point Selected': payload<number>(),
    'Frat Incident Selected': payload<FratIncident>(),
    'Incident Details Loaded': payload<FratIncident[]>(),
  },
});
