import { C2Context, SimEntity, Timeframe, payload } from '@/models';
import { createActionGroup, emptyProps } from '@ngrx/store';

export const c2Actions = createActionGroup({
  source: 'c2',
  events: {
    'Timeframe Change': payload<Timeframe>(),
    'Get C2 Context': emptyProps(),
    'C2 Context Loaded': payload<C2Context[]>(),
    'Context Selected': payload<string>(),
    'Context Deselected': payload<string>(),
    'Units Loaded': payload<{ uniqueId: string; units: SimEntity[] }>(),
    'Select All Contexts': payload<boolean>(),
  },
});

