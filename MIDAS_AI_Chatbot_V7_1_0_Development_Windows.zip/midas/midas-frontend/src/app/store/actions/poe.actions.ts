import {
  ControlMeasure,
  payload,
  POEPoint,
  Timeframe
} from '@/models';
import { createActionGroup, emptyProps } from '@ngrx/store';

export const poeActions = createActionGroup({
  source: 'POE',
  events: {
    'Get Control Measures': emptyProps(),
    'Control Measures Loaded': payload<ControlMeasure[]>(),
    'Control Measure Selected': payload<number>(),
    'Control Measure Deselected': payload<number>(),
    'Get Points': emptyProps(),
    'Points Loaded': payload<POEPoint[]>(),
    'Blue Timeframe Changed': payload<Timeframe>(),
    'Red Timeframe Changed': payload<Timeframe>(),
  },
});
