import { API_URL } from '@/app.config';
import {ROMEntity, ROMEntityDetails, ROMSpec, ROMStats} from '@/models';
import { sidebarActions } from '@/store/actions/sidebar.actions';
import { selectSelectedTimeFormat } from '@/store/features/sidebar.feature';
import {HttpClient, HttpParams} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { filter, map, of, switchMap, withLatestFrom } from 'rxjs';
import { romActions } from '../actions/rom.actions';
import {
  selectCurrentRomSpec,
  selectTimeframe,
  selectSelectedEntities,
} from '../features/rom.feature';
import { selectUrl } from '../selectors/route.selectors';
import { routes } from '@/utils/routes';

const ROUTE = routes['ROM'].route;

@Injectable()
export class RomEffects {
  selectedRom$ = this.store.select(selectCurrentRomSpec);
  selectedEntities$ = this.store.select(selectSelectedEntities);
  timeFormat$ = this.store.select(selectSelectedTimeFormat);
  timeframe$ = this.store.select(selectTimeframe);

  route$ = this.store.select(selectUrl);

  constructor(
    private actions$: Actions,
    private httpClient: HttpClient,
    private store: Store
  ) {}

  /**
   * Get the initial data of all the available captures. This is triggered on initial
   * dashboard load
   */
  getData$ = createEffect(() =>
    this.actions$.pipe(
      ofType(romActions.getData, sidebarActions.timeFormatSelected),
      withLatestFrom(this.timeFormat$),
      switchMap(([_, timeFormat]) => {
        return this.httpClient
          .get<ROMSpec[]>(`${API_URL}/advmetrics/rom/specs?format=${timeFormat}`)
          .pipe(
            map((res) => {
              return romActions.dataLoaded(res);
            })
          );
      })
    )
  );

  getStats = createEffect(() =>
    this.actions$.pipe(
      ofType(
        romActions.captureSelected,
        romActions.entitySelected,
        romActions.entityDeselected,
        romActions.batchEntitySelection,
        romActions.timeframeChange,
      ),
      withLatestFrom(
        this.route$,
        this.selectedEntities$,
        this.selectedRom$,
        this.timeframe$,
      ),
      filter(([_ , route]) => route.includes(ROUTE)),
      switchMap(([_, __, selectedEntities, selectedROM, timeframe]) => {

        const params = new HttpParams()
          .append("romSpecId", selectedROM?.id || '')
          .append('startTime', timeframe.start)
          .append('endTime', timeframe.end)
          .append("selectedIds", selectedEntities.map(v => v.id).join(','));

        return this.httpClient
          .get<ROMStats>(`${API_URL}/advmetrics/rom/stats`, {params})
          .pipe(map((res) => romActions.statsLoaded(res)));
      })
    )
  );

  /**
   * When a capture is selected, if this is triggered from an initial data load, select the first capture to get the
   *  entities for or else use the selected capture to get the entities for
   */
  captureSelected$ = createEffect(() =>
    this.actions$.pipe(
      ofType(
        romActions.captureSelected,
        romActions.dataLoaded,
        sidebarActions.timeFormatSelected
      ),
      withLatestFrom(this.selectedRom$, this.timeFormat$),
      switchMap(([_, selectedROM, timeFormat]) => {
        return this.httpClient
          .get<ROMEntity[]>(
            `${API_URL}/advmetrics/rom/entities?romSpecId=${selectedROM?.id}&format=${timeFormat}`
          )
          .pipe(
            map((res) =>
              romActions.entitiesLoaded(
                res.map((e) => ({
                  ...e,
                  children: e.children ? e.children : [],
                }))
              )
            )
          );
      })
    )
  );

  getSelectedEntityDetails$ = createEffect(() =>
    this.actions$.pipe(
      ofType(
        romActions.entitySelected,
        romActions.entityDeselected,
        romActions.batchEntitySelection,
        romActions.timeframeChange,
        sidebarActions.timeFormatSelected
      ),
      withLatestFrom(
        this.route$,
        this.selectedEntities$,
        this.selectedRom$,
        this.timeFormat$,
        this.timeframe$,
      ),
      filter(([_ , route]) => route.includes(ROUTE)),
      switchMap(([_, __, selectedEntities, selectedROM, timeFormat, timeframe]) => {
        //if the last entity is unselected nothing to get
        if (selectedEntities.length === 0) {
          return of(romActions.entityDetailsLoaded([]));
        }

        const params = new HttpParams()
          .append("romSpecId", selectedROM?.id || '')
          .append('timeFormat', timeFormat || '')
          .append('startTime', timeframe.start)
          .append('endTime', timeframe.end)
          .append("selectedIds", selectedEntities.map(v => v.id).join(','));

        return this.httpClient
          .get<ROMEntityDetails[]>(`${API_URL}/advmetrics/rom/rom-results`, {params})
          .pipe(map((res) => romActions.entityDetailsLoaded(res)));
      })
    )
  );

  updateTimeframe$ = createEffect(() =>
    this.actions$.pipe(
      ofType(sidebarActions.minMaxTimeLoaded),
      withLatestFrom(this.route$),
      filter(([_, route]) => route.includes(ROUTE)),
      map((_) => {
        return romActions.getData();
      })
    )
  );
}
