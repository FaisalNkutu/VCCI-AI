import { API_URL } from '@/app.config';
import {
  EnemyEngagementControlMeasure,
  EnemyEngagementPoint,
  EnemyEngagementUnit,
} from '@/models';
import {
  selectBlueTimeframe,
  selectRedTimeframe,
  selectSelectedBlueControlMeasure,
  selectSelectedChartPoint,
  selectSelectedRedControlMeasure,
} from '@/store/features/enemy-engagement.feature';
import { selectSelectedTimeFormat } from '@/store/features/sidebar.feature';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Action, Store } from '@ngrx/store';
import { filter, map, mergeMap, switchMap, withLatestFrom } from 'rxjs';
import { enemyEngagementActions } from '../actions/enemy-engagment.actions';
import { sidebarActions } from '../actions/sidebar.actions';
import { selectUrl } from '../selectors/route.selectors';
import { routes } from '@/utils/routes';

const ROUTE = routes['ENG'].route;

@Injectable()
export class EnemyEngagementEffects {
  timeFormat$ = this.store.select(selectSelectedTimeFormat);
  selectedBlueControlMeasure$ = this.store.select(
    selectSelectedBlueControlMeasure
  );
  selectedRedControlMeasure$ = this.store.select(
    selectSelectedRedControlMeasure
  );
  selectedChartPoint$ = this.store.select(selectSelectedChartPoint);
  redTimeframe$ = this.store.select(selectRedTimeframe);
  blueTimeframe$ = this.store.select(selectBlueTimeframe);

  route$ = this.store.select(selectUrl);

  constructor(
    private actions$: Actions,
    private httpClient: HttpClient,
    private store: Store
  ) {}

  getControlMeasures$ = createEffect(() =>
    this.actions$.pipe(
      ofType(enemyEngagementActions.getControlMeasures),
      switchMap(() =>
        this.httpClient
          .get<EnemyEngagementControlMeasure[]>(
            `${API_URL}/advmetrics/eneeng/controlmeasures`
          )
          .pipe(
            map((controlMeasures) =>
              enemyEngagementActions.controlMeasuresLoaded(controlMeasures)
            )
          )
      )
    )
  );

  getEntityDetails$ = createEffect(() =>
    this.actions$.pipe(
      ofType(enemyEngagementActions.chartPointSelected),
      withLatestFrom(this.selectedChartPoint$),
      switchMap(([{ payload }, selectedChartPoint]) => {
        const params = new HttpParams()
          .append('selectedControlMeasures', payload.cmID || '')
          .append('time', selectedChartPoint?.point.time || 0)
          .append('engaged', payload.isEngaged);
        return this.httpClient
          .get<EnemyEngagementUnit[]>(`${API_URL}/advmetrics/eneeng/entity-details`, {
            params,
          })
          .pipe(
            map((entityDetails) =>
              enemyEngagementActions.entityDetailsLoaded(entityDetails)
            )
          );
      })
    )
  );

  getBlueEngagementResults$ = createEffect(() =>
    this.actions$.pipe(
      ofType(
        enemyEngagementActions.blueTimeframeChanged,
        enemyEngagementActions.blueControlMeasureSelected,
        sidebarActions.timeFormatSelected
      ),
      withLatestFrom(
        this.route$,
        this.timeFormat$,
        this.selectedBlueControlMeasure$,
        this.blueTimeframe$
      ),
      filter(([_, route]) => route.includes(ROUTE)),
      switchMap(
        ([_, __, timeFormat, selectedBlueControlMeasure, blueTimeframe]) => {
          const params = new HttpParams()
            .append(
              'selectedControlMeasures',
              selectedBlueControlMeasure?.id.toString() || ''
            )
            .set('isFriendly', selectedBlueControlMeasure?.isFriendly || true)
            .set('startTime', blueTimeframe.start)
            .set('endTime', blueTimeframe.end)
            .set('timeFormat', timeFormat || 'null');

          return this.httpClient
            .get<EnemyEngagementPoint[]>(`${API_URL}/advmetrics/eneeng/results-by-time`, {
              params,
            })
            .pipe(
              map((engagementResults) =>
                enemyEngagementActions.blueEngagementResultsLoaded(
                  engagementResults
                )
              )
            );
        }
      )
    )
  );

  getRedEngagementResults$ = createEffect(() =>
    this.actions$.pipe(
      ofType(
        enemyEngagementActions.redTimeframeChanged,
        enemyEngagementActions.redControlMeasureSelected,
        sidebarActions.timeFormatSelected
      ),
      withLatestFrom(
        this.route$,
        this.timeFormat$,
        this.selectedRedControlMeasure$,
        this.redTimeframe$
      ),
      filter(([_, route]) => route.includes(ROUTE)),
      switchMap(([_, __, timeFormat, selectedRedControlMeasure, redTimeframe]) => {
        const params = new HttpParams()
          .append(
            'selectedControlMeasures',
            selectedRedControlMeasure?.id || ''
          )
          .set('isFriendly', selectedRedControlMeasure?.isFriendly || false)
          .set('startTime', redTimeframe.start)
          .set('endTime', redTimeframe.end)
          .set('timeFormat', timeFormat || 'null');

        return this.httpClient
          .get<EnemyEngagementPoint[]>(`${API_URL}/advmetrics/eneeng/results-by-time`, {
            params,
          })
          .pipe(
            map((engagementResults) =>
              enemyEngagementActions.redEngagementResultsLoaded(
                engagementResults
              )
            )
          );
      })
    )
  );

  updateTimeframe$ = createEffect(() =>
    this.actions$.pipe(
      ofType(sidebarActions.minMaxTimeLoaded),
      withLatestFrom(this.route$, this.blueTimeframe$, this.redTimeframe$),
      filter(([_, route]) => route.includes(ROUTE)),
      mergeMap(([{ payload }, _, blueTimeframe, redTimeframe]) => {
        if (
          !blueTimeframe ||
          !redTimeframe ||
          blueTimeframe.end === 0 ||
          redTimeframe.end === 0
        ) {
          return [
            enemyEngagementActions.blueTimeframeChanged({
              start: payload.minTime,
              end: payload.maxTime,
            }),
            enemyEngagementActions.redTimeframeChanged({
              start: payload.minTime,
              end: payload.maxTime,
            }),
          ];
        }

        const actions: Action[] = [];

        if (blueTimeframe.end === payload.prevMaxTime) {
          actions.push(
            enemyEngagementActions.blueTimeframeChanged({
              start: blueTimeframe.start,
              end: payload.maxTime,
            })
          );
        }
        if (redTimeframe.end === payload.prevMaxTime) {
          actions.push(
            enemyEngagementActions.redTimeframeChanged({
              start: redTimeframe.start,
              end: payload.maxTime,
            })
          );
        }

        actions.push(enemyEngagementActions.getControlMeasures());

        return actions;
      })
    )
  );
}
