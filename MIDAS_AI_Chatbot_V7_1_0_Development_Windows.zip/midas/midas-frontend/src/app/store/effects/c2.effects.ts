import { Inject, Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { HttpClient } from '@angular/common/http';
import { c2Actions } from '../actions/c2.actions';
import { map, switchMap, withLatestFrom } from 'rxjs/operators';
import { API_URL } from '@/app.config';
import { selectC2Timeframe } from '../features/c2.feature';
import { SimEntity } from '@/models';

@Injectable()
export class C2Effects {
  basePath = 'c2sim-comparison';

  constructor(
    @Inject(Actions) private actions$: Actions,
    @Inject(HttpClient) private httpClient: HttpClient,
    @Inject(Store) private store: Store
  ) {}

  timeframe$ = this.store.select(selectC2Timeframe);

  //todo this will change to single context info call
  getC2Context$ = createEffect(() =>
    this.actions$.pipe(
      ofType(c2Actions.getC2Context),
      switchMap((_) => {
        return this.httpClient
          .get<any>(`${API_URL}/${this.basePath}/advmetrics/context-info`)
          .pipe(
            map((res) =>
              c2Actions.c2ContextLoaded(
                res.map((context: any) => ({
                  ...context,
                  uniqueID: `${context.id}:${context.type}`,
                  selected: false,
                }))
              )
            )
          );
      })
    )
  );

  getUnitLocations$ = createEffect(() =>
    this.actions$.pipe(
      ofType(c2Actions.contextSelected),
      withLatestFrom(this.timeframe$),
      switchMap(([{ payload }, timeframe]) => {
        // Extract numeric ID from uniqueID (format: "id:type")
        const numericId = parseInt(payload.split(':')[0], 10);
        return this.httpClient
          .get<SimEntity[]>(`${API_URL}/${this.basePath}/advmetrics/unit-locations`, {
            params: {
              timeStamp: timeframe.end,
              contextId: numericId,
              contextType: payload.split(':')[1],
            },
          })
          .pipe(
            map((response) =>
              c2Actions.unitsLoaded({
                uniqueId: payload,
                units: response,
              })
            )
          );
      })
    )
  );
}
