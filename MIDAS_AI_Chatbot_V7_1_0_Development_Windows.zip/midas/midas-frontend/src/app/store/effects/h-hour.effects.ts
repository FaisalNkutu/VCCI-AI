import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { hhourActions } from '../actions/h-hour.actions';
import { catchError, filter, map, of, switchMap, withLatestFrom } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';
import { HHourSpecs, LodLocation, Unit } from '@/models';
import { Store } from '@ngrx/store';
import { selectSelectedTimeFormat } from '@/store/features/sidebar.feature';
import { sidebarActions } from '@/store/actions/sidebar.actions';
import { API_URL } from '@/app.config';
import {
  selectHHourSelectedUnitIds,
  selectSelectedHHour,
  selectThreshold,
} from '@/store/features/h-hour.feature';
import { selectUrl } from '../selectors/route.selectors';
import { routes } from '@/utils/routes';

const ROUTE = routes['HH'].route;

@Injectable()
export class HHourEffects {

  constructor(
    private actions$: Actions,
    private httpClient: HttpClient,
    private store: Store
  ) {}

  selectedHHour$ = this.store.select(selectSelectedHHour);
  selectedUnitIds$ = this.store.select(selectHHourSelectedUnitIds);
  timeFormat$ = this.store.select(selectSelectedTimeFormat);
  threshold$ = this.store.select(selectThreshold);
  route$ = this.store.select(selectUrl);

  getAchievedHHour$ = createEffect(() =>
    this.actions$.pipe(
      ofType(
        hhourActions.hHourDataLoaded,
        hhourActions.hHourSelection,
        hhourActions.thresholdChanged,
        hhourActions.batchUnitSelection
      ),
      withLatestFrom(this.selectedHHour$, this.threshold$, this.selectedUnitIds$),
      switchMap(([_, latestHHour, latestThreshold, latestUnitIds]) => {
        const params = new HttpParams()
          .append('hhourid', latestHHour ? latestHHour.id : 0)
          .append('threshold', latestThreshold)
          .append('selectedEntities', latestUnitIds.join(','));

        return this.httpClient
          .get<number>(`${API_URL}/advmetrics/hhour/xpercentage`, {params})
          .pipe(map((res) => hhourActions.achievedHHourLoaded(res)));
      })
    )
  );

  /**
   * Load the units for a given h-hour
   */
  loadUnits$ = createEffect(() =>
    this.actions$.pipe(
      ofType(
        hhourActions.hHourDataLoaded,
        hhourActions.hHourSelection,
        hhourActions.thresholdChanged,
        sidebarActions.timeFormatSelected
      ),
      withLatestFrom(this.selectedHHour$, this.timeFormat$),
      switchMap(([_, selectedHHour, timeFormat]) => {
        return this.httpClient
          .get<any>(
            `${API_URL}/advmetrics/hhour/entities?hhourid=${selectedHHour?.id}&format=${timeFormat}`
          )
          .pipe(
            map((res) => {
              return hhourActions.unitsLoaded({
                units: res.map((unit: Unit) => ({
                  ...unit,
                  children: unit.children ? unit.children : [],
                })),
                hHour: selectedHHour,
              });
            }),
            catchError((e) => {
              console.log('Error getting units');
              return of(hhourActions.unitsLoaded({ units: [], hHour: null }));
            })
          );
      })
    )
  );

  /**
   * Gets all the info about the available h-hours, use the time format in the request. If its undefined that is treated
   * as being default time then. This is also triggered when a new time format is selected, because the entire metric
   * has to be reloaded at that point.
   */
  getHHourData$ = createEffect(() =>
    this.actions$.pipe(
      ofType(hhourActions.getHHourData, sidebarActions.timeFormatSelected),
      withLatestFrom(this.timeFormat$),
      switchMap(([_, timeFormat]) => {
        return this.httpClient
          .get<HHourSpecs[]>(`${API_URL}/advmetrics/hhour/specs?format=${timeFormat}`)
          .pipe(
            //the id of the first h-hour, so we can show that data as the default
            map((data) =>
              hhourActions.hHourDataLoaded({ data: data, id: data[0]?.id })
            )
          );
      })
    )
  );

  /**
   * Get the LOD location info, if the HHour selection changes, or the default one when the data is loaded which is always
   * the first entry
   */
  getLODInfo$ = createEffect(() =>
    this.actions$.pipe(
      ofType(
        hhourActions.hHourDataLoaded,
        hhourActions.hHourSelection
      ),
      switchMap((action) => {
        const lodId =
          action.type === hhourActions.hHourDataLoaded.type
            ? action.data[0]?.lineofdepid
            : action.payload.hHour.lineofdepid;
        return this.httpClient
          .get<LodLocation[]>(`${API_URL}/advmetrics/hhour/lod-loc/${lodId}`)
          .pipe(map((res) => hhourActions.lODInfoLoaded({ lod: res })));
      })
    )
  );

  updateTimeframe$ = createEffect(() =>
    this.actions$.pipe(
      ofType(sidebarActions.minMaxTimeLoaded),
      withLatestFrom(this.route$),
      filter(([_, route]) => route.includes(ROUTE)),
      map((_) => {
        return hhourActions.getHHourData();
      })
    )
  );

}
