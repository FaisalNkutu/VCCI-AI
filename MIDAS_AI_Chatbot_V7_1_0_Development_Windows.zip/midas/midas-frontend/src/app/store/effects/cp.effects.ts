import { API_URL } from '@/app.config';
import {
  CombatPowerEntityDetails,
  CombatPowerEquipmentDetails,
  SimEntity,
} from '@/models';
import { selectSelectedTimeFormat } from '@/store/features/sidebar.feature';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { EMPTY, filter, map, mergeMap, switchMap, withLatestFrom } from 'rxjs';
import { cpActions } from '../actions/cp.actions';
import { sidebarActions } from '../actions/sidebar.actions';
import {
  selectCombatPowerDataGrouping,
  selectCpSelectedEntityIds,
  selectCpTimeframe,
  selectExcludeZeroToHundred,
} from '../features/cp.feature';
import { selectUrl } from '../selectors/route.selectors';
import { routes } from '@/utils/routes';

const ROUTE = routes['CP'].route;

@Injectable()
export class CpEffects {
  dataGrouping$ = this.store.select(selectCombatPowerDataGrouping);
  timeFormat$ = this.store.select(selectSelectedTimeFormat);
  selectedEntityIds$ = this.store.select(selectCpSelectedEntityIds);
  timeframe$ = this.store.select(selectCpTimeframe);
  excludeZeroToHundred$ = this.store.select(selectExcludeZeroToHundred);

  route$ = this.store.select(selectUrl);

  constructor(
    private actions$: Actions,
    private httpClient: HttpClient,
    private store: Store
  ) {}

  getEntities$ = createEffect(() =>
    this.actions$.pipe(
      ofType(cpActions.getEntities, cpActions.includeAllChanged),
      withLatestFrom(this.route$, this.excludeZeroToHundred$),
      filter(([_ , route]) => route.includes(ROUTE)),
      switchMap(([_, __, excludeZeroToHundred]) => {
        return this.httpClient
          .get<SimEntity[]>(
            `${API_URL}/advmetrics/cp/entities?ignoreZeroHundredValues=${excludeZeroToHundred}`
          )
          .pipe(
            map((res) => {
              return cpActions.entitiesLoaded(
                res.map((entity) => ({
                  ...entity,
                  children: entity.children || [], // Ensure children is always an array
                }))
              );
            })
          );
      })
    )
  );

  getSelectedEntityDetails$ = createEffect(() =>
    this.actions$.pipe(
      ofType(
        cpActions.entitySelected,
        cpActions.batchEntitySelection,
        cpActions.entityDeselected,
        cpActions.timeframeChange,
        cpActions.dataGroupingChanged,
        sidebarActions.timeFormatSelected
      ),
      withLatestFrom(
        this.route$,
        this.selectedEntityIds$,
        this.timeframe$,
        this.timeFormat$,
        this.dataGrouping$
      ),
      filter(([_ , route]) => route.includes(ROUTE)),
      switchMap(([_, __, entityIds, timeframe, timeFormat, dataGrouping]) => {
        if (dataGrouping === 'equipment') {
          return EMPTY;
        }
        const params = new HttpParams()
          .set('selectedEntities', entityIds.join(','))
          .set('startTime', timeframe?.start || 0)
          .set('endTime', timeframe?.end || 0)
          .set('timeFormat', timeFormat || '');

        return this.httpClient
          .get<CombatPowerEntityDetails>(`${API_URL}/advmetrics/cp/cpower`, { params })
          .pipe(map((res) => cpActions.entityDetailsLoaded(res)));
      })
    )
  );

  getSelectedEntityEquipmentDetails$ = createEffect(() =>
    this.actions$.pipe(
      ofType(
        cpActions.entitySelected,
        cpActions.batchEntitySelection,
        cpActions.entityDeselected,
        cpActions.timeframeChange,
        cpActions.dataGroupingChanged,
        sidebarActions.timeFormatSelected
      ),
      withLatestFrom(
        this.route$,
        this.selectedEntityIds$,
        this.timeframe$,
        this.timeFormat$,
        this.dataGrouping$
      ),
      filter(([_ , route]) => route.includes(ROUTE)),
      switchMap(([_, __, entityIds, timeframe, timeFormat, dataGrouping]) => {
        if (dataGrouping === 'unit') {
          return EMPTY;
        }
        const params = new HttpParams()
          .set('selectedEntities', entityIds.join(','))
          .set('startTime', timeframe?.start || 0)
          .set('endTime', timeframe?.end || 0)
          .set('timeFormat', timeFormat || '');

        return this.httpClient
          .get<CombatPowerEquipmentDetails>(
            `${API_URL}/advmetrics/cp/cpower-equipment-breakdown`,
            { params }
          )
          .pipe(map((res) => cpActions.entityEquipmentDetailsLoaded(res)));
      })
    )
  );

  getCombatPowerData$ = createEffect(() =>
    this.actions$.pipe(
      ofType(cpActions.combatPowerPointSelected),
      withLatestFrom(this.timeFormat$),
      switchMap(([{ payload }, timeFormat]) => {
        const params = new HttpParams()
          .set('entityId', payload.entityId.toString())
          .set('time', payload.time.toString())
          .set('timeFormat', timeFormat || '');
        return this.httpClient
          .get<any>(`${API_URL}/advmetrics/cp/cpower-details`, { params })
          .pipe(map((res) => cpActions.combatPowerDataLoaded(res)));
      })
    )
  );

  getCombatPowerEquipmentData$ = createEffect(() =>
    this.actions$.pipe(
      ofType(cpActions.combatPowerEquipmentPointSelected),
      withLatestFrom(this.selectedEntityIds$, this.timeFormat$),
      switchMap(([{ payload }, entityIds, timeFormat]) => {
        const params = new HttpParams()
          .set('selectedEntities', entityIds.join(','))
          .set('equipmentType', payload.equipmentType)
          .set('time', payload.time.toString())
          .set('timeFormat', timeFormat || '');
        return this.httpClient
          .get<any>(`${API_URL}/advmetrics/cp/cpower-equipment-contribution`, { params })
          .pipe(map((res) => cpActions.combatPowerEquipmentDataLoaded(res)));
      })
    )
  );

  updateTimeframe$ = createEffect(() =>
    this.actions$.pipe(
      ofType(sidebarActions.minMaxTimeLoaded),
      withLatestFrom(this.route$, this.timeframe$),
      filter(([_ , route]) => route.includes(ROUTE)),
      mergeMap(([{ payload }, __, timeframe]) => {
        if (!timeframe || timeframe.end === 0) {
          return [
            cpActions.timeframeChange({
              start: payload.minTime,
              end: payload.maxTime,
            }),
          ];
        }
        if (timeframe.end !== payload.prevMaxTime) {
          return EMPTY;
        }

        return [
          cpActions.timeframeChange({
            start: timeframe.start,
            end: payload.maxTime,
          }),
          cpActions.getEntities(),
        ];
      })
    )
  );
}
