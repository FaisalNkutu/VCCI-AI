import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { map, switchMap, withLatestFrom } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Equipment, SimEntity } from '@/models';
import { Store } from '@ngrx/store';
import { selectSelectedTimeFormat } from '@/store/features/sidebar.feature';
import {
  selectSelectedEntityIds,
  selectSelectedEquipmentIds,
  selectTimeframe,
} from '../features/hr.feature';
import { API_URL } from '@/app.config';
import { hrActions } from '../actions/hr.actions';
import { sidebarActions } from '../actions/sidebar.actions';

@Injectable()
export class HREffects {
  selectedEntityIds$ = this.store.select(selectSelectedEntityIds);
  selectedEquipmentIds$ = this.store.select(selectSelectedEquipmentIds);
  timeFormat$ = this.store.select(selectSelectedTimeFormat);
  timeframe$ = this.store.select(selectTimeframe);

  constructor(
    private actions$: Actions,
    private httpClient: HttpClient,
    private store: Store
  ) {}

  getEntities$ = createEffect(() =>
    this.actions$.pipe(
      ofType(hrActions.getEntities),
      switchMap(() => {
        return this.httpClient
          .get<SimEntity[]>(`${API_URL}/advmetrics/report/entities`)
          .pipe(
            map((res) => {
              return hrActions.entitiesLoaded(
                res.map((entity) => ({
                  ...entity,
                  children: entity.children || [], // Ensure children is always an array
                }))
              );
            })
          );
      })
    )
  );

  getEquipment$ = createEffect(() =>
    this.actions$.pipe(
      ofType(hrActions.getEquipment),
      withLatestFrom(this.selectedEntityIds$),
      switchMap(([_, entityIds]) => {
        const params = new HttpParams().set(
          'selectedEntities',
          entityIds.join(',')
        );

        return this.httpClient
          .get<Equipment[][]>(`${API_URL}/advmetrics/report/equipment-types`, { params })
          .pipe(
            switchMap((res) => [
              hrActions.equipmentLoaded(res),
              hrActions.commoditiesLoaded(res),
            ])
          );
      })
    )
  );

  generateReport$ = createEffect(() =>
    this.actions$.pipe(
      ofType(hrActions.generateReport),
      withLatestFrom(
        this.selectedEntityIds$,
        this.selectedEquipmentIds$,
        this.timeframe$
      ),
      switchMap(([_, entityIds, equipmentIds, timeframe]) => {
        const params = new HttpParams()
          .set('selectedEntities', entityIds.join(','))
          .set('equipmentTypeIds', equipmentIds.join(','))
          .set('startTime', timeframe.start.toString())
          .set('endTime', timeframe.end.toString());

        return this.httpClient
          .get<Equipment[]>(`${API_URL}/advmetrics/report/rollup/holdings`, { params })
          .pipe(map((res) => hrActions.reportGenerated(res)));
      })
    )
  );

  loadHoldingsContribution$ = createEffect(() =>
    this.actions$.pipe(
      ofType(hrActions.holdingsContributionSelected),
      withLatestFrom(this.timeFormat$, this.selectedEntityIds$),
      switchMap(([{ payload }, timeFormat, entityIds]) => {
        const { equipmentId, time } = payload;
        const params = new HttpParams()
          .set('equipmentTypeId', equipmentId.toString())
          .set('time', time.toString())
          .set('timeFormat', timeFormat || '')
          .set('selectedEntities', entityIds.join(','));

        return this.httpClient
          .get<any>(`${API_URL}/advmetrics/report/rollup/holdings/contribution`, {
            params,
          })
          .pipe(map((res) => hrActions.holdingsContributionLoaded(res)));
      })
    )
  );

  resetState$ = createEffect(() =>
    this.actions$.pipe(
      ofType(hrActions.resetState),
      map(() => hrActions.getEntities())
    )
  );

  updateTimeframe$ = createEffect(() =>
    this.actions$.pipe(
      ofType(sidebarActions.minMaxTimeLoaded),
      withLatestFrom(this.timeframe$),
      map(([{ payload }, timeframe]) => {
        if (!timeframe || timeframe.end === 0) {
          return hrActions.timeframeChange({
            start: payload.minTime,
            end: payload.maxTime,
          });
        }

        if (timeframe.end !== payload.prevMaxTime) {
          return { type: 'NO_ACTION' };
        }
        return hrActions.timeframeChange({
          start: timeframe.start,
          end: payload.maxTime,
        });
      })
    )
  );
}
