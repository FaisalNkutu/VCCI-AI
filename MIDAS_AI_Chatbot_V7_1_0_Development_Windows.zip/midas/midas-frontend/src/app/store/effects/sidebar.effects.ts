import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { HttpClient } from '@angular/common/http';
import { map, switchMap, withLatestFrom } from 'rxjs';
import { sidebarActions } from '@/store/actions/sidebar.actions';
import { databaseActions } from '@/store/actions/db-list.actions';
import { API_URL } from '@/app.config';
import { ConnectedDB, TimeFormat, TimeMinMax } from '@/models';
import { Store } from '@ngrx/store';
import { catchError, of, from } from 'rxjs';
import {
  DEFAULT_MAP_URL,
  selectMinMaxTime,
  selectSelectedTimeFormat,
} from '@/store/features/sidebar.feature';
import {
  fetchWMTSCapabilities,
  parseWMTSCapabilities,
  WMTSCapabilitiesLayer,
} from '@/services/wmts-capabilities';
import { WMTSOptions } from '@/services/tile-layer-wmts';

@Injectable()
export class SidebarEffects {
  constructor(
    private httpClient: HttpClient,
    private actions$: Actions,
    private store: Store
  ) {}

  /**
   * Load the time formats immediately after the database is selected and  loaded or if get time formats is triggered
   */
  getTimeFormats$ = createEffect(() =>
    this.actions$.pipe(
      ofType(
        sidebarActions.getTimeFormats,
        databaseActions.chosenDatabaseLoaded
      ),
      switchMap((_) => {
        return this.httpClient
          .get<TimeFormat[]>(`${API_URL}/advmetrics/omdbdata/formats`)
          .pipe(map((res) => sidebarActions.timeFormatsLoaded(res)));
      })
    )
  );

  /**
   * The min max is overall for the whole database selected. This needs to be triggered in 2 cases,
   * the first when the database is loaded (the selected time format will be default) and the second is
   * when the user selects a new time format because that effects how the min and max are displayed.
   */
  getTimeSliderMinMax$ = createEffect(() =>
    this.actions$.pipe(
      ofType(sidebarActions.getMinMaxTime, sidebarActions.timeFormatSelected),
      withLatestFrom(
        this.store.select(selectMinMaxTime),
        this.store.select(selectSelectedTimeFormat)
      ),
      switchMap(([_, minMaxTime, selectedTimeFormat]) => {
        return this.httpClient
          .get<TimeMinMax>(
            `${API_URL}/advmetrics/omdbdata/minmaxtime?format=${selectedTimeFormat}`
          )
          .pipe(
            map((res) =>
              sidebarActions.minMaxTimeLoaded({
                ...res,
                prevMaxTime: minMaxTime?.maxTime || 0,
              })
            )
          );
      })
    )
  );

  getMapServerURL$ = createEffect(() =>
    this.actions$.pipe(
      ofType(sidebarActions.getMapServerURL),
      switchMap((_) =>
        this.httpClient.get<{ url: string }>(`${API_URL}/advmetrics/mapconfig`).pipe(
          map((res) => {
            return sidebarActions.mapServerURLLoaded(res.url || '');
          })
        )
      )
    )
  );

  /**
   * Effect to resolve map URL from WMTS capabilities or use directly
   */
  resolveMapURL$ = createEffect(() =>
    this.actions$.pipe(
      ofType(sidebarActions.mapServerURLLoaded),
      switchMap(({ payload: mapServerURL }) => {
        // If it's already a tile URL pattern, use it directly
        if (
          mapServerURL.includes('{z}') &&
          mapServerURL.includes('{x}') &&
          mapServerURL.includes('{y}')
        ) {
          return of(
            sidebarActions.resolvedMapURLLoaded({
              url: mapServerURL,
              wmtsOptions: undefined,
            })
          );
        }

        // If it's a WMTS capabilities URL, try to parse it
        if (
          mapServerURL.includes('wmts') ||
          mapServerURL.includes('capabilities')
        ) {
          return from(
            fetchWMTSCapabilities(
              `${mapServerURL}?SERVICE=WMTS&REQUEST=GetCapabilities`
            )
          ).pipe(
            map((xmlDoc) => {
              return parseWMTSCapabilities(xmlDoc);
            }),
            map((layers: WMTSCapabilitiesLayer[]) => {
              let requestedLayer: WMTSCapabilitiesLayer | undefined;
              requestedLayer = layers.find((res: WMTSCapabilitiesLayer) =>
                res.tileMatrixSet.includes('EPSG:3857')
              );
              if (!requestedLayer) {
                requestedLayer = layers.find((res: WMTSCapabilitiesLayer) =>
                  res.tileMatrixSet.includes('GoogleMapsCompatible')
                );
              }

              if (requestedLayer) {
                // Create WMTS options from the layer information
                const wmtsOptions: WMTSOptions = {
                  format: requestedLayer.format,
                  style: requestedLayer.style,
                  layer: requestedLayer.identifier,
                  tileMatrixSet: requestedLayer.tileMatrixSet,
                  tileMatrixIds: requestedLayer.tileMatrices,
                  maxNativeZoom: requestedLayer.maxNativeZoom,
                  maxZoom: 24,
                  version: '1.0.0',
                };

                return sidebarActions.resolvedMapURLLoaded({
                  url: mapServerURL,
                  wmtsOptions: wmtsOptions,
                });
              }

              // Fallback if no suitable layer found
              return sidebarActions.resolvedMapURLLoaded({
                url: DEFAULT_MAP_URL,
                wmtsOptions: undefined,
              });
            }),
            catchError((error) => {
              console.error('Error parsing WMTS capabilities:', error);
              return of(
                sidebarActions.resolvedMapURLLoaded({
                  url: DEFAULT_MAP_URL,
                  wmtsOptions: undefined,
                })
              );
            })
          );
        }

        // Fallback to default URL
        return of(
          sidebarActions.resolvedMapURLLoaded({
            url: DEFAULT_MAP_URL,
            wmtsOptions: undefined,
          })
        );
      })
    )
  );

  setMinMaxTime = createEffect(() =>
    this.actions$.pipe(
      ofType(sidebarActions.statusDataReceived),
      withLatestFrom(this.store.select(selectMinMaxTime)),
      map(([{ payload }, minMaxTime]) => {
        const newMaxTime = payload.jMaxTime;
        let prevMaxTime = minMaxTime?.maxTime || minMaxTime?.prevMaxTime || 0;
        if (newMaxTime === -1 || prevMaxTime === newMaxTime) {
          return { type: 'NO_ACTION' };
        }
        return sidebarActions.minMaxTimeLoaded({
          minTime: minMaxTime?.minTime || 0,
          maxTime: newMaxTime,
          prevMaxTime,
        });
      })
    )
  );

  getConnectedDB$ = createEffect(() =>
    this.actions$.pipe(
      ofType(sidebarActions.getConnectedDB, sidebarActions.statusDataReceived),
      switchMap((_) => {
        return this.httpClient
          .get<ConnectedDB | { connected: boolean }>(
            `${API_URL}/advmetrics/omdbdata/selecteddb`
          )
          .pipe(
            map((res) => {
              if (!res.connected) {
                return sidebarActions.connectedDBLoaded({
                  connected: false,
                  database: '',
                  live: false,
                  host: '',
                });
              }

              return sidebarActions.connectedDBLoaded(res as ConnectedDB);
            })
          );
      })
    )
  );
}
