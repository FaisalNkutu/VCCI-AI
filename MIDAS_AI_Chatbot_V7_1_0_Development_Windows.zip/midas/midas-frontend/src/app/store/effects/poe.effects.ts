import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { filter, map, mergeMap, switchMap, withLatestFrom } from 'rxjs';
import { ControlMeasure, POEPoint } from '@/models';
import { HttpClient, HttpParams } from '@angular/common/http';
import { selectSelectedTimeFormat } from '@/store/features/sidebar.feature';
import { poeActions } from '@/store/actions/poe.actions';
import {
  selectedPOECmIds,
  selectRedTimeframe,
  selectBlueTimeframe,
} from '@/store/features/poe.feature';
import { Action, Store } from '@ngrx/store';
import { API_URL } from '@/app.config';
import { sidebarActions } from '../actions/sidebar.actions';
import { selectUrl } from '../selectors/route.selectors';
import { routes } from '@/utils/routes';

const ROUTE = routes['POE'].route;

@Injectable()
export class PoeEffects {
  blueTimeframe$ = this.store.select(selectBlueTimeframe);
  redTimeframe$ = this.store.select(selectRedTimeframe);
  timeFormat$ = this.store.select(selectSelectedTimeFormat);
  poeCMs$ = this.store.select(selectedPOECmIds);

  route$ = this.store.select(selectUrl);

  constructor(
    private actions$: Actions,
    private httpClient: HttpClient,
    private store: Store
  ) {}

  getControlMeasures$ = createEffect(() =>
    this.actions$.pipe(
      ofType(poeActions.getControlMeasures),
      switchMap((_) => {
        return this.httpClient
          .get<ControlMeasure[]>(`${API_URL}/advmetrics/poe/controlmeasures`)
          .pipe(map((res) => poeActions.controlMeasuresLoaded(res)));
      })
    )
  );
  getPoints$ = createEffect(() =>
    this.actions$.pipe(
      ofType(
        poeActions.redTimeframeChanged,
        poeActions.blueTimeframeChanged,
        poeActions.controlMeasureSelected,
        poeActions.controlMeasureDeselected,
        sidebarActions.timeFormatSelected
      ),
      withLatestFrom(
        this.route$,
        this.blueTimeframe$,
        this.redTimeframe$,
        this.timeFormat$,
        this.poeCMs$
      ),
      filter(([_, route]) => route.includes(ROUTE)),
      switchMap(([_, __, blue, red, time, cms]) => {
        const params = new HttpParams()
          .append('timeFormat', time || 'null')
          .append('friendlyStartTime', blue.start)
          .append('friendlyEndTime', blue.end as number)
          .append('hostileStartTime', red.start as number)
          .append('hostileEndTime', red.end as number)
          .append('selectedControlMeasures', cms.join(','))
          .append('timeInterval', 1);

        return this.httpClient
          .get<POEPoint[]>(`${API_URL}/advmetrics/poe/filtered-results?${params}`)
          .pipe(map((res) => poeActions.pointsLoaded(res)));
      })
    )
  );

  updateTimeframe$ = createEffect(() =>
    this.actions$.pipe(
      ofType(sidebarActions.minMaxTimeLoaded),
      withLatestFrom(this.route$, this.blueTimeframe$, this.redTimeframe$),
      filter(([_, route]) => route.includes(ROUTE)),
      mergeMap(([{ payload }, _, blueTimeframe, redTimeframe]) => {
        if (
          !blueTimeframe ||
          !redTimeframe ||
          blueTimeframe.end === 0 ||
          redTimeframe.end === 0
        ) {
          return [
            poeActions.blueTimeframeChanged({
              start: payload.minTime,
              end: payload.maxTime,
            }),
            poeActions.redTimeframeChanged({
              start: payload.minTime,
              end: payload.maxTime,
            }),
          ];
        }

        const actions: Action[] = [];

        if (blueTimeframe.end === payload.prevMaxTime) {
          actions.push(
            poeActions.blueTimeframeChanged({
              start: blueTimeframe.start,
              end: payload.maxTime,
            })
          );
        }
        if (redTimeframe.end === payload.prevMaxTime) {
          actions.push(
            poeActions.redTimeframeChanged({
              start: redTimeframe.start,
              end: payload.maxTime,
            })
          );
        }

        actions.push(poeActions.getControlMeasures());

        return actions;
      })
    )
  );
}
