import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { cmActions } from '@/store/actions/cm.actions';
import { EMPTY, filter, map, mergeMap, switchMap, withLatestFrom } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';
import { CmChartData, CMEntity, ControlMeasure, SFMap, SimEntity } from '@/models';
import {
  selectSelectedControlMeasures,
  selectTimeframe,
  selectDeselectedIds,
} from '@/store/features/cm.feature';
import { Store } from '@ngrx/store';
import { selectSelectedTimeFormat } from '@/store/features/sidebar.feature';
import { API_URL } from '@/app.config';
import { sidebarActions } from '../actions/sidebar.actions';
import { selectUrl } from '../selectors/route.selectors';
import { routes } from '@/utils/routes';

const ROUTE = routes['CM'].route;

@Injectable()
export class CmEffects {
  deselectedIds$ = this.store.select(selectDeselectedIds);
  selectedControlMeasures$ = this.store.select(selectSelectedControlMeasures);
  timeframe$ = this.store.select(selectTimeframe);
  timeFormat$ = this.store.select(selectSelectedTimeFormat);

  route$ = this.store.select(selectUrl);

  constructor(
    private actions$: Actions,
    private httpClient: HttpClient,
    private store: Store
  ) {}

  getControlMeasures$ = createEffect(() =>
    this.actions$.pipe(
      ofType(cmActions.getControlMeasures),
      switchMap((_) => {
        return this.httpClient
          .get<ControlMeasure[]>(`${API_URL}/advmetrics/cmocc/controlmeasures`)
          .pipe(map((res) => cmActions.controlMeasuresLoaded(res)));
      })
    )
  );
  getEntities$ = createEffect(() =>
    this.actions$.pipe(
      ofType(
        cmActions.getEntities,
        cmActions.controlMeasureSelected,
        cmActions.controlMeasureDeselected
      ),
      withLatestFrom(this.selectedControlMeasures$),
      switchMap(([_ , selectedControlMeasures]) => {
        const params = new HttpParams().append(
          'cmOccIds',
          selectedControlMeasures.map((cm) => cm.id).join(',')
        );

        return this.httpClient
          .get<SimEntity[]>(`${API_URL}/advmetrics/cmocc/entities?${params}`)
          .pipe(
            map((res) =>
              cmActions.entitiesLoaded(
                res.map((e) => ({ ...e, children: e.children || [] }))
              )
            )
          );
      })
    )
  );

  getChartData$ = createEffect(() =>
    this.actions$.pipe(
      ofType(
        cmActions.timeframeChange,
        cmActions.controlMeasureSelected,
        cmActions.controlMeasureDeselected,
        cmActions.unitSelected,
        cmActions.unitDeselected,
        cmActions.batchUnitSelection,
        sidebarActions.timeFormatSelected
      ),
      withLatestFrom(
        this.route$,
        this.timeFormat$,
        this.timeframe$,
        this.selectedControlMeasures$,
        this.deselectedIds$,
      ),
      filter(([_ , route]) => route.includes(ROUTE)),
      switchMap(
        ([
          _,
          __,
          timeFormat,
          timeframe,
          selectedControlMeasures,
          deselectedIds,
        ]) => {
          const params = new HttpParams()
            .append('startTime', timeframe.start)
            .append('endTime', timeframe.end)
            .append('timeFormat', timeFormat || '')
            .append(
              'cmOccIds',
              selectedControlMeasures.map((cm) => cm.id).join(',')
            )
            .append('deselectedEntities', deselectedIds.join(','))
            .append('interval', '-1'); //not used right now

          return this.httpClient
            .get<SFMap<CmChartData>>(`${API_URL}/advmetrics/cmocc/results?${params}`)
            .pipe(map((res) => cmActions.chartDataLoaded(res)));
        }
      )
    )
  );

  /**
   * When control measures are selected, get the resulting entities over time for that control measure.
   * Need to send the time to get, any deselected entities so they can be filtered out and the selected control
   * measures ids. This needs to be triggered as well when the time slider changes.
   */
  controlMeasureSelectionOrTimeChange$ = createEffect(() =>
    this.actions$.pipe(
      ofType(cmActions.getOccupyingUnits),
      withLatestFrom(this.route$, this.deselectedIds$),
      filter(([_ , route]) => route.includes(ROUTE)),
      switchMap(([{ payload }, __, deselectedIds]) => {
        const params = new HttpParams()
          .append('startTime', payload.time || '')
          .append('endTime', payload.time || '')
          .append('selectedControlMeasures', payload.cmId)
          .append('deselectedEntities', deselectedIds.join(','));

        return this.httpClient
          .get<SFMap<CMEntity[]>>(`${API_URL}/advmetrics/cmocc/results-by-time?${params}`)
          .pipe(map((res) => cmActions.selectedControlMeasuresLoaded(res)));
      })
    )
  );

  updateTimeframe$ = createEffect(() =>
    this.actions$.pipe(
      ofType(sidebarActions.minMaxTimeLoaded),
      withLatestFrom(this.route$, this.timeframe$),
      filter(([_ , route]) => route.includes(ROUTE)),
      mergeMap(([{ payload }, __, timeframe]) => {
        if (!timeframe || timeframe.end === 0) {
          return [
            cmActions.timeframeChange({
              start: payload.minTime,
              end: payload.maxTime,
            }),
          ];
        }
        if (timeframe.end !== payload.prevMaxTime) {
          return EMPTY;
        }

        return [
          cmActions.timeframeChange({
            start: timeframe.start,
            end: payload.maxTime,
          }),
          cmActions.getEntities(),
          cmActions.getControlMeasures(),
        ];
      })
    )
  );
}
