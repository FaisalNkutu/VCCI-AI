import { API_URL } from '@/app.config';
import { UnitWatchResults } from '@/models';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { Subject } from 'rxjs';
import { filter, map, switchMap, tap, withLatestFrom } from 'rxjs/operators';
import { SimEntity } from '../../models/models';
import { SseService } from '../../services/sse.service';
import { sidebarActions } from '../actions/sidebar.actions';
import { unitWatchActions } from '../actions/unit-watch.actions';
import { selectUrl } from '../selectors/route.selectors';
import { routes } from '@/utils/routes';

const ROUTE = routes['UW'].route;

@Injectable()
export class UnitWatchEffects {
  private stopStream$ = new Subject<void>();

  route$ = this.store.select(selectUrl);

  constructor(
    private actions$: Actions,
    private httpClient: HttpClient,
    private sseService: SseService,
    private store: Store
  ) {}

  getUnits$ = createEffect(() =>
    this.actions$.pipe(
      ofType(unitWatchActions.getUnits),
      switchMap((_) => {
        return this.httpClient
          .get<Partial<SimEntity>[]>(`${API_URL}/advmetrics/entity-watch/ids`)
          .pipe(
            map((res) =>
              unitWatchActions.unitsLoaded(
                //nate todo fix on backend side, return the whole entity object
                res.map((entity) => ({
                  ...entity,
                  name: entity.name as string,
                  lat: 0,
                  lon: 0,
                  id: entity.id as number,
                  milSym: entity.milSym as string,
                  children: [],
                  isFriendly: entity.isFriendly as boolean,
                }))
              )
            )
          );
      })
    )
  );

  startUnitWatchStream$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(unitWatchActions.unitsLoaded),
        tap((action) => {
          // Stop any existing stream
          this.stopStream$.next();

          const ids = action.payload.map((entity) => entity.id).join(',');

          this.sseService
            .getServerSentEvents<UnitWatchResults>(
              `${API_URL}/advmetrics/entity-watch/stream?entityIds=${ids}`
            )
            .subscribe({
              next: (event) => {
                console.log('SSE event received:', event);
                this.store.dispatch(
                  unitWatchActions.unitWatchEventReceived(event)
                );
              },
              error: (error) => {
                console.error('Unit watch stream error:', error);
              },
            });
        })
      ),
    { dispatch: false }
  );

  updateTimeframe$ = createEffect(() =>
    this.actions$.pipe(
      ofType(sidebarActions.minMaxTimeLoaded),
      withLatestFrom(this.route$),
      filter(([_, route]) => route.includes(ROUTE)),
      map((_) => {
        return unitWatchActions.getUnits();
      })
    )
  );
}
