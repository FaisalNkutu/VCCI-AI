import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { API_URL } from '@/app.config';
import { summaryActions } from '../actions/summary.actions';

@Injectable()
export class SummaryEffects {
  constructor(
    private actions$: Actions,
    private httpClient: HttpClient,
    private store: Store
  ) {}

  /**
   * Get the initial data of all the available captures. This is triggered on initial
   * dashboard load
   */
  // testData$ = createEffect(() =>
  //   this.actions$.pipe(ofType(summaryActions.test))
  // );
}
