import { API_URL } from '@/app.config';
import { FratIncident, FratricideGraphPoint } from '@/models';
import { fratricideActions } from '@/store/actions/fratricide.actions';
import { selectTimeframe } from '@/store/features/fratricide.feature';
import { selectSelectedTimeFormat } from '@/store/features/sidebar.feature';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { filter, map, switchMap, withLatestFrom } from 'rxjs';
import { sidebarActions } from '../actions/sidebar.actions';
import { selectUrl } from '../selectors/route.selectors';
import { routes } from '@/utils/routes';

const ROUTE = routes['FRAT'].route;

@Injectable()
export class FratricideEffects {
  timeFormat$ = this.store.select(selectSelectedTimeFormat);
  timeframe$ = this.store.select(selectTimeframe);

  route$ = this.store.select(selectUrl);

  constructor(
    private actions$: Actions,
    private httpClient: HttpClient,
    private store: Store
  ) {}

  // the result is an array with one entry that is returned
  getResults$ = createEffect(() =>
    this.actions$.pipe(
      ofType(fratricideActions.getResults, fratricideActions.timeframeChange),
      withLatestFrom(this.route$, this.timeFormat$, this.timeframe$),
      filter(([_, route]) => route.includes(ROUTE)),
      switchMap(([_, __, time, timeframe]) => {
        return this.httpClient
          .get<FratricideGraphPoint[]>(
            `${API_URL}/advmetrics/frat/graph?format=${time}&startTime=${timeframe.start}&endTime=${timeframe.end}&interval=5`
          )
          .pipe(map((res) => fratricideActions.resultsLoaded(res)));
      })
    )
  );

  getIncidentDetails$ = createEffect(() =>
    this.actions$.pipe(
      ofType(fratricideActions.fratIncidentSelected),
      withLatestFrom(this.timeFormat$),
      switchMap(([action, timeFormat]) => {
        return this.httpClient
          .get<FratIncident[]>(
            `${API_URL}/advmetrics/frat/incidentdetails?format=${timeFormat}&fireEventId=${action.payload.fireEventId}`
          )
          .pipe(map((res) => fratricideActions.incidentDetailsLoaded(res)));
      })
    )
  );

  getIncidentsAtTime$ = createEffect(() =>
    this.actions$.pipe(
      ofType(fratricideActions.pointSelected),
      withLatestFrom(this.timeFormat$),
      switchMap(([action, timeFormat]) => {
        return this.httpClient
          .get<FratIncident[]>(
            `${API_URL}/advmetrics/frat/incidentsattime?time=${action.payload}&format=${timeFormat}&interval=5`
          )
          .pipe(map((res) => fratricideActions.incidentsAtTimeLoaded(res)));
      })
    )
  );

  updateTimeframe$ = createEffect(() =>
    this.actions$.pipe(
      ofType(sidebarActions.minMaxTimeLoaded),
      withLatestFrom(this.route$, this.timeframe$),
      filter(([_, route]) => route.includes(ROUTE)),
      map(([{ payload }, _, timeframe]) => {
        if (!timeframe || timeframe.end === 0) {
          return fratricideActions.timeframeChange({
            start: payload.minTime,
            end: payload.maxTime,
          });
        }
        if (timeframe.end !== payload.prevMaxTime) {
          return { type: 'NO_ACTION' };
        }

        return fratricideActions.timeframeChange({
          start: timeframe.start,
          end: payload.maxTime,
        });
      })
    )
  );
}
