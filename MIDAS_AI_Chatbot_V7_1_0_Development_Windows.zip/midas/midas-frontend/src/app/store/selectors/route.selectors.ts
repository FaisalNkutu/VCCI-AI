import { createFeatureSelector } from '@ngrx/store';
import { getRouterSelectors, RouterReducerState } from '@ngrx/router-store';

export const selectRouter = createFeatureSelector<RouterReducerState>('router');

export const {
  selectCurrentRoute,
  selectUrl,
  selectQueryParams,
  selectRouteParams,
  selectRouteData,
} = getRouterSelectors(selectRouter);
