import { createFeature, createReducer, createSelector, on, select } from '@ngrx/store';
import { TimeFormat, TimeMinMax, StatusData, ConnectedDB } from '@/models';
import { sidebarActions } from '@/store/actions/sidebar.actions';
import { WMTSOptions } from '@/services/tile-layer-wmts';

export const DEFAULT_MAP_URL =
  'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';

export type SidebarState = {
  timeFormats: TimeFormat[];
  selectedTimeFormat: string;
  minMaxTime: TimeMinMax | undefined;
  statusData: StatusData | undefined;
  mapServerURL: string | undefined;
  resolvedMapConfig: { url: string; wmtsOptions: WMTSOptions | undefined };
  connectedDB: ConnectedDB;
};

export const initialState: SidebarState = {
  timeFormats: [],
  selectedTimeFormat: '',
  minMaxTime: undefined,
  statusData: undefined,
  mapServerURL: undefined,
  resolvedMapConfig: { url: DEFAULT_MAP_URL, wmtsOptions: undefined },
  connectedDB: { database: '', live: false, connected: false, host: '' },
};

export const sidebarReducer = createReducer(
  initialState,
  on(sidebarActions.timeFormatsLoaded, (state, { payload }) => ({
    ...state,
    timeFormats: payload,
  })),
  on(sidebarActions.timeFormatSelected, (state, { payload }) => ({
    ...state,
    selectedTimeFormat: payload,
  })),
  on(sidebarActions.minMaxTimeLoaded, (state, { payload }) => ({
    ...state,
    minMaxTime: payload,
  })),
  on(sidebarActions.mapServerURLLoaded, (state, { payload }) => ({
    ...state,
    mapServerURL: payload,
  })),
  on(sidebarActions.resolvedMapURLLoaded, (state, { payload }) => ({
    ...state,
    resolvedMapConfig: payload,
  })),
  // If live mode, status data contains new max times, move the max time ahead.
  //If max time is -1, do not move it ahead
  on(sidebarActions.statusDataReceived, (state, { payload }) => {
      return {
        ...state,
        statusData: payload,
      };
  }),
  on(sidebarActions.connectedDBLoaded, (state, { payload }) => ({
    ...state,
    connectedDB: payload,
  }))
);

export const sidebarFeature = createFeature({
  name: 'sidebar',
  reducer: sidebarReducer,
  extraSelectors: ({ selectTimeFormats, selectResolvedMapConfig }) => {
    const selectTimeFormatNames = createSelector(
      selectTimeFormats,
      (timeFormats: TimeFormat[]) => {
        return timeFormats.map((tf: TimeFormat) => tf.name);
      }
    );

    return {
      selectTimeFormatNames,
    };
  },
});

export const {
  name,
  reducer,
  selectMinMaxTime,
  selectTimeFormats,
  selectTimeFormatNames,
  selectSelectedTimeFormat,
  selectMapServerURL,
  selectResolvedMapConfig,
  selectSidebarState,
  selectStatusData,
  selectConnectedDB,
} = sidebarFeature;
