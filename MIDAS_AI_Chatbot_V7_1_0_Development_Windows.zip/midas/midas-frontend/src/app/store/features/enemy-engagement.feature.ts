import { SimChartData } from '@/chart-v2/chart-v2.component';
import {
  EnemyEngagementControlMeasure,
  EnemyEngagementPoint,
  EnemyEngagementUnit,
  Timeframe,
} from '@/models';
import { createFeature, createReducer, createSelector, on } from '@ngrx/store';
import { enemyEngagementActions } from '../actions/enemy-engagment.actions';

export interface EnemyEngagementState {
  selectedBlueControlMeasure: EnemyEngagementControlMeasure | undefined;
  selectedRedControlMeasure: EnemyEngagementControlMeasure | undefined;
  controlMeasures: EnemyEngagementControlMeasure[];
  redTimeframe: Timeframe;
  blueTimeframe: Timeframe;
  redEngagementResults: EnemyEngagementPoint[]; //at this point return the index of the data point and engaged or entity count
  blueEngagementResults: EnemyEngagementPoint[];
  selectedChartPoint:
    | { isBlue: boolean; point: EnemyEngagementPoint; isEngaged: boolean }
    | undefined;
  entities: EnemyEngagementUnit[];
}

export const initialState: EnemyEngagementState = {
  controlMeasures: [],
  redTimeframe: { start: 0, end: 0 },
  blueTimeframe: { start: 0, end: 0 },
  redEngagementResults: [],
  selectedBlueControlMeasure: undefined,
  selectedRedControlMeasure: undefined,
  blueEngagementResults: [],
  selectedChartPoint: undefined,
  entities: [],
};

export const enemyEngagementReducer = createReducer(
  initialState,
  on(enemyEngagementActions.controlMeasuresLoaded, (state, { payload }) => ({
    ...state,
    controlMeasures: payload,
  })),
  on(enemyEngagementActions.entityDetailsLoaded, (state, { payload }) => ({
    ...state,
    entities: payload,
  })),
  on(enemyEngagementActions.redTimeframeChanged, (state, { payload }) => ({
    ...state,
    redTimeframe: payload,
  })),
  on(enemyEngagementActions.blueTimeframeChanged, (state, { payload }) => ({
    ...state,
    blueTimeframe: payload,
  })),
  on(
    enemyEngagementActions.blueControlMeasureSelected,
    (state, { payload }) => {
      return {
        ...state,
        selectedBlueControlMeasure: payload,
      };
    }
  ),
  on(enemyEngagementActions.redControlMeasureSelected, (state, { payload }) => {
    return {
      ...state,
      selectedRedControlMeasure: payload,
    };
  }),
  on(
    enemyEngagementActions.redEngagementResultsLoaded,
    (state, { payload }) => ({
      ...state,
      redEngagementResults: payload,
    })
  ),
  on(
    enemyEngagementActions.blueEngagementResultsLoaded,
    (state, { payload }) => ({
      ...state,
      blueEngagementResults: payload,
    })
  ),

  on(enemyEngagementActions.chartPointSelected, (state, { payload }) => ({
    ...state,
    selectedChartPoint: payload.isBlue
      ? {
          isBlue: true,
          point: state.blueEngagementResults[payload.index],
          isEngaged: payload.isEngaged,
        }
      : {
          isBlue: false,
          point: state.redEngagementResults[payload.index],
          isEngaged: payload.isEngaged,
        },
  }))
);
4;

export const enemyEngagementFeature = createFeature({
  name: 'enemy-engagement',
  reducer: enemyEngagementReducer,
  extraSelectors: ({
    selectRedEngagementResults,
    selectBlueEngagementResults,
  }) => {
    const selectRedChartData = createSelector(
      selectRedEngagementResults,
      (redEngagementResults): SimChartData<'line'> => {
        return {
          chartData: {
            labels: redEngagementResults.map((r) => r.formattedTime),
            datasets: [
              {
                type: 'line',
                label: 'Engaged Count',
                data: redEngagementResults.map((r) => ({
                  ...r,
                  yAxisKey: r.engagedCount,
                })),
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgb(107,224,65)',
                borderWidth: 2,
              },
              {
                type: 'line',
                label: 'Entity Count',
                data: redEngagementResults.map((r) => ({
                  ...r,
                  yAxisKey: r.entityCount,
                })),
                backgroundColor: 'rgba(255, 99, 99, 0.2)',
                borderColor: 'rgb(255, 60, 60)',
                borderWidth: 2,
              },
            ],
          },
          chartOptions: {
            interaction: {
              mode: 'nearest',
              intersect: true,
            },
            onHover: (event: any, activeElements: any[]) => {
              if (activeElements.length) {
                event.native.target.style.cursor = 'pointer';
              } else {
                event.native.target.style.cursor = 'default';
              }
            },
            responsive: true,
            maintainAspectRatio: false,
            scales: {
              x: {
                ticks: {
                  color: 'white',
                },
              },
              y: {
                grid: {
                  color: '#414546',
                },
                ticks: {
                  color: 'white',
                  precision: 0,
                },
              },
            },
            parsing: {
              yAxisKey: 'yAxisKey',
              xAxisKey: 'formattedTime',
            },
            plugins: {
              datalabels: {
                display: false,
              },
            },
          },
        };
      }
    );

    const selectBlueChartData = createSelector(
      selectBlueEngagementResults,
      (blueEngagementResults): SimChartData<'line'> => {
        return {
          chartData: {
            labels: blueEngagementResults.map((r) => r.formattedTime),
            datasets: [
              {
                type: 'line',
                label: 'Engaged Count', //data index is 0
                data: blueEngagementResults.map((r) => ({
                  ...r,
                  yAxisKey: r.engagedCount,
                })),
                backgroundColor: 'rgba(107, 224, 65, 0.2)',
                borderColor: 'rgb(107,224,65)',
                borderWidth: 2,
              },
              {
                type: 'line',
                label: 'Entity Count', //data index is 1
                data: blueEngagementResults.map((r) => ({
                  ...r,
                  yAxisKey: r.entityCount,
                })),
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgb(63,153,243)',
                borderWidth: 2,
              },
            ],
          },
          chartOptions: {
            interaction: {
              mode: 'nearest',
              intersect: true,
            },
            onHover: (event: any, activeElements: any[]) => {
              if (activeElements.length) {
                event.native.target.style.cursor = 'pointer';
              } else {
                event.native.target.style.cursor = 'default';
              }
            },
            responsive: true,
            maintainAspectRatio: false,
            scales: {
              x: {
                ticks: {
                  color: 'white',
                },
              },
              y: {
                grid: {
                  color: '#414546',
                },
                ticks: {
                  color: 'white',
                  precision: 0,
                },
              },
            },
            parsing: {
              yAxisKey: 'yAxisKey',
              xAxisKey: 'formattedTime',
            },
            plugins: {
              datalabels: {
                display: false,
              },
            },
          },
        };
      }
    );
    return { selectRedChartData, selectBlueChartData };
  },
});

export const {
  selectControlMeasures,
  selectRedChartData,
  selectBlueChartData,
  selectBlueTimeframe,
  selectRedTimeframe,
  selectSelectedBlueControlMeasure,
  selectSelectedRedControlMeasure,
  selectSelectedChartPoint,
  selectEntities: selectEnemyEngagementEntities,
} = enemyEngagementFeature;
