import { C2Context, Timeframe } from '@/models';
import { createFeature, createReducer, createSelector, on } from '@ngrx/store';
import { createEntityAdapter, EntityState } from '@ngrx/entity';
import { c2Actions } from '../actions/c2.actions';

export type C2ContextState = EntityState<C2Context>;

const adapter = createEntityAdapter<C2Context>({
  selectId: (context) => context.uniqueID,
});

export interface C2State {
  timeframe: Timeframe;
  contexts: C2ContextState;
}

export const initialState: C2State = {
  timeframe: { start: 0, end: 0 },
  contexts: adapter.getInitialState(),
};

export const c2Reducer = createReducer(
  initialState,
  on(c2Actions.timeframeChange, (state, { payload }) => ({
    ...state,
    timeframe: payload,
  })),
  on(c2Actions.c2ContextLoaded, (state, { payload }) => ({
    ...state,
    contexts: adapter.setAll(
      payload.map((context: C2Context) => ({
        ...context,
        selected: state.contexts.entities[context.uniqueID]?.selected ?? false,
        units: state.contexts.entities[context.uniqueID]?.units ?? [],
      })),
      state.contexts
    ),
  })),
  on(c2Actions.contextSelected, (state, { payload }) => ({
    ...state,
    contexts: adapter.updateOne(
      {
        id: payload,
        changes: { selected: true },
      },
      state.contexts
    ),
  })),
  on(c2Actions.contextDeselected, (state, { payload }) => ({
    ...state,
    contexts: adapter.updateOne(
      {
        id: payload,
        changes: { selected: false },
      },
      state.contexts
    ),
  })),
  on(c2Actions.selectAllContexts, (state, { payload }) => ({
    ...state,
    contexts: adapter.updateMany(
      (state.contexts.ids as string[]).map((id) => ({
        id,
        changes: { selected: payload },
      })),
      state.contexts
    ),
  })),
  on(c2Actions.unitsLoaded, (state, { payload }) => ({
    ...state,
    contexts: adapter.updateOne(
      { id: payload.uniqueId, changes: { units: payload.units } },
      state.contexts
    ),
  }))
);

export const c2Feature = createFeature({
  name: 'c2',
  reducer: c2Reducer,
  extraSelectors: ({ selectContexts, selectTimeframe }) => {
    const contextSelectors = adapter.getSelectors(selectContexts);

    const selectMetricContexts = createSelector(
      contextSelectors.selectAll,
      (contexts) => contexts.filter((c) => c.type === 'MET_DATA_TYPE')
    );

    const selectVcciContexts = createSelector(
      contextSelectors.selectAll,
      (contexts) => contexts.filter((c) => c.type === 'VCCI_DATA_TYPE')
    );

    const selectSelectedContexts = createSelector(
      contextSelectors.selectAll,
      (contexts) => contexts.filter((c) => c.selected)
    );

    return {
      ...contextSelectors,
      selectMetricContexts,
      selectVcciContexts,
      selectSelectedContexts,
    };
  },
});

export const {
  selectTimeframe: selectC2Timeframe,
  selectMetricContexts,
  selectVcciContexts,
  selectSelectedContexts,
  selectAll: selectAllC2Contexts,
  selectEntities: selectC2ContextEntities,
} = c2Feature;
