import { Equipment, SimEntity, Timeframe } from '@/models';
import { createFeature, createReducer, on } from '@ngrx/store';
import { hrActions } from '../actions/hr.actions';
import { FilterStatus } from '@/components/entity-selector/entity-selector.component';

export interface HoldingsRollupState {
  entities: SimEntity[];
  selectedEntityIds: number[];
  equipment: Equipment[];
  commodities: Equipment[];
  selectedEquipmentIds: number[];
  timeframe: Timeframe;
  reportData: any;
  holdingsContribution: any[];
  entityFilters: FilterStatus[];
}

export const initialState: HoldingsRollupState = {
  entities: [],
  selectedEntityIds: [],
  equipment: [],
  commodities: [],
  selectedEquipmentIds: [],
  timeframe: { start: 0, end: 0 },
  reportData: null,
  holdingsContribution: [],
  entityFilters: [],
};

export const hrReducer = createReducer(
  initialState,
  on(hrActions.entitiesLoaded, (state, { payload }) => ({
    ...state,
    entities: payload,
  })),
  on(hrActions.entitySelected, (state, { payload }) => {
    return {
      ...state,
      selectedEntityIds: payload.selected
        ? [...state.selectedEntityIds, ...payload.items.map((e) => e.id)]
        : state.selectedEntityIds.filter(
            (id) => !payload.items.map((e) => e.id).includes(id)
          ),
    };
  }),
  on(hrActions.equipmentLoaded, (state, { payload }) => ({
    ...state,
    equipment: payload[0],
  })),
  on(hrActions.commoditiesLoaded, (state, { payload }) => ({
    ...state,
    commodities: payload[1],
  })),
  on(hrActions.equipmentSelected, (state, { payload }) => {
    return {
      ...state,
      selectedEquipmentIds: payload.selected
        ? [
            ...state.selectedEquipmentIds,
            ...payload.items.map((e) => e.equipmentTypeId),
          ]
        : state.selectedEquipmentIds.filter(
            (id) => !payload.items.map((e) => e.equipmentTypeId).includes(id)
          ),
    };
  }),
  on(hrActions.timeframeChange, (state, { payload }) => ({
    ...state,
    timeframe: payload,
  })),
  on(hrActions.reportGenerated, (state, { payload }) => ({
    ...state,
    reportData: payload,
  })),
  on(hrActions.holdingsContributionLoaded, (state, { payload }) => ({
    ...state,
    holdingsContribution: payload,
  })),
  on(hrActions.resetState, () => initialState),
  on(hrActions.entityFilterChange, (state, { payload }) => ({
    ...state,
    entityFilters: payload,
  }))
);

export const hrFeature = createFeature({
  name: 'holdings-rollup',
  reducer: hrReducer,
  extraSelectors: ({}) => {
    return {};
  },
});

export const {
  selectEntities,
  selectSelectedEntityIds,
  selectEquipment,
  selectCommodities,
  selectSelectedEquipmentIds,
  selectTimeframe,
  selectReportData,
  selectHoldingsContribution,
  selectEntityFilters: selectHrEntityFilters,
} = hrFeature;
