import { createFeature, createReducer, createSelector, on } from '@ngrx/store';
import { summaryActions } from '../actions/summary.actions';
import { SummaryState } from '@/models/summary.model';

export const DEFAULT_MAP_URL =
  'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';

export const initialState: SummaryState = {
  ROM: { controlMeasuresMonitored: 0, activeControlMeasureNames: [] },
  CombatPower: { unitsBelow100: 0 },
  CMO: { controlMeasuresMonitored: 0 },
  HHour: { entitiesCrossed: 0 },
  POE: { bluforControlMeasures: 0, opforControlMeasures: 0 },
  EntityWatch: { entitiesWatched: 0 },
  Fratricide: { incidentCount: 0 },
  EnemyEngagements: {
    controlMeasureId: 0,
    controlMeasureName: '',
    numberEngaged: 0,
    engagedEntityNames: [],
  },
};

export const summaryReducer = createReducer(
  initialState,
  on(summaryActions.dataReceived, (state, { payload }) => ({
    ...state,
    ...payload,
  }))
);

export const summaryFeature = createFeature({
  name: 'summary',
  reducer: summaryReducer,
});

export const { name, reducer, selectSummaryState } = summaryFeature;
