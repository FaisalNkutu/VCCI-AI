import { SimChartData } from '@/chart-v2/chart-v2.component';
import { ControlMeasure, POEPoint, Timeframe } from '@/models';
import { poeActions } from '@/store/actions/poe.actions';
import { createFeature, createReducer, createSelector, on } from '@ngrx/store';
import { ChartOptions } from 'chart.js';

export interface POEState {
  poePoints: POEPoint[];
  selectedIDs: number[];
  redTimeframe: Timeframe;
  blueTimeframe: Timeframe;
  controlMeasures: ControlMeasure[];
  selectedControlMeasureIds: number[];
}

const initialState: POEState = {
  poePoints: [],
  selectedIDs: [],
  redTimeframe: { start: 0, end: 0 },
  blueTimeframe: { start: 0, end: 0 },
  controlMeasures: [],
  selectedControlMeasureIds: [],
};

const chartOptions: ChartOptions = {
  backgroundColor: 'rgb(107,224,65)',
  responsive: true,
  scales: {
    y: {
      grid: {
        color: '#414546',
      },
      ticks: {
        color: 'white',
        precision: 0,
      },
    },

    x: {
      ticks: {
        color: 'white',
      },
    },
  },
  plugins: {
    datalabels: {
      display: false,
    },
  },
  maintainAspectRatio: false,
};
/**
 * When min max time is loaded, that is the initial values for the range of the time slider.
 * After that the values change based on the user sliding them
 */
export const poeReducer = createReducer(
  initialState,

  on(poeActions.redTimeframeChanged, (state, { payload }) => {
    return {
      ...state,
      redTimeframe: payload,
    };
  }),
  on(poeActions.blueTimeframeChanged, (state, { payload }) => {
    return {
      ...state,
      blueTimeframe: payload,
    };
  }),
  on(poeActions.controlMeasuresLoaded, (state, { payload }) => ({
    ...state,
    controlMeasures: payload,
  })),
  on(poeActions.controlMeasureSelected, (state, { payload }) => ({
    ...state,
    selectedControlMeasureIds: [...state.selectedControlMeasureIds, payload],
  })),
  on(poeActions.pointsLoaded, (state, { payload }) => ({
    ...state,
    poePoints: payload,
  })),

  on(poeActions.controlMeasureDeselected, (state, { payload }) => ({
    ...state,
    selectedControlMeasureIds: state.selectedControlMeasureIds.filter(
      (id) => id !== payload
    ),
  }))
);

export const poeFeature = createFeature({
  name: 'poe',
  reducer: poeReducer,
  extraSelectors: ({
    selectSelectedControlMeasureIds,
    selectControlMeasures,
    selectPoePoints,
  }) => {
    const selectSelectedControlMeasures = createSelector(
      selectControlMeasures,
      selectSelectedControlMeasureIds,
      (controlMeasures, selectedCmIds) => {
        return controlMeasures.filter((cm) => selectedCmIds.includes(cm.id));
      }
    );

    const selectControlMeasuresWithNames = createSelector(
      selectControlMeasures,
      (controlMeasures) => {
        return controlMeasures.map((cm) => ({ ...cm, name: cm.cmname }));
      }
    );

    const selectBlueChartData = createSelector(
      selectPoePoints,
      (points): SimChartData<'line'> => {
        return {
          chartData: {
            labels: points
              .filter((p) => p.friendlycm)
              .map((p) => p.formattedtime),
            datasets: [
              {
                label: 'Offside Count',
                data: points
                  .filter((p) => p.friendlycm)
                  .map((p) => p.offsidecount),
                backgroundColor: 'rgba(107, 224, 65, 0.2)',
                borderColor: 'rgb(107,224,65)',
                borderWidth: 2,
              },
              {
                type: 'line',
                label: 'Opposite Count',
                data: points
                  .filter((p) => p.friendlycm)
                  .map((p) => p.oppositecount),
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgb(63,153,243)',
                borderWidth: 2,
              },
            ],
          },
          chartOptions: chartOptions,
        };
      }
    );
    const selectRedChartData = createSelector(
      selectPoePoints,
      (points): SimChartData<'line'> => {
        return {
          chartData: {
            labels: points
              .filter((p) => !p.friendlycm)
              .map((p) => p.formattedtime),
            datasets: [
              {
                type: 'line',
                label: 'Offside Count',
                data: points
                  .filter((p) => !p.friendlycm)
                  .map((p) => p.offsidecount),
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgb(107,224,65)',
                borderWidth: 2,
              },
              {
                type: 'line',
                label: 'Opposite Count',
                data: points
                  .filter((p) => !p.friendlycm)
                  .map((p) => p.oppositecount),
                backgroundColor: 'rgba(255, 99, 99, 0.2)',
                borderColor: 'rgb(255, 60, 60)',
                borderWidth: 2,
              },
            ],
          },
          chartOptions: chartOptions,
        };
      }
    );

    return {
      selectSelectedControlMeasures,
      selectBlueChartData,
      selectRedChartData,
      selectControlMeasuresWithNames,
    };
  },
});

export const {
  selectRedTimeframe,
  selectBlueTimeframe,
  selectBlueChartData,
  selectRedChartData,
  selectControlMeasuresWithNames: selectPOEControlMeasuresWithNames,
  selectSelectedControlMeasureIds: selectedPOECmIds,
  selectControlMeasures: selectPOEControlMeasures,
} = poeFeature;
