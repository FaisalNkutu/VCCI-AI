import {ROMEntity, ROMEntityDetails, ROMSpec, ROMStats, Timeframe} from '@/models';
import {createFeature, createReducer, createSelector, on} from '@ngrx/store';
import {romActions} from '@/store/actions/rom.actions';
import 'chartjs-adapter-date-fns';
import {SimChartData} from '@/chart-v2/chart-v2.component';
import {FilterStatus} from '@/components/entity-selector/entity-selector.component';

export interface ROMState {
  allRomSpecs: ROMSpec[];
  currentRomSpec: ROMSpec | null;
  allEntities: ROMEntity[];
  currentEntityDetails: ROMEntityDetails[];
  currentEntityIds: number[];
  refThreshold: number;
  entityQuery: string | null;
  entityFilters: FilterStatus[];
  stats: ROMStats | undefined;
  timeframe: Timeframe;
}

const initialState: ROMState = {
  allRomSpecs: [],
  currentRomSpec: null,
  allEntities: [],
  currentEntityDetails: [],
  currentEntityIds: [],
  refThreshold: 0,
  entityQuery: null,
  entityFilters: [],
  stats: undefined,
  timeframe: {start: 0, end: 0},
};

export const romFeature = createFeature({
  reducer: createReducer(
    initialState,
    on(romActions.dataLoaded, (state, {payload}) => {
      // Try to preserve the existing selected ROM if it exists in the new data
      const preservedSelection =
        state.currentRomSpec && payload.length > 0
          ? payload.find((rom) => rom.id === state.currentRomSpec!.id) ||
          payload[0]
          : payload[0];

      return {
        ...state,
        allRomSpecs: payload,
        currentRomSpec: preservedSelection,
      };
    }),
    on(romActions.refThresholdChanged, (state, {payload}) => ({
      ...state,
      refThreshold: payload,
    })),
    on(romActions.entityQuery, (state, {payload}) => ({
      ...state,
      entityQuery: payload,
    })),
    on(romActions.statsLoaded, (state, {payload}) => ({
      ...state,
      stats: payload,
    })),
    on(romActions.captureSelected, (state, {payload}) => ({
      ...state,
      currentRomSpec: payload,
      currentEntityIds: [],
      currentEntityDetails: [],
    })),
    on(romActions.entitiesLoaded, (state, {payload}) => ({
      ...state,
      allEntities: payload,
    })),
    on(romActions.entitySelected, (state, {payload}) => ({
      ...state,
      currentEntityIds: [payload, ...state.currentEntityIds],
    })),
    on(romActions.entityDeselected, (state, {payload}) => ({
      ...state,
      currentEntityIds: state.currentEntityIds.filter((id) => id !== payload),
    })),
    on(romActions.entityDetailsLoaded, (state, {payload}) => ({
      ...state,
      currentEntityDetails: [...payload].sort((a, b) => a.time - b.time), //ensure the details are sorted by time, important for the charts
    })),
    on(romActions.batchEntitySelection, (state, {payload}) => ({
      ...state,
      currentEntityIds: payload.selected
        ? [...state.currentEntityIds, ...payload.entityIds]
        : state.currentEntityIds.filter((id) => !payload.entityIds.includes(id)),
    })),
    on(romActions.entityFilterChange, (state, {payload}) => ({
      ...state,
      entityFilters: payload,
    })),
    on(romActions.timeframeChange, (state, {payload}) => ({
      ...state,
      timeframe: payload,
    }))
  ),

  name: 'rom',

  extraSelectors: (
    {
      selectAllEntities,
      selectCurrentEntityIds,
      selectCurrentEntityDetails,
      selectRefThreshold,
      selectEntityQuery,
    }) => {

    const selectSelectedEntities = createSelector(
      selectAllEntities,
      selectCurrentEntityIds,
      (entities, selectedIds): ROMEntity[] => {
        return entities.filter((e) => selectedIds.includes(e.id));
      }
    );

    const selectEntitiesWithQueryFilter = createSelector(
      selectAllEntities,
      selectEntityQuery,
      (entities, query) => {
        if (!query || query.length === 0) {
          return entities;
        }
        return entities.filter((e) =>
          e.name.toLowerCase().includes(query.toLowerCase())
        );
      }
    );

    const selectVelocityChartData = createSelector(
      selectCurrentEntityDetails,
      selectRefThreshold,
      (entityDetails, refThreshold): SimChartData<'line'> => {
        return {
          chartData: {
            labels: entityDetails.map((e) => e.formattedtime),
            datasets: [
              {
                type: 'line',
                label: 'Reference (KM/hr)',
                data: entityDetails.map((e) => refThreshold),
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgb(107,224,65)',
                borderWidth: 2,
              },
              {
                type: 'line',
                label: 'Velocity (KM/hr)',
                data: entityDetails.map((e) => e.avgspeed),
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgb(63,153,243)',
                borderWidth: 2,
              },
            ],
          },
          chartOptions: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
              x: {
                ticks: {
                  color: 'white',
                },
              },
              y: {
                grid: {
                  color: '#414546',
                },
                ticks: {
                  color: 'white',
                },
                title: {
                  display: true,
                  text: 'Speed (KM/hr)',
                  color: 'white',
                },
              },
            },
            plugins: {
              datalabels: {
                display: false,
              },
            },
          },
        };
      }
    );

    const selectDistanceChartData = createSelector(
      selectCurrentEntityDetails,
      (entityDetails): SimChartData<'line'> => {
        return {
          chartData: {
            labels: entityDetails.map((e) => e.formattedtime),
            datasets: [
              {
                type: 'line',
                label: 'Cumulative Distance (Meters)',
                data: entityDetails.map((e) => e.avgcumuldist),
                backgroundColor: 'rgba(255, 99, 99, 0.2)',
                borderColor: 'rgb(255, 60, 60)',
                borderWidth: 2,
              },
            ],
          },
          chartOptions: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
              x: {
                ticks: {
                  color: 'white',
                },
              },
              y: {
                grid: {
                  color: '#414546',
                },
                ticks: {
                  color: 'white',
                },
                title: {
                  display: true,
                  text: 'Meters',
                  color: 'white',
                },
              },
            },
            plugins: {
              datalabels: {
                display: false,
              },
            },
          },
        };
      }
    );

    return {
      selectSelectedEntities,
      selectEntitiesWithQueryFilter,
      selectVelocityChartData,
      selectDistanceChartData,
    };
  },
});

export const {
  name,
  reducer,
  selectAllRomSpecs,
  selectCurrentRomSpec,
  selectCurrentEntityIds,
  selectEntityFilters,
  selectStats,
  selectTimeframe,
  selectSelectedEntities,
  selectEntitiesWithQueryFilter,
  selectVelocityChartData,
  selectDistanceChartData,
} = romFeature;
