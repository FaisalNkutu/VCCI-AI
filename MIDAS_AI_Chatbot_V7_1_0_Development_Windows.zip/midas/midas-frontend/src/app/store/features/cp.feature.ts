import {
  CombatPowerDataGrouping,
  CombatPowerEntityDetails,
  CombatPowerEquipmentDetails,
  CombatPowerEquipmentPoint,
  CombatPowerPoint,
  CombatPowerTableData,
  CombatPowerEquipmentTableData,
  SimEntity,
  Timeframe,
} from '@/models';
import { createFeature, createReducer, createSelector, on } from '@ngrx/store';
import { cpActions } from '../actions/cp.actions';
import { ChartData } from 'chart.js';
import { SimChartData } from '@/chart-v2/chart-v2.component';
import { FilterStatus } from '@/components/entity-selector/entity-selector.component';

export interface CombatPowerState {
  entities: SimEntity[];
  selectedEntityIds: number[];
  entityDetails: CombatPowerEntityDetails | undefined;
  entityEquipmentDetails: CombatPowerEquipmentDetails | undefined;
  combatPowerTableData: CombatPowerTableData | undefined;
  combatPowerEquipmentTableData: CombatPowerEquipmentTableData[];
  combatPowerDataGrouping: CombatPowerDataGrouping;
  excludeZeroToHundred: boolean;
  timeframe: Timeframe;
  entityFilters: FilterStatus[];
}

export const initialState: CombatPowerState = {
  entities: [],
  selectedEntityIds: [],
  entityDetails: undefined,
  entityEquipmentDetails: undefined,
  combatPowerTableData: undefined,
  combatPowerEquipmentTableData: [],
  combatPowerDataGrouping: 'unit',
  excludeZeroToHundred: false,
  timeframe: { start: 0, end: 0 },
  entityFilters: [],
};

export const cpReducer = createReducer(
  initialState,
  on(cpActions.entitiesLoaded, (state, { payload }) => ({
    ...state,
    entities: payload,
  })),
  on(cpActions.entitySelected, (state, { payload }) => ({
    ...state,
    selectedEntityIds: [...state.selectedEntityIds, payload],
  })),
  on(cpActions.entityDeselected, (state, { payload }) => ({
    ...state,
    selectedEntityIds: state.selectedEntityIds.filter((id) => id !== payload),
  })),
  on(cpActions.entityDetailsLoaded, (state, { payload }) => ({
    ...state,
    entityDetails: payload,
  })),
  on(cpActions.entityEquipmentDetailsLoaded, (state, { payload }) => ({
    ...state,
    entityEquipmentDetails: payload,
  })),
  on(cpActions.combatPowerDataLoaded, (state, { payload }) => ({
    ...state,
    combatPowerTableData: payload,
  })),
  on(cpActions.combatPowerEquipmentDataLoaded, (state, { payload }) => ({
    ...state,
    combatPowerEquipmentTableData: payload,
  })),
  on(cpActions.dataGroupingChanged, (state, { payload }) => ({
    ...state,
    combatPowerDataGrouping: payload,
  })),
  on(cpActions.includeAllChanged, (state, { payload }) => ({
    ...state,
    excludeZeroToHundred: payload,
  })),
  on(cpActions.batchEntitySelection, (state, { payload }) => {
    const { entityIds, selected } = payload;
    const updatedSelectedEntityIds = selected
      ? [...state.selectedEntityIds, ...entityIds]
      : state.selectedEntityIds.filter((id) => !entityIds.includes(id));
    return {
      ...state,
      selectedEntityIds: updatedSelectedEntityIds,
    };
  }),
  on(cpActions.timeframeChange, (state, { payload }) => ({
    ...state,
    timeframe: payload,
  })),
  on(cpActions.entityFilterChange, (state, { payload }) => ({
    ...state,
    entityFilters: payload,
  }))
);

export const cpFeature = createFeature({
  name: 'combat-power',
  reducer: cpReducer,
  extraSelectors: ({
    selectEntityDetails,
    selectEntityEquipmentDetails,
  }) => {
    const selectCpChartData = createSelector(
      selectEntityDetails,
      (entityDetails): SimChartData<'line', CombatPowerPoint> | undefined => {
        if (!entityDetails) {
          entityDetails = {
            entCPHash: {},
            timeArray: [],
            average: [],
          };
        }

        const sortedTimeArray = [...entityDetails.timeArray].sort(
          (a, b) => a.time - b.time
        );

        const entityPoints = Object.keys(entityDetails.entCPHash).map(
          (entityId, index) => {
            // Generate a unique color for each entity, golden angle approximation for good color distribution
            const hue = (index * 137.5) % 360;
            const color = `hsl(${hue}, 70%, 50%)`;
            const entityTimePoints = entityDetails.entCPHash[entityId];
            return {
              label: `${entityDetails.entCPHash[entityId][0]?.entityName}`,
              data: entityTimePoints.map((timePoint) => {
                return {
                  combatPower: timePoint.combatPower,
                  id: entityId,
                  formattedTime: timePoint.formattedTime,
                  entityName: timePoint.entityName,
                  time: timePoint.time,
                };
              }),
              backgroundColor: `${color}33`, // 33 is hex for 20% opacity
              borderColor: color,
              borderWidth: 2,
              spanGaps: true,
              parsing: {
                yAxisKey: 'combatPower',
                xAxisKey: 'formattedTime',
              },
            };
          }
        );

        const chartData: ChartData<'line', CombatPowerPoint[]> = {
          datasets: entityPoints,
        };
        chartData.datasets.push({
          type: 'line',
          label: 'Average',
          data: entityDetails.average.map((average) => {
            return {
              combatPower: average.combatPower,
              formattedTime: average.formattedTime,
              id: '-1',
              entityName: 'Average',
              time: average.time,
            };
          }),
          backgroundColor: 'rgb(255,255,255)',
          borderColor: 'rgb(255,255,255)',
          borderDash: [4, 4],
          borderWidth: 4,
          spanGaps: true,
          parsing: {
            yAxisKey: 'combatPower',
            xAxisKey: 'formattedTime',
          },
        });

        return {
          chartData: chartData,
          chartOptions: {
            backgroundColor: 'rgb(107,224,65)',
            responsive: true,
            scales: {
              x: {
                type: 'category',
                labels: sortedTimeArray.map((v) => v.formattedTime), //this is required
                grid: {
                  color: '#414546',
                },
                ticks: {
                  color: 'white',
                  maxRotation: 45,
                  minRotation: 45,
                },
              },
              y: {
                grid: {
                  color: '#414546',
                },
                ticks: {
                  color: 'white',
                  precision: 0,
                },
              },
            },
            plugins: {
              datalabels: {
                display: false,
              },
            },
            interaction: {
              mode: 'nearest',
              intersect: true,
            },
            onHover: (event: any, activeElements: any[]) => {
              if (activeElements.length) {
                event.native.target.style.cursor = 'pointer';
              } else {
                event.native.target.style.cursor = 'default';
              }
            },
            maintainAspectRatio: false,
          },
        };
      }
    );

    const selectCpEquipmentChartData = createSelector(
      selectEntityEquipmentDetails,
      (
        entityEquipmentDetails
      ): SimChartData<'line', CombatPowerEquipmentPoint> | undefined => {
        if (!entityEquipmentDetails?.hlding_per_equipment_type) {
          entityEquipmentDetails = {
            hlding_per_equipment_type: {},
          };
        }
        const sortedTimeArray = Array.from(
          new Set(
            Object.values(entityEquipmentDetails.hlding_per_equipment_type)
              .flat()
              .sort((a, b) => a.time - b.time)
              .map((v) => v.formattedTime)
          )
        );

        const entityPoints = Object.keys(
          entityEquipmentDetails.hlding_per_equipment_type
        ).map((equipmentType, index) => {
          // Generate a unique color for each entity, golden angle approximation for good color distribution
          const hue = (index * 137.5) % 360;
          const color = `hsl(${hue}, 70%, 50%)`;
          const entityTimePoints =
            entityEquipmentDetails.hlding_per_equipment_type[equipmentType];
          return {
            label: `${entityEquipmentDetails.hlding_per_equipment_type[equipmentType][0]?.equipmentType}`,
            data: entityTimePoints.map((timePoint) => {
              return {
                currentQuantity: timePoint.currentQuantity,
                originalQuantity: timePoint.originalQuantity,
                id: equipmentType,
                formattedTime: timePoint.formattedTime,
                equipmentType: timePoint.equipmentType,
                time: timePoint.time,
              };
            }),
            backgroundColor: `${color}33`, // 33 is hex for 20% opacity
            borderColor: color,
            borderWidth: 2,
            spanGaps: true,
            scales: {
              y: {
                ticks: {
                  precision: 0,
                }
              }
            },
            parsing: {
              yAxisKey: 'currentQuantity',
              xAxisKey: 'formattedTime',
            },
          };
        });

        const chartData: ChartData<'line', CombatPowerEquipmentPoint[]> = {
          datasets: entityPoints,
        };

        return {
          chartData: chartData,
          chartOptions: {
            backgroundColor: 'rgb(107,224,65)',
            responsive: true,
            scales: {
              x: {
                type: 'category',
                labels: sortedTimeArray, //this is required
                grid: {
                  color: '#414546',
                },
                ticks: {
                  color: 'white',
                  maxRotation: 45,
                  minRotation: 45,
                },
              },
              y: {
                grid: {
                  color: '#414546',
                },
                ticks: {
                  color: 'white',
                },
              },
            },
            plugins: {
              datalabels: {
                display: false,
              },
            },
            interaction: {
              mode: 'nearest',
              intersect: true,
            },
            onHover: (event: any, activeElements: any[]) => {
              if (activeElements.length) {
                event.native.target.style.cursor = 'pointer';
              } else {
                event.native.target.style.cursor = 'default';
              }
            },
            maintainAspectRatio: false,
          },
        };
      }
    );

    return { selectCpChartData, selectCpEquipmentChartData };
  },
});

export const {
  selectEntities: selectCpEntities,
  selectSelectedEntityIds: selectCpSelectedEntityIds,
  selectTimeframe: selectCpTimeframe,
  selectCpChartData,
  selectCpEquipmentChartData,
  selectCombatPowerTableData,
  selectCombatPowerEquipmentTableData,
  selectCombatPowerDataGrouping,
  selectExcludeZeroToHundred,
  selectEntityFilters: selectCpEntityFilters,
} = cpFeature;
