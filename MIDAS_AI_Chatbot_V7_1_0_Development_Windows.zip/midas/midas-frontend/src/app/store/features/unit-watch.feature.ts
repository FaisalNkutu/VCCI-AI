import { SimEntity } from '@/models';
import { createFeature, createReducer, on, createSelector } from '@ngrx/store';
import { unitWatchActions } from '../actions/unit-watch.actions';
import { UnitWatchUpdate, UpdateCategory } from '@/models/unit-watch.model';
import { FilterStatus } from '@/components/entity-selector/entity-selector.component';

export interface UnitWatchState {
  entities: SimEntity[];
  unitWatchEvents: UnitWatchUpdate[];
  selectedIds: number[];
  selectedCategories: UpdateCategory[];
  entityFilters: FilterStatus[];
}

const initialState: UnitWatchState = {
  // Initial state will be defined when needed
  entities: [],
  unitWatchEvents: [],
  selectedIds: [],
  selectedCategories: [
    'ACT',
    'FRAT',
    'CPOWER',
    'HHOUR',
    'ENGAGE',
    'HOLDING',
    'NOS',
  ], // Default to all categories
  entityFilters: [],
};

export const unitWatchReducer = createReducer(
  initialState,
  on(unitWatchActions.unitsLoaded, (state, { payload }) => ({
    ...state,
    entities: payload,
    selectedIds: payload.map((entity) => entity.id), //default to all ids selected
  })),
  on(unitWatchActions.unitWatchEventReceived, (state, { payload }) => ({
    ...state,
    unitWatchEvents: [...payload.results, ...state.unitWatchEvents],
  })),
  on(unitWatchActions.clearUnitWatchEvents, (state) => ({
    ...state,
    unitWatchEvents: [],
    selectedIds: [],
  })),
  on(unitWatchActions.unitSelected, (state, { payload }) => ({
    ...state,
    selectedIds: [...state.selectedIds, payload],
  })),
  on(unitWatchActions.unitDeselected, (state, { payload }) => ({
    ...state,
    selectedIds: state.selectedIds.filter((id) => id !== payload),
  })),
  on(unitWatchActions.batchUnitSelection, (state, { payload }) => ({
    ...state,
    selectedIds: payload.selection
      ? [...state.selectedIds, ...payload.unitIds]
      : state.selectedIds.filter((id) => !payload.unitIds.includes(id)),
  })),
  on(unitWatchActions.setCategoryFilterSelected, (state, { payload }) => ({
    ...state,
    selectedCategories: [...state.selectedCategories, payload],
  })),
  on(unitWatchActions.setCategoryFilterDeselected, (state, { payload }) => ({
    ...state,
    selectedCategories: state.selectedCategories.filter(
      (category) => category !== payload
    ),
  })),
  on(unitWatchActions.entityFilterChange, (state, { payload }) => ({
    ...state,
    entityFilters: payload,
  }))
);

export const unitWatchFeature = createFeature({
  name: 'unitWatch',
  reducer: unitWatchReducer,
  extraSelectors: ({
    selectEntities,
    selectSelectedIds,
    selectUnitWatchEvents,
    selectSelectedCategories,
  }) => ({
    selectSelectedEntities: createSelector(
      selectEntities,
      selectSelectedIds,
      (entities, selectedIds) =>
        entities.filter((entity) => selectedIds.includes(entity.id))
    ),
    selectFilteredUnitWatchEvents: createSelector(
      selectUnitWatchEvents,
      selectSelectedIds,
      selectSelectedCategories,
      (unitWatchEvents, selectedIds, selectedCategories) =>
        unitWatchEvents.filter(
          (event) =>
            selectedIds.includes(event.entityId) &&
            selectedCategories.includes(event.category)
        )
    ),
  }),
});

export const {
  selectEntities: selectUnitWatchEntities,
  selectUnitWatchEvents,
  selectSelectedEntities: selectSelectedUnitWatchEntities,
  selectFilteredUnitWatchEvents,
  selectSelectedIds: selectSelectedUnitWatchIds,
  selectSelectedCategories,
  selectEntityFilters: selectUnitWatchEntityFilters,
} = unitWatchFeature;
