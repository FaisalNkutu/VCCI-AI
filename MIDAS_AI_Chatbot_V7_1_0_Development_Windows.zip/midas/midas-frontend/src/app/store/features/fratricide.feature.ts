import { SimChartData } from '@/chart-v2/chart-v2.component';
import {
  FratIncident,
  FratricideGraphPoint,
  Timeframe
} from '@/models';
import { fratricideActions } from '@/store/actions/fratricide.actions';
import { createFeature, createReducer, createSelector, on } from '@ngrx/store';

export interface FratricideState {
  timeframe: Timeframe;
  fratChartData: FratricideGraphPoint[];
  fratIncidents: FratIncident[]; //the incidents at a point selected on the chart
  selectedPointIdx: number | undefined;
  selectedFratIncident: FratIncident | undefined;
  selectedFratIncidentDetails: FratIncident[] | undefined;
}

const initialState: FratricideState = {
  timeframe: { start: 0, end: 0 },
  fratChartData: [],
  selectedPointIdx: undefined,
  fratIncidents: [],
  selectedFratIncident: undefined,
  selectedFratIncidentDetails: [],
};

export const fratricideReducer = createReducer(
  initialState,
  on(fratricideActions.timeframeChange, (state, { payload }) => ({
    ...state,
    timeframe: payload,
  })),
  on(fratricideActions.resultsLoaded, (state, { payload }) => ({
    ...state,
    fratChartData: payload,
  })),
  on(fratricideActions.incidentDetailsLoaded, (state, { payload }) => ({
    ...state,
    selectedFratIncidentDetails: payload,
  })),
  on(fratricideActions.pointSelected, (state, { payload }) => ({
    ...state,
    selectedPointIdx: payload,
  })),
  on(fratricideActions.incidentsAtTimeLoaded, (state, { payload }) => ({
    ...state,
    fratIncidents: payload,
  })),
  on(fratricideActions.fratIncidentSelected, (state, { payload }) => ({
    ...state,
    selectedFratIncident: payload,
  }))
);

export const fratricideFeature = createFeature({
  name: 'fratricide',
  reducer: fratricideReducer,
  extraSelectors: ({ selectFratChartData }) => {
    const selectFratGraphData = createSelector(
      selectFratChartData,
      (
        points
      ): SimChartData<
        'line',
        { count: number; formattedTime: string; time: number }
      > => {
        return {
          chartData: {
            labels: points.map((p) => p.formattedTime),
            datasets: [
              {
                type: 'line',
                label: 'Incident Count',
                data: points.map((p) => ({
                  count: p.fratIncidentCount,
                  formattedTime: p.formattedTime,
                  time: p.time,
                })),
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgb(107,224,65)',
                borderWidth: 2,
                parsing: {
                  yAxisKey: 'count',
                  xAxisKey: 'formattedTime',
                },
              },
            ],
          },
          chartOptions: {
            backgroundColor: 'rgb(107,224,65)',
            responsive: true,
            interaction: {
              mode: 'nearest',
              intersect: true,
            },
            onHover: (event: any, activeElements: any[]) => {
              if (activeElements.length) {
                event.native.target.style.cursor = 'pointer';
              } else {
                event.native.target.style.cursor = 'default';
              }
            },
            scales: {
              y: {
                grid: {
                  color: '#414546',
                },
                ticks: {
                  color: 'white',
                  precision: 0
                },
              },

              x: {
                ticks: {
                  color: 'white',
                },
              },
            },
            plugins: {
              datalabels: {
                display: false,
              },
            },
            maintainAspectRatio: false,
          },
        };
      }
    );

    return {
      selectFratGraphData,
    };
  },
});
export const {
  selectTimeframe,
  selectFratGraphData,
  selectFratIncidents,
  selectSelectedFratIncident,
  selectSelectedFratIncidentDetails,
} = fratricideFeature;
