import {SimChartData} from '@/chart-v2/chart-v2.component';
import {HHourSpecs, LodLocation, Unit} from '@/models';
import {createFeature, createReducer, createSelector, on} from '@ngrx/store';
import {hhourActions} from '../actions/h-hour.actions';
import {FilterStatus} from '@/components/entity-selector/entity-selector.component';

export interface HHourState {
  units: Unit[];
  hHours: HHourSpecs[];
  selectedUnitIds: number[];
  selectedHHour: HHourSpecs | null;
  selectedLODLocation: LodLocation[];
  threshold: number;
  searchedUnit: string | null;
  achievedHHour: number;
  entityFilters: FilterStatus[];
}

const initialState: HHourState = {
  units: [],
  hHours: [],
  selectedUnitIds: [],
  selectedHHour: null,
  selectedLODLocation: [],
  threshold: 0,
  searchedUnit: null,
  achievedHHour: 0,
  entityFilters: [],
};

export const hHourReducer = createReducer(
  initialState,
  on(hhourActions.achievedHHourLoaded, (state, {payload}) => ({
    ...state,
    achievedHHour: payload,
  })),
  on(hhourActions.unitsLoaded, (state, {units, hHour}) => ({
    ...state,
    units: units,
    selectedHHour: hHour,
  })),
  on(hhourActions.hHourDataLoaded, (state, {data}) => {
    // Try to preserve the existing selected h-hour if it exists in the new data
    const preservedSelection =
      state.selectedHHour && data.length > 0
        ? data.find((h) => h.id === state.selectedHHour!.id) || data[0]
        : data[0];

    return {
      ...state,
      hHours: data,
      selectedHHour: preservedSelection,
      threshold: preservedSelection?.threshold || 0,
    };
  }),
  on(hhourActions.lODInfoLoaded, (state, {lod}) => ({
    ...state,
    selectedLODLocation: lod,
  })),
  on(hhourActions.thresholdChanged, (state, action) => ({
    ...state,
    threshold: action.threshold,
  })),
  on(hhourActions.hHourSelection, (state, {payload}) => {
    return {
      ...state,
      selectedHHour: payload.hHour,
      threshold: payload.hHour.threshold,
      selectedUnitIds: [],
    };
  }),
  on(hhourActions.batchUnitSelection, (state, {payload}) => ({
    ...state,
    selectedUnitIds: payload.selection
      ? [...new Set([...state.selectedUnitIds, ...payload.unitIds])]
      : state.selectedUnitIds.filter((id) => !payload.unitIds.includes(id)),
  })),
  on(hhourActions.entityFilterChange, (state, {payload}) => ({
    ...state,
    entityFilters: payload,
  }))
);

export const hHourFeature = createFeature({
  name: 'hhour',
  reducer: hHourReducer,
  extraSelectors: ({
                     selectSearchedUnit,
                     selectUnits,
                     selectSelectedUnitIds,
                     selectThreshold,
                   }) => {
    const selectSelectedUnits = createSelector(
      selectSelectedUnitIds,
      selectUnits,
      (ids, units) => {
        return units.filter((unit) => ids.includes(unit.id));
      }
    );

    const unitSelectorWithFilter = createSelector(
      selectSearchedUnit,
      selectUnits,
      (query, units) => {
        if (!query || query.length === 0) {
          return units;
        }
        return units.filter((u) => u.name.includes(query));
      }
    );

    const selectLODChartData = createSelector(
      selectSelectedUnits,
      selectThreshold,
      (units, threshold): SimChartData<'line'> => {
        return {
          chartData: {
            labels: units.map((u) => u.name),
            datasets: [
              {
                label: 'Threshold',
                data: units.map((u) => threshold),
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgb(107,224,65)',
                borderWidth: 2,
              },
              {
                label: 'Deviation',
                data: units.map((u) => u.deviation),
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgb(63,153,243)',
                borderWidth: 2,
              },
            ],
          },
          chartOptions: {
            backgroundColor: 'rgb(107,224,65)',
            responsive: true,
            scales: {
              y: {
                grid: {
                  color: '#414546',
                },
                min: threshold * -1 * 1.5,
                max: threshold * 1.5,
                ticks: {
                  color: 'white',
                },
              },
              x: {
                ticks: {
                  color: 'white',
                },
              },
            },
            maintainAspectRatio: false,
          },
        };
      }
    );

    return {
      selectSelectedUnits,
      unitSelectorWithFilter,
      selectLODChartData,
    };
  },
});

export const {
  selectUnits,
  selectSelectedUnits,
  selectSelectedUnitIds: selectHHourSelectedUnitIds,
  selectSearchedUnit,
  selectHHours,
  selectSelectedHHour,
  selectSelectedLODLocation,
  selectThreshold,
  unitSelectorWithFilter,
  selectLODChartData,
  selectAchievedHHour,
  selectEntityFilters: selectHHourEntityFilters,
} = hHourFeature;
