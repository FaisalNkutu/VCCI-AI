import { SimChartData } from '@/chart-v2/chart-v2.component';
import { FilterStatus } from '@/components/entity-selector/entity-selector.component';
import {
  CmChartData,
  CMEntity,
  CmPoint,
  ControlMeasure,
  ControlMeasureTableRow,
  SFMap,
  SimEntity,
  Timeframe
} from '@/models';
import { cmActions } from '@/store/actions/cm.actions';
import { sidebarActions } from '@/store/actions/sidebar.actions';
import { stringToHexColor } from '@/utils/color-gen';
import { createEntityAdapter, EntityState } from '@ngrx/entity';
import { createFeature, createReducer, createSelector, on } from '@ngrx/store';

export interface ControlMeasureEntityState extends EntityState<SimEntity> {}

const adaptor = createEntityAdapter<SimEntity>();

export interface ControlMeasureState {
  entities: ControlMeasureEntityState;
  deselectedIds: number[]; //deselected entity ID's
  tableData: SFMap<CMEntity[]>;
  controlMeasures: ControlMeasure[];
  selectedControlMeasureIds: number[];
  chartData: SFMap<CmChartData>;
  timeframe: Timeframe;
  entityFilters: FilterStatus[];
}

const initialState: ControlMeasureState = {
  entities: adaptor.getInitialState(),
  tableData: {},
  deselectedIds: [],
  controlMeasures: [],
  selectedControlMeasureIds: [],
  chartData: {},
  timeframe: { start: 0, end: 0 },
  entityFilters: [],
};

export const cmReducer = createReducer(
  initialState,
  on(cmActions.controlMeasuresLoaded, (state, { payload }) => ({
    ...state,
    controlMeasures: payload,
  })),
  on(cmActions.unitSelected, (state, { payload }) => ({
    ...state,
    deselectedIds: state.deselectedIds.filter((id) => id !== payload),
  })),
  on(cmActions.unitDeselected, (state, { payload }) => ({
    ...state,
    deselectedIds: [...state.deselectedIds, payload],
  })),
  on(sidebarActions.minMaxTimeLoaded, (state, { payload }) => ({
    ...state,
    timeSliderRange: payload,
  })),
  on(cmActions.entitiesLoaded, (state, { payload }) => {
    const updatedEntities = adaptor.setAll(payload, state.entities);

    return {
      ...state,
      selectedIds: payload.map((e) => e.id).filter((id) => !state.deselectedIds.includes(id)),
      entities: updatedEntities,
    };
  }),
  on(cmActions.selectedControlMeasuresLoaded, (state, { payload }) => ({
    ...state,
    tableData: payload,
  })),
  on(cmActions.timeframeChange, (state, { payload }) => ({
    ...state,
    timeframe: payload,
  })),
  on(cmActions.controlMeasureSelected, (state, { payload }) => ({
    ...state,
    selectedControlMeasureIds: [...state.selectedControlMeasureIds, payload],
  })),
  on(cmActions.controlMeasureDeselected, (state, { payload }) => ({
    ...state,
    selectedControlMeasureIds: state.selectedControlMeasureIds.filter(
      (id) => id !== payload
    ),
  })),
  on(cmActions.chartDataLoaded, (state, { payload }) => ({
    ...state,
    chartData: payload,
  })),
  on(cmActions.batchUnitSelection, (state, { payload }) => ({
    ...state,
    deselectedIds: payload.selection
      ? state.deselectedIds.filter((id) => !payload.unitIds.includes(id))
      : [...state.deselectedIds, ...payload.unitIds],
  })),
  on(cmActions.occupyingUnitsLoaded, (state, { payload }) => ({
    ...state,
  })),
  on(cmActions.entityFilterChange, (state, { payload }) => ({
    ...state,
    entityFilters: payload,
  }))
);

export const controlMeasureFeature = createFeature({
  name: 'cmoc',
  reducer: cmReducer,
  extraSelectors: ({
    selectDeselectedIds,
    selectEntities,
    selectControlMeasures,
    selectSelectedControlMeasureIds,
    selectTableData,
    selectChartData,
  }) => {
    const entitySelectors = adaptor.getSelectors(selectEntities);

    const selectSelectedIds = createSelector(
      selectDeselectedIds,
      entitySelectors.selectEntities,
      (deselectedIds, entities) => {
        return Object.values(entities)
          .map((e) => (e as SimEntity).id)
          .filter((id) => !deselectedIds.includes(id));
      }
    );

    const selectDeselectedEntities = createSelector(
      selectDeselectedIds,
      entitySelectors.selectEntities,
      (deselectedIds, entities) => {
        return deselectedIds.map((id) => entities[id]);
      }
    );

    const selectCMWithName = createSelector(
      selectControlMeasures,
      (controlMeasures) => {
        return controlMeasures.map((cm) => ({
          ...cm,
          name: cm.cmname,
        }));
      }
    );

    const selectSelectedControlMeasures = createSelector(
      selectControlMeasures,
      selectSelectedControlMeasureIds,
      (controlMeasures, selectedCmIds) => {
        return controlMeasures.filter((cm) => selectedCmIds.includes(cm.id));
      }
    );

    /**
     *
     */
    const selectCmTableData = createSelector(
      selectTableData,
      selectSelectedControlMeasures,
      (cmMap, controlMeasures): ControlMeasureTableRow[] => {
        return Object.keys(cmMap).map((cmId) => {
          const cm = controlMeasures.find(
            (cm) => cm.id === parseInt(cmId)
          );
          const cName = cm?.cmname;
          return {
            name: cName || cmId,
            units: cmMap[cmId],
          };
        });
      }
    );

    // This puts all the data into arrays for correct placement on the chart. Given the new
    // way the chart is being done, this can probably be changed later.
    const selectCmChartData = createSelector(
      selectChartData,
      selectControlMeasures,
      (data, controlMeasures): SimChartData<'bar'> => {
        //the res will be the cmID -> arr of all the counts over times
        const res: {
          [index: string]: (CmPoint & { formattedTime: string })[];
        } = {};
        const dataKeysInOrder = Object.keys(data).sort(
          (a, b) => parseInt(a) - parseInt(b)
        );
        dataKeysInOrder.forEach((timeKey) => {
          const dataPoint = data[timeKey];
          const hm = dataPoint.jOccupationsHM;
          Object.keys(hm).forEach((cmId) => {
            if (!res[cmId]) {
              res[cmId] = [];
            }
            res[cmId].push({
              ...hm[cmId],
              formattedTime: dataPoint.formattedTime,
              time: dataPoint.simulationTime,
            });
          });
        });

        return {
          chartData: {
            labels: Object.values(data).map((d) => d.formattedTime),
            datasets: Object.keys(res).map((key) => {
              return {
                type: 'bar',
                label: controlMeasures.find((cm) => cm.id === parseInt(key))
                  ?.cmname,
                data: res[key],
                backgroundColor:
                  stringToHexColor(
                    controlMeasures.find((cm) => cm.id === parseInt(key))
                      ?.cmname || key
                  ) + '66',
                borderColor: stringToHexColor(
                  controlMeasures.find((cm) => cm.id === parseInt(key))
                    ?.cmname || key
                ),
                borderWidth: 2,
              };
            }),
          },
          chartOptions: {
            backgroundColor: 'rgb(107,224,65)',
            responsive: true,
            scales: {
              y: {
                grid: {
                  color: '#414546',
                },
                stacked: true,
                ticks: {
                  color: 'white',
                  precision: 0,
                },
              },
              x: {
                stacked: true,
                ticks: {
                  color: 'white',
                },
              },
            },
            parsing: {
              yAxisKey: 'entityCount',
              xAxisKey: 'formattedTime',
            },
            maintainAspectRatio: false,
            plugins: {
              datalabels: {
                formatter: (value: CmPoint) => {
                  return value.entityCount > 0 ? value.entityCount : '';
                }
              }
            }
          },
        };
      }
    );

    return {
      ...entitySelectors,
      selectCmChartData,
      selectDeselectedEntities,
      selectSelectedControlMeasures,
      selectCmTableData,
      selectCMWithName,
      selectSelectedIds,
    };
  },
});

export const {
  selectEntities,
  selectTableData,
  selectSelectedIds,
  selectDeselectedIds,
  selectAll: selectAllCMEntities,
  selectControlMeasures,
  selectCMWithName: selectCMOCWithName,
  selectTimeframe,
  selectCmChartData,
  selectCmTableData,
  selectSelectedControlMeasureIds,
  selectSelectedControlMeasures,
  selectDeselectedEntities,
  selectEntityFilters: selectCmEntityFilters,
} = controlMeasureFeature;
