import { ConnectedDB, StatusData } from '@/models';
import { sidebarActions } from '@/store/actions/sidebar.actions';
import { customWidthExpandCollapse } from '@/utils/animate';
import { routes } from '@/utils/routes';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { Component, computed, EventEmitter, inject, input, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { NavigationEnd, Router, RouterLink, RouterLinkActive } from '@angular/router';
import { Store } from '@ngrx/store';
import { APP_PREF_KEY } from '@/app.guard';
import { MatIcon } from '@angular/material/icon';
import { MatTooltip } from '@angular/material/tooltip';
import { filter } from 'rxjs';
import { toSignal } from '@angular/core/rxjs-interop';

export interface SidebarItem {
  name: string;
  icon: string;
  urls: string[];
  active?: boolean;
  reason?: string;
}

export type SidebarItems = {
  title: string;
  items: SidebarItem[];
}

@Component({
  selector: 'sidebar',
  imports: [
    CommonModule,
    RouterLinkActive,
    NgOptimizedImage,
    RouterLink,
    MatTooltip,
    MatIcon,
    MatSelectModule,
    FormsModule
  ],
  standalone: true,
  animations: [customWidthExpandCollapse('translate', '256px', '48px')],
  templateUrl: './sidebar.component.html',
})
export class SidebarComponent {
  statusData = input<StatusData | null | undefined>();
  connectedDB = input<ConnectedDB | null | undefined>();
  advMetrics = input<boolean>(true);

  sidebar = computed<SidebarItems[]>(() => {
    if (this.advMetrics()) {
      return [
        {
          title: 'DASHBOARD',
          items: [
            { name: routes['SUM'].name, icon: 'dashboard', urls: ['/advmetrics', routes['SUM'].route] },
            {
              name: routes['HH'].name,
              icon: 'timer',
              urls: ['/advmetrics', routes['HH'].route],
              active: this.statusData()?.jHHourActive || false,
              reason: this.statusData()?.jHHourReason || ''
            },
            {
              name: routes['ROM'].name,
              icon: 'sensors',
              urls: ['/advmetrics', routes['ROM'].route],
              active: this.statusData()?.jROMActive || false,
              reason: this.statusData()?.jROMReason || ''
            },
            {
              name: routes['CM'].name,
              icon: 'open_with',
              urls: ['/advmetrics', routes['CM'].route],
              active: this.statusData()?.jCMOccupationsActive || false,
              reason: this.statusData()?.jCMOccsReason || ''
            },
            {
              name: routes['POE'].name,
              icon: 'picture_in_picture',
              urls: ['/advmetrics', routes['POE'].route],
              active: this.statusData()?.jPOEActive || false,
              reason: this.statusData()?.jPOEReason || ''
            },
            {
              name: routes['FRAT'].name,
              icon: 'skull',
              urls: ['/advmetrics', routes['FRAT'].route],
              active: this.statusData()?.jFratricideActive || false,
            },
            {
              name: routes['ENG'].name,
              icon: 'swords',
              urls: ['/advmetrics', routes['ENG'].route],
              active: this.statusData()?.jEnemyEngagementsActive || false,
              reason: this.statusData()?.jEneEngReason || ''
            },
            {
              name: routes['CP'].name,
              icon: 'shield_with_house',
              urls: ['/advmetrics', routes['CP'].route],
              active: this.statusData()?.jCPowerActive || false,
            },
            {
              name: routes['UW'].name,
              icon: 'visibility',
              urls: ['/advmetrics', routes['UW'].route],
              active: this.statusData()?.jEntityWatchActive || false,
              reason: this.statusData()?.jEntWatchReason || ''
            },
            {
              name: 'C2 Compare',
              icon: 'visibility',
              urls: ['/advmetrics', 'c2'],
              active: false, //TODO: nate add active status
              reason: '' //TODO: nate add reason
            }
          ]
        },
        {
          title: 'REPORTS',
          items: [
            { name: routes['HR'].name, icon: 'area_chart', urls: ['/advmetrics', routes['HR'].route] }
          ]
        }
      ];
    } else {
      return [
        {
          title: 'DASHBOARD',
          items: [
            { name: 'Unit', icon: 'military_tech', urls: ['/lvcts', 'unit'], active: this.isActive('lvcts/unit')() }
          ]
        },
        {
          title: 'REPORTS',
          items: [
            {
              name: 'Trainee',
              icon: 'person_add',
              urls: ['/lvcts', 'trainee'],
              active: this.isActive('lvcts/trainee')()
            }
          ]
        }
      ];
    }
  });

  private router = inject(Router);

  currentUrl = toSignal(
    this.router.events.pipe(filter(e => e instanceof NavigationEnd)),
    { initialValue: null }
  );

  isActive = (path: string) => computed(() => {
    this.currentUrl();
    return this.router.url.includes(path);
  });

  @Input() timeFormatOptions: string[] = [];
  @Input() selectedTimeFormat: string = '';
  @Output()
  expandedEmitter: EventEmitter<boolean> = new EventEmitter<boolean>();
  isExpanded: boolean = true;

  constructor(private store: Store) {
  }

  onExpandedChange(): void {
    this.isExpanded = !this.isExpanded;
  }

  onTimeFormatChange(val: string): void {
    this.store.dispatch(sidebarActions.timeFormatSelected(val));
  }

  protected readonly Object = Object;

  switchEnvironment() {
    localStorage.removeItem(APP_PREF_KEY);
    this.router.navigate(['/']).then();
  }
}
