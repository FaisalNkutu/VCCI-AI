import { Component, Input, Output, EventEmitter } from '@angular/core';
import {
  CdkFixedSizeVirtualScroll,
  CdkVirtualForOf,
  CdkVirtualScrollViewport,
} from '@angular/cdk/scrolling';
import { MatCheckbox, MatCheckboxChange } from '@angular/material/checkbox';
import { ArrayPipe } from '@/pipes/array.pipe';
import { SimEntity } from '@/models';

export interface VirtualSelectionScrollItem {
  id: number;
  name: string;
}

@Component({
    selector: 'virtual-selection-scroll',
    standalone: true,
    imports: [
        CdkFixedSizeVirtualScroll,
        CdkVirtualForOf,
        CdkVirtualScrollViewport,
        MatCheckbox,
        ArrayPipe,
    ],
    templateUrl: './virtual-selection-scroll.component.html'
})
export class VirtualSelectionScrollComponent {
  @Input() items: VirtualSelectionScrollItem[] = [];
  @Input() selectedIds: number[] = [];
  @Input() itemSize: number = 14;
  @Input() height: string = '100%';
  @Input() width: string = '100%';
  @Input() trackBy: (index: number, item: any) => string = (
    index: number,
    item: any
  ) => item.id.toString();

  @Output() selectionChange = new EventEmitter<{
    item: any;
    selected: boolean;
  }>();

  onSelectionChange(event: MatCheckboxChange): void {
    const item = this.items.find(i => event.source.value === i.id.toString());
    const selected = event.checked;
    this.selectionChange.emit({ item, selected });
  }
}
