import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { API_URL } from '@/app.config';

export interface ProcessorStatus { [field: string]: unknown; }
export interface CombatPowerEntity { id: number; name: string; children?: CombatPowerEntity[]; }

export type ResultRow = Record<string, unknown>;

export interface QueryResult {
  success: boolean;
  answer: string;
  sql: string;
  rows: ResultRow[];
  row_count: number;
  attempts: number;
  error: string;
  explanation?: {
    confidence?: {
      score?: number;
    };
    retrieved_tables?: Array<{
      name?: string;
    }>;
  };
}

export interface JobStatus {
  status: 'running' | 'done' | 'error';
  stage?: {
    stage?: string;
    attempt?: number;
  };
  result?: QueryResult | null;
}

export interface AgentHealth {
  database?: string;
  schema_source?: string;
  sql_model?: string;
  render_model?: string;
}

@Injectable({
  providedIn: 'root'
})
export class MidasAiService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = `${API_URL}/midas/ai`;

  processorStatus(): Observable<ProcessorStatus> {
    return new Observable(subscriber => {
      const stream = new EventSource(`${API_URL}/advmetrics/sse/mstatus`);
      const deadline = setTimeout(() => subscriber.error(new Error('Status unavailable')), 8000);
      stream.onmessage = event => {
        try {
          const status: unknown = JSON.parse(event.data);
          if (!status || typeof status !== 'object' || Array.isArray(status)) throw new Error('Invalid status');
          subscriber.next(status as ProcessorStatus);
          subscriber.complete();
        } catch (error) { subscriber.error(error); }
      };
      stream.onerror = () => subscriber.error(new Error('Status unavailable'));
      return () => { clearTimeout(deadline); stream.close(); };
    });
  }

  combatPowerEntities(): Observable<CombatPowerEntity[]> {
    return this.http.get<CombatPowerEntity[]>(`${API_URL}/advmetrics/cp/entities`, {
      params: { ignoreZeroHundredValues: 'false' }
    });
  }

  health(): Observable<AgentHealth> {
    return this.http.get<AgentHealth>(`${this.baseUrl}/health`);
  }

  start(
    question: string,
    originalQuestion: string,
    history: string[]
  ): Observable<{ job_id: string }> {
    return this.http.post<{ job_id: string }>(
      `${this.baseUrl}/query/start`,
      {
        question,
        options: {
          processor_help: {
            question: originalQuestion,
            history
          }
        }
      }
    );
  }

  status(jobId: string): Observable<JobStatus> {
    return this.http.get<JobStatus>(
      `${this.baseUrl}/query/status/${encodeURIComponent(jobId)}`
    );
  }
}
