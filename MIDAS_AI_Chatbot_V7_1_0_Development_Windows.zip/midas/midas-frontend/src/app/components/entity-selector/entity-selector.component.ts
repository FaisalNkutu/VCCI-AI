import { SelectionModel } from '@angular/cdk/collections';

import {
  ChangeDetectionStrategy,
  Component,
  computed,
  effect,
  EventEmitter,
  input,
  Input,
  OnDestroy,
  Output,
  signal,
  viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckbox } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import {
  SFFlatNode,
  SFTableTreeCellDirective,
  SFTableTreeDef,
  SFTreeMetaData,
  StickyDirective,
  StickyService,
  SymbologyComponent,
  VirtualTableTreeComponent,
} from '@simfront/common-libs';

interface WithSymbol {
  milSym: string;
  children: WithSymbol[];
  isFriendly: boolean;
}

interface FilterFunctionBase<T> {
  id: string;
  name: string;
  singlePass?: boolean;
  hide?: boolean;
}

interface CheckboxFilterFunction<T> extends FilterFunctionBase<T> {
  type: 'checkbox' | 'switch';
  value: boolean;
  fn: (item: T, value: boolean) => boolean;
}

interface SelectFilterFunction<T> extends FilterFunctionBase<T> {
  type: 'select';
  value: string;
  options: { label: string; value: string }[];
  fn: (item: T, value: string) => boolean;
}

export type FilterFunction<T> =
  | CheckboxFilterFunction<T>
  | SelectFilterFunction<T>;

export interface FilterStatus {
  id: string;
  value: string | boolean;
}

@Component({
  selector: 'entity-selector',
  imports: [
    FormsModule,
    SFTableTreeCellDirective,
    SFTableTreeDef,
    StickyDirective,
    VirtualTableTreeComponent,
    SymbologyComponent,
    MatCheckbox,
    MatTableModule,
    MatMenuModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    MatFormFieldModule,
    MatSelectModule,
    MatSlideToggleModule
],
  templateUrl: './entity-selector.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [StickyService],
  styles: [
    `
      :host {
        height: 100%;
      }

      .entity-selector {
        ::ng-deep .cdk-virtual-scrollable {
          height: 100% !important;
        }
        ::ng-deep #wrapper #left svg {
          margin: 0 auto;
        }

        ::ng-deep td .node {
          height: auto;
          width: fit-content;
        }

        ::ng-deep td .node button:disabled {
          display: none;
        }

        ::ng-deep td:has(.node),
        ::ng-deep td[role='cell'] {
          padding: 0;
          padding-right: 10px;
        }

        /* Adjust first column to fit content (kind of a hack) */
        ::ng-deep td:has(.node):nth-child(1),
        ::ng-deep td[role='cell']:nth-child(1) {
          width: 0px !important;
        }
      }
    `,
  ],
})
export class EntitySelectorComponent<T extends WithSymbol>
  implements OnDestroy
{
  // Inputs using new signal-based input API
  data = input.required<T[]>();
  @Input({ required: true }) metaData!: SFTreeMetaData<T, string>;
  @Input() headerTitle = 'Entity Selector';
  @Input() showSelectionOptions = true;
  @Input() debounceMs = 300;
  @Input() noDataMessage: string = "There are no entities to display.";
  @Input() set filters(value: FilterFunction<T>[]) {
    this.customFilters.update((filters) => {
      const filtersMap = new Map<string, FilterFunction<T>>();
      filters.forEach((f) => filtersMap.set(f.id, f));
      value.forEach((f) => filtersMap.set(f.id, f));
      return Array.from(filtersMap.values());
    });
  }
  @Input() set prefilter(filters: FilterStatus[]) {
    this.customFilters.update((currentFilters) => {
      filters.forEach((f) => {
        if (f.id === 'search-filter') {
          this.searchTerm.set(f.value as string);
          return;
        }
        const existingFilterIndex = currentFilters.findIndex(
          (cf) => cf.id === f.id
        );
        if (existingFilterIndex !== -1) {
          currentFilters[existingFilterIndex].value = f.value;
        }
      });
      return currentFilters;
    });
  }
  @Input() set preselect(items: (string | number)[]) {
    if (!items.length) {
      this.selection.clear();
      return;
    }
    this.selection.select(...items.map((i) => i.toString()));
  }

  @Output() onSelectionChange = new EventEmitter<{
    selected: boolean;
    items: T[];
  }>();
  @Output() onClearFilters = new EventEmitter<void>();
  @Output() onFilterChange = new EventEmitter<FilterStatus[]>();

  // Internal signals
  searchTerm = signal('');
  searchDebounceTimer: number | undefined;
  customFilters = signal<FilterFunction<T>[]>([]);

  selectAllChildren = signal(true);
  deselectAllChildren = signal(false);
  selection = new SelectionModel<string>(true);

  columns = ['Symbol', 'Name'];

  table = viewChild.required<VirtualTableTreeComponent<T, string>>(
    VirtualTableTreeComponent
  );

  expanded = computed(() => this.table().treeControl.expandedHash);
  options = computed<IntersectionObserverInit>(() => ({
    threshold: [0],
    root: this.table().scrollContainer().getElementRef().nativeElement,
    rootMargin: '-56px 0px 0px 0px',
  }));

  hasChildren = computed(() => {
    return this.data().some((item) => {
      const children = this.metaData.children(item);
      return children && children.length > 0;
    });
  });

  get allSelected() {
    // calculate length of children for all nodes in filtered data
    const allChildren = this.filteredData().flatMap((item) => {
      const children = this.metaData.children(item);
      return children
        ? children.map((c) => this.metaData.controlTrackBy(c))
        : [];
    });
    // combine with top-level items
    const allIds = [
      ...this.filteredData().map((item) => this.metaData.controlTrackBy(item)),
      ...allChildren,
    ];
    return (
      allIds.length > 0 && this.selection.selected.length === allIds.length
    );
  }

  get selectedCount() {
    return this.selection.selected.length;
  }

  // Computed filtered data with optimized filtering
  filteredData = computed(() => {
    const searchTerm = this.searchTerm().toLowerCase();
    const filters = this.customFilters();
    const data = this.data();

    if (!searchTerm && filters.length === 0) {
      return data;
    }

    // Pass the actual T type to filterTreeData
    return this.filterTreeData(
      data,
      searchTerm,
      filters as FilterFunction<T>[]
    ).sort((a, b) => (b?.children.length ?? 0) - (a?.children.length ?? 0));
  });

  // Performance-optimized computed values
  totalCount = computed(() => this.countAllItems(this.data()));
  filteredCount = computed(() => this.countAllItems(this.filteredData()));

  // Updated check for active filters
  hasActiveFilters = computed(
    () =>
      this.searchTerm() ||
      this.customFilters().some((f) =>
        f.type === 'checkbox' || f.type === 'switch'
          ? f.value
          : f.value !== (f as SelectFilterFunction<T>).options[0].value
      )
  );

  filterStatus = computed<FilterStatus[]>(() => [
    ...this.customFilters().map((f) => ({
      id: f.id,
      value: f.value,
    })),
    { id: 'search-filter', value: this.searchTerm() },
  ]);

  // Computed for highlighting
  highlightedLabel = computed(() => {
    return (text: string) => this.highlightSearchTerm(text, this.searchTerm());
  });

  constructor() {
    const defaultFilters: FilterFunction<T>[] = [
      {
        id: 'hostility-filter',
        name: 'Hostility',
        type: 'select',
        value: 'all',
        options: [
          { label: 'All', value: 'all' },
          { label: 'Friendly', value: 'friendly' },
          { label: 'Hostile', value: 'hostile' },
        ],
        fn: (item: T, value: string) => {
          if (value === 'all') return true;
          if (value === 'friendly') return item.isFriendly === true;
          if (value === 'hostile') return item.isFriendly === false;
          return true;
        },
        singlePass: true,
      },
      {
        id: 'orbat-filter',
        name: 'ORBAT / Orphan',
        type: 'select',
        value: 'all',
        options: [
          { label: 'All', value: 'all' },
          { label: 'ORBAT', value: 'orbat' },
          { label: 'Orphan', value: 'orphan' },
        ],
        fn: (item: T, value: string) => {
          if (value === 'all') return true;
          if (value === 'orbat') return item.children.length > 0;
          if (value === 'orphan')
            return !item.children || item.children.length === 0;
          return true;
        },
        singlePass: true,
      },
    ];

    this.customFilters.set(defaultFilters);
    effect(() => {
      this.customFilters.update((filters) => {
        return filters.map((f) => {
          if (f.id === 'orbat-filter') {
            return {
              ...f,
              hide: !this.hasChildren(),
            };
          }
          return f;
        });
      });
    });
  }

  ngOnDestroy(): void {
    if (this.searchDebounceTimer) {
      clearTimeout(this.searchDebounceTimer);
    }
  }

  private countAllItems(data: T[]): number {
    return data.reduce((count, item) => {
      const children = this.metaData.children(item);
      return count + 1 + (children ? this.countAllItems(children as T[]) : 0);
    }, 0);
  }

  private filterTreeData(
    data: T[],
    searchTerm: string,
    filters: FilterFunction<T>[]
  ): T[] {
    const lowerSearchTerm = searchTerm?.toLowerCase() || '';
    const deepFilters = filters.filter((f) => !f.singlePass);
    const singlePassFilters = filters.filter((f) => f.singlePass);

    const applyFilter = (filter: FilterFunction<T>, item: T): boolean => {
      if (filter.type === 'checkbox' || filter.type === 'switch') {
        return filter.fn(item, filter.value);
      }
      if (filter.type === 'select') {
        return filter.fn(item, filter.value);
      }
      return true;
    };

    const recursiveFilter = (items: T[]): T[] => {
      const results: T[] = [];

      for (const item of items) {
        const itemLabel = this.metaData.label(item);
        const matchesSearch =
          !lowerSearchTerm || itemLabel.toLowerCase().includes(lowerSearchTerm);

        // Apply deep filters: check if ALL deep filters pass
        const matchesDeepFilters =
          deepFilters.length === 0 ||
          deepFilters.every((filter) => applyFilter(filter, item));

        const itemMatchesDeepCriteria = matchesSearch && matchesDeepFilters;

        // Apply single-pass filters: check if ALL single-pass filters pass
        const matchesAllSinglePass =
          singlePassFilters.length === 0 ||
          singlePassFilters.every((filter) => applyFilter(filter, item));

        const itemMatchesDirectly =
          itemMatchesDeepCriteria && matchesAllSinglePass;

        const children = this.metaData.children(item);
        let filteredChildren: T[] = [];
        let itemIncludedByChild = false;

        if (children && children.length > 0) {
          filteredChildren = recursiveFilter(children as T[]);
          itemIncludedByChild = filteredChildren.length > 0;
        }

        if (itemMatchesDirectly || itemIncludedByChild) {
          const filteredItem = { ...item };
          if (children) {
            (filteredItem as any)[this.metaData.childrenProp] =
              filteredChildren;
          }
          results.push(filteredItem);
        }
      }

      return results;
    };
    return recursiveFilter(data);
  }

  isEntity = (entity: unknown): entity is WithSymbol => {
    if (!entity || typeof entity !== 'object') return false;
    return 'milSym' in entity && typeof entity.milSym === 'string';
  };

  isSelected(id: string): boolean {
    return this.selection.isSelected(id.toString());
  }

  selectEntity(item: SFFlatNode<T, string>) {
    this.selection.toggle(item.id.toString());
    const isSelected = this.selection.isSelected(item.id.toString());
    const emitArray = [item.obj as T];

    if (this.selectAllChildren() || this.deselectAllChildren()) {
      const children: SFFlatNode<T, string>[] =
        this.table().treeControl.getDescendants(item);

      if (isSelected) {
        this.selection.select(...children.map((c) => c.id.toString()));
      } else {
        this.selection.deselect(...children.map((c) => c.id.toString()));
      }
      emitArray.push(...children.map((c) => c.obj as T));
    }
    this.onSelectionChange.emit({
      selected: isSelected,
      items: emitArray,
    });
  }

  toggleAll(select: boolean) {
    const allChildren = this.filteredData().flatMap((item) => {
      const children = this.metaData.children(item);
      return children ? children : [];
    });
    const allItems = [...this.filteredData(), ...allChildren];

    const selection = allItems.map((item) =>
      this.metaData.controlTrackBy(item)
    );

    if (select) {
      this.selection.select(...selection);
    } else {
      this.selection.clear();
    }
    this.onSelectionChange.emit({
      selected: select,
      items: allItems,
    });
  }

  onSearchInput(event: Event) {
    const value = (event.target as HTMLInputElement).value;
    if (this.searchDebounceTimer) {
      clearTimeout(this.searchDebounceTimer);
    }
    this.searchDebounceTimer = setTimeout(() => {
      this.searchTerm.set(value);
      this.searchDebounceTimer = undefined;
      this.onFilterChange.emit(this.filterStatus());
    }, this.debounceMs);
  }

  clearSearch() {
    this.searchTerm.set('');
    this.onFilterChange.emit(this.filterStatus());
  }

  highlightSearchTerm(text: string, searchTerm: string): string {
    if (!searchTerm) return text;

    const regex = new RegExp(`(${this.escapeRegExp(searchTerm)})`, 'gi');
    return text.replace(
      regex,
      '<span class="bg-yellow-200 rounded text-black">$1</span>'
    );
  }

  private escapeRegExp(string: string): string {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  // Helper for filter UI changes (updates the mutable value)
  onFilterValueChange(filterName: string, newValue: string | boolean) {
    this.customFilters.update((filters) => {
      const index = filters.findIndex((f) => f.name === filterName);

      if (index > -1) {
        return filters.map((f, i) => {
          if (i === index) {
            // Update the mutable 'value' property
            return { ...f, value: newValue } as FilterFunction<T>;
          }
          return f;
        });
      }
      return filters;
    });
    this.onFilterChange.emit(this.filterStatus());
  }

  clearAllFilters() {
    this.clearSearch();
    this.customFilters.update((filters) =>
      filters.map((f) => {
        if (f.type === 'select') {
          return {
            ...f,
            // Reset select to first option
            value: (f as SelectFilterFunction<T>).options[0].value,
          };
        } else {
          // Reset checkbox/switch to false
          return { ...f, value: false };
        }
      })
    );
    this.onClearFilters.emit();
    this.onFilterChange.emit([]);
  }

  hasMatchingChildren(item: SFFlatNode<T, string>): boolean {
    if (!this.searchTerm()) return false;

    const children = this.table().treeControl.getDescendants(item);
    return children.some((child) =>
      this.metaData
        .label(child.obj as T)
        .toLowerCase()
        .includes(this.searchTerm().toLowerCase())
    );
  }

  getMatchingChildrenCount(item: SFFlatNode<T, string>): number {
    if (!this.searchTerm()) return 0;

    const children = this.table().treeControl.getDescendants(item);
    return children.filter((child) =>
      this.metaData
        .label(child.obj as T)
        .toLowerCase()
        .includes(this.searchTerm().toLowerCase())
    ).length;
  }

  // Public API methods for programmatic control
  selectAll() {
    const allIds = this.getAllItemIds(this.filteredData());
    this.selection.select(...allIds);
  }

  deselectAll() {
    this.selection.clear();
  }

  expandAll() {
    this.table().treeControl.expandAll();
  }

  collapseAll() {
    this.table().treeControl.collapseAll();
  }

  private getAllItemIds(data: T[]): string[] {
    return data.reduce((ids: string[], item) => {
      const itemId = this.metaData.controlTrackBy(item);
      ids.push(itemId);

      const children = this.metaData.children(item);
      if (children) {
        ids.push(...this.getAllItemIds(children as T[]));
      }

      return ids;
    }, []);
  }
}
