/*
 * Copyright 2026 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

import {Component, Input} from "@angular/core";
import {SymbologyComponent} from "@simfront/common-libs";

@Component({
  selector: 'name-and-mil-symbol-cell',
  imports: [SymbologyComponent],
  templateUrl: './name-and-mil-symbol-cell.component.html',
})
export class NameAndMilSymbolCellComponent {
  @Input({required: true}) name!: string;
  @Input({required: true}) milSymbol!: string;
}
