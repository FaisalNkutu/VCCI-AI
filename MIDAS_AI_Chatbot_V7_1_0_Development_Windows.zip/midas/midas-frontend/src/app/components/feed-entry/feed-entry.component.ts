import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UnitWatchUpdate } from '@/models';

export interface FeedEntryData {
  id: string;
  entityId: string;
  entityName: string;
  message: string;
  timestamp: Date;
  type: 'info' | 'warning' | 'error' | 'success';
  priority: 'low' | 'medium' | 'high' | 'critical';
}

@Component({
  selector: 'feed-entry',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './feed-entry.component.html'
})
export class FeedEntryComponent {
  @Input() entry!: UnitWatchUpdate;

  getTimeAgo(timestamp: number): string {

    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - timestamp) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes} min ago`;
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours} hour${diffInHours > 1 ? 's' : ''} ago`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays} day${diffInDays > 1 ? 's' : ''} ago`;
  }

  getBorderColor(): string {
    switch (this.entry.category) {
      case 'HOLDING':
        return 'border-l-4 border-l-blue-500/80';
      case 'ACT':
        return 'border-l-4 border-l-green-500/80';
      case 'FRAT':
        return 'border-l-4 border-l-red-500/80';
      case 'CPOWER':
        return 'border-l-4 border-l-purple-500/80';
      case 'HHOUR':
        return 'border-l-4 border-l-orange-500/80';
      case 'ENGAGE':
        return 'border-l-4 border-l-pink-500/80';
      case 'NOS':
        return 'border-l-4 border-l-gray-500/80';
      default:
        return 'border-l-4 border-l-blue-500/80';
    }
  }
}
