/** Served from the `flexgis` assets entry in angular.json. */
export const FLEX_GIS_BASE_PATH = '/assets/flexgis';

/** Dynamic-layer parent created by Flex GIS before LOAD_COMPLETE. */
export const GIS_DYNAMIC_LAYER_PARENT_ID = '-999';

export const DEFAULT_MAP_CENTER: GisCoordinate = { lat: 35.2271, lon: -80.8431 };
export const DEFAULT_MAP_ZOOM = 6;

/**
 * Shape values Flex GIS `createElement` switches on.
 * Point, polyline, polygon, and bounds match the Angular bundle.
 * Circle is the runtime value used by the iframe (`CIRCLE = 64`).
 */
export const gisShapeType = {
  point: 1,
  polyline: 2,
  polygon: 4,
  circle: 64,
  bounds: 512,
} as const;

export type GisShapeType = (typeof gisShapeType)[keyof typeof gisShapeType];

export type GisCoordinate = {
  lat: number;
  lon: number;
  alt?: number;
};

export type GisMapElementInfo = {
  id: string;
  shapeType: GisShapeType;
  sidc?: string;
  /** MIL-STD-2525 / APP-6, same field the client sends on entity symbols. */
  standard?: '2525' | 'APP6';
  coordinate?: GisCoordinate;
  coordinates?: GisCoordinate[];
  /** Circle center. Flex GIS reads this, not `coordinate`, for shape type 64. */
  centerLocation?: GisCoordinate;
  radius?: number;
  /**
   * Text drawn beside a 2525 point. The symbol texture does not read
   * `uniqueDesignation`, so a sidc point should not send both.
   */
  label?: string;
  uniqueDesignation?: string;
  filled?: boolean;
  /**
   * Point tint, or the stroke color Pixi applies in `drawGeometry`.
   * A packed RGB integer matches `UPDATE_COLOR`. A CSS color that includes
   * alpha is faded by that stroke. The bundle has no separate fill field.
   */
  color?: number | string;
  /**
   * PNG for a point that has no sidc. Flex GIS loads `/assets/` plus this path
   * (`UPDATE_ELEMENT_ICON` reads the same field). A sidc point ignores it.
   */
  icon?: string;
};

export type GisMapElement = {
  layerId: string;
  elementInfo: GisMapElementInfo;
};

export type GisCommand = {
  type: string;
  [key: string]: unknown;
};

export function basemapLayerId(layerName: string, url: string): string {
  return `${layerName}::${resolveBasemapUrl(url)}`;
}

export function addTileLayerCommand(
  url: string,
  layerName: string,
  alias = layerName
): GisCommand {
  return {
    type: 'ADD_TILE_LAYER',
    data: {
      url,
      layerName,
      alias,
      options: { maxZoom: 18, minZoom: 0, tileSize: 256 },
    },
  };
}

export function removeLayerCommand(layerId: string): GisCommand {
  return { type: 'REMOVE_LAYER', layerId };
}

export function setMapViewCommand(
  center: GisCoordinate,
  zoom: number
): GisCommand {
  return {
    type: 'SET_MAP_VIEW',
    data: { mapState: { center: { lat: center.lat, lon: center.lon }, zoom } },
  };
}

export type GisBounds = {
  north: number;
  south: number;
  east: number;
  west: number;
};

/**
 * Flex GIS fits these bounds in the current frame and picks the highest
 * zoom that still contains them (`leafletMap.flyToBounds`).
 */
export function setMapViewBoundsCommand(bounds: GisBounds): GisCommand {
  return { type: 'SET_MAP_VIEW_BOUNDS', data: bounds };
}

/**
 * Drag moves the map. Flex GIS replaces its pan controller with bulk-select
 * when the selection list starts empty, and that mode draws a box on drag.
 */
export function activatePanControllerCommand(): GisCommand {
  return {
    type: 'ACTIVATE_MAP_CONTROLLER',
    data: { controllerType: 'PAN' },
  };
}

export function createSymbolLayerCommand(
  layerId: string,
  layerName = layerId
): GisCommand {
  return {
    type: 'CREATE_MILITARY_SYMBOL_LAYER',
    layerId,
    layerName,
    parentId: GIS_DYNAMIC_LAYER_PARENT_ID,
    editable: false,
    selectable: false,
    geodetic: true,
  };
}

export function clearLayerCommand(layerId: string): GisCommand {
  return {
    type: 'REMOVE_ALL_MAP_ELEMENTS_FROM_LAYER',
    data: { layer: layerId },
  };
}

export function createElementsCommand(
  layerId: string,
  elements: GisMapElementInfo[]
): GisCommand {
  return {
    type: 'CREATE_MILITARY_MAP_ELEMENTS',
    elements: elements.map((elementInfo) => ({ layerId, elementInfo })),
  };
}

export function setLayerVisibleCommand(
  layerId: string,
  visible: boolean
): GisCommand {
  return {
    type: 'UPDATE_LAYER_VISIBILITY',
    data: { layerId, visibility: visible },
  };
}

function resolveBasemapUrl(url: string): string {
  if (!url.includes('/proxy?url=')) return url;
  try {
    const proxied = new URL(url).searchParams.get('url');
    return proxied ? decodeURIComponent(proxied) : url;
  } catch {
    return url;
  }
}
