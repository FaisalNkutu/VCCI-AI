import {
  AfterViewInit,
  Component,
  inject,
  viewChild,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FlexGisMapComponent } from '@simfront/gis-web-angular';
import { Store } from '@ngrx/store';
import { selectResolvedMapConfig } from '@/store/features/sidebar.feature';
import {
  FLEX_GIS_BASE_PATH,
  GisBounds,
  GisCoordinate,
  GisMapElementInfo,
} from './gis-map.commands';
import { GisMapSession } from './gis-map.session';

@Component({
  selector: 'gis-map-host',
  standalone: true,
  imports: [FlexGisMapComponent],
  templateUrl: './gis-map-host.component.html',
  styleUrl: './gis-map-host.component.css',
})
export class GisMapHostComponent implements AfterViewInit {
  readonly basePath = FLEX_GIS_BASE_PATH;

  private readonly store = inject(Store);
  private readonly map = viewChild.required(FlexGisMapComponent);
  private readonly session = new GisMapSession();

  constructor() {
    this.store
      .select(selectResolvedMapConfig)
      .pipe(takeUntilDestroyed())
      .subscribe((config) => {
        if (!config?.url) return;
        const layerName = config.wmtsOptions?.layer || 'basemap';
        this.setBasemap(config.url, layerName);
      });
  }

  ngAfterViewInit(): void {
    this.session.attach((command) => this.map().send(command));
  }

  /**
   * flex-map emits this after the iframe posts LOAD_COMPLETE.
   * That listener is inside the GIS component and is not filtered by frame,
   * so only one host should be mounted at a time.
   */
  onMapReady(): void {
    this.session.markReady();
  }

  setBasemap(url: string, layerName: string, alias = layerName): void {
    this.session.setBasemap(url, layerName, alias);
  }

  setView(center: GisCoordinate, zoom: number): void {
    this.session.setView(center, zoom);
  }

  setViewBounds(bounds: GisBounds): void {
    this.session.setViewBounds(bounds);
  }

  ensureLayer(layerId: string, layerName = layerId): void {
    this.session.ensureLayer(layerId, layerName);
  }

  replaceElements(
    layerId: string,
    elements: GisMapElementInfo[],
    layerName = layerId
  ): void {
    this.session.replaceElements(layerId, elements, layerName);
  }

  setLayerVisible(layerId: string, visible: boolean): void {
    this.session.setLayerVisible(layerId, visible);
  }
}
