import { C2Context, FratIncident } from '@/models';
import { gisShapeType } from './gis-map.commands';
import {
  contextToElements,
  fratricideToElements,
  fratricideView,
  expandBounds,
  lodBounds,
  lodToElements,
  unitsToElements,
} from './gis-map.elements';

describe('gis map elements', () => {
  it('draws a 2525 point when the unit has a symbol code', () => {
    expect(
      unitsToElements(
        [{ id: 4, name: 'A Co', lat: 35, lon: -80, milSym: 'SFGPUCI----' }],
        'hh-unit'
      )
    ).toEqual([
      {
        id: 'hh-unit-4',
        shapeType: gisShapeType.point,
        sidc: 'SFGPUCI----',
        standard: '2525',
        coordinate: { lat: 35, lon: -80 },
        label: 'A Co',
      },
    ]);
  });

  it('draws a circle when the unit has no symbol code', () => {
    expect(
      unitsToElements([{ name: 'Unknown', lat: 1, lon: 2 }], 'c2', 50)
    ).toEqual([
      {
        id: 'c2-0',
        shapeType: gisShapeType.circle,
        centerLocation: { lat: 1, lon: 2 },
        radius: 50,
        label: 'Unknown',
        filled: true,
      },
    ]);
  });

  it('colors metrics units green and vcci units blue', () => {
    const metrics = contextToElements(
      c2Context('MET_DATA_TYPE', [
        { id: 4, name: 'A Co', lat: 35, lon: -80, milSym: 'SFGPUCI----' },
      ])
    );
    const vcci = contextToElements(
      c2Context('VCCI_DATA_TYPE', [{ name: 'Unknown', lat: 1, lon: 2 }])
    );

    expect(metrics).toEqual([
      {
        id: 'c2-1:MET_DATA_TYPE-4',
        shapeType: gisShapeType.point,
        sidc: 'SFGPUCI----',
        standard: '2525',
        coordinate: { lat: 35, lon: -80 },
        label: 'A Co',
        color: 0x22c55e,
      },
    ]);
    expect(vcci).toEqual([
      {
        id: 'c2-1:VCCI_DATA_TYPE-0',
        shapeType: gisShapeType.circle,
        centerLocation: { lat: 1, lon: 2 },
        radius: 50,
        label: 'Unknown',
        filled: true,
        color: 0x3b82f6,
      },
    ]);
  });

  it('builds the line of departure from two or more points', () => {
    expect(
      lodToElements([
        { lat: 1, lon: 2 },
        { lat: 3, lon: 4 },
      ])
    ).toEqual([
      {
        id: 'hh-lod-line',
        shapeType: gisShapeType.polyline,
        coordinates: [
          { lat: 1, lon: 2 },
          { lat: 3, lon: 4 },
        ],
        label: 'Line of Departure',
      },
    ]);
    expect(lodToElements([{ lat: 1, lon: 2 }])).toEqual([]);
  });

  it('bounds the line of departure so the map can fit the whole line', () => {
    expect(
      lodBounds([
        { lat: 35.2, lon: -80.9 },
        { lat: 35.5, lon: -80.2 },
        { lat: 35.1, lon: -80.4 },
      ])
    ).toEqual({
      north: 35.5,
      south: 35.1,
      east: -80.2,
      west: -80.9,
    });
    expect(lodBounds([{ lat: 1, lon: 2 }])).toBeNull();
    expect(lodBounds([{ lat: Number.NaN, lon: 2 }, { lat: 1, lon: 3 }])).toBeNull();
  });

  it('pads the line bounds so the fitted view sits farther out', () => {
    expect(
      expandBounds({ north: 10, south: 8, east: 4, west: 0 }, 0.5)
    ).toEqual({
      north: 11,
      south: 7,
      east: 6,
      west: -2,
    });
    expect(
      expandBounds({ north: 89, south: 88, east: 1, west: 0 }, 2).north
    ).toBe(90);
  });

  it('builds a fratricide footprint, firing line, and symbols', () => {
    const incident = fratIncident();
    const elements = fratricideToElements([incident]);
    expect(elements.map((element) => element.id)).toEqual([
      'frat-footprint-9',
      'frat-rx-9',
      'frat-impact-9',
      'frat-firing-line',
      'frat-firing-9',
      'frat-max-line',
      'frat-target-9',
      'frat-hit-9',
    ]);
    const byId = Object.fromEntries(
      elements.map((element) => [element.id, element])
    );
    expect(byId['frat-footprint-9'].color).toBe(0x0000ff);
    expect(byId['frat-max-line'].color).toBe('rgba(0, 0, 255, 0.3)');
    expect(byId['frat-impact-9'].color).toBe(0xaf0000);
    expect(byId['frat-impact-9'].radius).toBe(20);
    expect(byId['frat-hit-9']).toEqual({
      id: 'frat-hit-9',
      shapeType: gisShapeType.point,
      coordinate: { lat: 35.3, lon: -80.3 },
      icon: 'icons/DF_marker.png',
    });
    expect(byId['frat-target-9'].label).toBe('Target');
    expect(byId['frat-target-9'].uniqueDesignation).toBeUndefined();
    expect(fratricideView([incident])).toEqual({ lat: 35.3, lon: -80.3 });
  });

  it('uses the IDF hit marker when the firing type is not DF', () => {
    const elements = fratricideToElements([
      { ...fratIncident(), firingType: 'IDF' },
    ]);
    expect(elements.find((element) => element.id === 'frat-hit-9')?.icon).toBe(
      'icons/IDF_marker.png'
    );
    expect(
      elements.find((element) => element.id === 'frat-impact-9')
    ).toBeUndefined();
  });
});

function c2Context(
  type: 'MET_DATA_TYPE' | 'VCCI_DATA_TYPE',
  units: C2Context['units']
): C2Context {
  return {
    id: 1,
    name: 'Context',
    type,
    uniqueID: `1:${type}`,
    selected: true,
    units,
  };
}

function fratIncident(): FratIncident {
  return {
    name: 'Gun 1',
    id: 9,
    lat: 35.1,
    lon: -80.1,
    milSym: 'SFGPUCI----',
    time: 0,
    formattedtime: '00:00',
    fireEventId: 1,
    firingType: 'DF',
    targetEntityName: 'Target',
    targetEntityMilSym: 'SHGPUCI----',
    targetLat: 35.3,
    targetLon: -80.3,
    munitionMaxLat: 35.4,
    munitionMaxLon: -80.4,
    intersectLat: 35.2,
    intersectLon: -80.2,
    receivingEntityName: 'Receiver',
    receivingEntityMilSym: 'SFGPUCIZ---',
    footprintPoint1Lat: 35.2,
    footprintPoint1Lon: -80.2,
    footprintPoint2Lat: 35.21,
    footprintPoint2Lon: -80.2,
    footprintPoint3Lat: 35.21,
    footprintPoint3Lon: -80.21,
    footprintPoint4Lat: 35.2,
    footprintPoint4Lon: -80.21,
  };
}
