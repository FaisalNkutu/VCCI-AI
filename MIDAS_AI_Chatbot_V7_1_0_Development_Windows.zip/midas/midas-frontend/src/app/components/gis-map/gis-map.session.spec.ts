import { DEFAULT_MAP_URL } from '@/store/features/sidebar.feature';
import {
  basemapLayerId,
  DEFAULT_MAP_CENTER,
  DEFAULT_MAP_ZOOM,
  gisShapeType,
  GisCommand,
} from './gis-map.commands';
import { GisMapSession } from './gis-map.session';

describe('GisMapSession', () => {
  let sent: GisCommand[];
  let session: GisMapSession;

  beforeEach(() => {
    sent = [];
    session = new GisMapSession();
  });

  function attach(): void {
    session.attach((command) => sent.push(command));
  }

  it('holds basemap and overlay commands until the iframe is ready', () => {
    attach();
    session.setBasemap(DEFAULT_MAP_URL, 'basemap');
    session.replaceElements('hh-units', [
      {
        id: 'unit-1',
        shapeType: gisShapeType.point,
        coordinate: { lat: 35.2, lon: -80.8 },
        uniqueDesignation: 'A CO',
      },
    ]);

    expect(sent).toEqual([]);

    session.markReady();

    expect(sent.map((command) => command.type)).toEqual([
      'ADD_TILE_LAYER',
      'CREATE_MILITARY_SYMBOL_LAYER',
      'REMOVE_ALL_MAP_ELEMENTS_FROM_LAYER',
      'CREATE_MILITARY_MAP_ELEMENTS',
      'SET_MAP_VIEW',
      'ACTIVATE_MAP_CONTROLLER',
    ]);
    expect(sent[0]).toEqual(
      jasmine.objectContaining({
        data: jasmine.objectContaining({
          url: DEFAULT_MAP_URL,
          layerName: 'basemap',
        }),
      })
    );
    expect(sent[4]).toEqual({
      type: 'SET_MAP_VIEW',
      data: {
        mapState: { center: DEFAULT_MAP_CENTER, zoom: DEFAULT_MAP_ZOOM },
      },
    });
    expect(sent[5]).toEqual({
      type: 'ACTIVATE_MAP_CONTROLLER',
      data: { controllerType: 'PAN' },
    });
  });

  it('uses the WMTS layer name in the basemap id Flex GIS will assign', () => {
    const url = 'https://maps.example/wmts';
    attach();
    session.setBasemap(url, 'WorldImagery');
    session.markReady();

    expect(sent[0]).toEqual(
      jasmine.objectContaining({
        data: jasmine.objectContaining({
          url,
          layerName: 'WorldImagery',
          alias: 'WorldImagery',
        }),
      })
    );
    expect(basemapLayerId('WorldImagery', url)).toBe(`WorldImagery::${url}`);
  });

  it('removes the previous basemap when the resolved config changes', () => {
    attach();
    session.markReady();
    sent = [];

    session.setBasemap(DEFAULT_MAP_URL, 'basemap');
    session.setBasemap('https://maps.example/wmts', 'WorldImagery');

    expect(sent.map((command) => command.type)).toEqual([
      'ADD_TILE_LAYER',
      'REMOVE_LAYER',
      'ADD_TILE_LAYER',
    ]);
    expect(sent[1]).toEqual({
      type: 'REMOVE_LAYER',
      layerId: basemapLayerId('basemap', DEFAULT_MAP_URL),
    });
  });

  it('does not add the same basemap twice', () => {
    attach();
    session.markReady();
    sent = [];

    session.setBasemap(DEFAULT_MAP_URL, 'basemap');
    session.setBasemap(DEFAULT_MAP_URL, 'basemap');

    expect(sent.length).toBe(1);
  });

  it('fits a bounds and skips the default camera', () => {
    attach();
    session.setViewBounds({ north: 36, south: 35, east: -80, west: -81 });
    session.markReady();

    const views = sent.filter(
      (command) =>
        command.type === 'SET_MAP_VIEW' || command.type === 'SET_MAP_VIEW_BOUNDS'
    );
    expect(views).toEqual([
      {
        type: 'SET_MAP_VIEW_BOUNDS',
        data: { north: 36, south: 35, east: -80, west: -81 },
      },
    ]);
  });

  it('keeps a caller view and skips the default camera', () => {
    attach();
    session.setView({ lat: 10, lon: 20 }, 13);
    session.markReady();

    const views = sent.filter((command) => command.type === 'SET_MAP_VIEW');
    expect(views).toEqual([
      {
        type: 'SET_MAP_VIEW',
        data: { mapState: { center: { lat: 10, lon: 20 }, zoom: 13 } },
      },
    ]);
  });

  it('clears a layer without creating elements when the overlay is empty', () => {
    attach();
    session.markReady();
    sent = [];

    session.replaceElements('c2-metrics', []);
    session.setLayerVisible('c2-metrics', false);

    expect(sent.map((command) => command.type)).toEqual([
      'CREATE_MILITARY_SYMBOL_LAYER',
      'REMOVE_ALL_MAP_ELEMENTS_FROM_LAYER',
      'UPDATE_LAYER_VISIBILITY',
    ]);
    expect(sent[2]).toEqual({
      type: 'UPDATE_LAYER_VISIBILITY',
      data: { layerId: 'c2-metrics', visibility: false },
    });
  });

  it('creates a symbol layer once', () => {
    attach();
    session.markReady();
    sent = [];

    session.ensureLayer('frat-incidents', 'Fratricide');
    session.ensureLayer('frat-incidents', 'Fratricide');

    expect(sent).toEqual([
      {
        type: 'CREATE_MILITARY_SYMBOL_LAYER',
        layerId: 'frat-incidents',
        layerName: 'Fratricide',
        parentId: '-999',
        editable: false,
        selectable: false,
        geodetic: true,
      },
    ]);
  });

  it('flushes commands that were queued before the frame send function was attached', () => {
    session.setBasemap(DEFAULT_MAP_URL, 'basemap');
    session.markReady();
    expect(sent).toEqual([]);

    attach();

    expect(sent.map((command) => command.type)).toEqual([
      'ADD_TILE_LAYER',
      'SET_MAP_VIEW',
      'ACTIVATE_MAP_CONTROLLER',
    ]);
  });
});
