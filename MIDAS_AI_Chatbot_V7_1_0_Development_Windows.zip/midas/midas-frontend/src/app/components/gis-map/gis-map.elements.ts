import { C2Context, FratIncident, LodLocation, Unit } from '@/models';
import {
  GisBounds,
  GisCoordinate,
  GisMapElementInfo,
  gisShapeType,
} from './gis-map.commands';

export const FRATRICIDE_VIEW_ZOOM = 13;

/** Metrics units. Packed RGB, read as a point tint or a shape stroke. */
export const METRICS_UNIT_COLOR = 0x22c55e;
/** VCCI units. */
export const VCCI_UNIT_COLOR = 0x3b82f6;
/** Footprint stroke. Pixi does not fill the polygon. */
export const FRAT_FOOTPRINT_COLOR = 0x0000ff;
/** Munition-max stroke. Pixi applies the alpha while stroking. */
export const FRAT_MAX_LINE_COLOR = 'rgba(0, 0, 255, 0.3)';
/** DF impact stroke. The circle is drawn as a ring, not a filled disk. */
export const FRAT_IMPACT_COLOR = 0xaf0000;
/** Paths under `/assets`. The bundle prefixes that directory itself. */
export const FRAT_DF_MARKER_ICON = 'icons/DF_marker.png';
export const FRAT_IDF_MARKER_ICON = 'icons/IDF_marker.png';

export type MapUnit = {
  id?: number | string;
  name?: string;
  lat: number;
  lon: number;
  milSym?: string;
};

export function unitsToElements(
  units: MapUnit[],
  idPrefix: string,
  fallbackRadius = 20,
  color?: number
): GisMapElementInfo[] {
  return units.flatMap((unit, index): GisMapElementInfo[] => {
    if (!Number.isFinite(unit.lat) || !Number.isFinite(unit.lon)) return [];
    const id = `${idPrefix}-${unit.id ?? index}`;
    const location = { lat: unit.lat, lon: unit.lon };
    if (unit.milSym) {
      return [
        {
          id,
          shapeType: gisShapeType.point,
          sidc: unit.milSym,
          standard: '2525',
          coordinate: location,
          label: unit.name,
          ...(color === undefined ? {} : { color }),
        },
      ];
    }
    return [
      {
        id,
        shapeType: gisShapeType.circle,
        centerLocation: location,
        radius: fallbackRadius,
        label: unit.name,
        filled: true,
        ...(color === undefined ? {} : { color }),
      },
    ];
  });
}

export function lodToElements(locations: LodLocation[]): GisMapElementInfo[] {
  const coordinates = finiteCoordinates(locations);
  if (coordinates.length < 2) return [];
  return [
    {
      id: 'hh-lod-line',
      shapeType: gisShapeType.polyline,
      coordinates,
      label: 'Line of Departure',
    },
  ];
}

export const LOD_VIEW_MARGIN = 0.5;

/** Bounds of a drawable line. */
export function lodBounds(locations: LodLocation[]): GisBounds | null {
  const coordinates = finiteCoordinates(locations);
  if (coordinates.length < 2) return null;
  return coordinates.reduce<GisBounds>(
    (bounds, coordinate) => ({
      north: Math.max(bounds.north, coordinate.lat),
      south: Math.min(bounds.south, coordinate.lat),
      east: Math.max(bounds.east, coordinate.lon),
      west: Math.min(bounds.west, coordinate.lon),
    }),
    {
      north: -Infinity,
      south: Infinity,
      east: -Infinity,
      west: Infinity,
    }
  );
}

/** Grows bounds so a fit view sits farther back from the line. */
export function expandBounds(bounds: GisBounds, margin: number): GisBounds {
  const latPad = (bounds.north - bounds.south) * margin;
  const lonPad = (bounds.east - bounds.west) * margin;
  return {
    north: Math.min(90, bounds.north + latPad),
    south: Math.max(-90, bounds.south - latPad),
    east: bounds.east + lonPad,
    west: bounds.west - lonPad,
  };
}

export function contextToElements(context: C2Context): GisMapElementInfo[] {
  const color =
    context.type === 'MET_DATA_TYPE' ? METRICS_UNIT_COLOR : VCCI_UNIT_COLOR;
  return unitsToElements(
    asMapUnits(context.units),
    `c2-${context.uniqueID}`,
    50,
    color
  );
}

export function fratricideToElements(
  incidents: FratIncident[]
): GisMapElementInfo[] {
  const elements: GisMapElementInfo[] = [];
  for (const incident of incidents) {
    const footprint = footprintCoordinates(incident);
    if (footprint.length === 4) {
      elements.push({
        id: `frat-footprint-${incident.id}`,
        shapeType: gisShapeType.polygon,
        coordinates: footprint,
        filled: true,
        label: incident.receivingEntityName,
        color: FRAT_FOOTPRINT_COLOR,
      });
      elements.push(
        symbolElement(
          `frat-rx-${incident.id}`,
          centroid(footprint),
          incident.receivingEntityMilSym,
          incident.receivingEntityName
        )
      );
    }
    if (
      incident.firingType === 'DF' &&
      Number.isFinite(incident.intersectLat) &&
      Number.isFinite(incident.intersectLon)
    ) {
      elements.push({
        id: `frat-impact-${incident.id}`,
        shapeType: gisShapeType.circle,
        centerLocation: {
          lat: incident.intersectLat,
          lon: incident.intersectLon,
        },
        radius: 20,
        filled: true,
        color: FRAT_IMPACT_COLOR,
      });
    }
  }

  const first = incidents[0];
  if (!first) return elements;

  if (
    Number.isFinite(first.lat) &&
    Number.isFinite(first.lon) &&
    Number.isFinite(first.targetLat) &&
    Number.isFinite(first.targetLon)
  ) {
    elements.push({
      id: 'frat-firing-line',
      shapeType: gisShapeType.polyline,
      coordinates: [
        { lat: first.lat, lon: first.lon },
        { lat: first.targetLat, lon: first.targetLon },
      ],
    });
    elements.push(
      symbolElement(`frat-firing-${first.id}`, { lat: first.lat, lon: first.lon }, first.milSym, first.name)
    );
  }

  if (
    Number.isFinite(first.targetLat) &&
    Number.isFinite(first.targetLon) &&
    Number.isFinite(first.munitionMaxLat) &&
    Number.isFinite(first.munitionMaxLon)
  ) {
    elements.push({
      id: 'frat-max-line',
      shapeType: gisShapeType.polyline,
      coordinates: [
        { lat: first.targetLat, lon: first.targetLon },
        { lat: first.munitionMaxLat, lon: first.munitionMaxLon },
      ],
      color: FRAT_MAX_LINE_COLOR,
    });
  }

  if (
    first.targetEntityName != null &&
    first.targetEntityMilSym != null &&
    Number.isFinite(first.targetLat) &&
    Number.isFinite(first.targetLon)
  ) {
    elements.push(
      symbolElement(
        `frat-target-${first.id}`,
        { lat: first.targetLat, lon: first.targetLon },
        first.targetEntityMilSym,
        first.targetEntityName
      )
    );
  }

  if (Number.isFinite(first.targetLat) && Number.isFinite(first.targetLon)) {
    elements.push({
      id: `frat-hit-${first.id}`,
      shapeType: gisShapeType.point,
      coordinate: { lat: first.targetLat, lon: first.targetLon },
      icon:
        first.firingType === 'DF' ? FRAT_DF_MARKER_ICON : FRAT_IDF_MARKER_ICON,
    });
  }

  return elements;
}

export function fratricideView(incidents: FratIncident[]): GisCoordinate | null {
  const first = incidents[0];
  if (!first || !Number.isFinite(first.targetLat) || !Number.isFinite(first.targetLon)) {
    return null;
  }
  return { lat: first.targetLat, lon: first.targetLon };
}

export function asMapUnits(units: Unit[] | unknown): MapUnit[] {
  if (!Array.isArray(units)) return [];
  return units.flatMap((unit) => {
    if (!unit || typeof unit !== 'object') return [];
    const record = unit as Record<string, unknown>;
    const lat = Number(record['lat']);
    const lon = Number(record['lon']);
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) return [];
    const id = record['id'];
    return [
      {
        id: typeof id === 'number' || typeof id === 'string' ? id : undefined,
        name: typeof record['name'] === 'string' ? record['name'] : undefined,
        lat,
        lon,
        milSym: typeof record['milSym'] === 'string' ? record['milSym'] : undefined,
      },
    ];
  });
}

function symbolElement(
  id: string,
  coordinate: GisCoordinate,
  sidc: string,
  label: string
): GisMapElementInfo {
  return {
    id,
    shapeType: gisShapeType.point,
    sidc,
    standard: '2525',
    coordinate,
    label,
  };
}

function footprintCoordinates(incident: FratIncident): GisCoordinate[] {
  return finiteCoordinates([
    { lat: incident.footprintPoint1Lat, lon: incident.footprintPoint1Lon },
    { lat: incident.footprintPoint2Lat, lon: incident.footprintPoint2Lon },
    { lat: incident.footprintPoint3Lat, lon: incident.footprintPoint3Lon },
    { lat: incident.footprintPoint4Lat, lon: incident.footprintPoint4Lon },
  ]);
}

function finiteCoordinates(
  locations: { lat: number; lon: number }[]
): GisCoordinate[] {
  return locations.filter(
    (location) => Number.isFinite(location.lat) && Number.isFinite(location.lon)
  );
}

function centroid(coordinates: GisCoordinate[]): GisCoordinate {
  const totals = coordinates.reduce(
    (sum, coordinate) => ({
      lat: sum.lat + coordinate.lat,
      lon: sum.lon + coordinate.lon,
    }),
    { lat: 0, lon: 0 }
  );
  return {
    lat: totals.lat / coordinates.length,
    lon: totals.lon / coordinates.length,
  };
}
