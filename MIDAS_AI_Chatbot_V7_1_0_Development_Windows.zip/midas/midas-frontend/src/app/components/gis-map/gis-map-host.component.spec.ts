import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Store } from '@ngrx/store';
import { of } from 'rxjs';
import { GisMapHostComponent } from './gis-map-host.component';

describe('GisMapHostComponent', () => {
  let fixture: ComponentFixture<GisMapHostComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GisMapHostComponent],
      providers: [
        {
          provide: Store,
          useValue: {
            select: () =>
              of({
                url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                wmtsOptions: undefined,
              }),
          },
        },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(GisMapHostComponent);
    fixture.detectChanges();
  });

  it('loads the Flex GIS frame from the served asset path', () => {
    const frame: HTMLIFrameElement | null =
      fixture.nativeElement.querySelector('iframe');
    expect(frame).not.toBeNull();
    expect(frame?.getAttribute('src')).toContain(
      '/assets/flexgis/index.html?host=iframe'
    );
  });
});
