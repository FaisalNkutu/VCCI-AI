import {
  activatePanControllerCommand,
  addTileLayerCommand,
  basemapLayerId,
  clearLayerCommand,
  createElementsCommand,
  createSymbolLayerCommand,
  DEFAULT_MAP_CENTER,
  DEFAULT_MAP_ZOOM,
  GisBounds,
  GisCommand,
  GisCoordinate,
  GisMapElementInfo,
  removeLayerCommand,
  setLayerVisibleCommand,
  setMapViewBoundsCommand,
  setMapViewCommand,
} from './gis-map.commands';

/**
 * Queues Flex GIS postMessage commands until the iframe reports LOAD_COMPLETE,
 * then sends them in order through one frame.
 */
export class GisMapSession {
  private readonly pending: GisCommand[] = [];
  private readonly layers = new Set<string>();
  private sendCommand: ((command: GisCommand) => void) | null = null;
  private isReady = false;
  private viewWasSet = false;
  private panWasSet = false;
  private basemapLayerId: string | undefined;

  attach(sendCommand: (command: GisCommand) => void): void {
    this.sendCommand = sendCommand;
    if (this.isReady) this.flush();
  }

  markReady(): void {
    if (!this.viewWasSet) {
      this.viewWasSet = true;
      this.pending.push(setMapViewCommand(DEFAULT_MAP_CENTER, DEFAULT_MAP_ZOOM));
    }
    if (!this.panWasSet) {
      this.panWasSet = true;
      this.pending.push(activatePanControllerCommand());
    }
    this.isReady = true;
    this.flush();
  }

  setBasemap(url: string, layerName: string, alias = layerName): void {
    const layerId = basemapLayerId(layerName, url);
    if (this.basemapLayerId === layerId) return;
    if (this.basemapLayerId) this.enqueue(removeLayerCommand(this.basemapLayerId));
    this.basemapLayerId = layerId;
    this.enqueue(addTileLayerCommand(url, layerName, alias));
  }

  setView(center: GisCoordinate, zoom: number): void {
    this.viewWasSet = true;
    this.enqueue(setMapViewCommand(center, zoom));
  }

  setViewBounds(bounds: GisBounds): void {
    this.viewWasSet = true;
    this.enqueue(setMapViewBoundsCommand(bounds));
  }

  ensureLayer(layerId: string, layerName = layerId): void {
    if (this.layers.has(layerId)) return;
    this.layers.add(layerId);
    this.enqueue(createSymbolLayerCommand(layerId, layerName));
  }

  replaceElements(
    layerId: string,
    elements: GisMapElementInfo[],
    layerName = layerId
  ): void {
    this.ensureLayer(layerId, layerName);
    this.enqueue(clearLayerCommand(layerId));
    if (elements.length > 0) this.enqueue(createElementsCommand(layerId, elements));
  }

  setLayerVisible(layerId: string, visible: boolean): void {
    this.enqueue(setLayerVisibleCommand(layerId, visible));
  }

  private enqueue(command: GisCommand): void {
    if (this.isReady && this.sendCommand) {
      this.sendCommand(command);
      return;
    }
    this.pending.push(command);
  }

  private flush(): void {
    if (!this.sendCommand) return;
    const commands = this.pending.splice(0);
    for (const command of commands) this.sendCommand(command);
  }
}
