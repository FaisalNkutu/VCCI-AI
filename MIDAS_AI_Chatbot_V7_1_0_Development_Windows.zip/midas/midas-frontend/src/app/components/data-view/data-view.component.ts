import {
  Component,
  Input,
  TemplateRef,
  ChangeDetectionStrategy,
  OnInit,
  computed,
  input,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';

export type ViewMode = 'list' | 'grid';

@Component({
  selector: 'data-view',
  imports: [
    CommonModule,
    ScrollingModule,
    MatButtonToggleModule,
    MatIconModule,
    MatMenuModule,
    MatButtonModule,
    MatTooltipModule
],
  templateUrl: './data-view.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DataViewComponent<T> implements OnInit {
  data = input<T[]>([]);
  @Input() headerTitle: string = '';
  @Input() viewMode: ViewMode = 'list';
  @Input() listItemHeight: number = 60;
  @Input() gridItemHeight: number = 200;
  @Input() gridColumns: number = 3;
  @Input() trackByFn: (index: number, item: T) => any = (index) => index;

  @Input() listViewTemplate: TemplateRef<any> | null = null;
  @Input() gridViewTemplate: TemplateRef<any> | null = null;

  gridData = computed(() => {
    const data = this.data();
    const columns = this.gridColumns;
    const rows = Math.ceil(data.length / columns);
    const result: T[][] = Array.from({ length: rows }, (_, rowIndex) =>
      data.slice(rowIndex * columns, (rowIndex + 1) * columns)
    );
    return result;
  });

  ngOnInit() {
    if (!this.gridViewTemplate && this.listViewTemplate) {
      this.gridViewTemplate = this.listViewTemplate;
    }
  }

  onViewModeChange(newMode: ViewMode) {
    this.viewMode = newMode;
  }

  getBlankContainers(itemsInRow: number): any[] {
  const remainingSlots = this.gridColumns - itemsInRow;
  return remainingSlots > 0 ? new Array(remainingSlots).fill(null) : [];
}

  clearAllFilters() {}
}
