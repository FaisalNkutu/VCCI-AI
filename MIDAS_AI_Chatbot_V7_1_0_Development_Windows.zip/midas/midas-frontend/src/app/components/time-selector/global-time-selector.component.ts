import { Timeframe } from '@/models';
import { selectMinMaxTime } from '@/store/features/sidebar.feature';
import { AsyncPipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Store } from '@ngrx/store';
import { filter, take } from 'rxjs/operators';
import {
  INPUT_UNITS_PER_SECOND,
  TimeSelectorComponent,
} from './time-selector.component';

@Component({
  selector: 'global-time-selector',
  imports: [TimeSelectorComponent, AsyncPipe],
  template: `
    <time-selector
      [min]="(range$ | async)?.minTime || 0"
      [max]="(range$ | async)?.maxTime || 0"
      [timeframe]="timeframe"
      [sliderStep]="sliderStep"
      [debounceTimeMs]="debounceTimeMs"
      (onTimeframeChange)="onTimeframeChange.emit($event)"
    />
  `,
})
export class GlobalTimeSelectorComponent implements OnInit {
  range$ = this.store.select(selectMinMaxTime);

  // COMPONENT INPUTS
  @Input() timeframe: Timeframe = { start: 0, end: 0 };
  @Input() sliderStep: number = INPUT_UNITS_PER_SECOND;
  @Input() debounceTimeMs: number = 300;

  // OUTPUTS
  @Output() onTimeframeChange = new EventEmitter<Timeframe>();

  constructor(private store: Store) {}

  ngOnInit(): void {
    this.range$
      .pipe(
        filter((v) => v !== null && v !== undefined),
        take(1),
      )
      .subscribe((v) => {
        this.timeframe = { start: v.minTime, end: v.maxTime };
        this.onTimeframeChange.emit(this.timeframe);
      });
  }
}
