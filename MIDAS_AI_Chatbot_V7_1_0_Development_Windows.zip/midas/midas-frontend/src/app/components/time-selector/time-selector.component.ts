import { Timeframe } from '@/models';
import { CommonModule } from '@angular/common';
import {
  Component,
  computed,
  EventEmitter,
  Input,
  input,
  OnInit,
  Output,
  signal,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatSliderDragEvent, MatSliderModule } from '@angular/material/slider';
import { MatTooltipModule } from '@angular/material/tooltip';
import { debounceTime, Subject, takeUntil } from 'rxjs';

enum TimeSliderMode {
  SLIDER = 'slider',
  NUMERIC = 'numeric',
}
type DurationComponent =
  | 'days'
  | 'hours'
  | 'minutes'
  | 'seconds'
  | 'milliseconds';

interface NumericChange {
  value: number;
  component: DurationComponent;
  isStartTime: boolean;
}

interface NumericTime {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

// milliseconds
export const INPUT_UNITS_PER_SECOND: number = 1_000;

// Conversion factors in terms of the input unit
const INPUT_UNITS_IN_MINUTE: number = 60 * INPUT_UNITS_PER_SECOND;
const INPUT_UNITS_IN_HOUR: number = 60 * INPUT_UNITS_IN_MINUTE;
const INPUT_UNITS_IN_DAY: number = 24 * INPUT_UNITS_IN_HOUR;

@Component({
  selector: 'time-selector',
  imports: [
    MatSliderModule,
    MatButtonToggleModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSelectModule,
    FormsModule,
    CommonModule,
    MatButtonModule,
    MatTooltipModule,
  ],
  templateUrl: './time-selector.component.html',
  styles: [
    `
      ::ng-deep .time-selector .mat-mdc-form-field-subscript-wrapper {
        display: none;
      }
    `,
  ],
})
export class TimeSelectorComponent implements OnInit {
  // REQUIRED INPUTS
  min = input.required<number>();
  max = input.required<number>();
  timeframe = input.required<Timeframe>();

  // COMPONENT INPUTS
  @Input() sliderStep: number = INPUT_UNITS_PER_SECOND;
  @Input() debounceTimeMs: number = 300;

  // OUTPUTS
  @Output() onTimeframeChange = new EventEmitter<Timeframe>();

  // REACTIVE STATE
  mode = signal<TimeSliderMode>(TimeSliderMode.SLIDER);
  dragMode = signal({
    isDraggingStart: false,
    value: 0,
  });
  isDragging = computed(() => this.dragMode().value !== 0);

  numericStartTime = computed<NumericTime>(() => ({
    days: this.getDurationComponent(this.timeframe().start, 'days'),
    hours: this.getDurationComponent(this.timeframe().start, 'hours'),
    minutes: this.getDurationComponent(this.timeframe().start, 'minutes'),
    seconds: this.getDurationComponent(this.timeframe().start, 'seconds'),
  }));

  numericEndTime = computed<NumericTime>(() => ({
    days: this.getDurationComponent(this.timeframe().end, 'days'),
    hours: this.getDurationComponent(this.timeframe().end, 'hours'),
    minutes: this.getDurationComponent(this.timeframe().end, 'minutes'),
    seconds: this.getDurationComponent(this.timeframe().end, 'seconds'),
  }));

  private numericTimeChange$ = new Subject<NumericChange>();
  private destroyed$ = new Subject<void>();

  ngOnInit() {
    this.numericTimeChange$
      .pipe(debounceTime(this.debounceTimeMs), takeUntil(this.destroyed$))
      .subscribe(({ value, component, isStartTime }) => {
        this.calculateTimeframe(value, component, isStartTime);
      });
  }

  ngOnDestroy() {
    this.destroyed$.next();
    this.destroyed$.complete();
  }

  // --- SLIDER MODE HANDLERS ---

  whileDragging(event: Event, isStartTime: boolean) {
    this.dragMode.set({
      isDraggingStart: isStartTime,
      value: (event.target as HTMLInputElement).value as unknown as number,
    });
  }

  onSliderChange(event: MatSliderDragEvent, isStartTime: boolean) {
    const newTimeframe = {
      start: isStartTime ? event.value : this.timeframe().start,
      end: isStartTime ? this.timeframe().end : event.value,
    };
    this.updateTimeframe(newTimeframe);
    this.dragMode.set({ isDraggingStart: false, value: 0 });
  }

  // --- NUMERIC MODE HANDLERS ---

  onSimTimeChange(
    event: Event,
    component: DurationComponent,
    isStartTime: boolean
  ) {
    const inputEl = event.target as HTMLInputElement | null;
    const value = Number(inputEl?.value) || 0;

    // Push the event to the subject for debouncing
    this.numericTimeChange$.next({ value, component, isStartTime });
  }

  // Core logic to calculate, clamp, and update the timeframe (runs after debounce)
  private calculateTimeframe(
    newValue: number,
    component: DurationComponent,
    isStartTime: boolean
  ): void {
    const currentMs = isStartTime
      ? this.timeframe().start
      : this.timeframe().end;

    let totalDays = this.getDurationComponent(currentMs, 'days');
    let totalHours = this.getDurationComponent(currentMs, 'hours');
    let totalMinutes = this.getDurationComponent(currentMs, 'minutes');
    let totalSeconds = this.getDurationComponent(currentMs, 'seconds');

    switch (component) {
      case 'days':
        totalDays = newValue;
        break;
      case 'hours':
        totalHours = newValue;
        break;
      case 'minutes':
        totalMinutes = newValue;
        break;
      case 'seconds':
        totalSeconds = newValue;
        break;
    }
    let newTotalMs =
      totalDays * INPUT_UNITS_IN_DAY +
      totalHours * INPUT_UNITS_IN_HOUR +
      totalMinutes * INPUT_UNITS_IN_MINUTE +
      totalSeconds * INPUT_UNITS_PER_SECOND;

    newTotalMs = Math.min(Math.max(newTotalMs, this.min()), this.max());
    let newStart: number;
    let newEnd: number;

    if (isStartTime) {
      newStart = newTotalMs;
      newEnd = this.timeframe().end;
      if (newStart > newEnd) {
        newEnd = Math.min(newStart, this.max());
      }
    } else {
      newStart = this.timeframe().start;
      newEnd = newTotalMs;
      if (newEnd < newStart) {
        newStart = Math.max(newEnd, this.min());
      }
    }

    this.updateTimeframe({ start: newStart, end: newEnd });
  }

  // --- UTILITY FUNCTIONS ---

  getDurationComponent(value: number, component: DurationComponent): number {
    switch (component) {
      case 'days':
        return Math.floor(value / INPUT_UNITS_IN_DAY);
      case 'hours':
        return Math.floor((value % INPUT_UNITS_IN_DAY) / INPUT_UNITS_IN_HOUR);
      case 'minutes':
        return Math.floor(
          (value % INPUT_UNITS_IN_HOUR) / INPUT_UNITS_IN_MINUTE
        );
      case 'seconds':
        return Math.floor(
          (value % INPUT_UNITS_IN_MINUTE) / INPUT_UNITS_PER_SECOND
        );
      case 'milliseconds':
        return Math.floor(value % INPUT_UNITS_PER_SECOND);
      default:
        return 0;
    }
  }

  displayValue(value: number): string {
    const days = Math.floor(value / INPUT_UNITS_IN_DAY);
    let remainingValue = value % INPUT_UNITS_IN_DAY;
    const hours = Math.floor(remainingValue / INPUT_UNITS_IN_HOUR);
    remainingValue = remainingValue % INPUT_UNITS_IN_HOUR;
    const minutes = Math.floor(remainingValue / INPUT_UNITS_IN_MINUTE);
    remainingValue = remainingValue % INPUT_UNITS_IN_MINUTE;
    const seconds = Math.floor(remainingValue / INPUT_UNITS_PER_SECOND);
    remainingValue = remainingValue % INPUT_UNITS_PER_SECOND;

    const smallestUnit = Math.floor(remainingValue);
    let result = `${days}d ${hours.toString().padStart(2, '0')}h ${minutes
      .toString()
      .padStart(2, '0')}m ${seconds.toString().padStart(2, '0')}s`;
    // Only include the smallest unit if it's non-zero
    if (smallestUnit > 0) {
      result += ` ${smallestUnit}ms`;
    }

    return result;
  }

  private updateTimeframe(newTimeframe: Timeframe) {
    this.onTimeframeChange.emit(newTimeframe);
  }

  syncTimeframe() {
    this.updateTimeframe({
      ...this.timeframe(),
      end: this.max(),
    });
  }
}
