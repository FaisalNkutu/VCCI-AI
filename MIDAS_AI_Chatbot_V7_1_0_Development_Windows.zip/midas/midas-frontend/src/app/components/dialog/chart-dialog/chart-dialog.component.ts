
import { Component, computed, Input, input } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { SymbologyComponent } from '@simfront/common-libs';

export interface ChartDialogColumn<T> {
  header: string;
  cell: (element: T) => string | number;
  symbol?: boolean;
}

@Component({
  selector: 'chart-dialog',
  imports: [
    MatDialogModule,
    MatTableModule,
    MatButtonModule,
    SymbologyComponent
],
  templateUrl: './chart-dialog.component.html',
  styles: [`
    ::ng-deep .cdk-overlay-pane.mat-mdc-dialog-panel {
      max-width: 100% !important;
    }
  `],
})
export class ChartDialogComponent<T> {
  data = input<T[]>([]);
  columns = input<ChartDialogColumn<T>[]>([]);

  @Input() dialogTitle: string = '';
  @Input() subTitle: string = '';
  @Input() subTitleDescription: string = '';
  @Input() time: string = '';

  dataSource = computed(() => new MatTableDataSource<T>(this.data()));
  displayedColumns = computed(() =>
    this.columns().map((col) => col.header.toLowerCase())
  );

   isNumeric(value: string | number): boolean {
    return !isNaN(Number(value));
  }
}
