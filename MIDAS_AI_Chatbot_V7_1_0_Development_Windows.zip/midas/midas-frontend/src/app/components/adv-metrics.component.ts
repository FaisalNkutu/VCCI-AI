import { Component } from '@angular/core';
import { customWidthExpandCollapse } from '@/utils/animate';
import { RouterOutlet } from '@angular/router';
import { Store } from '@ngrx/store';
import { SseService } from '@/services/sse.service';
import { sidebarActions } from '@/store/actions/sidebar.actions';
import { StatusData } from '@/models';
import { API_URL } from '@/app.config';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-adv-metrics',
  standalone: true,
  animations: [customWidthExpandCollapse('translate', '200px', '60px')],
  imports: [RouterOutlet],
  template: `
      <div class="w-full h-full p-2 overflow-y-auto">
        <router-outlet></router-outlet>
      </div>
  `
})
export class AdvMetricsComponent {
  private sseSubscription?: Subscription;

  constructor(private store: Store, private sseService: SseService) {}

  // on init, we need the overall time formats and start and end time of the exercise
  // we also need to subscribe to the status data from the server
  ngOnInit(): void {
    this.store.dispatch(sidebarActions.getTimeFormats());
    this.store.dispatch(sidebarActions.getMinMaxTime());
    this.store.dispatch(sidebarActions.getConnectedDB());
    this.store.dispatch(sidebarActions.getMapServerURL());

    this.sseSubscription = this.sseService
      .getServerSentEvents<StatusData>(`${API_URL}/advmetrics/sse/mstatus`)
      .subscribe((event) => {
        this.store.dispatch(sidebarActions.statusDataReceived(event));
      });
  }

  ngOnDestroy(): void {
    this.sseSubscription?.unsubscribe();
  }
}
