import {
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
  inject
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DragDropModule } from '@angular/cdk/drag-drop';
import {
  Subscription,
  exhaustMap,
  switchMap,
  takeUntil,
  takeWhile,
  timer,
  timeout
} from 'rxjs';
import {
  MidasAiService,
  CombatPowerEntity,
  ProcessorStatus,
  QueryResult,
  ResultRow
} from '../services/midas-ai.service';

interface ProcessorCard { name: string; flag?: string; }
interface GuidedQuestion { label: string; kind: string; inputs: 'none' | 'unit' | 'range' | 'compare' | 'time'; }

interface CombatInterval {
  label: string;
  range: string;
  changes: string[];
  events: string[];
}

interface ChatMessage {
  id: number;
  role: 'user' | 'assistant';
  text: string;
  html: string;
  result?: QueryResult;
  rows: ResultRow[];
  columns: string[];
  intervals: CombatInterval[];
  summaryHtml: string;
  confidence?: number;
  retrievedTables: string[];
}

@Component({
  selector: 'app-midas-ai',
  standalone: true,
  imports: [FormsModule, DragDropModule],
  templateUrl: './midas-ai.component.html',
  styleUrls: ['./midas-ai.component.css']
})
export class MidasAiComponent implements OnInit, OnDestroy {
  @ViewChild('messageList')
  private messageList?: ElementRef<HTMLDivElement>;

  private readonly service = inject(MidasAiService);
  private readonly subscriptions = new Subscription();
  private request?: Subscription;
  private scrollTimer?: ReturnType<typeof setTimeout>;
  private nextId = 0;
  private launcherMoved = false;

  readonly logoUrl = 'assets/midas_icon.png';

  isOpen = true;
  sizeMode = 0;
  loading = false;
  question = '';
  error = '';
  progress = '';
  connection = 'Checking service…';
  sqlModel = 'Loading…';
  answerModel = 'Loading…';
  databaseName = 'Loading…';
  schemaSource = 'Loading…';
  messages: ChatMessage[] = [];
  dragPosition = { x: 0, y: 0 };

  guideOpen = true;
  selectedProcessor?: ProcessorCard;
  processorStatus: ProcessorStatus = {};
  statusLoading = false;
  guideError = '';
  units: CombatPowerEntity[] = [];
  unitsLoading = false;
  unitName = '';
  secondUnitName = '';
  startMinute = 0;
  endMinute: number | null = null;
  pointMinute: number | null = null;
  selectedGuide?: GuidedQuestion;
  private statusRequest?: Subscription;
  private unitsRequest?: Subscription;
  readonly processors: ProcessorCard[] = [
    {name:'H-Hour',flag:'jHHourActive'}, {name:'Rate of Movement',flag:'jROMActive'},
    {name:'Control Measure Occupation',flag:'jCMOccupationsActive'},
    {name:'Picture of Enemy',flag:'jPOEActive'}, {name:'Enemy Engagement',flag:'jEnemyEngagementsActive'},
    {name:'Fratricide',flag:'jFratricideActive'}, {name:'Combat Power',flag:'jCPowerActive'},
    {name:'Entity Watch',flag:'jEntityWatchActive'}, {name:'Gun & AFV'},
    {name:'C2SIM Comparison'}, {name:'MDVT'}
  ];
  readonly dashboardGuides: GuidedQuestion[] = [
    {label:'List available units',kind:'list',inputs:'none'},
    {label:'Show a unit trend',kind:'trend',inputs:'range'},
    {label:'Show latest Combat Power',kind:'latest',inputs:'unit'},
    {label:'Show minimum Combat Power',kind:'minimum',inputs:'unit'},
    {label:'Show maximum Combat Power',kind:'maximum',inputs:'unit'},
    {label:'Compare two units',kind:'compare',inputs:'compare'},
    {label:'Show equipment details',kind:'details',inputs:'time'}
  ];
  readonly whyGuides: GuidedQuestion[] = [
    {label:'Explain a Combat Power drop',kind:'why-drop',inputs:'range'},
    {label:'Identify equipment quantity changes',kind:'why-equipment',inputs:'range'},
    {label:'Find related firing or damage events',kind:'why-events',inputs:'range'},
    {label:'Investigate why Combat Power stayed low',kind:'why-low',inputs:'range'},
    {label:'Investigate a recovery',kind:'why-recovery',inputs:'range'},
    {label:'Explain differences between two units',kind:'why-compare',inputs:'compare'}
  ];

  statusLabel(processor: ProcessorCard): string {
    if (this.statusLoading) return 'Checking status';
    const value = processor.flag ? this.processorStatus[processor.flag] : undefined;
    return value === true ? 'Active' : value === false ? 'Inactive' : 'Status unavailable';
  }

  refreshProcessors(after?: () => void): void {
    this.statusRequest?.unsubscribe();
    this.statusLoading = true;
    this.statusRequest = this.service.processorStatus().subscribe({
      next: status => {
        this.processorStatus = status;
        if (this.endMinute === null && typeof status['jMaxTime'] === 'number') this.endMinute = status['jMaxTime'] / 60000;
      },
      error: () => { this.processorStatus = {}; this.statusLoading = false; after?.(); },
      complete: () => { this.statusLoading = false; after?.(); }
    });
    this.subscriptions.add(this.statusRequest);
  }

  chooseProcessor(processor: ProcessorCard): void {
    this.selectedProcessor = processor;
    this.selectedGuide = undefined;
    this.guideError = '';
    this.refreshProcessors(() => {
      if (this.selectedProcessor !== processor || processor.name !== 'Combat Power' || this.statusLabel(processor) !== 'Active') return;
      this.unitsRequest?.unsubscribe();
      this.unitsLoading = true;
      this.unitsRequest = this.service.combatPowerEntities().pipe(timeout(10000)).subscribe({
        next: entities => {
          const found = new Map<number, CombatPowerEntity>();
          const visit = (items: CombatPowerEntity[]) => {
            for (const item of items) {
              if (Number.isInteger(item.id) && typeof item.name === 'string') found.set(item.id, item);
              if (Array.isArray(item.children)) visit(item.children);
            }
          };
          if (!Array.isArray(entities)) { this.guideError = 'Could not load unit names. You can still type a question.'; return; }
          visit(entities);
          this.units = [...found.values()].sort((a,b) => a.name.localeCompare(b.name));
        },
        error: () => { this.unitsLoading = false; this.guideError = 'Could not load unit names. You can still type a question.'; },
        complete: () => { this.unitsLoading = false; }
      });
      this.subscriptions.add(this.unitsRequest);
    });
  }

  selectGuide(guide: GuidedQuestion): void {
    this.selectedGuide = guide;
    this.guideError = '';
    if (guide.inputs === 'none') this.prepareGuidedQuestion();
  }

  prepareGuidedQuestion(): void {
    const guide = this.selectedGuide;
    if (!guide || !this.selectedProcessor || this.statusLabel(this.selectedProcessor) !== 'Active') return;
    const resolve = (name: string) => this.units.filter(unit => unit.name.toLowerCase() === name.trim().toLowerCase());
    const first = resolve(this.unitName);
    const second = resolve(this.secondUnitName);
    if (guide.inputs !== 'none' && first.length !== 1) { this.guideError = 'Choose one exact unit name from the suggestions.'; return; }
    if (guide.inputs === 'compare' && (second.length !== 1 || first[0].id === second[0].id)) {
      this.guideError = 'Choose a different second unit from the suggestions.'; return;
    }
    const validMinute = (value: number | null) => value !== null && Number.isFinite(value) && value >= 0 && Number.isInteger(value * 60000);
    if ((guide.inputs === 'range' || guide.inputs === 'compare') && (!validMinute(this.startMinute) || !validMinute(this.endMinute) || this.endMinute! < this.startMinute)) {
      this.guideError = 'Enter a valid simulation range in minutes, with the end at or after the start.'; return;
    }
    if (guide.inputs === 'time' && !validMinute(this.pointMinute)) { this.guideError = 'Enter a simulation time in minutes.'; return; }
    const name = first[0]?.name;
    const unit = JSON.stringify(name);
    const other = JSON.stringify(second[0]?.name);
    const range = `from ${this.startMinute * 60000} to ${this.endMinute! * 60000} milliseconds`;
    const questions: Record<string,string> = {
      list:'Which units have Combat Power data?',
      trend:`Show the Combat Power trend for ${unit} ${range}.`,
      latest:`What is the latest Combat Power for ${name}?`,
      minimum:`What is the minimum Combat Power for ${name}?`,
      maximum:`What is the maximum Combat Power for ${name}?`,
      compare:`Compare the Combat Power of ${unit} and ${other} ${range}.`,
      details:`Show Combat Power equipment details for ${unit} at ${this.pointMinute! * 60000} milliseconds.`,
      'why-drop':`Why did the Combat Power of ${unit} drop ${range}? Show equipment changes and related events.`,
      'why-equipment':`Why did the Combat Power of ${unit} change ${range}? Identify the equipment quantity changes that explain it.`,
      'why-events':`Why did the Combat Power of ${unit} fall ${range}? Investigate related firing or damage events, including the firing unit, weapon and ammunition where recorded.`,
      'why-low':`Why did the Combat Power of ${unit} remain low ${range}? Check for repair, resupply and operational equipment recovery evidence.`,
      'why-recovery':`Why did the Combat Power of ${unit} recover ${range}? Check whether any increase occurred and investigate supporting equipment and event records.`,
      'why-compare':`Why did the Combat Power of ${unit} differ from ${other} ${range}? Compare operational quantities, reference settings and related events.`
    };
    this.question = questions[guide.kind];
    this.guideError = '';
    this.guideOpen = false;
  }

  readonly suggestions = [
    {
      label: 'Show H-Hour crossings by line of departure',
      question:
        'How many H-Hour crossings were recorded for each line of departure?'
    },
    {
      label: 'Find units with Combat Power below 50 percent',
      question:
        'Using stored Combat Power results, which units have a recorded Combat Power below 50 percent?'
    },
    {
      label: "Show a unit's Combat Power history",
      question:
        'Show the Combat Power history for 102 BDE 18 BN A COY 2 PL, ordered by result time.'
    },
    {
      label: 'Show configured H-Hour events',
      question:
        'Show all configured H-Hour events with the line of departure name, scheduled time, and threshold in minutes.'
    }
  ];

  private readonly stageLabels: Record<string, string> = {
    starting: 'Starting…',
    schema_rag: 'Finding relevant data…',
    intent_classification: 'Understanding the request…',
    sql_generation: 'Preparing the database query…',
    static_check: 'Checking the query…',
    explain: 'Validating the query…',
    execution: 'Retrieving results…',
    rendering: 'Preparing the answer…'
  };

  ngOnInit(): void {
    this.refreshProcessors();
    this.subscriptions.add(
      this.service.health().pipe(timeout(10000)).subscribe({
        next: health => {
          this.connection = 'Service reachable';
          this.sqlModel = health.sql_model || 'Not configured';
          this.answerModel = health.render_model || 'Not configured';
          this.databaseName = health.database || 'Not provided';
          this.schemaSource = health.schema_source || 'Not provided';
        },
        error: () => {
          this.connection = 'Connection needs attention';
          this.sqlModel = 'Unavailable';
          this.answerModel = 'Unavailable';
          this.databaseName = 'Unavailable';
          this.schemaSource = 'Unavailable';
        }
      })
    );
  }

  open(): void {
    this.isOpen = true;
    this.scrollToBottom();
  }

  minimise(): void {
    this.isOpen = false;
  }

  cycleSize(): void {
    this.sizeMode = (this.sizeMode + 1) % 3;
    this.dragPosition = { x: 0, y: 0 };
    this.scrollToBottom();
  }

  launcherDragStarted(): void {
    this.launcherMoved = true;
  }

  launcherPointerDown(): void {
    this.launcherMoved = false;
  }

  launcherClicked(): void {
    if (!this.launcherMoved) {
      this.open();
    }
  }

  newConversation(): void {
    this.request?.unsubscribe();
    this.loading = false;
    this.progress = '';
    this.question = '';
    this.error = '';
    this.messages = [];
    this.guideOpen = true;
    this.selectedGuide = undefined;
    this.refreshProcessors();
  }

  sendSuggestion(question: string): void {
    if (!this.loading) {
      this.question = question;
      this.send();
    }
  }

  send(): void {
    const question = this.question.trim();

    if (!question || this.loading) {
      return;
    }

    const contextualQuestion = this.contextualQuestion(question);
    const history = this.messages
      .slice(-8)
      .filter(message => message.role === 'user')
      .map(message => message.text);

    const localReply = this.conversationalReply(question);

    this.addMessage('user', question);
    this.question = '';
    this.error = '';

    if (localReply) {
      this.addMessage('assistant', localReply);
      return;
    }

    this.loading = true;
    this.progress = 'Starting…';

    this.request = this.service.start(
      contextualQuestion,
      question,
      history
    ).pipe(
      timeout(15000),
      switchMap(start => {
        if (!start.job_id) {
          throw new Error('The service returned no job ID.');
        }

        return timer(0, 1000).pipe(
          exhaustMap(() =>
            this.service.status(start.job_id).pipe(timeout(15000))
          ),
          takeWhile(
            status => status.status !== 'done' && status.status !== 'error',
            true
          ),
          takeUntil(timer(600000))
        );
      })
    ).subscribe({
      next: status => {
        const stage = status.stage?.stage || 'starting';
        const attempt = status.stage?.attempt;

        this.progress = (this.stageLabels[stage] || 'Working…') +
          (attempt ? ` · attempt ${attempt}` : '');

        if (status.status === 'done' || status.status === 'error') {
          this.loading = false;

          if (status.result) {
            this.addResult(status.result);
          } else {
            this.error = 'The service returned no result.';
          }

          this.scrollToBottom();
        }
      },
      error: () => {
        this.loading = false;
        this.error =
          'Could not complete the DB Agent request. Check the MIDAS backend and DB Agent logs.';
        this.scrollToBottom();
      },
      complete: () => {
        if (this.loading) {
          this.loading = false;
          this.error =
            'The request exceeded 600 seconds. Check API logs for the active job.';
          this.scrollToBottom();
        }
      }
    });

    this.scrollToBottom();
  }

  onInputKeydown(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
      event.preventDefault();
      this.send();
    }
  }

  cell(value: unknown): string {
    if (value === null || value === undefined) {
      return '';
    }

    return typeof value === 'object'
      ? JSON.stringify(value)
      : String(value);
  }

  private conversationalReply(question: string): string | undefined {
    const normalized = question.trim().toLowerCase().replace(/[!.?\s]+$/, '');

    if ([
      'hi', 'hello', 'hey',
      'good morning', 'good afternoon', 'good evening'
    ].includes(normalized)) {
      return 'Hi! I can help you explore MIDAS military exercise data. ' +
        'Ask about units, H-Hour events, metrics, recorded results, or trends.';
    }

    if (['help', 'what can you do', 'what do you do'].includes(normalized)) {
      return 'I turn plain-language questions into SQL and retrieve evidence-based ' +
        'answers from the connected MIDAS exercise database. You can ask about ' +
        'dashboard results, units, events, metrics, recorded outcomes, and ' +
        'follow-up questions.';
    }

    return undefined;
  }

  private contextualQuestion(question: string): string {
    const turns = this.messages.slice(-8).map(message =>
      message.role === 'user'
        ? `User: ${message.text}`
        : `Assistant: ${message.text.slice(0, 900)}`
    );

    if (!turns.length) {
      return question;
    }

    return 'Continue this MIDAS database conversation. Use the prior conversation ' +
      "only to resolve references such as 'that unit', 'only LoD RED', or 'latest'. " +
      'Query the database for the answer; never invent data.\n\n' +
      'Prior conversation:\n' + turns.join('\n') +
      `\n\nCurrent user request: ${question}`;
  }

  private addMessage(
    role: ChatMessage['role'],
    text: string,
    result?: QueryResult
  ): void {
    const rows = result?.rows || [];
    const columns = [...new Set(rows.flatMap(row => Object.keys(row)))];
    const intervals = this.combatIntervals(rows);
    const answer = result?.answer?.trim() || '';
    const summary = answer.split('\n\n|', 1)[0].trim();
    const hasDropSummary = rows.length > 0 &&
      'drop_pp' in rows[0] && 'event_text' in rows[0];

    this.messages = [
      ...this.messages,
      {
        id: this.nextId++,
        role,
        text,
        html: this.markdown(text),
        result,
        rows,
        columns,
        intervals,
        summaryHtml: intervals.length || hasDropSummary
          ? this.markdown(summary)
          : '',
        confidence: result?.explanation?.confidence?.score,
        retrievedTables: (result?.explanation?.retrieved_tables || [])
          .map(table => table.name || '?')
      }
    ];

    this.scrollToBottom();
  }

  private addResult(result: QueryResult): void {
    const rows = result.rows || [];
    const count = result.row_count ?? rows.length;

    let text = (result.answer || '').split('\n').filter(line => !line.trimStart().startsWith('|')).join('\n').trim();

    if (rows.length && !text) {
      text = `I found ${count} matching record${count === 1 ? '' : 's'}.`;
    } else if (!text && result.success) {
      text = 'I did not find any matching records.';
    }

    const contextText = result.answer?.trim() || text;
    this.addMessage('assistant', text, result);

    // Follow-up context uses the analytical answer, matching Streamlit.
    this.messages[this.messages.length - 1].text = contextText;
  }

  private combatIntervals(rows: ResultRow[]): CombatInterval[] {
    if (!rows.length || !('interval_event_text' in rows[0])) {
      return [];
    }

    const groups = new Map<string, ResultRow[]>();

    for (const row of rows) {
      const key = JSON.stringify([
        row['unit_name'],
        row['previous_result_time'],
        row['result_time'],
        row['previous_combat_power'],
        row['current_combat_power']
      ]);

      const group = groups.get(key) || [];
      group.push(row);
      groups.set(key, group);
    }

    return [...groups.values()].map(group => {
      const first = group[0];
      const changes = new Set<string>();

      for (const row of group) {
        if (row['equipment_type'] !== null &&
          row['equipment_type'] !== undefined) {
          changes.add(
            `${this.cell(row['holding_change_time'])} ms · ` +
            `${this.cell(row['equipment_type'])}: ` +
            `${this.cell(row['previous_operational_quantity'])} → ` +
            `${this.cell(row['operational_quantity'])} operational`
          );
        }
      }

      const events = [
        ...new Set(this.cell(first['interval_event_text']).split('\n'))
      ].filter(Boolean).map(event => {
        const fields = event.split(' | ');

        if (fields.length >= 4) {
          return `${fields[0]} ms · Event #${fields[1]} · ${fields[2]}\n` +
            fields.slice(3).join(' | ');
        }

        return event;
      });

      return {
        label: `${this.cell(first['result_time'])} ms · ` +
          `${this.cell(first['previous_combat_power'])}% → ` +
          `${this.cell(first['current_combat_power'])}%`,
        range: `${this.cell(first['previous_result_time'])}–` +
          `${this.cell(first['result_time'])} ms`,
        changes: [...changes],
        events
      };
    });
  }

  private markdown(text: string): string {
    // Escape model output. Angular also sanitises the innerHTML binding.
    const escaped = text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');

    return escaped
      .split('\n')
      .map(line => {
        const formatted = line
          .replace(/`([^`]+)`/g, '<code>$1</code>')
          .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');

        if (/^#{1,6}\s/.test(formatted)) {
          return `<h4>${formatted.replace(/^#{1,6}\s+/, '')}</h4>`;
        }

        return formatted ? `<div>${formatted}</div>` : '<br>';
      })
      .join('');
  }

  private scrollToBottom(): void {
    clearTimeout(this.scrollTimer);

    this.scrollTimer = setTimeout(() => {
      const element = this.messageList?.nativeElement;

      if (element) {
        element.scrollTop = element.scrollHeight;
      }
    });
  }

  ngOnDestroy(): void {
    this.request?.unsubscribe();
    this.subscriptions.unsubscribe();
    clearTimeout(this.scrollTimer);
  }
}
