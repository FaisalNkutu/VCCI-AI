import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Store } from '@ngrx/store';
import { of } from 'rxjs';
import { GisMapComponent } from './map.component';

describe('GisMapComponent', () => {
  let component: GisMapComponent;
  let fixture: ComponentFixture<GisMapComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GisMapComponent],
      providers: [
        {
          provide: Store,
          useValue: { select: () => of([]) },
        },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(GisMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('hosts the Flex GIS frame instead of a Leaflet container', () => {
    const frame: HTMLIFrameElement | null =
      fixture.nativeElement.querySelector('iframe');
    expect(component).toBeTruthy();
    expect(frame?.getAttribute('src')).toContain(
      '/assets/flexgis/index.html?host=iframe'
    );
    expect(fixture.nativeElement.querySelector('#map')).toBeNull();
  });
});