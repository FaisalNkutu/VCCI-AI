import { Component, effect, inject, viewChild } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { Store } from '@ngrx/store';
import {
  selectSelectedLODLocation,
  selectSelectedUnits,
} from '@/store/features/h-hour.feature';
import { GisMapHostComponent } from '../gis-map/gis-map-host.component';
import {
  LOD_VIEW_MARGIN,
  asMapUnits,
  expandBounds,
  lodBounds,
  lodToElements,
  unitsToElements,
} from '../gis-map/gis-map.elements';

@Component({
  selector: 'gis-map',
  standalone: true,
  imports: [GisMapHostComponent],
  templateUrl: './map.component.html',
  styleUrl: './map.component.css',
})
export class GisMapComponent {
  private readonly store = inject(Store);
  private readonly host = viewChild(GisMapHostComponent);
  private readonly units = toSignal(this.store.select(selectSelectedUnits), {
    initialValue: [],
  });
  private readonly lodLocations = toSignal(
    this.store.select(selectSelectedLODLocation),
    { initialValue: [] }
  );

  constructor() {
    effect(() => {
      const host = this.host();
      if (!host) return;
      host.replaceElements(
        'hh-units',
        unitsToElements(asMapUnits(this.units()), 'hh-unit'),
        'Units'
      );
    });

    effect(() => {
      const host = this.host();
      if (!host) return;
      const locations = this.lodLocations() ?? [];
      host.replaceElements('hh-lod', lodToElements(locations), 'Line of Departure');
      const bounds = lodBounds(locations);
      if (bounds) host.setViewBounds(expandBounds(bounds, LOD_VIEW_MARGIN));
    });
  }
}
