/*
 * Copyright 2026 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

import {
  AfterViewInit,
  Component, computed, effect, EventEmitter, Injector, Input, input,
  InputSignal, Output,
  Signal, Type,
  ViewChild,
} from "@angular/core";
import {MatTableDataSource, MatTableModule} from "@angular/material/table";
import {MatSort, MatSortModule} from "@angular/material/sort";
import {NgClass, NgComponentOutlet} from "@angular/common";

export interface InjectableComponent<T> {
  component: Type<any>;
  injectorFn: (record: Record<string, unknown> & T) => Injector;
}

export interface ColumnDefinition<T> {
  field: string;
  header: string;
  injectableComponent?: InjectableComponent<T>; // Insert by "field" name if not provided
  sortingDataAccessor?: ((t: T) => string | number); // Sorting disabled if not provided
}

@Component({
  selector: 'sortable-table',
  imports: [
    MatTableModule,
    MatSortModule,
    NgComponentOutlet,
    NgClass,
  ],
  templateUrl: './sortable-table.component.html',
})
export class SortableTableComponent<T> implements AfterViewInit {

  @Input() enableRowSelection: boolean = false;
  @Output() onRowSelectionEvent : EventEmitter<T> = new EventEmitter<T>();
  tableData: InputSignal<T[]> = input.required<T[]>();
  tableDescription: InputSignal<ColumnDefinition<T>[]> = input.required<ColumnDefinition<T>[]>();
  displayedColumns: Signal<string[]> =
    computed<string[]>((): string[] => {
      return this.tableDescription().map(
        (columnDef: ColumnDefinition<T>): string => columnDef.field);
    })

  dataSource: MatTableDataSource<T> = new MatTableDataSource<T>([]);
  @ViewChild(MatSort) sort!: MatSort;

  constructor() {
    effect(() => {
      this.dataSource.data = this.tableData();
    })

    effect(() => {
      this.dataSource.sortingDataAccessor = (data: T, sortHeaderId: string): any => {
        const tableDescription: ColumnDefinition<T>[] = this.tableDescription();
        for (const columnDef of tableDescription) {
          if (columnDef.field === sortHeaderId) {
            if (columnDef.sortingDataAccessor !== undefined) {
              return columnDef.sortingDataAccessor(data);
            }
          }
        }
      }
    })
  }

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
  }

  selectedRow?: T;

  selectRow(row: T): void {
    this.onRowSelectionEvent.emit(row);
    this.selectedRow = row;
  }

  isSelectedRow(row: T) {
    return row === this.selectedRow;
  }

}
