import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { BaseChartDirective } from 'ng2-charts';
import { ChartData } from '@/models';
import { ChartDataset, ChartOptions } from 'chart.js';


@Component({
  selector: 'chart',
  standalone: true,
  imports: [
    BaseChartDirective
  ],
  templateUrl: './chart.component.html'
})
export class ChartComponent implements OnChanges {

  @Input({ required: true }) chartData: ChartData | null = null;
  chartLabels: string[] = [''];
  chartOptions: ChartOptions = {};
  data: ChartDataset[] = [];
  @Output()
  chartClicked: EventEmitter<any> = new EventEmitter();


  ngOnChanges(changes: SimpleChanges): void {
    if (!this.chartData) {
      return;
    }
    this.chartLabels = this.chartData.chartLabels;
    this.chartOptions = this.chartData.chartOptions;
    this.data = this.chartData.chartData;
  }

  onChartClicked(event: any) {
    this.chartClicked.emit(event);
  }


}
