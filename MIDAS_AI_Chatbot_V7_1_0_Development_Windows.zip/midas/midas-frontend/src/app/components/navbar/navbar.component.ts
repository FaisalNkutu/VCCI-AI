import { Component } from '@angular/core';
import { MatIcon } from '@angular/material/icon';
import { MatButton } from '@angular/material/button';

@Component({
  selector: 'navbar',
  standalone: true,
  imports: [
    MatIcon,
    MatButton
  ],
  templateUrl: './navbar.component.html',
})
export class NavbarComponent {

}
