import { Component, EventEmitter, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';
import { MatOption, MatSelect, MatSelectModule } from '@angular/material/select';

@Component({
  selector: 'app-datetime-picker',
  templateUrl: './datetime-picker.component.html',
  imports: [
    ReactiveFormsModule,
    MatDatepickerModule,
    MatInputModule,
    MatNativeDateModule,
    MatSelectModule,
    MatOption,
    MatSelect
  ],
  styles: `
  .full-width {
    width: 100%;
  }

  .time-container {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .time-container mat-form-field {
    width: 90px;
  }`
})
export class DatetimePickerComponent {
  @Output() dateTimeChange = new EventEmitter<Date | null>();

  form = new FormGroup({
    date: new FormControl<Date | null>(null),
    hour: new FormControl<number>(12),
    minute: new FormControl<number>(0),
    second: new FormControl<number>(0),
    meridiem: new FormControl<'AM' | 'PM'>('AM')
  });

  minutes = Array.from({ length: 60 }, (_, i) => i);
  hours = Array.from({ length: 13 }, (_, i) => i);

  constructor() {
    this.form.valueChanges.subscribe(() => {
      this.dateTimeChange.emit(this.getDateTime());
    });
  }

  getDateTime(): Date | null {
    const {
      date,
      hour,
      minute,
      second,
      meridiem
    } = this.form.getRawValue();

    if (!date) {
      return null;
    }

    const result = new Date(date);

    let hours = hour ?? 12;

    if (meridiem === 'PM' && hours < 12) {
      hours += 12;
    }

    if (meridiem === 'AM' && hours === 12) {
      hours = 0;
    }

    result.setHours(
      hours,
      minute ?? 0,
      second ?? 0,
      0
    );

    return result;
  }
}