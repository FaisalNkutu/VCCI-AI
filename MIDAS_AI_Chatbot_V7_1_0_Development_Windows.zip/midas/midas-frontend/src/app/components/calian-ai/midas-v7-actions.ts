/** V7 typed capability registry. The MIDAS host remains sole action executor. */
export interface V7CapabilityDefinition {
  id:string;kind:'navigation'|'selection'|'display-state';route?:string;
  requiresApproval:true;parameterNames:readonly string[];
  permission:'midas:dashboard:view'|'midas:dashboard:change';
}
export const V7_CAPABILITIES:readonly V7CapabilityDefinition[]=[
 {id:'navigate',kind:'navigation',requiresApproval:true,parameterNames:['dashboard'],permission:'midas:dashboard:view'},
 {id:'time_format',kind:'display-state',requiresApproval:true,parameterNames:['name'],permission:'midas:dashboard:change'},
 {id:'cp_time_range',kind:'selection',route:'/advmetrics/cp',requiresApproval:true,parameterNames:['start','end'],permission:'midas:dashboard:change'},
 {id:'cp_select_entity',kind:'selection',route:'/advmetrics/cp',requiresApproval:true,parameterNames:['id','selected'],permission:'midas:dashboard:change'},
 {id:'cp_grouping',kind:'selection',route:'/advmetrics/cp',requiresApproval:true,parameterNames:['grouping'],permission:'midas:dashboard:change'},
 {id:'rom_time_range',kind:'selection',route:'/advmetrics/rom',requiresApproval:true,parameterNames:['start','end'],permission:'midas:dashboard:change'},
 {id:'cm_time_range',kind:'selection',route:'/advmetrics/cm',requiresApproval:true,parameterNames:['start','end'],permission:'midas:dashboard:change'},
 {id:'rom_select_capture',kind:'selection',route:'/advmetrics/rom',requiresApproval:true,parameterNames:['id'],permission:'midas:dashboard:change'},
 {id:'cm_select_measure',kind:'selection',route:'/advmetrics/cm',requiresApproval:true,parameterNames:['id','selected'],permission:'midas:dashboard:change'}
];
/** Syntactic preflight only. Existing MIDAS NgRx validator enforces actual store/route bounds. */
export function preflightV7Action(action:unknown,params:unknown,route:string):boolean {
 const def=V7_CAPABILITIES.find(c=>c.id===action);
 if(!def|| (def.route && def.route!==route) || !params || typeof params!=='object' || Array.isArray(params))return false;
 const p=params as Record<string,unknown>;
 if(Object.keys(p).some(k=>!def.parameterNames.includes(k)))return false;
 switch(action){
  case 'navigate':return typeof p['dashboard']==='string' && /^[a-z0-9-]{1,40}$/.test(p['dashboard']);
  case 'time_format':return typeof p['name']==='string' && p['name'].length>0 && p['name'].length<=50;
  case 'cp_time_range':case 'rom_time_range':case 'cm_time_range':
   return typeof p['start']==='number' && typeof p['end']==='number' && Number.isFinite(p['start']) && Number.isFinite(p['end']) && p['start']<p['end'];
  case 'cp_select_entity':case 'rom_select_capture':case 'cm_select_measure':
   return typeof p['id']==='number' && Number.isSafeInteger(p['id']) && p['id']>=0 && (p['selected']===undefined || typeof p['selected']==='boolean');
  case 'cp_grouping':return p['grouping']==='equipment'||p['grouping']==='unit';
  default:return false;
 }
}
