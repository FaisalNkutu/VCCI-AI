import { Component } from '@angular/core';
@Component({
  selector: 'app-calian-ai',
  standalone: true,
  template: `<div class="h-full bg-zinc-950 text-white p-8"><h1>AI Chatbot</h1><p>Your assistant is hosted in the persistent panel alongside this workspace.</p></div>`
})
export class CalianAiComponent {}
