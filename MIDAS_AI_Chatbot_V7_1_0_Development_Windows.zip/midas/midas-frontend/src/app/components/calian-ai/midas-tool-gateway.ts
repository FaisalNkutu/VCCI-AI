/** V6 approved, bounded UI capability catalogue; not an arbitrary JavaScript executor. */
export const MIDAS_DASHBOARDS = {
  summary: { label: 'Summary', aliases: ['summary', 'overview'] },
  'h-hour': { label: 'H-Hour', aliases: ['h hour', 'h-hour'] },
  rom: { label: 'Rate of Movement', aliases: ['rate of movement', 'rom'] },
  cm: { label: 'CM Occupations', aliases: ['cm occupations', 'control measures', 'cm'] },
  poe: { label: 'Picture of Enemy', aliases: ['picture of enemy', 'poe'] },
  fratricide: { label: 'Fratricide', aliases: ['fratricide'] },
  'enemy-engagement': { label: 'Enemy Engagement', aliases: ['enemy engagement', 'enemy engagements'] },
  cp: { label: 'Combat Power', aliases: ['combat power', 'cp'] },
  'unit-watch': { label: 'Entity Watch', aliases: ['entity watch', 'unit watch'] },
  'holdings-rollup': { label: 'Holdings Rollup', aliases: ['holdings rollup'] },
  c2: { label: 'C2 Compare', aliases: ['c2 compare', 'c2'] },
} as const;

export type ReadTool = 'capabilities' | 'dashboard_snapshot' | 'compare_combat_power' | 'report_data';
export type ToolPayload = {
  tool: ReadTool; generatedAt: string; dashboard: string; connected: boolean;
  status: 'ok'|'unavailable'; reason?: string;
  data?: Record<string, unknown>;
};
export const MIDAS_ACTION_CATALOGUE = [
  'navigate', 'time_format', 'cp_time_range', 'cp_select_entity', 'cp_grouping',
  'rom_time_range', 'cm_time_range', 'rom_select_capture', 'cm_select_measure',
] as const;
export const MIDAS_READ_TOOLS: ReadTool[] = ['capabilities', 'dashboard_snapshot', 'compare_combat_power', 'report_data'];

/** Reject prompts that attempt to smuggle JSON actions; parsing happens inside the trusted host. */
export function normalizeDashboard(value: string): keyof typeof MIDAS_DASHBOARDS | undefined {
  const key = value.toLowerCase().trim().replace(/\s+/g,' ');
  return (Object.entries(MIDAS_DASHBOARDS) as Array<[keyof typeof MIDAS_DASHBOARDS, {label: string; aliases: readonly string[]}]>)
    .find(([, entry]) => entry.aliases.includes(key))?.[0];
}

export function seriesStats(points: unknown): {count:number;first:number;last:number;min:number;max:number;change:number} | null {
  if(!Array.isArray(points)) return null;
  const p = points.filter(x => x && typeof x==='object' && typeof x.time==='number' && Number.isFinite(x.time) && typeof x.combatPower==='number' && Number.isFinite(x.combatPower))
    .sort((a,b)=>a.time-b.time).slice(-2000);
  if(!p.length) return null;
  const values = p.map(x=>x.combatPower as number);
  return {count:values.length,first:values[0],last:values[values.length-1],min:Math.min(...values),max:Math.max(...values),change:values[values.length-1]-values[0]};
}

export function asReport(data: ToolPayload): string {
  const date = data.generatedAt;
  const body = data.status === 'ok' ? JSON.stringify(data.data || {}, null, 2) : `Data unavailable: ${data.reason || 'No data'}`;
  return `# MIDAS dashboard evidence report\n\nGenerated: ${date}\nDashboard: ${data.dashboard}\nData source connected: ${data.connected ? 'Yes':'No'}\nStatus: ${data.status}\n\n## Observations from available MIDAS state\n\n\`\`\`json\n${body}\n\`\`\`\n\nThis report reflects available authorized MIDAS state only; it is not a prediction or operational recommendation.\n`;
}
