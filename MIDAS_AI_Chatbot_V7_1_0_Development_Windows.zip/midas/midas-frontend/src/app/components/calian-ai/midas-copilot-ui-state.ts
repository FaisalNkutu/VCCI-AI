import { Injectable, signal } from '@angular/core';
/** One persistent iframe / panel shared across MIDAS routes. */
@Injectable({ providedIn: 'root' })
export class MidasCopilotUiState {
  readonly open = signal(false);
  readonly fullPage = signal(false);
}
