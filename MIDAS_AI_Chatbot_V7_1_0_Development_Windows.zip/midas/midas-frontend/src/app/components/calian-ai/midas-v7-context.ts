/** V7 context contract: opt-in, bounded selection metadata only. NOT an authorization token. */
export interface MidasV7Context {
  protocolVersion: 2;
  contextId: string;
  revision: number;
  capturedAt: string;
  dashboard: string | null;
  route: string | null;
  dataSource: {connected: boolean; datasetRef: null};
  selection: {entityIds: number[]; timeRange: {start:number;end:number}|null;
    grouping: string|null; timeFormat:string|null; selectedCaptureId:number|null; controlMeasureIds:number[]};
  consent: {includeInAgentQueries:boolean};
  kind: 'ui-selection-only';
}
const limited = (v: unknown, cap = 100): string | null =>
  typeof v === 'string' && v.length <= cap && !/[\x00-\x1f]/.test(v) ? v : null;
const ids = (v: unknown): number[] => Array.isArray(v) ? [...new Set(v.filter((n): n is number => typeof n === 'number' && Number.isSafeInteger(n) && n >= 0))].slice(0,40) : [];
const range = (v: unknown): {start:number;end:number}|null => {
  if (!v || typeof v !== 'object') return null;
  const r=v as Record<string,unknown>;
  return typeof r['start']==='number' && typeof r['end']==='number' &&
    Number.isFinite(r['start']) && Number.isFinite(r['end']) && r['start'] < r['end']
    ? {start:r['start'],end:r['end']} : null;
};
/** Never serializes raw NgRx state, credentials, PII or unbounded arrays. */
export function buildMidasV7Context(raw: Record<string, unknown>|null, id:string, revision:number): MidasV7Context|null {
  if (!raw || !/^[a-f0-9-]{36}$/i.test(id) || !Number.isSafeInteger(revision) || revision < 1) return null;
  const selected = (raw['selectedValues'] && typeof raw['selectedValues']==='object') ? raw['selectedValues'] as Record<string,unknown> : {};
  const cpIds=ids(raw['cpSelectedEntityIds']);
  const selectedEntities=Array.isArray(selected['entities']) ? ids((selected['entities'] as Array<{id?:unknown}>).map(e=>e?.id)) : [];
  const cmIds=Array.isArray(selected['controlMeasures']) ? ids((selected['controlMeasures'] as Array<{id?:unknown}>).map(e=>e?.id)) : [];
  const capture=selected['capture'] as {id?:unknown}|null|undefined;
  const captureId = typeof capture?.id==='number' && Number.isSafeInteger(capture.id) ? capture.id:null;
  const envelope: MidasV7Context = {
    protocolVersion:2, contextId:id, revision, capturedAt:new Date().toISOString(),
    dashboard: limited(raw['activeDashboard'],60), route:limited(raw['route'],120),
    // Do not accept a browser supplied dataset ID for authorization.
    dataSource:{connected:raw['dataSourceConnected']===true,datasetRef:null},
    selection:{entityIds:cpIds.length?cpIds:selectedEntities,timeRange:range(selected['timeframe'] || raw['cpTimeframe']),
      grouping:limited(selected['grouping'] || raw['cpGrouping'],32),timeFormat:limited(selected['timeFormat'] || raw['selectedTimeFormat'],48),
      selectedCaptureId:captureId,controlMeasureIds:cmIds},
    consent:{includeInAgentQueries:true},kind:'ui-selection-only'
  };
  return JSON.stringify(envelope).length<=16384?envelope:null;
}
