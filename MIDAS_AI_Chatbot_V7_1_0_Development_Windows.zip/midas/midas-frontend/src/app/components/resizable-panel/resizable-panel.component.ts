import { Component, ElementRef, NgZone, ViewChild, Input } from '@angular/core';

import { Store } from '@ngrx/store';
import { sidebarActions } from '@/store/actions/sidebar.actions';

const MIN_PANEL_WIDTH = 200;
const MAX_PANEL_WIDTH = 800;

@Component({
  selector: 'resizable-panel',
  templateUrl: './resizable-panel.component.html',
  styleUrl: './resizable-panel.component.css'
})
export class ResizablePanelComponent {
  @ViewChild('resizeBox') resizeBox!: ElementRef<HTMLElement>;
  @Input() isVisible: boolean = true;
  width = 300;

  constructor(private ngZone: NgZone, private store: Store) {}

  startResize(event: PointerEvent): void {
    if (event.button !== 0) return;

    event.preventDefault();
    const handle = event.currentTarget as HTMLElement;
    const box = this.resizeBox.nativeElement;
    let lastX = event.clientX;
    let currentWidth = box.getBoundingClientRect().width;
    handle.setPointerCapture(event.pointerId);

    const onMove = (moveEvent: PointerEvent) => {
      const delta = moveEvent.clientX - lastX;
      lastX = moveEvent.clientX;
      currentWidth = Math.min(
        MAX_PANEL_WIDTH,
        Math.max(MIN_PANEL_WIDTH, currentWidth + delta)
      );
      this.width = currentWidth;
      box.style.width = `${currentWidth}px`;
    };

    const onUp = () => {
      handle.removeEventListener('pointermove', onMove);
      handle.removeEventListener('pointerup', onUp);
      handle.removeEventListener('pointercancel', onUp);
      this.ngZone.run(() => {
        this.store.dispatch(sidebarActions.resizePanelDragEnd());
      });
    };

    this.ngZone.runOutsideAngular(() => {
      handle.addEventListener('pointermove', onMove);
      handle.addEventListener('pointerup', onUp);
      handle.addEventListener('pointercancel', onUp);
    });
  }
}
