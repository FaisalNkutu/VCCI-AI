import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { AppType } from '@/components/selection/selection.component';

export const APP_PREF_KEY = 'user_app_preference';

export const rootRedirectGuard: CanActivateFn = () => {
  const router = inject(Router);
  const preference = localStorage.getItem(APP_PREF_KEY)?.toLocaleLowerCase();

  if (preference === 'advmetrics') {
    return router.parseUrl('/advmetrics');
  }
  if (preference === 'lvcts') {
    return router.parseUrl('/lvcts');
  }
  if (preference === 'calian-ai') {
    return router.parseUrl('/calian-ai');
  }

  return true;
};

export function updatePreferenceGuard(appName: AppType): CanActivateFn {
  return () => {
    localStorage.setItem(APP_PREF_KEY, appName);

    return true;
  };
}
