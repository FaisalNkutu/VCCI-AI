import {
  AfterViewInit,
  Component,
  Inject,
  Input,
  OnChanges,
  SimpleChanges,
  viewChild,
} from '@angular/core';
import { Store } from '@ngrx/store';

import { MatCardModule } from '@angular/material/card';
import { FormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { C2Context } from '@/models';
import { c2Actions } from '@/store/actions/c2.actions';
import { GisMapHostComponent } from '@/components/gis-map/gis-map-host.component';
import { contextToElements } from '@/components/gis-map/gis-map.elements';

export type ContextType = 'vcci' | 'metrics';

@Component({
  selector: 'c2-map',
  standalone: true,
  imports: [
    MatCardModule,
    FormsModule,
    MatCheckboxModule,
    MatButtonToggleModule,
    GisMapHostComponent,
  ],
  templateUrl: './c2-map.component.html',
  styles: `
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
  `,
})
export class C2MapComponent implements AfterViewInit, OnChanges {
  @Input() metricContext: C2Context[] = [];
  @Input() vcciContext: C2Context[] = [];
  @Input() selectedContexts: C2Context[] = [];
  selectedContextType: ContextType = 'vcci';
  private readonly host = viewChild(GisMapHostComponent);
  private readonly shownLayerIds = new Set<string>();
  private viewReady = false;

  constructor(@Inject(Store) private store: Store) {}

  ngAfterViewInit() {
    this.viewReady = true;
    this.syncContexts();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (!this.viewReady) return;
    if (
      changes['metricContext'] ||
      changes['vcciContext'] ||
      changes['selectedContexts']
    ) {
      this.syncContexts();
    }
  }

  isContextSelected(context: C2Context): boolean {
    return this.selectedContexts.some((c) => c.uniqueID === context.uniqueID);
  }

  toggleContextSelection(context: C2Context) {
    if (this.isContextSelected(context)) {
      this.store.dispatch(c2Actions.contextDeselected(context.uniqueID));
    } else {
      this.store.dispatch(c2Actions.contextSelected(context.uniqueID));
    }
  }

  resizeMap(): void {}

  private syncContexts(): void {
    const host = this.host();
    if (!host) return;
    const contexts = [...this.metricContext, ...this.vcciContext];
    const nextIds = new Set(contexts.map((context) => context.uniqueID));
    for (const layerId of this.shownLayerIds) {
      if (nextIds.has(layerId)) continue;
      host.replaceElements(layerId, []);
      host.setLayerVisible(layerId, false);
    }
    this.shownLayerIds.clear();
    for (const id of nextIds) this.shownLayerIds.add(id);

    for (const context of contexts) {
      host.replaceElements(
        context.uniqueID,
        contextToElements(context),
        context.name
      );
      host.setLayerVisible(context.uniqueID, context.selected);
    }
  }
}
