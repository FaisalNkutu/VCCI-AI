import { Component, Input } from '@angular/core';
import { GlobalTimeSelectorComponent } from '@/components/time-selector/global-time-selector.component';
import { Timeframe } from '@/models/models';
import { MatCard, MatCardContent } from '@angular/material/card';
import { C2MapComponent } from './c2-map.component';
import { Store } from '@ngrx/store';
import { selectMetricContexts, selectSelectedContexts, selectVcciContexts } from '@/store/features/c2.feature';
import { AsyncPipe } from '@angular/common';
import { c2Actions } from '@/store/actions/c2.actions';

@Component({
  selector: 'c2-compare',
  imports: [GlobalTimeSelectorComponent, MatCard, MatCardContent, C2MapComponent, AsyncPipe],
  templateUrl: './c2-compare.component.html',
})
export class C2CompareComponent {
  metricContext$ = this.store.select(selectMetricContexts);
  vcciContext$ = this.store.select(selectVcciContexts);
  selectedContexts$ = this.store.select(selectSelectedContexts);

  constructor(private store: Store) {}

  @Input()
  timeframe!: Timeframe;

  onTimeframeChange(tf: Timeframe) {
    this.store.dispatch(c2Actions.timeframeChange(tf));
  }
}
