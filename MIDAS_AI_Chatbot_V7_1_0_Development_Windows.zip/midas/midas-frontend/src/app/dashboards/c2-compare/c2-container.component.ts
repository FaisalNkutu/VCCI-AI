import { Component, inject, OnInit } from '@angular/core';
import { C2CompareComponent } from './c2-compare.component';
import { Store } from '@ngrx/store';
import { AsyncPipe } from '@angular/common';
import { c2Actions } from '@/store/actions/c2.actions';
import { selectC2Timeframe, selectMetricContexts, selectSelectedContexts, selectVcciContexts } from '@/store/features/c2.feature';
@Component({
  selector: 'app-c2-container',
  imports: [C2CompareComponent, AsyncPipe],
  template: `
    <c2-compare
      [timeframe]="(timeframe$ | async) || { start: 0, end: 0 }"
    />
  `,
})
export class C2ContainerComponent implements OnInit {
  private store = inject(Store);

  timeframe$ = this.store.select(selectC2Timeframe);
  metricContext$ = this.store.select(selectMetricContexts);
  vcciContext$ = this.store.select(selectVcciContexts);
  ngOnInit(): void {
    this.store.dispatch(c2Actions.getC2Context());
   
  }
}
