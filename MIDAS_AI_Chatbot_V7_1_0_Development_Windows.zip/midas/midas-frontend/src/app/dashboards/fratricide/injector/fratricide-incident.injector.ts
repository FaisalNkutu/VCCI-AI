/*
 * Copyright 2026 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

import {inject, InjectionToken, Injector} from "@angular/core";
import {FratIncident} from "@/models";

export const FRAT_INCIDENT_CELL_INJECTION_TOKEN = new InjectionToken<FratIncident>('FRAT_INCIDENT_CELL_INJECTION_TOKEN');

export function createFratIncidentCellInjectorFn() {
  const injector: Injector = inject(Injector);

  return (incident: Record<string, unknown> & FratIncident): Injector =>
    Injector.create({
      parent: injector,
      providers: [{
        provide: FRAT_INCIDENT_CELL_INJECTION_TOKEN,
        useValue: incident,
      }],
    })
}
