import {ChartComponent, SimChartData} from '@/chart-v2/chart-v2.component';
import {ResizablePanelComponent} from '@/components/resizable-panel/resizable-panel.component';
import {GlobalTimeSelectorComponent} from '@/components/time-selector/global-time-selector.component';
import {FratricideMapComponent} from '@/dashboards/fratricide/fratricide-map.component';
import {FratIncident, Timeframe} from '@/models';
import {fratricideActions} from '@/store/actions/fratricide.actions';
import {selectSelectedFratIncidentDetails} from '@/store/features/fratricide.feature';
import { AsyncPipe } from '@angular/common';
import {Component, Injector, input, Input, InputSignal} from '@angular/core';
import {MatCard, MatCardContent} from '@angular/material/card';
import {MatIconModule} from '@angular/material/icon';
import {MatTooltip} from '@angular/material/tooltip';
import {Store} from '@ngrx/store';
import {
  ColumnDefinition,
  SortableTableComponent
} from "@/components/sortable-table/sortable-table.component";
import {
  FratricideFiringUnitCellComponent
} from "@/dashboards/fratricide/table-cell/fratricide-firing-unit-cell.component";
import {
  FratricideReceivingUnitCellComponent
} from "@/dashboards/fratricide/table-cell/fratricide-received-unit-cell.component";
import {
  createFratIncidentCellInjectorFn
} from "@/dashboards/fratricide/injector/fratricide-incident.injector";

interface FratDataPoint {
  count: number;
  time: number;
  formattedTime: string
}

@Component({
  selector: 'fratricide-dash',
  imports: [
    MatCard,
    MatCardContent,
    MatTooltip,
    ChartComponent,
    FratricideMapComponent,
    AsyncPipe,
    MatIconModule,
    ResizablePanelComponent,
    GlobalTimeSelectorComponent,
    SortableTableComponent
],
  templateUrl: './fratricide-dash.component.html',
})
export class FratricideDashComponent {

  @Input() timeframe!: Timeframe;
  @Input() graphData!: SimChartData<'line', FratDataPoint> | null;
  selectedFratIncidentDetails$ = this.store.select(selectSelectedFratIncidentDetails);
  fratTableData: InputSignal<FratIncident[]> = input.required<FratIncident[]>();
  fratIncidentInjectorFn: (incident: Record<string, unknown> & FratIncident) => Injector = createFratIncidentCellInjectorFn();
  fratTableDescription: ColumnDefinition<FratIncident>[] = [
    {
      field: "firingType",
      header: "Type",
      sortingDataAccessor: (incident: FratIncident): string => incident.firingType
    },
    {
      field: "firingUnit",
      header: "Firing Unit",
      injectableComponent: {
        component: FratricideFiringUnitCellComponent,
        injectorFn: this.fratIncidentInjectorFn
      },
      sortingDataAccessor: (incident: FratIncident): string => incident.name
    },
    {
      field: "unitRxFire",
      header: "Unit Rx Fire",
      injectableComponent: {
        component: FratricideReceivingUnitCellComponent,
        injectorFn: this.fratIncidentInjectorFn
      },
      sortingDataAccessor: (incident: FratIncident): string => incident.receivingEntityName
    },
    {
      field: "lat",
      header: "Firing Unit Lat.",
      sortingDataAccessor: (incident: FratIncident): number => incident.lat
    },
    {
      field: "lon",
      header: "Firing Unit Lon.",
      sortingDataAccessor: (incident: FratIncident): number => incident.lon
    },
  ]

  isResizablePanelVisible: boolean = false;

  constructor(private store: Store) {}

  onRowClick(row: FratIncident): void {
    this.store.dispatch(fratricideActions.fratIncidentSelected(row));
  }

  onTimeframeChange(tf: Timeframe) {
    this.store.dispatch(fratricideActions.timeframeChange(tf));
  }

  onChartClicked(event: any) {
    if (!this.graphData || !event.active || event.active.length === 0) {
      return;
    }
    const pointData = event.active[0].element.$context.raw;
    if (!pointData || !pointData.count) {
      console.log('No time for point data');
      return;
    }
    this.store.dispatch(fratricideActions.pointSelected(pointData.time));
  }

  toggleResizablePanel(): void {
    this.isResizablePanelVisible = !this.isResizablePanelVisible;
  }

}
