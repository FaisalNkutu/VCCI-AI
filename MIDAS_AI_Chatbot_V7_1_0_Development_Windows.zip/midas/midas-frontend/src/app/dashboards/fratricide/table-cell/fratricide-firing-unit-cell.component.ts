/*
 * Copyright 2026 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

import {Component, inject} from "@angular/core";
import {FratIncident} from "@/models";
import {NameAndMilSymbolCellComponent} from "@/components/table-cell/name-and-mil-symbol-cell.component";
import {FRAT_INCIDENT_CELL_INJECTION_TOKEN} from "@/dashboards/fratricide/injector/fratricide-incident.injector";

@Component({
  selector: 'fratricide-firing-unit-cell',
  imports: [NameAndMilSymbolCellComponent],
  template: `
    <name-and-mil-symbol-cell
      [name]="fratIncidentToken.name"
      [milSymbol]="fratIncidentToken.milSym"
    />`
})
export class FratricideFiringUnitCellComponent {
  public fratIncidentToken: FratIncident = inject(FRAT_INCIDENT_CELL_INJECTION_TOKEN);
}
