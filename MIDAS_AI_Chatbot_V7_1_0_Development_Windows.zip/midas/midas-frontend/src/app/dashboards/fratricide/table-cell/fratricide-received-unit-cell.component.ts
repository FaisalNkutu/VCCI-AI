/*
 * Copyright 2026 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

import {Component, inject} from "@angular/core";
import {FratIncident} from "@/models";
import {NameAndMilSymbolCellComponent} from "@/components/table-cell/name-and-mil-symbol-cell.component";
import {FRAT_INCIDENT_CELL_INJECTION_TOKEN} from "@/dashboards/fratricide/injector/fratricide-incident.injector";

@Component({
  selector: 'fratricide-receiving-unit-cell',
  imports: [NameAndMilSymbolCellComponent],
  template: `
    <name-and-mil-symbol-cell
      [name]="fratIncidentToken.receivingEntityName"
      [milSymbol]="fratIncidentToken.receivingEntityMilSym"
    />`
})
export class FratricideReceivingUnitCellComponent {
  public fratIncidentToken: FratIncident = inject(FRAT_INCIDENT_CELL_INJECTION_TOKEN);
}
