import { Component, OnInit } from '@angular/core';
import { FratricideDashComponent } from '@/dashboards/fratricide/fratricide-dash.component';
import { Store } from '@ngrx/store';
import { fratricideActions } from '@/store/actions/fratricide.actions';
import {
  selectTimeframe,
  selectFratGraphData,
  selectFratIncidents,
} from '@/store/features/fratricide.feature';
import { AsyncPipe } from '@angular/common';
import { sidebarActions } from '@/store/actions/sidebar.actions';

@Component({
  selector: 'fratricide-container',
  imports: [FratricideDashComponent, AsyncPipe],
  template: `
    <fratricide-dash
      [timeframe]="(timeframe$ | async) || { start: 0, end: 0 }"
      [graphData]="(fratChartData$ | async) || null"
      [fratTableData]="(fratIncidents$ | async) || []"
    />
  `,
})
export class FratricideContainerComponent implements OnInit {
  timeframe$ = this.store.select(selectTimeframe);
  fratChartData$ = this.store.select(selectFratGraphData);
  fratIncidents$ = this.store.select(selectFratIncidents);

  constructor(private store: Store) {}

  ngOnInit(): void {
    this.store.dispatch(fratricideActions.getResults());
    this.store.dispatch(sidebarActions.getMapServerURL());
  }
}
