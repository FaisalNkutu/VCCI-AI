import {
  AfterViewInit,
  Component,
  Input,
  OnChanges,
  SimpleChanges,
  viewChild,
} from '@angular/core';
import { FratIncident } from '@/models';
import { GisMapHostComponent } from '@/components/gis-map/gis-map-host.component';
import {
  FRATRICIDE_VIEW_ZOOM,
  fratricideToElements,
  fratricideView,
} from '@/components/gis-map/gis-map.elements';

@Component({
  selector: 'fratricide-map',
  imports: [GisMapHostComponent],
  templateUrl: './fratricide-map.component.html',
  styles: `
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
  `,
})
export class FratricideMapComponent implements AfterViewInit, OnChanges {
  @Input()
  fratIncidentDetails: FratIncident[] | undefined;

  private readonly host = viewChild(GisMapHostComponent);
  private viewReady = false;

  ngAfterViewInit(): void {
    this.viewReady = true;
    this.syncIncidents();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (!this.viewReady || !changes['fratIncidentDetails']) return;
    this.syncIncidents();
  }

  private syncIncidents(): void {
    const host = this.host();
    if (!host) return;
    const incidents = this.fratIncidentDetails ?? [];
    host.replaceElements(
      'frat-incidents',
      fratricideToElements(incidents),
      'Fratricide'
    );
    const center = fratricideView(incidents);
    if (center) host.setView(center, FRATRICIDE_VIEW_ZOOM);
  }
}
