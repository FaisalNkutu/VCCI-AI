import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { HHourDashComponent } from './h-hour-dash.component';
import { AsyncPipe } from '@angular/common';
import { hhourActions } from '@/store/actions/h-hour.actions';
import {
  selectHHours,
  selectLODChartData,
  selectSelectedHHour,
  selectAchievedHHour,
  unitSelectorWithFilter,
  selectHHourSelectedUnitIds,
  selectHHourEntityFilters,
} from '@/store/features/h-hour.feature';
import { sidebarActions } from '@/store/actions/sidebar.actions';

@Component({
  selector: 'h-hour-container',
  imports: [HHourDashComponent, AsyncPipe],
  template: `
    <h-hour-dash
      [units]="(unitsWithFilter$ | async) || []"
      [hhourData]="(hHourData$ | async) || []"
      [selectedHHour]="selectedHHour$ | async"
      [selectedUnitIds]="(selectedUnitIds$ | async) || []"
      [achievedHHour]="(achievedHHour$ | async) || 0"
      [lodChartData]="(lodChartData$ | async) || null"
      [entityFilters]="(entityFilters$ | async) || []"
    />
  `,
})

/**
 * A container to feed the h-hour dashboard with data
 */
export class HHourContainerComponent implements OnInit {
  unitsWithFilter$ = this.store.select(unitSelectorWithFilter);
  hHourData$ = this.store.select(selectHHours);
  selectedHHour$ = this.store.select(selectSelectedHHour);
  achievedHHour$ = this.store.select(selectAchievedHHour);
  lodChartData$ = this.store.select(selectLODChartData);
  selectedUnitIds$ = this.store.select(selectHHourSelectedUnitIds);
  entityFilters$ = this.store.select(selectHHourEntityFilters);

  constructor(private store: Store) {
    this.store.dispatch(sidebarActions.getMapServerURL());
  }

  ngOnInit(): void {
    this.store.dispatch(hhourActions.getHHourData());
  }
}
