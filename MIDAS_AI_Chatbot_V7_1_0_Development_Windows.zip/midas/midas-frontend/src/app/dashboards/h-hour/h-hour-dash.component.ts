import {
  ChartComponent as ChartV2Component,
  SimChartData,
} from '@/chart-v2/chart-v2.component';
import {
  EntitySelectorComponent,
  FilterStatus,
} from '@/components/entity-selector/entity-selector.component';
import { GisMapComponent } from '@/components/map/map.component';
import { ResizablePanelComponent } from '@/components/resizable-panel/resizable-panel.component';
import { HHourSpecs, HHourUnitDataGrouping, Unit } from '@/models';
import { hhourActions } from '@/store/actions/h-hour.actions';

import {
  Component,
  computed,
  input,
  Input,
  OnChanges,
  OnInit,
  signal,
  SimpleChanges,
} from '@angular/core';
import {
  FormControl,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIcon } from '@angular/material/icon';
import { MatInput } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltip } from '@angular/material/tooltip';
import { MatButtonToggle, MatButtonToggleGroup } from "@angular/material/button-toggle";
import { Store } from '@ngrx/store';
import { SFTreeMetaData } from '@simfront/common-libs';
import { debounceTime, distinctUntilChanged, filter, map } from 'rxjs';


@Component({
  selector: 'h-hour-dash',
  imports: [
    FormsModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInput,
    ReactiveFormsModule,
    ChartV2Component,
    GisMapComponent,
    MatCardModule,
    ResizablePanelComponent,
    MatIcon,
    MatTooltip,
    EntitySelectorComponent,
    MatButtonToggleGroup,
    MatButtonToggle
],
  templateUrl: './h-hour-dash.component.html',
})
export class HHourDashComponent implements OnChanges, OnInit {
  units = input<Unit[]>([]);
  @Input() hhourData: HHourSpecs[] = [];
  @Input() selectedHHour: HHourSpecs | null = null;
  @Input() achievedHHour: number = 0;
  @Input() selectedUnitIds: number[] = [];
  @Input() lodChartData: SimChartData<'line'> | null = null;
  @Input() entityFilters: FilterStatus[] = [];
  thresholdControl: FormControl;
  isResizablePanelVisible: boolean = false;
  dataGroupView : HHourUnitDataGrouping = "crossed";

  friendlyUnitFilter = signal<'all' | 'friendly' | 'hostile'>('all');

  allFilteredUnits = computed<Unit[]>(() => {
    const filter = this.friendlyUnitFilter();
    return this.units().filter((unit) => {
      if (filter === 'friendly') return unit.isFriendly;
      if (filter === 'hostile') return !unit.isFriendly;
      return true;
    });
  });

  crossedFilteredUnits = computed<Unit[]>(() => {
    const threshold : number = this.thresholdControl.value
    return this.allFilteredUnits().filter((unit) => {
      return Math.abs(unit.deviation) <= threshold;
    })
  });

  metaData: SFTreeMetaData<Unit, string> = {
    controlTrackBy: (n) => `${n.id}`,
    children: (n) => n.children,
    childrenProp: 'children',
    label: (n) => n.name,
  };

  constructor(private store: Store) {
    this.thresholdControl = new FormControl(0, [
      Validators.min(this.selectedHHour?.threshold ?? -1),
      Validators.max(this.selectedHHour?.threshold ?? 100),
    ]);
  }

  onClearFilters(): void {
    this.friendlyUnitFilter.set('all');
  }

  ngOnInit() {
    this.thresholdControl.valueChanges
      .pipe(
        debounceTime(500),
        distinctUntilChanged(),
        filter((val) => val && this.thresholdControl.valid),
        map((threshold) =>
          this.store.dispatch(
            hhourActions.thresholdChanged({
              threshold: threshold,
              hHour: this.selectedHHour as HHourSpecs,
              entityIds: this.selectedUnitIds
            })
          )
        )
      )
      .subscribe();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (this.selectedHHour) {
      this.thresholdControl.setValidators([
        Validators.min(this.selectedHHour.threshold * -1),
        Validators.max(this.selectedHHour.threshold),
      ]);

      // Only set the value when selectedHHour actually changes (not on other input changes)
      if (changes['selectedHHour']) {
        this.thresholdControl.setValue(this.selectedHHour.threshold);
      }
    }
  }

  onUnitSelectionChange(event: { items: Unit[]; selected: boolean }): void {
    if (!event.items || event.items.length === 0) {
      console.log('Could not get unit from selection');
      return;
    }

    this.store.dispatch(
      hhourActions.batchUnitSelection({
        unitIds: event.items.map((u) => u.id),
        selection: event.selected,
      })
    );
  }

  trackBy(index: number, item: Unit): string {
    return item.id.toString();
  }

  toggleResizablePanel(): void {
    this.isResizablePanelVisible = !this.isResizablePanelVisible;
  }

  onHHourChange(): void {
    this.store.dispatch(
      hhourActions.hHourSelection({ hHour: this.selectedHHour as HHourSpecs })
    );
  }

  onEntityFilterChange(filters: FilterStatus[]): void {
    this.store.dispatch(hhourActions.entityFilterChange(filters));
  }

  onGroupViewChange(dataGroupView: HHourUnitDataGrouping): void {
    this.dataGroupView = dataGroupView;
  }

}
