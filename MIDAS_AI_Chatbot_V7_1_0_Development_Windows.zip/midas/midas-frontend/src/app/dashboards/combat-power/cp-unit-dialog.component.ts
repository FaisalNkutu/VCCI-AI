import {
  ChartDialogColumn,
  ChartDialogComponent,
} from '@/components/dialog/chart-dialog/chart-dialog.component';
import { CombatPowerPoint, EquipmentHolding } from '@/models';
import { selectCombatPowerTableData } from '@/store/features/cp.feature';
import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';

@Component({
  selector: 'combat-power-table-dialog',
  imports: [ChartDialogComponent],
  template: `<chart-dialog
    dialogTitle="Combat Power Details"
    [subTitle]="combatPower + '%'"
    subTitleDescription="Combat Power"
    [time]="data.formattedTime"
    [data]="dataSource"
    [columns]="columns"
  /> `,
})
export class CPUnitDialog implements OnInit, OnDestroy {
  columns: ChartDialogColumn<EquipmentHolding>[] = [
    {
      header: 'Equipment Type',
      cell: (e) => e.jEquipmentTypeCatCode,
    },
    {
      header: 'Equipment Name',
      cell: (e) => e.jEquipmentTypeName,
    },
    {
      header: 'Original Quantity',
      cell: (e) => e.jOriginalQty,
    },
    {
      header: 'Current Quantity',
      cell: (e) => e.jCurrentQty,
    },
    {
      header: 'Reference Quantity',
      cell: (e) => e.jReferenceQty,
    },
  ];
  subscription: Subscription = new Subscription();
  dataSource: EquipmentHolding[] = [];
  combatPower: number = 0;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: CombatPowerPoint,
    private store: Store
  ) {}

  ngOnInit(): void {
    this.subscription = this.store
      .select(selectCombatPowerTableData)
      .subscribe((data) => {
        if (data) {
          this.dataSource = data.jHoldings;
          this.combatPower = data.combatpower;
        }
      });
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
