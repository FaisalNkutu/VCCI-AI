import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import {
  selectCombatPowerDataGrouping,
  selectCpChartData,
  selectCpEntities,
  selectCpEntityFilters,
  selectCpEquipmentChartData,
  selectCpSelectedEntityIds,
  selectCpTimeframe,
  selectExcludeZeroToHundred,
} from '@/store/features/cp.feature';
import { CpDashComponent } from './cp-dash.component';
import { AsyncPipe } from '@angular/common';
import { cpActions } from '@/store/actions/cp.actions';
@Component({
  selector: 'app-cp-container',
  imports: [CpDashComponent, AsyncPipe],
  template: `
    <cp-dash
      [entities]="(entities$ | async) || []"
      [selectedEntityIds]="(selectedEntityIds$ | async) || []"
      [timeframe]="(timeframe$ | async) || { start: 0, end: 0 }"
      [entityDetailsChartData]="(entityDetailsChartData$ | async) || null"
      [equipmentDetailsChartData]="(equipmentDetailsChartData$ | async) || null"
      [entityFilters]="(entityFilters$ | async) || []"
      [excludeZeroToHundred]="(excludeZeroToHundred$ | async) || false"
      [dataGrouping]="(dataGrouping$ | async) || 'unit'"
    />
  `,
})
export class CpContainerComponent implements OnInit {
  entities$ = this.store.select(selectCpEntities);
  selectedEntityIds$ = this.store.select(selectCpSelectedEntityIds);
  timeframe$ = this.store.select(selectCpTimeframe);
  entityDetailsChartData$ = this.store.select(selectCpChartData);
  equipmentDetailsChartData$ = this.store.select(selectCpEquipmentChartData);
  entityFilters$ = this.store.select(selectCpEntityFilters);
  excludeZeroToHundred$ = this.store.select(selectExcludeZeroToHundred);
  dataGrouping$ = this.store.select(selectCombatPowerDataGrouping);

  constructor(private store: Store) {}
  ngOnInit(): void {
    this.store.dispatch(cpActions.getEntities());
  }
}
