import {
  ChartDialogColumn,
  ChartDialogComponent,
} from '@/components/dialog/chart-dialog/chart-dialog.component';
import { CombatPowerEquipmentTableData } from '@/models';
import { selectCombatPowerEquipmentTableData } from '@/store/features/cp.feature';
import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';

interface CombatPowerEquipmentData {
  time: string;
  equipmentType: string;
}

@Component({
  selector: 'combat-power-equipment-table-dialog',
  imports: [ChartDialogComponent],
  template: `<chart-dialog
    dialogTitle="Combat Power Equipment Breakdown"
    [subTitle]="data.equipmentType"
    subTitleDescription="Equipment Type"
    [time]="data.formattedTime"
    [data]="dataSource"
    [columns]="columns"
  /> `,
})
export class CPEquipmentDialog implements OnInit, OnDestroy {
  columns: ChartDialogColumn<CombatPowerEquipmentTableData>[] = [
    {
      header: 'Symbol',
      cell: (e) => e.milSym,
      symbol: true,
    },
    {
      header: 'Entity Name',
      cell: (e) => e.unitName,
    },
    {
      header: 'Original Quantity',
      cell: (e) => e.originalQuantity,
    },
    {
      header: 'Current Quantity',
      cell: (e) => e.currentQuantity,
    },
  ];
  subscription: Subscription = new Subscription();
  dataSource: CombatPowerEquipmentTableData[] = [];
  combatPower: number = 0;

  constructor(
    @Inject(MAT_DIALOG_DATA)
    public data: CombatPowerEquipmentData & CombatPowerEquipmentTableData,
    private store: Store
  ) {}

  ngOnInit(): void {
    this.subscription = this.store
      .select(selectCombatPowerEquipmentTableData)
      .subscribe((data) => {
        if (data) {
          this.dataSource = data;
        }
      });
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
