import {
  ChartComponent as ChartV2Component,
  SimChartData,
} from '@/chart-v2/chart-v2.component';
import {
  EntitySelectorComponent,
  FilterStatus,
} from '@/components/entity-selector/entity-selector.component';
import { GlobalTimeSelectorComponent } from '@/components/time-selector/global-time-selector.component';
import {
  CombatPowerDataGrouping,
  CombatPowerEquipmentPoint,
  CombatPowerPoint,
  SimEntity,
  Timeframe,
} from '@/models';
import { cpActions } from '@/store/actions/cp.actions';
import { AsyncPipe } from '@angular/common';
import { Component, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MatButtonToggle,
  MatButtonToggleGroup,
} from '@angular/material/button-toggle';
import { MatCard, MatCardContent, MatCardHeader } from '@angular/material/card';
import { MatCheckbox } from '@angular/material/checkbox';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatMenuModule } from '@angular/material/menu';
import { MatSliderModule } from '@angular/material/slider';
import { Store } from '@ngrx/store';
import { SFTreeMetaData } from '@simfront/common-libs';
import { CPEquipmentDialog } from './cp-equipment-dialog.component';
import { CPUnitDialog } from './cp-unit-dialog.component';

@Component({
  selector: 'cp-dash',
  standalone: true,
  imports: [
    MatSliderModule,
    MatCard,
    MatCardContent,
    MatCardHeader,
    ChartV2Component,
    MatDialogModule,
    MatButtonModule,
    MatCheckbox,
    FormsModule,
    AsyncPipe,
    MatMenuModule,
    MatButtonToggle,
    MatButtonToggleGroup,
    EntitySelectorComponent,
    GlobalTimeSelectorComponent,
  ],
  templateUrl: './cp-dash.component.html',
})
export class CpDashComponent {
  @Input() entities: SimEntity[] = [];
  @Input() selectedEntityIds: number[] = [];
  @Input() timeframe: Timeframe = { start: 0, end: 0 };
  @Input() entityDetailsChartData: SimChartData<
    'line',
    CombatPowerPoint
  > | null = null;
  @Input() equipmentDetailsChartData: SimChartData<
    'line',
    CombatPowerEquipmentPoint
  > | null = null;
  @Input() entityFilters: FilterStatus[] = [];
  @Input() dataGrouping: CombatPowerDataGrouping = 'unit';
  @Input() excludeZeroToHundred: boolean = false;

  metaData: SFTreeMetaData<SimEntity, string> = {
    controlTrackBy: (n) => `${n.id}`,
    children: (n) => n.children,
    childrenProp: 'children',
    label: (n) => n.name,
  };

  constructor(private store: Store, private dialog: MatDialog) {}

  trackBy(index: number, item: SimEntity): string {
    return item.id.toString();
  }

  onEntitySelectionChange(event: { items: SimEntity[]; selected: boolean }) {
    const entities: SimEntity[] = event.items;
    const selected = event.selected;

    this.store.dispatch(
      cpActions.batchEntitySelection({
        entityIds: entities.map((e) => e.id),
        selected,
      })
    );
  }

  onTimeframeChange(tf: Timeframe) {
    this.store.dispatch(cpActions.timeframeChange(tf));
  }

  onChartClicked(event: any) {
    if (
      event.active &&
      event.active.length > 0 &&
      this.entityDetailsChartData
    ) {
      const pointData = event.active[0].element.$context
        .raw as CombatPowerPoint;

      this.store.dispatch(
        cpActions.combatPowerPointSelected({
          entityId: parseInt(pointData.id!),
          time: pointData.time,
        })
      );
      this.dialog.open(CPUnitDialog, {
        data: {
          ...pointData,
        },
      });
    }
  }

  onEqChartClicked(event: any) {
    if (
      event.active &&
      event.active.length > 0 &&
      this.entityDetailsChartData
    ) {
      const pointData = event.active[0].element.$context
        .raw as CombatPowerEquipmentPoint;
      console.log('POINT DATA', pointData);

      this.store.dispatch(
        cpActions.combatPowerEquipmentPointSelected({
          equipmentType: pointData.equipmentType,
          time: pointData.time,
        })
      );
      this.dialog.open(CPEquipmentDialog, {
        data: {
          ...pointData,
        },
      });
    }
  }

  onDynamicChartClicked(event: any) {
    if (this.dataGrouping === 'unit') {
      this.onChartClicked(event);
    } else if (this.dataGrouping === 'equipment') {
      this.onEqChartClicked(event);
    }
  }

  onClearFilters(): void {
    this.onExcludeAllChange(false);
  }

  onExcludeAllChange(checked: boolean): void {
    this.store.dispatch(cpActions.includeAllChanged(checked));
  }

  onGroupingChange(filter: CombatPowerDataGrouping): void {
    this.store.dispatch(cpActions.dataGroupingChanged(filter));
  }

  onEntityFilterChange(filters: FilterStatus[]): void {
    this.store.dispatch(cpActions.entityFilterChange(filters));
  }
}
