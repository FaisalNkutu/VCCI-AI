import { EntitySelectorComponent, FilterStatus } from '@/components/entity-selector/entity-selector.component';
import { FeedEntryComponent } from '@/components/feed-entry/feed-entry.component';
import { SimEntity, UnitWatchUpdate, UpdateCategory } from '@/models';
import { unitWatchActions } from '@/store/actions/unit-watch.actions';
import { selectFilteredUnitWatchEvents } from '@/store/features/unit-watch.feature';
import {
  CdkFixedSizeVirtualScroll,
  CdkVirtualForOf,
  CdkVirtualScrollViewport,
} from '@angular/cdk/scrolling';
import { AsyncPipe } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCard, MatCardContent, MatCardHeader } from '@angular/material/card';
import { MatCheckbox } from '@angular/material/checkbox';
import { MatIcon } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { Store } from '@ngrx/store';
import { SFTreeMetaData } from '@simfront/common-libs';

@Component({
  selector: 'unit-watch-dash',
  standalone: true,
  imports: [
    AsyncPipe,
    MatCard,
    CdkFixedSizeVirtualScroll,
    CdkVirtualForOf,
    CdkVirtualScrollViewport,
    MatCardHeader,
    EntitySelectorComponent,
    FeedEntryComponent,
    MatCardContent,
    MatIcon,
    MatMenuModule,
    MatButtonModule,
    MatCheckbox
],
  templateUrl: './unit-watch-dash.component.html',
})
export class UnitWatchDashComponent implements OnInit {
  metaData: SFTreeMetaData<SimEntity, string> = {
    controlTrackBy: (n) => `${n.id}`,
    children: (n) => n.children,
    childrenProp: 'children',
    label: (n) => n.name,
  };

  @Input() unitWatchEvents: UnitWatchUpdate[] = [];
  @Input() entities: SimEntity[] = [];
  @Input() selectedEntityIds: number[] = [];
  @Input() selectedCategories: UpdateCategory[] = [];
  @Input() entityFilters: FilterStatus[] = [];

  filteredUnitWatchEvents$ = this.store.select(selectFilteredUnitWatchEvents);
  availableCategories: UpdateCategory[] = [
    'ACT',
    'FRAT',
    'CPOWER',
    'HHOUR',
    'ENGAGE',
    'HOLDING',
    'NOS',
  ];

  constructor(private store: Store) {}

  ngOnInit(): void {
    // Initialize component
  }

  onEntitySelectionChange(event: { items: SimEntity[]; selected: boolean }) {
    const entities: SimEntity[] = event.items;
    const selected = event.selected;
    console.log("Entity selection changed:", event);
    unitWatchActions.batchUnitSelection({
      unitIds: entities.map((e) => e.id),
      selection: selected,
    });
  }

  onClearUnitWatchEvents() {
    this.store.dispatch(unitWatchActions.clearUnitWatchEvents());
  }

  onEntityFilterChange(filters: FilterStatus[]) {
    this.store.dispatch(unitWatchActions.entityFilterChange(filters));
  }

  trackBy(index: number, entry: UnitWatchUpdate) {
    return entry.entityId;
  }

  toggleCategoryFilter(category: UpdateCategory) {
    if (this.selectedCategories.includes(category)) {
      this.store.dispatch(
        unitWatchActions.setCategoryFilterDeselected(category)
      );
    } else {
      this.store.dispatch(unitWatchActions.setCategoryFilterSelected(category));
    }
  }

  isCategorySelected(category: string, selectedCategories: string[]): boolean {
    return selectedCategories.includes(category);
  }
}
