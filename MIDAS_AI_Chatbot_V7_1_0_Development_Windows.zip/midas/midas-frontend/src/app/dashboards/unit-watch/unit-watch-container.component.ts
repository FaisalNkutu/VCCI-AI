import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { AsyncPipe } from '@angular/common';
import { UnitWatchDashComponent } from './unit-watch-dash.component';
import {
  selectFilteredUnitWatchEvents,
  selectSelectedUnitWatchEntities,
  selectUnitWatchEntities,
  selectSelectedCategories,
  selectSelectedUnitWatchIds,
  selectUnitWatchEntityFilters,
} from '@/store/features/unit-watch.feature';
import { unitWatchActions } from '@/store/actions/unit-watch.actions';

@Component({
  selector: 'unit-watch-container',
  standalone: true,
  imports: [UnitWatchDashComponent, AsyncPipe],
  template: `
    <unit-watch-dash
      [unitWatchEvents]="(unitWatchEvents$ | async) || []"
      [entities]="(entities$ | async) || []"
      [selectedEntityIds]="(selectedIds$ | async) || []"
      [selectedCategories]="(selectedCategories$ | async) || []"
      [entityFilters]="(entityFilters$ | async) || []"
    />
  `,
})

/**
 * A container to feed the unit watch dashboard with data
 */
export class UnitWatchContainerComponent implements OnInit {
  unitWatchEvents$ = this.store.select(selectFilteredUnitWatchEvents);
  selectedCategories$ = this.store.select(selectSelectedCategories);
  entities$ = this.store.select(selectUnitWatchEntities);
  selectedEntities$ = this.store.select(selectSelectedUnitWatchEntities);
  selectedIds$ = this.store.select(selectSelectedUnitWatchIds);
  entityFilters$ = this.store.select(selectUnitWatchEntityFilters);

  constructor(private store: Store) {
    this.store.dispatch(unitWatchActions.getUnits());
  }

  ngOnInit(): void {
    // Unit Watch data will be implemented when needed
  }
}
