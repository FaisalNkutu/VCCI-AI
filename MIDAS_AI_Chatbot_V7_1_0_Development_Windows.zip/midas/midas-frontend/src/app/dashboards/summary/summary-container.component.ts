import { Component, OnDestroy, OnInit } from '@angular/core';
import { SummaryDashComponent } from './summary-dash.component';
import { map, Subscription } from 'rxjs';
import { SseService } from '@/services/sse.service';
import { Store } from '@ngrx/store';
import { SummaryState } from '@/models/summary.model';
import { API_URL } from '@/app.config';
import { summaryActions } from '@/store/actions/summary.actions';
import {
  initialState,
  selectSummaryState,
} from '@/store/features/summary.feature';
import { AsyncPipe } from '@angular/common';
import { selectStatusData } from '@/store/features/sidebar.feature';

@Component({
  selector: 'summary-container',
  imports: [SummaryDashComponent, AsyncPipe],
  template: `
    <summary-dash
      [summaryData]="(summaryData$ | async) || initialState"
      [statusData]="(statusData$ | async) || []"
    />
  `,
})
export class SummaryContainerComponent implements OnInit, OnDestroy {
  private sseSubscription?: Subscription;

  initialState = initialState;

  summaryData$ = this.store.select(selectSummaryState);
  statusData$ = this.store.select(selectStatusData).pipe(
    map((data) => {
      return [
        {
          name: 'H-Hour',
          active: data?.jHHourActive ?? false,
          reason: data?.jHHourReason || '',
        },
        {
          name: 'Rate of Movement',
          active: data?.jROMActive ?? false,
          reason: data?.jROMReason || '',
        },
        {
          name: 'Control Measure Occupations',
          active: data?.jCMOccupationsActive ?? false,
          reason: data?.jCMOccsReason || '',
        },
        {
          name: 'Picture of Enemy',
          active: data?.jPOEActive ?? false,
          reason: data?.jPOEReason || '',
        },
        {
          name: 'Fratricide',
          active: data?.jFratricideActive ?? false,
          reason: '',
        },
        {
          name: 'Enemy Engagements',
          active: data?.jEnemyEngagementsActive ?? false,
          reason: data?.jEneEngReason || '',
        },
        {
          name: 'Combat Power',
          active: data?.jCPowerActive ?? false,
          reason: '',
        },
        {
          name: 'Entity Watch',
          active: data?.jEntityWatchActive ?? false,
          reason: data?.jEntWatchReason || '',
        },
      ];
    })
  );

  constructor(private store: Store, private sseService: SseService) {}


  /*
 * SSE dashboard stability and debugging improvements
 *
 * Previously the dashboard subscribed to the SSE stream using a simple
 * `.subscribe()` callback that assumed every message contained a valid
 * summary payload. If malformed data was received or the stream produced
 * an unexpected event, it could result in invalid store updates or silent
 * failures that were difficult to debug.
 *
 * Changes introduced here:
 *
 * 1. Structured SSE subscription (next / error / complete)
 *    The SSE stream now explicitly handles lifecycle events so we can
 *    detect stream errors or closures instead of failing silently.
 *
 * 2. Defensive payload validation
 *    Before dispatching data to the NgRx store we verify that the
 *    received SSE message contains a valid `summary` object.
 *    This prevents corrupted or partial SSE messages from updating
 *    the dashboard state.
 *
 * 3. Debug logging for SSE lifecycle
 *    Added logs for:
 *      - opening the SSE connection
 *      - receiving SSE events
 *      - SSE errors
 *      - SSE stream closure
 *      - NgRx store updates
 *
 * This logging makes it easier to diagnose issues where the dashboard
 * stops updating or receives unexpected SSE payloads.
 *
 * Result:
 * - SSE connection behaviour is observable and easier to debug.
 * - Invalid SSE payloads no longer propagate into the store.
 * - Dashboard summary updates remain stable.
 */
  ngOnInit(): void {

    console.log("[SUMMARY] Opening SSE connection");

    this.sseSubscription = this.sseService
      .getServerSentEvents<{ summary: SummaryState; time: number }>(
        `${API_URL}/advmetrics/summary/stream`
      )
      .subscribe({
        next: (summaryData) => {

          console.log("[SUMMARY] Event received from SSE:", summaryData);

          if (summaryData && summaryData.summary) {
            this.store.dispatch(
              summaryActions.dataReceived(summaryData.summary)
            );
          }

        },
        error: (err) => {
          console.error("[SUMMARY] SSE error:", err);
        },
        complete: () => {
          console.warn("[SUMMARY] SSE stream closed");
        }
      });

    this.summaryData$.subscribe(data => {
      console.log("[SUMMARY STORE] Updated state:", data);
    });
  }

  ngOnDestroy(): void {
    this.sseSubscription?.unsubscribe();
  }
}
