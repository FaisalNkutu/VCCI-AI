import { SummaryState } from '@/models/summary.model';
import { routes } from '@/utils/routes';
import { CommonModule } from '@angular/common';
import { AfterViewInit, Component, ElementRef, NgZone, OnDestroy, computed, input, signal } from '@angular/core';
import { MatBadgeModule } from '@angular/material/badge';
import { MatCardModule } from '@angular/material/card';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatTooltipModule } from '@angular/material/tooltip';
import { RouterLink } from '@angular/router';

interface ProcessorStatus {
  name: string;
  active: boolean;
  reason: string;
}

@Component({
  selector: 'summary-dash',
  imports: [
    MatGridListModule,
    MatCardModule,
    MatListModule,
    CommonModule,
    MatIconModule,
    MatTooltipModule,
    RouterLink,
    MatBadgeModule,
  ],
  templateUrl: './summary-dash.component.html',
  styles: [`
    :host { display:block; width:100%; min-width:0; }
    .summary-dashboard { box-sizing:border-box; width:100%; min-width:0; padding:4px; }
    .summary-dashboard .summary-card { box-sizing:border-box; min-width:0; overflow:hidden; border-radius:11px; }
    .summary-dashboard mat-card-header { min-width:0; padding:0 0 5px; }
    .summary-dashboard mat-card-title { font-size:16px; line-height:1.25; font-weight:650;
      letter-spacing:-.1px; overflow-wrap:anywhere; }
    .summary-processor-title { font-size:clamp(21px, 2vw, 28px); line-height:1.15;
      letter-spacing:-.5px; overflow-wrap:break-word; margin:0 0 5px; }
    .summary-dashboard mat-card-content { min-height:0; }
    .summary-dashboard .mat-mdc-list-item { height:auto!important; }
    .summary-dashboard p { margin-bottom:3px; }
    .summary-dashboard a mat-icon { font-size:19px; width:20px; height:20px; }
  `],
})
export class SummaryDashComponent implements AfterViewInit, OnDestroy {
  summaryData = input.required<SummaryState>();
  statusData = input.required<ProcessorStatus[]>();

  activeCount = computed(() => this.statusData().filter((p) => p.active && !p.reason).length);
  warningCount = computed(() => this.statusData().filter((p) => p.active && p.reason).length);
  inactiveCount = computed(() => this.statusData().filter((p) => !p.active).length);

  routes = routes;
  // Read the ACTUAL Summary host width, not browser viewport width. The AI
  // Chatbot side panel can narrow MIDAS while the browser remains wide.
  readonly gridColumns = signal(5);
  private resizeObserver?: ResizeObserver;

  constructor(private readonly element: ElementRef<HTMLElement>, private readonly zone: NgZone) {}

  ngAfterViewInit(): void {
    const updateColumns = (width: number) => {
      const columns = width < 480 ? 2 : width < 700 ? 3 : width < 1000 ? 4 : 5;
      if (this.gridColumns() !== columns) {
        this.zone.run(() => this.gridColumns.set(columns));
      }
    };
    updateColumns(this.element.nativeElement.getBoundingClientRect().width);
    if (typeof ResizeObserver !== 'undefined') {
      this.resizeObserver = new ResizeObserver((entries) => {
        const width = entries[0]?.contentRect.width;
        if (typeof width === 'number') updateColumns(width);
      });
      this.resizeObserver.observe(this.element.nativeElement);
    }
  }

  ngOnDestroy(): void {
    this.resizeObserver?.disconnect();
  }
}
