import {
  ChartDialogColumn,
  ChartDialogComponent,
} from '@/components/dialog/chart-dialog/chart-dialog.component';
import {
  EnemyEngagementControlMeasure,
  EnemyEngagementPoint,
  EnemyEngagementUnit,
} from '@/models';
import { selectEnemyEngagementEntities } from '@/store/features/enemy-engagement.feature';
import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';

@Component({
  selector: 'ee-table-dialog',
  imports: [ChartDialogComponent],
  template: `<chart-dialog
    dialogTitle="Engaged Entities"
    [subTitle]="data.cmname"
    subTitleDescription="Control Measure Name"
    [time]="data.formattedTime"
    [data]="dataSource"
    [columns]="columns"
  /> `,
})
export class EETableDialog implements OnInit, OnDestroy {
  columns: ChartDialogColumn<EnemyEngagementUnit>[] = [
    {
      header: 'Symbol',
      cell: (e) => e.milSym,
      symbol: true,
    },
    {
      header: 'Name',
      cell: (e) => e.name,
    },
  ];
  subscription: Subscription = new Subscription();
  dataSource: EnemyEngagementUnit[] = [];

  entityDetails$ = this.store.select(selectEnemyEngagementEntities);

  ngOnInit() {
    this.subscription.add(
      this.entityDetails$.subscribe((data) => {
        this.dataSource = data;
      })
    );
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  constructor(
    @Inject(MAT_DIALOG_DATA)
    public data: EnemyEngagementControlMeasure & EnemyEngagementPoint,
    private store: Store
  ) {}
}
