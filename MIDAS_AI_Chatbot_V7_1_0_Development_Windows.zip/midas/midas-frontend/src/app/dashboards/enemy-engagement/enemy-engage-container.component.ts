import { Component } from '@angular/core';
import { EnemyEngageDashComponent } from '@/dashboards/enemy-engagement/enemy-engage-dash.component';
import { Store } from '@ngrx/store';
import {
  selectBlueChartData,
  selectBlueTimeframe,
  selectControlMeasures,
  selectRedChartData,
  selectRedTimeframe,
  selectSelectedBlueControlMeasure,
  selectSelectedRedControlMeasure,
} from '@/store/features/enemy-engagement.feature';
import { enemyEngagementActions } from '@/store/actions/enemy-engagment.actions';
import { AsyncPipe } from '@angular/common';

@Component({
  selector: 'enemy-engage-container',
  imports: [EnemyEngageDashComponent, AsyncPipe],
  template: `
    <enemy-engage-dash
      [selectedBlueControlMeasure]="
        (selectedBlueControlMeasure$ | async) || { id: -1, cmname: '', isFriendly: true }
      "
      [selectedRedControlMeasure]="
        (selectedRedControlMeasure$ | async) || { id: -1, cmname: '', isFriendly: false }
      "
      [controlMeasures]="(controlMeasures$ | async) || []"
      [redChartData]="(redChartData$ | async) || null"
      [redTimeframe]="(redTimeframe$ | async) || { start: 0, end: 0 }"
      [blueTimeframe]="(blueTimeframe$ | async) || { start: 0, end: 0 }"
      [blueChartData]="(blueChartData$ | async) || null"
    />
  `,
})
export class EnemyEngageContainerComponent {
  redTimeframe$ = this.store.select(selectRedTimeframe);
  blueTimeframe$ = this.store.select(selectBlueTimeframe);
  controlMeasures$ = this.store.select(selectControlMeasures);
  redChartData$ = this.store.select(selectRedChartData);
  blueChartData$ = this.store.select(selectBlueChartData);
  selectedBlueControlMeasure$ = this.store.select(
    selectSelectedBlueControlMeasure
  );
  selectedRedControlMeasure$ = this.store.select(
    selectSelectedRedControlMeasure
  );

  constructor(private store: Store) {
    this.store.dispatch(enemyEngagementActions.getControlMeasures());
  }
}
