import { ChartComponent, SimChartData } from '@/chart-v2/chart-v2.component';
import { ChartComponent as ChartComponentV3 } from '@/chart-v3/chart-v3.component';
import { GlobalTimeSelectorComponent } from '@/components/time-selector/global-time-selector.component';
import {
  EnemyEngagementControlMeasure,
  EnemyEngagementPoint,
  Timeframe,
} from '@/models';
import { enemyEngagementActions } from '@/store/actions/enemy-engagment.actions';
import {
  CdkFixedSizeVirtualScroll,
  CdkVirtualForOf,
  CdkVirtualScrollViewport,
} from '@angular/cdk/scrolling';
import { Component, computed, input, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatDialog } from '@angular/material/dialog';
import { MatIcon } from '@angular/material/icon';
import {
  MatListOption,
  MatSelectionList,
  MatSelectionListChange,
} from '@angular/material/list';
import { Store } from '@ngrx/store';
import { EETableDialog } from './ee-table-dialog.component';

@Component({
  selector: 'enemy-engage-dash',
  imports: [
    MatCardModule,
    MatSelectionList,
    CdkVirtualScrollViewport,
    MatListOption,
    CdkVirtualForOf,
    CdkFixedSizeVirtualScroll,
    FormsModule,
    ChartComponent,
    MatIcon,
    GlobalTimeSelectorComponent,
    ChartComponentV3,
  ],
  templateUrl: './enemy-engage-dash.component.html',
})
export class EnemyEngageDashComponent {
  controlMeasures = input<EnemyEngagementControlMeasure[]>([]);
  @Input() redChartData: SimChartData<'line'> | null = null;
  @Input() blueChartData: SimChartData<'line'> | null = null;
  @Input() redTimeframe!: Timeframe;
  @Input() blueTimeframe!: Timeframe;
  @Input() selectedBlueControlMeasure!: EnemyEngagementControlMeasure;
  @Input() selectedRedControlMeasure!: EnemyEngagementControlMeasure;

  adaptor = (data: any) => {
    return {
      xValue: data.time,
      yValue: data.value,
      label: data.label,
    };
  };

  blueControlMeasures = computed(() =>
    this.controlMeasures().filter((cm) => cm.isFriendly)
  );
  redControlMeasures = computed(() =>
    this.controlMeasures().filter((cm) => !cm.isFriendly)
  );

  constructor(private store: Store, private dialog: MatDialog) {}

  //isBlue is true if the chart is blue, false if it is red
  onChartClick(event: any, isBlue: boolean): void {
    if (!event.active || event.active.length === 0) {
      console.log('No active elements found');
      return;
    }
    console.log('Chart click event:', event);
    //if the index is 0, then the point is engaged, otherwise it is not
    const pointData = event.active[0].element.$context
      .raw as EnemyEngagementPoint;
    const index = event.active[0].index;
    const datasetIndex = event.active[0].datasetIndex;
    const selectedCM = isBlue
      ? this.selectedBlueControlMeasure
      : this.selectedRedControlMeasure;

    this.store.dispatch(
      enemyEngagementActions.chartPointSelected({
        isBlue,
        index,
        datasetIndex,
        isEngaged: datasetIndex === 0,
        cmID: selectedCM ? selectedCM.id : -1,
      })
    );

    this.dialog.open(EETableDialog, {
      data: {
        ...selectedCM,
        ...pointData,
      },
    });
  }

  onCMSelectionChange(event: MatSelectionListChange): void {
    const cmId: number = event.options[0].value;
    const cm = this.controlMeasures().find((cm) => cm.id === cmId);
    if (!cm) {
      console.log('Could not get cm from selection list');
      return;
    }
    if (cm.isFriendly) {
      this.store.dispatch(
        enemyEngagementActions.blueControlMeasureSelected(cm)
      );
    } else {
      this.store.dispatch(enemyEngagementActions.redControlMeasureSelected(cm));
    }
  }

  onBlueTimeframeChange(tf: Timeframe) {
    this.store.dispatch(enemyEngagementActions.blueTimeframeChanged(tf));
  }

  onRedTimeframeChange(tf: Timeframe) {
    this.store.dispatch(enemyEngagementActions.redTimeframeChanged(tf));
  }

  trackBy(index: number, cm: EnemyEngagementControlMeasure): number {
    return cm.id;
  }
}
