import {
  ChartDialogColumn,
  ChartDialogComponent,
} from '@/components/dialog/chart-dialog/chart-dialog.component';
import { CMEntity, CmPoint } from '@/models';
import { selectCmTableData } from '@/store/features/cm.feature';
import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';

@Component({
  selector: 'cm-table-dialog',
  template: `<chart-dialog
    dialogTitle="Units Occupying Control Measure"
    [subTitle]="data.controlMeasureName"
    subTitleDescription="Control Measure Name"
    [time]="data.formattedTime"
    [data]="dataSource"
    [columns]="columns"
  /> `,
  imports: [
    ChartDialogComponent,
  ],
})
export class CMTableDialog implements OnInit, OnDestroy {
  columns: ChartDialogColumn<CMEntity>[] = [
    {
      header: 'Symbol',
      cell: (e) => e.milSym,
      symbol: true,
    },
    {
      header: 'Entity Name',
      cell: (e) => e.entityName,
    },
  ];
  subscription: Subscription = new Subscription();
  dataSource: CMEntity[] = [];

  cmTableData$ = this.store.select(selectCmTableData);

  ngOnInit() {
    this.subscription.add(
      this.cmTableData$.subscribe((data) => {
        this.dataSource = data[0].units;
      })
    );
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: CmPoint,
    private store: Store
  ) {}
}
