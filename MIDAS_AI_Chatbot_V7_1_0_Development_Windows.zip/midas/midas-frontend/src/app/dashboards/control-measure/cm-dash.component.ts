import { ChartComponent, SimChartData } from '@/chart-v2/chart-v2.component';
import { EntitySelectorComponent, FilterStatus } from '@/components/entity-selector/entity-selector.component';
import { GlobalTimeSelectorComponent } from '@/components/time-selector/global-time-selector.component';
import {
  VirtualSelectionScrollComponent,
  VirtualSelectionScrollItem,
} from '@/components/virtual-selection-scroll/virtual-selection-scroll.component';
import {
  CmPoint,
  ControlMeasure,
  ControlMeasureTableRow,
  SimEntity,
  Timeframe,
} from '@/models';
import { cmActions } from '@/store/actions/cm.actions';
import { Component, Input } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCard, MatCardContent, MatCardHeader } from '@angular/material/card';
import { MatDialog } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { SFTreeMetaData } from '@simfront/common-libs';
import { CMTableDialog } from './cm-table-dialog.component';

@Component({
  selector: 'cm-dash',
  imports: [
    MatCard,
    MatCardContent,
    ReactiveFormsModule,
    MatCardHeader,
    ChartComponent,
    VirtualSelectionScrollComponent,
    EntitySelectorComponent,
    GlobalTimeSelectorComponent,
  ],
  templateUrl: './cm-dash.component.html',
})
export class CmDashComponent {
  @Input() controlMeasures!: (ControlMeasure & { name: string })[];
  @Input() entities!: SimEntity[];
  @Input() tableData!: ControlMeasureTableRow[];
  @Input() selectedEntities!: number[];
  @Input() selectedControlMeasureIds!: number[];
  @Input() timeframe!: Timeframe;
  @Input() chartData!: SimChartData<'bar'> | undefined;
  @Input() entityFilters: FilterStatus[] = [];

  metaData: SFTreeMetaData<SimEntity, string> = {
    controlTrackBy: (n) => `${n.id}`,
    children: (n) => n.children,
    childrenProp: 'children',
    label: (n) => n.name,
  };

  constructor(private store: Store, private dialog: MatDialog) {}

  onSliderChange(tf: Timeframe) {
    this.store.dispatch(cmActions.timeframeChange(tf));
  }

  onUnitSelectionChange(event: {
    items: SimEntity[];
    selected: boolean;
  }): void {
    if (!event.items || event.items.length === 0) return;

    const selected = event.selected;
    this.store.dispatch(
      cmActions.batchUnitSelection({
        unitIds: event.items.map((item) => item.id),
        selection: selected,
      })
    );
  }

  onChartClicked(event: any) {
    if (event.active && event.active.length > 0 && this.chartData) {
      const pointData = event.active[0].element.$context.raw as CmPoint;

      this.store.dispatch(
        cmActions.getOccupyingUnits({
          cmId: pointData.controlMeasureId,
          time: pointData.time,
        })
      );

      this.dialog.open(CMTableDialog, {
        data: {
          ...pointData,
        },
      });
    }
  }

  onCMSelectionChange(event: {
    item: VirtualSelectionScrollItem;
    selected: boolean;
  }): void {
    const cm = this.controlMeasures.find((c) => c.id === event.item.id);
    if (!cm) {
      console.log('Could not get cm from selection list');
      return;
    }

    const selected = event.selected;
    this.store.dispatch(
      selected
        ? cmActions.controlMeasureSelected(cm.id)
        : cmActions.controlMeasureDeselected(cm.id)
    );
  }

  onEntityFiltersChange(filters: FilterStatus[]): void {
    this.store.dispatch(cmActions.entityFilterChange(filters));
  }

  trackBy(index: number, item: any): string {
    return item.id.toString();
  }
}
