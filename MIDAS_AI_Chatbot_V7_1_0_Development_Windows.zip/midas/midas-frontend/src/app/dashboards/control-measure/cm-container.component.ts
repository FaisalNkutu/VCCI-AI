import { Component } from '@angular/core';
import { CmDashComponent } from '@/dashboards/control-measure/cm-dash.component';
import { Store } from '@ngrx/store';
import {
  selectAllCMEntities,
  selectCmChartData,
  selectTimeframe,
  selectSelectedControlMeasureIds,
  selectCMOCWithName,
  selectSelectedIds,
  selectCmEntityFilters,
} from '@/store/features/cm.feature';
import { AsyncPipe } from '@angular/common';
import { cmActions } from '@/store/actions/cm.actions';

@Component({
  selector: 'cm-container',
  imports: [CmDashComponent, AsyncPipe],
  template: `
    <cm-dash
      [entities]="(entities$ | async) || []"
      [controlMeasures]="(controlMeasures$ | async) || []"
      [selectedEntities]="(selectedIds$ | async) || []"
      [selectedControlMeasureIds]="(selectedControlMeasureIds$ | async) || []"
      [chartData]="(cmChartData$ | async) || undefined"
      [timeframe]="(timeframe$ | async) || { start: 0, end: 0 }"
      [entityFilters]="(entityFilters$ | async) || []"
    />
  `,
})
export class CmContainerComponent {
  entities$ = this.store.select(selectAllCMEntities);
  controlMeasures$ = this.store.select(selectCMOCWithName);
  selectedIds$ = this.store.select(selectSelectedIds);
  selectedControlMeasureIds$ = this.store.select(
    selectSelectedControlMeasureIds
  );
  timeframe$ = this.store.select(selectTimeframe);
  cmChartData$ = this.store.select(selectCmChartData);
  entityFilters$ = this.store.select(selectCmEntityFilters);

  constructor(private store: Store) {
    this.store.dispatch(cmActions.getEntities());
    this.store.dispatch(cmActions.getControlMeasures());
  }
}
