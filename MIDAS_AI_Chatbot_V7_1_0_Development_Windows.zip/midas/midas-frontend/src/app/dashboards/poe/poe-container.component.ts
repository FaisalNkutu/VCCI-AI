import { Component, OnInit } from '@angular/core';
import { PoeDashComponent } from '@/dashboards/poe/poe-dash.component';
import { Store } from '@ngrx/store';
import {
  selectBlueChartData,
  selectBlueTimeframe,
  selectPOEControlMeasuresWithNames,
  selectRedChartData,
  selectRedTimeframe,
  selectedPOECmIds,
} from '@/store/features/poe.feature';
import { AsyncPipe } from '@angular/common';
import { poeActions } from '@/store/actions/poe.actions';

@Component({
  selector: 'poe-container',
  standalone: true,
  imports: [PoeDashComponent, AsyncPipe],
  template: `
    <poe-dash
      [redTimeframe]="(redTimeframe$ | async) || { start: 0, end: 0 }"
      [blueTimeframe]="(blueTimeframe$ | async) || { start: 0, end: 0 }"
      [controlMeasures]="(controlMeasures$ | async) || []"
      [selectedControlMeasureIds]="(selectedControlMeasureIds$ | async) || []"
      [redChartData]="(redChartData$ | async) || null"
      [blueChartData]="(blueChartData$ | async) || null"
    />
  `,
})
export class PoeContainerComponent implements OnInit {
  redTimeframe$ = this.store.select(selectRedTimeframe);
  blueTimeframe$ = this.store.select(selectBlueTimeframe);
  controlMeasures$ = this.store.select(selectPOEControlMeasuresWithNames);
  selectedControlMeasureIds$ = this.store.select(selectedPOECmIds);
  blueChartData$ = this.store.select(selectBlueChartData);
  redChartData$ = this.store.select(selectRedChartData);

  constructor(private store: Store) {}

  ngOnInit(): void {
    this.store.dispatch(poeActions.getControlMeasures());
  }
}
