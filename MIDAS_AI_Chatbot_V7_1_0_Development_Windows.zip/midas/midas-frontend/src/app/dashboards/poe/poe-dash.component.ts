import { ChartComponent, SimChartData } from '@/chart-v2/chart-v2.component';
import { GlobalTimeSelectorComponent } from '@/components/time-selector/global-time-selector.component';
import { VirtualSelectionScrollComponent } from '@/components/virtual-selection-scroll/virtual-selection-scroll.component';
import { ControlMeasure, Timeframe } from '@/models';
import { poeActions } from '@/store/actions/poe.actions';
import { Component, computed, input, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatCard, MatCardContent, MatCardHeader } from '@angular/material/card';
import { MatIcon } from '@angular/material/icon';
import { Store } from '@ngrx/store';

@Component({
  selector: 'poe-dash',
  standalone: true,
  imports: [
    MatCard,
    MatCardContent,
    MatCardHeader,
    FormsModule,
    ChartComponent,
    MatIcon,
    VirtualSelectionScrollComponent,
    GlobalTimeSelectorComponent,
  ],
  templateUrl: './poe-dash.component.html',
})
export class PoeDashComponent {
  controlMeasures = input<(ControlMeasure & { name: string })[]>([]);
  @Input() redTimeframe!: Timeframe;
  @Input() blueTimeframe!: Timeframe;
  @Input() selectedControlMeasureIds: number[] = [];
  @Input() blueChartData!: SimChartData<'line'> | null;
  @Input() redChartData!: SimChartData<'line'> | null;

  blueControlMeasures = computed(() =>
    this.controlMeasures().filter((cm) => cm.isFriendly)
  );
  redControlMeasures = computed(() =>
    this.controlMeasures().filter((cm) => !cm.isFriendly)
  );

  constructor(private store: Store<any>) {}

  onCMSelectionChange(event: {
    item: ControlMeasure;
    selected: boolean;
  }): void {
    const cm: ControlMeasure = event.item;
    const selected = event.selected;
    if (!cm) {
      console.log('Could not get cm from selection list');
      return;
    }
    this.store.dispatch(
      selected
        ? poeActions.controlMeasureSelected(cm.id)
        : poeActions.controlMeasureDeselected(cm.id)
    );
  }

  trackBy(index: number, item: ControlMeasure): string {
    return item.id.toString();
  }

  onBlueTimeframeChange(tf: Timeframe) {
    this.store.dispatch(poeActions.blueTimeframeChanged(tf));
  }

  onRedTimeframeChange(tf: Timeframe) {
    this.store.dispatch(poeActions.redTimeframeChanged(tf));
  }
}
