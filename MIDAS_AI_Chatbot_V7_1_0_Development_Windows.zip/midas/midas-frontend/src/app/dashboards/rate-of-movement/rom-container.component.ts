import { Component, OnInit } from '@angular/core';
import { RomDashComponent } from './rom-dash.component';
import { Store } from '@ngrx/store';
import {
  selectAllRomSpecs,
  selectCurrentRomSpec,
  selectCurrentEntityIds,
  selectEntityFilters,
  selectStats,
  selectTimeframe,
  selectEntitiesWithQueryFilter,
  selectVelocityChartData,
  selectDistanceChartData,
} from '@/store/features/rom.feature';
import { romActions } from '@/store/actions/rom.actions';
import { AsyncPipe } from '@angular/common';

@Component({
  selector: 'rom-container',
  imports: [RomDashComponent, AsyncPipe],
  template: `
    <rom-dash
      [captures]="(captures$ | async) || []"
      [selectedROM]="(selectedROM$ | async) || undefined"
      [entities]="(entities$ | async) || []"
      [stats]="(stats$ | async) || undefined"
      [selectedIds]="(selectedIds$ | async) || []"
      [velocityChartData]="(velocityChartData$ | async) || null"
      [distanceChartData]="(distanceChartData$ | async) || null"
      [entityFilters]="(entityFilters$ | async) || []"
      [timeframe]="(timeframe$ | async) || { start: 0, end: 0 }"
    />
  `,
})
export class RomContainerComponent implements OnInit {
  captures$ = this.store.select(selectAllRomSpecs);
  selectedROM$ = this.store.select(selectCurrentRomSpec);
  entities$ = this.store.select(selectEntitiesWithQueryFilter);
  selectedIds$ = this.store.select(selectCurrentEntityIds);
  stats$ = this.store.select(selectStats);
  velocityChartData$ = this.store.select(selectVelocityChartData);
  distanceChartData$ = this.store.select(selectDistanceChartData);
  entityFilters$ = this.store.select(selectEntityFilters);
  timeframe$ = this.store.select(selectTimeframe);

  constructor(private store: Store) {}

  ngOnInit() {
    this.store.dispatch(romActions.getData());
  }
}
