import { ChartComponent, SimChartData } from '@/chart-v2/chart-v2.component';
import {
  EntitySelectorComponent,
  FilterStatus,
} from '@/components/entity-selector/entity-selector.component';
import {ROMEntity, ROMSpec, ROMStats, Timeframe} from '@/models';
import { romActions } from '@/store/actions/rom.actions';
import { NgClass } from '@angular/common';
import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCard, MatCardContent } from '@angular/material/card';
import { MatFormField, MatLabel } from '@angular/material/form-field';
import { MatInput } from '@angular/material/input';
import { MatOption, MatSelect } from '@angular/material/select';
import { Store } from '@ngrx/store';
import { SFTreeMetaData } from '@simfront/common-libs';
import {GlobalTimeSelectorComponent} from "@/components/time-selector/global-time-selector.component";

@Component({
  selector: 'rom-dash',
    imports: [
        FormsModule,
        MatFormField,
        MatLabel,
        MatOption,
        MatSelect,
        MatInput,
        ReactiveFormsModule,
        MatCard,
        MatCardContent,
        ChartComponent,
        EntitySelectorComponent,
        NgClass,
        GlobalTimeSelectorComponent,
    ],
  templateUrl: './rom-dash.component.html',
})
export class RomDashComponent implements OnChanges {
  @Input() captures: ROMSpec[] = [];
  @Input() selectedROM: ROMSpec | undefined = undefined;
  @Input() entities: ROMEntity[] = [];
  @Input() selectedIds: number[] = [];
  @Input() stats: ROMStats | undefined = undefined;
  @Input() velocityChartData: SimChartData<'line'> | null = null;
  @Input() distanceChartData: SimChartData<'line'> | null = null;
  @Input() entityFilters: FilterStatus[] = [];
  @Input() timeframe!: Timeframe;
  referenceThreshold: FormControl<number>;

  metaData: SFTreeMetaData<ROMEntity, string> = {
    controlTrackBy: (n) => `${n.id}`,
    children: (n) => n.children,
    childrenProp: 'children',
    label: (n) => n.name,
  };

  constructor(private store: Store) {
    this.referenceThreshold = new FormControl();
  }

  ngOnChanges(changes: SimpleChanges): void {}

  trackBy(index: number, item: ROMEntity): string {
    return item.id.toString();
  }

  onEntitySelectionChange(event: {
    items: ROMEntity[];
    selected: boolean;
  }): void {
    if (!event.items || event.items.length === 0) {
      console.log('Could not get entity from checkbox');
      return;
    }

    this.store.dispatch(
      romActions.batchEntitySelection({
        entityIds: event.items.map((i) => i.id),
        selected: event.selected,
      })
    );
  }

  onCaptureSelected(): void {
    this.store.dispatch(
      romActions.captureSelected(this.selectedROM as ROMSpec)
    );
  }

  onRefThresholdChange(): void {
    this.store.dispatch(
      romActions.refThresholdChanged(this.referenceThreshold.value)
    );
  }

  onEntityFilterChange(filters: FilterStatus[]): void {
    this.store.dispatch(romActions.entityFilterChange(filters));
  }

  onSliderChange(tf: Timeframe) {
    this.store.dispatch(romActions.timeframeChange(tf));
  }

}
