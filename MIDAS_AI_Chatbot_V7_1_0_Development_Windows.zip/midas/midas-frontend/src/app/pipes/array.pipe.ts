import { Pipe, PipeTransform } from '@angular/core';

export enum ArrayPipeType {
  Includes = 'includes',
  Find = 'find',
  Filter = 'filter',
  Custom = 'custom'
}

export type ArrayPipeResponse<T> = T | T[] | boolean | undefined;
export type ArrayPipeFunc<T> = (arr: T[], item: T, lookup: any) => ArrayPipeResponse<T>;

/**
 * Get value from array
 * in Template file: list | array: 'ArrayPipeType' : item : function
 */
@Pipe({
  name: 'array',
  standalone: true,
  pure: true
})
export class ArrayPipe implements PipeTransform {
  transform(value: Array<any>, type: ArrayPipeType | string, item?: any, func?: ArrayPipeFunc<any>): ArrayPipeResponse<any> {
    switch (type) {
      case ArrayPipeType.Includes:
        return item ? value.includes(item) : false;
      case ArrayPipeType.Find:
        return item ? value.find(s => item === s) : undefined;
      case ArrayPipeType.Filter:
        return item && func ? value.filter(s => func(value, s, item)) : [];
      case ArrayPipeType.Custom:
        // TODO: Custom Type implementation.
        break;
      default:
        return undefined;
    }
  }
}
