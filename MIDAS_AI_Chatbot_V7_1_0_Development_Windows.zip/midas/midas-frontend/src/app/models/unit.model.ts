import { SFMap } from '@simfront/common-libs';

export interface PersonInfo {
  id: number;
  name: string;
}

export interface UnitGroupData {
  vehicleName: string;
  persons: SFMap<PersonInfo[]>;
}

export interface UnitPersons {
  groups: UnitGroupData[];
}

export interface UnitVehicleData {
  type: string;
  name: string;
  kmDriven: number;
  timeOccupied: string;
  timeInMotion: string;
  timeInPlace: string;
}

export interface UnitVehicles {
  vehicles: UnitVehicleData[];
}

export interface UnitPassDetails {
  name: string;
  pass: boolean;
  percentage: number;
  percentile: number;
}

export interface TrainingLevel {
  name: string;
  count: number;
}

export interface UnitOverallData {
  btsCompleted: number;
  scenarioCompleted: number;
  trainingLevels: TrainingLevel[];
  scenarioPassed: SFMap<number>;
  scenarioFailed: SFMap<number>;
  pass: UnitPassDetails[];
}

export interface TargetingMetricsResult {
  obsToLRF: number;
  lrfToFirstShot: number;
  firstShotToElimination: number;  
}

export interface UnitTargetEngagementData {
  name: string;
  shotsFired: number;
  aimingDeviation: number;
  hits: number;
  misses: number;
  accuracy: number;
  targetingMetricsResults: TargetingMetricsResult[];
}

export interface UnitTargetEngagements {
  targetEngagements: UnitTargetEngagementData[];
}

export type UnitReportData = UnitOverallData & UnitVehicles & UnitPersons & UnitTargetEngagements;

export interface UnitReportFilter {
  units: PersonInfo[] | null;
  vehicleTypes: string[] | null; // Maybe enum
  roles: string[] | null; // Maybe enum
  accuracy: number[] | null;
  firstElimination: number[] | null;
  date: null | {
    start: Date | null;
    end: Date | null;
  }
}

export interface UnitFilterResponse {
  fields: string[];
  data: SFMap<string[]>;
}