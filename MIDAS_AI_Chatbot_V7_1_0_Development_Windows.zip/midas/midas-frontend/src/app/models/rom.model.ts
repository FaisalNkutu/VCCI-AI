import { SimEntity } from './models';

/**
 * ROM Dashboard models
 */
export interface ROMSpec extends SimEntity {
  parentId: number;
  controlmeasureid: number;
  controlmeasurename: string;
  formattedendtime: string;
  formattedtime: string;
  time: number;
  endtime: number;
}

export interface ROMEntityDetails {
  time: number;
  numEnts: number;
  avgspeed: number;
  avgcumuldist: number;
  formattedtime: string;
}

export interface ROMEntity extends SimEntity {
  avgspeed: number;
  children: ROMEntity[];
}

export interface ROMStats {
  average: number;
  min: number;
  max: number;
  staticEntityPercentage : number;
}
