interface BasePoint {
  id?: string;
  time: number;
  formattedTime: string;
}

export interface CombatPowerPoint extends BasePoint {
  combatPower: number;
  entityName: string;
}

export interface CombatPowerEquipmentPoint extends BasePoint {
  originalQuantity: number;
  currentQuantity: number;
  equipmentType: string;
}

export interface CombatPowerEntityDetails {
  entCPHash: {
    [key: string]: CombatPowerPoint[];
  };
  timeArray: { time: number; formattedTime: string }[];
  average: Omit<CombatPowerPoint, 'entityName'>[];
}

export interface CombatPowerEquipmentDetails {
  hlding_per_equipment_type: {
    [key: string]: CombatPowerEquipmentPoint[];
  };
}

export interface EquipmentHolding {
  jEquipmentTypeCatCode: string;
  jEquipmentTypeName: string;
  jOriginalQty: number;
  jCurrentQty: number;
  jReferenceQty: number;
}

export interface CombatPowerTableData {
  jHoldings: EquipmentHolding[];
  formattedtime: string;
  time: number;
  combatpower: number;
  entityid: number;
}

export interface CombatPowerEquipmentTableData {
  time: number;
  formattedTime: string;
  unitId: number;
  unitName: string;
  originalQuantity: number;
  currentQuantity: number;
  milSym: string;
}

export type CombatPowerDataGrouping = 'unit' | 'equipment';
