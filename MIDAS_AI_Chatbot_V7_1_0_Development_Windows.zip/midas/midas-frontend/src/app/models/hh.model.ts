import { ChartDataset, ChartOptions } from 'chart.js';
import { SimEntity } from './models';

/**
 * HHour Metrics Dasbhoard
 *
 */
export interface Unit extends SimEntity {
  deviation: number;
  children: Unit[];
}

export interface LodLocation {
  lon: number;
  lat: number;
}

//currently realtime not doing anything
export interface HHourSpecs {
  time: number;
  formattedtime: string;
  threshold: number; // populates threshold dropdown
  lineofdepid: number;
  lineofdepname: string;
  id: number;
  name: string;
}

export interface ChartData {
  chartData: ChartDataset[];
  chartOptions: ChartOptions;
  chartLabels: any[];
}

export type HHourUnitDataGrouping = 'crossed' | 'all';
