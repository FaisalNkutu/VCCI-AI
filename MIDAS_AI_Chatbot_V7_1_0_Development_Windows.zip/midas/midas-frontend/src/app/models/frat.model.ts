export interface FratricideGraphPoint {
  time: number;
  formattedTime: string;
  fratIncidentCount: number;
}

export interface FratIncident {
  name: string;
  id: number;
  lat: number;
  lon: number;
  milSym: string;
  time: number;
  formattedtime: string;

  fireEventId: number;
  firingType: string;
  targetEntityName: string | null;
  targetEntityMilSym: string | null;
  targetLat: number;
  targetLon: number;
  munitionMaxLat: number;
  munitionMaxLon: number;
  intersectLat: number;
  intersectLon: number;
  receivingEntityName: string;
  receivingEntityMilSym: string;
  footprintPoint1Lat: number;
  footprintPoint1Lon: number;
  footprintPoint2Lat: number;
  footprintPoint2Lon: number;
  footprintPoint3Lat: number;
  footprintPoint3Lon: number;
  footprintPoint4Lat: number;
  footprintPoint4Lon: number;

}
