export interface POEPoint {
  time: number;
  formattedtime: string;
  oppositecount: number;
  offsidecount: number;
  friendlycm: boolean;
}
