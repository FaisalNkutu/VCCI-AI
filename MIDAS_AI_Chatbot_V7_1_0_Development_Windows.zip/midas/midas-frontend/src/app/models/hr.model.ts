export interface EquipmentRollupHolding {
  unitId: number;
  unitName: string;
  equipmentTypeId: number;
  equipmentName: string;
  totalQty: number;
  operationalQty: number;
  time: number;
  formattedTime: string;
  delta: number;
  milSym: string;
}
