export interface UnitWatchResults {
  results: UnitWatchUpdate[];
  time: number;
}

export interface UnitWatchUpdate {
  entityName: string;
  entityId: number;
  time: number;
  detail: string;
  category: UpdateCategory;
}

export type UpdateCategory = 'ACT' | 'FRAT' | 'CPOWER' | 'HHOUR' | 'ENGAGE' | 'HOLDING' | 'NOS';
