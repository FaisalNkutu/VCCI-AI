import { ChartEvent } from 'chart.js';
export type { SFMap } from '@simfront/common-libs';

import { Chart } from 'chart.js';
import ChartZoom from 'chartjs-plugin-zoom';
import ChartDataLabels from 'chartjs-plugin-datalabels';

Chart.register(ChartZoom);
Chart.register(ChartDataLabels);

export interface DBState {
  databases: string[];
  selectedDB: string | undefined;
}

// Will be used later
// export interface TimeseriesData<T> {
//   id: number;
//   label: string;
//   data: T[];
// }

export type TimeseriesData<T> = Record<number, T[]>;

export interface Timeframe {
  start: number;
  end: number;
}

export interface Equipment {
  equipmentTypeId: number;
  equipmentName: string;
}

export interface TimeFormat {
  name: string;
  id: number;
}

export interface TimeMinMax {
  maxTime: number;
  minTime: number;
  prevMaxTime: number;
}

export interface SimEntity {
  name: string;
  lat: number;
  lon: number;
  id: number;
  children: SimEntity[];
  milSym: string;
  isFriendly: boolean;
}

export interface ChartClickEvent {
  event?: ChartEvent;
  active?: object[];
}

export const payload =
  <T>() =>
  (t: T): Payload<T> => ({ payload: t });
export const optionalPayload =
  <T>() =>
  (t?: T): OptionalPayload<T> => ({ payload: t });

export type Payload<P> = { payload: P };
export type OptionalPayload<P> = { payload?: P };

/**
 * Status data from the server on overall metrics
 */
export interface StatusData {
  jMaxTime: number;
  jFormattedMaxTime: string;

  jHHourActive: boolean;
  jROMActive: boolean;
  jCMOccupationsActive: boolean;
  jPOEActive: boolean;
  jCPowerActive: boolean;
  jEnemyEngagementsActive: boolean;
  jFratricideActive: boolean;
  jEntityWatchActive: boolean;

  jHHourReason?: string;
  jROMReason?: string;
  jPOEReason?: string;
  jCMOccsReason?: string;
  jEneEngReason?: string;
  jEntWatchReason?: string;

  jROMEntryCount: number;
  jFratricideIncidentCount: number;
  jHHourCount: number;
}

export interface ConnectedDB {
  connected: boolean;
  database: string;
  live: boolean;
  host: string;
}
