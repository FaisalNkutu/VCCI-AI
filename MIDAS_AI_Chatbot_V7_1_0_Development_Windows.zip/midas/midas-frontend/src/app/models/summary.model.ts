interface ROMSummary {
  controlMeasuresMonitored: number;
  activeControlMeasureNames: string[];
}

interface CPSummary {
  unitsBelow100: number;
}

interface CMOSummary {
  controlMeasuresMonitored: number;
}

interface HHourSummary {
  entitiesCrossed: number;
}

interface POESummary {
  bluforControlMeasures: number;
  opforControlMeasures: number;
}

interface EntityWatchSummary {
  entitiesWatched: number;
}

interface FratSummary {
  incidentCount: number;
}

interface EESummary {
  controlMeasureId: number;
  controlMeasureName: string;
  numberEngaged: number;
  engagedEntityNames: string[];
}

export interface SummaryState {
  ROM: ROMSummary;
  CombatPower: CPSummary;
  CMO: CMOSummary;
  HHour: HHourSummary;
  POE: POESummary;
  EntityWatch: EntityWatchSummary;
  Fratricide: FratSummary;
  EnemyEngagements: EESummary;
}
