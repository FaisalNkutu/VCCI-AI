export type TraineeReportResult = 'pass' | 'fail';
export type TraineeScenarioOutcome = 'success' | 'failure';

export interface TraineeId {
  id: string;
  name: string;
}

export interface TargetTiming {
  targetId: string;
  timeObsToLrf: string;
  timeLrfToFirstShot: string;
  timeFirstShotToEliminated: string;
}

export interface TraineeReport {
  trainee: string;
  position: string;
  btsCompleted: string;
  trainingLevel: string;
  timeOfFirstContact: string;
  attackStart: string;
  attackEnd: string;
  consolidationStart: string;
  consolidationEnd: string;
  friendlyPersonnelCasualties: number;
  friendlyVehicleCasualties: number;
  enemyPersonnelCasualties: number;
  enemyVehicleCasualties: number;
  timeInOrv: string;
  timeInAttackPosn: string;
  result: TraineeReportResult;
  scenarioOutcome: TraineeScenarioOutcome;
  kmsDriven: number;
  timeInVehicle: string;
  timeInMotion: string;
  timeInPlace: string;
  shotsFired: number;
  hits: number;
  missed: number;
  accuracy: string;
  aimingDeviation: number;
  targetTimings: TargetTiming[];
}

export const MOCK_TRAINEE_REPORT: TraineeReport = {
  trainee: '1',
  position: 'Gunner',
  btsCompleted: 'Gagetown range',
  trainingLevel: 'TL3',
  timeOfFirstContact: '00:03:26',
  attackStart: '00:03:42',
  attackEnd: '00:04:12',
  consolidationStart: '00:06:27',
  consolidationEnd: '00:07:10',
  friendlyPersonnelCasualties: 0,
  friendlyVehicleCasualties: 0,
  enemyPersonnelCasualties: 7,
  enemyVehicleCasualties: 2,
  timeInOrv: '00:02:08',
  timeInAttackPosn: '00:00:36',
  result: 'pass',
  scenarioOutcome: 'success',
  kmsDriven: 0,
  timeInVehicle: '00:07:40',
  timeInMotion: '00:06:53',
  timeInPlace: '00:00:47',
  shotsFired: 18,
  hits: 13,
  missed: 5,
  accuracy: '72.22%',
  aimingDeviation: 30,
  targetTimings: [
    {
      targetId: 'BMP_001',
      timeObsToLrf: '00:00:05',
      timeLrfToFirstShot: '00:00:09',
      timeFirstShotToEliminated: '00:00:10'
    },
    {
      targetId: 'BMP_002',
      timeObsToLrf: '00:00:25',
      timeLrfToFirstShot: '00:00:04',
      timeFirstShotToEliminated: '00:00:10'
    }
  ]
};

export const isTraineeReport = (val: unknown): val is TraineeReport => {
  if (!val || typeof val !== 'object') return false;
  const isTargetTiming = (t: unknown): t is TargetTiming => {
    if (!t || typeof t !== 'object') return false;
    return (
      'targetId' in t && typeof t.targetId === 'string'
      && 'timeObsToLrf' in t && typeof t.timeObsToLrf === 'string'
      && 'timeLrfToFirstShot' in t && typeof t.timeLrfToFirstShot === 'string'
      && 'timeFirstShotToEliminated' in t && typeof t.timeFirstShotToEliminated === 'string'
    );
  };

  return (
    'trainee' in val && typeof val.trainee === 'string'
    && 'position' in val && typeof val.position === 'string'
    && 'btsCompleted' in val && typeof val.btsCompleted === 'string'
    && 'trainingLevel' in val && typeof val.trainingLevel === 'string'
    && 'timeOfFirstContact' in val && typeof val.timeOfFirstContact === 'string'
    && 'attackStart' in val && typeof val.attackStart === 'string'
    && 'attackEnd' in val && typeof val.attackEnd === 'string'
    && 'consolidationStart' in val && typeof val.consolidationStart === 'string'
    && 'consolidationEnd' in val && typeof val.consolidationEnd === 'string'
    && 'friendlyPersonnelCasualties' in val && typeof val.friendlyPersonnelCasualties === 'number'
    && 'friendlyVehicleCasualties' in val && typeof val.friendlyVehicleCasualties === 'number'
    && 'enemyPersonnelCasualties' in val && typeof val.enemyPersonnelCasualties === 'number'
    && 'enemyVehicleCasualties' in val && typeof val.enemyVehicleCasualties === 'number'
    && 'timeInOrv' in val && typeof val.timeInOrv === 'string'
    && 'timeInAttackPosn' in val && typeof val.timeInAttackPosn === 'string'
    && 'result' in val && (val.result === 'pass' || val.result === 'fail')
    && 'scenarioOutcome' in val && (val.scenarioOutcome === 'success' || val.scenarioOutcome === 'failure')
    && 'kmsDriven' in val && typeof val.kmsDriven === 'number'
    && 'timeInVehicle' in val && typeof val.timeInVehicle === 'string'
    && 'timeInMotion' in val && typeof val.timeInMotion === 'string'
    && 'timeInPlace' in val && typeof val.timeInPlace === 'string'
    && 'shotsFired' in val && typeof val.shotsFired === 'number'
    && 'hits' in val && typeof val.hits === 'number'
    && 'missed' in val && typeof val.missed === 'number'
    && 'accuracy' in val && typeof val.accuracy === 'string'
    && 'aimingDeviation' in val && typeof val.aimingDeviation === 'number'
    && 'targetTimings' in val && Array.isArray(val.targetTimings)
    && (val.targetTimings).every(isTargetTiming)
  );
};
