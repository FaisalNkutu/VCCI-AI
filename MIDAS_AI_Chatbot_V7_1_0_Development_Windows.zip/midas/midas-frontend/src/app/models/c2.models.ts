export interface C2Context {
  id: number; //the id is not unique, because they use overlapping ids between vcci and metrics contexts
  name: string;
  type?: 'VCCI_DATA_TYPE' | 'MET_DATA_TYPE'; //todo remove optional, just for testing
  uniqueID: string; //this is unique and is used to identify the context, is id:type
  selected: boolean;
  units?: any[];
}
