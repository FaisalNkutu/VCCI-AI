import { SimEntity } from "./models";

export interface EnemyEngagementControlMeasure {
  id: number;
  cmname: string;
  isFriendly: boolean;
}
export interface EnemyEngagementPoint {
  time: number;
  engagedCount: number;
  formattedTime: string;
  entityCount: number;
}

export interface EnemyEngagementUnit extends SimEntity {
  parentId: number;
  time: number;
  children: EnemyEngagementUnit[];
}
