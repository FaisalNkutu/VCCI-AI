import { SFMap } from './models';

/**
 * Control Measure Occupation interfaces
 */
export interface ControlMeasure {
  id: number;
  cmname: string;
  isFriendly: boolean;
}

export interface CMEntity {
  entityId: number;
  entityName: string;
  milSym: string;
}

export interface ControlMeasureTableRow {
  name: string;
  units: CMEntity[];
}

export interface ControlMeasureEntityTableData {}

export interface CmChartData {
  jOccupationsHM: SFMap<CmPoint>;
  formattedTime: string;
  simulationTime: number;
}

export interface CmPoint {
  controlMeasureId: number;
  controlMeasureName: string;
  entityCount: number;
  time: number;
  formattedTime: string;
}


