import { HttpErrorResponse } from '@angular/common/http';
import { Component, Directive, effect, ElementRef, inject, InjectionToken, input, Renderer2 } from '@angular/core';

export interface ErrorParser<T = any> {
  is: (t: unknown) => t is T;
  format: (t: T) => string;
}

const DEFAULT_HTTP_ERROR_PARSER: ErrorParser<HttpErrorResponse> = {
  is: (t: unknown) => t instanceof HttpErrorResponse,
  format: (t: HttpErrorResponse) =>
    `
        <div class="text-red-500">
            <span class="material-icons" style="vertical-align: middle; transform: translateY(-2px);">
                error
            </span>
            <span>${t.error instanceof ErrorEvent ? 'Client Error' : 'Server Error'}: ${t.status}</span>
        </div>
        <br/>
        <span class="text-neutral-200" style="font-weight: lighter">${t.message}</span>
    `
};
const DEFAULTS = [DEFAULT_HTTP_ERROR_PARSER];
export const CUSTOM_ERROR_PARSERS = new InjectionToken<ErrorParser[]>('CUSTOM_ERROR_PARSERS');

export const ERROR_MSG_PARSERS = new InjectionToken<ErrorParser[]>('ERROR_MSG_PARSERS', {
  providedIn: 'root',
  factory: () => {
    const custom = inject(CUSTOM_ERROR_PARSERS, { optional: true })?.flat() || [];
    return [...custom, ...DEFAULTS];
  }
});

@Directive({
  selector: '[appErrorMsg]'
})
export class AppErrorMsgDirective {
  private el = inject(ElementRef);
  private renderer = inject(Renderer2);
  private parsers = inject(ERROR_MSG_PARSERS);

  error = input.required<unknown>({ alias: 'appErrorMsg' });

  constructor() {
    effect(() => {
      const value = this.error();
      if (value) {
        const html = this.parseError(value);
        this.renderer.setProperty(this.el.nativeElement, 'innerHTML', html);
        this.renderer.setStyle(this.el.nativeElement, 'display', 'block');
      } else {
        this.renderer.setStyle(this.el.nativeElement, 'display', 'none');
      }
    });
  }

  private parseError(error: unknown): string {
    const parser = this.parsers.find(p => p.is(error));
    return parser ? parser.format(error) : 'An unknown error occurred.';
  }
}

@Component({
  selector: 'app-error-display',
  template: ``,
  styles: `
    :host {
      display: block;
      margin: 10px 0;
    }
  `,
  hostDirectives: [{
    directive: AppErrorMsgDirective,
    inputs: ['appErrorMsg: error']
  }]
})
export class ErrorDisplayComponent {}
