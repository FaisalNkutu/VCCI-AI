import {
  Component,
  computed,
  EventEmitter,
  input,
  Input,
  Output,
  signal,
  ChangeDetectionStrategy,
} from '@angular/core';
import { BaseChartDirective } from 'ng2-charts';
import { ChartData, ChartOptions, ChartType, ChartTypeRegistry } from 'chart.js';
import { ChartClickEvent } from '@/models';
import { stringToHexColor } from '@/utils/color-gen';

import { MatIcon } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatButtonModule } from '@angular/material/button';

export interface BaseChartDataPoint {
  xValue: number;
  xLabel?: string;
  yValue: number;
  yLabel?: string;
  label: string;
}

export interface ChartClickEventData<V> {
  point: V;
  datasetIndex: number;
  index: number;
  event: ChartClickEvent;
}

@Component({
  selector: 'chart-v3',
  imports: [
    BaseChartDirective,
    MatIcon,
    MatMenuModule,
    MatButtonModule
],
  templateUrl: './chart-v3.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ChartComponent<T extends ChartType, V> {
  chartDataset = input.required<Record<string, V[]> | null | undefined>();
  @Input({ required: true }) adaptor!: (item: V) => BaseChartDataPoint;
  @Input({ required: true }) type!: T;
  @Input() chartTitle: string = '';

  // Convert additionalOptions to a signal for reactive updates
  additionalOptions = input<Partial<ChartOptions>>({});

  @Output() chartClicked: EventEmitter<ChartClickEventData<V>> =
    new EventEmitter();

  private rawDataMap = new Map<string, V[]>();
  private xLabelMap = new Map<number, string>(); // Map xValue to xLabel

  /**
   * Computed property that transforms raw data into Chart.js compatible format
   */
  data = computed(() => {
    const dataset = this.chartDataset();
    this.rawDataMap.clear();
    this.xLabelMap.clear();

    const hasData =
      dataset &&
      Object.keys(dataset).length > 0 &&
      Object.values(dataset).some((values) => values.length > 0);

    if (!hasData) {
      // Return empty chart data structure
      return {
        labels: [],
        datasets: [],
      } as ChartData;
    }

    // Store raw data for click events and collect x labels
    Object.entries(dataset).forEach(([key, values]) => {
      this.rawDataMap.set(key, values);
    });

    // Extract all unique x values and their labels
    const allXValues = new Set<number>();
    Object.values(dataset).forEach((values) => {
      values.forEach((item) => {
        const adapted = this.adaptor(item);
        allXValues.add(adapted.xValue);
        // Store xLabel if it exists, prioritizing the first encountered label for each xValue
        if (adapted.xLabel && !this.xLabelMap.has(adapted.xValue)) {
          this.xLabelMap.set(adapted.xValue, adapted.xLabel);
        }
      });
    });

    const sortedXValues = Array.from(allXValues).sort((a, b) => a - b);

    // Create datasets
    const datasets = Object.entries(dataset).map(([key, values]) => {
      const adaptedData = values.map((item) => this.adaptor(item));

      const dataPoints = sortedXValues.map((xValue) => {
        const point = adaptedData.find((d) => d.xValue === xValue);
        return point ? point.yValue : null;
      });

      return {
        label: this.adaptor(values[0]).label,
        data: dataPoints,
        backgroundColor: stringToHexColor(key) + '66',
        borderColor: stringToHexColor(key),
        borderWidth: 2,
        fill: false,
        tension: 0.1,
        pointRadius: 4,
        pointHoverRadius: 6,
        spanGaps: true,
        ...this.getDatasetDefaults(),
      };
    });

    // Use xLabel if available, otherwise fallback to xValue.toString()
    const labels = sortedXValues.map((xValue) => {
      const xLabel = this.xLabelMap.get(xValue);
      return xLabel || xValue.toString();
    });

    return {
      labels,
      datasets,
    } as ChartData;
  });

  /**
   * Computed options signal - creates zoom limits based on data
   */
  options = computed(() => {
    const currentData = this.data();
    const additionalOptions = this.additionalOptions();

    // Calculate zoom limits based on data
    const { minY, maxY, minX, maxX } = this.calculateDataBounds(currentData);

    const baseOptions: ChartOptions = {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: {
          type: 'category',
          grid: {
            color: '#414546',
          },
          ticks: {
            color: 'white',
            maxRotation: 45,
            minRotation: 45,
          },
          // X-axis zoom limits - always show full range at minimum zoom
          min: minX,
          max: maxX,
        },
        y: {
          grid: {
            color: '#414546',
          },
          ticks: {
            color: 'white',
          },
          // Y-axis zoom limits
          min: minY,
          max: maxY,
        },
      },
      plugins: {
        datalabels: {
          display: false,
        },
        legend: {
          labels: {
            color: 'white',
          },
        },
        tooltip: {
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
          titleColor: 'white',
          bodyColor: 'white',
          borderColor: '#414546',
          borderWidth: 1,
          callbacks: {
            title: (context) => {
              const index = context[0].dataIndex;
              const datasetIndex = context[0].datasetIndex;
              return this.getTooltipTitle(datasetIndex, index);
            },
            label: (context) => {
              const index = context.dataIndex;
              const datasetIndex = context.datasetIndex;
              return this.getTooltipLabel(datasetIndex, index);
            },
          },
        },
        zoom: {
          limits: {
            x: {
              min: minX,
              max: maxX,
            },
            y: {
              min: minY,
              max: maxY,
            },
          },
          pan: {
            enabled: true,
            mode: 'xy',
          },
          zoom: {
            wheel: {
              enabled: true,
            },
            pinch: {
              enabled: true,
            },
            mode: 'xy',
            scaleMode: 'xy',
          },
        },
      },
      interaction: {
        mode: 'nearest',
        intersect: true,
      },
      onHover: (event: any, activeElements: any[]) => {
        if (activeElements.length) {
          event.native.target.style.cursor = 'pointer';
        } else {
          event.native.target.style.cursor = 'default';
        }
      },
      animation: {
        duration: 300,
      },
    };

    return this.mergeOptions(baseOptions, additionalOptions);
  });

  /**
   * Calculate data bounds for zoom limits
   */
  private calculateDataBounds(data: ChartData) {
    let minY = Infinity;
    let maxY = -Infinity;
    let minX = 0;
    let maxX = 0;

    // Calculate Y bounds from actual data values
    data.datasets.forEach((dataset) => {
      dataset.data.forEach((value) => {
        if (typeof value === 'number' && value !== null) {
          minY = Math.min(minY, value);
          maxY = Math.max(maxY, value);
        }
      });
    });

    // X bounds are based on labels (full range)
    maxX = (data.labels?.length || 1) - 1;

    // Handle case where no valid data points exist
    if (minY === Infinity) minY = 0;
    if (maxY === -Infinity) maxY = 10;

    return { minY, maxY, minX, maxX };
  }

  onChartClicked(event: ChartClickEvent): void {
    if (!this.chartDataset() || !event.active || event.active.length === 0)
      return;

    const activePoint = event.active[0] as {
      datasetIndex: number;
      index: number;
    };
    const datasetIndex = activePoint.datasetIndex;
    const index = activePoint.index;

    const datasetKeys = Object.keys(this.chartDataset() as Record<string, V[]>);
    const datasetKey = datasetKeys[datasetIndex];

    if (datasetKey) {
      const rawData = this.rawDataMap.get(datasetKey);
      if (rawData && rawData[index]) {
        const clickEventData: ChartClickEventData<V> = {
          point: rawData[index],
          datasetIndex,
          index,
          event: event,
        };

        this.chartClicked.emit(clickEventData);
      }
    }
  }

  private getDatasetDefaults(): any {
    return {
      pointBackgroundColor: 'white',
      pointBorderWidth: 2,
      pointHoverBackgroundColor: 'white',
      pointHoverBorderWidth: 3,
    };
  }

  private getTooltipTitle(datasetIndex: number, index: number): string {
    if (!this.chartDataset()) return '';
    const datasetKeys = Object.keys(this.chartDataset() as Record<string, V[]>);
    const datasetKey = datasetKeys[datasetIndex];

    if (datasetKey) {
      const rawData = this.rawDataMap.get(datasetKey);
      if (rawData && rawData[index]) {
        const adapted = this.adaptor(rawData[index]);
        return adapted.label;
      }
    }

    return '';
  }

  private getTooltipLabel(datasetIndex: number, index: number): string {
    if (!this.chartDataset()) return '';
    const datasetKeys = Object.keys(this.chartDataset() as Record<string, V[]>);
    const datasetKey = datasetKeys[datasetIndex];

    if (datasetKey) {
      const rawData = this.rawDataMap.get(datasetKey);
      if (rawData && rawData[index]) {
        const adapted = this.adaptor(rawData[index]);
        const yLabel = adapted.yLabel || adapted.yValue.toString();
        return `${datasetKey}: ${yLabel}`;
      }
    }

    return '';
  }

  private mergeOptions(
    base: ChartOptions,
    additional: Partial<ChartOptions>
  ): ChartOptions {
    return {
      ...base,
      ...additional,
      scales: this.mergeScales(base.scales, additional.scales),
      plugins: {
        ...base.plugins,
        ...additional.plugins,
      },
    };
  }

  private mergeScales(
    base: ChartOptions['scales'],
    additional: Partial<ChartOptions>['scales']
  ): ChartOptions['scales'] {
    if (!base && !additional) return undefined;

    const merged: Record<string, any> = {
      ...base,
      ...additional,
    };

    return merged;
  }
}
