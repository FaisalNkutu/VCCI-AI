import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { routes } from './app.routes';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { provideCharts, withDefaultRegisterables } from 'ng2-charts';
import { provideHttpClient } from '@angular/common/http';
import { provideState, provideStore } from '@ngrx/store';
import { provideEffects } from '@ngrx/effects';
import { provideRouterStore, routerReducer } from '@ngrx/router-store';
import { HHourEffects } from './store/effects/h-hour.effects';
import { provideStoreDevtools } from '@ngrx/store-devtools';
import { RomEffects } from './store/effects/rom.effects';
import { romFeature } from './store/features/rom.feature';
import { hHourFeature } from './store/features/h-hour.feature';
import { sidebarFeature } from '@/store/features/sidebar.feature';
import { SidebarEffects } from '@/store/effects/sidebar.effects';
import { controlMeasureFeature } from '@/store/features/cm.feature';
import { CmEffects } from '@/store/effects/cm.effects';
import { poeFeature } from '@/store/features/poe.feature';
import { PoeEffects } from '@/store/effects/poe.effects';
import { FratricideEffects } from '@/store/effects/fratricide.effects';
import { fratricideFeature } from '@/store/features/fratricide.feature';
import { enemyEngagementFeature } from '@/store/features/enemy-engagement.feature';
import { EnemyEngagementEffects } from '@/store/effects/enemy-engagement.effects';
import { cpFeature } from './store/features/cp.feature';
import { CpEffects } from './store/effects/cp.effects';
import { unitWatchFeature } from './store/features/unit-watch.feature';
import { UnitWatchEffects } from './store/effects/unit-watch.effects';
import { HREffects } from './store/effects/hr.effects';
import { hrFeature } from './store/features/hr.feature';
import { SummaryEffects } from './store/effects/summary.effects';
import { summaryFeature } from './store/features/summary.feature';
import { c2Feature } from './store/features/c2.feature';
import { C2Effects } from './store/effects/c2.effects';

export const API_URL = 'http://localhost:10001';

const featureStates = [
  { name: 'summary', reducer: summaryFeature.reducer },
  { name: 'hhour', reducer: hHourFeature.reducer },
  { name: 'rom', reducer: romFeature.reducer },
  { name: 'sidebar', reducer: sidebarFeature.reducer },
  { name: 'cmoc', reducer: controlMeasureFeature.reducer },
  { name: 'poe', reducer: poeFeature.reducer },
  { name: 'fratricide', reducer: fratricideFeature.reducer },
  { name: 'enemy-engagement', reducer: enemyEngagementFeature.reducer },
  { name: 'combat-power', reducer: cpFeature.reducer },
  { name: 'unit-watch', reducer: unitWatchFeature.reducer },
  { name: 'holdings-rollup', reducer: hrFeature.reducer },
  { name: 'unitWatch', reducer: unitWatchFeature.reducer },
  { name: 'c2', reducer: c2Feature.reducer }
];

const stateProviders = featureStates.map(provideState);

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    provideAnimationsAsync(),
    provideCharts(withDefaultRegisterables()),
    provideHttpClient(),
    provideStore({
      router: routerReducer,
    }),
    ...stateProviders,
    provideEffects(
      HHourEffects,
      RomEffects,
      SidebarEffects,
      CmEffects,
      PoeEffects,
      FratricideEffects,
      EnemyEngagementEffects,
      CpEffects,
      UnitWatchEffects,
      HREffects,
      SummaryEffects,
      C2Effects
    ),
    provideStoreDevtools(),
    provideAnimationsAsync(),
    provideAnimationsAsync(),
    provideRouterStore()
  ],
};
