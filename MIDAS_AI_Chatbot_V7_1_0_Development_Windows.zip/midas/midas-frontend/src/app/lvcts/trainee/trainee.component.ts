import { Component, inject, signal } from '@angular/core';
import { ActivatedRoute, Router, RouterOutlet } from '@angular/router';
import { MatFormField, MatLabel } from '@angular/material/form-field';
import { MatOption, MatSelect, MatSelectChange } from '@angular/material/select';
import { MatDivider } from '@angular/material/divider';
import { MatIconButton } from '@angular/material/button';
import { MatIcon } from '@angular/material/icon';
import { NgClass } from '@angular/common';
import { MatTooltip } from '@angular/material/tooltip';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { map } from 'rxjs/operators';
import { httpResource } from '@angular/common/http';
import { TraineeId } from '@/models/trainee.model';
import { API_URL } from '@/app.config';

@Component({
  selector: 'app-trainee',
  template: `
    <div class="tr-report-bar">
      <mat-form-field class="tr-select">
        <mat-label>Trainee</mat-label>
        <mat-select [value]="traineeId()" (selectionChange)="onSelect($event)">
          @for (trainee of trainees.value(); track trainee.id) {
            <mat-option [value]="trainee.id">{{ trainee.name }}</mat-option>
          }
        </mat-select>
      </mat-form-field>
      <div style="flex-grow: 1"></div>
      <button
        mat-icon-button
        [ngClass]="{ 'list-view': listView() }"
        [disabled]="traineeId() === null"
        (click)="toggleListView()"
        matTooltip="Toggle detailed view"
      >
        <mat-icon>clarify</mat-icon>
      </button>
      <button
        mat-icon-button
        [disabled]="traineeId() === null"
        (click)="downloadPDF()"
        matTooltip="Download Trainee Report"
      >
        <mat-icon>print</mat-icon>
      </button>
    </div>
    <mat-divider class="hide-media-print"/>
    <div
      style="width: 100%; height: 100%"
      class="router-outlet-container"
      [ngClass]="{ 'list-view': listView() }"
    >
      @if (!outlet.isActivated) {
        <div class="placeholder">
          <h3>Please select a trainee to view their report.</h3>
        </div>
      }
      <router-outlet #outlet="outlet"></router-outlet>
    </div>
  `,
  imports: [
    RouterOutlet,
    MatFormField,
    MatLabel,
    MatSelect,
    MatOption,
    MatDivider,
    MatIconButton,
    MatIcon,
    NgClass,
    MatTooltip
  ],
  styles: `
    .placeholder {
      padding: 10px;
      margin: 10px;
      color: whitesmoke;
      text-align: center;
    }

    .tr-report-bar {
      display: flex;
      align-items: center;

      button {
        margin: 10px;
      }

      .list-view {
        background-color: rgba(255, 255, 255, 0.15);
      }
    }

    .tr-select {
      transform: translateY(5px);
    }

    .router-outlet-container {
      overflow: auto;
    }

    :host-context /deep/ {
      .list-view {
        app-trainee-report {
          mat-divider {
            display: none !important;
          }

          mat-card {
            background-color: transparent !important;
            border-color: transparent !important;
            box-shadow: none !important;
          }

          app-trainee-report-details {
            .grid {
              grid-template-columns: 1fr !important;
            }
          }
        }
      }
    }

    @media print {
      .router-outlet-container {
        overflow: visible !important;
      }
    }
  `
})
export class TraineeComponent {
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private routeId$ = this.route.paramMap.pipe(
    takeUntilDestroyed(),
    map(() => this.route.snapshot.firstChild?.paramMap.get('traineeId') ?? null)
  );

  listView = signal(false);
  traineeId = signal<string | null>(null);
  trainees = httpResource<TraineeId[]>(() => ({
    url: `${API_URL}/lvcts/trainee`,
    method: 'GET'
  }), {
    defaultValue: []
  });

  constructor() {
    this.routeId$.subscribe(routeId => this.traineeId.set(routeId));
  }

  onSelect(event: MatSelectChange<string>) {
    this.router.navigate([event.value], { relativeTo: this.route }).then(() => this.traineeId.set(event.value));
  }

  downloadPDF() {
    window.print();
  }

  toggleListView() {
    this.listView.set(!this.listView());
  }

}
