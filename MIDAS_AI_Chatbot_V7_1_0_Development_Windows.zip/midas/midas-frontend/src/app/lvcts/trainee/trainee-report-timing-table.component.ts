import { Component, input } from '@angular/core';
import { MatCard, MatCardContent, MatCardHeader, MatCardTitle } from '@angular/material/card';
import {
  MatCell,
  MatCellDef,
  MatColumnDef,
  MatHeaderCell,
  MatHeaderCellDef,
  MatHeaderRow,
  MatHeaderRowDef,
  MatRow,
  MatRowDef,
  MatTable
} from '@angular/material/table';
import { TargetTiming } from '@/models/trainee.model';

@Component({
  selector: 'app-trainee-report-timing-table',
  template: `
    <mat-card class="target-card">
      <mat-card-header>
        <mat-card-title>Target Timings</mat-card-title>
      </mat-card-header>
      <br/>
      <mat-card-content>
        <table mat-table [dataSource]="dataSource()" class="full-width">

          <ng-container matColumnDef="targetId">
            <th mat-header-cell *matHeaderCellDef>Target ID</th>
            <td mat-cell *matCellDef="let t">{{ t.targetId }}</td>
          </ng-container>

          <ng-container matColumnDef="timeObsToLrf">
            <th mat-header-cell *matHeaderCellDef>Obs → LRF</th>
            <td mat-cell *matCellDef="let t">{{ t.timeObsToLrf }}</td>
          </ng-container>

          <ng-container matColumnDef="timeLrfToFirstShot">
            <th mat-header-cell *matHeaderCellDef>LRF → First Shot</th>
            <td mat-cell *matCellDef="let t">{{ t.timeLrfToFirstShot }}</td>
          </ng-container>

          <ng-container matColumnDef="timeFirstShotToEliminated">
            <th mat-header-cell *matHeaderCellDef>First Shot → Eliminated</th>
            <td mat-cell *matCellDef="let t">{{ t.timeFirstShotToEliminated }}</td>
          </ng-container>

          <tr mat-header-row *matHeaderRowDef="columns"></tr>
          <tr mat-row *matRowDef="let _row; columns: columns;"></tr>
        </table>
      </mat-card-content>
    </mat-card>
  `,
  imports: [
    MatCard,
    MatCardHeader,
    MatCardTitle,
    MatCardContent,
    MatHeaderRow,
    MatRow,
    MatRowDef,
    MatHeaderRowDef,
    MatColumnDef,
    MatHeaderCell,
    MatCell,
    MatTable,
    MatHeaderCellDef,
    MatCellDef
  ],
  styles: `
    .full-width { width: 100%; }
    .target-card { margin-bottom: 16px; }
    @media print {
      .target-card {
        break-inside: avoid !important;
      }
    }
  `
})
export class TraineeReportTimingTableComponent {
  columns: string[] = [
    'targetId',
    'timeObsToLrf',
    'timeLrfToFirstShot',
    'timeFirstShotToEliminated'
  ];
  dataSource = input.required<TargetTiming[]>();
}
