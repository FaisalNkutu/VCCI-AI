import { Component, computed, inject } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { MatProgressSpinner } from '@angular/material/progress-spinner';
import {
  MatCard,
  MatCardAvatar,
  MatCardContent,
  MatCardHeader,
  MatCardSubtitle,
  MatCardTitle
} from '@angular/material/card';
import { MatIcon } from '@angular/material/icon';
import { NgClass, UpperCasePipe } from '@angular/common';
import { TraineeReportDetailsComponent } from '@/lvcts/trainee/trainee-report-details.component';
import { TraineeReportTimingTableComponent } from '@/lvcts/trainee/trainee-report-timing-table.component';
import { ErrorDisplayComponent } from '@/directives/error-msg.directive';
import { ActivatedRoute } from '@angular/router';
import { map } from 'rxjs/operators';
import { httpResource } from '@angular/common/http';
import { TraineeReport } from '@/models/trainee.model';
import { API_URL } from '@/app.config';

@Component({
  selector: 'app-trainee-report',
  imports: [
    MatProgressSpinner,
    MatCard,
    MatCardContent,
    MatCardHeader,
    MatIcon,
    MatCardAvatar,
    MatCardTitle,
    MatCardSubtitle,
    NgClass,
    UpperCasePipe,
    TraineeReportDetailsComponent,
    TraineeReportTimingTableComponent,
    ErrorDisplayComponent
  ],
  template: `
    <div class="report-container">
      @if (isLoading()) {
        <mat-spinner class="spinner" mode="indeterminate"/>
      }
      @if (error()) {
        <mat-card class="error-card">
          <mat-card-content>
            <app-error-display [error]="error()"/>
          </mat-card-content>
        </mat-card>
      }
      @let report = traineeResource.value();
      @if (report) {
        <mat-card class="header-card">
          <mat-card-header>
            <mat-icon mat-card-avatar class="header-avatar">military_tech</mat-icon>
            <mat-card-title>Trainee Report: {{ report.trainee }}</mat-card-title>
            <mat-card-subtitle>
              {{ report.position }} · {{ report.btsCompleted }} · {{ report.trainingLevel }}
            </mat-card-subtitle>
          </mat-card-header>
          <mat-card-content style="display: flex; gap: 10px;">
            <span class="badge" [ngClass]="report.result === 'pass' ? 'badge-pass' : 'badge-fail'">
              <span class="badge-start">RESULT</span>
              <span class="badge-end">{{ report.result | uppercase }}</span>
            </span>
            <span class="badge" [ngClass]="report.scenarioOutcome === 'success' ? 'badge-pass' : 'badge-fail'">
              <span class="badge-start">SCENARIO</span>
              <span class="badge-end">{{ report.scenarioOutcome | uppercase }}</span>
            </span>
          </mat-card-content>
        </mat-card>
        <app-trainee-report-details [traineeReport]="report"/>
        <app-trainee-report-timing-table [dataSource]="report.targetTimings"/>
      }
    </div>
  `,
  styles: `
    :host {
      color: whitesmoke;
    }

    .header-avatar {
      padding: 10px;
      transform: scale(1.5);
    }

    .report-container {
      padding: 24px;
      margin: auto;
    }

    .spinner {
      margin: 80px auto;
      display: block;
    }

    .header-card {
      margin-bottom: 16px;
    }

    .badge {
      display: flex;
      align-items: center;
      border-radius: 100px;
      font-size: 12px;
      font-weight: 500;
      line-height: 1.5;
      white-space: nowrap;
      border: 1px solid transparent;
      cursor: default;
      overflow: hidden;
      padding: 0;
      width: fit-content;

      .badge-start, .badge-end {
        padding: 2px 8px;
        display: flex;
        align-items: center;
      }
    }

    .badge-pass {
      color: #e8f5e9;
      background-color: #2e7d32;
      border: 2px solid #2e7d32;

      .badge-end {
        background-color: rgba(0, 0, 0, 0.8);
        border-left: 1px solid #2e7d32;
      }
    }

    .badge-fail {
      color: #ffebee;
      background-color: #c62828;
      border: 2px solid #c62828;

      .badge-end {
        background-color: rgba(0, 0, 0, 0.8);
        border-left: 1px solid #c62828;
      }
    }
  `
})
export class TraineeReportComponent {
  private route = inject(ActivatedRoute);

  traineeId = toSignal(
    this.route.paramMap.pipe(
      map(() => this.route.snapshot.paramMap.get('traineeId') ?? null)
    ),
    { initialValue: this.route.snapshot.paramMap.get('traineeId') ?? null }
  );
  traineeResource = httpResource<TraineeReport | undefined>(() => {
    const traineeId = this.traineeId();
    if (!traineeId) {
      return undefined;
    }
    return {
      url: `${API_URL}/lvcts/trainee/report`,
      method: 'GET',
      params: { traineeId }
    };
  }, {
    defaultValue: undefined
  })
  isLoading = computed(() => this.traineeResource.isLoading());
  error = computed(() => this.traineeResource.error());
}
