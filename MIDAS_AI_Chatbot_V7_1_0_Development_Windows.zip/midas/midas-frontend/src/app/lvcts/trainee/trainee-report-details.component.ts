import { Component, computed, input } from '@angular/core';
import { MatCard, MatCardContent, MatCardHeader, MatCardTitle } from '@angular/material/card';
import { TraineeReport } from '@/models/trainee.model';
import { MatDivider, MatList, MatListItem } from '@angular/material/list';

export interface CardData {
  title: string;
  list: {
    label: string;
    value: string;
  }[]
}

@Component({
  selector: 'app-trainee-report-details',
  template: `
    <div class="grid">
      @for (card of cardItems(); track card.title) {
        <mat-card>
          <mat-card-header>
            <mat-card-title>{{ card.title }}</mat-card-title>
          </mat-card-header>

          <mat-card-content>
            <mat-list>
              @for (item of card.list; track item.label; let last = $last) {
                <mat-list-item>
                  <div style="display: flex">
                    <span class="label">{{ item.label }}</span>
                    <span class="value">{{ item.value }}</span>
                  </div>
                </mat-list-item>

                @if (!last) {
                  <mat-divider></mat-divider>
                }
              }
            </mat-list>
          </mat-card-content>
        </mat-card>
      }
    </div>
  `,
  imports: [
    MatCard,
    MatCardHeader,
    MatCardTitle,
    MatCardContent,
    MatList,
    MatListItem,
    MatDivider
  ],
  styles: `
    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 16px;
      margin: 16px 0;
    }

    .label {
      font-weight: 500;
      align-items: center;
    }

    mat-list-item {
      height: 40px !important;
    }

    .value {
      margin-left: auto;
      color: rgba(255,255,255,0.6);
    }
  `
})
export class TraineeReportDetailsComponent {
  traineeReport = input.required<TraineeReport>();
  cardItems = computed(() => {
    const report = this.traineeReport();
    return [
      {
        title: 'Timeline',
        list: [
          { label: 'First Contact', value: report.timeOfFirstContact },
          { label: 'Attack Start', value: report.attackStart },
          { label: 'Attack End', value: report.attackEnd },
          { label: 'Consolidation Start', value: report.consolidationStart },
          { label: 'Consolidation End', value: report.consolidationEnd }
        ]
      },
      {
        title: 'Casualties',
        list: [
          { label: 'Friendly Personnel', value: String(report.friendlyPersonnelCasualties) },
          { label: 'Friendly Vehicles', value: String(report.friendlyVehicleCasualties) },
          { label: 'Enemy Personnel', value: String(report.enemyPersonnelCasualties) },
          { label: 'Enemy Vehicles', value: String(report.enemyVehicleCasualties) }
        ]
      },
      {
        title: 'Marksmanship',
        list: [
          { label: 'Shots Fired', value: String(report.shotsFired) },
          { label: 'Hits', value: String(report.hits) },
          { label: 'Missed', value: String(report.missed) },
          { label: 'Accuracy', value: report.accuracy },
          { label: 'Aiming Deviation', value: String(report.aimingDeviation) }
        ]
      },
      {
        title: 'Movement',
        list: [
          { label: 'Km Driven', value: String(report.kmsDriven) },
          { label: 'Time in Vehicle', value: report.timeInVehicle },
          { label: 'Time in Motion', value: report.timeInMotion },
          { label: 'Time in Place', value: report.timeInPlace },
          { label: 'Time in ORV', value: report.timeInOrv },
          { label: 'Time in Attack Position', value: report.timeInAttackPosn }
        ]
      }
    ];
  });
}
