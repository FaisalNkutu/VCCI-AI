import { computed, effect, Injectable, signal } from '@angular/core';
import { HttpClient, httpResource } from '@angular/common/http';

import { API_URL } from '@/app.config';
import { UnitFilterResponse } from '@/models/unit.model';
import { FilterValue } from './unit-filter.component';

@Injectable({
  providedIn: 'root'
})
export class UnitService {
    filters = signal<Record<string, FilterValue>>({});
    aggregateFields = signal<string[]>(['unit', 'vehicle type', 'trainee']);
    fieldsResponse = httpResource<UnitFilterResponse>(() => ({
        url: `${API_URL}/mdvt/fields`,
        method: 'GET'
    }));

    filterData = signal<Record<string, any>>({});
    unitData = signal<Record<string, any>>({});

    constructor(private http: HttpClient) {
        effect(() => {
            const fields = this.fieldsResponse.value()?.fields;

            if (!fields?.length) return;

            fields.forEach(field => {
                this.http.get<{ records: string[] }>(`${API_URL}/mdvt/aggregate`, {
                    params: {
                        metric: field,
                        filters: JSON.stringify(this.filters())
                    }
                })
                .subscribe(({ records }) => {
                    this.filterData.update(current => ({...current, [field]: records }));
                });
            });
        });
    }
    
    traineeData = this.fetchMDVTData('trainee', 'unit,role');
    vehicleData = this.fetchMDVTData('vehiclename', 'KMdriven,timevehoccupied,timeinmotion,timeinplace, vehicletype');
    scenarioData = this.fetchMDVTData('scenario', 'trainee,scenariorun,traineeresult');
    btsData = this.fetchMDVTData('BTS', ',trainee');
    trainingLevelsData = this.fetchMDVTData('traininglevels', 'trainee');
    targetEngagementsData = this.fetchMDVTData('accuracy', '1st-to-eliminated,obs-to-LRF,LRF-to-1st');

    personsData = computed(() => {
        const records = this.traineeData.value()?.records ?? [];

        const roleCounts: Record<string, Set<string>> = {};

        for (const record of records) {
            if (!roleCounts[record.role]) {
                roleCounts[record.role] = new Set();
            }

            roleCounts[record.role].add(record.trainee);
        }

        const entries = Object.entries(roleCounts).map(
            ([title, trainees]) => ({ title, count: trainees.size })
        );

        const total = new Set(records.map(r => r.trainee)).size;

        return { total, entries };
    });


    btsCompleted = computed(() => this.btsData.value()?.records.length);

    passedScenarios = this.getScenariosByResult('pass');
    failedScenarios = this.getScenariosByResult('fail');

    passData = computed(() => {
        const traineeStats: Record<string, { passed: number; total: number }> = {};

        this.scenarioData.value()?.records.forEach(record => {
            if (!traineeStats[record.trainee]) {
                traineeStats[record.trainee] = {
                    passed: 0,
                    total: 0
                };
            }

            traineeStats[record.trainee].total++;

            if (record.traineeresult?.toLowerCase() === 'pass') {
                traineeStats[record.trainee].passed++;
            }
        });

        return Object.entries(traineeStats).map(([name, stats]) => ({
            percentile: 1,
            name,
            percentage: Math.round((stats.passed / stats.total) * 100)
        }));
    });

    trainingLevels = computed(() => {
        const counts: Record<string, number> = {};

        (this.trainingLevelsData.value()?.records ?? []).forEach(record => {
            counts[record.traininglevels] =
                (counts[record.traininglevels] || 0) + 1;
        });

        return Object.entries(counts).map(([name, count]) => ({
            name,
            count
        }));
    });

    aggregateTableData = httpResource<{ records: any[] }>(() => {
        const filters = this.filters();

        const selectedFields = this.aggregateFields();

        if (!selectedFields.length) {
            return undefined;
        }

        const metric = selectedFields[0];
        const groupbys = selectedFields.slice(1).join(',');

        return {
            url: `${API_URL}/mdvt/aggregate`,
            method: 'GET',
            params: {
            metric,
            ...(groupbys ? { groupbys } : {}),
            filters: JSON.stringify(filters)
            }
        };
    });

    private getScenariosByResult(result: 'pass' | 'fail') {
        return computed(() => {
            const counts: Record<string, number> = {};

            this.scenarioData.value()?.records.forEach(record => {
                if (record.traineeresult?.toLowerCase() === result) {
                    counts[record.scenario] = (counts[record.scenario] || 0) + 1;
                }
            });

            return Object.entries(counts);
        });
    }

    private fetchMDVTData(metric: string, groupbys?: string) {
        return httpResource<{ records: any[] }>(() => {
            const filters = this.filters();

            return {
                url: `${API_URL}/mdvt/aggregate`,
                method: 'GET',
                params: {
                    metric,
                    ...(groupbys ? { groupbys } : {}),
                    filters: JSON.stringify(filters)
                }
            }
        });
    }
}