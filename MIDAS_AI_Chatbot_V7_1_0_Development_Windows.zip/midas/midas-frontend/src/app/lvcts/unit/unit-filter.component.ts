import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { MatExpansionModule } from '@angular/material/expansion';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';

import { UnitService } from './unit.service';

type CheckboxFilter = string[];

type RangeFilter = {
  min?: number | null;
  max?: number | null;
};

export type FilterValue = CheckboxFilter | RangeFilter;

@Component({
  selector: 'app-unit-filter',
  imports: [
    MatExpansionModule,
    MatCheckboxModule,
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
    FormsModule
  ],
  template: `
    <div class="h-full w-full text-white">
      <div class="flex justify-between items-center p-4">
        <h2 class="text-xl font-bold">
          Filters
          @if (activeFilterCount()) {
            <span>({{ activeFilterCount() }})</span>
          }
        </h2>

        @if (activeFilterCount()) {
          <button
            mat-button
            class="border border-gray-700 rounded-lg"
            (click)="resetFilters()"
          >
            Reset Filters
          </button>
        }
      </div>

      @for (field of visibleFields(); track field) {
        <mat-expansion-panel>
          <mat-expansion-panel-header>
            <mat-panel-title>
              {{ field }}
            </mat-panel-title>

            @if (!defaultFields.includes(field)) {
              <button
                mat-button
                (click)="$event.stopPropagation(); removeField(field)"
              >
                ✕
              </button>
            }
          </mat-expansion-panel-header>

          @if (hasCheckboxData(field)) {
            @for (option of getOptions(field); track option) {
              <mat-checkbox
                [checked]="isSelected(field, option)"
                (change)="toggleCheckbox(field, option)"
              >
                {{ option }}
              </mat-checkbox>
              <br />
            }
          } @else {
            <div class="flex flex-col gap-2">
              <mat-form-field>
                <mat-label>Min</mat-label>
                <input
                  matInput
                  type="number"
                  [ngModel]="getRange(field, 'min')"
                  (blur)="updateRange(field, $any($event.target).valueAsNumber, 'min')"
                />
              </mat-form-field>

              <mat-form-field>
                <mat-label>Max</mat-label>
                <input
                  matInput
                  type="number"
                  [ngModel]="getRange(field, 'max')"
                  (blur)="updateRange(field, $any($event.target).valueAsNumber, 'max')"
                />
              </mat-form-field>
            </div>
          }
        </mat-expansion-panel>
      }

      @if (availableFields().length) {
        <mat-expansion-panel>
          <mat-expansion-panel-header>
            <mat-panel-title>
              Add Field
            </mat-panel-title>
          </mat-expansion-panel-header>

          @for (field of availableFields(); track field) {
            <button
              mat-button
              class="w-full text-left"
              (click)="addField(field)"
            >
              {{ field }}
            </button>
          }
        </mat-expansion-panel>
      }
    </div>
  `
})
export class UnitFilterComponent {
  private unitService = inject(UnitService);

  readonly defaultFields = [
    'unit',
    'vehicle type',
    'trainee'
  ];

  addedFields = signal<string[]>([]);

  filters = signal<Record<string, FilterValue>>({});

  fields = computed(
    () => this.unitService.fieldsResponse.value()?.fields ?? []
  );

  visibleFields = computed(() => [
    ...this.defaultFields,
    ...this.addedFields()
  ]);

  availableFields = computed(() =>
    this.fields().filter(
      field =>
        !this.defaultFields.includes(field) &&
        !this.addedFields().includes(field)
    )
  );

  filterData = this.unitService.filterData;

  data = computed<Record<string, string[]>>(() => {
    const filterData = this.filterData();

    return Object.fromEntries(
      Object.entries(filterData).map(([field, records]) => [
        field,
        records.map((record: any) => record[field]).filter(Boolean)
      ])
    );
  });

  activeFilterCount = computed(() => {
    const values = Object.values(this.filters());

    return values.reduce((count, value) => {
      if (Array.isArray(value)) {
        return count + value.length;
      }

      if (value?.min != null || value?.max != null) {
        return count + 1;
      }

      return count;
    }, 0);
  });

  addField(field: string) {
    if (this.addedFields().includes(field)) {
      return;
    }

    this.addedFields.update(fields => [...fields, field]);
  }

  removeField(field: string) {
    this.addedFields.update(fields =>
      fields.filter(f => f !== field)
    );

    this.filters.update(current => {
      const updated = { ...current };

      delete updated[field];

      return updated;
    });

    this.applyFilters();
  }

  hasCheckboxData(field: string): boolean {
    return field in this.data();
  }

  getOptions(field: string): string[] {
    return this.data()[field] ?? [];
  }

  getRange(
    field: string,
    type: 'min' | 'max'
  ): number | null | undefined {
    return (this.filters()[field] as RangeFilter | undefined)?.[type];
  }

  isSelected(field: string, value: string): boolean {
    return ((this.filters()[field] as string[]) ?? []).includes(value);
  }

  applyFilters() {
    this.unitService.filters.set(this.filters());
  }

  toggleCheckbox(field: string, value: string) {
    this.filters.update(currentFilters => {
      const existing = (currentFilters[field] as string[]) ?? [];

      const updated = existing.includes(value)
        ? existing.filter(v => v !== value)
        : [...existing, value];

      return {
        ...currentFilters,
        updated
      };
    });

    this.applyFilters();
  }

  updateRange(
    field: string,
    value: number | null,
    type: 'min' | 'max'
  ) {
    this.filters.update(currentFilters => {
      const existing =
        (currentFilters[field] as RangeFilter) ?? {};

      if (Number.isNaN(value)) {
        delete existing[type];
      } else {
        existing[type] = value;
      }

      return {
        ...currentFilters,
        existing
      };
    });

    this.applyFilters();
  }

  resetFilters() {
    this.filters.set({});
    this.applyFilters();
  }
}