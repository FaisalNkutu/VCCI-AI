import { Component, computed, signal } from '@angular/core';
import { MatIconButton } from '@angular/material/button';
import { MatIcon } from '@angular/material/icon';
import { MatTooltip } from '@angular/material/tooltip';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatTableModule } from '@angular/material/table'; // Imported MatTableModule for the table directives
import { MatListModule } from '@angular/material/list';
import { UnitFilterComponent } from './unit-filter.component';

import { inject } from '@angular/core';
import { UnitService } from './unit.service';

@Component({
  selector: 'app-unit',
  imports: [
    MatExpansionModule,
    MatIcon,
    MatIconButton,
    MatListModule,
    MatTableModule,
    MatTooltip,
    UnitFilterComponent,
  ],
  template: `
    <div class="title">
      <h2>Unit Report</h2>
      <div style="flex-grow: 1"></div>
      <button
        mat-icon-button
        matTooltip="Filter Unit Report"
        class="hide-media-print"
      >
        <mat-icon>filter_alt</mat-icon>
      </button> 
      <button
        mat-icon-button
        matTooltip="Download Unit Report"
        class="hide-media-print"
        (click)="downloadPDF()"
      >
        <mat-icon>print</mat-icon>
      </button>
    </div>
    <div class="flex flex-row w-full gap-4 h-full overflow-y-auto">
      <div class="w-1/4">
        <app-unit-filter />
      </div>
      <div class="w-3/4">
        <div class="flex gap-4">
          <div class="w-1/3 text-white pt-2">
            <p class="pl-4">BTS Completed: {{ btsCompleted() }}</p>
            <p class="pl-4">Scenarios Completed: {{ scenariosCompletedCount() }}</p>
            <mat-expansion-panel class="pt-2" style="grid-column: span 1">
              <mat-expansion-panel-header>
                <mat-panel-title>Training Levels</mat-panel-title>
              </mat-expansion-panel-header>
              <div class="exp-container">
                @for (trainingLevel of trainingLevels(); track trainingLevel.name) {
                  <p>{{ trainingLevel.name }}: {{ trainingLevel.count }}</p>
                }
              </div>
            </mat-expansion-panel>
          </div>
          <div class="w-1/3 pt-2">
            <mat-expansion-panel style="grid-column: span 1">
              <mat-expansion-panel-header>
                <mat-panel-title>Scenarios Passed: {{ scenariosPassedCount() }}</mat-panel-title>
              </mat-expansion-panel-header>
              <div class="exp-container">
                <div class="flex">
                  <div class="w-1/4">
                    <p>#</p>
                    @for (scenario of passedScenarios(); track scenario[0]) {
                      <p>{{ scenario[1] }}</p>
                    }
                  </div>
                  <div class="w-3/4">
                    <p>Scenario</p>
                    @for (scenario of passedScenarios(); track scenario[0]) {
                      <p>{{ scenario[0] }}</p>
                    }
                  </div>
                </div>
              </div>
            </mat-expansion-panel>
            <mat-expansion-panel class="pt-2" style="grid-column: span 1">
              <mat-expansion-panel-header>
                <mat-panel-title>Scenarios Failed: {{ scenariosFailedCount() }}</mat-panel-title>
              </mat-expansion-panel-header>
              <div class="exp-container">
                <div class="flex">
                  <div class="w-1/4">
                    <p>#</p>
                    @for (scenario of failedScenarios(); track scenario[0]) {
                      <p>{{ scenario[1] }}</p>
                    }
                  </div>
                  <div class="w-3/4">
                    <p>Scenario</p>
                    @for (scenario of failedScenarios(); track scenario[0]) {
                      <p>{{ scenario[0] }}</p>
                    }
                  </div>
                </div>
              </div>
            </mat-expansion-panel>
          </div>
          <div class="w-1/3 pt-2">
            <mat-expansion-panel style="grid-column: span 1">
              <mat-expansion-panel-header>
                <mat-panel-title>% Pass: {{ passPercentage() }}%</mat-panel-title>
              </mat-expansion-panel-header>
              <div class="exp-container">
                <div class="flex">
                  <div class="w-1/4">
                    <p>P</p>
                    @for (person of passData(); track person.name) {
                      <p>{{ person.percentile }}</p>
                    }
                  </div>
                  <div class="w-1/4">
                    <p>% Pass</p>
                    @for (person of passData(); track person.name) {
                      <p>{{ person.percentage }}%</p>
                    }
                  </div>
                  <div class="w-1/2">
                    <p>Name</p>
                    @for (person of passData(); track person.name) {
                      <p>{{ person.name }}</p>
                    }
                  </div>
                </div>
              </div>
            </mat-expansion-panel>
          </div>
        </div>
        <div class="flex gap-4 mt-4">
          <div class="w-1/2">
            <mat-expansion-panel style="grid-column: span 1">
              <mat-expansion-panel-header>
                <mat-panel-title># Persons: {{ personsData().total }}</mat-panel-title>
              </mat-expansion-panel-header>
              <div class="exp-container">
                @for (entry of personsData().entries; track entry.title) {
                  <p>
                    {{ entry.title }}: {{ entry.count }}
                  </p>
                }
                @for (group of groups(); track group.unit) {
                  <div class="border border-gray-700 rounded-lg p-2 mt-2">
                    <p class="font-bold">{{ group.unit }}</p>
                    @for (role of group.roles; track role.role) {
                      <p>
                        {{ role.role }}:
                        {{ role.trainees.join(', ') }}
                      </p>
                    }
                  </div>
                }
              </div>
            </mat-expansion-panel>
          </div>
          <div class="w-1/2">
            <mat-expansion-panel style="grid-column: span 1">
              <mat-expansion-panel-header>
                <mat-panel-title># Vehicles: {{ vehicleCount() }}</mat-panel-title>
              </mat-expansion-panel-header>
              <div class="exp-container">
                @for (vehicle of vehicleSummary(); track vehicle.type) {
                  <p>{{ vehicle.type }}: {{ vehicle.count }}</p>
                }
                @for (vehicle of vehicleData().vehicles; track vehicle.name) {
                  <div class="border border-gray-700 rounded-lg p-2 mt-2">
                    <p class="font-bold">{{ vehicle.name }}</p>
                    <p>Time Occupied: {{ vehicle.timeOccupied }}</p>
                    <p>Time in Motion: {{ vehicle.timeInMotion }}</p>
                    <p>Time in Place: {{ vehicle.timeInPlace }}</p>
                  </div>
                }
              </div>
            </mat-expansion-panel>
          </div>
        </div>
        <div class="mt-4 h-[28vh]">
          <div class="w-full h-full">
            <mat-expansion-panel style="grid-column: span 1">
              <mat-expansion-panel-header>
                <mat-panel-title># Target Engagements</mat-panel-title>
              </mat-expansion-panel-header>
              <div class="exp-container">
                @for (targetEngagement of targetEngagementData().targetEngagements; track targetEngagement.name) {
                  <div class="border border-gray-700 rounded-lg p-2 mt-2">
                    <h2 class="font-bold">{{ targetEngagement.name }}</h2>
                    <div class="flex mt-4">
                      <div class="w-1/4">
                        <p>Shots Fired: {{ targetEngagement.shotsFired }}</p>
                        <p>Hits: {{ targetEngagement.hits }}</p>
                        <p>Misses: {{ targetEngagement.misses }}</p>
                        <p>Accuracy: {{ targetEngagement.accuracy }}</p>
                        <p>Aim Deviation: {{ targetEngagement.aimingDeviation }}</p>
                      </div>
                      <div class="w-3/4">
                        <table
                          mat-table
                          [dataSource]="targetEngagement.targetingMetricsResults"
                          class="w-full"
                        >
                          <ng-container matColumnDef="obsToLRF">
                            <th mat-header-cell *matHeaderCellDef>Obs → LRF</th>
                            <td mat-cell *matCellDef="let row">
                              {{ row.obsToLRF }}
                            </td>
                          </ng-container>
                          <ng-container matColumnDef="lrfToFirstShot">
                            <th mat-header-cell *matHeaderCellDef>LRF → First Shot</th>
                            <td mat-cell *matCellDef="let row">
                              {{ row.lrfToFirstShot }}
                            </td>
                          </ng-container>
                          <ng-container matColumnDef="firstShotToElimination">
                            <th mat-header-cell *matHeaderCellDef>
                              First Shot → Elimination
                            </th>
                            <td mat-cell *matCellDef="let row">
                              {{ row.firstShotToElimination }}
                            </td>
                          </ng-container>
                          <tr mat-header-row *matHeaderRowDef="targetMetricColumns"></tr>
                          <tr mat-row *matRowDef="let row; columns: targetMetricColumns"></tr>
                        </table>
                      </div>
                    </div>
                  </div>
                }
              </div>
            </mat-expansion-panel>
            <div class="mt-4">
              <mat-expansion-panel expanded>
                <mat-expansion-panel-header>
                  <mat-panel-title>
                    Aggregate Data
                  </mat-panel-title>
                </mat-expansion-panel-header>
                <div class="mb-4 flex flex-wrap gap-2 items-start">
                  @for (field of tableColumns(); track field) {
                    <div
                      class="border border-gray-700 rounded-lg px-2 py-1 flex items-center gap-2"
                    >
                      <span>{{ field }}</span>
                      <button
                        mat-button
                        (click)="removeAggregateField(field)"
                      >
                        ✕
                      </button>
                    </div>
                  }
                  @if (availableAggregateFields().length) {
                    <div class="relative">
                      <button
                        mat-button
                        class="px-2 py-1 border border-gray-700 rounded-lg"
                        (click)="showAddFieldMenu.set(!showAddFieldMenu())"
                      >
                        Add Field
                      </button>
                      @if (showAddFieldMenu()) {
                        <div
                          class="absolute top-full left-0 mt-1 z-50
                                min-w-56 max-h-64 overflow-y-auto
                                bg-[#2d2d2d]
                                border border-gray-700
                                rounded-lg shadow-lg"
                        >
                          @for (field of availableAggregateFields(); track field) {
                            <button
                              mat-button
                              class="w-full justify-start"
                              (click)="addAggregateField(field); showAddFieldMenu.set(false)"
                            >
                              {{ field }}
                            </button>
                          }
                        </div>
                      }
                    </div>
                  }
                </div>
                <div class="overflow-auto">
                  <table
                    mat-table
                    [dataSource]="aggregateData()"
                    class="w-full"
                  >
                    @for (column of tableColumns(); track column) {
                      <ng-container [matColumnDef]="column">
                        <th mat-header-cell *matHeaderCellDef>
                          {{ column }}
                        </th>
                        <td mat-cell *matCellDef="let row">
                          {{ row[column] }}
                        </td>
                      </ng-container>
                    }
                    <tr
                      mat-header-row
                      *matHeaderRowDef="tableColumns()"
                    ></tr>
                    <tr
                      mat-row
                      *matRowDef="let row; columns: tableColumns()"
                    ></tr>
                  </table>
                </div>
              </mat-expansion-panel>
            </div>
          </div>
        </div>
      </div>
    </div>`,
  styles: `
    .title {
      width: 100%;
      height: 60px;
      display: flex;
      align-items: center;

      h2 {
        font-size: 1.4rem;
        color: rgb(255 255 255);
        padding: 5px;
      }
    }
  `
})
export class UnitComponent {
  private unitService = inject(UnitService);
  showAddFieldMenu = signal(false);

  traineeData = this.unitService.traineeData;

  vehicleData = computed(() => ({
    vehicles:
      this.unitService.vehicleData.value()?.records.map(vehicle => ({
        name: vehicle.vehiclename,
        type: vehicle.vehicletype,
        timeOccupied: vehicle.timevehoccupied,
        timeInMotion: vehicle.timeinmotion,
        timeInPlace: vehicle.timeinplace,
        kmDriven: vehicle.KMdriven
      })) ?? []
  }));

  targetEngagementData = computed(() => ({
    targetEngagements:
      this.unitService.targetEngagementsData.value()?.records.map(
        (record, index) => ({
          name: `Target Engagement ${index + 1}`,
          shotsFired: 0,
          hits: 0,
          misses: 0,
          aimingDeviation: 0,
          accuracy: record.accuracy,
          targetingMetricsResults: [
            {
              obsToLRF: record['obs-to-LRF'],
              lrfToFirstShot: record['LRF-to-1st'],
              firstShotToElimination: record['1st-to-eliminated']
            }
          ]
        })
      ) ?? []
  }));

  targetMetricColumns: string[] = [
    'obsToLRF',
    'lrfToFirstShot',
    'firstShotToElimination'
  ];

  personsData = this.unitService.personsData;

  groups = computed(() => {
    const records = this.traineeData.value()?.records ?? [];
    const unitMap = new Map<string, Map<string, Set<string>>>();

    for (const record of records) {
      if (!unitMap.has(record.unit)) {
        unitMap.set(record.unit, new Map());
      }

      const roleMap = unitMap.get(record.unit)!;

      if (!roleMap.has(record.role)) {
        roleMap.set(record.role, new Set());
      }

      roleMap.get(record.role)!.add(record.trainee);
    }

    return Array.from(unitMap.entries()).map(
      ([unit, roleMap]) => ({
        unit,
        roles: Array.from(roleMap.entries()).map(
          ([role, trainees]) => ({
            role,
            trainees: Array.from(trainees)
          })
        )
      })
    );
  });

  vehicleCount = computed(
    () => this.vehicleData().vehicles.length
  );

  vehicleSummary = computed(() => {
    const typeCounts: Record<string, number> = {};

    this.vehicleData().vehicles.forEach(vehicle => {
      typeCounts[vehicle.type] =
        (typeCounts[vehicle.type] || 0) + 1;
    });

    return Object.entries(typeCounts).map(
      ([type, count]) => ({
        type,
        count
      })
    );
  });

  passedScenarios = this.unitService.passedScenarios;
  failedScenarios = this.unitService.failedScenarios;

  scenariosPassedCount = computed(() =>
    this.passedScenarios().reduce(
      (total, [, count]) => total + count,
      0
    )
  );

  scenariosFailedCount = computed(() =>
    this.failedScenarios().reduce(
      (total, [, count]) => total + count,
      0
    )
  );

  scenariosCompletedCount = computed(
    () =>
      this.scenariosPassedCount() +
      this.scenariosFailedCount()
  );

  btsCompleted = this.unitService.btsCompleted;

  passPercentage = computed(() => {
    const passed = this.scenariosPassedCount();
    const failed = this.scenariosFailedCount();
    const total = passed + failed;

    return total > 0
      ? Math.round((passed / total) * 100)
      : 0;
  });

  passData = this.unitService.passData;

  trainingLevels = this.unitService.trainingLevels;

  aggregateData = computed(
    () => this.unitService.aggregateTableData.value()?.records ?? []
  );

  // NEW AGGREGATE COLUMN STATE

  aggregateFields = this.unitService.aggregateFields;

  allFields = computed(
    () => this.unitService.fieldsResponse.value()?.fields ?? []
  );

  availableAggregateFields = computed(() =>
    this.allFields().filter(
      field => !this.aggregateFields().includes(field)
    )
  );

  tableColumns = this.aggregateFields;

  addAggregateField(field: string) {
    if (this.aggregateFields().includes(field)) {
      return;
    }

    this.aggregateFields.update(fields => [
      ...fields,
      field
    ]);
  }

  removeAggregateField(field: string) {
    this.aggregateFields.update(fields =>
      fields.filter(f => f !== field)
    );
  }

  downloadPDF() {
    window.print();
  }
}