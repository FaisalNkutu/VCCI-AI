import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-lvcts',
  standalone: true,
  imports: [RouterOutlet],
  template: `
    <div class="w-full h-full p-2" style="height: calc(100% - 70px)">
      <router-outlet></router-outlet>
    </div>
  `
})
export class LvctsComponent {}
