import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
} from '@angular/core';
import { BaseChartDirective } from 'ng2-charts';
import { ChartData, ChartOptions, ChartType } from 'chart.js';
import { ChartClickEvent } from '@/models';

export interface SimChartData<T extends ChartType, K = any> {
  chartData: ChartData<T, K[]>;
  chartOptions: ChartOptions;
}

@Component({
  selector: 'chart-v2',
  standalone: true,
  imports: [BaseChartDirective],
  templateUrl: './chart-v2.component.html',
})
export class ChartComponent<T extends ChartType> implements OnChanges {
  @Input({ required: true }) simChartData: SimChartData<T, any> | null = null;
  @Input({ required: true }) type!: T;
  @Output() chartClicked: EventEmitter<any> = new EventEmitter();
  options!: ChartOptions<T>;
  data!: ChartData<T, any[]>;

  ngOnChanges(changes: SimpleChanges): void {
    if (!this.simChartData) {
      return;
    }
    this.options = this.simChartData.chartOptions as ChartOptions<T>;
    this.data = this.simChartData.chartData as ChartData<T, any[]>;
  }

  onChartClicked(event: ChartClickEvent) {
    this.chartClicked.emit(event);
  }
}
