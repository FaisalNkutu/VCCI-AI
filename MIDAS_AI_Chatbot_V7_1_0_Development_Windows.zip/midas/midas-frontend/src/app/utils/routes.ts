export const routes = {
  SUM: {
    name: 'Summary',
    route: 'summary'
  },
  HH: {
    name: 'H-Hour',
    route: 'h-hour'
  },
  ROM: {
    name: 'Rate Of Movement',
    route: 'rom'
  },
  CM: {
    name: 'CM Occupations',
    route: 'cm'
  },
  POE: {
    name: 'Picture Of Enemy',
    route: 'poe'
  },
  FRAT: {
    name: 'Fratricide',
    route: 'fratricide'
  },
  ENG: {
    name: 'Enemy Engagement',
    route: 'enemy-engagement'
  },
  CP: {
    name: 'Combat Power',
    route: 'cp'
  },
  UW: {
    name: 'Entity Watch',
    route: 'unit-watch'
  },
  HR: {
    name: 'Holdings Rollup',
    route: 'holdings-rollup'
  }
} as const;
