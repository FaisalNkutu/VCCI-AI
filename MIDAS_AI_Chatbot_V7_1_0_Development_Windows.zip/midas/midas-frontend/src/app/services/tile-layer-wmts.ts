/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */

/**
 * WMTS parameters resolved from a capabilities document and stored with the
 * map config. The sidebar still resolves these; Flex GIS consumes the URL.
 */
export type WMTSOptions = {
  layer?: string;
  style?: string;
  tileMatrixSet?: string;
  tileMatrixIds?: string[];
  format?: string;
  version?: string;
  maxNativeZoom?: number;
  maxZoom?: number;
};
