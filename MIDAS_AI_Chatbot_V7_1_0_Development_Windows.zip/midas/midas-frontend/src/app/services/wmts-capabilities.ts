/*
 * Copyright 2025 Operational and Training Technology, Calian Learning
 *                   All rights reserved.
 */


/**
 * Represents a link to a TileMatrixSet from a WMTS Layer.
 */

/**
 * Represents a parsed WMTS Layer entry from a GetCapabilities document.
 */
export interface WMTSCapabilitiesLayer {
  identifier: string;
  title: string;
  tileMatrixSet: string;
  tileMatrices: string[];
  style: string;
  format: string;
  maxNativeZoom: number;
}

export type TileMatrixSetMap = { [tileMatrixSetId: string]: string[] };
export type MaxNativeZoomMap = { [tileMatrixSetId: string]: number };

/**
 * Fetches and parses a WMTS GetCapabilities XML document from the given URL.
 *
 * This is typically used to dynamically retrieve available layers and tile matrix sets
 * from a WMTS-compliant server.
 *
 * @param url - The full URL to the WMTS GetCapabilities endpoint.
 * @returns A parsed XML Document representing the capabilities' response.
 *
 * @example
 * ```ts
 * const xml = await fetchWMTSCapabilities('https://example.com/wmts?SERVICE=WMTS&REQUEST=GetCapabilities');
 * ```
 */
export async function fetchWMTSCapabilities(url: string): Promise<Document> {
  const res = await fetch(url);
  const xmlText = await res.text();
  return new DOMParser().parseFromString(xmlText, 'application/xml');
}

function getMatrixIdIncrementer(baseId: string) {
  const match = baseId.match(/(.*?)(\d+)([^0-9]*)$/);
  if (!match) throw new Error('No number found in baseId');

  const prefix = match[1];
  const number = parseInt(match[2], 10);
  const suffix = match[3] || '';

  return function (i: number) {
    return `${prefix}${number + i}${suffix}`;
  };
}

/**
 * Parses a WMTS capabilities XML document and extracts typed layer information.
 *
 * @param xml - A `Document` object returned from `fetchWMTSCapabilities`.
 * @returns An array of `WMTSCapabilitiesLayer` objects.
 *
 * @example
 * ```ts
 * const xml = await fetchWMTSCapabilities('...');
 * const layers = parseWMTSCapabilities(xml);
 * console.log(layers[0].identifier); // e.g. 'topo'
 * ```
 */
export function parseWMTSCapabilities(xml: Document): WMTSCapabilitiesLayer[] {
  const layers = Array.from(xml.querySelectorAll('Layer'));
  const tileMatrixSets = Array.from(xml.querySelectorAll('TileMatrixSet'));

  const tileMatrixSetMap: TileMatrixSetMap = {};
  const maxNativeZoomMap: MaxNativeZoomMap = {};
  tileMatrixSets.forEach((tileMatrixSet) => {
    const tileMatrixSetId = tileMatrixSet.querySelector(
      'ows\\:Identifier, Identifier'
    )?.textContent;
    if (tileMatrixSetId) {
      let latestMatrixId = '';
      const tileMatrices: string[] = [];
      tileMatrixSet.querySelectorAll('TileMatrix').forEach((tileMatrix) => {
        const tileMatrixId = tileMatrix.querySelector(
          'ows\\:Identifier, Identifier'
        )?.textContent;
        tileMatrices.push(tileMatrixId ?? '');
        latestMatrixId = tileMatrixId ?? '0';
      });

      maxNativeZoomMap[tileMatrixSetId] = tileMatrices.length - 1;
      if (tileMatrices.length < 22) {
        const nextMatrixId = getMatrixIdIncrementer(latestMatrixId);
        const remainingCount = 23 - tileMatrices.length;
        for (let j = 1; j < remainingCount; j++) {
          tileMatrices.push(nextMatrixId(j));
        }
      }

      tileMatrixSetMap[tileMatrixSetId] = tileMatrices;
    }
  });

  const resultLayers: WMTSCapabilitiesLayer[] = [];

  layers.forEach((layer) => {
    const identifier =
      layer.querySelector('ows\\:Identifier, Identifier')?.textContent || '';
    const title = layer.querySelector('ows\\:Title, Title')?.textContent || '';
    const tileMatrixSetArray = Array.from(
      layer.querySelectorAll('TileMatrixSet')
    );

    const style =
      layer
        .querySelector('Style')
        ?.querySelector('ows\\:Identifier, Identifier')?.textContent || '';
    const format = layer.querySelector('Format')?.textContent || '';
    tileMatrixSetArray.forEach((tileMatrixSet) => {
      const tileMatrixSetId = tileMatrixSet.textContent || '';
      const matrixIds = tileMatrixSetMap[tileMatrixSetId];
      const maxNativeZoom = maxNativeZoomMap[tileMatrixSetId] || 0;
      resultLayers.push({
        identifier,
        title,
        tileMatrixSet: tileMatrixSetId,
        tileMatrices: matrixIds,
        style,
        format,
        maxNativeZoom
      });
    });
  });

  return resultLayers;
}
