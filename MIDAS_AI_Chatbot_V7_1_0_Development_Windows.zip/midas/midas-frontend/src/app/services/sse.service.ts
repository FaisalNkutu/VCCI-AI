import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SseService {

  constructor() { }

  /**
   * Creates an Observable that parses JSON data from SSE events
   * @param url The SSE endpoint URL
   * @returns Observable that emits parsed JSON data
   */

    /*
    * Improved SSE stream stability.
    *
    * Previously JSON parse errors or connection errors triggered
    * `observer.error()` and closed the EventSource, which terminated
    * the SSE stream and stopped dashboard updates until refresh.
    *
    * Changes:
    * - Log JSON parse errors instead of breaking the stream
    * - Do not close EventSource on error (allow browser auto-reconnect)
    * - Add connection/debug logs for SSE lifecycle
    */
  getServerSentEvents<T>(url: string): Observable<T> {
    return new Observable(observer => {
      console.log("[SSE] Connecting to:", url);
      const eventSource = new EventSource(url);
      eventSource.onopen = () => {
        console.log("[SSE] Connection opened");
      };


      eventSource.onmessage = (event) => {
        console.log("[SSE] Raw message:", event.data);
        try {
          const data = JSON.parse(event.data);
          observer.next(data);
        } catch (error) {
          console.error("[SSE] Failed to parse SSE data as JSON:", error);
        }
      };

      eventSource.onerror = (error) => {
        console.error("[SSE] Connection error:", error);
        //observer.error(error);
        //eventSource.close();
      };

      return () => {
        console.log("[SSE] Closing connection");
        eventSource.close();
      };
    });
  }
}
