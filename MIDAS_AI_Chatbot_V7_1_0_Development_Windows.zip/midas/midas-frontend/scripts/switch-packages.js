#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const PACKAGE_JSON_PATH = path.join(process.cwd(), 'package.json');

const LIBRARY_CONFIG = {
  '@simfront/common-libs': {
    path: 'C:/Dev/common-libs-web/web/angular/dist/common-libs',
    groups: ['common'],
    aliases: ['common-libs', 'common'],
    releaseTag: '@newarch'
  },
  '@simfront/gis-web-angular': {
    path: 'C:/Dev/jnx/dist/libs/angular',
    groups: ['gis'],
    aliases: ['angular', 'gis-angular'],
    releaseTag: '@latest'
  },
  '@simfront/gis-web-interface': {
    path: 'C:/Dev/jnx/dist/libs/interface',
    groups: ['gis'],
    aliases: ['interface', 'gis-interface'],
    releaseTag: '@latest'
  },
  '@simfront/gis-web-leaflet': {
    path: 'C:/Dev/jnx/dist/libs/leaflet',
    groups: ['gis'],
    aliases: ['leaflet', 'gis-leaflet'],
    releaseTag: '@latest'
  }
};

const ALL_LIB_NAMES = Object.keys(LIBRARY_CONFIG);

function modifyPackageJson(callback) {
  const pkg = JSON.parse(fs.readFileSync(PACKAGE_JSON_PATH, 'utf8'));
  callback(pkg);
  fs.writeFileSync(PACKAGE_JSON_PATH, JSON.stringify(pkg, null, 2) + '\n');
}

/**
 * Resolves targets based on Full Name, Group, or Alias.
 */
function resolveTargets(args) {
  if (args.length === 0) return ALL_LIB_NAMES;

  const targets = new Set();
  args.forEach(arg => {
    // 1. Check Groups (gis, common)
    const matchedGroup = ALL_LIB_NAMES.filter(name => LIBRARY_CONFIG[name].groups.includes(arg));
    if (matchedGroup.length > 0) {
      matchedGroup.forEach(n => targets.add(n));
      return;
    }

    // 2. Check Aliases (angular, interface, leaflet, common-libs)
    const matchedAlias = ALL_LIB_NAMES.find(name => LIBRARY_CONFIG[name].aliases.includes(arg));
    if (matchedAlias) {
      targets.add(matchedAlias);
      return;
    }

    // 3. Check Full Name
    if (LIBRARY_CONFIG[arg]) {
      targets.add(arg);
    }
  });

  return targets.size > 0 ? Array.from(targets) : ALL_LIB_NAMES;
}

function runPnpm(commandArgs = '') {
  const fullCommand = `pnpm install ${commandArgs}`.trim();
  console.log(`📦 Running: ${fullCommand}`);
  try {
    execSync(fullCommand, { stdio: 'inherit' });
  } catch (error) {
    console.error(' ❌ pnpm execution failed');
    process.exit(1);
  }
}

function switchToLocal(args) {
  const targets = resolveTargets(args);
  console.log(`🏠 Switching ${targets.length} packages to LOCAL...`);

  modifyPackageJson((pkg) => {
    if (!pkg.pnpm) pkg.pnpm = {};
    if (!pkg.pnpm.overrides) pkg.pnpm.overrides = {};

    targets.forEach(name => {
      const localPath = `file:${LIBRARY_CONFIG[name].path}`;
      if (pkg.dependencies && pkg.dependencies[name]) {
        pkg.dependencies[name] = localPath;
        pkg.pnpm.overrides[name] = localPath;
        console.log(`   📝 ${name} -> ${localPath}`);
      }
    });
  });

  runPnpm();
}

function switchToRelease(args) {
  const targets = resolveTargets(args);
  console.log(`🚀 Switching ${targets.length} packages to RELEASE...`);

  modifyPackageJson((pkg) => {
    targets.forEach(name => {
      if (pkg.pnpm?.overrides) delete pkg.pnpm.overrides[name];
    });
    if (pkg.pnpm && Object.keys(pkg.pnpm.overrides || {}).length === 0) delete pkg.pnpm.overrides;
    if (pkg.pnpm && Object.keys(pkg.pnpm).length === 0) delete pkg.pnpm;
  });

  const installStr = targets.map(name => `${name}${LIBRARY_CONFIG[name].releaseTag}`).join(' ');
  runPnpm(installStr);
}

function showStatus() {
  const pkg = JSON.parse(fs.readFileSync(PACKAGE_JSON_PATH, 'utf8'));
  const overrides = pkg.pnpm?.overrides || {};

  console.log('\n📊 Package Status:');
  console.log('─'.repeat(85));
  ALL_LIB_NAMES.forEach(name => {
    const ver = pkg.dependencies?.[name] || 'MISSING';
    const isLocal = ver.startsWith('file:') || !!overrides[name];
    const mode = isLocal ? '🏠 LOCAL  ' : '📦 RELEASE';
    console.log(` ${mode} | ${name.padEnd(30)} | ${ver}`);
  });
  console.log('─'.repeat(85) + '\n');
}

const [,, command, ...args] = process.argv;

switch (command) {
  case 'local':   switchToLocal(args); break;
  case 'release': switchToRelease(args); break;
  case 'status':  showStatus(); break;
  default:
    console.log(`
Usage: node switch.js [command] [target/alias]

Commands:
  local [gis|common|angular|interface|leaflet]   Link to local folders
  release [gis|common|angular|interface|leaflet] Install registry versions
  status                                         Show current links

Examples:
  node switch.js local angular
  node switch.js release common-libs
  node switch.js local gis
    `);
}
