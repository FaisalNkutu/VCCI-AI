# MIDAS + Calian AI Copilot V5.2 — bridge and command hotfix

This patches the **existing extracted V5/V5.1 project**. It is intended for the situation in which the Calian Session Inspector shows **Context shared** while MIDAS says **Bridge disconnected**, and the command `Open Combat Power` incorrectly reports **No supported MIDAS action matched**.

## Apply

1. Extract this small ZIP using **Extract All** (do not run inside the ZIP).
2. Double-click **APPLY-V5-2-BRIDGE-WINDOWS.bat**.
3. Select the installation corresponding to the MIDAS window you actually use, if multiple MIDAS copies are found.
4. Confirm `Y`. The script backs up three source files first, then applies them. It does not stop existing instances or reinstall packages.
5. Let **both** MIDAS Angular and Calian Angular recompile in their existing consoles; refresh the MIDAS browser tab. If either console reports a compile error, restore the three source backups shown by the script.
6. Select **Share dashboard context**, enter `Open Combat Power` **in the MIDAS control request input** inside Calian, and click **Propose MIDAS action**. Accept the MIDAS host approval prompt.
7. Because your screenshot shows Combat Power already open, the success message should say that this dashboard is already open. For a visible navigation test, move to Summary first, then request `Open Combat Power`.

## What changed

- Calian now sends an authenticated `BRIDGE_READY` acknowledgment for each trusted MIDAS `INIT`.
- MIDAS retries its initialization briefly until a token-valid acknowledgment arrives.
- The allowlisted command parser no longer relies on a potentially delayed capability list for known dashboard navigation. **The MIDAS host still validates every command and requires user approval.**
- An already-open dashboard is reported as a successful no-op rather than a router rejection.
- Better user-facing feedback distinguishes a disconnected bridge from an unrecognized command.

## Limits

These are **source changes validated by offline targeted tests**, not a completed Windows/Chrome end-to-end test. The changes do not connect MIDAS data sources, provide production authentication, or move active video calls. The independent browser pop-out and automatic port allocation remain unchanged.
