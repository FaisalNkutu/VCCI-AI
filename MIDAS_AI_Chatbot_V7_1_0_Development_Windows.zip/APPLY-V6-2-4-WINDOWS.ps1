param([string]$ProjectRoot = '')
$ErrorActionPreference = 'Stop'
Write-Host 'AI Chatbot + MIDAS V6.2.4 - Workspaces and Close navigation correction' -ForegroundColor Cyan
Write-Host 'This patch does not install packages or terminate existing services.'
function Resolve-Root([string]$candidate) {
  if ([string]::IsNullOrWhiteSpace($candidate) -or !(Test-Path -LiteralPath $candidate -PathType Container)) { return $null }
  $root=$candidate
  if (Test-Path -LiteralPath (Join-Path $root 'src\app\components\calian-ai\midas-calian-copilot.component.ts')) {
    $root=(Resolve-Path -LiteralPath (Join-Path $root '..\..')).Path
  } elseif (Test-Path -LiteralPath (Join-Path $root 'midas-frontend\src\app\components\calian-ai\midas-calian-copilot.component.ts')) {
    $root=(Resolve-Path -LiteralPath (Join-Path $root '..')).Path
  }
  if ((Test-Path -LiteralPath (Join-Path $root 'midas\midas-frontend\src\app\app.component.html')) -and
      (Test-Path -LiteralPath (Join-Path $root 'midas\midas-frontend\src\app\components\calian-ai\midas-calian-copilot.component.ts'))) { return $root }
  return $null
}
$root=Resolve-Root $ProjectRoot
if (!$root) {
  $choices=New-Object 'System.Collections.Generic.List[string]'
  foreach($place in @((Join-Path $env:USERPROFILE 'Downloads'),(Get-Location).Path) | Select-Object -Unique) {
    if (!(Test-Path -LiteralPath $place -PathType Container)) { continue }
    $dirs=@((Get-Item -LiteralPath $place)) + @(Get-ChildItem -LiteralPath $place -Directory -Recurse -Depth 5 -ErrorAction SilentlyContinue)
    foreach($dir in $dirs) {
      $found=Resolve-Root $dir.FullName
      if ($found -and !$choices.Contains($found)) { $choices.Add($found) }
    }
  }
  if ($choices.Count -eq 0) { throw 'MIDAS source not found. Run with -ProjectRoot "C:\path\to\your\extracted\project".' }
  Write-Host 'Choose the installation serving the MIDAS port you see in the browser.' -ForegroundColor Yellow
  for($i=0;$i -lt $choices.Count;$i++) { Write-Host ('[{0}] {1}' -f ($i+1),$choices[$i]) }
  $answer=Read-Host 'Number (blank cancels)'
  if ($answer -notmatch '^\d+$' -or [int]$answer -lt 1 -or [int]$answer -gt $choices.Count) { throw 'Cancelled without changes.' }
  $root=$choices[[int]$answer-1]
}
Write-Host ('Target project: '+$root) -ForegroundColor Cyan
$manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'PATCH_MANIFEST.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$changes=@()
foreach($entry in @($manifest)) {
  $target=Join-Path $root $entry.file
  if (!(Test-Path -LiteralPath $target -PathType Leaf)) { throw "Missing expected project source: $target" }
  $current=[IO.File]::ReadAllText($target)
  $changed=$false
  foreach($edit in @($entry.edits)) {
    $before=[string]$edit.before; $after=[string]$edit.after
    if ($current.Contains($after)) { continue }
    $first=$current.IndexOf($before,[StringComparison]::Ordinal)
    if ($first -lt 0 -or $first -ne $current.LastIndexOf($before,[StringComparison]::Ordinal)) {
      throw "Source differs from V6.2.3 at $target. Refusing to overwrite local changes."
    }
    $current=$current.Replace($before,$after); $changed=$true
  }
  if ($changed) { $changes+=@{path=$target;contents=$current} }
}
if ($changes.Count -eq 0) { Write-Host 'V6.2.4 is already applied; nothing changed.' -ForegroundColor Green; exit 0 }
foreach($change in $changes) { Write-Host ('Will patch: '+$change.path) }
$answer=Read-Host 'Type Y to back up and apply this correction'
if ($answer -notin @('Y','y')) { Write-Host 'Cancelled; no changes.'; exit 0 }
$stamp=Get-Date -Format 'yyyyMMdd-HHmmss'; $backups=@()
try {
  foreach($change in $changes) {
    $backup=$change.path+'.v6.2.4.'+$stamp+'.bak'
    Copy-Item -LiteralPath $change.path -Destination $backup -ErrorAction Stop
    $backups+=@{source=$change.path;backup=$backup}
    [IO.File]::WriteAllText($change.path,[string]$change.contents,[Text.UTF8Encoding]::new($false))
  }
  Write-Host 'Applied V6.2.4 source correction. Wait for Angular to rebuild and refresh your MIDAS browser.' -ForegroundColor Green
  foreach($item in $backups) { Write-Host ('Backup: '+$item.backup) }
} catch {
  foreach($item in $backups) { if (Test-Path -LiteralPath $item.backup) { Copy-Item -LiteralPath $item.backup -Destination $item.source -Force } }
  throw
}
