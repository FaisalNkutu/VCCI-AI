@echo off
REM Compatibility alias: always start a new free-port V4 instance.
call "%~dp0START-EVERYTHING-WINDOWS.bat"
