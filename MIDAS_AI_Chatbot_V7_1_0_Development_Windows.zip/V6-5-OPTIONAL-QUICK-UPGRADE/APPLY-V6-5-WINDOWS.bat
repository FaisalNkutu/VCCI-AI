@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLY-V6-5-WINDOWS.ps1"
if errorlevel 1 (echo Upgrade did not complete. Review the message above.)
pause
