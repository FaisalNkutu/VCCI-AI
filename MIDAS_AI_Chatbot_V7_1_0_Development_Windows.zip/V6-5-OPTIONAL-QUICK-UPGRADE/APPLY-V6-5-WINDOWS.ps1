﻿param([string]$ProjectRoot = '')
$ErrorActionPreference = 'Stop'
$patchRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$rel = 'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\app.component.scss'
$oldHash = 'fcad2fbfa6beff185252c01e9bc897d6421b88e77b2fe3fd16662574283b3309'
$newHash = '50f81f8b7434e923d26cfa2bc3fad65a1c19861a511f00f128c3f978e2607731'
function IsProject([string]$root) {
  if ([string]::IsNullOrWhiteSpace($root)) { return $false }
  return (Test-Path -LiteralPath (Join-Path $root 'midas\midas-frontend\package.json')) -and
         (Test-Path -LiteralPath (Join-Path $root 'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\package.json'))
}
Write-Host 'AI Chatbot V6.5 - Full-height Chat and Visible Send/Speak Controls' -ForegroundColor Cyan
if (-not $ProjectRoot) {
  $downloads = Join-Path $env:USERPROFILE 'Downloads'
  $candidates = New-Object System.Collections.Generic.List[string]
  $first = @(Get-ChildItem -LiteralPath $downloads -Directory -ErrorAction SilentlyContinue)
  $second = @($first | ForEach-Object { Get-ChildItem -LiteralPath $_.FullName -Directory -ErrorAction SilentlyContinue })
  $third = @($second | ForEach-Object { Get-ChildItem -LiteralPath $_.FullName -Directory -ErrorAction SilentlyContinue })
  foreach ($folder in @($first) + @($second) + @($third)) {
    if ($folder -and (IsProject $folder.FullName) -and -not $candidates.Contains($folder.FullName)) { [void]$candidates.Add($folder.FullName) }
  }
  if ($candidates.Count) {
    Write-Host 'Choose the running MIDAS project (NOT an old, idle copy):' -ForegroundColor Yellow
    for($i=0;$i -lt $candidates.Count;$i++){ Write-Host ('{0}. {1}' -f ($i+1),$candidates[$i]) }
    $choice = Read-Host 'Number (or Enter for a custom path)'
    $index = 0
    if([int]::TryParse($choice,[ref]$index) -and $index -ge 1 -and $index -le $candidates.Count){ $ProjectRoot=$candidates[$index-1] }
  }
  if(-not $ProjectRoot){ $ProjectRoot=Read-Host 'Full MIDAS + AI Chatbot source project path' }
}
$ProjectRoot = $ProjectRoot.Trim().Trim('"')
if(-not (IsProject $ProjectRoot)){ throw "Project root not found: $ProjectRoot" }
$dest = Join-Path $ProjectRoot $rel
$patch = Join-Path $patchRoot ('PATCH_FILES\'+$rel)
if(-not (Test-Path -LiteralPath $dest) -or -not (Test-Path -LiteralPath $patch)){throw 'Source or patch stylesheet missing.'}
$hash = (Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash.ToLowerInvariant()
if($hash -eq $newHash){ Write-Host 'V6.5 is already applied.' -ForegroundColor Green; exit 0 }
if($hash -ne $oldHash){ throw 'Source differs from the original V6.4 stylesheet. No file changed. Select your V6.4 project or merge manually.' }
if((Get-FileHash -LiteralPath $patch -Algorithm SHA256).Hash.ToLowerInvariant() -ne $newHash){ throw 'Patch checksum failed.' }
Write-Host "Selected: $ProjectRoot" -ForegroundColor Cyan
if((Read-Host 'Type APPLY to back up the stylesheet and install V6.5') -cne 'APPLY'){ Write-Host 'Cancelled.'; exit 0 }
$backup = Join-Path $ProjectRoot ('BACKUPS\AI_Chatbot_V6_5_'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
$backupFile = Join-Path $backup $rel
New-Item -ItemType Directory -Path (Split-Path -Parent $backupFile) -Force | Out-Null
Copy-Item -LiteralPath $dest -Destination $backupFile
try {
 Copy-Item -LiteralPath $patch -Destination $dest -Force
 if((Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash.ToLowerInvariant() -ne $newHash){ throw 'Updated stylesheet failed hash verification.' }
} catch {
 Copy-Item -LiteralPath $backupFile -Destination $dest -Force
 throw
}
Write-Host 'V6.5 stylesheet applied. MIDAS files, services, ports, video and agents unchanged.' -ForegroundColor Green
Write-Host 'Check Angular watch-mode compilation; refresh the browser with Ctrl+Shift+R.'
Write-Host ('Backup created: '+$backupFile)
