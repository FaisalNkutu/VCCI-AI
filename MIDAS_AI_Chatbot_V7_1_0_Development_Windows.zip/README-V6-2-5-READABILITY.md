# MIDAS + AI Chatbot V6.2.5 — Typography and Response Reading Layout

This release updates the **existing V6.2.4** source, without changing agent routing, session handoff, MIDAS bridge permissions, live video, port allocation, or backend services.

## 1. MIDAS Summary cards

**Problem:** Summary had five hard-coded columns (`cols="5"` and square tiles), while the chatbot could shrink MIDAS to a few hundred pixels. The `Processor Status` heading used a 48px font, and the metrics used up to 60px. That made cards cramped and hard to read.

**Change:** Summary observes its own rendered width and automatically uses 2, 3, 4, or 5 grid columns. Card rows have enough vertical space for text, card padding is reduced, the processor heading is ~21–28px, card headings ~16px, and counters ~30px. The metrics, computed values, data sources, and original MIDAS routes are unchanged. The adjustment happens when you drag the AI Chatbot panel width, without reloading.

## 2. AI Chatbot conversation reading area

**Problem:** Replies were shown in small 13px bubbles within a short conversation box, while agent registry, dashboard tools and Session Inspector consumed space.

**Change:** Look for a **Read responses** button on the Conversation card header. It temporarily hides sidebar, inspector, summary metrics and the composer, then fills the existing iframe or popup with a large scrollable conversation view. Reply text is 16px with more line spacing. Click **Back to chat** to restore the normal composer and tools. The response viewer never closes or remounts the popup/iframe and does not change conversation history. The normal chat reply font is slightly increased to 14px.

To read the widest view: **Expand** the embedded AI Chatbot first, or use **Pop out** and choose Large, then click Read responses inside the chatbot. Side-panel width slider still works and retains its settings.

When speaking/recording, Read responses is disabled so microphone stop controls remain accessible. This is not a new agent feature, and does not fetch additional MIDAS data.

## Apply to your running V6.2.4 installation

1. Extract the `MIDAS_AI_Chatbot_V6_2_5_Readability_Quick_Fix.zip` into a separate folder.
2. Run `APPLY-V6-2-5-WINDOWS.bat`. Choose the installation whose URL/port you are currently viewing. If no project is found, invoke the PowerShell script with `-ProjectRoot "C:\path\to\your\extracted\source"`.
3. Confirm the five file updates. The script checks original SHA-256 hashes, makes timestamped backups and **refuses to overwrite unknown local changes**.
4. Allow both Angular watchers to recompile, then refresh your exact MIDAS browser URL using **Ctrl+Shift+R**.
5. On MIDAS Summary, adjust the panel width between Narrower / Wider: card headings should remain proportionate and the number of columns should adapt.
6. Open AI Chatbot, send or load an existing answer, and click **Read responses**; verify 16px readable answer text, scrolling, and **Back to chat**. Test again inside the independent Pop out.

## Troubleshooting

- **No Read responses button:** You probably patched a different source copy or are viewing an old port. Check the active Angular watcher and source folder.
- **Card layout still huge:** Confirm Summary browser hard refresh; check MIDAS Angular console for compile errors.
- **Script refuses to apply:** It detected a different source version or local edits. Do not overwrite manually; compare the backed-up source and request a version-aware merge.
- **Chat with no assistant reply:** The viewer can only display existing conversation data; it does not restore missing data or fix disconnected agents.

**Validation:** Source-level invariants and TypeScript syntax checks, plus ZIP integrity checks were performed here. An end-to-end Windows Angular build and browser resize test were not possible in this environment because the private MIDAS registry and running backend are not accessible. Keep the backup and validate in development before deploying.
