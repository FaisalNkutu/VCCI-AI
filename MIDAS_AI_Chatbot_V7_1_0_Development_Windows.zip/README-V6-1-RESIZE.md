# AI Chatbot V6.1 — Visible Resizing Controls

This is a **UI-only refinement to V6**, not a different agent orchestration backend.

### Change
The width slider had been hidden among the crowded main toolbar controls, and it was absent in expanded/full-page mode. In V6.1 a high-contrast **↔ Resize AI Chatbot** bar is permanently visible directly **below the MIDAS AI Chatbot toolbar** in side-panel mode. It has **− Narrower**, **Width slider**, **+ Wider**, **Reset**, and a live pixel readout. A vertical grab handle appears on the **left edge** of the embedded panel; drag it left to widen or right to narrow. Keyboard Left/Right arrows work when the handle has focus. The selected width is remembered in the browser's local storage.

In expanded/full-page mode the bar explains why side-panel resizing is unavailable and offers **Switch to side panel to resize**. In pop-out mode, use the pop-out's independent browser window edges; the MIDAS docking control already offers Compact, Standard, Large and Center buttons. The browser may restrict programmatic moves or resizes.

### Upgrade an existing V5.3 or V6 installation
1. Extract the **V6.1 Quick Upgrade ZIP** fully.
2. Run `APPLY-V6-1-AI-CHATBOT-WINDOWS.bat`. Choose the **source tree serving the browser address that is actually open**; auto-ports may mean several installations are on your machine. The script verifies the expected MIDAS/AI Chatbot bridge signatures, asks for confirmation, backs up the affected source, and updates the V6 files with V6.1 resizing.
3. Let the Angular watchers recompile, then press **Ctrl+Shift+R** in MIDAS. Check that the header says **AI Chatbot** and the bright blue **↔ Resize AI Chatbot** bar appears immediately below the header.
4. If it does not appear, inspect the browser port and the Angular console's source directory. Your browser is likely connected to another running instance. The patch does **not** stop or restart any existing applications.

### Clean installation
Extract the full **V6.1 Windows Package** and run `START-EVERYTHING-WINDOWS.bat`. Private Simfront Artifactory access, dependencies and your configured MIDAS/AI services remain required; this ZIP is not a completely self-contained offline executable.

### Limitations and safety
- The width bar changes the **embedded side-panel width**, not Chrome/Edge browser zoom or a separately popped-out window.
- On narrow/mobile layouts MIDAS intentionally uses full-screen panel presentation; use Pop out to request an independently resizable browser window.
- This patch changes the UI component and, for previous V5.3 installs, installs the V6 functionality. It does **not** authorize additional commands, change agent routing, bypass MIDAS approval, disclose context without opt-in, or modify video code.
- Existing source files are backed up; if the selected installation contains local customizations, inspect the backup/diff before proceeding.
- Static checks and packaging are performed here; **live Windows/Angular end-to-end operation is not verified**.
