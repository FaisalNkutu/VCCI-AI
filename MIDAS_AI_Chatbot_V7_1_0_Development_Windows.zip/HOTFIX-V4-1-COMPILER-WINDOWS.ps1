﻿# MIDAS / Calian Copilot V4.1 -> V4.2 Angular compiler repair.
# Makes a source backup. Does NOT install packages or stop/change processes.
[CmdletBinding()]
param([string]$PackageRoot = '')
$ErrorActionPreference = 'Stop'
$relative = 'midas\midas-frontend\src\app\components\calian-ai\midas-calian-copilot.component.ts'
function Candidate([string]$folder) {
    if ([string]::IsNullOrWhiteSpace($folder)) { return $null }
    $file = Join-Path $folder $relative
    if (Test-Path -LiteralPath $file -PathType Leaf) { return $file }
    return $null
}
if ($PackageRoot) {
    $target = Candidate $PackageRoot
    if (-not $target) { throw "V4.1 Copilot source not found in -PackageRoot: $PackageRoot" }
} else {
    $candidateRoots = New-Object 'System.Collections.Generic.List[string]'
    [void]$candidateRoots.Add($PSScriptRoot)
    $downloads = Join-Path $env:USERPROFILE 'Downloads'
    if (Test-Path -LiteralPath $downloads -PathType Container) {
        $matches = @(Get-ChildItem -LiteralPath $downloads -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like '*MIDAS_Calian_AI_Copilot_V4_1*' })
        foreach ($dir in $matches) {
            [void]$candidateRoots.Add($dir.FullName)
            foreach ($sub in @(Get-ChildItem -LiteralPath $dir.FullName -Directory -ErrorAction SilentlyContinue)) {
                [void]$candidateRoots.Add($sub.FullName)
            }
        }
    }
    $found = @($candidateRoots | Select-Object -Unique | ForEach-Object { Candidate $_ } | Where-Object { $_ })
    if ($found.Count -eq 0) { throw "Could not locate an extracted V4.1 package under Downloads. Put the script in the extracted V4.1 root or rerun with -PackageRoot 'C:\path\to\V4.1\root'." }
    if ($found.Count -gt 1) { throw "Multiple V4.1 installations found; choose explicitly with -PackageRoot. Matches:`n$($found -join "`n")" }
    $target = $found[0]
}
$content = [System.IO.File]::ReadAllText($target)
$working = $content.Replace("`r`n", "`n")
$oldWatch = @'
    const watches = [
      this.store.select(selectSelectedTimeFormat),
      this.store.select(selectTimeFormatNames),
      this.store.select(selectCpTimeframe),
      this.store.select(selectCpSelectedEntityIds),
      this.store.select(selectCpEntities),
    ];
    for (const watch of watches) this.subscriptions.add(watch.subscribe(() => this.sendContext()));
'@
$newWatch = @'
    // Each NgRx selector has its own observable type. Subscribing separately
    // avoids calling subscribe() on a union of incompatible overload signatures.
    this.subscriptions.add(this.store.select(selectSelectedTimeFormat).subscribe(() => this.sendContext()));
    this.subscriptions.add(this.store.select(selectTimeFormatNames).subscribe(() => this.sendContext()));
    this.subscriptions.add(this.store.select(selectCpTimeframe).subscribe(() => this.sendContext()));
    this.subscriptions.add(this.store.select(selectCpSelectedEntityIds).subscribe(() => this.sendContext()));
    this.subscriptions.add(this.store.select(selectCpEntities).subscribe(() => this.sendContext()));
'@
$fixes = @(
    [PSCustomObject]@{ Old=$oldWatch; New=$newWatch },
    [PSCustomObject]@{ Old="cpActions.timeframeChange({ payload: { start: Number(p['start']), end: Number(p['end']) } })"; New="cpActions.timeframeChange({ start: Number(p['start']), end: Number(p['end']) })" },
    [PSCustomObject]@{ Old='cpActions.entitySelected({payload:id})'; New='cpActions.entitySelected(id)' },
    [PSCustomObject]@{ Old='cpActions.entityDeselected({payload:id})'; New='cpActions.entityDeselected(id)' }
)
$changed = 0
foreach ($fix in $fixes) {
    if ($working.Contains($fix.Old)) {
        $working = $working.Replace($fix.Old, $fix.New)
        $changed++
    } elseif (-not $working.Contains($fix.New)) {
        throw 'This Copilot source differs from the expected V4.1 code; no changes were written. Apply the full V4.2 package instead.'
    }
}
if ($changed -eq 0) {
    Write-Host 'The four V4.2 corrections are already installed; nothing to do.' -ForegroundColor Green
    exit 0
}
$backup = "$target.backup-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
Copy-Item -LiteralPath $target -Destination $backup -ErrorAction Stop
$utf8NoBom = [System.Text.UTF8Encoding]::new($false)
[System.IO.File]::WriteAllText($target, $working, $utf8NoBom)
Write-Host "V4.2 Angular compiler repair applied ($changed change(s))." -ForegroundColor Green
Write-Host "Updated: $target"
Write-Host "Backup: $backup"
Write-Host 'If Angular is in watch mode it should recompile automatically.'
Write-Host 'No dependencies, ports, other processes, registry settings or lockfiles were modified.'
