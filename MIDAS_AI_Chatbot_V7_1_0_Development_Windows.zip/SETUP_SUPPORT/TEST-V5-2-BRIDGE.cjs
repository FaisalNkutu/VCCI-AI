// Focused offline tests for V5.2 MIDAS bridge and command recognition.
// Run: node SETUP_SUPPORT/TEST-V5-2-BRIDGE.cjs (requires TypeScript installed).
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const ts = require('typescript');
const root = path.resolve(__dirname, '..');
const mkSignal = (v) => { const f = () => v; f.set = x => { v = x }; return f; };
function load(rel, mocks = {}, globals = {}) {
  const filename = path.join(root, rel);
  const input = fs.readFileSync(filename, 'utf8');
  const output = ts.transpileModule(input, {fileName: filename, reportDiagnostics: true,
    compilerOptions: {module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022,
      experimentalDecorators: true}});
  const errors = (output.diagnostics || []).filter(d => d.category === ts.DiagnosticCategory.Error);
  assert.equal(errors.length, 0, `TypeScript parse errors in ${rel}`);
  const exports = {};
  vm.runInNewContext(output.outputText, {exports, require: name => mocks[name] || {},
    console, URL, crypto:globalThis.crypto, setInterval, clearInterval, setTimeout, clearTimeout,
    ...globals}, { filename });
  return exports;
}
const prefix = 'Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/src/app/';
const parser = load(prefix + 'midas-bridge.ts');
const caps = {dashboards: ['summary', 'cp'], actions: ['navigate'], approvalRequired: true};
for (const [command, expected] of [
  ['Open Combat Power', 'cp'], ['OPEN   COMBAT POWER!', 'cp'],
  ['Open the Combat Power dashboard', 'cp'], ['Switch to Summary', 'summary']]) {
  for (const availableCaps of [caps, null, {dashboards: [], actions: [], approvalRequired:true}]) {
    const action = parser.parseMidasCommand(command, null, availableCaps);
    assert.equal(action && action.params.dashboard, expected, command);
  }
}
assert.equal(parser.parseMidasCommand('Delete all records', null, null), null);
console.log('PASS: known navigation commands are recognized despite delayed or stale capabilities');

const hostWin = {messages:[],postMessage(msg,origin) {this.messages.push({msg,origin});}};
const calianWin = {parent:hostWin,opener:null,__CALIAN_MIDAS_ALLOWED_ORIGINS__:['http://127.0.0.1:4201']};
const calian = load(prefix + 'app.component.ts', {
  '@angular/core':{Component:()=>x=>x,ViewChild:()=>()=>{}},
  './midas-bridge':parser
},{window: calianWin}).AppComponent;
const c = new calian({}, {open(){}}, {run: fn => fn()});
const token = 'b58ca8e7-1683-4e61-b210-9a9a48278152';
c.onMidasMessage({source:hostWin, origin:'http://127.0.0.1:4201',data:{bridge:'MIDAS_CALIAN_V1',type:'INIT',token,capabilities:caps}});
assert.equal(c.midasConnected, true);
assert(hostWin.messages.some(x=>x.msg.type==='BRIDGE_READY'&&x.msg.token===token));
assert(hostWin.messages.some(x=>x.msg.type==='CONTEXT_REQUEST'&&x.msg.token===token));
console.log('PASS: Calian acknowledges INIT with authenticated BRIDGE_READY');

const router = {url:'/advmetrics/cp',events:{pipe:()=>({subscribe:()=>({})})},
  navigateByUrl:()=>{throw new Error('Unexpected same-route navigation')}};
const store = {selectSignal:()=>()=>[],dispatch:()=>{}};
const midas = load('midas/midas-frontend/src/app/components/calian-ai/midas-calian-copilot.component.ts',{
  '@angular/core':{Component:()=>x=>x,ViewChild:()=>()=>{},signal:mkSignal,
    inject:(t)=>({store,router,sanitizer:{bypassSecurityTrustResourceUrl:x=>x},
      ui:{open:mkSignal(true),fullPage:mkSignal(false)}})[t]},
  '@angular/platform-browser':{DomSanitizer:'sanitizer'},
  '@angular/router':{Router:'router',NavigationEnd:class{}},
  '@ngrx/store':{Store:'store'},
  'rxjs':{Subscription:class {add(){} unsubscribe(){}},filter:fn=>fn},
  '@/app.guard':{APP_PREF_KEY:'preferred'},
  '@/utils/routes':{routes:Object.fromEntries(['SUM','HH','ROM','POE','CM','FRAT','ENG','CP','UW','HR'].map(k=>[k,{route:k.toLowerCase()}]))},
  './midas-copilot-ui-state':{MidasCopilotUiState:'ui'},
},{window:{__MIDAS_CALIAN_EMBED_URL__:'http://127.0.0.1:4301/',addEventListener(){},removeEventListener(){}}}).MidasCalianCopilotComponent;
(async()=>{
  const host=new midas();
  const frame={sent:[],postMessage(msg,origin){this.sent.push({msg,origin});}};
  host.frame={nativeElement:{contentWindow:frame}};
  host.frameLoaded();
  host.onMessage({source:frame,origin:'http://127.0.0.1:4301',
    data:{bridge:'MIDAS_CALIAN_V1',type:'BRIDGE_READY',token:host.token}});
  assert.equal(host.connected(),true);
  host.shareContext.set(true);
  host.onMessage({source:frame,origin:'http://127.0.0.1:4301',
    data:{bridge:'MIDAS_CALIAN_V1',type:'ACTION_REQUEST',token:host.token,id:'request-12',
      action:'navigate',params:{dashboard:'cp'}}});
  assert.equal(host.pending().request.action,'navigate');
  await host.approve();
  assert(frame.sent.some(x=>x.msg.type==='ACTION_RESULT'&&x.msg.id==='request-12' &&
    x.msg.ok===true && /already open/.test(x.msg.message)));
  host.onMessage({source:frame,origin:'http://invalid.example',
    data:{bridge:'MIDAS_CALIAN_V1',type:'ACTION_REQUEST',token:host.token,id:'request-13',
      action:'navigate',params:{dashboard:'cp'}}});
  assert.equal(host.pending(),null);
  host.ngOnDestroy();
  console.log('PASS: token-backed connection, allowlisted action approval, already-open route, rejected origin');
})().catch(e=>{console.error(e);process.exitCode=1});
