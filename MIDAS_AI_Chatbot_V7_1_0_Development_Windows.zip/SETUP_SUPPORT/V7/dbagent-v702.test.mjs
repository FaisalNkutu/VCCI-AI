import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {classifyDbInput} from '../../Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/server/direct-sql.ts';
import {isDatabaseRetrievalRequest} from '../../Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/src/app/db-intent.ts';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
const source=(name)=>fs.readFileSync(path.join(root,'Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES',name),'utf8');
const app=source('src/app/app.component.ts');
const backend=source('server/index.ts');
const sql=source('server/direct-sql.ts');
const schema=source('server/schema-aware-sql.ts');
const launch=fs.readFileSync(path.join(root,'SETUP-AND-RUN-WINDOWS.ps1'),'utf8');

test('literal SQL classified as SQL, spoken retrieval classified as English',()=>{
  assert.equal(classifyDbInput('SELECT * FROM `vcci_aug_26_dbg_1`.`contxt_oi_assoc` LIMIT 100'),'sql');
  assert.equal(classifyDbInput('Select ten records from the table contxt_oi_assoc'),'question');
  assert.equal(classifyDbInput('DROP TABLE contxt_oi_assoc'),'unsafe');
});

test('frontend DBAgent routing leaves MIDAS select-entity commands alone',()=>{
  const fn=app.match(/private isDatabaseQuery\(text:string\):boolean \{([\s\S]*?)\n \}/);
  assert.ok(fn,'DBAgent intent method must exist');
  const matches=isDatabaseRetrievalRequest;
  assert.equal(matches('Select entity 123'),false);
  assert.equal(matches('Select unit 8'),false);
  assert.equal(matches('Open Combat Power'),false);
  assert.equal(matches('SELECT * FROM `contxt_oi_assoc` LIMIT 1000'),true);
  assert.equal(matches('SELECT * FROM `vcci_aug_26_dbg_1`.`contxt_oi_assoc` LIMIT 100'),true);
  assert.equal(matches('Select 10 records from the table contxt_oi_assoc'),true);
  assert.equal(matches('With happiness and joy, greet everyone'),false);
});

test('browser sends original query to DBAgent without untrusted MIDAS tool output',()=>{
  assert.match(app,/agentId:'DBAgent',message,contextId:this\.contextId/);
  assert.match(app,/const dbIntent=this\.isDatabaseQuery\(message\);/);
  assert.match(app,/await this\.sendDatabaseQuery\(message\);return;/);
  assert.match(app,/const isDB=\/\^db/);
  assert.match(app,/message:isDB\?message:agentQuery/);
});

test('database selection is independent from MIDAS dataSourceConnected and validated against readable schemas',()=>{
  assert.match(app,/databasePickerEnabled=false/);
  assert.match(app,/databaseSchema=''/);
  assert.match(backend,/if\(!DB_SCHEMA_PICKER\)throw new Error/);
  assert.match(backend,/const available=await accessibleDbSchemas\(\)/);
  assert.match(backend,/if\(!selected\)throw new Error/);
  assert.match(backend,/app\.get\('\/api\/db\/options'/);
});

test('SQL execution remains read-only and schema-scoped, no multiagent SQL rewriting',()=>{
  assert.match(sql,/Only a read-only SELECT statement is allowed/);
  assert.match(sql,/The query references a database different from the selected schema/);
  assert.match(sql,/Please select the database or use a schema-qualified table reference/);
  assert.match(sql,/result = asyncio\.run\(call_tool\('execute_sql'/);
  assert.match(backend,/if\(directKind==='sql'\) \{/);
  assert.match(backend,/planningMethod:'deterministic-db'/);
  assert.match(schema,/preferredDatabase\?:string/);
});

test('Windows launcher reads schema-only config and preserves independent ports',()=>{
  assert.match(launch,/V7_DATABASE_CONFIG\.json/);
  assert.match(launch,/CALIAN_SCHEMA_DATABASE=/);
  assert.match(launch,/CALIAN_DB_SCHEMA_PICKER=true/);
  assert.match(launch,/ChoosePortFamily/);
  assert.equal(fs.existsSync(path.join(root,'CONFIGURE-V7-DATABASE-WINDOWS.bat')),true);
});
