export async function resolve(specifier,context,next){
 try{return await next(specifier,context);}catch(e){
  if(e.code==='ERR_MODULE_NOT_FOUND' && /^\.\.?\//.test(specifier) && !/\.[a-z]+$/i.test(specifier))return next(specifier+'.ts',context);
  throw e;
 }
}
