import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {stripTypeScriptTypes} from 'node:module';
const app=new URL('../../Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/src/app/',import.meta.url);
const source=readFileSync(new URL('app.component.ts',app),'utf8');
const html=readFileSync(new URL('app.component.html',app),'utf8');
const helper=new URL('hands-free-commands.ts',app);
const commands=source.slice(source.indexOf(' private async handleVoiceCommand('),source.indexOf(' private voiceSessionId='));
const playback=source.slice(source.indexOf(' readReply(turn:Turn'),source.indexOf(' // Record first, transcribe'));
const harness=`import {voiceCommand,voiceNoise,confirmationCommand,replacementQuestion} from ${JSON.stringify(helper.href)};
export class VoiceHarness {
 handsFree=true;voicePending='';prompt='';lastVoicePlayback='';voiceAutoSubmit=false;busy=false;voiceActive=false;voiceProcessing=false;speechPlaying=false;history=[];sent=[];said=[];schedules=0;databasePickerEnabled=true;databaseSchemas=['c_', 'vcci_aug_26_dbg_1', 'c_dsds'];databaseSchema='c_';saved=[];inspectorOpen=false;inspectorTab=1;
 sayVoice(s){this.said.push(s);this.scheduleVoice();} scheduleVoice(){this.schedules++;} saveDatabaseChoice(){this.saved.push(this.databaseSchema);} stopHandsFree(){this.handsFree=false;}
 async send(){this.sent.push(this.prompt);this.history.push({role:'user',content:this.prompt},{role:'assistant',content:'Returned rows.'});this.prompt='';}
 readReply(t){this.sayVoice(t.content);} ${commands}
}
export class PlaybackHarness {
 canReadAloud=true;handsFree=true;voiceActive=false;speechPlaying=false;speechToken=0;voicePlaybackNotice='';lastVoicePlayback='';schedules=0; zone={run:f=>f()}; snack={open(){}}; scheduleVoice(){this.schedules++;} stopReadback(){this.speechPlaying=false;this.speechToken++;if(this.speechWatchdog)clearTimeout(this.speechWatchdog);} stopHandsFree(){this.handsFree=false;}
 ${playback}
}`;
const {VoiceHarness,PlaybackHarness}=await import('data:text/javascript;base64,'+Buffer.from(stripTypeScriptTypes(harness)).toString('base64'));
test('auto-send is outside scrolling body and before pinned footer',()=>{assert.match(html,/<div class="voice-control-bar"><mat-checkbox[^>]*voiceAutoSubmit/);assert.equal((html.match(/\[\(ngModel\)\]="voiceAutoSubmit"/g)||[]).length,1);assert.ok(html.indexOf('voice-control-bar')<html.indexOf('composer-footer'));});
test('list databases opens inspector, speaks accessible numbers, and does not dispatch',async()=>{const v=new VoiceHarness();await v.handleVoiceCommand('List available databases.');assert.equal(v.inspectorOpen,true);assert.equal(v.inspectorTab,0);assert.match(v.said[0],/2: vcci aug 26 dbg 1/);assert.deepEqual(v.sent,[]);});
test('spoken database number changes the actual saved schema and does not submit a query',async()=>{const v=new VoiceHarness();v.voiceAutoSubmit=true;await v.handleVoiceCommand('Select database number two.');assert.equal(v.databaseSchema,'vcci_aug_26_dbg_1');assert.deepEqual(v.saved,['vcci_aug_26_dbg_1']);assert.deepEqual(v.sent,[]);});
test('dictated database names with underscores and number words match exactly',async()=>{const v=new VoiceHarness();await v.handleVoiceCommand('Select database V C C I underscore August underscore twenty six underscore D B G underscore one.');assert.equal(v.databaseSchema,'vcci_aug_26_dbg_1');assert.deepEqual(v.saved,['vcci_aug_26_dbg_1']);});
test('invalid or ambiguous choices do not change the selected schema or dispatch',async()=>{const v=new VoiceHarness();v.voiceAutoSubmit=true;await v.handleVoiceCommand('Select database number 99.');await v.handleVoiceCommand('Select database nonexistent.');await v.handleVoiceCommand('Select database.');v.databaseSchemas=['c_a','ca'];await v.handleVoiceCommand('Select database c a.');assert.equal(v.databaseSchema,'c_');assert.deepEqual(v.saved,[]);assert.deepEqual(v.sent,[]);});
test('database change cannot replace or redirect a pending confirmed question',async()=>{const v=new VoiceHarness();await v.handleVoiceCommand('Select all records from table X');await v.handleVoiceCommand('Select database number two');assert.equal(v.databaseSchema,'c_');assert.equal(v.voicePending,'Select all records from table X');assert.deepEqual(v.saved,[]);});
test('unavailable database picker fails closed',async()=>{const v=new VoiceHarness();v.databasePickerEnabled=false;await v.handleVoiceCommand('Select database number 2');assert.deepEqual(v.saved,[]);assert.deepEqual(v.sent,[]);});
test('current database is reported without dispatch',async()=>{const v=new VoiceHarness();await v.handleVoiceCommand('Which database is selected?');assert.match(v.said[0],/Current database: c /);assert.deepEqual(v.sent,[]);});
test('missing browser speech API does not disable hands-free',()=>{const v=new PlaybackHarness();v.canReadAloud=false;v.readReply({content:'hello',speechText:'hello'});assert.equal(v.handsFree,true);assert.ok(v.schedules>0);assert.match(v.voicePlaybackNotice,/Voice commands still work/);});
test('empty or remote-only voice inventory never sends speech to a remote voice and resumes listening',()=>{const originalWindow=globalThis.window;const originalUtterance=globalThis.SpeechSynthesisUtterance;try{globalThis.SpeechSynthesisUtterance=class{constructor(text){this.text=text;}};for(const voices of [[],[{localService:false,lang:'en-US'}]]){let spoken=0;globalThis.window={speechSynthesis:{getVoices:()=>voices,speak(){spoken++;}}};const v=new PlaybackHarness();v.readReply({content:'hello',speechText:'hello'});assert.equal(spoken,0);assert.equal(v.handsFree,true);assert.ok(v.schedules>0);assert.match(v.voicePlaybackNotice,/No local playback/);}}finally{globalThis.window=originalWindow;globalThis.SpeechSynthesisUtterance=originalUtterance;}});
test('local playback error recovers without disabling hands-free',()=>{const originalWindow=globalThis.window;const originalUtterance=globalThis.SpeechSynthesisUtterance;try{globalThis.SpeechSynthesisUtterance=class{constructor(text){this.text=text;}};let utterance;globalThis.window={speechSynthesis:{getVoices:()=>[{localService:true,lang:'en-US'}],speak(u){utterance=u;}}};const v=new PlaybackHarness();v.readReply({content:'hello',speechText:'hello'});assert.equal(v.speechPlaying,true);utterance.onerror();assert.equal(v.handsFree,true);assert.equal(v.speechPlaying,false);assert.ok(v.schedules>0);}finally{globalThis.window=originalWindow;globalThis.SpeechSynthesisUtterance=originalUtterance;}});
