import test from 'node:test';
import assert from 'node:assert/strict';
import {buildMidasV7Context} from '../../midas/midas-frontend/src/app/components/calian-ai/midas-v7-context.ts';
import {preflightV7Action,V7_CAPABILITIES} from '../../midas/midas-frontend/src/app/components/calian-ai/midas-v7-actions.ts';
import {acceptV7Context} from '../../Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/src/app/midas-v7-context.ts';
import {interpretV7Action} from '../../Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/src/app/midas-v7-natural-language.ts';
const id='11111111-1111-4111-8111-111111111111';
const raw={route:'/advmetrics/cp',activeDashboard:'cp',dataSourceConnected:true,
 selectedValues:{grouping:'equipment',timeFormat:'UTC',entities:[{id:101,name:'A'}],timeframe:{start:10,end:30},
 controlMeasures:[{id:55,name:'CM'}]},secrets:'should-never-leave',accessToken:'BEARER-SECRET'};
const cp={route:'/advmetrics/cp',timeBounds:{min:0,max:120},cpEntities:[{id:101,name:'Alpha'},{id:102,name:'Bravo'}],availableTimeFormats:['UTC','LOCAL']};
test('strict, bounded context contains selections and excludes credentials',()=>{
 const result=buildMidasV7Context(raw,id,1); assert.equal(result.protocolVersion,2);assert.deepEqual(result.selection.entityIds,[101]);
 assert.equal(result.dataSource.datasetRef,null);const json=JSON.stringify(result);assert.equal(json.includes('BEARER'),false);
 assert.equal(json.includes('should-never'),false);assert.equal(result.selection.timeRange.end,30);
});
test('receiver rejects replay/out-of-order context for matching session',()=>{
 const a=buildMidasV7Context(raw,id,1);assert.equal(acceptV7Context(a,null)?.revision,1);
 assert.equal(acceptV7Context(a,a),null);
 const newer=buildMidasV7Context(raw,id,2);assert.equal(acceptV7Context(newer,a)?.revision,2);
 assert.equal(acceptV7Context(a,newer),null);
});
test('host refuses invalid ID and rev; receiver refuses injection of dataset ref',()=>{
 assert.equal(buildMidasV7Context(raw,'not-a-uuid',1),null);
 assert.equal(buildMidasV7Context(raw,id,0),null);
 const a=buildMidasV7Context(raw,id,1); a.dataSource.datasetRef='real-dataset';
 assert.equal(acceptV7Context(a,null),null);
});
test('typed catalogue disallows shell/sql and untyped args',()=>{
 assert.equal(V7_CAPABILITIES.every(c=>c.requiresApproval),true);
 assert.equal(preflightV7Action('execute_sql',{sql:'drop table x'},'/advmetrics/cp'),false);
 assert.equal(preflightV7Action('navigate',{dashboard:'cp',onClick:'bad'},'/advmetrics/cp'),false);
 assert.equal(preflightV7Action('cp_time_range',{start:10,end:30},'/advmetrics/cp'),true);
 assert.equal(preflightV7Action('cp_time_range',{start:30,end:10},'/advmetrics/cp'),false);
 assert.equal(preflightV7Action('cp_grouping',{grouping:'unit'},'/advmetrics/summary'),false);
});
test('natural-language navigation produces typed proposals, not execution',()=>{
 for(const value of ['Open Summary','Please show me summary','Navigate to the Combat Power dashboard','Bring up the enemy engagement screen','View CM Occupations']){
  const r=interpretV7Action(value,cp);assert.equal(r.kind,'proposal',value);assert.equal(r.request.action,'navigate');
 }
});
test('time ranges respect currently authorized selection bounds',()=>{
 assert.equal(interpretV7Action('Set time range 10 to 30',cp).kind,'proposal');
 assert.equal(interpretV7Action('Set time range 140 to 200',cp).kind,'needs-input');
 assert.equal(interpretV7Action('Set time range',cp).kind,'needs-input');
});
test('only existing MIDAS entities may be proposed for selection',()=>{
 assert.equal(interpretV7Action('Select entity Alpha',cp).kind,'proposal');
 assert.equal(interpretV7Action('Select entity 999',cp).kind,'needs-input');
});
