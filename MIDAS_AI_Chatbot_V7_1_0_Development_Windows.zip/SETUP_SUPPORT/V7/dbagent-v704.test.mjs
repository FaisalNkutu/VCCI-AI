import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {schemaAwareTranslate,clearSchemaCache} from '../../Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/server/schema-aware-sql.ts';
import {validatePlanIntent,compileReadOnlyPlan} from '../../Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/server/db-natural-language.ts';
import {speechSummary} from '../../Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/src/app/result-speech.ts';
const db='vcci_aug_26_dbg_1',table=db+'.contxt_oi_assoc',cols=['contxt_id','obj_item_id','cat_code','time'];
const execute=async(sql)=>({success:true,error:'',rows:sql.includes('INFORMATION_SCHEMA.TABLES')?[{schema_name:db,table_name:'contxt_oi_assoc'}]:cols.map(column_name=>({column_name}))});
const plan=(filters=[],extra={})=>({operation:'list',table,filters,...extra});
const translate=(q,make)=>schemaAwareTranslate(q,execute,make,'v704',db);
test('reported spoken request never calls model, selects all columns, no WHERE',async()=>{
 clearSchemaCache(); const out=await translate('Select data from table Context_OL_ASoc.',()=>{throw Error('unexpected model');});
 assert.equal(out.sql,'SELECT * FROM `'+db+'`.`contxt_oi_assoc` LIMIT 100;');
});
test('plain data and explicit limits bypass model',async()=>{
 for(const q of ['Select data from table contxt_oi_assoc','Show data from table contxt_oi_assoc','Show all records from table contxt_oi_assoc','Show first 10 rows from table contxt_oi_assoc']){
 const out=await translate(q,()=>{throw Error('unexpected model');});assert.doesNotMatch(out.sql,/WHERE/);assert.match(out.sql,/SELECT \*/);}
});
test('model fabricated filter blocked',()=>assert.throws(()=>validatePlanIntent(plan([{column:'contxt_id',operator:'=',value:'literal'}]),'Show data from table contxt_oi_assoc',cols),/filter was not explicitly requested/));
test('requested filter grounded in original speech',async()=>{
 const out=await translate('Show records from table contxt_oi_assoc where contxt_id equals one.',async()=>plan([{column:'contxt_id',operator:'=',value:1}]));assert.match(out.sql,/WHERE `contxt_id` = 1/);
});
test('wrong value, column, operator or omitted predicate rejected',()=>{
 const q='Show records from table contxt_oi_assoc where contxt_id equals 1';
 for(const f of [[{column:'contxt_id',operator:'=',value:'literal'}],[{column:'obj_item_id',operator:'=',value:1}],[{column:'contxt_id',operator:'>',value:1}],[]])assert.throws(()=>validatePlanIntent(plan(f),q,cols),/intent validation/);
});
test('missing value and OR predicates fail closed',()=>{
 for(const q of ['Show records from table contxt_oi_assoc where contxt_id equals','Show records from table contxt_oi_assoc where contxt_id equals 1 or 2'])assert.throws(()=>validatePlanIntent(plan([{column:'contxt_id',operator:'=',value:1}]),q,cols),/intent validation/);
});
test('explicit distinct projection retained',()=>{const p=plan([],{columns:['cat_code'],distinct:true});validatePlanIntent(p,'Show distinct cat_code from table contxt_oi_assoc',cols);assert.match(compileReadOnlyPlan(p,table,cols),/SELECT DISTINCT `cat_code`/);});
test('unrequested projection and sorting rejected',()=>{for(const extra of [{columns:['cat_code']},{orderBy:{column:'time',direction:'DESC'}}])assert.throws(()=>validatePlanIntent(plan([],extra),'Show data from table contxt_oi_assoc',cols),/intent validation/);});
test('result readback uses actual structured rows and counts',()=>{assert.match(speechSummary({rows:[]},''),/no matching records/);assert.match(speechSummary({rows:[{total_records:25}]},''),/25 matching records/);assert.match(speechSummary({Response:{rows:[{cat_code:'A'}]}},''),/cat code is A/);});
const root=new URL('../../Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/',import.meta.url);
const source=readFileSync(new URL('src/app/app.component.ts',root),'utf8');const html=readFileSync(new URL('src/app/app.component.html',root),'utf8');
test('hands-free opt-in, silence detection, confirmation, stop and readback controls present',()=>{
 for(const value of ['handsFree=false','this.voicePending=text','await this.send()','voiceLastSound>1450','document.hidden','this.stopHandsFree()','this.speechPlaying','v.localService'])assert.ok(source.includes(value),value);
 assert.ok(html.includes('toggleHandsFree()'));assert.ok(html.indexOf('Read answers aloud')>html.indexOf('composer-footer'));
});
test('dedicated database response invokes automatic speech summary',()=>{const body=source.slice(source.indexOf('private async sendDatabaseQuery'),source.indexOf('midasV7Context:'));assert.match(body,/speechSummary\(reply,answer\)/);assert.match(body,/if\(this.autoReadAnswers\|\|this.handsFree\)this.readReply\(turn\)/);});
test('structured DB preview is bounded and reflects returned values',async()=>{
 const {databaseResultPreview}=await import('../../Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/src/app/result-speech.ts');
 const preview=databaseResultPreview({generatedSql:'SELECT 1',rowCount:50,rows:Array.from({length:50},(_,i)=>({id:i,cat_code:'A'}))});
 assert.equal(preview.rowCount,50);assert.equal(preview.rows.length,20);assert.deepEqual(preview.rows[0],['0','A']);assert.equal(preview.sql,'SELECT 1');
 assert.equal(databaseResultPreview({text:'no structured response'}),undefined);
});
test('projected column is not misidentified as a table',async()=>{const out=await translate('Show distinct cat_code from table contxt_oi_assoc',async()=>plan([],{columns:['cat_code'],distinct:true}));assert.match(out.sql,/SELECT DISTINCT `cat_code` FROM/);});
