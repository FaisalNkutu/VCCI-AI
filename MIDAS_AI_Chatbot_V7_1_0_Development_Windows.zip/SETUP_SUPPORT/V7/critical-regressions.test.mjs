import test from 'node:test';import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';
const root=new URL('../../',import.meta.url);
const text=(p)=>readFileSync(new URL(p,root),'utf8');
const host=text('midas/midas-frontend/src/app/components/calian-ai/midas-calian-copilot.component.ts');
const chat=text('Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/src/app/app.component.html');
const ui=text('Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/src/app/app.component.ts');
test('MIDAS baseline navigation, pop-out, dock, resizing and approval retained',()=>{
 for(const code of ['switchWorkspace()','close(): void','beginPanelResize(', 'popOut(): void','dockPopout(): void', 'async approve()', 'reject(): void'])
 assert.ok(host.includes(code),code);
});
test('AI Chatbot composer and voice controls retained',()=>{
 for(const code of ['send()','toggleVoice()', 'Transcribing locally with Whisper','Read responses']){
  assert.ok(chat.includes(code)||ui.includes(code),code);
 }
});
test('V7 feature flags are explicit and bounded',()=>{
 assert.match(text('midas/midas-frontend/src/assets/calian-embed-config.js'),/contextV2: (true|false), typedActions: (true|false)/);
 assert.match(text('Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/public/ai-chatbot-v7-config.js'),/syntheticDemo:(true|false), nlActions:(true|false)/);
});
