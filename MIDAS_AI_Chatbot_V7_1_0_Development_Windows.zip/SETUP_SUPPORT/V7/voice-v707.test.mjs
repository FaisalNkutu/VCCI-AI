import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {stripTypeScriptTypes} from 'node:module';
const app=new URL('../../Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/src/app/',import.meta.url);
const source=readFileSync(new URL('app.component.ts',app),'utf8');
const html=readFileSync(new URL('app.component.html',app),'utf8');
const helper=new URL('hands-free-commands.ts',app);
const commands=source.slice(source.indexOf(' private async handleVoiceCommand('),source.indexOf(' private voiceSessionId='));
const playback=source.slice(source.indexOf(' readReply(turn:Turn'),source.indexOf(' // Record first, transcribe'));
const harness=`import {voiceCommand,voiceNoise,confirmationCommand,replacementQuestion} from ${JSON.stringify(helper.href)};
export class VoiceHarness {
 handsFree=true;voicePending='';prompt='';lastVoicePlayback='';voiceAutoSubmit=false;busy=false;voiceActive=false;voiceProcessing=false;speechPlaying=false;history=[];sent=[];said=[];schedules=0;databasePickerEnabled=true;databaseSchemas=['c_', 'vcci_aug_26_dbg_1', 'c_dsds'];databaseSchema='c_';voiceDatabaseListOpen=false;saved=[];inspectorOpen=false;inspectorTab=1;
 async loadDatabaseOptions(){this.databaseSchemas=['c_','vcci_aug_26_dbg_1','c_dsds'];this.databasePickerEnabled=true;} sayVoice(s){this.said.push(s);this.scheduleVoice();} scheduleVoice(){this.schedules++;} saveDatabaseChoice(){this.saved.push(this.databaseSchema);} stopHandsFree(){this.handsFree=false;}
 async send(){this.sent.push(this.prompt);this.history.push({role:'user',content:this.prompt},{role:'assistant',content:'Returned rows.'});this.prompt='';}
 readReply(t){this.sayVoice(t.content);} ${commands}
}
export class PlaybackHarness {
 canReadAloud=true;handsFree=true;voiceActive=false;speechPlaying=false;speechToken=0;voicePlaybackNotice='';lastVoicePlayback='';schedules=0; zone={run:f=>f()}; snack={open(){}}; scheduleVoice(){this.schedules++;} stopReadback(){this.speechPlaying=false;this.speechToken++;if(this.speechWatchdog)clearTimeout(this.speechWatchdog);} stopHandsFree(){this.handsFree=false;}
 ${playback}
}`;
const {VoiceHarness,PlaybackHarness}=await import('data:text/javascript;base64,'+Buffer.from(stripTypeScriptTypes(harness)).toString('base64'));

test('polite database commands and punctuation are consumed locally',async()=>{for(const phrase of ['Please, select database number two.','Switch database to number 2','Choose database, option 2','Change the database to VCCI Aug 26 DBG 1','Set current database to vcci_aug_26_dbg_1','Select data base number 2','Use database second']){const v=new VoiceHarness();v.voiceAutoSubmit=true;await v.handleVoiceCommand(phrase);assert.equal(v.databaseSchema,'vcci_aug_26_dbg_1',phrase);assert.deepEqual(v.sent,[],phrase);}});
test('number only or short choice works after list',async()=>{for(const phrase of ['Two','2','Number two','Choose number 2','Select second','Option two']){const v=new VoiceHarness();v.voiceAutoSubmit=true;await v.handleVoiceCommand('Show me all available databases.');await v.handleVoiceCommand(phrase);assert.equal(v.databaseSchema,'vcci_aug_26_dbg_1',phrase);assert.deepEqual(v.sent,[],phrase);assert.equal(v.voiceDatabaseListOpen,false);}});
test('list variants do not enter SQL path',async()=>{for(const phrase of ['Please list databases','What databases are available?','Which databases can I access?','Refresh databases']){const v=new VoiceHarness();v.voiceAutoSubmit=true;await v.handleVoiceCommand(phrase);assert.equal(v.voiceDatabaseListOpen,true,phrase);assert.deepEqual(v.sent,[]);}});
test('missing or invalid selection opens list without changing schema',async()=>{const v=new VoiceHarness();v.voiceAutoSubmit=true;await v.handleVoiceCommand('Select database');await v.handleVoiceCommand('Number 99');assert.equal(v.voiceDatabaseListOpen,true);assert.equal(v.databaseSchema,'c_');assert.deepEqual(v.sent,[]);});
test('ordinary SQL remains a query even when list open',async()=>{const v=new VoiceHarness();v.voiceAutoSubmit=true;await v.handleVoiceCommand('List databases');const q='Select all records from table contxt_oi_assoc';await v.handleVoiceCommand(q);assert.deepEqual(v.sent,[q]);assert.equal(v.voiceDatabaseListOpen,false);});
test('last recognized transcript is exposed in UI',async()=>{const v=new VoiceHarness();await v.handleVoiceCommand('Select database number two');assert.equal(v.voiceLastTranscript,'Select database number two');assert.match(html,/Heard: {{voiceLastTranscript}}/);});
