import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {stripTypeScriptTypes} from 'node:module';
const root=new URL('../../Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/',import.meta.url);
const app=new URL('src/app/',root);
const helper=new URL('hands-free-commands.ts',app);
const {voiceNoise}=await import(helper.href);
const source=readFileSync(new URL('app.component.ts',app),'utf8');
const server=readFileSync(new URL('server/index.ts',root),'utf8');
const whisper=readFileSync(new URL('server/speech-whisper.ts',root),'utf8');
const commands=source.slice(source.indexOf(' private async handleVoiceCommand('),source.indexOf(' private voiceSessionId='));
const recovery=source.slice(source.indexOf(' private pauseHiddenVoice()'),source.indexOf(' /** Opt-in only.'));
const harness=`import {voiceCommand,voiceNoise,confirmationCommand,replacementQuestion} from ${JSON.stringify(helper.href)};
export class VoiceHarness {
 handsFree=true;voicePending='';prompt='';lastVoicePlayback='';voiceAutoSubmit=true;busy=false;voiceActive=false;voiceProcessing=false;speechPlaying=false;history=[];sent=[];said=[];schedules=0;databaseSchema='a';selected='auto';voiceSessionId='session';voicePlaybackAttempt=0;lastVoiceQuestion='';lastVoiceQuestionAt=0;voiceFailures=0;voiceRetryAt=0;voiceSuspended=false;voiceBuffers=[];voiceSamples=0;voiceError='';
 sayVoice(s){this.said.push(s);this.scheduleVoice();} scheduleVoice(){this.schedules++;} stopHandsFree(){this.handsFree=false;}
 releaseMic(){this.voiceActive=false;} readReply(t){this.voicePlaybackAttempt++;this.said.push(t.content);}
 async send(){this.sent.push(this.prompt);this.history.push({role:'user',content:this.prompt},{role:'assistant',content:'An answer.'});this.prompt='';this.readReply(this.history.at(-1));}
 ${commands}
 ${recovery}
}`;
const {VoiceHarness}=await import('data:text/javascript;base64,'+Buffer.from(stripTypeScriptTypes(harness)).toString('base64'));
const q='Select all records from table contxt_oi_assoc';
test('reported caption and related non-verbal descriptions are ignored',async()=>{const v=new VoiceHarness();for(const t of ['(speaking in foreign language)','[Speaking in a foreign language.]','(unknown speech)','[background chatter]','Music playing']){assert.equal(voiceNoise(t),true,t);await v.handleVoiceCommand(t);}assert.deepEqual(v.sent,[]);assert.equal(voiceNoise('Translate speaking in foreign language into French'),false);});
test('same recent question is not automatically repeated; next distinct question is accepted',async()=>{const v=new VoiceHarness();await v.handleVoiceCommand(q);await v.handleVoiceCommand(q+'.');await v.handleVoiceCommand('Count records in table contxt_oi_assoc');assert.deepEqual(v.sent,[q,'Count records in table contxt_oi_assoc']);});
test('repeat question explicitly allows resubmission',async()=>{const v=new VoiceHarness();await v.handleVoiceCommand(q);await v.handleVoiceCommand('Repeat question');assert.deepEqual(v.sent,[q,q]);});
test('same question after changing schema is a distinct request',async()=>{const v=new VoiceHarness();await v.handleVoiceCommand(q);v.databaseSchema='b';await v.handleVoiceCommand(q);assert.deepEqual(v.sent,[q,q]);});
test('same question after dedup window is allowed',async()=>{const v=new VoiceHarness();await v.handleVoiceCommand(q);v.lastVoiceQuestionAt-=31000;await v.handleVoiceCommand(q);assert.deepEqual(v.sent,[q,q]);});
test('successful request playback is attempted once',async()=>{const v=new VoiceHarness();await v.handleVoiceCommand(q);assert.deepEqual(v.said,['An answer.']);});
test('temporary errors retain opt-in and apply capped retry backoff',()=>{const v=new VoiceHarness();for(let i=0;i<12;i++)v.retryVoice('Whisper unavailable');assert.equal(v.handsFree,true);assert.equal(v.voiceFailures,12);assert.ok(v.voiceRetryAt-Date.now()<=30000);assert.match(v.voiceStatus,/Retrying in 30 seconds/);});
test('permission denial pauses without disabling hands-free, resume clears pause',()=>{const v=new VoiceHarness();v.retryVoice('blocked',true);assert.equal(v.voiceNeedsResume,true);assert.equal(v.handsFree,true);v.resumeVoice();assert.equal(v.voiceNeedsResume,false);assert.equal(v.voiceRetryAt,0);});
test('hidden tab releases microphone and invalidates pending transcription without disabling hands-free',()=>{const v=new VoiceHarness();v.voiceActive=true;v.voiceProcessing=true;v.voiceBuffers=[new Float32Array(10)];v.voiceSamples=10;let aborted=false;v.voiceAbort={abort(){aborted=true;}};v.pauseHiddenVoice();assert.ok(aborted);assert.equal(v.handsFree,true);assert.equal(v.voiceActive,false);assert.equal(v.voiceProcessing,false);assert.equal(v.voiceSamples,0);assert.notEqual(v.voiceSessionId,'session');});
test('fresh microphone capture is gated while command is processing, and retains short pre-roll',()=>{assert.match(source,/this\.voiceProcessing\|\|this\.voiceHandling\|\|this\.speechPlaying/);assert.match(source,/this\.voiceSamples>context\.sampleRate\*0\.65/);assert.match(source,/this\.voiceHandling=true;try\{await this\.handleVoiceCommand/);assert.doesNotMatch(source,/voiceFailures>=3/);});
test('voice orchestration uses shorter budgets and preserves original direct SQL path',()=>{assert.match(server,/deadlineMs:voiceProfile\?55000:165000/);assert.match(server,/Math\.min\(voiceProfile\?2:5,/);assert.match(server,/signal:AbortSignal\.timeout\(voiceProfile\?45000:180000\)/);assert.match(source,/responseProfile:'voice'/);const start=server.indexOf("app.post('/api/orchestration/execute'");const section=server.slice(start,server.indexOf('const sharedContext=',start));assert.doesNotMatch(section,/voiceProfile|responseProfile/);assert.match(section,/executeReadOnlySql\(message,db\)/);});
test('Whisper voice deadline is shorter while manual transcription stays unchanged',()=>{assert.match(whisper,/handsFree\?75000:285000/);assert.match(whisper,/handsFree\?45000:/);assert.match(source,/this\.handsFree\?85000:310000/);});
