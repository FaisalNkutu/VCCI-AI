import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {isDatabaseRetrievalRequest} from '../../Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/src/app/db-intent.ts';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
const read=(p)=>fs.readFileSync(path.join(root,'Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES',p),'utf8');
const ui=read('src/app/app.component.ts');
const server=read('server/index.ts');
const schema=read('server/schema-aware-sql.ts');
const checks=[
 ['SELECT * FROM `vcci_aug_26_dbg_1`.`contxt_oi_assoc` LIMIT 100',true],
 ['Show me records from table contxt_oi_assoc',true],
 ['Show me the records from table `contxt_oi_assoc`',true],
 ['Show me records from table context underscore o i underscore assoc',true],
 ['Show me the number of records in the table contxt_oi_assoc',true],
 ['How many records are in the contxt_oi_assoc table?',true],
 ['List the records in `vcci_aug_26_dbg_1`.`contxt_oi_assoc`',true],
 ['SELECT entity 123',false],
 ['Select unit 8',false],
 ['Open Combat Power',false],
 ['Change time format',false],
 ['Analyze the current Combat Power dashboard',false],
 ['Explain what a database is',false],
 ['Show me the selected entities in MIDAS',false],
];
for(const [message,expected] of checks){
 test('database intent: '+message,()=>assert.equal(isDatabaseRetrievalRequest(message),expected));
}
test('frontend uses shared intent and forwards selected DB directly',()=>{
 assert.match(ui,/import \{isDatabaseRetrievalRequest\} from '\.\/db-intent';/);
 assert.match(ui,/return isDatabaseRetrievalRequest\(text\);/);
 assert.match(ui,/if\(dbIntent && !this\.selectionOnly/);
 assert.match(ui,/agentId:'DBAgent',message,contextId:this\.contextId/);
 assert.match(ui,/database:this\.databaseSchema/);
});
test('orchestrator classifies DB before planning and calls read-only DBAgent',()=>{
 const start=server.indexOf("app.post('/api/orchestration/execute'");
 const forward=server.indexOf("internalChainPost('/api/ai-core/execute'",start);
 const planner=server.indexOf('const result=await runAgentChain',start);
 assert.ok(start>=0 && forward>start && forward<planner);
 assert.match(server.slice(start,planner),/selectedDbSchema\(database\)/);
 assert.match(server.slice(start,planner),/agentId:'DBAgent',message,contextId/);
 assert.match(server.slice(start,planner),/no fallback answer was generated/);
 assert.match(server.slice(start,planner),/planningMethod:'deterministic-db'/);
});
test('no MIDAS connection flag used for DBAgent and REQA remains read-only',()=>{
 assert.match(schema,/preferredDatabase\?:string/);
 assert.match(server,/const DB_SCHEMA_PICKER=/);
 const sql=read('server/direct-sql.ts');
 assert.match(sql,/Only a read-only SELECT statement is allowed/);
 assert.doesNotMatch(server.slice(server.indexOf("app.post('/api/orchestration/execute'"),server.indexOf('const sharedContext=context')),/dataSourceConnected/);
});
