// Offline protocol smoke tests, run with Node + TypeScript available.
// Does not require private MIDAS npm packages, launch a browser, or access credentials.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const ts=require('typescript');
const root=path.resolve(__dirname,'..');
const mkSignal=(initial)=>{let val=initial;const f=()=>val;f.set=(v)=>val=v;return f;};
function load(relative,mocks,globals={}){
 const filename=path.join(root,relative),source=fs.readFileSync(filename,'utf8');
 const out=ts.transpileModule(source,{fileName:filename,reportDiagnostics:true,compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,experimentalDecorators:true}});
 assert.equal(out.diagnostics.length,0,`Syntax diagnostics in ${relative}`);
 const exports={};
 const ctx={exports,require(name){return mocks[name]||{};},console,URL,crypto:globalThis.crypto,setInterval,clearInterval,setTimeout,clearTimeout,...globals};
 vm.runInNewContext(out.outputText,ctx,{filename});return exports;
}
const protocolPath='Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/src/app/app.component.ts';
const app=load(protocolPath,{'@angular/core':{Component:()=>x=>x,ViewChild:()=>()=>{}}}, {window:{},document:{},localStorage:{setItem(){},getItem(){return null}}}).AppComponent;
const zone={run:cb=>cb()},snack={open:()=>{}};
const first=new app({},snack,zone);first.midasToken='a';first.history=[{role:'user',content:'Hello',time:'10:00'},{role:'assistant',content:'World',time:'10:01'}];
const sent=[];first.postMidas=(type,body)=>sent.push({type,body});
const id='0b4a3e12-504d-42ea-bbee-77a3ceded99e';
first.exportMidasSession(id);
assert.equal(sent.at(-1).type,'SESSION_EXPORT_RESPONSE');
const snapshot=sent.at(-1).body.snapshot;
const second=new app({},snack,zone);const replies=[];second.midasToken='b';second.postMidas=(type,body)=>replies.push({type,body});
second.importMidasSession(id,snapshot);
assert.equal(second.history[0].content,'Hello');
assert.equal(second.history[1].content,'World');
assert.equal(second.contextId,first.contextId);
assert.equal(replies.at(-1).type,'SESSION_IMPORTED');
first.activeView='video';first.exportMidasSession(id);
assert.equal(sent.at(-1).type,'SESSION_EXPORT_ERROR');
const count=second.history.length;
second.importMidasSession(id,{version:1,contextId:second.contextId,history:[{role:'user',content:'X'.repeat(9000)}]});
assert.equal(second.history.length,count,'Oversize snapshot must be rejected');
console.log('PASS: Calian chat export/import, busy-video guard, input-size validation');

const midasMocks={
 '@angular/core':{Component:()=>x=>x,ViewChild:()=>()=>{},inject:(token)=>{
   if(token==='store')return{selectSignal:()=>()=>[],dispatch:()=>{}};
   if(token==='router')return{url:'/advmetrics',navigateByUrl:()=>Promise.resolve(true),events:{pipe:()=>({subscribe:()=>({})})}};
   if(token==='sanitizer')return{bypassSecurityTrustResourceUrl:x=>x};
   if(token==='ui')return{open:mkSignal(true),fullPage:mkSignal(false)};
 },signal:mkSignal},
 '@angular/platform-browser':{DomSanitizer:'sanitizer'},
 '@angular/router':{Router:'router',NavigationEnd:class {}},
 '@ngrx/store':{Store:'store'},
 'rxjs':{Subscription:class {add(){} unsubscribe(){}},filter:()=>x=>x},
 '@/app.guard':{APP_PREF_KEY:'preferred'},
 '@/utils/routes':{routes:Object.fromEntries(['SUM','HH','ROM','POE','CM','FRAT','ENG','CP','UW','HR'].map(k=>[k,{route:k.toLowerCase()}]))},
 './midas-copilot-ui-state':{MidasCopilotUiState:'ui'}
};
let popwin=null;const framewin={messages:[],postMessage(m,origin){this.messages.push({m,origin})}};
const windowMock={__MIDAS_CALIAN_EMBED_URL__:'http://127.0.0.1:4301/',screenX:10,screenY:10,
 open(url,name,features){assert.equal(url,'http://127.0.0.1:4301/');assert(features.includes('resizable=yes'));popwin={closed:false,messages:[],postMessage(m,origin){this.messages.push({m,origin})},focus(){},resizeTo(w,h){this.size=[w,h]},moveTo(x,y){this.position=[x,y]},close(){this.closed=true}};return popwin;},
 addEventListener(){},removeEventListener(){} };
const midas=load('midas/midas-frontend/src/app/components/calian-ai/midas-calian-copilot.component.ts',midasMocks,{window:windowMock,screen:{availWidth:1920,availHeight:1080},localStorage:{setItem(){},removeItem(){}}}).MidasCalianCopilotComponent;
const host=new midas();host.frame={nativeElement:{contentWindow:framewin}};host.connected.set(true);
host.popOut();assert.equal(host.popoutActive(),true);assert.equal(host.open(),false);
assert(framewin.messages.some(x=>x.m.type==='SESSION_EXPORT_REQUEST'));
host.onMessage({origin:'http://127.0.0.1:4301',source:popwin,data:{bridge:'MIDAS_CALIAN_V1',type:'HELLO'}});
assert.equal(host.popoutConnected(),true);
const handoffId=host.handoff.id;
host.onMessage({origin:'http://127.0.0.1:4301',source:framewin,data:{bridge:'MIDAS_CALIAN_V1',type:'SESSION_EXPORT_RESPONSE',id:handoffId,token:host.token,snapshot}});
assert(popwin.messages.some(x=>x.m.type==='SESSION_IMPORT'), 'Popup must receive session snapshot');
host.onMessage({origin:'http://127.0.0.1:4301',source:popwin,data:{bridge:'MIDAS_CALIAN_V1',type:'SESSION_IMPORTED',id:handoffId,token:host.popupToken}});
assert.equal(host.handoff,undefined);
host.resizePopout(900,650);assert.deepEqual(popwin.size,[900,650]);
host.centerPopout();assert.deepEqual(popwin.position,[410,140]);
host.shareContext.set(true);
host.onMessage({origin:'http://127.0.0.1:4301',source:popwin,data:{bridge:'MIDAS_CALIAN_V1',type:'ACTION_REQUEST',id:'a123',token:host.popupToken,action:'navigate',params:{dashboard:'cp'}}});
assert.equal(host.pending().source,'popup');
// Bad source/token must not overwrite a pending request
host.onMessage({origin:'http://attacker.example',source:popwin,data:{bridge:'MIDAS_CALIAN_V1',type:'ACTION_REQUEST',id:'bad',token:host.popupToken,action:'navigate',params:{dashboard:'cp'}}});
assert.equal(host.pending().id,'a123');
host.pending.set(null);
host.dockPopout();const dockId=host.handoff.id;
host.onMessage({origin:'http://127.0.0.1:4301',source:popwin,data:{bridge:'MIDAS_CALIAN_V1',type:'SESSION_EXPORT_RESPONSE',id:dockId,token:host.popupToken,snapshot}});
assert(framewin.messages.some(x=>x.m.type==='SESSION_IMPORT' && x.m.id===dockId));
host.onMessage({origin:'http://127.0.0.1:4301',source:framewin,data:{bridge:'MIDAS_CALIAN_V1',type:'SESSION_IMPORTED',id:dockId,token:host.token}});
assert.equal(host.popoutActive(),false);assert.equal(host.open(),true);assert.equal(popwin.closed,true);
console.log('PASS: Popup creation, resizing, centering, origin/source token checks, safe docking');
