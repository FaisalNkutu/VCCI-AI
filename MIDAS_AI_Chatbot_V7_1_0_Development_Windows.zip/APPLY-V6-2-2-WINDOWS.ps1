﻿# AI Chatbot V6.2.2 - TS18048 and (if still present) TS2322 repair
param([string]$ProjectRoot = '')
$ErrorActionPreference = 'Stop'
$midRel = 'midas\midas-frontend\src\app\components\calian-ai\midas-calian-copilot.component.ts'
$appRel = 'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\app.component.ts'
Write-Host 'AI Chatbot + MIDAS V6.2.2 - targeted TypeScript repair' -ForegroundColor Cyan
Write-Host 'No dependency installation, process shutdown, registry edits, or port changes.'

function Resolve-Root([string]$path) {
  if ([string]::IsNullOrWhiteSpace($path) -or !(Test-Path -LiteralPath $path -PathType Container)) { return $null }
  $root = $path
  # Also accept direct MIDAS frontend folder or MIDAS parent folder.
  if ((Test-Path -LiteralPath (Join-Path $root 'src\app\components\calian-ai\midas-calian-copilot.component.ts'))) {
    $root = (Resolve-Path -LiteralPath (Join-Path $root '..\..')).Path
  } elseif ((Test-Path -LiteralPath (Join-Path $root 'midas-frontend\src\app\components\calian-ai\midas-calian-copilot.component.ts'))) {
    $root = (Resolve-Path -LiteralPath (Join-Path $root '..')).Path
  }
  $mid = Join-Path $root $script:midRel
  $app = Join-Path $root $script:appRel
  if ((Test-Path -LiteralPath $mid -PathType Leaf) -and (Test-Path -LiteralPath $app -PathType Leaf)) { return $root }
  return $null
}

$root = Resolve-Root $ProjectRoot
if (!$root) {
  $choices = New-Object 'System.Collections.Generic.List[string]'
  $locations = @((Join-Path $env:USERPROFILE 'Downloads'), (Get-Location).Path) | Select-Object -Unique
  foreach ($loc in $locations) {
    if (!(Test-Path -LiteralPath $loc -PathType Container)) { continue }
    $dirs = @((Get-Item -LiteralPath $loc)) + @(Get-ChildItem -LiteralPath $loc -Directory -Recurse -Depth 4 -ErrorAction SilentlyContinue)
    foreach ($dir in $dirs) {
      $found = Resolve-Root $dir.FullName
      if ($found -and !$choices.Contains($found)) { $choices.Add($found) }
    }
  }
  if ($choices.Count -eq 0) { throw 'Could not find an extracted V6.2 project. Rerun the PowerShell script using -ProjectRoot "C:\path\to\project".' }
  Write-Host 'Select the project folder used by the active MIDAS browser URL:' -ForegroundColor Yellow
  for ($i=0; $i -lt $choices.Count; $i++) { Write-Host ('[{0}] {1}' -f ($i+1), $choices[$i]) }
  $choice = Read-Host 'Enter selection number (blank cancels)'
  if ($choice -notmatch '^\d+$' -or [int]$choice -lt 1 -or [int]$choice -gt $choices.Count) { throw 'Cancelled, no files changed.' }
  $root = $choices[[int]$choice-1]
}

$midFile = Join-Path $root $midRel
$appFile = Join-Path $root $appRel
$midText = [IO.File]::ReadAllText($midFile)
$appText = [IO.File]::ReadAllText($appFile)
$old = 'const series = (chart.chartData.datasets as unknown as Array<{label?:string;data?:unknown}>).slice(0,10)'
$new = 'const rawDatasets = chart?.chartData?.datasets;' + "`n      " +
       'const datasets = Array.isArray(rawDatasets) ? rawDatasets : [];' + "`n      " +
       'const series = (datasets as Array<{label?: string; data?: unknown}>).slice(0, 10)'
$oldID = 'contextId=crypto.randomUUID(); previousAgentId:string|null=null;'
$newID = 'contextId: string = crypto.randomUUID(); previousAgentId:string|null=null;'

if (!$midText.Contains('selectCpChartData') -or !$midText.Contains('seriesStats(item.data)') -or !$midText.Contains('MIDAS_CALIAN_V1')) { throw 'MIDAS source does not match this V6.2 fix. Nothing changed.' }
$midNeeds = $midText.Contains($old)
$midFixed = $midText.Contains('const rawDatasets = chart?.chartData?.datasets;')
if (!$midNeeds -and !$midFixed) { throw 'Unexpected MIDAS code: chart expression not found. No files changed.' }
$appNeeds = $appText.Contains($oldID)
if (!$appNeeds -and !$appText.Contains($newID)) { throw 'Unexpected chatbot context ID declaration. No files changed.' }
if (!$midNeeds -and !$appNeeds) { Write-Host 'Both fixes are already present; no files changed.' -ForegroundColor Green; exit 0 }

Write-Host ('MIDAS source: ' + $midFile) -ForegroundColor Yellow
Write-Host ('Chatbot source: ' + $appFile) -ForegroundColor Yellow
Write-Host ('Changes required: chart=' + $midNeeds + ', contextId=' + $appNeeds)
$confirm = Read-Host 'Type Y to back up and apply these targeted corrections'
if ($confirm -notin @('Y','y')) { Write-Host 'Cancelled. No files changed.'; exit 0 }
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backups = @()
try {
  if ($midNeeds) {
    $backup = $midFile + '.v6.2.2.' + $stamp + '.bak'
    Copy-Item -LiteralPath $midFile -Destination $backup -ErrorAction Stop
    $backups += @{source=$midFile; backup=$backup}
    $midNew = $midText.Replace($old,$new)
    # Add an explanation; does not change runtime behavior.
    $midNew = $midNew.Replace('const rawDatasets = chart?.chartData?.datasets;', '// A chart is unavailable until Combat Power data loads.' + "`n" + '      const rawDatasets = chart?.chartData?.datasets;')
    [IO.File]::WriteAllText($midFile,$midNew,[Text.UTF8Encoding]::new($false))
  }
  if ($appNeeds) {
    $backup = $appFile + '.v6.2.2.' + $stamp + '.bak'
    Copy-Item -LiteralPath $appFile -Destination $backup -ErrorAction Stop
    $backups += @{source=$appFile; backup=$backup}
    [IO.File]::WriteAllText($appFile,$appText.Replace($oldID,$newID),[Text.UTF8Encoding]::new($false))
  }
  Write-Host 'Targeted V6.2.2 fixes applied.' -ForegroundColor Green
  foreach ($b in $backups) { Write-Host ('Backup: ' + $b.backup) }
  Write-Host 'Check the existing Angular consoles for successful recompilation. Do not stop other instances.'
} catch {
  foreach ($b in $backups) { if (Test-Path -LiteralPath $b.backup) { Copy-Item -LiteralPath $b.backup -Destination $b.source -Force } }
  throw
}
