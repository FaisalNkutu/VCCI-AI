# AI Chatbot V6.3 — optional MIDAS skin + contextual controls

## Changes

1. **MIDAS Theme** is an additional optional skin in the AI Chatbot SKIN selector. It does not change the MIDAS app's own CSS or other four chatbot skins.
2. **Navigation selection → control-request suggestion**: When you select a MIDAS menu/dashboard, the AI Chatbot Session Inspector can prefill `Open <dashboard label>` in the MIDAS control-request field, provided it is empty or still contains the previous auto-generated suggestion. **It does not execute the action.** User approval remains necessary.
3. **Selected dashboard values → query context**: With **Share dashboard context** and **Include MIDAS context in AI queries** enabled, the bridge includes bounded selected time format/range, Combat Power grouping and entity IDs/names, Rate of Movement capture and selected entity IDs, and Control Measures IDs/names. Only available state is sent; no arbitrary DOM scraping, database dumps, passwords or tokens.
4. **Visible prompt support**: A `Linked MIDAS selections` strip appears above the chatbot text box. Click **Use selection in prompt** to insert a draft; or leave **Auto-fill empty prompt** enabled to fill only an empty or previously auto-generated draft when selections change. Handwritten text is preserved. The selected state is also attached directly to actual agent search/query requests and structured context, if sharing is enabled.

## Apply to existing V6.2.5

Extract the ZIP, then run `APPLY-V6-3-WINDOWS.bat`. Choose the correct currently running project root and type APPLY. The script verifies all five source files against the V6.2.5 baseline, backs them up, and does not stop existing instances or reinstall dependencies. If local files have changed, the script refuses to overwrite them.

Refresh MIDAS and the chatbot after Angular rebuilds, preferably using Ctrl+Shift+R. The MIDAS skin remains opt-in; select `MIDAS Theme` from SKIN. Check **Share dashboard context**.

## Quick acceptance tests

- With sharing on, choose **Combat Power** in the MIDAS navigation: the Session Inspector's MIDAS control-request should say `Open Combat Power` without approving or executing anything.
- Type a different request manually, then choose another MIDAS dashboard. Your draft must not be overwritten.
- With a MIDAS data source connected, select entities, a timeframe, grouping or a capture; verify that `Linked MIDAS selections` shows the values and use its Insert control. With no data source, no live analytics are fabricated.
- Turn off **Share dashboard context**: MIDAS details must no longer be included in AI agent query strings.
- Choose the new `MIDAS Theme`; switch back to Corporate to verify the default skin is preserved.
- Check side panel, Full Page, Read responses, Pop out and video for regressions.

## Security and limitations

The bridge still validates origin, window source and token; MIDAS remains the authority for permission checks, action allowlists and explicit approval. Shared selections are descriptive, **not** authorization grants. Context entries from the host are untrusted data and should not be treated as model instructions. Only current documented MIDAS selectors are supported; this is not an unrestricted all-controls bridge. External services and Simfront Artifactory packages are not bundled. Full Windows Angular/browser runtime testing is not possible in the build environment.
