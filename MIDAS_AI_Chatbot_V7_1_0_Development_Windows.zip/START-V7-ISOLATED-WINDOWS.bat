@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo AI Chatbot + MIDAS V7 DEVELOPMENT - independent port family, no changes to V6.5
call "%~dp0START-EVERYTHING-WINDOWS.bat"
endlocal
