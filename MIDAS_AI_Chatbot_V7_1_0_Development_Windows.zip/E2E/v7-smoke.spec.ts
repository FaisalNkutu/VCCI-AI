/** Optional full-browser smoke suite. Requires BOTH locally running services and their authorized dependencies. */
import { test, expect } from '@playwright/test';
const base=process.env.MIDAS_BASE_URL;
test.skip(!base, 'Set MIDAS_BASE_URL to the exact freshly launched V7 URL before running E2E tests');
test('MIDAS sidebar remains usable and AI Chatbot can be opened', async({page})=>{
 await page.goto(`${base}/advmetrics/summary`);
 await expect(page.getByText('MIDAS').first()).toBeVisible();
 const chatbot=page.getByRole('button',{name:/AI Chatbot/i}).first();
 if(await chatbot.isVisible())await chatbot.click();
 await expect(page.locator('iframe[title="AI Chatbot embedded application"]')).toHaveCount(1);
});
test('chatbot workspaces/close do not leave a blank MIDAS shell', async({page})=>{
 await page.goto(`${base}/calian-ai`);
 const workspaces=page.getByRole('button',{name:'Workspaces'}).first();
 await workspaces.click();
 await expect(page.locator('body')).not.toBeEmpty();
 await page.goto(`${base}/advmetrics/summary`);
 await expect(page.getByText('MIDAS').first()).toBeVisible();
});
test('embedded resize handle and explicit user-action approval remain present', async({page})=>{
 await page.goto(`${base}/advmetrics/summary`);
 const chatbot=page.getByRole('button',{name:/AI Chatbot/i}).first();
 if(await chatbot.isVisible())await chatbot.click();
 await expect(page.getByRole('separator',{name:/Drag left or right/i})).toBeVisible();
 await expect(page.getByText(/Bridge (connected|disconnected)/)).toBeVisible();
});
