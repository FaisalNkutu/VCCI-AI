# Optional Playwright browser verification (not executed during packaging)

This suite requires Windows or a test machine with the **actual** MIDAS/AI Chatbot services running, and authorized private dependencies. Run in a fresh, isolated V7 port family.

```powershell
cd .\E2E
npm install
npx playwright install chromium
$env:MIDAS_BASE_URL='http://127.0.0.1:4201' # replace with V7 launcher actual URL
npm test
```

Do not capture screenshots/video/HTTP traces containing real classified data in a cloud CI worker. The suite is intentionally limited to non-sensitive UI smoke checks. Add MIDAS fixture accounts and OIDC integration before production authorization testing.
