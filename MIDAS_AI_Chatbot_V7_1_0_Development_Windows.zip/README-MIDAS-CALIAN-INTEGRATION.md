# V4.1 — Fix for ERR_PNPM_IGNORED_BUILDS (24 Nov 2026)

The previous V4 launcher stopped during `pnpm install --frozen-lockfile` because pnpm did not have explicit permission to execute lifecycle scripts for the four known build dependencies in the lockfile. The V4.1 package adds a narrowly scoped, **exact-version** policy at `midas/midas-frontend/pnpm-workspace.yaml`:

```
allowBuilds:
  '@parcel/watcher@2.5.6': true
  'esbuild@0.28.1': true
  'lmdb@3.5.1': true
  'msgpackr-extract@3.0.4': true
```

This is a conscious security decision: those four dependency installation scripts will execute on your computer. Only use this package if you trust the package supply chain and your organization permits these builds. No package version or lockfile integrity digest was changed in this V4.1 repair. `strictDepBuilds` stays enabled; the script does **not** use `dangerouslyAllowAllBuilds`, `--ignore-scripts`, or automatic approval of other packages. If pnpm reports a new package needing approval, do not automatically trust it; review the dependency and allow it explicitly.

**To use:** Fully extract **this V4.1 ZIP**, then run `START-EVERYTHING-WINDOWS.bat` from the extracted folder. Your previous V4 running processes remain untouched. The launcher selects a new free matching port group. Make sure Windows Node.js, npm, pnpm and valid Simfront Artifactory credentials/connectivity are available. The package contains source code, not node_modules, Node.js, a private npm cache, credentials, AI agents or a production video server. A full end-to-end Windows build is not verified in this environment.

**If a prior V4 folder already has partially installed dependencies:** use the fresh V4.1 extracted folder rather than copying over `node_modules` from V4.

---

# V4 startup note

For automatic free-port startup, use **START-EVERYTHING-WINDOWS.bat** and **README-START-HERE-COMPLETE-KIT.md** in this package. Fixed-port commands in the older integration notes below refer to prior versions, not the V4 launcher.

---

# MIDAS + Calian AI: Context-Aware Copilot (Option B, V2)

## What has changed

This bundle is based on the previously delivered MIDAS/Calian iFrame source integration, not a replacement for the working chatbot. The Calian Angular 19 frontend continues to run independently of the MIDAS Angular 21 frontend; the Node backend, auto-agent routing, agent-chain orchestration, speech and existing video functions are retained.

**New in V2:** a single *persistent* Calian iframe appears as a collapsible, expandable MIDAS Copilot panel alongside the live MIDAS interface. MIDAS publishes only a bounded, opt-in snapshot of current UI state to the iframe. A versioned `postMessage` bridge permits Calian to propose a small set of safe MIDAS UI actions. The MIDAS host, not the chatbot, validates and applies those actions, and every action requires an explicit user approval in the host toolbar.

The previous `/calian-ai` route continues to open Calian as a maximized full-page Copilot using that *same* iframe; switching back to a side panel does not replace the iframe instance and should preserve its in-memory chat session.

## Source changes

### MIDAS Angular 21 (`midas/midas-frontend/`)
- `src/app/components/calian-ai/midas-calian-copilot.component.ts`: persistent panel, opt-in context, handshake, exact origin/frame validation, action allowlist, confirmation and NgRx dispatch.
- `src/app/components/calian-ai/midas-copilot-ui-state.ts`: shared open/full-page state.
- `src/app/components/calian-ai/calian-ai.component.ts`: `/calian-ai` placeholder; the global panel owns the only iframe.
- `src/app/app.component.ts` and `.html`: always mount the panel, preserve dashboard routing, hide the old MIDAS floating AI when the Copilot is visible.
- `src/assets/calian-embed-config.js`: admin-controlled Calian frontend URL.

### Calian Angular 19 (`Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/`)
- `src/app/midas-bridge.ts`: bounded command parser, typed action proposals, fenced JSON proposal parser.
- `src/app/app.component.ts`, `.html`, `.scss`: bridge handshake; opt-in context added to the existing `SharedContext.taskContext`; MIDAS Controls in inspector; natural-language navigation / filtering requests from the main chat; **Propose MIDAS action** button for agent suggestions.
- `src/index.html` and `public/midas-bridge-config.js`: approved MIDAS parent origin list (development defaults only).
- `scripts/test-midas-bridge.cjs`, `package.json`: parser unit tests (`npm run test:midas-bridge`).

### Supported approved actions (current implementation)
1. `navigate`: one of the existing MIDAS Advanced Metrics dashboard/report routes (Summary, Combat Power, Rate of Movement, C2, etc.).
2. `time_format`: dispatches MIDAS's existing `sidebarActions.timeFormatSelected`, only for names actually in the NgRx time-format list.
3. `cp_time_range`: dispatches `cpActions.timeframeChange` only on Combat Power and only inside the actual MIDAS min/max bounds; **numeric native MIDAS time units**, not automatically minutes.
4. `cp_select_entity`: selects/deselects a Combat Power entity using its real ID, only if the ID is in the loaded MIDAS entity list.

Current context includes the route, selected / available time formats and, only on the Combat Power dashboard, current timeframe and a bounded set of entity IDs/names. It **does not automatically transmit database records or query data**, and it is explicitly user-opt-in each time the panel is reopened. No arbitrary DOM clicks, JavaScript evaluation, filesystem access, SQL execution or direct LLM writes to MIDAS are permitted.

## Windows local setup

1. Extract the ZIP into a *new folder*, retaining the supplied directory structure.
2. If MIDAS's private packages are not installed, the previously observed `ERR_PNPM_TARBALL_URL_MISMATCH` must be resolved first. This archive also contains `FIX-MIDAS-PNPM-REGISTRY-WINDOWS.ps1` as a **separate, explicit opt-in** script; it backs up the lockfile before removing only the 12 legacy explicit Artifactory tarball entries, retains integrity hashes, and retries the frozen-lockfile install against the specified project-only registry. **Confirm the approved registry with your team before running it.** This does not disable pnpm security policies; further private access problems may remain.
3. In `Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES`, run `npm install` if needed; retain your working environment and backend credentials privately (never share them in screenshots).
4. Run `START-MIDAS-CALIAN-DEV-WINDOWS.bat` from the newly extracted ZIP. It starts Calian backend port 8797, Calian browser port 4300 and MIDAS port 4200 when not occupied; it does **not** launch Electron. **If an older Calian UI is already running on 4300 or older MIDAS frontend on 4200, stop the older dev server with Ctrl+C so the V2 code can start.** The launcher warns when it detects an older running UI. Don't terminate unrelated services.
5. Open `http://127.0.0.1:4200/`; select **Advance Metrics Application**, then click **Calian AI Copilot**. Alternatively open `http://127.0.0.1:4200/calian-ai` for maximized mode.
6. In the MIDAS panel toolbar, tick **Share dashboard context**. Calian's topbar now offers **MIDAS Controls**, showing the opt-in route/context snapshot and command input in the context inspector. The iframe should show **Bridge connected** in the MIDAS toolbar.
7. Try: `Open Combat Power` in the main Calian chat. MIDAS should show **Approve MIDAS change?**. Select **Approve**, then view Combat Power alongside the assistant. Try `Set time format to <one of the listed time formats>`, or on Combat Power `Select entity <actual name or ID>` and `Set time range 20 to 40` (only when bounds contain those numbers).
8. For agent-produced actions, the agent may return a suggestion in a fenced `midas-action` JSON block. Click the **Propose MIDAS action** button beside that assistant response and approve the proposal in MIDAS. No agent proposal executes automatically.
9. Run `npm run test:midas-bridge` from Calian project after installing dependencies, and the included `TEST-MIDAS-CALIAN-LOCAL.ps1` for endpoint smoke checks. Test real agent calls, video permissions, webcam and group sessions separately.

## Example agent-produced proposal

An agent can **suggest**, not execute, this text:

```midas-action
{"action":"navigate","params":{"dashboard":"cp"}}
```

The UI displays a **Propose MIDAS action** button. The action is not sent until the user clicks the button, and MIDAS requires *another explicit approval* before navigation. Unsupported action types and invalid parameters are rejected.

## Deployment and security

- Keep MIDAS and Calian separately built/deployed. Calian's UI/backend must be reachable by end users as an HTTPS site, with HTTPS proxying of `/api`, `/ws`, video gateways / LiveKit as needed. Set MIDAS's `src/assets/calian-embed-config.js` to the approved Calian URL. The URL is **not** an authentication token.
- In production set `window.__CALIAN_MIDAS_ALLOWED_ORIGINS__` in Calian's `public/midas-bridge-config.js` to the exact, administrator-approved HTTPS MIDAS origin(s), then rebuild/redeploy. The file defaults to *no allowed production MIDAS hosts*. Never derive this allowlist from arbitrary `document.referrer` values or use wildcard origins. The shipped local defaults allow only `localhost` and `127.0.0.1` MIDAS on port 4200.
- Set Calian's optional `CALIAN_EMBED_PARENT_ORIGIN` and CSP `frame-ancestors` to allow only MIDAS; set MIDAS `frame-src` to allow only the approved Calian host. Strict message origin + iframe source + session nonce checks are implemented in the frontend but **are not a substitute for server-side authentication/authorization**.
- Production blockers: company-approved SSO / per-user auth across both web apps, server-side role checks for Calian API / WebSocket / video and invitation scopes, centralized audit trail for authorized UI actions, secure cookies, HTTPS and Permissions Policy. MIDAS's localStorage workspace preference is **not** proof of identity. No backend authorization layer was added by this V2 prototype.
- The host confirmation protects browser UI state but cannot guarantee the underlying service authorizes the corresponding operation. Existing MIDAS API permissions must remain in effect.
- Browser iframe media permissions do not guarantee video calls will function in all embedding contexts; check browser permission prompts, group call behavior and LiveKit server configuration. The Electron desktop flow remains independent.

## Validation status

- TypeScript source was parsed successfully using the TypeScript compiler API (not a full Angular build).
- A packaged, build-free parser test covers 10 allowed/blocked MIDAS command/proposal cases and passed locally.
- Full MIDAS Angular compilation, browser-to-browser bridge integration, real MIDAS/Simfront API connectivity, authenticated external-user access, agent orchestration and video conference functionality **could not be executed here** because the required private MIDAS packages and running services are only on the user's system. These require the local acceptance checks above.

**If the MIDAS installation still fails**, fix the pnpm lockfile/Artifactory issue before attempting the MIDAS browser test. The Calian standalone backend and frontend remain independently runnable.
