@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ===================================================
echo AI Chatbot V7 SYNTHETIC TEST MODE - NOT REAL MIDAS DATA
echo This launches its own free ports. V6.5 is untouched.
echo ===================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0ENABLE-V7-SYNTHETIC-TEST.ps1"
if errorlevel 1 (echo Could not enable demo configuration. & pause & exit /b 1)
set "MIDAS_V7_FIXTURE_MODE=true"
call "%~dp0START-EVERYTHING-WINDOWS.bat"
endlocal
