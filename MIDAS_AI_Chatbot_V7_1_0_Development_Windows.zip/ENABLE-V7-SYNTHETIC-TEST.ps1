# Explicitly enable V7 TEST-ONLY features in THIS extracted V7 directory.
# Does not change existing V6.5 installation; preserves .v7-before-demo backups.
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$files=@(
 @{path=(Join-Path $root 'midas\midas-frontend\src\assets\calian-embed-config.js');from='contextV2: false, typedActions: false';to='contextV2: true, typedActions: true'},
 @{path=(Join-Path $root 'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\public\ai-chatbot-v7-config.js');from='syntheticDemo:false, nlActions:false';to='syntheticDemo:true, nlActions:true'}
)
foreach($f in $files){
 if(!(Test-Path -LiteralPath $f.path)){throw "File not found: $($f.path)"}
 $content=[System.IO.File]::ReadAllText($f.path)
 if($content.Contains($f.to)) {Write-Host "Already enabled: $($f.path)" -ForegroundColor Yellow;continue}
 if(!$content.Contains($f.from)){throw "Refusing to modify unexpected config: $($f.path)"}
 $backup=$f.path+'.v7-before-demo'
 if(!(Test-Path -LiteralPath $backup)){Copy-Item -LiteralPath $f.path -Destination $backup}
 [System.IO.File]::WriteAllText($f.path,$content.Replace($f.from,$f.to))
}
Write-Host 'V7 experimental flags enabled in this V7 source copy. This is SYNTHETIC DATA only.' -ForegroundColor Green
