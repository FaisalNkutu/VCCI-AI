**V7.0.2 DATABASE REPAIR:** Configure DBAgent separately with `CONFIGURE-V7-DATABASE-WINDOWS.bat`, then launch a new V7 isolated instance; see `README-V7-0-2-DATABASE.md`. Real MIDAS authorization remains disabled.

# AI Chatbot + MIDAS V7 — Isolated Development Implementation

**Status: V7 development build. NOT approved for real MIDAS data or production.**

This package is a separate source copy of the tested V6.5 code with new V7 feature-flagged functionality. It does **not** overwrite or patch your working V6.5. Extract it into a different directory with a path that contains no `#` character.

## What is implemented

| Workstream | V7 source implementation | Verification and limitation |
|---|---|---|
| Stable V6.5 | Original source preserved as a distinct ZIP, development copy + SHA256 reference, separate auto-allocated local ports | Back up your real, working V6.5 folder before use. This ZIP is not a backup of local changes |
| Context V2 | Versioned, opt-in, bounded UI selection envelope, monotonic revisions, stale-replay rejection and context revocation | Does not attest to data authorization or actual measurements |
| MIDAS data intelligence | Read-only tool registry; deterministic synthetic Summary/Combat Power test measurements; evidence ID, source label, units, bounds | No real data until MIDAS server identity and per-entity authorization adapter exists |
| Multi-agent | Existing bounded multi-agent chain can consume **server-created** synthetic evidence, with evidenceId in trace response | Requires local Ollama and configured agents for full demo. Must never label synthetic output as operational evidence |
| Natural-language controls | Opt-in typed intent interpreter (dashboard navigation, time range, time format, grouping, existing entities) and V7 typed preflight registry | All UI mutations still go through existing MIDAS approval and latest-state validation. No arbitrary DOM/SQL |
| Security | Strict tool allowlist, loopback synthetic fixture, max entities/time bounds, production read gateway fails closed, context-size limit | OIDC, RBAC, classification-aware routing, audited production gateway **not yet implemented**; deployment blocked |
| Testing | 29 Node tests across context, action validation, fixture provenance, baseline code presence and existing agent-chain | Full Angular/Java builds and Playwright tests require your authorized dependencies and environment |

## Standard launch — no V7 experimental features (safe default)

1. Extract this ZIP to e.g. `C:\Projects\AI_Chatbot_MIDAS_V7_Development` (not on top of V6.5).
2. Double-click `RUN-V7-CHECKS-WINDOWS.bat` to run tests with Node 22.16+.
3. Double-click `START-V7-ISOLATED-WINDOWS.bat` to install dependencies if missing and start new services on the next free port group.
4. In browser, use the displayed MIDAS URL. All V6.5 capabilities should still work.

**Private Simfront Artifactory access is required to install the MIDAS frontend.** This package does not contain secret credentials or node_modules.

## Explicit synthetic V7 demo

For a **separate test-only instance**, double-click `START-V7-SYNTHETIC-DEMO-WINDOWS.bat` instead. It:

1. Enables the V7 context and action feature flags inside **this V7 source copy only** (backs up each config file once).
2. Sets `MIDAS_V7_FIXTURE_MODE=true` in the newly launched backend process environment.
3. Starts its own free port family without killing or reusing your V6.5 services.
4. Adds two buttons under AI Chatbot's MIDAS Controls: **View test evidence** and **Run synthetic multi-agent test**.

Test entities 101 and 102 with times 0–120. Their values are synthetic, not MIDAS data. `Run synthetic multi-agent test` requires configured live agent services. `View test evidence` works without them if the backend starts.

### Example responses

- `Open Combat Power`, `Please show me summary`, `Show Rate of Movement` → approval-gated navigation proposals.
- `Set time range 10 to 30` → range proposal only when current MIDAS time bounds permit it.
- `Select entity 101` → proposal only if entity 101 is available in MIDAS's selected entity list.
- With no MIDAS data source: real data analysis must return **unavailable**, not invented numbers.

## Safety and production blockers

Production is NOT ready. The existing Node/Express API and WebSocket endpoint still require verified identity, secure session exchange, role/dataset policies and a classification-aware MIDAS Java/Micronaut read API. Browser origin/token checks only validate cross-window messages; they do not authenticate a user. No real MIDAS read proxy is enabled by V7. When fixture mode is off, `/api/midas/v7/read` returns HTTP 503 instead of guessing or returning data.

Do not insert MIDAS access tokens into browser configuration or messages. Do not forward classified/sensitive MIDAS data to unapproved models. Use approved security review before enabling actual data access.

## Regression list to complete on Windows

- Full `pnpm install --frozen-lockfile`, `ng build` for MIDAS; `npm install`, `npm run build` for AI Chatbot; Java/Micronaut build.
- Navigate Summary/Combat Power/CM/ROM, workspaces and Close, verify no blank screens.
- Test 350–1100px side-panel resizing, Expand, Pop out, Compact/Standard/Large/Center, Dock; chat survives.
- Test Speak → Stop → transcription → Send and Read responses; all buttons visible.
- Test manual and auto agent selection, multi-agent trace, one-to-one and group video, WebSocket reconnect.
- Test opt-in context, context revocation, rapid change ordering, typed actions approval/reject/duplicate.
- Test fixture read, evidence ID, synthetic labels and unavailable when fixture OFF.

## Suggested next step toward full V7 production

Connect an organization-approved OIDC identity provider to MIDAS and AI Chatbot, implement an authenticated and dataset-scoped server-side read adapter in `midas/midas-microservice/`, and run authorization/real-data acceptance tests. This is **not** in the current V7 development build because the required organization-specific identity, permissions and MIDAS data access details are not available in the provided sources.

## Optional browser tests and rollback

The `E2E/` folder contains opt-in Playwright smoke checks. They were not run in this environment, because the full MIDAS runtime and private Artifactory dependencies were unavailable. `RUN-V7-CHECKS-WINDOWS.bat` covers dependency-free unit and static regression checks. To turn off V7 source feature flags, execute `DISABLE-V7-EXPERIMENTS-WINDOWS.ps1` (then restart only V7). Your V6.5 installation was never modified by this package.
