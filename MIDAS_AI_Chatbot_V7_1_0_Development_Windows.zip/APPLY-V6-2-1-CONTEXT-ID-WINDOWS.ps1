﻿# AI Chatbot V6.2.1 — targeted TypeScript TS2322 fix
param([string]$ProjectRoot = '')
$ErrorActionPreference = 'Stop'
$relative = 'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\app.component.ts'
Write-Host 'AI Chatbot V6.2.1 - TS2322 context ID type fix' -ForegroundColor Cyan
Write-Host 'Only the Calian Angular app.component.ts contextId field will change.'
Write-Host 'No process shutdown, pnpm install, or port changes.'

function Get-Target([string]$root) {
    if ([string]::IsNullOrWhiteSpace($root)) { return $null }
    $direct = Join-Path $root 'src\app\app.component.ts'
    if ((Test-Path -LiteralPath $direct) -and $root.TrimEnd('\') -match 'CALIAN_AI_ELECTRON_THEMES$') { return $direct }
    $combined = Join-Path $root $script:relative
    if (Test-Path -LiteralPath $combined) { return $combined }
    return $null
}

$target=Get-Target $ProjectRoot
if (-not $target) {
    $choices = New-Object System.Collections.Generic.List[string]
    $locations = @((Join-Path $env:USERPROFILE 'Downloads'), (Get-Location).Path) | Select-Object -Unique
    foreach ($location in $locations) {
        if (-not (Test-Path -LiteralPath $location)) { continue }
        $dirs = @((Get-Item -LiteralPath $location)) + @(Get-ChildItem -LiteralPath $location -Recurse -Directory -Depth 4 -ErrorAction SilentlyContinue)
        foreach ($d in $dirs) {
            $candidate = Get-Target $d.FullName
            if ($candidate -and -not $choices.Contains($candidate)) { $choices.Add($candidate) }
        }
    }
    if ($choices.Count -eq 0) { throw 'No extracted AI Chatbot source found. Run with -ProjectRoot "path to the extracted V6.2 root".' }
    Write-Host 'Select the chatbot SOURCE folder serving your active browser URL:' -ForegroundColor Yellow
    for ($i=0; $i -lt $choices.Count; $i++) { Write-Host ('[{0}] {1}' -f ($i+1),$choices[$i]) }
    $choice=Read-Host 'Number (blank cancels)'
    if ($choice -notmatch '^\d+$' -or [int]$choice -lt 1 -or [int]$choice -gt $choices.Count) { throw 'Cancelled; no files changed.' }
    $target=$choices[[int]$choice-1]
}
$target = (Resolve-Path -LiteralPath $target).Path
$contents = [IO.File]::ReadAllText($target)
$old='contextId=crypto.randomUUID(); previousAgentId:string|null=null;'
$new='contextId: string = crypto.randomUUID(); previousAgentId:string|null=null;'
if ($contents.Contains($new)) { Write-Host 'This fix is already present. No changes necessary.' -ForegroundColor Green; exit 0 }
if (-not $contents.Contains($old)) { throw 'Expected V6.2 contextId declaration not found. No changes made.' }
if (-not $contents.Contains("this.contextId=s['contextId']")) { throw 'Not the expected V6.2 session-handoff source. No changes made.' }
if ($contents.Split(@($old),[StringSplitOptions]::None).Length -ne 2) { throw 'Unexpected multiple contextId declarations; no changes made.' }
Write-Host ('Target: ' + $target) -ForegroundColor Yellow
$confirm=Read-Host 'Type Y to make the backup and apply the one-line fix'
if ($confirm -notin @('y','Y')) { Write-Host 'Cancelled; no files changed.'; exit 0 }
$backup=$target+'.v6.2.1.'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.bak'
Copy-Item -LiteralPath $target -Destination $backup -ErrorAction Stop
try {
    $updated = $contents.Replace($old,$new)
    [IO.File]::WriteAllText($target, $updated, [Text.UTF8Encoding]::new($false))
    Write-Host 'TS2322 declaration corrected.' -ForegroundColor Green
    Write-Host ('Backup: '+$backup)
    Write-Host 'Allow Angular watch-mode to rebuild. Refresh browser after successful compilation.'
} catch {
    Copy-Item -LiteralPath $backup -Destination $target -Force
    throw
}
