const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const r=path.resolve(__dirname,'..');
let ts;
for(const candidate of [
 path.join(r,'Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/node_modules/typescript'),
 path.join(r,'midas/midas-frontend/node_modules/typescript'),
 'typescript',
 '/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript'
]) {try {ts=require(candidate);break;}catch {}}
if(!ts) {console.error('Install MIDAS/AI Chatbot dependencies to run this optional verification test (typescript required).');process.exit(2);}
const chatbot=path.join(r,'Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/src/app');
const midas=path.join(r,'midas/midas-frontend/src/app/components/calian-ai');
function moduleFrom(file){const source=fs.readFileSync(file,'utf8');const code=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;const mod={exports:{}};vm.runInNewContext(code,{exports:mod.exports,module:mod,console},{filename:file});return mod.exports}
const parser=moduleFrom(path.join(chatbot,'midas-bridge.ts'));
const tools=moduleFrom(path.join(midas,'midas-tool-gateway.ts'));
let n=0;function test(ok,msg){assert.ok(ok,msg);n++}
const context={route:'/advmetrics/cp',timeBounds:{min:0,max:100},cpTimeBounds:{min:0,max:100},availableTimeFormats:['Minutes','Hours'],cpEntities:[{id:123,name:'Alpha'}]};
for(const [text,action,dashboard] of [['Open Summary','navigate','summary'],['Open CM Occupations','navigate','cm'],['Open Control Measures','navigate','cm'],['Open Enemy Engagement','navigate','enemy-engagement'],['Open Combat Power','navigate','cp']]) {const v=parser.parseMidasCommand(text,context,null);test(v?.action===action && v.params.dashboard===dashboard,text)}
test(parser.parseMidasCommand('Change time format to Minutes',context,null)?.action==='time_format','time format');
test(parser.parseMidasCommand('Select entity 123',context,null)?.action==='cp_select_entity','entity');
test(parser.parseMidasCommand('Change Combat Power grouping to equipment',context,null)?.params.grouping==='equipment','grouping');
test(parser.parseMidasCommand('Set time range 10 to 30',context,null)?.action==='cp_time_range','CP timeframe');
test(parser.parseMidasCommand('Set time range 10 to 30',{...context,route:'/advmetrics/rom'},null)?.action==='rom_time_range','ROM timeframe');
test(parser.parseMidasCommand('Set time range 10 to 30',{...context,route:'/advmetrics/cm'},null)?.action==='cm_time_range','CM timeframe');
test(parser.parseMidasCommand('Select capture 11',{...context,route:'/advmetrics/rom',romCaptures:[{id:11,name:'Capture A'}]},null)?.action==='rom_select_capture','ROM capture selection');
test(parser.parseMidasCommand('Select control measure 7',{...context,route:'/advmetrics/cm',cmMeasures:[{id:7,name:'Bridge'}]},null)?.action==='cm_select_measure','CM measure selection');
test(parser.parseMidasCommand('Delete all data',context,null)===null,'reject destructive action');
test(tools.seriesStats([{time:3,combatPower:11},{time:1,combatPower:5},{time:2,combatPower:8}]).change===6,'trend change');
test(tools.seriesStats([])===null,'no fake stats');
test(tools.normalizeDashboard('CM Occupations')==='cm','capability aliases');
const host=fs.readFileSync(path.join(midas,'midas-calian-copilot.component.ts'),'utf8');
const frontend=fs.readFileSync(path.join(chatbot,'app.component.ts'),'utf8');
const html=fs.readFileSync(path.join(chatbot,'app.component.html'),'utf8');
test(host.includes("dataSourceConnected: this.store.selectSignal(selectConnectedDB)().connected === true"),'connection status from MIDAS');
test(host.includes("data.type === 'TOOL_REQUEST'")&&host.includes("this.handleToolRequest(data.id, data.tool, source)"),'read tool bridge');
test(frontend.includes("message:agentQuery")&&frontend.includes('a2aRequest(agent.id,agentQuery'),'context in multi-agent and A2A queries');
test(html.includes('Include MIDAS context in AI queries')&&html.includes('Export evidence (.md)'),'query control and report');
test(host.includes('panelWidth = signal(540)')&&host.includes('resizePanel($event)'),'side panel resizable');
test(host.includes('approve(): Promise<void>')&&host.includes('validateRequest(item.request.action'),'host revalidation on approve');
console.log(`PASS ${n} V6 bridge, query, UI, and safety checks`);
