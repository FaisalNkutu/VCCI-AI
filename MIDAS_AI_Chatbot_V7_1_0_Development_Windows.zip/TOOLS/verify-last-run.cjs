// Read-only runtime smoke test for the most recent V4 launch (requires Node 22+).
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const base=path.join(root,'RUNS');
const files=fs.existsSync(base)?fs.readdirSync(base,{withFileTypes:true}).filter(x=>x.isDirectory()).map(x=>path.join(base,x.name,'instance.json')).filter(x=>fs.existsSync(x)):[];
if(!files.length){console.error('No V4 instance records. Run START-EVERYTHING-WINDOWS.bat first.');process.exit(1)}
files.sort((a,b)=>fs.statSync(b).mtimeMs-fs.statSync(a).mtimeMs);
const run=JSON.parse(fs.readFileSync(files[0],'utf8').replace(/^\uFEFF/,''));
console.log(`Verifying ${run.id}: MIDAS ${run.ports.midas}, Calian ${run.ports.calian}, backend ${run.ports.backend}`);
async function fetchText(url){const res=await fetch(url,{signal:AbortSignal.timeout(10000)});if(!res.ok)throw Error(`${url} returned HTTP ${res.status}`);return res.text()}
async function check(){
 const midasUrl=`http://127.0.0.1:${run.ports.midas}`;
 const calianUrl=`http://127.0.0.1:${run.ports.calian}`;
 const backendUrl=`http://127.0.0.1:${run.ports.backend}`;
 const midas=await fetchText(`${midasUrl}/assets/calian-embed-config.js`);
 if(!midas.includes('MIDAS-CALIAN-BRIDGE-V4'))throw Error('MIDAS is not serving V4 embed config');
 console.log('PASS MIDAS iframe config');
 const child=await fetchText(`${calianUrl}/midas-bridge-config.js`);
 if(!child.includes('MIDAS-CALIAN-BRIDGE-V4'))throw Error('Calian is not serving V4 bridge config');
 console.log('PASS Calian bridge config');
 const localHealth=JSON.parse(await fetchText(`${backendUrl}/api/health`));
 if(localHealth.instanceId!==run.id)throw Error('Backend instance ID does not match the V4 launch');
 console.log('PASS isolated backend instance ID');
 const proxiedHealth=JSON.parse(await fetchText(`${calianUrl}/api/health`));
 if(proxiedHealth.instanceId!==run.id)throw Error('Calian /api proxy is targeting the wrong backend');
 console.log('PASS Calian /api proxy matches backend instance');
 if(typeof WebSocket!=='function'){console.log('SKIP WebSocket check: Node 22+ required');return}
 const wsUrl=`ws://127.0.0.1:${run.ports.calian}/ws`;
 await new Promise((resolve,reject)=>{
   const ws=new WebSocket(wsUrl);const t=setTimeout(()=>{ws.close();reject(Error('WebSocket timeout'))},12000);
   const fail=e=>{clearTimeout(t);reject(e instanceof Error?e:Error('WebSocket error'))};
   ws.addEventListener('open',()=>ws.send(JSON.stringify({id:'v4-smoke-check',path:'/api/health',method:'GET'})));
   ws.addEventListener('message',e=>{
     let d;try{d=JSON.parse(String(e.data))}catch(err){fail(err);return}
     if(d.id!=='v4-smoke-check')return;
     if(d.type==='error'){fail(Error(d.error));return}
     if(d.type==='result'){
       clearTimeout(t);ws.close();
       if(d.data?.instanceId!==run.id)reject(Error('WebSocket connected to wrong backend'));
       else {console.log('PASS Calian /ws proxy to correct backend');resolve()}
     }
   });
   ws.addEventListener('error',fail);
 });
}
check().then(()=>console.log('PASS V4 HTTP/WS smoke tests; verify chat/dashboard actions in browser.')).catch(e=>{console.error('FAIL',e.message);process.exitCode=1});
