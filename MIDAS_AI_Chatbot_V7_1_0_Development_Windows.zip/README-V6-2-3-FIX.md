# MIDAS + AI Chatbot V6.2.3 — navigation and pop-out focus fix

## Verified source-code causes

1. **Blank MIDAS dashboard:** In `midas-frontend/src/app/app.component.ts`, the old `calianAi` computed expression used `router.url.startsWith('/calian-ai') || currentUrl()?.url.startsWith(...)`. When first computed while on `/calian-ai`, the short-circuit branch prevented `currentUrl()` from being read, so Angular did not subscribe to navigation changes. The computed value could remain `true` and keep `<router-outlet>` hidden after navigating to other MIDAS dashboards. The new expression always reads the NavigationEnd signal.
2. **Pop-out appears to disappear:** The Compact/Standard/Large/Center buttons were in the original MIDAS window. Clicking MIDAS brings that window to the foreground; browser policies can ignore `window.focus()` and keep the pop-out behind it. V6.2.3 puts size and centre controls inside the pop-out window itself. The old popup remains open and can be recovered via Alt+Tab or the host **Focus pop-out** button.

## What changed

- The MIDAS router-outlet visibility check reacts to every NavigationEnd.
- Resizing controls now appear in the standalone browser pop-out; dimensions are clamped to the available screen to avoid requests larger than the laptop display.
- MIDAS shows **Focus pop-out** and **Dock in MIDAS**, with a clear note about window focus. The popup never intentionally closes when a size command is clicked.
- No changes to agents, authentication rules, `postMessage` origin checks, MIDAS action approval, data source configuration, dependency versions, Angular libraries, or port selection.

## Applying the small patch

1. Extract `MIDAS_AI_Chatbot_V6_2_3_Quick_Fix.zip`.
2. Double-click `APPLY-V6-2-3-WINDOWS.bat`. If prompted, select the exact MIDAS/AI Chatbot installation powering the browser you are using (multiple instances may exist).
3. Confirm the backup and patch. The launcher only modifies three source components and the AI Chatbot stylesheet.
4. Check that both Angular consoles report successful compilation. Refresh MIDAS (Ctrl+Shift+R) and the pop-out. If a hot reload fails, restart **only the affected instance**, not unrelated instances.
5. Open MIDAS and choose Fratricide, Summary, Combat Power, etc.; each page should load its content (possibly empty if MIDAS has no data source).
6. Click **Pop out**, then use **Compact**, **Standard**, **Large** or **Center** inside the new pop-out toolbar. The separate window remains visible when resizing. You may drag the native title bar and window edges manually.

## Limitations and safety

The new source passed static syntax and targeted regression checks. Full Angular builds and Windows UI validation were **not available** in the build environment. Browser window managers may reject scripted resizing/centering. This patch does not fix absent MIDAS data sources or backend service errors. If a dashboard remains empty, inspect browser Console (F12) and Angular terminal for runtime errors and confirm the address bar points to the intended new instance.
