# MIDAS AI Chatbot V7.0.6 — Visible Auto-send and voice database selection

Full Windows development package based on V7.0.5. No separate patch is needed. Backend, SQL generation, agents, MIDAS host, configuration and video source files are unchanged.

## Installation
1. Stop the running V7.0.5 development services. Extract this archive into a new directory, e.g. C:\Projects\MIDAS_AI_Chatbot_V7_0_6.
2. Follow the approved dependency and private registry configuration in README-V7-START-HERE.md. Existing external services and database credentials are required; no secrets should be added to this distributable.
3. Run RUN-V7-CHECKS-WINDOWS.bat with Node 22.16+.
4. Run START-V7-ISOLATED-WINDOWS.bat. Open the MIDAS URL reported by the launcher, hard-refresh (Ctrl+Shift+R), and verify v7.0.6 in the chatbot sidebar.

## Live voice acceptance checks
- Auto-submit voice is pinned immediately above Speak/Send in the non-scrolling voice control bar. It is OFF by default. Enable it before starting Hands-free if you want recognized questions automatically submitted without saying Send. Use only in a quiet, private setting; existing MIDAS approvals are not bypassed.
- Enable Hands-free. Say “List databases” and wait. The inspector opens and shows the current accessible database list with numbered choices. With a local playback voice available, the first 12 choices are also spoken. The displayed list is not truncated.
- Say “Select database number two” (use the actual desired number from your list) or “Select database vcci aug twenty six dbg one.” Selection is restricted to unique accessible names or a valid current list number, updates the existing database selector and persists the choice. It does not submit an agent query. Say “Which database is selected?” to check. If a question is pending, cancel it before switching databases.
- Speak the query “Select all records from table contxt_oi_assoc.” If auto-submit is off, wait for confirmation and say Send. If on, the query should submit automatically. Confirm the SQL has no unrequested WHERE clause and uses the selected schema. Verify the result independently.
- Say “Stop listening” to leave hands-free mode.

## Local speech playback
V7.0.5 turned hands-free off when the browser reported no local speech synthesis voices. V7.0.6 keeps listening and presents on-screen confirmations instead, including after playback errors. It checks the voice inventory again on each readback and continues to reject remote playback voices in hands-free mode. Audible replies still require a functioning local voice. On Windows 11, open Settings > Time & language > Speech and install an English voice under Manage voices/Add voices (wording can vary). Restart Edge/Chrome and retry. A Windows-installed voice may not be exposed as local by every browser. If unavailable, voice commands can still work with visual feedback; truly eyes-free audible conversation remains blocked until local playback works. Do not switch to a cloud TTS service for sensitive data without organizational approval.

## Verification
85/85 Node tests passed (74 existing, 11 new). The new tests exercise command and playback methods with mocked browser APIs and verify the pinned template structure. TypeScript component transpilation reports zero errors; this is not full Angular compilation. The full Windows/browser UI, microphone, live agent/database connection and real local voice playback remain unverified. SQL/backend/MIDAS/video files were not changed.
