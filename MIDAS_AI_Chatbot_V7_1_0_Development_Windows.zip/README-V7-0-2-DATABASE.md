# AI Chatbot + MIDAS V7.0.2 — DBAgent Configuration and SQL Routing

**Scope:** V7 development build only. Do **not** install over working V6.5.

## What was wrong in V7.0.1

1. The standalone Electron chatbot has a first-run `CALIAN_SCHEMA_DATABASE` option in its `calian.env`. The MIDAS-hosted browser V7 launcher did not set the corresponding environment variable.
2. Multiple REQA-accessible databases contain the same table `contxt_oi_assoc`; without a database/schema selection, table discovery must not guess.
3. In automatic multi-agent mode, raw SQL could be embedded in a general chatbot query containing unrelated MIDAS context. The planning agent could rewrite it into a count, introduce a timestamp, or incorrectly assert that MIDAS `dataSourceConnected=false` means DBAgent is offline.
4. MySQL uses `\`database\`.\`table\`` (two independently quoted identifiers), not `\`database.table\`` (one quoted identifier). A space after the opening identifier quote is also incorrect.
5. The existing REQA/DBAgent execution policy can reject `SELECT *` row reads or high limits; V7 cannot and must not bypass it.

## Fixes in V7.0.2

- `CONFIGURE-V7-DATABASE-WINDOWS.bat` prompts for one default schema (example `vcci_aug_26_dbg_1`) and creates `V7_DATABASE_CONFIG.json` containing **only** the schema name. No database usernames, passwords, connections or tokens are stored.
- The launcher reads that file into the **new** V7 backend process as `CALIAN_SCHEMA_DATABASE`. It retains automatic free port selection and does not stop existing processes.
- In AI Chatbot **Session Inspector → Context**, a **DBAgent · Database / Schema** section shows the selected schema; when enabled in **local-only** development, it can show the schemas already accessible to your existing REQA database connection. This is not a new database connection manager.
- The selected schema is validated against REQA metadata; it cannot select arbitrary unseen databases. Each request carries the chosen schema explicitly, without modifying global process environment across user requests.
- Direct `SELECT` queries go straight to the dedicated DBAgent read-only executor; they are **not** rewritten by the multi-agent planner, nor supplemented with MIDAS context. MIDAS `Select entity` operations remain on MIDAS's approval bridge.
- The direct SQL adapter uses `sqlglot` to apply the selected schema to unqualified tables. It rejects a conflicting qualified schema and refuses unqualified tables if no default or explicit database is selected.
- **Neither MIDAS data-source status nor time-format is used as DBAgent authorization.** MIDAS source may still be unconnected while the separate DBAgent data connection works.
- The existing read-only SQL validation and REQA permissions are retained. It reports service policy failures rather than guessing, rewriting the query, or producing fabricated results.

## Installation (recommended: V7-only quick fix)

1. Extract `MIDAS_AI_Chatbot_V7_0_2_Database_Quick_Fix.zip` into a new folder.
2. Double-click `APPLY-V7-0-2-DATABASE-WINDOWS.bat` and provide the exact extracted **V7.0.1** project directory. It checks `README-V7-START-HERE.md` before touching anything, and backs up the affected source files.
3. From your patched V7 project root, run `CONFIGURE-V7-DATABASE-WINDOWS.bat` and enter **`vcci_aug_26_dbg_1`**.
4. Run `START-V7-ISOLATED-WINDOWS.bat` to start a *new* isolated V7 instance with the newly selected schema. **Do not stop V6.5.** An already-running V7 backend retains its previous environment settings.
5. In AI Chatbot, open **Session Inspector → Context → DBAgent · Database / Schema**. If the selector can list schemas, choose the desired one. If it cannot enumerate REQA metadata, the configured default remains available to the backend.
6. Select **Intelligent Auto Select** or **DBAgent** and send the query below. It routes directly and read-only to DBAgent.

```sql
SELECT COUNT(*) AS total_records
FROM `vcci_aug_26_dbg_1`.`contxt_oi_assoc`;
```

Then try a small read (subject to REQA's actual read permissions):

```sql
SELECT *
FROM `vcci_aug_26_dbg_1`.`contxt_oi_assoc`
LIMIT 20;
```

If the second command is rejected with `Only count, list, and aggregate read-only operations are supported`, the **external REQA/DBAgent policy**, not MIDAS context, is blocking row retrieval. Have the authorized service owner confirm supported list operations. V7.0.2 deliberately does not bypass that policy.

## Regression tests

- Run `RUN-V7-CHECKS-WINDOWS.bat` from the V7 project root. It includes the pre-existing 29 tests and six new DBAgent routing/configuration checks.
- Verify that `Select entity 123` still produces MIDAS's approval proposal rather than going to DBAgent.
- Verify that `SELECT COUNT(*) ...` goes directly to DBAgent even when Intelligent Multi-Agent Chain is selected.
- Verify that the MIDAS UI works unchanged in side panel, expanded view and pop-out.
- Verify that any `dataSourceConnected=false` shown in MIDAS is not treated as DBAgent authentication or SQL failure.

## Security and verified limits

- Existing REQA database permissions remain the authority; this update does not create users, grant access, install MariaDB, or configure database credentials.
- The browser schema picker is **local-development only**, enabled by the isolated V7 launcher and exposed from a backend bound to `127.0.0.1`. Do not use it for employee or external-guest deployment without authentication, RBAC and per-dataset policy enforcement.
- No full Angular build, Windows startup or live REQA connection test could be run here. TypeScript transpilation, embedded Python syntax compilation, test assertions and ZIP integrity were checked.
- Preserve working V6.5 unchanged.
