# MIDAS AI Chatbot V7.0.7 — Voice database selection

Baseline: complete V7.0.6 Windows development archive. SQL generation, backend, routing, MIDAS integration, video, and audio capture/playback are unchanged.

Extract into a new directory, stop prior development services, run `START-V7-ISOLATED-WINDOWS.bat`, and follow existing setup instructions. The same private registry and local service configuration requirements apply. No patch is needed.

## Live test
1. Select Auto-submit voice, then Hands-free. Say “List databases” and wait until the numbered list is shown and listening resumes.
2. Say “Choose number two” (or the number of another accessible database). The selector and selected database status should change. Do not use a number without first opening the numbered list unless you say “Select database number two.”
3. Say “Which database is selected?” and verify the displayed confirmation. Then issue a normal read-only query and verify the generated SQL uses the selected schema. Change back to your original database if necessary.
4. If recognition fails, note the exact `Heard:` transcript and status. The transcript display is local to the component. Invalid or ambiguous explicit database-selection requests do not execute SQL. A pending query still must be sent or cancelled before changing its database.

New supported forms include “Please, select database number two”, “Switch database to number 2”, “Choose database, option 2”, “What databases are available?”, and short numeric choices while the list is open. Numbered choices follow the current displayed list order. Local speech playback limitations from V7.0.6 remain; no remote playback voice is enabled.

Validation: 91 source regression tests passed (85 prior plus six new). Tests exercise component command methods in a lightweight harness; full Angular compilation, Windows startup, actual Whisper recognition and live database switching remain unverified here. The precise original spoken transcript was not available, so this is a targeted robustness improvement rather than a confirmed reproduction of the live failure.
