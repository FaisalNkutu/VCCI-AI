@echo off
setlocal EnableExtensions
cd /d "%~dp0Standalone_Calian_AI_Chatbot\VIDEO_CALL_SERVICE"
if not exist package.json (
  echo ERROR: Video gateway source missing from extracted package.
  pause
  exit /b 1
)
where npm >nul 2>&1 || (echo ERROR: Node.js/npm is required. & pause & exit /b 1)
echo Installing optional Calian VIDEO_CALL_SERVICE dependencies...
call npm install --no-audit --no-fund
if errorlevel 1 (
  echo ERROR: Dependency installation failed. Check network/npm access.
  pause
  exit /b 1
)
echo.
echo Video gateway dependencies installed. This does not provision LiveKit, HTTPS,
echo TURN, DNS or credentials. See VIDEO_CALL_SERVICE\.env.example for configuration.
echo Do not publish this local gateway without server-side authentication.
pause
endlocal
