param([string]$ProjectRoot = '')
$ErrorActionPreference = 'Stop'
Write-Host 'MIDAS + AI Chatbot V6.2.5 — Summary and conversation readability' -ForegroundColor Cyan
Write-Host 'No port, process, dependency, lockfile or backend changes are made.'
function Test-ProjectRoot([string]$p) {
  if (!$p -or !(Test-Path -LiteralPath $p -PathType Container)) {return $null}
  $candidates = @($p, (Join-Path $p 'MIDAS_AI_Chatbot_V6_2_4_Full_Windows'))
  foreach ($candidate in $candidates) {
    $summary = Join-Path $candidate 'midas\midas-frontend\src\app\dashboards\summary\summary-dash.component.html'
    $chat = Join-Path $candidate 'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\app.component.ts'
    if ((Test-Path -LiteralPath $summary -PathType Leaf) -and (Test-Path -LiteralPath $chat -PathType Leaf)) { return (Resolve-Path -LiteralPath $candidate).Path }
  }
  return $null
}
$root = Test-ProjectRoot $ProjectRoot
if (!$root) {
  $locations = @((Join-Path $env:USERPROFILE 'Downloads'), (Get-Location).Path) | Select-Object -Unique
  $found = New-Object 'System.Collections.Generic.List[string]'
  foreach ($location in $locations) {
    if (!(Test-Path -LiteralPath $location -PathType Container)) {continue}
    $children = @(Get-Item -LiteralPath $location) + @(Get-ChildItem -LiteralPath $location -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '(?i)midas|chatbot' })
    foreach ($parent in $children) {
      $dirs = @($parent) + @(Get-ChildItem -LiteralPath $parent.FullName -Directory -ErrorAction SilentlyContinue)
      foreach ($dir in $dirs) {
        $matched = Test-ProjectRoot $dir.FullName
        if ($matched -and !$found.Contains($matched)) {$found.Add($matched)}
      }
    }
  }
  if ($found.Count -eq 0) { throw 'Could not locate V6.2.4 source in Downloads. Run APPLY-V6-2-5-WINDOWS.ps1 -ProjectRoot "C:\path\to\extracted\package".' }
  Write-Host 'Select the exact V6.2.4 source folder used by your active MIDAS and AI Chatbot ports:' -ForegroundColor Yellow
  for ($i=0; $i -lt $found.Count; $i++) {Write-Host ('[{0}] {1}' -f ($i+1), $found[$i])}
  $choice=Read-Host 'Installation number (blank cancels)'
  if ($choice -notmatch '^\d+$' -or [int]$choice -lt 1 -or [int]$choice -gt $found.Count) {throw 'Cancelled. No files changed.'}
  $root=$found[[int]$choice-1]
}
Write-Host ('Target: ' + $root) -ForegroundColor Cyan
$manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'PATCH_MANIFEST.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$todo=@()
foreach($entry in @($manifest)) {
  $target = Join-Path $root $entry.file
  $replacement = Join-Path $PSScriptRoot ('PATCH_FILES\' + $entry.file)
  if (!(Test-Path -LiteralPath $target -PathType Leaf)) {throw "Source missing: $target"}
  if (!(Test-Path -LiteralPath $replacement -PathType Leaf)) {throw "Patch file missing: $replacement"}
  $oldHash=(Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
  $replacementHash=(Get-FileHash -LiteralPath $replacement -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($replacementHash -ne [string]$entry.afterSha256) {throw "Patch integrity mismatch: $replacement"}
  if ($oldHash -eq [string]$entry.afterSha256) {Write-Host "Already updated: $target";continue}
  if ($oldHash -ne [string]$entry.beforeSha256) {throw "Different project version or local edits: $target. Refusing to overwrite."}
  $todo+=@{target=$target;replacement=$replacement}
}
if ($todo.Count -eq 0) {Write-Host 'V6.2.5 is already applied.' -ForegroundColor Green;exit 0}
Write-Host ('Five-file readability update; '+$todo.Count+' file(s) need changes.') -ForegroundColor Cyan
foreach($item in $todo){Write-Host ('  '+$item.target)}
$answer=Read-Host 'Type Y to back up and apply the update'
if ($answer -notin @('y','Y')){Write-Host 'Cancelled without changes.';exit 0}
$stamp=Get-Date -Format 'yyyyMMdd-HHmmss'; $backed=@()
try {
  foreach($item in $todo) {
    $backup=$item.target+'.v625.'+$stamp+'.bak'
    Copy-Item -LiteralPath $item.target -Destination $backup -ErrorAction Stop
    $backed+=@{target=$item.target;backup=$backup}
    Copy-Item -LiteralPath $item.replacement -Destination $item.target -Force -ErrorAction Stop
  }
  Write-Host 'Updated source files. Wait for BOTH Angular watchers to rebuild, then refresh MIDAS (Ctrl+Shift+R).' -ForegroundColor Green
  foreach($item in $backed) {Write-Host ('Backup: '+$item.backup)}
} catch {
  foreach($item in $backed) {Copy-Item -LiteralPath $item.backup -Destination $item.target -Force -ErrorAction SilentlyContinue}
  throw
}
