# AI Chatbot + MIDAS V6.2.3 — repair route blanking + popup focus
param([string]$ProjectRoot = '')
$ErrorActionPreference = 'Stop'
Write-Host 'MIDAS + AI Chatbot V6.2.3 - targeted navigation and pop-out fix' -ForegroundColor Cyan
Write-Host 'No dependency installation, process termination, or port modification.'

function Resolve-Root([string]$candidate) {
  if ([string]::IsNullOrWhiteSpace($candidate) -or !(Test-Path -LiteralPath $candidate -PathType Container)) { return $null }
  $root = $candidate
  $frontend = 'src\app\components\calian-ai\midas-calian-copilot.component.ts'
  if (Test-Path -LiteralPath (Join-Path $root $frontend)) {
    $root = (Resolve-Path -LiteralPath (Join-Path $root '..\..')).Path
  } elseif (Test-Path -LiteralPath (Join-Path $root ('midas-frontend\' + $frontend))) {
    $root = (Resolve-Path -LiteralPath (Join-Path $root '..')).Path
  }
  if ((Test-Path -LiteralPath (Join-Path $root 'midas\midas-frontend\src\app\app.component.ts')) -and
      (Test-Path -LiteralPath (Join-Path $root 'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\app.component.ts'))) { return $root }
  return $null
}

$root = Resolve-Root $ProjectRoot
if (!$root) {
  $choices = New-Object 'System.Collections.Generic.List[string]'
  $places = @((Join-Path $env:USERPROFILE 'Downloads'),(Get-Location).Path) | Select-Object -Unique
  foreach ($place in $places) {
    if (!(Test-Path -LiteralPath $place -PathType Container)) { continue }
    $candidates = @((Get-Item -LiteralPath $place)) + @(Get-ChildItem -LiteralPath $place -Directory -Recurse -Depth 5 -ErrorAction SilentlyContinue)
    foreach ($candidate in $candidates) {
      $found = Resolve-Root $candidate.FullName
      if ($found -and !$choices.Contains($found)) { $choices.Add($found) }
    }
  }
  if ($choices.Count -eq 0) { throw 'No suitable extracted project found. Run PowerShell script with -ProjectRoot "C:\path\to\project".' }
  Write-Host 'Choose the source installation powering your browser. Your system can have multiple active instances.' -ForegroundColor Yellow
  for ($i=0; $i -lt $choices.Count; $i++) { Write-Host ('[{0}] {1}' -f ($i+1),$choices[$i]) }
  $answer = Read-Host 'Number (blank cancels)'
  if ($answer -notmatch '^\d+$' -or [int]$answer -lt 1 -or [int]$answer -gt $choices.Count) { throw 'Cancelled without changes.' }
  $root = $choices[[int]$answer-1]
}
Write-Host ('Target: '+$root) -ForegroundColor Cyan

$manifest = @(Get-Content -LiteralPath (Join-Path $PSScriptRoot 'PATCH_MANIFEST.json') -Raw -Encoding UTF8 | ConvertFrom-Json)
$changes = @()
foreach ($entry in $manifest) {
  $target = Join-Path $root $entry.file
  if (!(Test-Path -LiteralPath $target -PathType Leaf)) { throw "Missing expected project source: $target" }
  $content = [IO.File]::ReadAllText($target)
  $needs = 0
  foreach ($edit in $entry.edits) {
    $before = [string]$edit.before; $after = [string]$edit.after
    if ($content.Contains($after)) { continue }
    $first = $content.IndexOf($before,[StringComparison]::Ordinal)
    if ($first -lt 0 -or $first -ne $content.LastIndexOf($before,[StringComparison]::Ordinal)) {
      throw "Unexpected source revision at $target. Aborting rather than overwriting local changes. Use the full V6.2.3 package as a new copy."
    }
    $content = $content.Replace($before,$after)
    $needs++
  }
  if ($needs -gt 0) { $changes += @{ path=$target; contents=$content; count=$needs } }
}
if ($changes.Count -eq 0) { Write-Host 'All changes already applied. Nothing changed.' -ForegroundColor Green; exit 0 }
Write-Host ('Files to update: '+$changes.Count) -ForegroundColor Yellow
foreach ($change in $changes) { Write-Host ('  '+$change.path+' ('+$change.count+' edits)') }
$answer = Read-Host 'Type Y to back up these files and apply the targeted update'
if ($answer -notin @('y','Y')) { Write-Host 'Cancelled, no files changed.'; exit 0 }
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backups = @()
try {
  foreach ($change in $changes) {
    $backup = $change.path+'.v6.2.3.'+$stamp+'.bak'
    Copy-Item -LiteralPath $change.path -Destination $backup -ErrorAction Stop
    $backups += @{source=$change.path;backup=$backup}
    [IO.File]::WriteAllText($change.path,[string]$change.contents,[Text.UTF8Encoding]::new($false))
  }
  Write-Host 'V6.2.3 source update applied. Check MIDAS and AI Chatbot consoles for successful rebuilds.' -ForegroundColor Green
  foreach($b in $backups) { Write-Host ('Backup: '+$b.backup) }
  Write-Host 'Existing unrelated processes and ports were not touched.'
} catch {
  foreach ($b in $backups) { if (Test-Path -LiteralPath $b.backup) { Copy-Item -LiteralPath $b.backup -Destination $b.source -Force } }
  throw
}
