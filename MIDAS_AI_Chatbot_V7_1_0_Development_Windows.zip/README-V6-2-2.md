# AI Chatbot / MIDAS V6.2.2 — TypeScript compile fixes

## What was wrong

Angular reports `TS18048: 'chart' is possibly 'undefined'` in
`midas/midas-frontend/src/app/components/calian-ai/midas-calian-copilot.component.ts`
when it compiles the Combat Power read-only data tool. MIDAS's
`selectCpChartData` selector can return `undefined` while data is unavailable.
The code previously accessed `chart.chartData.datasets` without checking.

The fix checks for missing chart data and defaults to an empty dataset array.
It does not fabricate analytical results; an unavailable comparison still
requires two loaded series. The original authorization, approval, bridge,
resize, pop-out, agent routing, and video code remain unchanged.

The quick fix also applies the previous `TS2322` session-ID typing correction
if your existing source still has the older declaration.

## Apply to your *existing* source

1. Extract `MIDAS_AI_Chatbot_V6_2_2_Quick_Fix.zip`.
2. Double-click `APPLY-V6-2-2-WINDOWS.bat`.
3. Choose the specific extracted project whose MIDAS/Calian dev servers you are using.
   Do not select an older or unrelated copy. The script lists full paths.
4. Confirm `Y`. The script creates timestamped `.bak` backups before changing files.
5. Allow the Angular watch compiler to rebuild and refresh the browser only
   **after** compilation succeeds.

This quick fix does not install packages or stop running processes. If the
Angular compiler still reports another error, share its first `ERROR` line.

## What has and has not been verified

- Checked the failing source in the V6.2.1 integrated ZIP against the screenshot.
- Corrected only the undefined-chart dereference; retained the session-ID fix.
- Ran a focused strict TypeScript nullability compile test and source syntax checks.
- Verified ZIP integrity.
- Full private-package Windows/Angular build remains unverified.

Existing Sass deprecation warnings are separate and do not block compilation.
