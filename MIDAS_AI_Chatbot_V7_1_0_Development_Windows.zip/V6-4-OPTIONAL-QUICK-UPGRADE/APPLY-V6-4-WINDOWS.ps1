﻿param([string]$ProjectRoot = '')
$ErrorActionPreference = 'Stop'
$patchRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$rel = 'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\'
$hashes = @{
  'app.component.html' = @('8a86e26745095a43662491baba984ecf0925f742f3e79d37aceaad62712fc4cc','55c838095c2416f217daa6869c96752acbe2204b027bf7092dfc25aec27dfd57')
  'app.component.scss' = @('379d4380c34e6de5628f4de71f0e9818f32570b16347e8fbff253bcc4160815b','fcad2fbfa6beff185252c01e9bc897d6421b88e77b2fe3fd16662574283b3309')
}
function IsProject([string]$path) {
  if ([string]::IsNullOrWhiteSpace($path)) { return $false }
  return ((Test-Path -LiteralPath (Join-Path $path 'midas\midas-frontend\package.json')) -and
          (Test-Path -LiteralPath (Join-Path $path 'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\package.json')))
}
Write-Host 'AI Chatbot V6.4 - Send and Transcription Controls' -ForegroundColor Cyan
if (-not $ProjectRoot) {
  $downloads = Join-Path $env:USERPROFILE 'Downloads'
  $candidates = New-Object System.Collections.Generic.List[string]
  $one = @(Get-ChildItem -LiteralPath $downloads -Directory -ErrorAction SilentlyContinue)
  $two = @($one | ForEach-Object { Get-ChildItem -LiteralPath $_.FullName -Directory -ErrorAction SilentlyContinue })
  $three = @($two | ForEach-Object { Get-ChildItem -LiteralPath $_.FullName -Directory -ErrorAction SilentlyContinue })
  foreach($entry in @((Get-Item -LiteralPath $downloads)) + @($one) + @($two) + @($three)) {
    if ($entry -and (IsProject $entry.FullName) -and -not $candidates.Contains($entry.FullName)) {
       [void]$candidates.Add($entry.FullName)
    }
  }
  if ($candidates.Count -gt 0) {
    Write-Host 'Found MIDAS/AI Chatbot installations:' -ForegroundColor Yellow
    for ($i=0; $i -lt $candidates.Count; $i++) { Write-Host ('{0}. {1}' -f ($i+1),$candidates[$i]) }
    $answer=Read-Host 'Choose the number of the project serving your browser (Enter to provide a custom path)'
    $index=0
    if([int]::TryParse($answer,[ref]$index) -and $index -ge 1 -and $index -le $candidates.Count) {
      $ProjectRoot=$candidates[$index-1]
    }
  }
  if(-not $ProjectRoot) { $ProjectRoot=Read-Host 'Enter complete extracted project path' }
}
$ProjectRoot=$ProjectRoot.Trim().Trim('"')
if(-not (IsProject $ProjectRoot)) { throw "Not a complete MIDAS and AI Chatbot project root: $ProjectRoot" }
$updates=@()
foreach($name in @('app.component.html','app.component.scss')) {
  $dest=Join-Path $ProjectRoot ($rel+$name)
  $patch=Join-Path $patchRoot ('PATCH_FILES\'+$rel+$name)
  if(-not (Test-Path -LiteralPath $dest) -or -not (Test-Path -LiteralPath $patch)) { throw "Missing file: $name" }
  $actual=(Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash.ToLowerInvariant()
  $expectedOld=$hashes[$name][0]
  $expectedNew=$hashes[$name][1]
  if($actual -eq $expectedNew) { Write-Host "Already V6.4: $name" -ForegroundColor Gray; continue }
  if($actual -ne $expectedOld) {
    throw "Unexpected changes to $name. Stopping without overwriting custom work. Select the exact V6.3 installation or compare manually."
  }
  if((Get-FileHash -LiteralPath $patch -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expectedNew) { throw "Patch file integrity error: $name" }
  $updates+=@{name=$name; dest=$dest; patch=$patch}
}
if($updates.Count -eq 0){ Write-Host 'V6.4 is already applied.' -ForegroundColor Green; exit 0 }
Write-Host ('Target: '+$ProjectRoot) -ForegroundColor Cyan
Write-Host 'Only AI Chatbot template and stylesheet will change. MIDAS and agents remain untouched.'
if((Read-Host 'Type APPLY to back up and update') -cne 'APPLY'){ Write-Host 'Cancelled';exit 0 }
$stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
$backup=Join-Path $ProjectRoot ('BACKUPS\AI_Chatbot_V6_4_'+$stamp)
$done=@()
try {
  foreach($item in $updates){
    $destBack=Join-Path $backup ($rel+$item.name)
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $destBack) | Out-Null
    Copy-Item -LiteralPath $item.dest -Destination $destBack -Force
    $done += @{dest=$item.dest; backup=$destBack}
  }
  foreach($item in $updates){
    Copy-Item -LiteralPath $item.patch -Destination $item.dest -Force
    if((Get-FileHash -LiteralPath $item.dest -Algorithm SHA256).Hash.ToLowerInvariant() -ne $hashes[$item.name][1]) { throw "Verification failed: $($item.name)" }
    Write-Host ('Updated: '+$item.name) -ForegroundColor Green
  }
} catch {
  foreach($entry in $done){ Copy-Item -LiteralPath $entry.backup -Destination $entry.dest -Force -ErrorAction SilentlyContinue }
  throw
}
Write-Host 'Updated. Angular watch mode can rebuild without stopping other instances.' -ForegroundColor Green
Write-Host 'When compilation succeeds, refresh MIDAS with Ctrl+Shift+R.'
Write-Host ('Backup: '+$backup)
