@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLY-V6-4-WINDOWS.ps1"
if errorlevel 1 echo UPDATE FAILED. See the error above.
echo.
pause
