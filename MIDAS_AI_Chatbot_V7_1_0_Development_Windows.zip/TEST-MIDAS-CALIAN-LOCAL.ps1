# V4 status + HTTP/WebSocket checks for the latest recorded local run.
$ErrorActionPreference='Stop'
$script=Join-Path $PSScriptRoot 'TOOLS\verify-last-run.cjs'
if(-not (Get-Command node -ErrorAction SilentlyContinue)){throw 'Node.js is required for the V4 verifier.'}
& node $script
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
