@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CONFIGURE-V7-DATABASE-WINDOWS.ps1"
pause
