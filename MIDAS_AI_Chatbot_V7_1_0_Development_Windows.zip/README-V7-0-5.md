# MIDAS AI Chatbot V7.0.5 — Hands-free stabilization

Targeted development upgrade for V7.0.4. SQL, routing, server code, MIDAS host, video, dependencies, credentials and ports are unchanged.

## Install
1. Extract this ZIP in a separate folder. Finish any active call or request and stop the V7.0.4 chatbot client/backend.
2. Run APPLY-V7-0-5-WINDOWS.bat. Enter your existing V7.0.4 root (contains midas and Standalone_Calian_AI_Chatbot). Type APPLY to authorize the patch.
3. The updater validates every baseline file and payload SHA-256, backs up originals, and refuses mismatches. If files were locally modified, do not force the patch; reconcile first.
4. Restart the same development services and refresh Chrome/Edge with Ctrl+Shift+R. Confirm v7.0.5 in the AI Chatbot sidebar. Run RUN-V7-CHECKS-WINDOWS.bat with Node 22.15+.

## Live voice test
- Keep Auto-submit voice unchecked for the first test. Enable Hands-free and grant microphone access. Speak “Select all records from table contxt_oi_assoc”. Pause. Wait for the spoken confirmation to finish and the Listening status to return.
- In the confirmation state, non-command transcriptions do not replace the pending question. Music/silence/known Whisper noise markers are ignored. Say Send, Send it, or Please send. The original transcript must be dispatched once. Check the SQL and result, then listen for readback and the next Listening status.
- Say Cancel to discard; say Replace question followed by the new question to change a pending draft. Say Stop listening or click Exit hands-free to stop. A failed dispatch retains its draft. Playback keeps the mic closed; there is a 650 ms delay before restart and a playback watchdog. Transcription failures recover or pause after three errors. Idle silent recordings restart rather than exit. These safeguards cannot eliminate all background speech or transcription errors.
- Optional: exit hands-free, enable Auto-submit voice in the composer settings, then enter hands-free again. This skips confirmation for ordinary recognized questions; use only in a quiet/private environment. MIDAS operational approvals remain required. No always-on background microphone or hands-free video calling is added.

## Results
74/74 Node tests passed: 65 existing tests + nine new voice tests. The command-handler tests execute actual component methods with mocked send/playback; the recovery guard test checks source presence. Five additional existing database regression scripts passed. TypeScript helper strict check and changed TypeScript transpilation checks passed. SQL server files are byte-identical to V7.0.4. Full Angular compilation, Windows installer execution, microphone/audio timing, real agents and live database integration have not been tested in this environment. This is a candidate for live testing, not a verified production release.
