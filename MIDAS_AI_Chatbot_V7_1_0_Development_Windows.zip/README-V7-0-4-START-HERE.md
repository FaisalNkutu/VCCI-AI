# MIDAS AI Chatbot V7.0.4 — SQL intent validation and hands-free conversation

**Development release.** Derived directly from the complete V7.0.3 archive. Keeps the existing MIDAS host, separate Angular chatbot, Python A2A, AI Core, Ollama, RabbitMQ, selected schema and video services. No dependencies, ports, credentials, grants or MIDAS host code were changed.

## Quick upgrade (recommended for an existing V7.0.3 installation)

1. Extract the V7.0.4 Quick Upgrade ZIP to a separate directory.
2. Finish any active request or video call and stop only the V7.0.3 development chatbot client/backend if possible. Leave V6.5 and unrelated services running.
3. Double-click `APPLY-V7-0-4-WINDOWS.bat`. Paste the absolute path of the existing V7.0.3 extracted project root (contains `midas` and `Standalone_Calian_AI_Chatbot`). Enter `APPLY` after reviewing the path. The updater verifies all original source hashes before writing and creates a timestamped backup. A mismatch refuses the whole upgrade; use the full ZIP in a separate folder instead.
4. Restart the V7 development chatbot backend/client using your normal V7 startup procedure. Do not start a duplicate instance on the same ports. If restarting the complete isolated stack, use `START-V7-ISOLATED-WINDOWS.bat` and its reported URL. Refresh Chrome/Edge (Ctrl+Shift+R).
5. Confirm AI Chatbot v7.0.4 in the sidebar. Select your existing accessible database in Session Inspector. Run `RUN-V7-CHECKS-WINDOWS.bat` from the project root (Node 22+).

## Full isolated installation

Extract the full development ZIP into a **new** folder, not over the working V7.0.3 or V6.5 tree. Follow the existing `README-V7-START-HERE.md`, using your approved registry credentials, existing services and `CONFIGURE-V7-DATABASE-WINDOWS.bat` as necessary. Run `START-V7-ISOLATED-WINDOWS.bat` to choose a free port family. No production deployment is implied.

## SQL correction

The simple request `Select data from table Context_OL_ASoc.` is resolved against the selected schema's live metadata. In the test catalog containing `contxt_oi_assoc`, it compiles deterministically to:

```sql
SELECT * FROM `vcci_aug_26_dbg_1`.`contxt_oi_assoc` LIMIT 100;
```

If another table name actually exists, the resolver uses the verified exact match or rejects ambiguity. Simple data requests bypass Ollama, and complex single-table plans are checked against the original instruction before compilation. Explicit WHERE filters must match the requested verified column, comparison and value. Missing or unsupported filters, speculative columns, unsupported joins or groupings are refused, not silently dropped. The legacy opt-in REQA NL fallback is disabled for this path to prevent bypassing validation. Explicit read-only SQL continues to use the existing executor. Row-list caps are still subject to the external MCP service; a 100-row cap is used for generic data requests, while the previous 20-row default remains for simple record/row listings. The generated SQL and returned row counts are displayed. The table preview is bounded to 20 records and 20 columns; the original executor response remains expandable. No query results are fabricated.

Test spoken examples: `Select data from table contxt_oi_assoc`; `Show first ten records from table contxt_oi_assoc`; `Show records from table contxt_oi_assoc where contxt_id equals one`; `Show distinct cat_code from table contxt_oi_assoc`; `How many records are in table contxt_oi_assoc?`. A filter must be explicit (WHERE column equals value, with optional AND); more complex phrasing may require rephrasing or direct read-only SQL. Compare the SQL and results to HeidiSQL.

## Hands-free workflow

1. Click **Hands-free** once in the composer footer and allow microphone access. This is an opt-in, active-window-only session; no background wake word or always-on microphone. A local browser/Windows speech voice and the existing local Whisper service are required.
2. Speak a question and pause for about 1.25 seconds. The microphone stops, the existing local Whisper endpoint transcribes the audio, and the assistant speaks the recognized question (up to 500 characters). The full transcript remains on screen.
3. Say **Send** to submit or **Cancel** to discard. Restate your question to replace the pending one. Nothing is sent automatically from ambient speech; a separate spoken Send command is required.
4. The existing agent selection and orchestration execute the request. The result is read aloud, including the dedicated DBAgent response path. The mic remains off during playback and resumes when the answer is complete. No need to click Speak, Stop, Send or Read results again for ordinary conversation.
5. Say **Stop listening** (while listening) or click **Exit hands-free** to stop. The microphone closes on tab hiding, video view entry and component teardown. Silence for 45 seconds without a detected utterance exits hands-free mode. The mic does not listen over playback; interrupt via the visible stop control. Browser permission and local speech-voice availability may require a click/setup. Auto read-aloud remains independently available beside the composer controls.

Supported spoken controls:
- Send / Send it / Cancel / Stop listening
- Read results / Repeat that / Read details
- Auto select / Select DBAgent / Select agent [exact friendly name]
- Select database [exact accessible database name]
- Open response reader / Back to chat / New session

Ordinary MIDAS UI requests may still be spoken and submitted, but the existing host approval boundary stays intact; this version does not add voice-only approval of operational MIDAS actions. Video calls still use the existing UI, not hands-free calling. Do not use sensitive data where other people can hear speech playback. Only a local speech synthesis voice is selected in hands-free mode; do not assume the browser/Windows platform is approved for classified data. Production authentication, authorization and deployment remain unverified.

## Verification performed in this packaging environment

- 65/65 Node test cases passed, including 13 new SQL/voice/readback/preview regressions. Voice UI tests are source-level checks, not hardware tests.
- Five additional existing database/spoken-table regression scripts passed (one existing assertion was corrected to ignore message capitalization).
- Strict TypeScript type checking passed for the SQL translation modules; TypeScript transpilation syntax checks passed for changed application/server modules.
- Full Angular/MIDAS build, Windows PowerShell execution, real microphone/audio playback, actual MariaDB/REQA and real agent registry were **not** tested here. Test these on the isolated V7 environment before relying on this release.
