@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0UPGRADE-WHISPER-QUALITY-WINDOWS.ps1"
if errorlevel 1 (echo Model upgrade failed. & pause & exit /b 1)
pause
