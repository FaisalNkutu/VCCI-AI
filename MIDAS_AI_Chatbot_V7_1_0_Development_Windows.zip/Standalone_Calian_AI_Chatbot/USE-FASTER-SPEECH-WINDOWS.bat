@echo off
setlocal
set "SPEECH_DIR=%LOCALAPPDATA%\CalianAI\speech"
if exist "%SPEECH_DIR%\ggml-medium.en-q5_0.bin" (
  move /y "%SPEECH_DIR%\ggml-medium.en-q5_0.bin" "%SPEECH_DIR%\ggml-medium.en-q5_0.bin.disabled" >nul
  echo Using the original small model from the next transcription request.
) else (
  echo The high-accuracy model is not active.
)
pause
