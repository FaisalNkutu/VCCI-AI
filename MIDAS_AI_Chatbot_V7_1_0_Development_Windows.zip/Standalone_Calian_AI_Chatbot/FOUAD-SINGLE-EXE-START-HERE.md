# CALIAN.AI V8 — One executable, automatic `calian.env`

This release was derived from `Standalone_Calian_AI_Chatbot_V8_Live_Video_Maximum_10_Records_422_Fix.zip`. The change is confined to Electron's first-run configuration and the Windows distribution scripts. All SQL/REQA/DBAgent, Whisper, speech playback, and live-video source files are preserved.

## For the person BUILDING the Windows executable

1. Extract the full source ZIP onto the **build computer**.
2. Double-click `BUILD-CALIAN-WINDOWS.bat` (Node.js and internet needed to install build dependencies).
3. Give Fouad **only** the resulting `DELIVER_TO_FOUAD\CALIAN.AI.exe`. No `.bat` or `.env` is required at distribution time. The portable EXE bundles the Angular UI and the Electron-managed local Node backend.

**Do not send the entire source directory, `win-unpacked` folder, or any existing `calian.env` to Fouad.** Do not distribute private API keys or passwords.

## For Fouad — first launch

1. Copy `CALIAN.AI.exe` to a normal writable folder, such as `Documents\CALIAN.AI`.
2. Double-click the executable. It **automatically creates** `calian.env` beside that original EXE.
3. A one-time setup window opens. Select the current MariaDB database/schema (if known), or leave the field blank to auto-detect. A database name can be edited later under **File → Configure database and services…**.
4. Optionally expand Advanced to set the existing REQA, Python A2A, Ollama and remote video-service addresses. These are **connection settings**, not replacements for those services.
5. Click **Save and continue**. The config is saved before CALIAN's local Node backend is launched. Further launches reuse the settings and do not show the setup window again.

If `CALIAN.AI.exe` is inside a read-only directory, the generated config is written to Electron's per-user application-data folder; the setup screen shows the actual file path.

**Existing `calian.env` files are never overwritten automatically.** Existing settings are preserved. If reopening the setup screen using the File menu, restart the app to apply changes.

## What one EXE does — and does not — bundle

**Bundled:** Windows Electron UI, the Angular front end, and CALIAN's local Node/Express WebSocket/backend bridge (as already designed in V8).

**Still external:** Fouad's REQA/DBAgent Docker components, Python A2A service, AI Core, Ollama and its models, local Whisper program/model, and the separately hosted public video-call HTTPS gateway/TURN infrastructure. Their addresses may be configured from the executable. This package **does not** install or modify those services, and a single desktop EXE alone cannot offer worldwide guest video calls without the public video gateway.

## Checks

- The Node/Electron source passes `node --check`.
- Local simulated first-run tests cover config creation, saving the database before backend startup, existing-config preservation, read-only-folder fallback, and invalid-schema rejection.
- A complete Windows executable cannot be verified without running the Windows build and launching it on a Windows computer. Use the existing working release as a rollback until that test succeeds.
