# CALIAN.AI V8 — spoken underscore / table-name resolution fix

Based on: `Standalone_Calian_AI_Chatbot_V8_Speech_Table_Matching_422_Fix.zip`.

## Root cause

Whisper may dictate database identifiers as phrases such as:

- `context underscore O I underscore assoc`
- `Context_Underscore_OI_Underscore_ASSOC`
- `context under score O I under score association`

The earlier schema-aware adapter treated the word `underscore` as part of the table identifier, then failed its name-matching checks, producing HTTP 422 even when the table was present in verified MariaDB metadata.

## Correction

The **CALIAN-owned** schema-aware resolver interprets spoken underscore separators and common SQL abbreviations, then matches the normalized phrase against the **live schema catalog**. A unique exact canonical match takes precedence over fuzzy similarity, helping avoid unnecessary ambiguous matches among similarly named tables. A near match is accepted only when unique. For intentionally SQL-formatted messages, the existing direct-SQL execution path remains unchanged.

This is **generic**, not hardcoded to a specific table, database, or user. No changes to REQA, Fouad's containers, AI Core, Whisper, read-aloud results, or the A2A dispatcher.

## Install

1. Keep your working CALIAN.AI executable as a backup.
2. Extract this ZIP into a new directory.
3. Run `BUILD-CALIAN-WINDOWS.bat` at the extracted root, then launch the NEW executable under `CALIAN_AI_ELECTRON_THEMES\\release`.
4. If the active MariaDB connection has no default database or sees multiple copies of the same table, use the existing `SET-CALIAN-DATABASE-WINDOWS.bat` to choose the intended database and relaunch.

## Try

Say or type: `How many records are in the table context underscore O I underscore assoc?`

Expected generated SQL *only if* the live schema contains this verified table in the selected database:

```sql
SELECT COUNT(*) AS total_records FROM `vcci_aug_26_dbg_1`.`contxt_oi_assoc`;
```

To test list queries: `Show me 10 records from the context O I association table.`

## Safety and verification

- Generic SQL metadata discovery remains read-only.
- Never execute a guessed table if there are ambiguous matches.
- Existing literal `SELECT` messages are not modified by this patch.
- This ZIP is source only. On-device Windows and live MariaDB verification is required.

Developer regression tests (after `npm install` inside the Angular project):

```powershell
npx tsx server/test-spoken-underscore.mjs
```
