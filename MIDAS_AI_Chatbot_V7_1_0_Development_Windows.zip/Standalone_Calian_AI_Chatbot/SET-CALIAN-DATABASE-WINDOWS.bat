@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0SET-CALIAN-DATABASE-WINDOWS.ps1"
pause
