# CALIAN.AI V8 — Speech/SQL Table Resolution Repair

## Why the screenshot failed

HeidiSQL shows the actual MariaDB table `contxt_oi_assoc`. Whisper sometimes produces
`context_ol_assoc`, `context_oi_assoc`, or `contxt_ol_assoc`. The previous CALIAN
resolver demanded an exact match whenever it saw underscores, so it returned HTTP 422
before executing any SQL. The error originated in CALIAN, not Fouad's Docker image.

## What changed

Only `CALIAN_AI_ELECTRON_THEMES/server/schema-aware-sql.ts` was modified in the V8
application. A new regression test file was added; all existing V8 features and the
REQA/DBAgent direct SQL bridge remain unchanged.

- Resolves generic abbreviations, such as `context` → `contxt`, against the **live**
  current-database schema metadata (not a per-database list of hardcoded mappings).
- Permits a uniquely matching **one-character** transcription error (`ol` vs `oi`).
- Uses the verified, schema-qualified MariaDB table name in the generated `SELECT`.
- Refuses to guess if a table does not exist, if multiple tables are equally close,
  or if multiple databases contain the same matching table and no default database
  can be identified. An explicitly qualified `database.table` must match exactly.
- Does **not** rewrite literal SQL. Copy-pasted `SELECT` commands remain exact.

## Build (Windows)

1. Extract this ZIP into a new folder, retaining your last working version.
2. Double-click `BUILD-CALIAN-WINDOWS.bat` and wait for the build to finish.
3. Start the **new** `CALIAN_AI_ELECTRON_THEMES\release\CALIAN AI 1.0.0.exe`.
4. Try these English/spoken requests:

   - `Show me 10 records from context_ol_assoc.`
   - `Show me ten records from the context O I association table.`
   - `How many records are in context_ol_assoc?`

Expected generated query (assuming the current database is `vcci_aug_26_dbg_1`):

```sql
SELECT * FROM `vcci_aug_26_dbg_1`.`contxt_oi_assoc` LIMIT 10;
```

For a literal SQL baseline, **copy the exact table spelling from HeidiSQL**:

```sql
SELECT * FROM `vcci_aug_26_dbg_1`.`contxt_oi_assoc` LIMIT 10;
```

If CALIAN reports that multiple databases contain that table, run the included
`SET-CALIAN-DATABASE-WINDOWS.bat` to select the same database used by HeidiSQL,
and restart CALIAN. This creates `calian.env` next to the new executable; the setting
is not stored inside the Docker image. Other models require no per-table configuration.

## Developer smoke test

From `CALIAN_AI_ELECTRON_THEMES` after `npm install`:

```powershell
node --import tsx server/test-spoken-table-fix.mjs
```

## Verification scope

The model-to-SQL conversion and safety/selection cases were tested locally with mock
MariaDB metadata. A complete Windows Electron build and live Docker/MariaDB execution
still require verification on your own Windows machine.
