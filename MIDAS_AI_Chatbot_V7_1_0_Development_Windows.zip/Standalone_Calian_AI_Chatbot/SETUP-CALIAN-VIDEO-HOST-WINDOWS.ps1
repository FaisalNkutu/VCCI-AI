$ErrorActionPreference='Stop'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$release=Join-Path $root 'CALIAN_AI_ELECTRON_THEMES\release'
if(-not(Test-Path $release)){Write-Error 'Please run BUILD-CALIAN-WINDOWS.bat first.';exit 1}
Write-Host 'Configure your private CALIAN.AI app to create invitations on a SEPARATELY hosted public video service.'
Write-Host 'First deploy VIDEO_CALL_SERVICE over HTTPS on a public host; do NOT expose local REQA or DBAgent.'
$url=(Read-Host 'Public video origin, e.g. https://video.example.com').TrimEnd('/')
try {$uri=[uri]$url} catch {throw 'Invalid HTTPS URL'}
if($uri.Scheme -ne 'https' -or $uri.AbsolutePath -ne '/' -or $uri.Query -or $uri.Fragment){throw 'A public HTTPS origin without path is required'}
$key=(Read-Host 'Enter the same VIDEO_ADMIN_KEY configured on the public video server').Trim()
if($key.Length -lt 32){throw 'The admin key must have at least 32 characters'}
$model=(Read-Host 'Local Ollama vision model [llama3.2-vision]').Trim()
if(-not $model){$model='llama3.2-vision'}
if($model -notmatch '^[A-Za-z0-9._:/-]{1,120}$'){throw 'Invalid vision model name'}
$dest=Join-Path $release 'calian.env'
$old=@();if(Test-Path $dest){$old=Get-Content $dest | Where-Object {$_ -notmatch '^\s*(CALIAN_VIDEO_PUBLIC_ORIGIN|CALIAN_VIDEO_ADMIN_KEY|CALIAN_VISION_MODEL)\s*='}}
$new=@($old)+@("CALIAN_VIDEO_PUBLIC_ORIGIN=$url", "CALIAN_VIDEO_ADMIN_KEY=$key", "CALIAN_VISION_MODEL=$model")
[System.IO.File]::WriteAllLines($dest,[string[]]$new,[System.Text.UTF8Encoding]::new($false))
Write-Host "Updated $dest (contains a secret; do not share or upload this file)."
