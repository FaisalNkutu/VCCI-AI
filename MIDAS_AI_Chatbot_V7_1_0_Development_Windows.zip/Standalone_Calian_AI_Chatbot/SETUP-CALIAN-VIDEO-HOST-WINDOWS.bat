@echo off
setlocal
cd /d "%~dp0"
where powershell >nul 2>&1 || (echo Windows PowerShell required & pause & exit /b 1)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0SETUP-CALIAN-VIDEO-HOST-WINDOWS.ps1"
if errorlevel 1 (echo Configuration failed & pause & exit /b 1)
echo Configuration saved. Close and reopen the new CALIAN AI executable.
pause
