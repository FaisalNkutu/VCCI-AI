$ErrorActionPreference='Stop'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$file=Join-Path $root 'VIDEO_CALL_SERVICE\.env'
if(-not(Test-Path $file)){
 $template=Join-Path $root 'VIDEO_CALL_SERVICE\.env.example'
 if(-not(Test-Path $template)){throw 'VIDEO_CALL_SERVICE\.env.example is missing'}
 Copy-Item -LiteralPath $template -Destination $file
 Write-Host 'Created video gateway .env. Configure VIDEO_PUBLIC_ORIGIN and VIDEO_ADMIN_KEY as before.'
}
Write-Host 'LiveKit setup affects only the separate VIDEO_CALL_SERVICE; CALIAN.AI REQA and DBAgent are unchanged.'
$url=(Read-Host 'LiveKit WSS server URL (wss://your-project.livekit.cloud)').Trim().TrimEnd('/')
if($url -notmatch '^wss://[A-Za-z0-9.:-]+$'){throw 'Enter a wss:// LiveKit server origin, with no path'}
$key=(Read-Host 'LiveKit API key').Trim()
if($key.Length -lt 8){throw 'Invalid LiveKit API key'}
$secure=Read-Host 'LiveKit API secret (input hidden)' -AsSecureString
$secret=[System.Net.NetworkCredential]::new('', $secure).Password
if($secret.Length -lt 12){throw 'Invalid LiveKit API secret'}
$content=Get-Content -LiteralPath $file | Where-Object {$_ -notmatch '^\s*(VIDEO_LIVEKIT_URL|VIDEO_LIVEKIT_API_KEY|VIDEO_LIVEKIT_API_SECRET)\s*='}
$content=@($content)+@('VIDEO_LIVEKIT_URL='+$url,'VIDEO_LIVEKIT_API_KEY='+$key,'VIDEO_LIVEKIT_API_SECRET='+$secret)
[System.IO.File]::WriteAllLines($file,[string[]]$content,[System.Text.UTF8Encoding]::new($false))
Write-Host 'Saved group SFU configuration to VIDEO_CALL_SERVICE\.env. Protect this file and restart the public gateway.'
Write-Host 'Do not copy this secret file into DELIVER_TO_FOUAD or CALIAN_AI_ELECTRON_THEMES.'
