# Optional higher-accuracy model for CALIAN.AI speech recognition.
# Preserves the existing small.en model, Electron app, Docker, and Fouad's services.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) { throw 'LOCALAPPDATA missing: run from your normal Windows account.' }
$dir = Join-Path $env:LOCALAPPDATA 'CalianAI\speech'
[System.IO.Directory]::CreateDirectory($dir) | Out-Null
$dest = Join-Path $dir 'ggml-medium.en-q5_0.bin'
$expected = '76733e26ad8fe1c7a5bf7531a9d41917b2adc0f20f2e4f5531688a8c6cd88eb0'
$uri = 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-medium.en-q5_0.bin'
$tmp = Join-Path $dir ('download-medium-' + [guid]::NewGuid().ToString('N') + '.part')
try {
  if ((Test-Path -LiteralPath $dest -PathType Leaf) -and
      (Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash.ToLowerInvariant() -eq $expected) {
    Write-Host 'High-accuracy model already verified and installed.' -ForegroundColor Green
    exit 0
  }
  Write-Host 'Downloading optional medium.en-q5_0 Whisper model (~539 MB). Existing small model stays installed.'
  Write-Host 'This model is slower but can improve recognition. Installation may take several minutes.'
  Add-Type -AssemblyName System.Net.Http
  $client = [System.Net.Http.HttpClient]::new()
  $client.Timeout = [TimeSpan]::FromMinutes(45)
  $client.DefaultRequestHeaders.UserAgent.ParseAdd('CALIAN-AI-Whisper-Accuracy/1.0')
  $response = $null; $inputStream = $null; $outputStream = $null
  try {
    $response = $client.GetAsync($uri,[System.Net.Http.HttpCompletionOption]::ResponseHeadersRead).GetAwaiter().GetResult()
    $response.EnsureSuccessStatusCode() | Out-Null
    $inputStream = $response.Content.ReadAsStreamAsync().GetAwaiter().GetResult()
    $outputStream = [System.IO.File]::Create($tmp)
    $inputStream.CopyTo($outputStream)
    $outputStream.Flush()
  } finally {
    if ($null -ne $outputStream) { $outputStream.Dispose() }
    if ($null -ne $inputStream) { $inputStream.Dispose() }
    if ($null -ne $response) { $response.Dispose() }
    $client.Dispose()
  }
  if ((Get-Item -LiteralPath $tmp).Length -lt 500000000) { throw 'Model download was incomplete.' }
  $actual = (Get-FileHash -LiteralPath $tmp -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($actual -ne $expected) { throw 'SHA-256 verification failed; refusing to install corrupted model.' }
  Move-Item -LiteralPath $tmp -Destination $dest -Force
  Write-Host 'Verified high-accuracy model is installed. Restart the CALIAN.AI backend.' -ForegroundColor Green
  Write-Host 'To revert, use USE-FASTER-SPEECH-WINDOWS.bat; it will keep the model backed up.'
} catch {
  Write-Host ('Whisper model upgrade failed: ' + $_.Exception.Message) -ForegroundColor Red
  throw
} finally {
  if (Test-Path -LiteralPath $tmp -PathType Leaf) {
    try { Remove-Item -LiteralPath $tmp -Force -ErrorAction Stop } catch { Write-Warning $_.Exception.Message }
  }
}
