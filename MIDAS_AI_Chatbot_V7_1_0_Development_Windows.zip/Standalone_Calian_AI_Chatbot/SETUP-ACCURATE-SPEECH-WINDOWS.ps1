# CALIAN.AI Whisper installer - repaired Windows path handling.
# Standalone Windows PowerShell 5.1 script; no Docker or Python changes.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) {
    throw 'LOCALAPPDATA is not available. Please run this script from your normal Windows account.'
}
$install = Join-Path $env:LOCALAPPDATA 'CalianAI\speech'
[System.IO.Directory]::CreateDirectory($install) | Out-Null
$exe = Join-Path $install 'whisper-cli.exe'
$model = Join-Path $install 'ggml-small.en.bin'

# Avoid $env:TEMP, which can contain a stale 8.3 short path on Windows.
# Stage the downloads next to the final files to keep paths consistent.
$stage = Join-Path $install ('setup-' + [guid]::NewGuid().ToString('N'))
[System.IO.Directory]::CreateDirectory($stage) | Out-Null

function Save-Download {
    param([Parameter(Mandatory=$true)][string]$Uri,
          [Parameter(Mandatory=$true)][string]$Destination)
    # Download directly to disk; Windows PowerShell's Invoke-WebRequest may
    # consume considerable RAM when downloading a 460 MB model.
    Add-Type -AssemblyName System.Net.Http
    $handler = New-Object System.Net.Http.HttpClientHandler
    $handler.AllowAutoRedirect = $true
    $http = [System.Net.Http.HttpClient]::new($handler)
    $http.Timeout = [TimeSpan]::FromMinutes(45)
    $http.DefaultRequestHeaders.UserAgent.ParseAdd('CALIAN-AI-Whisper-Setup/2.0')
    $response = $null
    $source = $null
    $target = $null
    try {
        $response = $http.GetAsync($Uri, [System.Net.Http.HttpCompletionOption]::ResponseHeadersRead).GetAwaiter().GetResult()
        $response.EnsureSuccessStatusCode() | Out-Null
        $source = $response.Content.ReadAsStreamAsync().GetAwaiter().GetResult()
        $target = [System.IO.File]::Create($Destination)
        $source.CopyTo($target)
        $target.Flush()
    }
    finally {
        if ($null -ne $target) { $target.Dispose() }
        if ($null -ne $source) { $source.Dispose() }
        if ($null -ne $response) { $response.Dispose() }
        $http.Dispose()
        $handler.Dispose()
    }
}

try {
    Write-Host ('Speech install folder: ' + $install)

    if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) {
        $zip = Join-Path $stage 'whisper-bin-x64.zip'
        Write-Host 'Downloading official whisper.cpp Windows x64 engine...'
        Save-Download -Uri 'https://github.com/ggml-org/whisper.cpp/releases/download/b5454/whisper-bin-x64.zip' -Destination $zip
        if ((Get-Item -LiteralPath $zip).Length -lt 8000000) {
            throw 'The Whisper engine download is incomplete. Please rerun the installer.'
        }
        # Verify the pinned GitHub release against Scoop's published checksum.
        $expectedSha256 = '6ba69e3482d7826214f90a6a9c84ca07782aec1e1d0c6a7c30c994fd5d816ccb'
        $actualSha256 = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actualSha256 -ne $expectedSha256) {
            throw 'The downloaded Whisper engine failed SHA-256 verification. Installation stopped.'
        }
        $expanded = Join-Path $stage 'bin'
        Expand-Archive -LiteralPath $zip -DestinationPath $expanded -Force
        $cli = Get-ChildItem -LiteralPath $expanded -File -Recurse -Filter 'whisper-cli.exe' | Select-Object -First 1
        if ($null -eq $cli) {
            throw 'The official release archive did not contain whisper-cli.exe.'
        }
        # Include runtime DLLs bundled beside the CLI, not just its executable.
        Copy-Item -Path (Join-Path $cli.Directory.FullName '*') -Destination $install -Recurse -Force
    }
    else { Write-Host 'Whisper engine already present; reusing it.' }

    if (-not (Test-Path -LiteralPath $model -PathType Leaf) -or
        (Get-Item -LiteralPath $model).Length -lt 350000000) {
        $partial = Join-Path $stage 'ggml-small.en.bin.download'
        Write-Host 'Downloading the English small model (approximately 460 MB)...'
        Save-Download -Uri 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.en.bin?download=true' -Destination $partial
        if ((Get-Item -LiteralPath $partial).Length -lt 350000000) {
            throw 'The English Whisper model download was incomplete. Please rerun the installer.'
        }
        Move-Item -LiteralPath $partial -Destination $model -Force
    }
    else { Write-Host 'Whisper model already present; reusing it.' }

    if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) {
        throw 'Whisper engine executable is missing after setup.'
    }
    if (-not (Test-Path -LiteralPath $model -PathType Leaf)) {
        throw 'Whisper model is missing after setup.'
    }
    Write-Host ''
    Write-Host 'SUCCESS: Accurate Whisper speech recognition is installed.' -ForegroundColor Green
    Write-Host $install
    Write-Host 'Restart CALIAN.AI and use Speak / Stop.'
}
catch {
    # Show the original download/installation failure, not a cleanup error.
    Write-Host ''
    Write-Host ('Whisper setup failed: ' + $_.Exception.Message) -ForegroundColor Red
    throw
}
finally {
    # Cleanup is best effort; it must not override the real result.
    try {
        if (Test-Path -LiteralPath $stage -PathType Container) {
            Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction Stop
        }
    }
    catch {
        Write-Warning ('Could not remove the temporary download folder: ' + $_.Exception.Message)
    }
}
