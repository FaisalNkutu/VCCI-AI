# CALIAN.AI V8 — Group video meetings (up to 10 people)

This upgrade starts from `Standalone_Calian_AI_Chatbot_V8_Single_EXE_Speech_SQL_Routing_Fix.zip`, the most recent working V8 source. It **preserves direct SQL, natural-language SQL, the portable calian.env first-run setup, DBAgent, REQA, A2A, Ollama, Whisper, AI camera video, spoken results, and the previous one-on-one video feature.**

## What you get

The **Live Video** page now offers three separate modes: **Talk to AI**, **Call a Person** (the original direct peer-to-peer call), and **Group Meeting (10)**. A group invitation can be opened in any supported desktop or mobile browser without installing CALIAN.AI or Tailscale. The host admits/declines guests from a waiting room, sees a participant video grid, can mute their own mic, turn off their camera, remove a guest, and end the entire room. **Ten means the host plus nine guests** (not ten guests plus a host). The group has a 60-minute invitation lifetime. This version does not add screen sharing, recording, or a multi-host meeting role.

For group meetings, the public VIDEO_CALL_SERVICE issues **short-lived LiveKit access tokens only after host admission**. Video/audio travels through a **LiveKit SFU** rather than the old one-to-one WebRTC relay logic. LiveKit must be separately deployed/hosted; no API credentials are bundled in the Windows EXE. The existing public gateway still has no endpoints for CALIAN.AI's REQA, SQL, DBAgent, or Ollama.

## 1 — Build the desktop EXE

1. Extract to a NEW folder, not over the working V8. Keep the old `.exe` as a rollback.
2. Run `BUILD-CALIAN-WINDOWS.bat`. It runs the existing SQL regression checks, a group-source syntax/routing check, and the Angular/Electron build.
3. The single EXE for Fouad is `DELIVER_TO_FOUAD\CALIAN.AI.exe`. On first launch, the existing launcher creates `calian.env` and prompts for the relevant local backend/database configuration. An existing `calian.env` is not overwritten.
4. To avoid losing your established settings, ensure your current `calian.env` remains beside the EXE or in its supported per-user fallback location. **Never include `calian.env` in a public ZIP or share private keys.**
5. Test REQA/DBAgent queries and one-to-one calling BEFORE configuring group calls; both should behave as before.

## 2 — Set up LiveKit (required for group video)

**The Tailscale Funnel URL alone does NOT carry a 10-person SFU meeting.** It already exposes your *guest invitation gateway* on port 9443 and can continue to do so. The SFU is a separate service. The simplest option is to create a LiveKit Cloud project (https://cloud.livekit.io/) and obtain:

- LiveKit server WebSocket URL: `wss://<your-project>.livekit.cloud`
- LiveKit API key
- LiveKit API secret

Alternatively, deploy and manage your own LiveKit server with publicly reachable signaling and media ports. Reliable remote video depends on LiveKit's public UDP/TURN connectivity.

On the **machine hosting VIDEO_CALL_SERVICE**, add these three lines to `VIDEO_CALL_SERVICE\.env` (keeping the existing `VIDEO_PORT`, `VIDEO_BIND`, `VIDEO_PUBLIC_ORIGIN`, and `VIDEO_ADMIN_KEY`):

```ini
VIDEO_LIVEKIT_URL=wss://<your-project>.livekit.cloud
VIDEO_LIVEKIT_API_KEY=<your-api-key>
VIDEO_LIVEKIT_API_SECRET=<your-private-api-secret>
```

For a local Windows gateway, double-click `CONFIGURE-GROUP-CALLS-WINDOWS.bat` in the extracted root to enter those values. The script **edits only the gateway's `.env`**, not the portable desktop `calian.env`. If your VIDEO_CALL_SERVICE is hosted elsewhere, edit its deployment environment there instead. Protect the private API secret on the server.

In `VIDEO_CALL_SERVICE`, install the new SDKs and restart the service:

```powershell
npm install --no-audit --no-fund
npm start
```

In another PowerShell window, check the local health endpoint:

```powershell
Invoke-RestMethod http://127.0.0.1:9443/health
```

Expect `ready: true`, `role: public-video-only`, and `groupCallsConfigured: true`. If `groupCallsConfigured` is false, check the **gateway** environment, restart it, and retry. The existing Funnel `tailscale funnel --bg 9443` can remain enabled. Use your *actual* assigned Funnel HTTPS URL as `VIDEO_PUBLIC_ORIGIN` and `CALIAN_VIDEO_PUBLIC_ORIGIN` (never an example domain).

**Important:** `VIDEO_ADMIN_KEY` must match `CALIAN_VIDEO_ADMIN_KEY` already stored in the private CALIAN desktop configuration. LiveKit API key/secret must **never** be entered into CALIAN's desktop configuration, invitation links, or browser guest page.

## 3 — Test a group call

1. Open the newly built CALIAN.AI, select **Live Video → Group Meeting (10)**.
2. Select **Create group meeting**. If not configured, the app explains that the public video gateway needs LiveKit settings. A successful room creation requires working LiveKit credentials and a reachable LiveKit server.
3. Copy the invitation link to a second device (preferably on mobile data rather than the same Wi-Fi). Open in Safari/Chrome/Edge; enter a name and choose **Request to join**.
4. Host: click **Admit**. The guest's browser receives short-lived LiveKit media credentials only at this point and displays the other video tiles.
5. Add a third participant, then up to **nine guests** in total. An additional guest cannot be admitted while the meeting is full. Use headphones to avoid audio feedback.
6. Test **Mute**, **Camera off/on**, **Remove guest**, **Leave**, and **End group meeting**. Finishing a meeting revokes its invitation and deletes the LiveKit room. The standard **Call a Person** tab should continue to work without LiveKit configuration.

## Security / limitations

- Guest invitations use 256-bit random tokens, expire, and require host admission. Guest media tokens have a short 60-second join TTL; those tokens are not desktop or gateway admin keys.
- The gateway's **Remove guest** control asks LiveKit to disconnect the participant. A malicious guest might attempt a rejoin using a still-valid, short-lived media token until it expires; stronger immediate revocation would require LiveKit server webhook enforcement or token-deny management. Do not rely on this version for sensitive/regulated meetings without further hardening.
- Media is WebRTC-encrypted in transit (DTLS-SRTP). LiveKit may terminate encrypted media at the SFU as needed for forwarding; this is not a claim of end-to-end encryption from host to guests.
- The gateway uses in-memory rooms; restart closes invitations. The public service needs HTTPS/WSS, and LiveKit must be properly secured and available.
- The guest browser only connects to the public video service and LiveKit, **never to** the private REQA/DBAgent/SQL services.
- A 10-person call's quality depends on bandwidth, CPU, the cameras, and the LiveKit service capacity. Test across Wi-Fi and cellular networks.
- **Not verified end-to-end in this environment:** the full Windows/Electron build, Cloud LiveKit room creation, 10 real simultaneous cameras, and long-term reconnects. The package includes static source regression checks and the existing public-gateway tests; test on your deployed services before production.

## Where the changes are

- Desktop group UI: `CALIAN_AI_ELECTRON_THEMES/src/app/video-center.component.{ts,html,scss}`
- Private video-only bridge: `CALIAN_AI_ELECTRON_THEMES/server/video-routes.ts`
- Public gateway for group admission and LiveKit token issuance: `VIDEO_CALL_SERVICE/server.mjs`
- Public guest group grid: `VIDEO_CALL_SERVICE/public/guest.{html,js,css}`
- LiveKit dependencies in the two `package.json` files
- Configuration helper: `CONFIGURE-GROUP-CALLS-WINDOWS.bat/.ps1`

**Do not deploy CALIAN.AI's private backend to the public internet.** Expose only the dedicated video gateway, and leave all LiveKit secrets on that gateway.
