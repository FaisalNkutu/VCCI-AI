@echo off
setlocal
set "SPEECH_DIR=%LOCALAPPDATA%\CalianAI\speech"
if exist "%SPEECH_DIR%\ggml-medium.en-q5_0.bin.disabled" (
  move /y "%SPEECH_DIR%\ggml-medium.en-q5_0.bin.disabled" "%SPEECH_DIR%\ggml-medium.en-q5_0.bin" >nul
  echo Using the high-accuracy model from the next transcription request.
) else (
  echo High-accuracy model is already enabled, or not installed.
)
pause
