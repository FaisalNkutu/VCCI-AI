Natural-language SQL routing lives only in:
  server/index.ts
  server/db-natural-language.ts
Disable by setting CALIAN_DB_NL_ENABLED=false in the backend environment.
See ../START-HERE-NL_TO_SQL.txt for installation and tests.
