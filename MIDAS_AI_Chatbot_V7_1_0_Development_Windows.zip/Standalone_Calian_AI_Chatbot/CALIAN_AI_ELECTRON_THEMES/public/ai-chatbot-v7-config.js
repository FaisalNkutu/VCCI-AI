// Explicit opt-in. Both frontend flag AND backend MIDAS_V7_FIXTURE_MODE=true are required.
window.__AI_CHATBOT_V7_FLAGS__ = {syntheticDemo:false, nlActions:false};
