/* MIDAS-CALIAN-BRIDGE-V4: development-only exact paired MIDAS origins.
 * CALIAN port 4300+n trusts MIDAS 4200+n; this is NOT API authentication.
 * Production parent origins must be explicitly configured by an administrator.
 */
(() => {
  const local = location.hostname === 'localhost' || location.hostname === '127.0.0.1';
  const offset = Number(location.port) - 4300;
  const valid = local && Number.isInteger(offset) && offset >= 0 && offset <= 99;
  const midasPort = 4200 + offset;
  window.__CALIAN_MIDAS_ALLOWED_ORIGINS__ = valid
    ? [`http://127.0.0.1:${midasPort}`, `http://localhost:${midasPort}`]
    : [];
})();
