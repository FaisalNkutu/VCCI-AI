require('dotenv').config();
// Each Angular dev server runs with CALIAN_BACKEND_PORT from its own launcher window.
// The UI proxies both HTTP API and WebSocket requests to the matching backend.
const port = Number(process.env.CALIAN_BACKEND_PORT || process.env.PORT || 8797);
if (!Number.isInteger(port) || port < 1024 || port > 65535) throw Error('Invalid Calian backend port');
const target = `http://127.0.0.1:${port}`;
module.exports = {
  '/api': { target, secure: false, changeOrigin: true },
  '/ws': { target, ws: true, secure: false, changeOrigin: true }
};
