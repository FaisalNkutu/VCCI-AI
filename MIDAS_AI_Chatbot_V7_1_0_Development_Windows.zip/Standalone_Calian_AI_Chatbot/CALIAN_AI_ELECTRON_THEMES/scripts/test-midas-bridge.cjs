// Run after npm install: node scripts/test-midas-bridge.cjs
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const ts = require('typescript');
const source = fs.readFileSync(path.resolve(__dirname,'../src/app/midas-bridge.ts'),'utf8');
const js = ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
const compiledExports = {};
vm.runInNewContext(js,{exports: compiledExports});
const {parseMidasCommand:parse,suggestedActionFromAgent:suggest}=compiledExports;
const caps={dashboards:['summary','cp','c2'],actions:['navigate','time_format','cp_time_range','cp_select_entity'],approvalRequired:true};
const ctx={route:'/advmetrics/cp',availableTimeFormats:['Seconds','Minutes'],cpEntities:[{id:12,name:'Alpha'}]};
for(const [command,action] of [
 ['Open Combat Power','navigate'],['show summary dashboard','navigate'],
 ['Set time format to Minutes','time_format'],['set time range 20 to 40','cp_time_range'],
 ['Select entity Alpha','cp_select_entity'],['deselect unit 12','cp_select_entity'],
 ['delete the database',null],['open admin dashboard',null]
]){
 const result=parse(command,ctx,caps);
 assert.equal(result?.action ?? null,action,command);
}
assert.equal(suggest('```midas-action\n{"action":"navigate","params":{"dashboard":"cp"}}\n```')?.action,'navigate');
assert.equal(suggest('```midas-action\n{"action":"execute_shell","params":{}}\n```'),null);
console.log('PASS: 10 MIDAS bridge parser / allowlist test cases.');
