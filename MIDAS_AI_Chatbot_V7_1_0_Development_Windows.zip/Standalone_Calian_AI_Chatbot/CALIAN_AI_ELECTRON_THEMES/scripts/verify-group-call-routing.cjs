const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const ts=require('typescript');
const base=path.join(__dirname,'..');
for(const file of ['src/app/video-center.component.ts','server/video-routes.ts']){
 const content=fs.readFileSync(path.join(base,file),'utf8');
 const out=ts.transpileModule(content,{fileName:file,reportDiagnostics:true,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}});
 const fatal=(out.diagnostics||[]).filter(d=>d.category===ts.DiagnosticCategory.Error);
 assert.equal(fatal.length,0, file+' TypeScript syntax: '+fatal.map(d=>ts.flattenDiagnosticMessageText(d.messageText,' ')).join('; '));
}
const ui=fs.readFileSync(path.join(base,'src/app/video-center.component.html'),'utf8');
const gw=fs.readFileSync(path.join(base,'../VIDEO_CALL_SERVICE/server.mjs'),'utf8');
const app=fs.readFileSync(path.join(base,'server/video-routes.ts'),'utf8');
assert.match(ui,/Group Meetings \(10\/room\)/);
assert.match(ui,/<app-group-meetings/);
assert.match(gw,/maxParticipants:10/);
assert.match(gw,/\[\.\.\.room\.guests\.values\(\)\]\.filter\(x=>x\.admitted\)\.length>=9/);
assert.match(gw,/m.type==='admit'&&role==='host'/);
assert.match(gw,/room.mode==='direct'&&m.type==='signal'/);
assert.match(app,/requestedMode=req.body\?\.mode==='group'\?'group':'direct'/);
assert.match(app,/body.mode!=='group'/);
assert.match(app,/maxParticipants!==10/);
assert.match(gw,/protocolVersion:'calian-livekit-group-v2'/);
console.log('PASS: Multi-group UI, 10-person limit, invitation admission, direct-call routing, TypeScript syntax.');
