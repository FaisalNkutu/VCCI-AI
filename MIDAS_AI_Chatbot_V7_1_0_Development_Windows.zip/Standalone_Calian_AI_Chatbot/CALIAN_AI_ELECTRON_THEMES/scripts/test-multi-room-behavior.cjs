'use strict';
// Offline component-level behavior test. Fake LiveKit/WebSocket objects exercise
// the real TS controller without opening a public gateway or using credentials.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const Module=require('node:module');
const ts=require('typescript');
const file=path.join(__dirname,'../src/app/group-meetings.component.ts');
const source=fs.readFileSync(file,'utf8');
const compiled=ts.transpileModule(source,{fileName:file,compilerOptions:{experimentalDecorators:true,target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText;
const groups=[];
class FakeRoom{
 constructor(){this.events=new Map();this.remoteParticipants=new Map();this.live=true;this.published=[];this.unpublished=[];
  this.localParticipant={publishTrack:async track=>{this.published.push(track);},unpublishTrack:async(track,stop)=>{assert.equal(stop,false);this.unpublished.push(track);}};
  groups.push(this);
 }
 on(evt,fn){this.events.set(evt,fn);return this;}
 async connect(url,token){assert.match(url,/^wss:\/\//);assert.ok(token);}
 disconnect(){this.live=false;}
 async startAudio(){}
}
const fakeAngular={Component:()=>klass=>klass,ViewChild:()=>()=>{},ViewEncapsulation:{None:0}};
const mod=new Module(file,module);mod.filename=file;
mod.require=id=>{
 if(id==='@angular/core')return fakeAngular;
 if(id==='@angular/common'||id==='@angular/forms')return {};
 if(id==='livekit-client')return {Room:FakeRoom,RoomEvent:{TrackSubscribed:'track',TrackUnsubscribed:'untrack',ParticipantConnected:'join',ParticipantDisconnected:'leave',Disconnected:'gone'},Track:{Source:{Camera:'camera',Microphone:'mic'},Kind:{Video:'video'}}};
 throw Error('Unexpected dependency '+id);
};
mod._compile(compiled,file);
const {GroupMeetingsComponent}=mod.exports;
let stopped=0;
const tracks=[{kind:'video',enabled:true,stop:()=>stopped++},{kind:'audio',enabled:true,stop:()=>stopped++}];
Object.defineProperty(global,"navigator",{configurable:true,value:{mediaDevices:{getUserMedia:async()=>({active:true,getTracks:()=>tracks,getAudioTracks:()=>[tracks[1]],getVideoTracks:()=>[tracks[0]]})}}});
let sequence=0;
global.fetch=async(_url,options)=>{
 const body=JSON.parse(options.body);assert.equal(body.mode,'group');
 const i=++sequence;
 return {ok:true,json:async()=>({roomId:'room'+i,mode:'group',name:body.name,maxParticipants:10,expiresAt:'2026-12-01T00:00:00Z',inviteUrl:'https://gateway.test/i/invite'+i,wsUrl:'wss://gateway.test/signal',hostTicket:'ticket'+i})};
};
class FakeWS{
 static OPEN=1;
 constructor(){this.readyState=1;this.sent=[];}
 send(msg){this.sent.push(JSON.parse(msg));}
 close(){this.readyState=3;}
}
global.WebSocket=FakeWS;
const tick=async()=>{await new Promise(resolve=>setImmediate(resolve));await new Promise(resolve=>setImmediate(resolve));};
(async()=>{
 const m=new GroupMeetingsComponent({run:fn=>fn()},{detectChanges(){}});
 m.newName='Engineering';await m.createGroup();
 m.newName='Training';await m.createGroup();
 assert.equal(m.rooms.length,2);
 assert.equal(m.rooms[0].name,'Engineering');assert.equal(m.rooms[1].name,'Training');
 assert.notEqual(m.rooms[0].invite,m.rooms[1].invite);
 assert.equal(m.selectedId,'room2');
 await m.handleSignal(m.rooms[0],{type:'group-join',url:'wss://project.livekit.cloud',token:'room1-token'});
 await m.handleSignal(m.rooms[1],{type:'group-join',url:'wss://project.livekit.cloud',token:'room2-token'});
 await tick();
 assert.equal(groups.length,2,'two distinct LiveKit connections');
 assert.equal(groups[0].published.length,0,'background room must not publish camera');
 assert.equal(groups[1].published.length,2,'selected room publishes video + audio');
 m.selectGroup('room1');await m.publishing;
 assert.equal(groups[1].unpublished.length,2,'switch must withdraw camera + microphone from former room');
 assert.equal(groups[0].published.length,2,'newly selected room gets camera + microphone');
 await m.handleSignal(m.rooms[0],{type:'waiting',guestId:'guest-a',name:'A Guest'});
 await m.handleSignal(m.rooms[1],{type:'waiting',guestId:'guest-b',name:'B Guest'});
 assert.equal(m.rooms[0].pending.length,1);assert.equal(m.rooms[1].pending.length,1);
 m.admit(m.rooms[0],'guest-a');
 assert.equal(m.rooms[0].ws.sent.at(-1).guestId,'guest-a');
 assert.equal(m.rooms[1].ws.sent.length,0,'admit only touches requested room');
 m.endGroup(m.rooms[1]);assert.equal(m.rooms.length,1);
 assert.equal(m.rooms[0].name,'Engineering','other room remains alive');
 m.endAll();assert.equal(m.rooms.length,0);assert.equal(stopped,2,'camera and microphone are stopped');
 console.log('PASS: Two separate rooms, isolated invitations/admissions, one on-air camera, room switching, independent ending.');
})().catch(e=>{console.error(e);process.exitCode=1;});
