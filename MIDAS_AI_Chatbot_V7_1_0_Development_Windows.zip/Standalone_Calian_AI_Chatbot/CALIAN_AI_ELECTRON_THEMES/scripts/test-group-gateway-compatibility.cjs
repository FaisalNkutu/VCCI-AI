'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const Module=require('node:module');
const ts=require('typescript');

// Exercise the real private Express route with simulated public gateway replies.
// This requires only TypeScript, not an internet-facing gateway or LiveKit credentials.
const file=path.join(__dirname,'../server/video-routes.ts');
const js=ts.transpileModule(fs.readFileSync(file,'utf8'),{fileName:file,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText;
const m=new Module(file,module);m.filename=file;m.paths=module.paths;m._compile(js,file);
const {registerVideoRoutes}=m.exports;
let roomsHandler;
const app={get(){},post(route,handler){if(route==='/api/video/rooms')roomsHandler=handler;}};
process.env.CALIAN_VIDEO_PUBLIC_ORIGIN='https://video.example.test';
process.env.CALIAN_VIDEO_ADMIN_KEY='a'.repeat(40);
registerVideoRoutes(app,{port:8797,publicOrigin:'http://127.0.0.1:8797'});
assert.equal(typeof roomsHandler,'function');
const mockResponse=()=>({statusCode:200,output:null,headers:{},status(n){this.statusCode=n;return this;},json(v){this.output=v;return this;},setHeader(k,v){this.headers[k]=v;}});
const oldRoom={roomId:'id',hostTicket:'ticket',inviteUrl:'https://video.example.test/i/test',wsUrl:'wss://video.example.test/signal',iceServers:[],expiresAt:new Date().toISOString()};
const groupRoom={...oldRoom,mode:'group',maxParticipants:10};
const originalFetch=global.fetch;
async function callGateway(body,requestedMode){
 let actualMode=null;
 global.fetch=async(_url,options)=>{actualMode=JSON.parse(options.body).mode;return {ok:true,json:async()=>body};};
 const res=mockResponse();await roomsHandler({body:{mode:requestedMode},get:()=>undefined},res);
 assert.equal(actualMode,requestedMode);return res;
}
(async()=>{
 let res=await callGateway(oldRoom,'group');
 assert.equal(res.statusCode,502,'group call must never silently accept legacy direct gateway');
 assert.match(res.output.error,/older one-to-one service/);
 res=await callGateway(groupRoom,'group');
 assert.equal(res.statusCode,200);
 assert.equal(res.output.mode,'group');assert.equal(res.output.maxParticipants,10);
 assert.equal(res.output.hostTicket,groupRoom.hostTicket);
 res=await callGateway(oldRoom,'direct');
 assert.equal(res.statusCode,200,'legacy direct mode should remain compatible');
 console.log('PASS: Legacy gateway group mismatch rejected, group ticket passed, direct calls preserved.');
})().catch(e=>{console.error(e);process.exitCode=1;}).finally(()=>global.fetch=originalFetch);
