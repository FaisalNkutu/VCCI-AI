# V8: REQA's working web UI API + unchanged V7 direct SQL

The archived `pipeline-reqa-sql-mcp-repaired/app.py` uses two modes. The screenshot's default v1 workflow uses:

1. `POST /query/start` with JSON `{ "question": "Show me 10 records from contxt_oi_assoc" }`.
2. Poll `GET /query/status/{job_id}` until the job's `status` is `done` or `error`.
3. Read `result.success`, `result.sql`, `result.rows`, `result.row_count` and `result.error`.

This runs the existing REQA v1 pipeline, which **generates and executes SQL**; the returned SQL must **not** be executed again. CALIAN shows the generated SQL and results, with an error if the pipeline reports failure. This bypasses A2A's unreliable GenerateSQL/execute_sql skill selection for CALIAN English questions.

Direct literal SQL is **unchanged** from V7: `docker exec ... mcp_servers.database_server.call_tool('execute_sql')` via `server/direct-sql.ts`. All other agents keep the existing A2A routing.

The implementation uses the Windows-host-mapped API at `http://127.0.0.1:8080` by default; internal `http://api:8080` is only valid in Docker networking. Optional `REQA_API_KEY` in `calian.env` becomes the `X-API-Key` header. The API target is restricted to a loopback HTTP origin.

**No Docker image or Fouad Python code changed.** Only `server/index.ts`, new `server/reqa-web-query.ts`, startup version check, socket request timeouts, and sample environment documentation differ from V7.

For installation and tests, see `../START-HERE-V8.txt`.

Verification is local with mocked REQA responses and TypeScript syntax checks. Live execution on the user's Windows/Docker setup is not yet proven.
