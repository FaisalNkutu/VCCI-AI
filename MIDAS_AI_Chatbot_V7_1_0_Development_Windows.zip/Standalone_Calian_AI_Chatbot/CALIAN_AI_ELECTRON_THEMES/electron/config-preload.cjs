const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('calianConfig',Object.freeze({
 get:()=>ipcRenderer.invoke('calian:config:get'),
 save:values=>ipcRenderer.invoke('calian:config:save',values),
 close:()=>ipcRenderer.invoke('calian:config:close')
}));
