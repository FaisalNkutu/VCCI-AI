'use strict';
const ids={CALIAN_SCHEMA_DATABASE:'db',PYTHON_SERVICE_URL:'python',OLLAMA_URL:'ollama',REQA_API_URL:'reqa',CALIAN_SQL_DOCKER_CONTAINER:'docker',CALIAN_VIDEO_PUBLIC_ORIGIN:'video',CALIAN_VIDEO_ADMIN_KEY:'videoKey'};
const $=id=>document.getElementById(id);
const status=$('status');
const isFirst=new URLSearchParams(location.search).get('first')==='1';
if(!isFirst){$('heading').textContent='Update connections';document.querySelector('.intro').textContent='Update calian.env without rebuilding the executable. Changes take effect after closing and reopening CALIAN.AI.';}
(async()=>{
 try{
  const initial=await window.calianConfig.get();
  for(const [key,id] of Object.entries(ids))$(id).value=initial.values[key]||'';
  $('filepath').textContent='Configuration file: '+initial.path;
 }catch(e){status.textContent=String(e);}
})();
$('later').addEventListener('click',()=>window.calianConfig.close());
$('save').addEventListener('click',async()=>{
 $('save').disabled=true;status.textContent='';
 try{
  const values=Object.fromEntries(Object.entries(ids).map(([key,id])=>[key,$(id).value.trim()]));
  await window.calianConfig.save(values);
  await window.calianConfig.close();
 }catch(e){status.textContent=String(e.message||e);$('save').disabled=false;}
});
