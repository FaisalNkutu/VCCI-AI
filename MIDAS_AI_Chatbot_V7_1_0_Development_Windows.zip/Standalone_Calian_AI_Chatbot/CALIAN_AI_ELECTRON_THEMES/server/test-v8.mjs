import assert from 'node:assert/strict';
import {queryViaReqaWebPipeline, formatReqaAnswer} from './reqa-web-query.ts';

const question = 'Show me 10 records from contxt_oi_assoc';
const sample = {
 success: true,
 sql: 'SELECT * FROM contxt_oi_assoc LIMIT 10;',
 rows: [{contxt_id:1,obj_item_id:1,cat_code:'INCLDE',time:-1}],
 row_count:1,attempts:1,error:'',answer:'Returned one matching record.',
 explanation:{confidence:{score:.91}},
};
const toResponse = (data,status=200) => new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json'}});
const seen=[];
const responses=[
 toResponse({job_id:'test-job-123'}),
 toResponse({status:'running',stage:{stage:'sql_generation'},result:null}),
 toResponse({status:'done',stage:null,result:sample}),
];
const mock=async(url,init)=>{seen.push({url,init});const out=responses.shift();assert(out,'Unexpected API call');return out;};
const result=await queryViaReqaWebPipeline(question,{fetchImpl:mock,sleep:async()=>{},apiUrl:'http://127.0.0.1:8080'});
assert.equal(result.sql,sample.sql);
assert.equal(result.row_count,1);
assert.deepEqual(result.rows,sample.rows);
assert.equal(seen.length,3);
assert.equal(seen[0].url,'http://127.0.0.1:8080/query/start');
assert.deepEqual(JSON.parse(seen[0].init.body),{question});
assert.equal(seen[0].init.method,'POST');
assert.equal(seen[1].url,'http://127.0.0.1:8080/query/status/test-job-123');
assert.equal(seen[2].url,seen[1].url);
assert.match(formatReqaAnswer(result),/SELECT \* FROM contxt_oi_assoc LIMIT 10/);
assert.match(formatReqaAnswer(result),/INCLDE/);
assert.match(formatReqaAnswer(result),/91%/);
console.log('PASS: mirrored REQA Streamlit v1 POST + GET/poll contract and result.');

let failed=false;
try {
 await queryViaReqaWebPipeline('How many records are in contxt_oi_assoc?',{
  fetchImpl:async url=>String(url).endsWith('query/start')?toResponse({job_id:'test-job'}):toResponse({status:'done',result:{success:false,error:'Invalid SQL grounded table',sql:'',rows:[]}}),
  sleep:async()=>{},
 });
} catch(e){failed=/Invalid SQL grounded table/.test(e.message);}
assert(failed,'REQA SQL generation errors must NOT masquerade as empty success');
console.log('PASS: REQA grounding/generation failure propagated; no silent fallback.');

let key='';
await queryViaReqaWebPipeline('How many records are in contxt_oi_assoc?',{
 apiKey:'test-token',
 fetchImpl:async(url,init)=>{key=init.headers['X-API-Key'];return String(url).endsWith('/query/start')?toResponse({job_id:'test-job'}):toResponse({status:'done',result:sample});},
});
assert.equal(key,'test-token');
console.log('PASS: optional X-API-Key is passed to REQA.');

await assert.rejects(()=>queryViaReqaWebPipeline(question,{apiUrl:'http://example.com:8080'}),/local HTTP origin/);
console.log('PASS: REQA endpoint restricted to localhost.');
