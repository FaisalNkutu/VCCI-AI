/** The exact A2A request envelope from the previously working CALIAN adapter.
 * Both raw SQL and CALIAN-translated English use this ONE builder.
 * No changes to the Python/Docker/DBAgent skill-dispatch implementation.
 */
import {randomUUID} from 'node:crypto';
export type SqlContext={userContext:string;taskContext:string;systemInstructions:string;conversationHistory:Array<{role:string;content:string}>;agentResults:unknown[]};
export function buildOriginalA2aMessage(agentId:string,message:string,contextId:string,context:unknown){
 return {
  jsonrpc:'2.0',
  id:randomUUID(),
  method:'message/send',
  params:{message:{role:'user',messageId:randomUUID(),contextId,parts:[{kind:'text',text:message}],metadata:{agent_id:agentId,context}}}
 };
}
/** Stop an old English question in conversationHistory biasing the SQL skill selector. */
export function dbSqlOnlyContext(sql:string):SqlContext {
 return {userContext:'',taskContext:'',systemInstructions:'',conversationHistory:[{role:'user',content:sql}],agentResults:[]};
}
