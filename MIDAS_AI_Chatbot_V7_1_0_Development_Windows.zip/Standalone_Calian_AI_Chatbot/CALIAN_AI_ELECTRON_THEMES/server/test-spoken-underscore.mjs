import {strict as assert} from 'node:assert';
import {resolveTable, schemaAwareTranslate, clearSchemaCache} from './schema-aware-sql.ts';

const db='vcci_aug_26_dbg_1';
const allowed=[`${db}.contxt_oi_assoc`, `${db}.contxt_assoc`, `${db}.contxt_oi_assoc_stat`];
const cases=[
 'How many records are in the table Context_Underscore_OI_Underscore_ASSOC?',
 'How many records are in the table context underscore O I underscore assoc?',
 'Show me 10 records from the table context under score O I under score association',
 'Show me 10 records from the context O I association table',
 'Show 10 records from the table context_ol_assoc',
 'Count the records of the context under score O I under score associates table'
];
for (const question of cases) {
  assert.equal(resolveTable(question,allowed).name,`${db}.contxt_oi_assoc`,question);
}
// Existing behavior stays: exact table names work, ambiguity and fabricated tables fail closed.
assert.equal(resolveTable('Show 10 records from contxt_oi_assoc',allowed).name,`${db}.contxt_oi_assoc`);
assert.throws(()=>resolveTable('Show 10 records from table fake_thing',allowed),/not found/);
assert.throws(()=>resolveTable('Show 10 records from table contxt_oi_assoc',
 [`${db}.contxt_oi_assoc`,'another_db.contxt_oi_assoc']),/Several accessible databases/);
assert.throws(()=>resolveTable(`Show 10 records from other_db.contxt_oi_assoc`,allowed),/does not exist/);
assert.throws(()=>resolveTable('Show 10 records from context_oo_assoc',
 [`${db}.contxt_oi_assoc`,`${db}.contxt_ol_assoc`]),/several tables/);

const statements=[];
const executor=async sql=>{
 statements.push(sql);
 if(sql.startsWith('SELECT DATABASE()'))return {success:true,rows:[{current_database:db}],error:''};
 if(sql.includes('INFORMATION_SCHEMA.TABLES'))return {success:true,rows:[
  {schema_name:db,table_name:'contxt_oi_assoc'},
  {schema_name:db,table_name:'contxt_assoc'},
  {schema_name:db,table_name:'contxt_oi_assoc_stat'}
 ],error:''};
 return {success:true,rows:[{total_records:42}],error:''};
};
const noOllama=async()=>{throw Error('Simple count/list must not call Ollama')};
clearSchemaCache();
const count=await schemaAwareTranslate(cases[0],executor,noOllama,'spoken-separator-test');
assert.equal(count.sql,`SELECT COUNT(*) AS total_records FROM \`${db}\`.\`contxt_oi_assoc\`;`);
const list=await schemaAwareTranslate(cases[2],executor,noOllama,'spoken-separator-test');
assert.equal(list.sql,`SELECT * FROM \`${db}\`.\`contxt_oi_assoc\` LIMIT 10;`);
assert(statements.some(sql=>sql.includes(`TABLE_SCHEMA = '${db}'`)));
console.log('PASS: spoken separators, near-match guard, exact match, database scoping, count/list translation, ambiguity rejection');
