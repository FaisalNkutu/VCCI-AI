import assert from 'node:assert/strict';
import http from 'node:http';
import {queryViaReqaWebPipeline} from './reqa-web-query.ts';
let received=0;let poll=0;
const server=http.createServer(async(req,res)=>{
  res.setHeader('content-type','application/json');
  if(req.method==='POST' && req.url==='/query/start'){
    let body='';for await(const chunk of req)body+=chunk;
    assert.deepEqual(JSON.parse(body),{question:'Show me 10 records from contxt_oi_assoc.'});
    received++;
    res.end(JSON.stringify({job_id:'live-mock-job'}));return;
  }
  if(req.method==='GET' && req.url==='/query/status/live-mock-job'){
    poll++;
    const done=poll>1;
    res.end(JSON.stringify(done?{status:'done',result:{success:true,sql:'SELECT * FROM contxt_oi_assoc LIMIT 10;',rows:[{contxt_id:1,obj_item_id:1}],row_count:1,attempts:1,error:'',answer:'ok'}}:{status:'running',stage:{stage:'schema_rag'},result:null}));return;
  }
  res.statusCode=404;res.end(JSON.stringify({error:'Unknown endpoint'}));
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
try {
 const address=server.address();
 const result=await queryViaReqaWebPipeline('Show me 10 records from contxt_oi_assoc.',{apiUrl:`http://127.0.0.1:${address.port}`,sleep:async()=>{}});
 assert.equal(result.row_count,1);assert.equal(received,1);assert.equal(poll,2);
 console.log('PASS: real local HTTP client POST /query/start and two status polls, no second execution.');
} finally {server.close();}
