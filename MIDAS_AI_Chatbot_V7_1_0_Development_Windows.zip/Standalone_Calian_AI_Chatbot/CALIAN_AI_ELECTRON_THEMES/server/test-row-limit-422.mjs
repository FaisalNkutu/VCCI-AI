import {strict as assert} from 'node:assert';
import {clearSchemaCache, schemaAwareTranslate} from './schema-aware-sql.ts';
import {classifyDbInput} from './direct-sql.ts';

process.env.CALIAN_SCHEMA_DATABASE='vcci_aug_26_dbg_1';
const schema='vcci_aug_26_dbg_1';
const sqls=[];
const db=async sql=>{
 sqls.push(sql);
 if(sql.includes('INFORMATION_SCHEMA.TABLES'))return {success:true,rows:[
  {schema_name:schema,table_name:'contxt_oi_assoc'},
  {schema_name:schema,table_name:'contxt_assoc'}],error:''};
 if(sql.includes('INFORMATION_SCHEMA.COLUMNS'))return {success:true,rows:[{column_name:'cat_code'},{column_name:'salary'}],error:''};
 return {success:true,rows:[],error:''};
};
const noOllama=async()=>{throw Error('Ollama should not be called for row caps');};
const examples=[
 'Show me a maximum of 10 records from contxt_oi_assoc table',
 'Show me a maximum of ten records from the context O I association table',
 'Show me no more than 10 rows from contxt_oi_assoc',
 'Display up to 10 records from contxt_oi_assoc',
 'List at most 10 rows from contxt_oi_assoc',
 'Show me only 10 records from contxt_oi_assoc',
 'Show me 10 records only from contxt_oi_assoc',
 'Show me 10 records from contxt_oi_assoc',
 'Select 10 records from contxt_oi_assoc',
];
clearSchemaCache();
for(const q of examples){
 const r=await schemaAwareTranslate(q,db,noOllama,'row-limit-test');
 assert.equal(r.method,'schema-list',q);
 assert.equal(r.sql,`SELECT * FROM \`${schema}\`.\`contxt_oi_assoc\` LIMIT 10;`,q);
}
// True value filters and value aggregates must not be mistaken for row limits.
let plans=0;
const plan=async (_q,table,_columns)=>{plans++;return {operation:'aggregate',table,aggregate:{function:'MAX',column:'salary'}};};
const agg=await schemaAwareTranslate('What is the maximum salary in contxt_oi_assoc?',db,plan,'row-limit-test');
assert.equal(agg.method,'schema-ollama-plan');
assert.match(agg.sql,/MAX\(`salary`\)/);
assert.equal(plans,1);
assert.equal(classifyDbInput('Select 10 records from contxt_oi_assoc'), 'question');
assert.equal(classifyDbInput('SELECT * FROM `vcci_aug_26_dbg_1`.`contxt_oi_assoc` LIMIT 10;'), 'sql');
assert.equal(classifyDbInput('SELECT COUNT(*) FROM contxt_oi_assoc'), 'sql');
console.log('PASS: natural-language row caps use deterministic LIMIT, value MAX remains an aggregate, direct SQL unchanged.');
