/**
 * CALIAN-only client for the existing REQA Streamlit UI's v1 workflow.
 * The reference app.py invokes POST /query/start and polls
 * GET /query/status/{job_id}. That pipeline both GENERATES and EXECUTES SQL.
 * We consume its result as-is: do NOT execute returned SQL again.
 * This file does not modify REQA or its containers.
 */
export type ReqaQueryResult = {
  success: boolean;
  sql: string;
  answer: string;
  rows: unknown[];
  row_count: number;
  attempts: number;
  error: string;
  explanation?: Record<string, unknown>;
};

export type ReqaWebQueryOptions = {
  apiUrl?: string;
  apiKey?: string;
  fetchImpl?: typeof fetch;
  sleep?: (ms: number) => Promise<void>;
  now?: () => number;
  timeoutMs?: number;
};

function requireLocalApi(url: string): string {
  let u: URL;
  try { u = new URL(url); } catch { throw new Error('REQA_API_URL is not a valid URL'); }
  if (u.protocol !== 'http:' || !['127.0.0.1','localhost','[::1]'].includes(u.hostname.toLowerCase()) ||
      u.username || u.password || u.search || u.hash || (u.pathname !== '/' && u.pathname !== '')) {
    throw new Error('REQA_API_URL must be a local HTTP origin, such as http://127.0.0.1:8080');
  }
  return u.origin;
}

const DEFAULT_TIMEOUT_MS = 400_000;
const POLL_INTERVAL_MS = 1_000;
const sleepMs = (ms: number) => new Promise<void>(resolve => setTimeout(resolve,ms));

/** Only HTTP requests shown in Fouad's working Streamlit app.py are used. */
export async function queryViaReqaWebPipeline(question: string, opts: ReqaWebQueryOptions = {}): Promise<ReqaQueryResult> {
  if (!question.trim() || question.length > 4_000) throw new Error('English database question must be 1–4000 characters');
  const origin = requireLocalApi(opts.apiUrl ?? process.env.REQA_API_URL ?? 'http://127.0.0.1:8080');
  const apiKey = opts.apiKey ?? process.env.REQA_API_KEY ?? '';
  const fetcher = opts.fetchImpl ?? fetch;
  const sleep = opts.sleep ?? sleepMs;
  const now = opts.now ?? Date.now;
  const timeoutMs = opts.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  const deadline = now() + timeoutMs;
  const headers: Record<string,string> = {'Accept':'application/json'};
  if (apiKey) headers['X-API-Key'] = apiKey;

  async function request(uri: string, method: 'GET'|'POST', body?: Record<string,unknown>): Promise<any> {
    const remaining = deadline - now();
    if (remaining <= 0) throw new Error(`REQA query timed out after ${Math.round(timeoutMs/1000)} seconds`);
    let response: Response;
    try {
      response = await fetcher(origin+uri,{
        method,
        headers: {...headers,...(body?{'Content-Type':'application/json'}:{})},
        body: body ? JSON.stringify(body) : undefined,
        signal: AbortSignal.timeout(Math.min(15_000,remaining)),
      });
    } catch (e) {
      throw new Error(`Cannot reach REQA API at ${origin}: ${e instanceof Error ? e.message : String(e)}`);
    }
    if (!response.ok) {
      const text = (await response.text()).slice(0,600);
      const extra = response.status === 403 ? ' Check REQA_API_KEY in calian.env.' : '';
      throw new Error(`REQA API HTTP ${response.status} (${uri}): ${text}${extra}`);
    }
    try { return await response.json(); }
    catch { throw new Error(`REQA API returned non-JSON data for ${uri}`); }
  }

  const start = await request('/query/start','POST',{question:question.trim()});
  const jobId = start?.job_id;
  if (typeof jobId !== 'string' || !/^[A-Za-z0-9_-]{1,128}$/.test(jobId)) {
    throw new Error('REQA API returned an invalid or missing job_id');
  }

  while (true) {
    const status = await request(`/query/status/${jobId}`,'GET');
    if (status?.status === 'done' || status?.status === 'error') {
      const result = status?.result;
      if (!result || typeof result !== 'object' || typeof result.success !== 'boolean') {
        throw new Error('REQA query finished without a valid result');
      }
      if (status.status === 'error' || !result.success) {
        throw new Error(`REQA SQL pipeline failed: ${String(result.error || result.answer || 'Unknown error').slice(0,1200)}`);
      }
      if (typeof result.sql !== 'string' || !/^\s*(SELECT|WITH)\b/i.test(result.sql)) {
        throw new Error('REQA reported success but returned no read-only SELECT query');
      }
      if (!Array.isArray(result.rows)) throw new Error('REQA returned an invalid rows array');
      return {
        success:true,
        sql:result.sql,
        answer:typeof result.answer==='string'?result.answer:'',
        rows:result.rows,
        row_count:Number.isInteger(result.row_count)?result.row_count:result.rows.length,
        attempts:Number.isInteger(result.attempts)?result.attempts:0,
        error:'',
        explanation:result.explanation && typeof result.explanation==='object'?result.explanation:{},
      };
    }
    if (status?.status !== 'running') throw new Error(`REQA returned unexpected job status: ${String(status?.status)}`);
    if (now()+POLL_INTERVAL_MS > deadline) throw new Error(`REQA query timed out after ${Math.round(timeoutMs/1000)} seconds`);
    await sleep(POLL_INTERVAL_MS);
  }
}

/** Compact, readable answer; keep WebSocket messages bounded. */
export function formatReqaAnswer(result: ReqaQueryResult): string {
  const rows = result.rows.slice(0,100);
  let formatted = JSON.stringify(rows,null,2);
  if (formatted.length > 150_000) formatted=formatted.slice(0,150_000)+'\n… (display truncated)';
  const extra = result.rows.length > 100 ? `\n(Showing first 100 of ${result.rows.length} returned rows in chat)` : '';
  const explanation = result.explanation?.confidence;
  const score = explanation && typeof explanation === 'object' && 'score' in explanation &&
    typeof (explanation as any).score === 'number' ? `\nGeneration confidence: ${Math.round((explanation as any).score*100)}%` : '';
  return `Generated SQL (REQA v1):\n${result.sql}\n\nQuery results (${result.row_count} row(s)):${extra}\n${formatted}${score}${result.answer ? `\n\n${result.answer.slice(0,2500)}` : ''}`;
}
