import test from 'node:test';import assert from 'node:assert/strict';
import {readV7Fixture,validateV7ReadRequest,requireV7ReadPolicy,fixtureModeActive} from '../midas-v7-tools.mjs';
test('disabled by default',()=>{assert.equal(fixtureModeActive({}),false);assert.equal(requireV7ReadPolicy({}).allow,false);});
test('never accepts arbitrary tool names, SQL, URLs',()=>{for(const tool of ['sql','delete','http://x','shell'])assert.equal(validateV7ReadRequest({tool}).ok,false);});
test('authorization scope cannot expand to unknown entities',()=>{assert.equal(validateV7ReadRequest({tool:'combat_power_series',entityIds:[999]}).ok,false);});
test('invalid ranges fail without partial data',()=>{assert.equal(validateV7ReadRequest({tool:'combat_power_series',timeRange:{start:130,end:200}}).ok,false);});
test('comparison reproducible with evidence id',()=>{
 const input={tool:'compare_series',entityIds:[101,102],timeRange:{start:0,end:120}};
 const a=readV7Fixture(input),b=readV7Fixture(input);
 assert.equal(a.status,'ok');assert.equal(a.data.lastValueDifference,-18);assert.equal(a.evidenceId,b.evidenceId);
 assert.equal(a.source.verifiedLiveData,false);
});
test('two ids required to compare',()=>assert.equal(readV7Fixture({tool:'compare_series',entityIds:[101]}).status,'unavailable'));
test('production proxy fails closed even if caller has role string',()=>assert.equal(requireV7ReadPolicy({fixtureMode:false,verifiedPrincipal:{sub:'s'},permissions:['midas:copilot:read']}).allow,false));
