export interface ChainAgent {id: string; name: string; type: 'north' | 'aicore'; description?: string; commands?: string[];}
export interface ChainTrace {agentId: string; agentName: string; status: 'completed' | 'failed' | 'blocked'; reason: string;}
export interface ChainResult {answer:string;trace:ChainTrace[];planningMethod:string;reason:string;stopReason:string;complete:boolean;steps:number;}
export function runAgentChain(options: {
 question: string; contextId: string; context?: unknown; agents: ChainAgent[]; maxSteps?: number; deadlineMs?: number;
 choose: (args:any)=>Promise<any>; invoke:(args:any)=>Promise<string>;
 planner?: (args:any)=>Promise<any>; evaluate?: (args:any)=>Promise<any>; synthesize?: (args:any)=>Promise<string>;
}):Promise<ChainResult>;
