/** V7 synthetic, read-only evidence tools. No MIDAS DB network access. Production FAIL-CLOSED. */
import {createHash} from 'node:crypto';
const MAX_IDS=20;
const DATASET='synthetic-v7-fixture';
const SERIES={
  101:[{time:0,value:91},{time:20,value:89},{time:40,value:83},{time:60,value:80},{time:80,value:77},{time:100,value:75},{time:120,value:70}],
  102:[{time:0,value:78},{time:20,value:80},{time:40,value:82},{time:60,value:84},{time:80,value:83},{time:100,value:85},{time:120,value:88}],
};
export const V7_READ_TOOLS=Object.freeze([
 {id:'summary_metrics',mode:'read',description:'Synthetic summary for offline V7 testing'},
 {id:'combat_power_series',mode:'read',description:'Synthetic time-series evidence for selected entities'},
 {id:'compare_series',mode:'read',description:'Deterministic comparison with evidence references'},
 {id:'entities_available',mode:'read',description:'Synthetic authorized entity catalogue'},
 {id:'selected_dashboard_metadata',mode:'read',description:'Safe selected UI metadata only'},
]);
const normalId=(v)=>Number.isSafeInteger(v)&&v>0;
export function validateV7ReadRequest(value){
 if(!value||typeof value!=='object'||Array.isArray(value))return {ok:false,error:'Expected a read-tool request object'};
 const tool=value.tool;
 if(!V7_READ_TOOLS.some(t=>t.id===tool))return {ok:false,error:'Tool is not in the read-only catalogue'};
 const source=Array.isArray(value.entityIds)?value.entityIds:[];
 if(source.length>MAX_IDS||source.some(x=>!normalId(x)))return {ok:false,error:'Entity ID list must contain at most 20 valid numeric IDs'};
 const entityIds=[...new Set(source)];
 if(entityIds.some(id=>!Object.hasOwn(SERIES,id)))return {ok:false,error:'Entity not in synthetic fixture authorization scope'};
 const range=value.timeRange;
 if(range!==undefined&&range!==null && (!Number.isFinite(range?.start)||!Number.isFinite(range?.end)||range.start<0||range.end>120||range.start>=range.end))return {ok:false,error:'Synthetic time range must be within 0–120 with start < end'};
 const start=range?.start??0, end=range?.end??120;
 if(typeof value.dashboard!=='undefined' && (typeof value.dashboard!=='string'||value.dashboard.length>60))return {ok:false,error:'Invalid dashboard identifier'};
 return {ok:true,request:{tool,entityIds,start,end,dashboard:typeof value.dashboard==='string'?value.dashboard:null}};
}
function summarize(points){
 if(!points.length)return null;
 const values=points.map(p=>p.value);
 const first=values[0],last=values[values.length-1];
 return {count:values.length,first,last,min:Math.min(...values),max:Math.max(...values),change:last-first};
}
/** No inferred observations: deterministic numbers and explicit source labels. */
export function readV7Fixture(input){
 const checked=validateV7ReadRequest(input);
 if(!checked.ok)return {status:'invalid',reason:checked.error};
 const {tool,entityIds,start,end,dashboard}=checked.request;
 const chosen=entityIds.length?entityIds:[101,102];
 const series=chosen.map(id=>{
  const data=SERIES[id].filter(p=>p.time>=start&&p.time<=end);
  return {entityId:id,unit:'synthetic-index-points',data,statistics:summarize(data)};
 });
 let data;
 switch(tool){
  case 'entities_available': data={entities:[{id:101,name:'Fixture Alpha'},{id:102,name:'Fixture Bravo'}]};break;
  case 'selected_dashboard_metadata':data={dashboard,timeRange:{start,end},selectedEntityIds:chosen};break;
  case 'summary_metrics':data={entityCount:2,fixture:true,summary:series.map(s=>({entityId:s.entityId,statistics:s.statistics}))};break;
  case 'combat_power_series':data={series};break;
  case 'compare_series':
   if(series.length<2)return {status:'unavailable',reason:'Comparison requires two distinct synthetic entity IDs'};
   data={series:series.map(s=>({entityId:s.entityId,statistics:s.statistics})),lastValueDifference:series[0].statistics&&series[1].statistics?series[0].statistics.last-series[1].statistics.last:null};break;
  default:return {status:'invalid',reason:'Unsupported tool'};
 }
 const parameters={tool,dashboard,entityIds:chosen,timeRange:{start,end}};
 const digest=createHash('sha256').update(JSON.stringify({dataset:DATASET,parameters,data})).digest('hex');
 return {status:'ok',evidenceId:'fixture-sha256:'+digest,source:{kind:'synthetic-fixture',dataset:DATASET,classification:'TEST-ONLY',verifiedLiveData:false},
   generatedAt:new Date().toISOString(),parameters,units:'synthetic-index-points',data,
   warnings:['SYNTHETIC TEST DATA: Not a MIDAS measurement or operational finding.']};
}
export function fixtureModeActive(env=process.env){return env.MIDAS_V7_FIXTURE_MODE==='true';}
export function requireV7ReadPolicy({fixtureMode,verifiedPrincipal,permissions}={}){
 if(fixtureMode===true)return {allow:true,mode:'synthetic-fixture-only'};
 // Real MIDAS reads require audited, authoritative identity AND dataset-scoped permission.
 // The adapter is intentionally absent until the MIDAS security integration is supplied.
 if(!verifiedPrincipal||!permissions?.includes('midas:copilot:read'))return {allow:false,reason:'MIDAS V7 data gateway is disabled until server-side identity and dataset authorization are configured'};
 return {allow:false,reason:'Production MIDAS read adapter has not been installed: fail closed'};
}
