export declare const V7_READ_TOOLS: ReadonlyArray<{id:string;mode:string;description:string}>;
export declare function fixtureModeActive(env?:Record<string,string|undefined>):boolean;
export declare function requireV7ReadPolicy(opts?:{fixtureMode?:boolean;verifiedPrincipal?:unknown;permissions?:string[]}):{allow:boolean;mode?:string;reason?:string};
export declare function readV7Fixture(input:unknown):any;
