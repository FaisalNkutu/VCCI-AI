/**
 * CALIAN-owned read-only natural-language database adapter.
 * Does not alter the Python A2A executor or Fouad's GenerateSQL implementation.
 * For simple requests, generate a deterministic query. For more complex SINGLE-TABLE
 * requests, ask local Ollama for a JSON PLAN, and compile SQL from validated columns.
 */

import {classifyDbInput} from './direct-sql';

export type SqlExecutor = (sql: string) => Promise<unknown>;
export type PlanGenerator = (question: string, table: string, columns: string[]) => Promise<unknown>;
export type SqlTranslation = { sql: string; method: 'deterministic' | 'ollama-plan' };

const IDENTIFIER = /^[A-Za-z_][A-Za-z_0-9]*$/;
const MUTATING_INTENT = /\b(?:delete|remove|drop|truncate|insert|update|alter|replace|grant|revoke|overwrite|erase|modify|create|execute|run a command)\b/i;

export function isDirectSql(message: string): boolean { return classifyDbInput(message) !== 'question'; }

function quoteIdentifier(name: string): string {
  if (!IDENTIFIER.test(name)) throw new Error(`Invalid SQL identifier: ${name}`);
  return '`' + name + '`';
}
function quotedTable(name: string): string {
  const chunks = name.split('.');
  if (chunks.length > 2 || !chunks.every(x => IDENTIFIER.test(x))) throw new Error('Invalid table name');
  return chunks.map(quoteIdentifier).join('.');
}
function namedTable(message: string): string | null {
  const quoted = message.match(/[`"]([A-Za-z_][A-Za-z_0-9]*(?:\.[A-Za-z_][A-Za-z_0-9]*)?)[`"](?!\w)/);
  if (quoted) return quoted[1];
  const matches = [...message.matchAll(/\b(?:from|in|within|table|of)\s+([A-Za-z_][A-Za-z_0-9]*(?:\.[A-Za-z_][A-Za-z_0-9]*)?)(?=\b)/gi)]
   .map(m => m[1]).filter(x => !/^(?:the|a|an|my|our|this|that|database|table|records|rows|entries|all|each|which|how|what)$/i.test(x));
  const underscored = matches.find(x => x.includes('_') || x.includes('.'));
  return underscored || matches[0] || null;
}
function countIntent(question: string): boolean {
 return /\bhow many\s+(?:(?:total|matching|all)\s+)?(?:rows?|records?|entries?)\b/i.test(question) ||
        /\b(?:count|number of|total number of)\s+(?:(?:all|the)\s+)?(?:rows?|records?|entries?)\b/i.test(question);
}
export function listIntent(question: string): boolean {
 return /^(?:please\s+)?(?:show|list|display|fetch|retrieve|give me|select)\s+(?:(?:me|the|all|any|some|a|an|first|top|exactly|only|just|\d{1,4}|one|two|three|four|five|six|seven|eight|nine|ten|twenty|hundred)\s+)*(?:rows?|records?|entries?|items?|data|information|everything)\s+(?:from|in|within|of)\b/i.test(question.trim());
}
function maxRows(): number {
 const n = Number(process.env.CALIAN_DB_NL_MAX_ROWS || '100');
 return Number.isInteger(n) && n > 0 && n <= 500 ? n : 100;
}
function desiredLimit(question: string): number {
 const n = question.match(/\b(?:first|top|show|list|display|fetch|retrieve|give me)\s+(?:me\s+)?(?:the\s+)?(\d{1,4})\b/i);
 return n ? Math.max(1, Math.min(maxRows(), Number(n[1]))) : Math.min(maxRows(), /\b(?:data|information|everything)\b/i.test(question)?100:20);
}

/** Parse the A2A ExecuteSQL result for information_schema.columns metadata. */
export function extractColumnNames(payload: unknown): string[] {
 const found = new Set<string>();
 const seen = new Set<unknown>();
 function visit(v: unknown, depth: number): void {
  if (depth > 16 || v == null || seen.has(v) || found.size > 250) return;
  if (typeof v === 'string') {
   if (v.length > 250000) return;
   try { visit(JSON.parse(v), depth + 1); } catch { /* non-JSON message */ }
   return;
  }
  if (typeof v !== 'object') return;
  seen.add(v);
  if (Array.isArray(v)) { for (const x of v.slice(0,500)) visit(x,depth+1); return; }
  const o = v as Record<string, unknown>;
  for (const key of ['COLUMN_NAME','column_name','Field','field']) {
   const value = o[key];
   if (typeof value === 'string' && IDENTIFIER.test(value)) found.add(value);
  }
  for (const value of Object.values(o)) visit(value,depth+1);
 }
 visit(payload,0);
 return [...found];
}

function safeSqlValue(value: unknown): string {
 if (value === null) return 'NULL';
 if (typeof value === 'number' && Number.isFinite(value) && Math.abs(value) < 1e15) return String(value);
 if (typeof value === 'boolean') return value ? '1' : '0';
 // Fail closed instead of accepting arbitrary LLM-generated SQL fragments.
 if (typeof value !== 'string' || value.length > 128 || !/^[\p{L}\p{N} _.,:@\-]+$/u.test(value)) throw new Error('Unsafe or unsupported filter value');
 return `'${value}'`;
}


/** A model may suggest a plan, but must not invent predicates or omit requested ones.
 * Supported filter grammar: WHERE verified_column operator value [AND ...].
 * Values are compared to the original utterance, not model-generated text. */
export function validatePlanIntent(raw:unknown, question:string, availableColumns:string[]):void {
 if(!raw||typeof raw!=='object'||Array.isArray(raw))throw Error('Invalid query plan');
 const p=raw as Record<string,any>;
 const fail=(reason:string):never=>{throw Error('SQL intent validation: '+reason+' No data query was executed.');};
 const filters:unknown[]=p.filters===undefined?[]:p.filters;
 if(!Array.isArray(filters))fail('Invalid filters.');
 const where=question.match(/\bwhere\s+(.+?)(?=\s+(?:order\s+by|sort\s+by|limit\s+|ordered\s+by|sorted\s+by)\b|[?;]?$)/i);
 if(!where){
  if(/\bwhere\b/i.test(question))fail('Please specify the missing filter condition.');
  if(filters.length)fail('A filter was not explicitly requested.');
  if(/\b(?:whose|having|matching|filter(?:ed)?|with(?:out)?)\b/i.test(question))fail('Please express the filter as WHERE column equals value.');
 }else{
  const parts=where[1].trim().split(/\s+and\s+/i);
  if(parts.length!==filters.length||parts.length>5)fail('Requested filters do not match the plan.');
  const numbers:Record<string,string>={zero:'0',one:'1',two:'2',three:'3',four:'4',five:'5',six:'6',seven:'7',eight:'8',nine:'9',ten:'10',eleven:'11',twelve:'12',twenty:'20',hundred:'100'};
  const ops:Record<string,string>={'=':'=', 'is':'=', 'equals':'=', 'equal to':'=', 'is equal to':'=', '!=':'!=','<>':'!=','is not':'!=','not equal to':'!=','>':'>','greater than':'>','<':'<','less than':'<','>=':'>=','at least':'>=','<=':'<=','at most':'<=','contains':'contains','starts with':'starts_with'};
  const norm=(x:string)=>x.toLowerCase().replace(/[`]/g,'').replace(/\s+/g,'_');
  const remaining=[...filters] as Array<Record<string,any>>;
  for(const part of parts){
   const m=part.trim().match(/^(.+?)\s*(>=|<=|!=|<>|=|>|<|\bis not\b|\bis equal to\b|\bnot equal to\b|\bequal to\b|\bequals\b|\bgreater than\b|\bless than\b|\bat least\b|\bat most\b|\bcontains\b|\bstarts with\b|\bis\b)\s*(.+)$/i);
   if(!m)fail('Please specify an explicit column, operator and value.');
   const [,field,operator,rawValue]=m!;
   const col=availableColumns.find(c=>norm(c)===norm(field.trim()));
   if(!col)fail('Unknown or ambiguous filter column: '+field+'.');
   const valueText=rawValue.trim().replace(/\.$/,'');
   const quoted=/^(['"])(.*)\1$/.exec(valueText);
   const value=quoted?quoted[2]:valueText;
   if(!value||(!quoted&&/\b(?:or|and|where|select)\b/i.test(value)))fail('Unsupported or ambiguous filter value.');
   const op=ops[operator.toLowerCase()];
   const index=remaining.findIndex(f=>f&&typeof f.column==='string'&&norm(f.column)===norm(col!)&&f.operator===op&&
    (f.value===null?(!quoted&&/^null$/i.test(value)):typeof f.value==='number'?(!quoted&&/^-?\d+(?:\.\d+)?$/.test(numbers[value.toLowerCase()]||value)&&Number(numbers[value.toLowerCase()]||value)===f.value):typeof f.value==='string'&&f.value===value));
   if(index<0)fail('Filter column, comparison or value differs from the request.');
   remaining.splice(index,1);
  }
 }
 const intentHead=question.split(/\b(?:from|in|within|where)\b/i)[0];
 const count=/\b(?:how many|count|number of|total number of)\b/i.test(intentHead);
 const aggregate=intentHead.match(/\b(sum|average|avg|minimum|min|maximum|max)\b(?!\s+(?:of\s+)?\d+\s+(?:rows?|records?|items?))/i);
 const aggMap:Record<string,string>={sum:'SUM',average:'AVG',avg:'AVG',minimum:'MIN',min:'MIN',maximum:'MAX',max:'MAX'};
 if(p.operation==='count'&&!count)fail('An unrequested count was generated.');
 if(count&&p.operation!=='count')fail('The requested count was not preserved.');
 if(p.operation==='aggregate'&&(!aggregate||String(p.aggregate?.function).toUpperCase()!==aggMap[aggregate[1].toLowerCase()]))fail('An unrequested aggregate was generated.');
 if(aggregate&&p.operation!=='aggregate')fail('The requested aggregate was not preserved.');
 const projection=question.split(/\b(?:from|in|within)\b/i)[0].toLowerCase().replace(/_/g,' ');
 const explicitlyNamed=(c:string)=>(' '+projection.replace(/[^a-z0-9]+/g,' ')+' ').includes(' '+c.toLowerCase().replace(/_/g,' ')+' ');
 if(p.operation==='aggregate'&&!explicitlyNamed(String(p.aggregate?.column||'')))fail('The aggregate column was not requested.');
 if(p.operation==='list'){
  if(/\b(?:including|excluding|except|between|above|below|after|before)\b/i.test(question)&&!where)fail('Please restate the requested columns or filter explicitly.');
  const requested=availableColumns.filter(explicitlyNamed);
  if(requested.length){if(!Array.isArray(p.columns)||p.columns.length!==requested.length||!requested.every(c=>p.columns.some((v:unknown)=>typeof v==='string'&&v.toLowerCase()===c.toLowerCase())))fail('Requested columns differ from the plan.');}
  else if(Array.isArray(p.columns)&&p.columns.length)fail('Unrequested column projection.');
  if(p.orderBy||/\b(?:order(?:ed)? by|sort(?:ed)? by|latest|newest|oldest|last)\b/i.test(question)){
   const ordering=question.match(/\b(?:order(?:ed)?|sort(?:ed)?)\s+by\s+([a-z_][a-z_0-9]*)(?:\s+(asc|desc|ascending|descending))?/i);
   if(!ordering||!p.orderBy||String(p.orderBy.column).toLowerCase()!==ordering[1].toLowerCase()||String(p.orderBy.direction||'ASC').toUpperCase()!==(/^(desc|descending)$/i.test(ordering[2]||'')?'DESC':'ASC'))fail('Please specify the sort column and direction explicitly.');
  }
  const distinct=/\b(?:distinct|unique)\b/i.test(question);
  if(distinct!== (p.distinct===true))fail('DISTINCT was not preserved or was not requested.');
  const requestedLimit=question.match(/\b(?:first|top|limit(?: to)?)\s+(\d{1,4})\b/i)||question.match(/\b(\d{1,4})\s+(?:rows?|records?|entries?|items?)\b/i);
  const limit=requestedLimit?Math.max(1,Math.min(maxRows(),Number(requestedLimit[1]))):Math.min(maxRows(),100);
  p.limit=limit;
 }
 if(/\b(?:group by|per each|for each|join|having)\b/i.test(question))fail('This query requires an unsupported grouping or join. Use explicit read-only SQL instead.');
}

/** Compile a structured JSON plan; NEVER execute SQL text supplied by Ollama. */
export function compileReadOnlyPlan(raw: unknown, table: string, availableColumns: string[]): string {
 if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('Ollama returned an invalid query plan');
 const p = raw as Record<string, any>;
 if (p.table !== table) throw new Error('Ollama selected a different table; refusing execution');
 const columns = new Map(availableColumns.map(c => [c.toLowerCase(),c]));
 const col = (value: unknown): string => {
  if (typeof value !== 'string' || !IDENTIFIER.test(value)) throw new Error('Invalid column name from Ollama');
  const actual = columns.get(value.toLowerCase());
  if (!actual) throw new Error(`Unknown column requested by Ollama: ${value}`);
  return quoteIdentifier(actual);
 };
 const action = p.operation;
 if (!['count','list','aggregate'].includes(action)) throw new Error('Only count, list, and aggregate read-only operations are supported');
 let select: string;
 if (action === 'count') select = 'COUNT(*) AS total_records';
 else if (action === 'aggregate') {
  const fun = String(p.aggregate?.function || '').toUpperCase();
  if (!['SUM','AVG','MIN','MAX','COUNT'].includes(fun)) throw new Error('Unsupported aggregate');
  select = `${fun}(${col(p.aggregate?.column)}) AS aggregate_result`;
 } else {
  const selected = Array.isArray(p.columns) ? p.columns : [];
  select = selected.length ? selected.slice(0,20).map(col).join(', ') : '*';
  if(p.distinct===true)select='DISTINCT '+select;
 }
 const where: string[] = [];
 if (p.filters !== undefined) {
  if (!Array.isArray(p.filters) || p.filters.length > 5) throw new Error('Too many filters');
  for (const f of p.filters) {
   const field = col(f?.column);
   const op = f?.operator;
   if (!['=','!=','>','>=','<','<=','contains','starts_with'].includes(op)) throw new Error('Unsafe filter operator');
   if (f.value == null) {
    if (op !== '=' && op !== '!=') throw new Error('Unsupported NULL comparison');
    where.push(`${field} IS ${op === '!=' ? 'NOT ' : ''}NULL`);
   } else if (op === 'contains' || op === 'starts_with') {
    if (typeof f.value !== 'string') throw new Error('Text filter expected');
    const v = safeSqlValue(f.value);
    where.push(`${field} LIKE ${op === 'contains' ? `CONCAT('%', ${v}, '%')` : `CONCAT(${v}, '%')`}`);
   } else where.push(`${field} ${op} ${safeSqlValue(f.value)}`);
  }
 }
 let sql = `SELECT ${select} FROM ${quotedTable(table)}`;
 if (where.length) sql += ` WHERE ${where.join(' AND ')}`;
 if (action === 'list') {
  if (p.orderBy != null) {
   const ordering = p.orderBy as Record<string, unknown>;
   if (!ordering || typeof ordering !== 'object') throw new Error('Invalid ORDER BY');
   const direction = String(ordering.direction || 'ASC').toUpperCase();
   if (!['ASC','DESC'].includes(direction)) throw new Error('Unsafe ORDER BY direction');
   sql += ` ORDER BY ${col(ordering.column)} ${direction}`;
  }
  const n = Number(p.limit);
  const limit = Number.isInteger(n) && n > 0 ? Math.min(n,maxRows()) : Math.min(maxRows(),20);
  sql += ` LIMIT ${limit}`;
 }
 return sql + ';';
}

export async function translateNaturalLanguage(
 question: string,
 queryMetadata: SqlExecutor,
 generatePlan: PlanGenerator
): Promise<SqlTranslation> {
 if (typeof question !== 'string' || question.length > 4000 || !question.trim()) throw new Error('Invalid database question');
 if (MUTATING_INTENT.test(question)) throw new Error('English-to-SQL supports read-only questions only. Direct SQL mode is unchanged.');
 const table = namedTable(question);
 if (!table) throw new Error('Please name the table in your question (for example, "How many records are in contxt_oi_assoc?").');
 const quoted = quotedTable(table);
 if (countIntent(question) && !/\b(?:where|whose|having|with|matching|filter|group|per|by|for each|only|distinct|unique)\b/i.test(question)) {
  return {sql:`SELECT COUNT(*) AS total_records FROM ${quoted};`,method:'deterministic'};
 }
 if (listIntent(question) && !/\b(?:latest|newest|oldest|last|where|whose|matching|filter|sorted|order|by|group|distinct|unique|with)\b/i.test(question)) {
  return {sql:`SELECT * FROM ${quoted} LIMIT ${desiredLimit(question)};`,method:'deterministic'};
 }
 // Only query metadata for the named table; never join other tables on an LLM guess.
 const names = table.split('.');
 const tbl = names[names.length-1];
 const whereSchema = names.length === 2 ? `TABLE_SCHEMA = '${names[0]}'` : 'TABLE_SCHEMA = DATABASE()';
 const infoSql = `SELECT COLUMN_NAME AS column_name FROM information_schema.columns WHERE ${whereSchema} AND TABLE_NAME = '${tbl}' ORDER BY ORDINAL_POSITION;`;
 const metadata = await queryMetadata(infoSql);
 const columns = extractColumnNames(metadata);
 if (!columns.length) throw new Error(`Could not verify columns for ${table} via DBAgent. No speculative SQL was executed. Try a simple count or first-N records question.`);
 const plan = await generatePlan(question,table,columns);
 validatePlanIntent(plan,question,columns);
 return {sql:compileReadOnlyPlan(plan,table,columns),method:'ollama-plan'};
}
