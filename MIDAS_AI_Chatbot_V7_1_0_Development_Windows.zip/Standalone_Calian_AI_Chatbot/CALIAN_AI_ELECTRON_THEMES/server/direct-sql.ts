/**
 * CALIAN-only adapter to the existing REQA MCP execute_sql tool.
 * No modifications to REQA, Fouad's SQL agent, Ollama or its configuration.
 * Requires Docker CLI and a running reqa-api container on this computer.
 */
import { spawn } from 'node:child_process';

export type DbInputType = 'sql' | 'unsafe' | 'question';

/**
 * Spoken instructions can start with "Select" but are NOT SQL statements.
 * Example: "Select 10 records from the table contxt_oi_assoc".
 * Classify those as English before passing anything to REQA execute_sql.
 * Literal SQL continues through the original read-only validator unchanged.
 */
function spokenSelectInstruction(value: string): boolean {
  const text = value.trim();
  // A number + a row noun is an English instruction, not an SQL projection.
  // SQL such as SELECT 10 FROM foo or SELECT COUNT(*) FROM foo is unaffected.
  const quantity = '(?:\\d{1,4}|one|two|three|four|five|six|seven|eight|nine|ten|twenty|thirty|forty|fifty|hundred)';
  const rowWord = '(?:records?|rows?|entries?|items?)';
  const prefix = '(?:(?:me|the|all|any|some|first|top|last|latest)\\s+)*';
  // Whisper often inserts quantitative qualifiers before the row count:
  // "Select a maximum of ten records ...", "Select no more than 10 rows ...".
  // These are *instructions*, not SQL, even though they start with SELECT.
  const spokenLimitModifier = '(?:(?:maximum|max|minimum|min)\\s+(?:of\\s+)?|(?:up\\s+to|at\\s+most|no\\s+more\\s+than|not\\s+more\\s+than|exactly)\\s+)';
  const spokenIntro = '(?:(?:me|the|all|any|some|a|an|only|just|first|top|last)\\s+)*';
  if (new RegExp('^select\\s+' + spokenIntro + spokenLimitModifier + quantity + '\\s+' + rowWord + '\\b', 'i').test(text)) return true;
  if(new RegExp('^select\\s+'+prefix+'(?:'+quantity+'\\s+)?'+rowWord+'\\b','i').test(text)) return true;
  if(/^select\s+(?:me\s+)?(?:the\s+)?(?:first|last|top|latest)\s+(?:\d+|one|two|three|five|ten)\s+(?:records?|rows?|entries?)\b/i.test(text)) return true;
  if(/^select\s+(?:me\s+)?(?:all\s+)?(?:data|information|everything)\s+from\s+(?:the\s+)?(?:table|database)\b/i.test(text)) return true;
  if(/^select\s+(?:the\s+)?(?:number|count)\s+of\s+(?:records?|rows?)\b/i.test(text)) return true;
  return false;
}

export function classifyDbInput(text: string): DbInputType {
  const trimmed = text.trimStart();
  if (/^SELECT\b/i.test(trimmed)) return spokenSelectInstruction(trimmed) ? 'question' : 'sql';
  // A real CTE starts "WITH name AS ( ..."; spoken "with ..." stays English.
  if (/^WITH\s+(?:RECURSIVE\s+)?[`"\w]+\s*(?:\([^)]*\)\s*)?AS\s*\(/i.test(trimmed)) return 'sql';
  if (/^(?:INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|TRUNCATE|REPLACE|GRANT|REVOKE|CALL|EXEC|EXECUTE|LOAD|SET|USE|DESCRIBE|DESC|EXPLAIN|SHOW\s+(?:TABLES?|DATABASES?|COLUMNS?|INDEX(?:ES)?|CREATE|FULL|STATUS|VARIABLES|PROCESSLIST|GRANTS|ENGINES))\b/i.test(trimmed)) return 'unsafe';
  return 'question';
}

// Static, pre-reviewed code. SQL data is sent to stdin, never interpolated into shell arguments.
// sqlglot is available in reqa-api because the existing MCP module imports it.
const PYTHON_SQL = String.raw`
import sys, json, asyncio
import sqlglot
from sqlglot import exp
from mcp_servers.database_server import call_tool

def fail(message):
    print(json.dumps({'success': False, 'rows': [], 'error': str(message)}))

try:
    request = json.loads(sys.stdin.read(7000))
    sql = request.get('sql', '')
    selected_database = request.get('database', '')
    if not isinstance(sql, str) or not sql.strip() or len(sql) > 6000:
        raise ValueError('SQL must be between 1 and 6000 characters')
    if not isinstance(selected_database, str) or (selected_database and not __import__('re').fullmatch(r'[A-Za-z_][A-Za-z_0-9]{0,127}', selected_database)):
        raise ValueError('Invalid selected database name')
    statements = sqlglot.parse(sql, read='mysql')
    if len(statements) != 1 or statements[0] is None:
        raise ValueError('Exactly one SQL statement is required')
    tree = statements[0]
    if not isinstance(tree, exp.Select):
        raise ValueError('Only a read-only SELECT statement is allowed')
    if not selected_database:
        for table in tree.find_all(exp.Table):
            # Without a chosen schema, refuse an unqualified table; REQA may
            # have multiple databases with the same name, risking a wrong read.
            if not table.db:
                raise ValueError('Please select the database or use a schema-qualified table reference. No SQL was executed.')
    if selected_database:
        for table in tree.find_all(exp.Table):
            if '.' in str(table.name):
                raise ValueError('Quote database and table separately using MySQL identifier quotes.')
            explicit_db = str(table.db or '')
            if explicit_db and explicit_db.lower() != selected_database.lower() and explicit_db.lower() != 'information_schema':
                raise ValueError('The query references a database different from the selected schema. Select it explicitly first.')
            if not explicit_db and str(table.name).lower() != 'database':
                table.set('db', exp.to_identifier(selected_database))
        sql = tree.sql(dialect='mysql')
    forbidden = {'Into','Lock','Insert','Update','Delete','Create','Drop','Alter','Command',
                 'Merge','Grant','Revoke','TruncateTable','Transaction','Commit','Rollback',
                 'Set','Use','LoadData','Execute','ExecuteAs','Declare','SetItem',
                 'SessionParameter','Parameter','Var','Variable'}
    safe_functions = {'Count','Sum','Min','Max','Avg','Coalesce','Lower','Upper','Round',
                      'Length','Substring','Concat','Cast','Date','Year','Month','Day',
                      'If','IfNull','Abs','Ceil','Floor','Trim','LTrim','RTrim','Nullif'}
    for node in tree.walk():
        name = type(node).__name__
        if name in forbidden:
            raise ValueError('SQL contains an operation forbidden in read-only mode: '+name)
        # sqlglot represents boolean operators as Func nodes in some versions.
        # AND/OR/NOT are safe SQL predicates, not database functions.
        if isinstance(node, (exp.And, exp.Or, exp.Not)):
            continue
        if isinstance(node, exp.Func) and name not in safe_functions:
            # DATABASE() reveals only the active schema for this same connection.
            # Permit that exact zero-argument function, not arbitrary functions.
            current_database = (name in ('Database', 'CurrentDatabase') or
                (name == 'Anonymous' and getattr(node, 'name', '').lower() == 'database'))
            if not (current_database and not list(node.iter_expressions())):
                raise ValueError('SQL function not allowed in read-only mode: '+name)
    result = asyncio.run(call_tool('execute_sql', {'sql': sql, 'max_rows': 1000}))
    if not result:
        raise RuntimeError('Database tool returned no result')
    payload = json.loads(result[0].text)
    if not isinstance(payload, dict) or not isinstance(payload.get('success'), bool):
        raise RuntimeError('Unexpected database tool response')
    print(json.dumps(payload, default=str))
except Exception as exc:
    fail(exc)
`;

export type DirectSqlResult = { success: boolean; rows: unknown[]; error: string };
export function executeReadOnlySql(sql: string, selectedDatabase?: string): Promise<DirectSqlResult> {
  if (classifyDbInput(sql) !== 'sql') {
    return Promise.resolve({success: false, rows: [], error: 'Use exactly one SELECT statement for direct SQL execution'});
  }
  if (sql.length > 6000) {
    return Promise.resolve({success: false, rows: [], error: 'SQL exceeds the 6000-character limit'});
  }
  const container = process.env.CALIAN_SQL_DOCKER_CONTAINER || 'reqa-api';
  // Allow only a simple Docker container name, never user-supplied CLI flags.
  if (!/^[a-zA-Z][a-zA-Z0-9_.-]{0,127}$/.test(container)) {
    return Promise.reject(new Error('Invalid CALIAN_SQL_DOCKER_CONTAINER setting'));
  }
  return new Promise((resolve, reject) => {
    const child = spawn('docker', ['exec', '-i', container, 'python', '-c', PYTHON_SQL],
      {stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true, shell: false});
    let stdout = '';
    let stderr = '';
    let settled = false;
    const finish = (error?: Error, result?: DirectSqlResult) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (error) reject(error); else resolve(result!);
    };
    const timer = setTimeout(() => {
      child.kill();
      finish(new Error('REQA database execution timed out after 60 seconds'));
    }, 60000);
    child.stdout.on('data', chunk => {
      stdout += chunk.toString();
      if (stdout.length > 5_000_000) {
        child.kill();
        finish(new Error('REQA returned too much data. Reduce the SQL LIMIT.'));
      }
    });
    child.stderr.on('data', chunk => { stderr = (stderr + chunk.toString()).slice(-2000); });
    child.on('error', error => finish(new Error(`Cannot start Docker CLI: ${error.message}`)));
    child.on('close', code => {
      if (settled) return;
      if (code !== 0) return finish(new Error(`REQA execute_sql exited with code ${code}: ${stderr}`));
      try {
        const last = stdout.trim().split(/\r?\n/).filter(Boolean).at(-1) || '';
        const parsed = JSON.parse(last);
        if (typeof parsed.success !== 'boolean' || !Array.isArray(parsed.rows)) throw new Error('Invalid database result format');
        finish(undefined, {success: parsed.success, rows: parsed.rows, error: String(parsed.error || '')});
      } catch (error) {
        finish(new Error(`Cannot decode REQA SQL result: ${error instanceof Error ? error.message : String(error)}; ${stderr.slice(-300)}`));
      }
    });
    child.stdin.on('error', () => {}); // Errors surface through close/error handlers.
    child.stdin.end(JSON.stringify({sql,database:selectedDatabase||''}));
  });
}
