// node --experimental-strip-types server/test-v6.mjs (requires Node 22+)
import assert from 'node:assert/strict';
import {buildOriginalA2aMessage,dbSqlOnlyContext} from './db-a2a-dispatch.ts';
const sql='SELECT * FROM `contxt_oi_assoc` LIMIT 10;';
const agent='DBAgent'; const id='test-context';
const context={userContext:'test',taskContext:'',systemInstructions:'',conversationHistory:[],agentResults:[]};
const direct=buildOriginalA2aMessage(agent,sql,id,context);
assert.deepEqual({...direct,id:'fixed',params:{message:{...direct.params.message,messageId:'fixed'}}},
 {jsonrpc:'2.0',id:'fixed',method:'message/send',params:{message:{role:'user',messageId:'fixed',contextId:id,parts:[{kind:'text',text:sql}],metadata:{agent_id:agent,context}}}});
const translated=buildOriginalA2aMessage(agent,sql,'new-id',dbSqlOnlyContext(sql));
assert.equal(translated.method,direct.method);
assert.deepEqual(translated.params.message.parts,direct.params.message.parts);
assert.equal(translated.params.message.metadata.agent_id,direct.params.message.metadata.agent_id);
assert.deepEqual(translated.params.message.metadata.context.conversationHistory,[{role:'user',content:sql}]);
assert.notEqual(translated.params.message.contextId,direct.params.message.contextId);
console.log('PASS: original direct-SQL A2A payload preserved; English SQL shares the same dispatcher.');
