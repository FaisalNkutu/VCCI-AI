import { strict as assert } from 'node:assert';
import { discoverTables,clearSchemaCache,schemaAwareTranslate } from './schema-aware-sql.ts';
import { speechSummary } from '../src/app/result-speech.ts';
const schema='vcci_aug_26_dbg_1';
const seen=[];
const db=async sql=>{
 seen.push(sql);
 if(sql.includes('INFORMATION_SCHEMA.TABLES'))return {success:true,rows:[
  {schema_name:schema,table_name:'contxt_oi_assoc'},
  {schema_name:schema,table_name:'contxt_assoc'}
 ],error:''};
 if(sql.includes('INFORMATION_SCHEMA.COLUMNS'))return {success:true,rows:[{column_name:'created_at'},{column_name:'cat_code'}],error:''};
 return {success:true,rows:[],error:''};
};
clearSchemaCache();
const plan=async()=>{throw new Error('A simple query must not invoke Ollama')};
const list=await schemaAwareTranslate('Show me ten records from the context O I association table',db,plan);
assert.equal(list.sql,`SELECT * FROM \`${schema}\`.\`contxt_oi_assoc\` LIMIT 10;`);
const count=await schemaAwareTranslate('How many records are in the context O I association table?',db,plan);
assert.equal(count.sql,`SELECT COUNT(*) AS total_records FROM \`${schema}\`.\`contxt_oi_assoc\`;`);
assert.equal(seen.filter(q=>q.includes('INFORMATION_SCHEMA.TABLES')).length,1);
await assert.rejects(schemaAwareTranslate('Delete all records from contxt_oi_assoc',db,plan),/read-only/);
assert.match(speechSummary({rows:[{total_records:253}]},''),/253 matching records/);
assert.match(speechSummary({rows:[{cat_code:'A'},{cat_code:'B'},{cat_code:'C'},{cat_code:'D'}]},'',10),/Record 4/);
console.log('PASS: dynamic schema lookup, spoken table matching, limits, counts, safety, cached metadata and speech summaries');
