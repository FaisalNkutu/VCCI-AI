import {isDatabaseRetrievalRequest} from './db-intent';

/** Conservative automatic conversational route; unknown or operational requests use existing routing. */
export function naturalVoiceRoute(text:string,previousAgentId:string|null):boolean {
 const q=text.trim();
 if(!q||isDatabaseRetrievalRequest(q)||/\d\s*[+*/=−×÷-]\s*\d/.test(q))return false;
 // Keep operational and specialized requests on their existing paths, even in conversation.
 if(/\b(?:midas|dashboard|database|sql|schema|dbagent|table|records?|rows?|agent|translate|translation|transcribe|transcription|dice|roll|calculate|compute|arithmetic|multiply|divide|subtract|add|percent|json|xml|csv|structured|social media|linkedin|report|analy[sz]e|compare|export|upload|download|execute|run|navigate|select|deselect|switch|configure|set|change|delete|update|insert|create|code|script|file|endpoint|api|video|call|meeting|combat power|entity|entities|time range|time format|statistics|metrics|chart)\b/i.test(q))return false;
 if(/^(?:hi|hello|hey|good (?:morning|afternoon|evening)|thanks|thank you|yes|no|okay|ok|sure|exactly|indeed|interesting|i agree|i disagree)(?:[.!?, ]|$)/i.test(q))return true;
 if(/^(?:(?:start |please |can you |could you )*(?:talk(?:ing)?|speak(?:ing)?|chat(?:ting)?) (?:to|with) me|(?:tell me|talk about|speak about|explain|what (?:do you think|is|are|does|makes)|why|how (?:are you|do you|does|can|is|are)|who (?:is|was|are)|would you|do you|can we|could we)\b)/i.test(q))return true;
 // Short conversational continuations only after the local assistant answered.
 return previousAgentId==='local-ollama' && /^(?:and\b|but\b|what about\b|how about\b|go on\b|continue\b|tell me more\b|say more\b|please continue\b|i (?:think|feel|mean|believe|wonder|said|like|don't|do not)\b|that\b|it\b|this\b)/i.test(q);
}

/** Wake phrase must lead the utterance; it is not speaker authentication. */
export function stripVoiceWake(text:string):string|null {
 const match=text.trim().match(/^(?:hey|okay|ok)[,\s]+(?:ai\s+)?chat\s*bot\b[\s,.:!\-]*(.*)$/i);
 return match?match[1].trim():null;
}

export const NATURAL_VOICE_SYSTEM='You are a friendly conversational assistant speaking aloud. Respond directly to the user in natural, concise language (usually 1–3 sentences). Maintain the conversational topic and interpret metaphors as metaphors when appropriate. Do not turn casual dialogue into a task plan, requirements analysis, or agent-routing explanation. If something is unclear, ask one short clarifying question. You have no tools in this mode; never claim to have executed a database query, MIDAS action, or external operation.';

export function naturalVoiceMessages(message:string,context:any):{role:string;content:string}[]{
 // No tool results or MIDAS snapshots are sent by the dedicated conversational path.
 const history=Array.isArray(context?.conversationHistory)?context.conversationHistory.slice(-12):[];
 const safe=history.filter((t:any)=>['user','assistant'].includes(t?.role)&&typeof t.content==='string').map((t:any)=>({role:t.role as string,content:t.content.slice(0,2000)}));
 // A client may already have appended the current turn. Send it only once.
 if(safe.at(-1)?.role==='user'&&safe.at(-1)?.content===message)safe.pop();
 const system=[NATURAL_VOICE_SYSTEM,typeof context?.systemInstructions==='string'?context.systemInstructions.slice(0,4000):'',typeof context?.userContext==='string'&&context.userContext?`User context: ${context.userContext.slice(0,2000)}`:''].filter(Boolean).join('\n');
 return [{role:'system',content:system},...safe,{role:'user',content:message}];
}
