import {Component, ElementRef, ViewChild, OnDestroy, ChangeDetectorRef, NgZone, ViewEncapsulation} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {Room, RoomEvent, Track, type RemoteParticipant, type RemoteTrack} from 'livekit-client';

interface GroupGuest {id:string;name:string}
interface ManagedGroup {
 id:string; name:string; invite:string; expires:string; status:string; error:string;
 pending:GroupGuest[]; admitted:GroupGuest[]; participants:number;
 ws:WebSocket|null; room:Room|null; connected:boolean; published:boolean;
 closed:boolean; ticketTimer:ReturnType<typeof setTimeout>|null;
}

/** Several independent host signaling/LiveKit rooms, one deliberately on-air at a time.
 * All remote media is detached when its room is not selected. One-to-one calls use
 * the original VideoCenterComponent and are intentionally not changed here. */
@Component({selector:'app-group-meetings',standalone:true,imports:[CommonModule,FormsModule],templateUrl:'./group-meetings.component.html',styleUrl:'./group-meetings.component.scss',encapsulation:ViewEncapsulation.None})
export class GroupMeetingsComponent implements OnDestroy {
 @ViewChild('hostPreview') hostPreview?:ElementRef<HTMLVideoElement>;
 @ViewChild('remoteTiles') remoteTiles?:ElementRef<HTMLDivElement>;
 readonly maxOpenGroups=10;
 rooms:ManagedGroup[]=[]; selectedId=''; newName=''; busy=false; error=''; notice='';
 audioMuted=false; cameraMuted=false; private stream:MediaStream|null=null;
 private publishing:Promise<void>=Promise.resolve();
 constructor(private zone:NgZone,private cdr:ChangeDetectorRef){}
 get current():ManagedGroup|undefined{return this.rooms.find(g=>g.id===this.selectedId);}
 get pendingTotal():number{return this.rooms.reduce((n,g)=>n+g.pending.length,0);}
 trackById(_index:number,g:ManagedGroup){return g.id;}
 private describe(e:unknown):string{return e instanceof Error?e.message:String(e);}
 private async ensureMedia(){
  if(this.stream?.active)return;
  if(!navigator.mediaDevices?.getUserMedia)throw Error('Camera and microphone require the installed desktop app or HTTPS.');
  this.stream=await navigator.mediaDevices.getUserMedia({video:{width:{ideal:960},height:{ideal:540}},audio:{echoCancellation:true,noiseSuppression:true}});
  this.audioMuted=false;this.cameraMuted=false;
 }
 async createGroup(){
  if(this.busy||this.rooms.length>=this.maxOpenGroups)return;
  const name=this.newName.trim().replace(/[\r\n\x00-\x1f\x7f]/g,' ').slice(0,70);
  if(!name){this.error='Enter a meeting name (e.g. Engineering Team).';return;}
  this.busy=true;this.error='';
  try{
   // Obtain permission before creating a room, so a denied camera does not leak a meeting.
   await this.ensureMedia();
   const response=await fetch('/api/video/rooms',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode:'group',name})});
   const data=await response.json();
   if(!response.ok)throw Error(data.error||`Meeting gateway HTTP ${response.status}`);
   if(data.mode!=='group'||data.maxParticipants!==10||typeof data.roomId!=='string'||typeof data.wsUrl!=='string'||typeof data.hostTicket!=='string'||typeof data.inviteUrl!=='string'){
    throw Error('The video gateway did not create a LiveKit group room. Restart the updated VIDEO_CALL_SERVICE and check /health.');
   }
   const g:ManagedGroup={id:data.roomId,name,invite:data.inviteUrl,expires:data.expiresAt,status:'Connecting signaling…',error:'',pending:[],admitted:[],participants:0,ws:null,room:null,connected:false,published:false,closed:false,ticketTimer:null};
   this.rooms.push(g);this.newName='';this.selectGroup(g.id);
   this.openSignaling(g,data.wsUrl,data.hostTicket);
   this.notice=`Created ${name}. Each meeting has a separate invitation.`;
  }catch(e){this.error=this.describe(e);if(!this.rooms.length)this.stopMedia();}
  finally{this.busy=false;}
 }
 private openSignaling(g:ManagedGroup,url:string,hostTicket:string){
  const ws=new WebSocket(url);g.ws=ws;
  ws.onopen=()=>{if(g.closed){ws.close();return;}ws.send(JSON.stringify({type:'auth',ticket:hostTicket}));};
  ws.onmessage=(e)=>this.zone.run(()=>{
   if(g.closed)return;
   try{void this.handleSignal(g,JSON.parse(e.data)).catch(err=>{g.error=this.describe(err);g.status='LiveKit connection failed';});}
   catch(err){g.error='Invalid signaling response: '+this.describe(err);}
  });
  ws.onerror=()=>this.zone.run(()=>{if(!g.closed)g.error='Public signaling connection failed. Check the gateway HTTPS/WebSocket address.';});
  ws.onclose=()=>this.zone.run(()=>{if(!g.closed){g.status='Signaling disconnected';g.error='Room cannot admit new guests until its gateway connection is restored. End this room and create a new one.';}});
 }
 private send(g:ManagedGroup,payload:unknown){if(g.ws?.readyState===WebSocket.OPEN)g.ws.send(JSON.stringify(payload));else g.error='The room signaling connection is not open.';}
 private clearTicketTimer(g:ManagedGroup){if(g.ticketTimer){clearTimeout(g.ticketTimer);g.ticketTimer=null;}}
 private async handleSignal(g:ManagedGroup,m:any){
  if(m.type==='ready'){
   if(m.mode!=='group'||m.mediaProvider!=='livekit')throw Error('This gateway is not in LiveKit group mode. Deploy the updated VIDEO_CALL_SERVICE.');
   g.status='Waiting for LiveKit credentials…';this.clearTicketTimer(g);
   g.ticketTimer=setTimeout(()=>this.zone.run(()=>{if(!g.closed&&!g.room)g.error='No LiveKit group-join credentials arrived. Verify VIDEO_LIVEKIT_URL and API credentials on the running public gateway.';}),12000);
  }
  if(m.type==='group-join'){
   this.clearTicketTimer(g);await this.connectLivekit(g,m.url,m.token);
  }
  if(m.type==='waiting'&&typeof m.guestId==='string'&&!g.pending.some(x=>x.id===m.guestId)){
   g.pending.push({id:m.guestId,name:String(m.name||'Guest')});
   this.notice=`${g.name}: someone is waiting for admission.`;
  }
  if(m.type==='admitted'){
   g.pending=g.pending.filter(x=>x.id!==m.guestId);
   if(typeof m.guestId==='string'&&!g.admitted.some(x=>x.id===m.guestId))g.admitted.push({id:m.guestId,name:String(m.name||'Guest')});
   g.status='Guest admitted. Waiting for participant media…';
  }
  if(m.type==='guest-left'){
   g.pending=g.pending.filter(x=>x.id!==m.guestId);g.admitted=g.admitted.filter(x=>x.id!==m.guestId);
   if(g.connected)g.status='LiveKit room connected';
  }
  if(m.type==='ended'){this.endGroup(g,false);}
  if(m.type==='error')g.error=String(m.error||'Gateway signaling error');
 }
 private async connectLivekit(g:ManagedGroup,url:unknown,token:unknown){
  if(g.room||g.closed)return;
  if(typeof url!=='string'||!/^wss:\/\/[^/?#]+$/.test(url)||typeof token!=='string'||!token)throw Error('Invalid LiveKit credentials.');
  const room=new Room({adaptiveStream:true,dynacast:true});g.room=room;
  room.on(RoomEvent.TrackSubscribed,(track,_pub,participant)=>this.zone.run(()=>{if(this.selectedId===g.id)this.addRemote(track,participant);}));
  room.on(RoomEvent.TrackUnsubscribed,track=>{for(const e of track.detach())e.remove();});
  room.on(RoomEvent.ParticipantConnected,()=>this.zone.run(()=>{g.participants=room.remoteParticipants.size+1;}));
  room.on(RoomEvent.ParticipantDisconnected,()=>this.zone.run(()=>{g.participants=room.remoteParticipants.size+1;if(this.selectedId===g.id)this.renderRemotes(g);}));
  room.on(RoomEvent.Disconnected,()=>this.zone.run(()=>{if(!g.closed){g.connected=false;g.published=false;g.status='LiveKit media disconnected';g.error='Check LiveKit connectivity or the gateway participant token.';}}));
  try{
   await room.connect(url,token);
   if(g.closed){void room.disconnect();return;}
   g.connected=true;g.participants=room.remoteParticipants.size+1;g.status='LiveKit connected';g.error='';
   await this.queuePublishing();
  }catch(e){void room.disconnect();g.room=null;g.connected=false;throw Error(`LiveKit connection failed for ${g.name}: ${this.describe(e)}`);}
 }
 selectGroup(id:string){
  const g=this.rooms.find(x=>x.id===id);if(!g)return;
  if(this.selectedId!==id){this.clearRemoteElements();this.selectedId=id;}
  this.cdr.detectChanges();
  if(this.hostPreview)this.hostPreview.nativeElement.srcObject=this.stream;
  this.renderRemotes(g);
  void this.queuePublishing().catch(e=>this.zone.run(()=>this.error=this.describe(e)));
 }
 /** Serialize track movement: the host publishes ONLY to the selected meeting.
  * Other rooms remain connected for admission/guests, but host camera/mic are never
  * broadcast simultaneously across rooms. */
 private queuePublishing():Promise<void>{
  this.publishing=this.publishing.catch(()=>{}).then(async()=>{
   const stream=this.stream;
   for(const g of this.rooms){
    if(!g.room||!g.connected||g.closed)continue;
    if(g.published&&g.id!==this.selectedId){
     for(const t of stream?.getTracks()||[])await g.room.localParticipant.unpublishTrack(t,false);
     g.published=false;
    }
   }
   const current=this.current;
   if(current?.connected&&current.room&&!current.published&&stream){
    for(const t of stream.getTracks())await current.room.localParticipant.publishTrack(t,{source:t.kind==='video'?Track.Source.Camera:Track.Source.Microphone});
    current.published=true;
    current.status='LiveKit connected · Host on air';
   }
  });return this.publishing;
 }
 private clearRemoteElements(){
  const previous=this.rooms.find(x=>x.id===this.selectedId);
  if(previous?.room)for(const p of previous.room.remoteParticipants.values()){
   for(const pub of p.trackPublications.values())if(pub.track)for(const node of pub.track.detach())node.remove();
  }
  this.remoteTiles?.nativeElement.replaceChildren();
 }
 private renderRemotes(g:ManagedGroup){
  this.clearRemoteElements();if(this.selectedId!==g.id||!g.room)return;
  for(const p of g.room.remoteParticipants.values()){
   for(const pub of p.trackPublications.values())if(pub.track)this.addRemote(pub.track,p);
  }
 }
 private addRemote(track:RemoteTrack,p:RemoteParticipant){
  const root=this.remoteTiles?.nativeElement;if(!root||this.selectedId==='')return;
  let tile=Array.from(root.children).find(el=>el.getAttribute('data-participant')===p.identity) as HTMLDivElement|undefined;
  if(!tile){tile=document.createElement('div');tile.className='mg-participant';tile.setAttribute('data-participant',p.identity);
   const name=document.createElement('small');name.textContent=p.name||'Participant';tile.appendChild(name);root.appendChild(tile);}
  const element=document.createElement(track.kind===Track.Kind.Video?'video':'audio');
  element.autoplay=true;if(element instanceof HTMLVideoElement){element.playsInline=true;element.className='mg-remote-video';}
  track.attach(element);tile.appendChild(element);
 }
 admit(g:ManagedGroup,id:string){this.send(g,{type:'admit',guestId:id});}
 deny(g:ManagedGroup,id:string){this.send(g,{type:'deny',guestId:id});g.pending=g.pending.filter(x=>x.id!==id);}
 remove(g:ManagedGroup,id:string){this.send(g,{type:'remove',guestId:id});}
 async copy(g:ManagedGroup){try{await navigator.clipboard.writeText(g.invite);this.notice=`Copied invitation for ${g.name}.`;}catch{this.notice='Select the invitation URL and copy it manually.';}}
 toggleMute(){for(const t of this.stream?.getAudioTracks()||[])t.enabled=!t.enabled;this.audioMuted=!(this.stream?.getAudioTracks()[0]?.enabled??false);}
 toggleCamera(){for(const t of this.stream?.getVideoTracks()||[])t.enabled=!t.enabled;this.cameraMuted=!(this.stream?.getVideoTracks()[0]?.enabled??false);}
 async enableAudio(){try{await this.current?.room?.startAudio();this.notice='Sound enabled for the selected room.';}catch(e){this.error=this.describe(e);}}
 endGroup(g:ManagedGroup,notify=true){
  if(g.closed)return;
  if(notify)this.send(g,{type:'end'});
  g.closed=true;this.clearTicketTimer(g);
  g.ws?.close();g.ws=null;
  g.room?.disconnect();g.room=null;
  this.rooms=this.rooms.filter(x=>x!==g);
  if(this.selectedId===g.id){this.clearRemoteElements();this.selectedId='';const next=this.rooms[0];if(next)this.selectGroup(next.id);}
  if(!this.rooms.length){this.stopMedia();this.notice='All your hosted meetings have ended.';}
 }
 endAll(){for(const g of [...this.rooms])this.endGroup(g);}
 private stopMedia(){this.stream?.getTracks().forEach(t=>t.stop());this.stream=null;if(this.hostPreview)this.hostPreview.nativeElement.srcObject=null;}
 ngOnDestroy(){this.endAll();}
}
