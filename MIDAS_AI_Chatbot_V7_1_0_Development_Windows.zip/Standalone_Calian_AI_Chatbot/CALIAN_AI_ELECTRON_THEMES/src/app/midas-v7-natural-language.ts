import type { MidasContext, MidasRequest } from './midas-bridge';
/** V7 bounded natural-language interpreter. Always produces a proposal, never executes. */
export type IntentResult = {kind:'proposal';request:MidasRequest;confidence:1;description:string}|
 {kind:'needs-input';message:string}|{kind:'not-supported';message:string};
const dashboards: Record<string,string>={
 'summary':'summary','overview':'summary','home dashboard':'summary','h hour':'h-hour',
 'rate of movement':'rom','movement rate':'rom','rom':'rom','control measures':'cm',
 'cm occupations':'cm','control measure occupations':'cm','cm':'cm',
 'picture of enemy':'poe','poe':'poe','enemy picture':'poe',
 'fratricide':'fratricide','friendly fire':'fratricide','enemy engagement':'enemy-engagement',
 'enemy engagements':'enemy-engagement','combat power':'cp','cp':'cp',
 'entity watch':'unit-watch','unit watch':'unit-watch','holdings rollup':'holdings-rollup',
 'c2 compare':'c2','c2 comparison':'c2'};
const clean=(s:string)=>s.normalize('NFKC').trim().toLowerCase().replace(/[.!?]+$/,'').replace(/\s+/g,' ')
 .replace(/^(?:please\s+|could you\s+|can you\s+|would you\s+|i want you to\s+|i would like to\s+)/,'');
const done=(request:MidasRequest,description:string):IntentResult=>({kind:'proposal',request,confidence:1,description});
export function interpretV7Action(raw:string,context:MidasContext|null):IntentResult {
 if(typeof raw!=='string'||raw.length>240)return {kind:'not-supported',message:'Command must be 1–240 characters.'};
 const s=clean(raw);
 if(!s)return {kind:'needs-input',message:'Describe a dashboard or one approved MIDAS control change.'};
 const nav=s.match(/^(?:open|show(?: me)?|display|view|go to|switch to|navigate to|take me to|bring up)(?: the)? (.+?)(?: (?:dashboard|screen|view|page))?$/);
 if(nav){const id=dashboards[nav[1]];if(id)return done({action:'navigate',params:{dashboard:id}},`Open ${nav[1]} in MIDAS after approval.`);
  return {kind:'not-supported',message:'Unknown dashboard. Use an available MIDAS navigation label.'};}
 const time=s.match(/^(?:set|change|update)(?: the)?(?: combat power)?(?: time)?(?: range| timeframe| time range| time frame) (?:from )?(\d+(?:\.\d+)?) (?:to|through|until|-) (\d+(?:\.\d+)?)$/);
 if(time){
  const start=Number(time[1]),end=Number(time[2]);
  const bounds=context?.timeBounds || context?.cpTimeBounds;
  const route=context?.route;
  if(!route||!['/advmetrics/cp','/advmetrics/rom','/advmetrics/cm'].includes(route))return {kind:'needs-input',message:'Open Combat Power, Rate of Movement or CM Occupations first.'};
  if(!bounds||start<bounds.min||end>bounds.max||start>=end)return {kind:'needs-input',message:'Requested time range is invalid or not covered by the current MIDAS data.'};
  const action=route==='/advmetrics/cp'?'cp_time_range':route==='/advmetrics/rom'?'rom_time_range':'cm_time_range';
  return done({action,params:{start,end}},`Change MIDAS time range from ${start} to ${end}.`);
 }
 if(/^(?:set|change|update)(?: the)?(?: time)?(?: range| timeframe| time range| time frame)$/.test(s))return {kind:'needs-input',message:'Provide both boundaries: Set time range 10 to 30.'};
 const grouping=s.match(/^(?:group|set|change)(?: the)?(?: combat power)?(?: data)?(?: grouping)? (?:by|to) (units?|equipments?)$/);
 if(grouping){if(context?.route!=='/advmetrics/cp')return {kind:'needs-input',message:'Open Combat Power first.'};
  return done({action:'cp_grouping',params:{grouping:grouping[1].startsWith('unit')?'unit':'equipment'}},'Change Combat Power grouping.');}
 const fmt=s.match(/^(?:set|change|update)(?: the)? time format (?:to|as) (.+)$/);
 if(fmt){const value=context?.availableTimeFormats?.find(f=>f.toLowerCase()===fmt[1]);
  return value?done({action:'time_format',params:{name:value}},'Change MIDAS time format.'):
    {kind:'needs-input',message:'Select a valid MIDAS time format from the shared choices.'};}
 const entity=s.match(/^(select|deselect|unselect)(?: the)? (?:entity|unit) (.{1,70})$/);
 if(entity){if(context?.route!=='/advmetrics/cp')return {kind:'needs-input',message:'Open Combat Power first.'};
  const match=context.cpEntities?.find(e=>String(e.id)===entity[2]||e.name.toLowerCase()===entity[2]);
  return match?done({action:'cp_select_entity',params:{id:match.id,selected:entity[1]==='select'}},'Update selected Combat Power entity.'):
   {kind:'needs-input',message:'The requested entity is not available in the current MIDAS selection.'};}
 if(/^(?:select|deselect|unselect)(?: the)? (?:entity|unit)\b/.test(s))return {kind:'needs-input',message:'Specify an existing entity ID or exact available name.'};
 return {kind:'not-supported',message:'No allowlisted MIDAS action matched. Try Open Summary or Show Combat Power.'};
}
