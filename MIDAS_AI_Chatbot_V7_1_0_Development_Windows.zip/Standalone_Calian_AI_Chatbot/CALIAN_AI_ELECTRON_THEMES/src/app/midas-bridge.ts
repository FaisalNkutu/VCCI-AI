/** Explicitly approved MIDAS <-> Calian iframe protocol. Never executes arbitrary scripts. */
export const MIDAS_BRIDGE_ID = 'MIDAS_CALIAN_V1';
export type MidasAction = 'navigate' | 'time_format' | 'cp_time_range' | 'cp_select_entity' | 'cp_grouping' | 'rom_time_range' | 'cm_time_range' | 'rom_select_capture' | 'cm_select_measure';
export interface MidasContext {
  route?: string | null;
  activeDashboard?: string | null;
  selectedMenuLabel?: string | null;
  selectedMenuCommand?: string | null;
  /** Only current selected UI control values. Bounded and read-only. */
  selectedValues?: {
    timeFormat?: string;
    timeframe?: {start: number; end: number};
    grouping?: string;
    entities?: {id: number; name: string}[];
    capture?: {id: number; name: string} | null;
    selectedEntityIds?: number[];
    controlMeasures?: {id: number; name: string}[];
  };
  dataSourceConnected?: boolean;
  cpGrouping?: 'unit' | 'equipment';
  romCaptures?: {id:number;name:string}[];
  cmMeasures?: {id:number;name:string}[];
  selectedTimeFormat?: string;
  availableTimeFormats?: string[];
  cpTimeframe?: { start: number; end: number };
  cpTimeBounds?: { min: number; max: number };
  timeBounds?: { min: number; max: number };
  cpSelectedEntityIds?: number[];
  cpEntities?: { id: number; name: string }[];
}
export interface MidasRequest { action: MidasAction; params: Record<string, unknown> }
export interface MidasCapabilities { dashboards: string[]; actions: string[]; readTools?:string[]; approvalRequired: boolean }

const DISPLAY_NAMES: Record<string,string> = {
  summary:'summary', 'h-hour':'h-hour', 'rate of movement':'rom', rom:'rom',
  'picture of enemy':'poe', poe:'poe', 'control measures':'cm', 'cm occupations':'cm', cm:'cm',
  fratricide:'fratricide', 'enemy engagement':'enemy-engagement',
  'combat power':'cp', cp:'cp', 'unit watch':'unit-watch', 'entity watch':'unit-watch',
  'holdings rollup':'holdings-rollup', 'c2 compare':'c2', c2:'c2'
};
export function parseMidasCommand(raw: string, context: MidasContext | null, capabilities: MidasCapabilities | null): MidasRequest | null {
  // The MIDAS host validates every proposed action against its own allowlist.
  // A delayed capabilities handshake must not prevent a known, safe navigation
  // request from being proposed. It still requires the user to approve in MIDAS.
  const text = raw.normalize('NFKC').trim().toLowerCase().replace(/\s+/g, ' ').replace(/[.!?]+$/,'');
  if (!text || text.length > 160) return null;
  const nav = text.match(/^(?:open|show|navigate to|go to|switch to|display)(?: the)? (.+?)(?: dashboard| view| report)?$/);
  if (nav) {
    const id = DISPLAY_NAMES[nav[1].trim()];
    if (id) return { action:'navigate', params:{dashboard:id} };
  }
  const format = text.match(/^(?:set|change)(?: the)? time format to (.{1,60})$/);
  if (format) {
    const name = context?.availableTimeFormats?.find(x => x.toLowerCase() === format[1]);
    if (name) return {action:'time_format',params:{name}};
  }
  const range = text.match(/^(?:set|change)(?: the)?(?: combat power)? time (?:range|frame)(?: from| to)? (\d+(?:\.\d+)?) (?:to|through|-) (\d+(?:\.\d+)?)$/);
  if (range && context?.route === '/advmetrics/cp' && Number(range[1]) < Number(range[2]) && context.cpTimeBounds && Number(range[1]) >= context.cpTimeBounds.min && Number(range[2]) <= context.cpTimeBounds.max) return {action:'cp_time_range',params:{start:Number(range[1]),end:Number(range[2])}};
  const grouping = text.match(/^(?:set|change|group)(?: the)?(?: combat power)?(?: data)? grouping (?:to|by) (unit|equipment)s?$/);
  if (grouping && context?.route === '/advmetrics/cp') return {action:'cp_grouping',params:{grouping:grouping[1]}};
  const broaderRange = text.match(/^(?:set|change)(?: the)? (?:time range|timeframe)(?: from| to)? (\d+(?:\.\d+)?) (?:to|through|-) (\d+(?:\.\d+)?)$/);
  const availableBounds=context?.timeBounds || context?.cpTimeBounds;
  if (broaderRange && availableBounds && Number(broaderRange[1]) < Number(broaderRange[2]) && Number(broaderRange[1])>=availableBounds.min && Number(broaderRange[2])<=availableBounds.max) {
    const action=context.route==='/advmetrics/rom'?'rom_time_range':context.route==='/advmetrics/cm'?'cm_time_range':context.route==='/advmetrics/cp'?'cp_time_range':null;
    if(action) return {action,params:{start:Number(broaderRange[1]),end:Number(broaderRange[2])}};
  }
  const romCapture = text.match(/^(?:select|open|show) (?:rom )?capture (.{1,70})$/);
  if (romCapture && context?.route==='/advmetrics/rom') {
    const match=context.romCaptures?.find(v=>String(v.id)===romCapture[1]||v.name.toLowerCase()===romCapture[1]);
    if(match) return {action:'rom_select_capture',params:{id:match.id}};
  }
  const cmSelect = text.match(/^(select|deselect) (?:control measure|cm) (.{1,70})$/);
  if (cmSelect && context?.route==='/advmetrics/cm') {
    const match=context.cmMeasures?.find(v=>String(v.id)===cmSelect[2]||v.name.toLowerCase()===cmSelect[2]);
    if(match) return {action:'cm_select_measure',params:{id:match.id,selected:cmSelect[1]==='select'}};
  }
  const unit = text.match(/^(select|deselect) (?:unit|entity) (.{1,70})$/);
  if (unit && context?.route === '/advmetrics/cp') {
    const key=unit[2].trim();
    const found=context.cpEntities?.find(x => String(x.id) === key || x.name.toLowerCase() === key);
    // MIDAS validates the full entity store, not only the first 40 shared entries.
    const numericId = /^\d{1,12}$/.test(key) ? Number(key) : NaN;
    const id = found?.id ?? (context.cpEntities?.length && Number.isSafeInteger(numericId) ? numericId : null);
    if (id !== null && id !== undefined) return {action:'cp_select_entity',params:{id,selected:unit[1]==='select'}};
  }
  return null;
}
/** Human-readable guidance for recognized but incomplete/invalid commands. No UI changes. */
export function explainMidasCommand(raw: string, context: MidasContext | null): string {
  const command = raw.normalize('NFKC').trim().toLowerCase().replace(/\s+/g, ' ');
  const currentRoute = context?.route;
  const timeFormats = (context?.availableTimeFormats || []).filter(Boolean);
  if (!command) return 'Enter a MIDAS action: Open Summary, Open Combat Power, or choose an available control below.';
  if (/^(?:set|change)(?: the)? time format\b/.test(command)) {
    if (!timeFormats.length) return 'MIDAS has not supplied any available time formats. Connect the required MIDAS data/configuration and check the time-format control.';
    const requested = command.match(/time format to (.+)$/)?.[1]?.trim();
    return requested
      ? `Time format "${requested}" is not available. Choose exactly one of: ${timeFormats.join(', ')}.`
      : `Choose a target time format: Change time format to ${timeFormats[0]}. Available: ${timeFormats.join(', ')}.`;
  }
  if (/^(?:set|change)(?: the)?(?: combat power)? time (?:range|frame)\b/.test(command)) {
    if (!['/advmetrics/cp','/advmetrics/rom','/advmetrics/cm'].includes(currentRoute || '')) return 'Open Combat Power, Rate of Movement or Control Measures first, then specify both time boundaries.';
    const bounds = context?.timeBounds || context?.cpTimeBounds;
    const span = bounds && Number.isFinite(bounds.min) && Number.isFinite(bounds.max) && bounds.min < bounds.max
      ? ` Allowed MIDAS-native range: ${bounds.min} to ${bounds.max}.` : ' MIDAS has not supplied a valid available time span yet.';
    const alreadySpecified = /\d+(?:\.\d+)?\s+(?:to|through|-)\s+\d+(?:\.\d+)?/.test(command);
    if (alreadySpecified && (!bounds || !Number.isFinite(bounds.min) || !Number.isFinite(bounds.max) || bounds.min >= bounds.max)) {
      return 'MIDAS has not supplied an available time range. Connect/load the relevant MIDAS data before changing the Combat Power timeframe.';
    }
    if (alreadySpecified) return `Requested boundaries are invalid or outside the available MIDAS range.${span}`;
    return `Provide two numerical values with start before end, such as: Set time range 10 to 30.${span}`;
  }
  if (/^(?:select|deselect) (?:unit|entity)\b/.test(command)) {
    if (currentRoute !== '/advmetrics/cp') return 'Open Combat Power before selecting an entity.';
    const entities = context?.cpEntities || [];
    if (!entities.length) return 'MIDAS has shared no Combat Power entities. The current screen shows no data source/entities; connect a MIDAS data source before selecting an entity.';
    const list = entities.slice(0,5).map(e => `${e.name} (ID ${e.id})`).join(', ');
    return `Use an existing entity ID or exact name, for example: Select entity ${entities[0].id}. Available examples: ${list}.`;
  }
  if (/^(?:open|show|go to|navigate to|switch to|display)\b/.test(command)) {
    return 'Dashboard not recognized. Try Open Summary or Open Combat Power.';
  }
  return 'This command is outside the approved MIDAS controls. Supported examples: Open Summary; Open Combat Power; Change time format to <available format>; Set time range <start> to <end>; Select entity <existing ID>.';
}

/** Assistant-generated snippets are suggestions only and ALWAYS require MIDAS approval. */
export function suggestedActionFromAgent(text: string): MidasRequest | null {
  const match = text.match(/```midas-action\s*([\s\S]{1,2048}?)```/i);
  if (!match) return null;
  try {
    const value: unknown = JSON.parse(match[1]);
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const record = value as Record<string,unknown>;
    const allowed = ['navigate','time_format','cp_time_range','cp_select_entity','cp_grouping','rom_time_range','cm_time_range','rom_select_capture','cm_select_measure'];
    if (typeof record['action'] !== 'string' || !allowed.includes(record['action']) || !record['params'] || typeof record['params'] !== 'object' || Array.isArray(record['params'])) return null;
    return {action:record['action'] as MidasAction,params:record['params'] as Record<string,unknown>};
  } catch { return null; }
}
