/** Compact, user-triggered read-back of query results. Never recite raw JSON or SQL. */
type Row=Record<string,unknown>;
function rowsOf(payload:any):unknown[]|undefined {
 const direct=payload?.rows;
 if(Array.isArray(direct))return direct;
 if(Array.isArray(payload?.Response?.rows))return payload.Response.rows;
 return undefined;
}
function spokenValue(value:unknown):string {
 if(value===null||value===undefined)return 'null';
 if(typeof value==='boolean')return value?'true':'false';
 if(typeof value==='number')return Number.isFinite(value)?String(value):'unknown';
 if(typeof value==='string')return value.replace(/\s+/g,' ').slice(0,90);
 return 'complex value';
}
function spokenName(key:string):string{return key.replace(/_/g,' ').replace(/([a-z])([A-Z])/g,'$1 $2');}
function isObject(v:unknown):v is Row{return Boolean(v)&&typeof v==='object'&&!Array.isArray(v);}
export function speechSummary(payload:unknown,answer:string,maxSpokenRecords=3):string {
 const p=payload as any;
 const rows=rowsOf(p);
 if(rows){
  if(rows.length===0)return 'The query completed successfully, but no matching records were returned.';
  if(rows.length===1&&isObject(rows[0])){
   const pair=Object.entries(rows[0]).find(([key,value])=>/^(?:total_records|count|row_count|total|count\(\*\))$/i.test(key) && (typeof value==='number'||/^\d+$/.test(String(value))));
   if(pair)return `The database contains ${spokenValue(pair[1])} matching records.`;
  }
  const shown=Math.min(rows.length,Math.max(1,Math.min(10,Math.floor(maxSpokenRecords))));
  const announced=Number(p?.rowCount??p?.row_count??p?.Response?.row_count);
  const count=Number.isFinite(announced)&&announced>=rows.length?announced:rows.length;
  const prefix=`The query returned ${count} ${count===1?'record':'records'}.`;
  const details=rows.slice(0,shown).map((row:unknown,i:number)=>{
    if(!isObject(row))return `Record ${i+1}: ${spokenValue(row)}.`;
    const columns=Object.entries(row).slice(0,4);
    return `Record ${i+1}: ${columns.map(([key,value])=>`${spokenName(key)} is ${spokenValue(value)}`).join(', ')}.`;
  });
  const ending=rows.length>shown?` Only the first ${shown} records have been read aloud; all results remain visible on screen.`:'';
  return `${prefix} ${details.join(' ')}${ending}`.slice(0,4500);
 }
 // Other agents: read a short human-friendly answer, not SQL statements / JSON.
 const human=String(answer||'')
  .replace(/```[\s\S]*?```/g,' Code example omitted. ')
  .replace(/\b(?:SELECT|FROM|WHERE|JOIN|LIMIT|ORDER BY|GROUP BY)\b[^\n]{0,240};/gi,' Query omitted. ')
  .replace(/[{}\[\]"`]/g,' ').replace(/[_*#]/g,' ').replace(/\s+/g,' ').trim();
 return human.slice(0,900)||'There was no spoken summary available.';
}

/** A bounded display preview from actual executor rows; never infer missing data. */
export function databaseResultPreview(payload:unknown):import('./protocol').DbResultPreview|undefined {
 const p=payload as any;const rows=rowsOf(p);
 if(!rows)return undefined;
 const sample=rows.slice(0,20);
 const columns=[...new Set(sample.flatMap(r=>isObject(r)?Object.keys(r):['value']))].slice(0,20);
 const value=(v:unknown)=>v===null?'NULL':v===undefined?'':typeof v==='object'?(JSON.stringify(v)||'').slice(0,300):String(v).slice(0,300);
 const total=Number(p?.rowCount??p?.row_count??p?.Response?.row_count);
 return {sql:String(p?.generatedSql??p?.Response?.sql??p?.Request?.Query??''),rowCount:Number.isFinite(total)&&total>=rows.length?total:rows.length,columns,rows:sample.map(r=>columns.map(c=>value(isObject(r)?r[c]:c==='value'?r:undefined)))};
}
