/**
 * V7.0.3 database-retrieval intent guard shared by the Angular frontend and
 * the local Node orchestration backend. This classifies intent only; database
 * access, identifiers and SQL are validated by the existing DBAgent gateway.
 *
 * Explicit MIDAS UI commands must never be intercepted by DBAgent.
 */
export function isDatabaseRetrievalRequest(value: string): boolean {
  const text = String(value || '').trim();
  if (!text || text.length > 20000) return false;
  if (/^select\s+(?:(?:an?|the)\s+)?(?:entity|unit|capture|time\s+(?:range|format)|dashboard)\b/i.test(text)) return false;
  if (/^(?:open|navigate|switch|go\s+to|change\s+(?:the\s+)?time|set\s+(?:the\s+)?time)\b/i.test(text)) return false;
  // SQL requests, including denied writes, must reach the read-only validator,
  // not an unrelated LLM or agent capable of taking actions.
  if (/^(?:select|with\s+(?:recursive\s+)?[`"\w]+\s*(?:\([^)]*\)\s*)?as\s*\(|insert|update|delete|drop|truncate|alter|create|replace|grant|revoke)\b/i.test(text)) return true;
  if (/^(?:show\s+(?:tables?|databases?|columns?|indexes?)|describe\s+\w+|desc\s+\w+)\b/i.test(text)) return true;
  const retrieval = /\b(?:show|list|display|find|fetch|retrieve|count|calculate|total|summari[sz]e|sum|average|group|filter|sort|how\s+many|number\s+of|give\s+me|what\s+are|what\s+is|select)\b/i;
  const databaseNoun = /\b(?:databases?|schemas?|tables?|rows?|records?|entries|sql\s+queries?)\b/i;
  const namedTable = /\b[a-z][a-z0-9]*_[a-z0-9_]+\b/i;
  const explicitDb = /\b(?:from|in|of)\s+(?:(?:the|a)\s+)?(?:database\s+|table\s+)?[`"]?[a-z_][a-z0-9_]*\.[a-z_][a-z0-9_]*\b/i;
  // Require a retrieval verb AND a database referent. MIDAS measurements and
  // entity selection alone are not database queries.
  return retrieval.test(text) && (databaseNoun.test(text) || (namedTable.test(text) && /\b(?:from|in|table|database)\b/i.test(text)) || explicitDb.test(text));
}
