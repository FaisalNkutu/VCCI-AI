/** Conservative offline transcript classification for the hands-free controller. */
export function voiceCommand(text:string):string {
 return text.toLowerCase().trim().replace(/[.!?,;:]+/g,' ').replace(/\s+/g,' ').trim();
}
export function voiceNoise(text:string,lastSpoken=''):boolean {
 const t=voiceCommand(text.replace(/[\[\]()♪♫*_]/g,' '));
 // Whisper captions and non-verbal hallucinations are not questions, even in auto-send.
 if(/^(?:(?:speaking|talking|speech|conversation|people talking|person speaking)(?: in (?:a )?(?:foreign|unknown|another|different|unidentified) language)?|(?:foreign|unknown|unintelligible|indistinct|inaudible) (?:language|speech|talking|conversation)|(?:no|unclear) (?:audio|speech detected)|(?:background|ambient) (?:sounds?|chatter)|(?:music|applause|laughter) (?:playing|continues))$/.test(t))return true;
 if(!t||/^(?:music(?: playing)?|background music|silence|no speech|inaudible|unintelligible|noise|background noise|applause|laughter|coughing|breathing|blank audio|sound of music|thank you for watching|thanks for watching|subtitles by .+)$/.test(t))return true;
 // Confirmation instructions spoken by a second assistant or echoed from playback
 // are not requests. Do not treat a quoted command inside a sentence as a command.
 if(/^(?:i heard|question retained|question ready|please confirm or discard)\b/i.test(t)||/\b(?:say|saying) send (?:to submit|to confirm)\b.*\b(?:cancel|discard)\b/i.test(t))return true;
 const spoken=voiceCommand(lastSpoken);
 return !!spoken && (t===spoken || (t.length>=18 && spoken.includes(t)) || /^(?:i heard[: ]|say send to submit|cancel to discard|or restate your question|say replace question)/i.test(t));
}
export function confirmationCommand(text:string):'send'|'cancel'|'stop'|null {
 const t=voiceCommand(text);
 if(/^(?:please )?(?:send(?: (?:it|the (?:message|query|question)|message|query|question|now))?|submit(?: (?:it|the (?:message|query|question)|message|query|question))?|confirm(?: and send)?)(?: please)?$/.test(t))return 'send';
 if(/^(?:please )?(?:cancel|discard|cancel (?:the )?(?:message|query|question))(?: please)?$/.test(t))return 'cancel';
 if(/^(?:please )?(?:stop hands[- ]?free|exit (?:voice mode|hands[- ]?free)|stop listening|disable hands[- ]?free)(?: please)?$/.test(t))return 'stop';
 return null;
}
export function replacementQuestion(text:string):string|null {
 const m=text.trim().match(/^(?:replace|restate|change) (?:the |my )?question[,:]?\s+(.+)$/i);
 return m?.[1]?.trim()||null;
}
