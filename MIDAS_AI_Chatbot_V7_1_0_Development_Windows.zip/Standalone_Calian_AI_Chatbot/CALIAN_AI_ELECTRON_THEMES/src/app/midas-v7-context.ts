/** Strict bridge recipient. Versioned selections describe UI state; NEVER prove authorization. */
export interface MidasV7Context {
  protocolVersion: 2; contextId: string; revision:number; capturedAt:string;
  dashboard:string|null;route:string|null;
  dataSource:{connected:boolean;datasetRef:null};
  selection:{entityIds:number[];timeRange:{start:number;end:number}|null;grouping:string|null;
    timeFormat:string|null;selectedCaptureId:number|null;controlMeasureIds:number[]};
  consent:{includeInAgentQueries:boolean};kind:'ui-selection-only';
}
export function acceptV7Context(value:unknown, previous:MidasV7Context|null):MidasV7Context|null {
  if(!value || typeof value!=='object' || Array.isArray(value))return null;
  try {
    const raw=JSON.stringify(value);
    if(raw.length>16384)return null;
    const x=value as MidasV7Context;
    if(x.protocolVersion!==2 || x.kind!=='ui-selection-only' ||
      !/^[a-f0-9-]{36}$/i.test(x.contextId) || !Number.isSafeInteger(x.revision) || x.revision<1 ||
      Number.isNaN(Date.parse(x.capturedAt)) || x.consent?.includeInAgentQueries!==true ||
      typeof x.dataSource?.connected!=='boolean' || x.dataSource?.datasetRef!==null ||
      !x.selection || !Array.isArray(x.selection.entityIds) || !Array.isArray(x.selection.controlMeasureIds) ||
      x.selection.entityIds.length>40 || x.selection.controlMeasureIds.length>40 ||
      [...x.selection.entityIds,...x.selection.controlMeasureIds].some(n=>!Number.isSafeInteger(n)||n<0) ||
      (x.route!==null && (typeof x.route!=='string' || x.route.length>120)) ||
      (x.dashboard!==null && (typeof x.dashboard!=='string'||x.dashboard.length>60)))return null;
    if(previous && previous.contextId===x.contextId && x.revision<=previous.revision)return null;
    return x;
  } catch {return null;}
}
