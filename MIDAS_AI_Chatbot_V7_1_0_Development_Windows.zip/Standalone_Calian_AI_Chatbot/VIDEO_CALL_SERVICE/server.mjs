/** CALIAN public guest-only calling gateway: it never proxies to REQA, AI Core, Ollama or DBAgent. */
import http from 'node:http';
import {createHash, createHmac, randomBytes, timingSafeEqual} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {WebSocketServer, WebSocket} from 'ws';

const DEV = process.env.VIDEO_DEV_MODE === '1';
const PORT = Number(process.env.VIDEO_PORT || 9443);
const HOST = process.env.VIDEO_BIND || '127.0.0.1';
const PUBLIC = (process.env.VIDEO_PUBLIC_ORIGIN || '').replace(/\/+$/, '');
const ADMIN = process.env.VIDEO_ADMIN_KEY || '';
if (!PUBLIC || !(/^https:\/\/[^/?#]+$/i.test(PUBLIC) || (DEV && /^http:\/\/(?:localhost|127\.0\.0\.1)(?::\d+)?$/.test(PUBLIC))))
 throw Error('VIDEO_PUBLIC_ORIGIN must be a public https:// origin (http://localhost only in VIDEO_DEV_MODE=1)');
if (ADMIN.length < 32 || /replace|example|changeme/i.test(ADMIN)) throw Error('Set a random VIDEO_ADMIN_KEY of at least 32 characters');
if (!DEV && /\.example\.(com|net|org)$/i.test(new URL(PUBLIC).hostname))throw Error('Replace the example video domain before starting the public service');
let ICE;
try {ICE=JSON.parse(process.env.VIDEO_ICE_SERVERS || '[{"urls":["stun:stun.l.google.com:19302"]}]');}catch{throw Error('VIDEO_ICE_SERVERS must be a JSON array');}
if (!Array.isArray(ICE) || ICE.some(s=>!s || (typeof s.urls!=='string' && !Array.isArray(s.urls)))) throw Error('Invalid ICE servers');
// Optional SFU integration. Existing peer-to-peer calls work unchanged without LiveKit.
const LIVEKIT_URL=(process.env.VIDEO_LIVEKIT_URL||'').trim().replace(/\/+$/,'');
const LIVEKIT_KEY=(process.env.VIDEO_LIVEKIT_API_KEY||'').trim();
const LIVEKIT_SECRET=(process.env.VIDEO_LIVEKIT_API_SECRET||'').trim();
const LIVEKIT_READY=!!(LIVEKIT_URL&&LIVEKIT_KEY&&LIVEKIT_SECRET);
if (LIVEKIT_READY&&!/^wss:\/\/[^/?#]+$/.test(LIVEKIT_URL)&&!(DEV&&/^ws:\/\/(localhost|127\.0\.0\.1):\d+$/.test(LIVEKIT_URL)))
 throw Error('VIDEO_LIVEKIT_URL must be a wss:// origin (ws://localhost only in VIDEO_DEV_MODE=1)');
const livekitSdk=LIVEKIT_READY?await import('livekit-server-sdk'):null;
const AccessToken=livekitSdk?.AccessToken;
const RoomServiceClient=livekitSdk?.RoomServiceClient;
const livekitService=LIVEKIT_READY?new RoomServiceClient(LIVEKIT_URL.replace(/^wss:/,'https:').replace(/^ws:/,'http:'),LIVEKIT_KEY,LIVEKIT_SECRET):null;
async function groupTicket(room,role,guestId){
 if(!LIVEKIT_READY||room.mode!=='group')throw Error('LiveKit group calls not configured');
 const identity=role==='host'?`host_${room.id}`:`guest_${guestId}`;
 const name=role==='host'?'Host':room.guests.get(guestId)?.name||'Guest';
 const token=new AccessToken(LIVEKIT_KEY,LIVEKIT_SECRET,{identity,name,ttl:role==='host'?'5m':'1m'});
 token.addGrant({roomJoin:true,room:room.livekitRoom,canPublish:true,canSubscribe:true,canPublishData:false});
 return {type:'group-join',url:LIVEKIT_URL,token:await token.toJwt(),identity};
}
const TURN_URLS=JSON.parse(process.env.VIDEO_TURN_URLS||'[]');
const TURN_SECRET=process.env.VIDEO_TURN_SHARED_SECRET||'';
if(!Array.isArray(TURN_URLS)||TURN_URLS.some(u=>typeof u!=='string'))throw Error('VIDEO_TURN_URLS must be a JSON string array');
const freshIce=()=>{
 const servers=[...ICE];
 if(TURN_URLS.length&&TURN_SECRET){const username=`${Math.floor(now()/1000)+3600}:calian`;const credential=createHmac('sha1',TURN_SECRET).update(username).digest('base64');servers.push({urls:TURN_URLS,username,credential});}
 return servers;
};
const sha=s=>createHash('sha256').update(s).digest('hex');
const rand=()=>randomBytes(32).toString('base64url');
const equal=(a,b)=>typeof a==='string'&&typeof b==='string'&&a.length===b.length&&timingSafeEqual(Buffer.from(a),Buffer.from(b));
const rooms=new Map();
const invites=new Map();
const tickets=new Map();
const rate=new Map();
const minute=60_000;
const now=()=>Date.now();
function cleanRoom(room){
 rooms.delete(room.id); invites.delete(room.inviteHash);
 for(const h of room.ticketHashes)tickets.delete(h);
 if(room.mode==='group'&&livekitService)void livekitService.deleteRoom(room.livekitRoom).catch(e=>console.warn('LiveKit room cleanup:',e.message));
 try{room.host?.close(1000,'Meeting closed');}catch{}
 for(const guest of room.guests.values())try{guest.ws?.close(1000,'Meeting closed');}catch{}
}
const cleanup=()=>{for(const r of rooms.values())if(r.expires<=now())cleanRoom(r);for(const [k,v] of rate)if(v.until<now())rate.delete(k);};
const cleanupTimer=setInterval(cleanup,60000);cleanupTimer.unref();
function throttle(req, route, max=15){const key=`${req.socket.remoteAddress}:${route}`;const t=now();let record=rate.get(key);if(!record||record.until<t){record={n:0,until:t+minute};rate.set(key,record);}record.n++;return record.n<=max;}
function respond(res,status,body){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(body));}
async function body(req, limit=8192){let text='';for await(const chunk of req){text+=chunk;if(text.length>limit)throw Error('Request body too large');}return JSON.parse(text||'{}');}
const file=(name)=>readFileSync(path.join(path.dirname(fileURLToPath(import.meta.url)),'public',name));
const security={"Cache-Control":"no-store","X-Content-Type-Options":"nosniff","Referrer-Policy":"no-referrer","Permissions-Policy":"camera=(self), microphone=(self)","Content-Security-Policy":`default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self' ${PUBLIC.replace(/^http/,'ws')} ${LIVEKIT_READY?LIVEKIT_URL+' '+LIVEKIT_URL.replace(/^ws/,'http'):''}; media-src 'self' blob:; form-action 'none'; frame-ancestors 'none'; base-uri 'none'`};
const server=http.createServer(async(req,res)=>{
 try{
  const url=new URL(req.url||'/',PUBLIC);
  if(req.method==='GET'&&url.pathname==='/health'){return respond(res,200,{ready:true,role:'public-video-only',protocolVersion:'calian-livekit-group-v2',groupCallsConfigured:LIVEKIT_READY,maxGroupParticipants:LIVEKIT_READY?10:0});}
  if(req.method==='GET'&&(url.pathname==='/' || /^\/i\/[A-Za-z0-9_-]{30,}$/.test(url.pathname))){res.writeHead(200,{...security,'Content-Type':'text/html; charset=utf-8'});return res.end(file('guest.html'));}
  if(req.method==='GET' && url.pathname==='/guest.js'){res.writeHead(200,{...security,'Content-Type':'application/javascript; charset=utf-8'});return res.end(file('guest.js'));}
  if(req.method==='GET' && url.pathname==='/livekit-client.umd.min.js'){
   if(!LIVEKIT_READY)return respond(res,404,{error:'Group calls not configured'});
   res.writeHead(200,{...security,'Content-Type':'application/javascript; charset=utf-8'});
   return res.end(readFileSync(path.join(path.dirname(fileURLToPath(import.meta.url)),'node_modules','livekit-client','dist','livekit-client.umd.min.js')));
  }
  if(req.method==='GET' && url.pathname==='/guest.css'){res.writeHead(200,{...security,'Content-Type':'text/css; charset=utf-8'});return res.end(file('guest.css'));}
  if(req.method==='POST' && url.pathname==='/api/host/rooms'){
   if(!throttle(req,'host',30))return respond(res,429,{error:'Too many meetings'});
   if(!equal(req.headers.authorization?.replace(/^Bearer /,''), ADMIN))return respond(res,401,{error:'Host API key required'});
   if(rooms.size>=100)return respond(res,503,{error:'Maximum active meetings reached'});
   const params=await body(req);const mode=params.mode==='group'?'group':'direct';
   const name=mode==='group'?String(params.name||'Group meeting').replace(/[\x00-\x1f\x7f]/g,' ').trim().slice(0,70)||'Group meeting':'Private call';
   if(mode==='group'&&!LIVEKIT_READY)return respond(res,503,{error:'Group calling requires VIDEO_LIVEKIT_URL, VIDEO_LIVEKIT_API_KEY and VIDEO_LIVEKIT_API_SECRET on the public video service.'});
   const id=rand();const invite=rand();const hostTicket=rand();const expires=now()+60*60*1000;
   const livekitRoom=mode==='group'?`calian_${randomBytes(18).toString('hex')}`:null;
   if(mode==='group'){
    try{await livekitService.createRoom({name:livekitRoom,maxParticipants:10,emptyTimeout:3600});}
    catch(e){return respond(res,502,{error:`Cannot create LiveKit room: ${String(e.message||e).slice(0,180)}`});}
   }
   const r={id,mode,name,livekitRoom,inviteHash:sha(invite),expires,host:null,guestAdmitted:null,guests:new Map(),ticketHashes:new Set([sha(hostTicket)])};
   rooms.set(id,r);invites.set(r.inviteHash,r);tickets.set(sha(hostTicket),{room:r,role:'host'});
   return respond(res,201,{roomId:id,name,mode,maxParticipants:mode==='group'?10:2,inviteUrl:`${PUBLIC}/i/${invite}`,hostTicket,wsUrl:PUBLIC.replace(/^http/,'ws')+'/signal',iceServers:freshIce(),expiresAt:new Date(expires).toISOString()});
  }
  if(req.method==='POST' && url.pathname==='/api/guest/join'){
   if(!throttle(req,'guest-join',30))return respond(res,429,{error:'Please wait before trying again'});
   const b=await body(req);
   if(typeof b.invite!=='string'||!b.invite.match(/^[\w-]{30,}$/))return respond(res,400,{error:'Invalid invitation'});
   const room=invites.get(sha(b.invite));
   if(!room||room.expires<=now())return respond(res,404,{error:'Invitation expired or revoked'});
   if(room.guests.size>=20)return respond(res,429,{error:'Waiting room is full'});
   const name=String(b.name||'Guest').trim().slice(0,70);
   if(!name)return respond(res,400,{error:'Enter a display name'});
   const guestId=rand();const guestTicket=rand();
   const guest={id:guestId,name,ws:null,admitted:false};room.guests.set(guestId,guest);
   const hash=sha(guestTicket);room.ticketHashes.add(hash);tickets.set(hash,{room,role:'guest',guestId});
   return respond(res,200,{roomName:room.name,mode:room.mode,maxParticipants:room.mode==='group'?10:2,guestTicket,guestId,wsUrl:PUBLIC.replace(/^http/,'ws')+'/signal',iceServers:freshIce(),expiresAt:new Date(room.expires).toISOString()});
  }
  return respond(res,404,{error:'Not found'});
 }catch(e){return respond(res,400,{error:e.message||'Invalid request'});}
});
const wss=new WebSocketServer({noServer:true,maxPayload:24*1024,perMessageDeflate:false});
server.on('upgrade',(req,socket,head)=>{
 if(req.url!=='/signal'){socket.destroy();return;}
 if(!throttle(req,'websocket',60)){socket.destroy();return;}
 wss.handleUpgrade(req,socket,head,ws=>wss.emit('connection',ws,req));
});
const send=(ws,obj)=>{if(ws?.readyState===WebSocket.OPEN)ws.send(JSON.stringify(obj));};
wss.on('connection',(ws)=>{
 let room=null, role=null, guestId=null;
 const authenticationTimer=setTimeout(()=>{if(!role)ws.close(1008,'Authentication required');},8000);
 ws.on('message',async(raw)=>{
  try {
   const m=JSON.parse(raw.toString());
   if(!role){
    if(m.type!=='auth'||typeof m.ticket!=='string')return ws.close(1008,'Invalid ticket');
    const info=tickets.get(sha(m.ticket));
    if(!info||info.room.expires<=now())return ws.close(1008,'Expired ticket');
    room=info.room;role=info.role;guestId=info.guestId||null;
    if(role==='host'){if(room.host&&room.host!==ws)room.host.close(1008,'Another host connected');room.host=ws;}
    else {const g=room.guests.get(guestId);if(!g)return ws.close(1008,'Invalid guest');if(g.ws&&g.ws!==ws)g.ws.close(1008,'Reconnected');g.ws=ws;}
    clearTimeout(authenticationTimer);
    send(ws,{type:'ready',role,roomId:room.id,mode:room.mode,mediaProvider:room.mode==='group'?'livekit':'webrtc',expiresAt:new Date(room.expires).toISOString()});
    if(role==='host'){
     for(const g of room.guests.values())if(!g.admitted&&g.ws)send(ws,{type:'waiting',guestId:g.id,name:g.name});
     if(room.mode==='group')send(ws,await groupTicket(room,'host'));
    }
    if(role==='guest'){const g=room.guests.get(guestId);send(ws,{type:g.admitted?'admitted':'waiting-status'});if(g.admitted&&room.mode==='group')send(ws,await groupTicket(room,'guest',g.id));if(!g.admitted)send(room.host,{type:'waiting',guestId:g.id,name:g.name});}
    return;
   }
   if(m.type==='admit'&&role==='host'){
    const g=room.guests.get(m.guestId);
    if(!g||!g.ws)return send(ws,{type:'error',error:'Guest not connected'});
    if(g.admitted)return;
    if(room.mode==='direct'&&room.guestAdmitted&&room.guestAdmitted!==g.id)return send(ws,{type:'error',error:'Only one connected guest may be admitted'});
    if(room.mode==='group'&&[...room.guests.values()].filter(x=>x.admitted).length>=9)
      return send(ws,{type:'error',error:'Group meeting is full (10 including host)'});
    if(room.mode==='direct')room.guestAdmitted=g.id;
    g.admitted=true;
    send(g.ws,{type:'admitted'});send(room.host,{type:'admitted',guestId:g.id,name:g.name});
    if(room.mode==='group')send(g.ws,await groupTicket(room,'guest',g.id));
    return;
   }
   if(m.type==='remove'&&role==='host'&&room.mode==='group'){
    const g=room.guests.get(m.guestId);if(!g)return;
    if(g.admitted){try{await livekitService.removeParticipant(room.livekitRoom,`guest_${g.id}`);}catch(e){console.warn('LiveKit removal:',e.message);}}
    send(g.ws,{type:'removed'});g.ws?.close(1000,'Removed');room.guests.delete(g.id);
    for(const h of room.ticketHashes){const record=tickets.get(h);if(record?.guestId===g.id){tickets.delete(h);room.ticketHashes.delete(h);}}
    send(room.host,{type:'guest-left',guestId:g.id});return;
   }
   if(m.type==='deny'&&role==='host'){
    const g=room.guests.get(m.guestId);if(g&&!g.admitted){send(g.ws,{type:'denied'});g.ws?.close(1000,'Denied');room.guests.delete(g.id);}return;
   }
   if(room.mode==='direct'&&m.type==='signal'&&m.data&&['offer','answer','candidate'].includes(m.data.kind)){
    if(role==='host'){
     const g=room.guests.get(room.guestAdmitted);
     if(g?.admitted)send(g.ws,{type:'signal',data:m.data});
    }else if(room.guestAdmitted===guestId && room.guests.get(guestId)?.admitted){send(room.host,{type:'signal',data:m.data});}
    return;
   }
   if(m.type==='end'&&role==='host'){send(room.host,{type:'ended'});cleanRoom(room);return;}
  }catch(e){send(ws,{type:'error',error:'Signaling failed: '+String(e.message||e).slice(0,160)});}
 });
 ws.on('close',()=>{
  clearTimeout(authenticationTimer);
  if(!room)return;
  if(role==='host'&&room.host===ws){room.host=null;for(const g of room.guests.values())send(g.ws,{type:'host-disconnected'});}
  if(role==='guest'){const g=room.guests.get(guestId);if(g?.ws===ws){room.guests.delete(guestId);if(room.guestAdmitted===guestId)room.guestAdmitted=null;send(room.host,{type:'guest-left',guestId});}}
 });
});
server.listen(PORT,HOST,()=>console.log(`CALIAN public video-only service listening on ${HOST}:${PORT}, public origin ${PUBLIC}`));
export {server,rooms,cleanRoom};
