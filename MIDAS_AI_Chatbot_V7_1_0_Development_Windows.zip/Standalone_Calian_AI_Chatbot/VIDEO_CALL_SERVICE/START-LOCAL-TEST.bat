@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>&1 || (echo Node.js 20+ required & pause & exit /b 1)
if not exist node_modules call npm install --omit=dev
if errorlevel 1 (echo npm install failed & pause & exit /b 1)
if not exist .env (
 echo No .env file configured. Copy .env.example to .env and set VIDEO_ADMIN_KEY, origin and TURN.
 pause
 exit /b 1
)
call npm start
pause
