# CALIAN.AI V8 — Live AI Camera + Worldwide Person-to-Person Video

**Based on the exact user-supplied working V8 portable database-configuration ZIP.**

## What is included

- Existing desktop Angular/Electron CALIAN.AI and Android/iPhone PWA, with all four themes, unchanged DBAgent/REQA, schema selection, Whisper, and spoken result support.
- New **Live Video** left-nav workspace with two modes:
  1. **Talk to AI**: opt-in camera preview, spoken questions via existing local Whisper, vision inference through the configured Ollama image-capable model, and optional spoken answers. A 10-second *Live observations* option processes discrete still frames, one at a time. **This is frame-based AI video, not a continuous low-latency streaming AI avatar.**
  2. **Call a Person**: one-on-one WebRTC camera/microphone call with expiring link, host approval, guest waiting room, mute/camera/hang-up. The guest uses a browser and does NOT install CALIAN.AI or Tailscale.
- A **separate** `VIDEO_CALL_SERVICE/` Node/WebSocket service serving the only public guest interface. It has **no** REQA, database, Ollama, Python, or local CALIAN routes.

## 1. Build your Windows app

1. Extract this ZIP to a new folder. **Keep your currently working executable and its `calian.env` intact as a fallback.**
2. Run `BUILD-CALIAN-WINDOWS.bat` from the extracted root; Node.js/npm and an internet connection for dependency installation are required.
3. Your executable is inside `CALIAN_AI_ELECTRON_THEMES\release\CALIAN AI 1.0.0.exe`.
4. **IMPORTANT: copy your original working `calian.env` from the old `release` folder into the NEW `release` folder.** The working `CALIAN_SCHEMA_DATABASE` selection and other settings are machine-specific and are intentionally not embedded in this ZIP.
5. Start the new executable. Existing Chat / REQA / DBAgent should behave as before; the new **Live Video** entry appears in the sidebar.

## 2. Test Talk to AI on Windows (no public server required)

1. If you have not installed a vision-capable Ollama model, run `ollama pull llama3.2-vision` on Windows (requires disk space and sufficient memory).
2. In CALIAN.AI, select **Live Video → Talk to AI → Start camera**.
3. Allow camera permission, type "What do you see?" and click **Ask AI about this frame**.
4. Optionally click **Speak question**, dictate, click **Stop speaking** to transcribe using your existing Windows Whisper, review the question and click **Ask AI**. Enable **Read AI answers aloud** if desired.
5. Optionally enable **Live observations (every 10 seconds)**. Frames are never recorded by this new feature. Actual performance depends on Ollama model/hardware.

## 3. Host invite links that work worldwide — public HTTPS service required

**A public URL cannot be produced by simply rebuilding the Windows desktop app.** For guests anywhere without Tailscale, deploy `VIDEO_CALL_SERVICE/` to a separate Internet-accessible host (e.g. a small Linux VPS) with its own domain and a reverse-proxy TLS certificate. Do **not** expose Windows localhost/REQA/DBAgent ports publicly.

Example deployment on a VPS with Node.js 20.6+:

```bash
cd VIDEO_CALL_SERVICE
cp .env.example .env
# Replace VIDEO_PUBLIC_ORIGIN with https://video.yourdomain.example
# Set VIDEO_ADMIN_KEY to a random secret from: openssl rand -hex 32
# Optionally configure TURN; see section 5.
npm install --omit=dev
npm start
```

The service binds to `127.0.0.1:9443`. Configure public DNS for `video.yourdomain.example` and run Caddy using the included `Caddyfile.example` (update domain). Caddy terminates public HTTPS and forwards to localhost, including `/signal` WebSockets. Configure your process manager/systemd to keep this service running. The gateway stores active rooms only in memory; service restart ends active meetings.

### Configure your private Windows CALIAN host

After the new Windows build, run `SETUP-CALIAN-VIDEO-HOST-WINDOWS.bat`. It writes the following entries **next to the newly built portable EXE**, preserving `CALIAN_SCHEMA_DATABASE` and your other working config:

```ini
CALIAN_VIDEO_PUBLIC_ORIGIN=https://video.yourdomain.example
CALIAN_VIDEO_ADMIN_KEY=<exact same secret as public VIDEO_ADMIN_KEY>
CALIAN_VISION_MODEL=llama3.2-vision
```

**Never** upload or share `calian.env` or the public server `.env`. Restart CALIAN.AI after changing configuration.

Click **Live Video → Call a Person → Create secure invitation**. Copy the link and send it by WhatsApp/SMS/email. The invited person opens it in Safari/Chrome/Edge, enters a display name and allows camera/microphone; **you must press Admit**. Both sides can mute, disable camera or hang up. Invite expires after 60 minutes, and ending the meeting revokes it. This release supports **one guest at a time**, not multi-party conferencing.

## 4. Quick local test (without a public domain)

For developers only, on one Windows PC, edit `VIDEO_CALL_SERVICE/.env` with:

```ini
VIDEO_PUBLIC_ORIGIN=http://127.0.0.1:9443
VIDEO_PORT=9443
VIDEO_BIND=127.0.0.1
VIDEO_DEV_MODE=1
VIDEO_ADMIN_KEY=<random at least 32 characters>
VIDEO_ICE_SERVERS=[{"urls":["stun:stun.l.google.com:19302"]}]
```

Run `npm install` then `npm start` in `VIDEO_CALL_SERVICE`. In your test CALIAN `calian.env`, set `CALIAN_VIDEO_PUBLIC_ORIGIN=http://127.0.0.1:9443`, `CALIAN_VIDEO_ADMIN_KEY=<matching secret>`, and `CALIAN_VIDEO_ALLOW_HTTP_DEV=true`. Restart CALIAN.AI. Two browser windows on localhost can test the signaling/waiting-room workflow. **This does not give Internet-wide access**; do not use HTTP outside localhost.

After `npm install`, run `npm test` within `VIDEO_CALL_SERVICE` for its automated local permission and signaling checks.

## 5. TURN relay is strongly recommended for worldwide calls

Public HTTPS handles invitations and WebSocket signaling; it does NOT guarantee video/audio transport across strict NAT or mobile networks. Use a TURN service such as coturn, LiveKit infrastructure, or a managed TURN provider.

For coturn with `use-auth-secret` and `static-auth-secret`, configure the public service:

```ini
VIDEO_TURN_URLS=["turn:turn.yourdomain.example:3478?transport=udp","turns:turn.yourdomain.example:5349?transport=tcp"]
VIDEO_TURN_SHARED_SECRET=<same shared secret configured in coturn>
```

The gateway derives short-lived 1-hour TURN credentials for the clients (not the static shared secret). Your firewall and TURN deployment must allow relay traffic; test calls between different network providers, not just Wi-Fi on the same LAN.

## 6. Security and boundaries

- Public service has no routes or connectivity to the private CALIAN.AI APIs, DBAgent, REQA, SQL, or Ollama.
- Invitation tokens and host/guest WebSocket tickets are random 256-bit bearer capabilities with server-side hash lookup, time limits and host approval. Share links only with intended guests.
- One-to-one media is WebRTC encrypted with DTLS-SRTP. Signaling passes through the public video gateway, not the database backend.
- Browser camera/microphone permissions are requested on explicit user actions. End Call/Stop Camera removes local tracks.
- No recording, group calling, screen sharing, password-protected meetings, account identities or native APK/IPA builds are included. Those require further work.
- If a model or camera is unavailable, the interface displays an error and existing SQL/REQA chat remains unaffected.

## 7. Verification limitations

The Angular/Electron source and video gateway JavaScript underwent syntax and consistency checks. **A full `npm install`/Angular Windows build and physical camera/video tests could not be completed in the author's environment**, so run the supplied Windows build and the local gateway tests before production use. End-to-end Internet calls additionally require your own public HTTPS hostname and a working TURN deployment.

### Component locations

- Angular UI: `CALIAN_AI_ELECTRON_THEMES/src/app/video-center.component.{ts,html,scss}` and small nav additions to `app.component`.
- Private API bridge: `CALIAN_AI_ELECTRON_THEMES/server/video-routes.ts` registered from `server/index.ts`.
- Public guest video service: `VIDEO_CALL_SERVICE/server.mjs`, `VIDEO_CALL_SERVICE/public/guest.*`, tests and sample Caddy/env files.
- **Portable database selection:** `CALIAN_AI_ELECTRON_THEMES/electron/main.cjs` was not modified.
