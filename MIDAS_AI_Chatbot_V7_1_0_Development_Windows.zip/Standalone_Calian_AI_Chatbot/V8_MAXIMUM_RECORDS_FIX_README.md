# CALIAN.AI V8 — English row-limit / read-only SQL repair

Base: Standalone_Calian_AI_Chatbot_V8_Live_Video_English_SELECT_422_Fix.zip

## Repaired

- English questions such as **“Show me a maximum of 10 records from contxt_oi_assoc table”** no longer trigger an unnecessary Ollama query plan. The schema-aware adapter produces deterministic SQL using the verified selected database and a LIMIT of 10.
- Recognizes **maximum of N**, **up to N**, **at most N**, **no more than N**, **only N**, and ordinary record limits; respects the existing 100-row cap.
- The CALIAN-side read-only Docker SQL parser now permits SQLGlot boolean conjunction/disjunction/negation expression nodes (AND, OR, NOT), without permitting writes or unsafe database functions.
- Requests about the maximum **value** of a column continue to use validated schema-aware planning instead of being mistaken for a row limit.

## Unchanged

- Video-call service, AI vision, Tailscale/mobile PWA, REQA, DBAgent, Whisper, spoken results, UI, A2A, and your portable `calian.env` loading behavior.
- The Docker image and Fouad's source are never changed.

## Install

1. Back up the current working version. Extract this ZIP into a **new** folder.
2. Run `BUILD-CALIAN-WINDOWS.bat`.
3. Copy the **working `calian.env`** file beside the new portable `.exe` in `CALIAN_AI_ELECTRON_THEMES\release`.
4. Run the new executable.
5. Say: **“Show me a maximum of 10 records from the context O I association table.”**
6. Verify the displayed `Generated read-only SQL` contains **LIMIT 10** and returns records.

Expected SQL (if the current selected database/table are the ones already verified on your machine):

```sql
SELECT * FROM `vcci_aug_26_dbg_1`.`contxt_oi_assoc` LIMIT 10;
```

## Verification limits

The English-to-SQL path was unit-tested using mocked database metadata and read-only SQL. The embedded Python bridge was syntax-checked. The complete Windows build and actual Docker/MariaDB execution still need to be verified on your computer.
