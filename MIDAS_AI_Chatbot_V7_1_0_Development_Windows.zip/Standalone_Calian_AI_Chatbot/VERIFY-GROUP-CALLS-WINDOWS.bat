@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0VERIFY-GROUP-CALLS-WINDOWS.ps1"
if errorlevel 1 (echo. & echo Group video preflight FAILED. See details above.)
pause
