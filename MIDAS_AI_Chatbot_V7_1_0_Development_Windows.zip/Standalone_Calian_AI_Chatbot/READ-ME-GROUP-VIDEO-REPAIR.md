# CALIAN AI group video repair — detecting an old public gateway

## Why your host and guest could not see each other

The captured `POST /api/video/rooms` response shown in Developer Tools contained `roomId`, `inviteUrl`, `hostTicket`, `wsUrl`, `iceServers`, and `expiresAt`, but **no `mode` or `maxParticipants`**. The current group gateway source MUST return `mode: "group"` and `maxParticipants: 10`; this is strong evidence that a **different/older public gateway was running** (or that the desktop was pointing to one). That older gateway can create and admit a one-to-one meeting but cannot provide a LiveKit `group-join` token. The result is the endless **“Waiting for their video...”** state and no LiveKit participants.

**This is a source inspection and screenshot diagnosis, not an end-to-end proof of your remote deployment.** It must be checked with the public gateway's health endpoint.

## Correct deployment steps on the Windows host

1. Keep your current working installation as a rollback. Extract this ZIP into a **new** directory.
2. Copy the **existing private `VIDEO_CALL_SERVICE\.env`** from your actual running gateway into this new ZIP's `VIDEO_CALL_SERVICE` folder. Do **not** share your `.env` or add secrets to `calian.env`. Ensure each `VIDEO_LIVEKIT_*` value is on its own line. The URL should begin with `wss://`.
3. Stop the previous video gateway process/service. If unsure which instance is running, run PowerShell `Get-NetTCPConnection -LocalPort 9443 -State Listen | Select LocalAddress,OwningProcess`, then `Get-Process -Id <PID>` to identify it **before** stopping it. Do not kill all Node processes.
4. Run **`START-UPDATED-VIDEO-GATEWAY-WINDOWS.bat`**. It installs `ws`, `livekit-client`, and `livekit-server-sdk` and launches the gateway from the corrected folder. Keep its command window open. If this service is on another machine, deploy `VIDEO_CALL_SERVICE` and its `.env` there instead; starting a second local gateway is not enough.
5. Run **`VERIFY-GROUP-CALLS-WINDOWS.bat`** on the gateway host. This safely checks your local and public HTTPS `/health` endpoints without exposing API credentials. **Both** must show `protocolVersion: calian-livekit-group-v2` and `groupCallsConfigured: True`. If your Tailscale Funnel is routing to the old service, correct the Funnel/proxy target. If the old gateway still answers at the public URL, Calian will continue to create incompatible rooms.
6. Rebuild the portable desktop using **`BUILD-CALIAN-WINDOWS.bat`** (requires Node.js on build machine). It does not copy LiveKit secrets into the EXE. Replace the desktop executable, but preserve your working `calian.env` beside it or in the supported per-user fallback. Do not use the EXE already installed in the old `release` directory.
7. Create a **new** group meeting and rejoin from the other laptop. Confirm two participants in LiveKit Sessions.

## What changed

- The desktop backend checks that a **group** request really resulted in a **group** response. If a legacy gateway returned one-to-one fields, it now returns a clear 502 error instead of a broken invitation.
- The desktop also checks the gateway's signaling `ready` message and raises an error if no LiveKit ticket arrives promptly.
- The guest page reports an outdated gateway or missing LiveKit media credentials instead of endlessly displaying “Connecting media”.
- The public gateway now identifies its protocol in `/health`, without disclosing credentials.
- No change to REQA, DBAgent, speech, Ollama, A2A, database routing, or the normal one-to-one WebRTC signal path.

## Security

Never post `hostTicket`, guest invitation tokens, `VIDEO_ADMIN_KEY`, or the LiveKit secret in screenshots. Generate a new invitation after updating. Store LiveKit credentials only in `VIDEO_CALL_SERVICE\.env` on the gateway host; expose only the separate gateway to public clients.

## Verification limits

Automated checks cover TypeScript syntax, protocol-routing assertions, and private-bridge behavior against simulated old/new gateway replies. Actual LiveKit Cloud connectivity and the Windows portable executable must be tested on the target machine; this ZIP contains **source and build scripts, not a prebuilt Windows EXE**.
