# Optional fallback when the REQA MCP driver cannot report SELECT DATABASE().
# No changes to Docker, REQA, Fouad's services, or SQL code.
$ErrorActionPreference = 'Stop'
try {
  $release = Join-Path $PSScriptRoot 'CALIAN_AI_ELECTRON_THEMES\release'
  if (-not (Test-Path $release -PathType Container)) {
    throw "Build CALIAN AI first. The release folder is missing: $release"
  }
  $exe = Get-ChildItem -LiteralPath $release -Filter '*.exe' -File | Select-Object -First 1
  if (-not $exe) { throw 'No CALIAN AI portable .exe found in the release folder. Build the app first.' }
  Write-Host 'Only use this if automatic database selection reports ambiguous tables.'
  Write-Host 'Current database as shown in HeidiSQL (example: vcci_aug_26_dbg_1)'
  $database = (Read-Host 'Database name').Trim()
  if ($database -notmatch '^[A-Za-z_][A-Za-z0-9_]{0,127}$') {
    throw 'Invalid database name. Enter only letters, digits and underscore; begin with a letter or underscore.'
  }
  $configFile = Join-Path $release 'calian.env'
  $existing = if (Test-Path -LiteralPath $configFile) { [IO.File]::ReadAllText($configFile) } else { '' }
  if (Test-Path -LiteralPath $configFile) { Copy-Item -LiteralPath $configFile -Destination ($configFile + '.backup') -Force }
  $cleanLines = @($existing -split "`r?`n" | Where-Object { $_ -notmatch '^\s*CALIAN_SCHEMA_DATABASE\s*=' })
  $updated = (($cleanLines + "CALIAN_SCHEMA_DATABASE=$database") -join "`r`n").Trim() + "`r`n"
  [IO.File]::WriteAllText($configFile, $updated, (New-Object System.Text.UTF8Encoding($false)))
  Write-Host "Selected database: $database" -ForegroundColor Green
  Write-Host "Saved: $configFile"
  Write-Host 'Close CALIAN AI completely, then launch the EXE again.'
  Write-Host 'The repaired portable launcher reads this file next to the ORIGINAL .exe, not a temporary extracted copy.'
} catch {
  Write-Host ("ERROR: " + $_.Exception.Message) -ForegroundColor Red
  exit 1
}
