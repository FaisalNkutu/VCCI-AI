$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$gateway = Join-Path $root 'VIDEO_CALL_SERVICE'
$envFile = Join-Path $gateway '.env'
Write-Host 'CALIAN GROUP VIDEO - SAFE GATEWAY DIAGNOSTIC' -ForegroundColor Cyan
Write-Host 'Only public capability flags are shown; keys and secrets are never printed.'
if (-not (Test-Path -LiteralPath $envFile)) {
  Write-Host 'FAILED: VIDEO_CALL_SERVICE\.env is missing. Copy your private working .env into the updated gateway folder.' -ForegroundColor Red
  exit 1
}
$values = @{}
$seen = @{}
Get-Content -LiteralPath $envFile | ForEach-Object {
  if ($_ -match '^\s*#') { return }
  if ($_ -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$') {
    $name = $matches[1]; $val = $matches[2].Trim().Trim('"').Trim("'")
    if ($seen.ContainsKey($name)) { Write-Host "WARNING: duplicate active key $name" -ForegroundColor Yellow }
    $seen[$name] = $true; $values[$name] = $val
  }
}
$required = @('VIDEO_PORT','VIDEO_PUBLIC_ORIGIN','VIDEO_ADMIN_KEY','VIDEO_LIVEKIT_URL','VIDEO_LIVEKIT_API_KEY','VIDEO_LIVEKIT_API_SECRET')
$invalid = $false
foreach ($name in $required) {
  $val = $values[$name]
  $ok = -not [string]::IsNullOrWhiteSpace($val) -and $val -notmatch 'REPLACE|YOUR_|example\.com|changeme'
  if ($name -eq 'VIDEO_ADMIN_KEY') { $ok = $ok -and $val.Length -ge 32 }
  if ($name -eq 'VIDEO_LIVEKIT_URL') { $ok = $ok -and $val -match '^wss://[^/?#]+$' }
  Write-Host ("{0}: {1}" -f $name, $(if($ok){'configured'}else{'MISSING / PLACEHOLDER'}))
  if (-not $ok) { $invalid = $true }
}
if ($invalid) { Write-Host 'Fix the missing settings and restart the updated gateway before testing.' -ForegroundColor Red; exit 1 }
$port = if($values['VIDEO_PORT']){[int]$values['VIDEO_PORT']}else{9443}
$origin = $values['VIDEO_PUBLIC_ORIGIN'].TrimEnd('/')
$checks = @(
  @{Name='Local gateway'; Url="http://127.0.0.1:$port/health"},
  @{Name='Public gateway'; Url="$origin/health"}
)
$failed = $false
foreach($c in $checks){
 try {
  $health=Invoke-RestMethod -Uri $c.Url -TimeoutSec 8 -ErrorAction Stop
  Write-Host ($c.Name+': role='+$health.role+', protocol='+$health.protocolVersion+', groupCallsConfigured='+$health.groupCallsConfigured)
  if ($health.protocolVersion -ne 'calian-livekit-group-v2') {
    Write-Host ('FAILED: '+$c.Name+' is running an older gateway build. Stop that process, install dependencies and launch VIDEO_CALL_SERVICE from THIS package.') -ForegroundColor Red
    $failed=$true
  } elseif ($health.groupCallsConfigured -ne $true){
    Write-Host ('FAILED: '+$c.Name+' is not loading all three LiveKit settings.') -ForegroundColor Red
    $failed=$true
  }
 } catch {
  Write-Host ($c.Name+': NOT REACHABLE ('+$_.Exception.Message+')') -ForegroundColor Yellow
  $failed=$true
 }
}
if ($failed){Write-Host 'Do not test invitations until the public gateway reports protocolVersion=calian-livekit-group-v2 and groupCallsConfigured=True.' -ForegroundColor Red;exit 1}
Write-Host 'PASS: Both gateway endpoints expose the updated LiveKit group protocol. Create a NEW group meeting to test.' -ForegroundColor Green
