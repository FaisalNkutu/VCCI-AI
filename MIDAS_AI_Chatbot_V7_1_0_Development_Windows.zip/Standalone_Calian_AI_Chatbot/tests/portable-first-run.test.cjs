'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const vm=require('node:vm');
const EventEmitter=require('node:events');
const source=fs.readFileSync(path.join(__dirname,'../CALIAN_AI_ELECTRON_THEMES/electron/main.cjs'),'utf8');

async function startup({existing=null,denied=false}={}){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'calian-exe-test-'));
 const portableDir=path.join(root,'deliver');
 const userDir=path.join(root,'userData');
 fs.mkdirSync(portableDir);fs.mkdirSync(userDir);
 const portableFile=path.join(portableDir,'calian.env');
 if(existing!==null)fs.writeFileSync(portableFile,existing);
 const errors=[];
 const ipc={};
 const windows=[];
 let launchEnv;
 class Window extends EventEmitter{
  constructor(options){super();this.options=options;this.webContents={setWindowOpenHandler(){},on(){},getURL(){return 'file:///wizard'}};windows.push(this);}
  setMenuBarVisibility(){}
  focus(){}
  loadFile(){return Promise.resolve();}
  loadURL(){return Promise.resolve();}
  close(){this.emit('closed');}
 }
 const electron={
  app:{isPackaged:true,getPath:()=>userDir,getAppPath:()=>path.join(root,'app'),whenReady:()=>Promise.resolve(),on(){},quit(){}},BrowserWindow:Window,
  dialog:{showErrorBox:(title,error)=>errors.push(title+': '+error)},
  ipcMain:{handle:(name,callback)=>ipc[name]=callback},
  Menu:{buildFromTemplate:a=>a,setApplicationMenu(){}},
 };
 const mockedFs=denied?{...fs,writeFileSync:(file,...args)=>{if(file===portableFile){const e=new Error('Access denied');e.code='EACCES';throw e;}return fs.writeFileSync(file,...args)}}:fs;
 const spawn=(exe,args,options)=>{launchEnv=options.env;return new EventEmitter();};
 const mockNet={createServer:()=>({once(){return this},listen(port,_host,cb){this.port=port||59012;cb()},address(){return {port:this.port}},close(cb){cb()}})};
 const processStub={env:{PORTABLE_EXECUTABLE_DIR:portableDir},pid:47321,execPath:path.join(root,'extracted','CALIAN AI.exe')};
 let readyHealth=()=>({status:'ready',instanceId:launchEnv?.CALIAN_INSTANCE_ID,nlAdapterVersion:'8-schema-discovery-speech-playback-v1'});
 const context={require:(n)=>{
  if(n==='electron')return electron;
  if(n==='node:child_process')return {spawn};
  if(n==='node:net')return mockNet;
  if(n==='node:fs')return mockedFs;
  return require(n);
 },__dirname:path.join(__dirname,'../CALIAN_AI_ELECTRON_THEMES/electron'),process:processStub,
 fetch:async()=>({ok:true,json:async()=>readyHealth()}),AbortSignal,URL,setTimeout,console};
 vm.runInNewContext(source,context,{filename:'main.cjs'});
 await new Promise(resolve=>setTimeout(resolve,25));
 return {root,portableFile,userFile:path.join(userDir,'calian.env'),ipc,windows,errors,launchEnv:()=>launchEnv};
}
test('one portable EXE creates calian.env and its first-run wizard saves selected database',async()=>{
 const s=await startup();
 try{
  assert.ok(fs.existsSync(s.portableFile));
  assert.equal(s.windows.length,1,'First-run settings window is shown');
  const event={sender:s.windows[0].webContents};
  const initial=await s.ipc['calian:config:get'](event);
  assert.equal(initial.path,s.portableFile);
  assert.equal(initial.values.CALIAN_SCHEMA_DATABASE,'');
  await s.ipc['calian:config:save'](event,{...initial.values,CALIAN_SCHEMA_DATABASE:'vcci_aug_26_dbg_1'});
  await s.ipc['calian:config:close'](event);
  await new Promise(resolve=>setTimeout(resolve,25));
  assert.equal(s.launchEnv().CALIAN_SCHEMA_DATABASE,'vcci_aug_26_dbg_1');
  assert.ok(fs.readFileSync(s.portableFile,'utf8').includes('CALIAN_SCHEMA_DATABASE=vcci_aug_26_dbg_1'));
  assert.equal(s.windows.length,2,'Main app appears after configuration');
  assert.deepEqual(s.errors,[]);
 }finally{fs.rmSync(s.root,{recursive:true,force:true});}
});
test('existing calian.env is never rewritten and setup wizard is skipped',async()=>{
 const custom='# keep this custom file\nCALIAN_SCHEMA_DATABASE=production_1\nMY_SECRET=unchanged\n';
 const s=await startup({existing:custom});
 try{
  assert.equal(fs.readFileSync(s.portableFile,'utf8'),custom);
  assert.equal(s.windows.length,1);
  assert.equal(s.launchEnv().CALIAN_SCHEMA_DATABASE,'production_1');
  assert.deepEqual(s.errors,[]);
 }finally{fs.rmSync(s.root,{recursive:true,force:true});}
});
test('read-only executable folder falls back to userData, preserving first launch',async()=>{
 const s=await startup({denied:true});
 try{
  assert.ok(fs.existsSync(s.userFile));
  assert.ok(!fs.existsSync(s.portableFile));
  const event={sender:s.windows[0].webContents};
  const initial=await s.ipc['calian:config:get'](event);
  assert.equal(initial.path,s.userFile);
  await s.ipc['calian:config:close'](event);
  await new Promise(resolve=>setTimeout(resolve,25));
  assert.equal(s.windows.length,2);
  assert.deepEqual(s.errors,[]);
 }finally{fs.rmSync(s.root,{recursive:true,force:true});}
});
test('invalid schema name does not overwrite generated configuration',async()=>{
 const s=await startup();
 try{
  const event={sender:s.windows[0].webContents};
  const initial=await s.ipc['calian:config:get'](event);
  const original=fs.readFileSync(s.portableFile,'utf8');
  assert.throws(()=>s.ipc['calian:config:save'](event,{...initial.values,CALIAN_SCHEMA_DATABASE:'database-name;DROP TABLE users'}),/Database name/);
  assert.equal(fs.readFileSync(s.portableFile,'utf8'),original);
  await s.ipc['calian:config:close'](event);
 }finally{fs.rmSync(s.root,{recursive:true,force:true});}
});
