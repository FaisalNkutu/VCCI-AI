@echo off
setlocal
cd /d "%~dp0CALIAN_AI_ELECTRON_THEMES" || (echo Missing frontend directory & exit /b 1)
where node >nul 2>&1 || (echo Node.js is required. & exit /b 1)
echo Checking intelligent multi-agent orchestration behavior...
node --test server\tests\agent-chain.test.mjs
if errorlevel 1 (echo FAIL: Agent orchestration tests. & pause & exit /b 1)
echo PASS: Agent orchestration tests.
pause
endlocal
