@echo off
call "%~dp0BUILD-CALIAN-WINDOWS.bat"
