CALIAN.AI V8 — Electron startup repair (20 November 2026)

Symptom:
    CALIAN V8+Voice backend failed to start at http://127.0.0.1:<random port>.
    The app will not attach to an older server.

Root cause in the prior Dynamic Schema + Spoken Results source ZIP:
    Electron's main.cjs expected nlAdapterVersion = 8-reqa-web-ui-whisper-v2
    while the actual /api/health response reported
    nlAdapterVersion = 8-schema-discovery-speech-playback-v1.
    Therefore the old launcher rejected its own healthy backend.

Fix:
    - Accept ready V8 backends while retaining the per-process random instance ID
      check, which prevents accidental attachment to an older process.
    - Log backend startup output to backend-startup.log in Electron's userData
      directory. Future startup errors show that log's path in the dialog.
    - All existing REQA, MariaDB/DBAgent, A2A, Whisper, dynamic schema, spoken
      results, mobile access, and SQL routing implementation files are unchanged.

Build on Windows:
    1. Extract this ZIP into a NEW folder; keep your previous installation intact.
    2. Double-click BUILD-CALIAN-WINDOWS.bat in the extracted root.
    3. Run the NEW executable from CALIAN_AI_ELECTRON_THEMES\release.
    4. If startup still fails, use the log path shown in the error dialog and
       share its last 20-30 lines. Never paste secrets from configuration files.

For code review: one functional source file was changed:
    CALIAN_AI_ELECTRON_THEMES\electron\main.cjs

Validation performed outside Windows:
    - node --check main.cjs: PASS
    - mocked Electron startup accepting current V8 /api/health: PASS
    - ZIP integrity and comparison of other original source files: PASS
    - Live Windows executable build not performed in this environment.
