@echo off
setlocal
cd /d "%~dp0VIDEO_CALL_SERVICE" || (echo VIDEO_CALL_SERVICE not found. & pause & exit /b 1)
where node >nul 2>&1 || (echo Node.js 20 or later is required on the VIDEO GATEWAY host. & pause & exit /b 1)
where npm >nul 2>&1 || (echo npm not found. & pause & exit /b 1)
if not exist .env (echo ERROR: Copy your EXISTING private .env into VIDEO_CALL_SERVICE first. & pause & exit /b 1)
echo Installing the updated group video gateway dependencies...
call npm install --no-audit --no-fund
if errorlevel 1 (echo npm install failed. & pause & exit /b 1)
echo.
echo IMPORTANT: Stop the OLD VIDEO_CALL_SERVICE first if it is still listening on port 9443.
echo Starting the UPDATED group gateway. Keep this window open.
echo.
call npm start
if errorlevel 1 (echo The gateway exited with an error. Check the messages above.)
pause
