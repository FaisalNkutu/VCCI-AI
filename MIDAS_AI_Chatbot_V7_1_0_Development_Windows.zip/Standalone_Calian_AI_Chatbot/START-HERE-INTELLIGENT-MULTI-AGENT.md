# CALIAN V8 — Intelligent Multi-Agent Orchestration (CIMAO)

## What is implemented

The existing Angular/Electron **Agent Conversation → Intelligent Auto Select** mode now defaults to **Intelligent multi-agent chain (automatic handoffs)**. It can:

1. Discover registered executable AI Core/Paradigm agents and the existing local Ollama agent from the **server-side** registry.
2. Ask the configured local Ollama model to plan the minimum necessary ordered chain of distinct specialists, or fall back to Calian's existing agent router if planning fails.
3. Execute tasks with the existing `/api/ai-core/execute` and `/api/ollama/chat` paths. DBAgent continues to use the existing read-only SQL/NL-to-SQL adapter.
4. Pass previous agent results as explicitly labeled *untrusted data*, not instructions, to subsequent specialists.
5. Evaluate whether another unused specialist is needed, with at most four steps by default (hard limit five), and synthesize one answer where more than one agent succeeds.
6. Display the **Agent execution trace**, including completed, failed, and blocked steps. Incomplete answers are labeled partial/unverified.
7. Keep the existing **Manual agent selection** and **Test auto-selection only** modes.

**Not implemented:** The Python router's non-Ollama A2A execution is not available in the supplied backend (`/api/a2a` returns HTTP 503). Such Python-only agents are deliberately excluded from the new executor. It does not invent upstream endpoints. This upgrade does not build or deploy a public Web/SSO guest portal.

## Safety and limits

- Only trusted server-discovered/explicitly configured agent IDs can be invoked; the browser cannot specify an execution endpoint or invent agents.
- Automatically proposed actions that may mutate data, send messages, publish, deploy or make payments are rejected. Manual mode remains separate. All auto-mode DBAgent operations still pass the existing read-only SQL controls.
- A failing agent is recorded in the trace. A remaining planned specialist can still attempt its safe task, but partial answers are never labeled complete.
- A requested agent cannot be invoked repeatedly in a single chain. Limit: `CALIAN_CHAIN_MAX_STEPS=4` (1–5), overall budget about 165 seconds, per-tool call bounded by the remaining budget.
- Previous agent output is untrusted, and no agent chain bypasses the application's existing API authorization rules. Do **not** publish the existing private Node bridge to external invited users without implementing employee sign-in, role checks, guest authorization, abuse limits, and per-agent permissions.
- Agent handoffs are chosen by an LLM; they may not always be the optimal plan. Verify consequential output against the sources.

## Build on your Windows computer

1. Extract the ZIP to a **new folder**, keeping your previous working executable and its `calian.env` as a backup.
2. Keep your existing local Ollama, AI Core and DBAgent services running as before. Use the same private `calian.env` settings; **do not copy private secrets into source or share them**.
3. Run `BUILD-CALIAN-WINDOWS.bat`. It installs JavaScript dependencies, runs orchestration and existing SQL/video regression tests, then uses Electron Builder to create a portable Windows executable.
4. The resulting executable appears in `DELIVER_TO_FOUAD\CALIAN.AI.exe` (assuming the build succeeds). It creates/uses `calian.env` just as the prior portable version did.
5. In the app, select **Intelligent Auto Select**. Leave **Intelligent multi-agent chain (automatic handoffs)** checked and **Test auto-selection only** unchecked. Ask a compound question, for example: “Retrieve the latest authorized sales summary, write a short management report, and translate it into French.” The trace appears below the final response.
6. If you want only the original router behavior, uncheck **Intelligent multi-agent chain**. If you want to select a particular agent yourself, use Manual agent selection in the sidebar.

## Tests without a Windows build

From `CALIAN_AI_ELECTRON_THEMES`:

```powershell
node --test server/tests/agent-chain.test.mjs
node server/test-select-english-routing.cjs
node scripts/test-multi-room-management.cjs
node scripts/test-multi-room-behavior.cjs
node scripts/verify-group-call-routing.cjs
node scripts/test-group-gateway-compatibility.cjs
```

The second through sixth scripts require normal `npm install` dependencies. Windows build also requires Node.js, npm, and network access to install packages and Electron binaries.

## Files changed

- `CALIAN_AI_ELECTRON_THEMES/server/agent-chain.mjs`, `.d.mts`: bounded orchestration engine
- `CALIAN_AI_ELECTRON_THEMES/server/index.ts`: private `/api/orchestration/execute` route; trusted registry, existing agent execution, JSON/SSE support, WebSocket allowlist
- `CALIAN_AI_ELECTRON_THEMES/src/app/app.component.{ts,html,scss}`: automatic mode, chain trace and partial-result status
- `CALIAN_AI_ELECTRON_THEMES/src/app/protocol.ts`: trace metadata
- `CALIAN_AI_ELECTRON_THEMES/server/tests/agent-chain.test.mjs`: offline behavior tests
- `BUILD-CALIAN-WINDOWS.bat`: gate Windows build on orchestration tests
- `CALIAN_AI_ELECTRON_THEMES/.env.example` and Electron first-run defaults: `CALIAN_CHAIN_MAX_STEPS=4`

**Preserved unchanged:** Video gateway source, group-meeting components, one-to-one calling path, SQL translator, REQA pipeline, and the existing AI Core execution contract.

## Known verification limitations

Source and offline tests can prove routing/guardrail behavior, not real agent availability, correctness of the agent responses, or a working cross-device LiveKit connection. Test using your Windows installation and actual configured backend services before distributing the executable.
