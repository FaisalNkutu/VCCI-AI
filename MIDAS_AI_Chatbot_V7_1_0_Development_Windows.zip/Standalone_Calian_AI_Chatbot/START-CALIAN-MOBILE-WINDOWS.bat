@echo off
setlocal
cd /d "%~dp0"
where powershell.exe >nul 2>&1 || (echo PowerShell is required. & pause & exit /b 1)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0START-CALIAN-MOBILE-WINDOWS.ps1"
if errorlevel 1 (echo. & echo Mobile startup failed; see the error above. & pause & exit /b 1)
pause
