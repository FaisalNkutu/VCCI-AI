$ErrorActionPreference = 'Stop'
$project = Join-Path $PSScriptRoot 'CALIAN_AI_ELECTRON_THEMES'
if (-not (Test-Path -LiteralPath (Join-Path $project 'package.json'))) { throw 'CALIAN project folder was not found.' }
if (-not (Get-Command node.exe -ErrorAction SilentlyContinue)) { throw 'Install Node.js 20 or newer first.' }
if (-not (Get-Command npm.cmd -ErrorAction SilentlyContinue)) { throw 'npm.cmd was not found.' }
# Tailscale Serve keeps CALIAN private to devices explicitly joined to the tailnet.
$tsCommand = Get-Command tailscale.exe -ErrorAction SilentlyContinue
if ($tsCommand) { $ts = $tsCommand.Source } else {
 $ts = Join-Path $env:ProgramFiles 'Tailscale\tailscale.exe'
 if (-not (Test-Path -LiteralPath $ts)) { throw 'Install Tailscale on this Windows PC and sign in. Also install Tailscale on the phone. See START-HERE-ANDROID-IPHONE.md.' }
}
$statusText = & $ts status --json
if ($LASTEXITCODE -ne 0) { throw 'Tailscale is not connected. Open the Tailscale app and sign in.' }
$status = $statusText | Out-String | ConvertFrom-Json
$dns = ([string]$status.Self.DNSName).TrimEnd('.')
if (-not $dns -or $dns -notmatch '\.ts\.net$') { throw 'Could not find the private Tailscale DNS name. Turn on MagicDNS and HTTPS in your tailnet.' }
$origin = 'https://' + $dns
$port = 8798
Set-Location -LiteralPath $project
# Reuse per-user configuration from the desktop executable when available.
# Never log credentials, passwords, or API tokens.
$configCandidates = @((Join-Path $project '.env'), (Join-Path $project 'release\calian.env'))
foreach ($configPath in $configCandidates) {
 if (Test-Path -LiteralPath $configPath) {
  foreach ($line in [System.IO.File]::ReadAllLines($configPath)) {
   if ($line -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$') {
    $key = $matches[1]; $value=$matches[2].Trim().Trim('"').Trim("'")
    if (-not [Environment]::GetEnvironmentVariable($key,'Process')) { [Environment]::SetEnvironmentVariable($key,$value,'Process') }
   }
  }
 }
}
if (-not (Test-Path -LiteralPath (Join-Path $project 'node_modules'))) {
 Write-Host 'Installing CALIAN dependencies (first time only)...'
 & npm.cmd install --no-audit --no-fund
 if ($LASTEXITCODE -ne 0) { throw 'npm install failed.' }
}
Write-Host 'Building the shared Angular UI and Node backend (no changes to Docker or Fouad services)...'
& npm.cmd run build:desktop
if ($LASTEXITCODE -ne 0) { throw 'CALIAN build failed.' }
$env:PORT = [string]$port
$env:CALIAN_STATIC_DIR = Join-Path $project 'dist\calian\browser'
$env:CALIAN_PUBLIC_ORIGIN = $origin
if (-not (Test-Path -LiteralPath (Join-Path $env:CALIAN_STATIC_DIR 'index.html'))) { throw 'Angular build output is missing.' }
Write-Host 'Enabling PRIVATE HTTPS access through Tailscale Serve...'
& $ts serve --bg $port
if ($LASTEXITCODE -ne 0) { throw 'Tailscale Serve failed. It may ask you to enable HTTPS in the Tailscale admin console.' }
Write-Host ''
Write-Host '=========================================='
Write-Host 'CALIAN.AI MOBILE (Android + iPhone)' -ForegroundColor Cyan
Write-Host 'PRIVATE HTTPS URL:' -ForegroundColor Green
Write-Host $origin -ForegroundColor Green
Write-Host 'Open it in Safari (iPhone) or Chrome (Android) with Tailscale connected.'
Write-Host 'Then choose Add to Home Screen / Install app.'
Write-Host 'Keep this PowerShell window and your backend services running.'
Write-Host 'Stop with Ctrl+C. Tailscale Serve may remain configured until you run: tailscale serve --https=443 off' -ForegroundColor Yellow
Write-Host '=========================================='
Write-Host ''
& node.exe (Join-Path $project 'dist\backend.cjs')
if ($LASTEXITCODE -ne 0) { throw "Node backend stopped with error $LASTEXITCODE" }
