# CALIAN.AI V8 — automatic active-database selection fix

## What the screenshots demonstrated

- Direct read-only SQL **works**, proving the database tool can execute your SELECT statements.
- The V8 English-to-SQL resolver sees tables in **multiple accessible MariaDB databases**. Since the same table name exists more than once, it correctly refuses to guess which database you meant.
- The old resolver did not ask the database driver which database was selected, even though a direct unqualified SELECT already uses one. This release fixes that **inside CALIAN.AI**; it does not change Fouad's Docker image.

## Changes

1. Check the active schema with `SELECT DATABASE() AS current_database;` through the very same read-only `execute_sql` bridge. This is narrowly permitted in the CALIAN-owned SQL safety validator; arbitrary function calls remain blocked.
2. Search only that schema's `INFORMATION_SCHEMA.TABLES` catalog. SQL generation uses qualified `database.table` identifiers and validates the table name.
3. Cache metadata by connection **and database**, preventing one selected database's table list leaking into the next.
4. If the MCP backend blocks `DATABASE()` or no default schema exists, keep the safe no-guess behavior. To resolve duplicate names, either provide `database.table` or use the optional selector below.
5. Literal SQL still uses exactly the existing direct REQA MCP `execute_sql` pipeline. The UI, speech, spoken answers, A2A, and REQA API remain unchanged.

## Installation

1. Unzip into a **new** directory (keep your working build as a fallback).
2. Run `BUILD-CALIAN-WINDOWS.bat` once, then start the new executable in `CALIAN_AI_ELECTRON_THEMES\release`.
3. Ask: `Show me 10 records from the context O I association table.`
4. If it still reports several accessible databases, run `SET-CALIAN-DATABASE-WINDOWS.bat` and enter the database displayed in HeidiSQL (for example `vcci_aug_26_dbg_1`). Restart the executable. The script writes `CALIAN_SCHEMA_DATABASE=...` to `calian.env` next to the portable .exe, backing up existing configuration. **Do not edit Docker or REQA**.
5. If SQL still fails, compare the database name and table name from the CALIAN-generated SQL with HeidiSQL, and copy the exact error response for diagnosis.

Important: This is a **source release**. A full Windows Electron build and live database connection have not been tested here. The new active-database detection logic has passed mock-backed tests. A successful direct SQL request does **not** prove that a different English request passed until it returns real rows.
