# CALIAN.AI V8 — Multiple named group meeting rooms

This update extends the **LiveKit group meeting** view of the CALIAN.AI Electron desktop app while retaining **Call a Person** (original 1:1 WebRTC) and **Talk to AI**.

## What the new Group Meetings screen supports

- Create up to **10 simultaneous hosted group meeting rooms from one open Calian desktop window**, each with a **separate name, invite URL, waiting list, host approval, and End button**.
- Each room supports **10 participants total**, including its host, through the public VIDEO_CALL_SERVICE gateway and LiveKit Cloud.
- Select a room in the left list. Host camera/microphone are sent **only to the currently selected room**, never to several rooms at once. Non-selected rooms stay alive and guests can talk to each other while the host manages another meeting; requests from other rooms appear as counts in the list. To broadcast to a room, select it.
- Invite guests to different rooms independently. New name appears to the guest after redeeming the room invitation.
- End a single meeting without terminating others, or End all.
- The gateway itself still enforces its own **100 active-meeting global maximum**, invitation expiry (60 minutes in this build), rate limits, and your LiveKit plan's actual capacity. The *desktop room manager* caps one window at 10 concurrently hosted rooms to protect client performance. That is not 100 rooms in a single Electron window.
- **Navigating away from Live Video, switching to the AI/one-to-one video tab, or closing the app ends groups hosted by that window.** These are *live room sessions*, not permanent persistent channels. Reopen and recreate to host later. The UI explicitly warns of this behavior.

## Installation — Windows

1. Preserve the existing working installation and portable executable as a backup. Extract this ZIP to a new folder; do not overwrite the old working EXE before successful testing.
2. Copy the **existing private** `VIDEO_CALL_SERVICE\.env` from the *actual host* to the new `VIDEO_CALL_SERVICE` directory. This ZIP does **not** include credentials. Keep your own `calian.env` settings for the private chatbot/backend as well. Never paste secrets into chat or a public screenshot.
3. Stop the old public video gateway, then start the updated one using `START-UPDATED-VIDEO-GATEWAY-WINDOWS.bat` (on the machine that serves the real public HTTPS video domain). If the public gateway is hosted remotely, deploy this updated VIDEO_CALL_SERVICE *there*. Running an updated local gateway while a previous gateway still handles public requests will not resolve old-protocol behavior.
4. On that host, run `VERIFY-GROUP-CALLS-WINDOWS.bat`. Both **local** and **public** `/health` must indicate `protocolVersion=calian-livekit-group-v2` and `groupCallsConfigured=True` before testing. This check doesn't show secrets.
5. On your Windows **build machine**, run `BUILD-CALIAN-WINDOWS.bat` from the package root. It installs dependencies, runs pre-build checks, and creates a new portable **`DELIVER_TO_FOUAD\CALIAN.AI.exe`**. It does not bundle your separate public video service or LiveKit credentials. Node.js and npm are needed on the build machine; the intended target executable is portable.
6. Start the **new** executable, open **Live Video → Group Meetings (10/room)**, type a name such as `Engineering`, and click **Create meeting room**. Copy the link. Create `Training`, then `Operations` the same way. Guests use their individual HTTPS links.
7. Admit a guest from the relevant room, switch between groups, and confirm camera/microphone are active **only in the selected room**. The LiveKit Cloud Sessions dashboard should show participants for working sessions.
8. Check **Live Video → Call a Person** to confirm the original one-on-one calling flow still works.

## Debugging and safety

If a group room fails with an *older video gateway* or *no LiveKit group-join credentials* error, recheck the actual public gateway version and `VIDEO_CALL_SERVICE\.env`. In prior user screenshots a `rooms` response lacked `mode` and `maxParticipants`; this is evidence the earlier public service was still running. `VIDEO_PUBLIC_ORIGIN` is the gateway's external HTTPS origin, **not** the LiveKit `wss://...livekit.cloud` URL. Group-room guest browser code still uses the LiveKit service; direct person-to-person calls continue using the original WebRTC/ICE flow.

Each invitation grants entry to a waiting room and is time-limited. Never share API secrets, host tickets, or access tokens; rotate invitations if publicly exposed. Closing this Electron window ends hosted sessions; an interrupted public gateway can leave a room on the server until it expires.

## Files changed

- `CALIAN_AI_ELECTRON_THEMES/src/app/group-meetings.component.{ts,html,scss}` — new standalone multi-room manager.
- `CALIAN_AI_ELECTRON_THEMES/src/app/video-center.component.{ts,html}` — mount the group manager, without changing the person-to-person workflow.
- `CALIAN_AI_ELECTRON_THEMES/server/video-routes.ts` — forward the public group room's friendly name.
- `VIDEO_CALL_SERVICE/server.mjs` and `VIDEO_CALL_SERVICE/public/{guest.js,guest.html}` — keep a separate server-side room name and show it after guest joins.
- `CALIAN_AI_ELECTRON_THEMES/scripts/test-multi-room-{management,behavior}.cjs` and `scripts/verify-group-call-routing.cjs` — multi-room regression checks.
- `BUILD-CALIAN-WINDOWS.bat` — add the multi-room checks to the existing Windows EXE build.

## Verification performed in this environment

**Passed**: TypeScript transpilation syntax of modified files, Node syntax of the gateway/guest, gateway backward-compatibility route check, multi-room source invariants, and a mocked behavioral test that creates 2 independent rooms, isolates approvals, switches host audio/video publication, and ends rooms separately.

**Not validated here**: Angular compiler/full Windows `.exe` build, physical two-laptop cameras/microphones, actual LiveKit Cloud connections, networking/Funnel/TURN, or your public gateway configuration. Those must be tested on your Windows hardware and public service. No working public calling claim is made until those tests pass.
