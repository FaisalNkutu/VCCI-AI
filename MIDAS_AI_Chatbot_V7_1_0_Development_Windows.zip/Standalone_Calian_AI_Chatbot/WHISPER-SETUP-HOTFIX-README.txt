CALIAN.AI V8 - WHISPER SETUP HOTFIX
====================================
Fixes a Windows PowerShell failure on paths such as C:\Users\FD3A6~1.NKU.
The original setup used $env:TEMP and could fail during Remove-Item cleanup.

IF YOU HAVE ALREADY BUILT THE V8 EXECUTABLE:
  1. Copy the included SETUP-ACCURATE-SPEECH-WINDOWS.ps1 over the old file in
     your current extracted V8 folder.
  2. Double-click SETUP-ACCURATE-SPEECH-WINDOWS.bat in that same folder.
  3. You do NOT need to rebuild solely to run the repaired installer.

IF YOU WANT THE EXTRA SPEECH RUNTIME TEMP-FILE SAFEGUARD:
  Extract this full fixed ZIP to a new folder; build with BUILD-CALIAN-WINDOWS.bat;
  then run SETUP-ACCURATE-SPEECH-WINDOWS.bat once.

Updates only: setup PowerShell script and CALIAN speech-whisper.ts temporary
recording folder handling. All V8 REQA, DBAgent, direct SQL, and A2A files
remain identical to the earlier V8 Whisper release.

NOTE: Whisper is downloaded on your computer and requires internet for setup.
This package has not been tested end-to-end on a real Windows microphone.
