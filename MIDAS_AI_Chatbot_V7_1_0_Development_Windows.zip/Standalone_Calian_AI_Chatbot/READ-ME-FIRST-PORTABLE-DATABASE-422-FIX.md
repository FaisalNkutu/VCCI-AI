# CALIAN.AI V8 — Portable database selection: HTTP 422 fix

## What the screenshot shows

The DBAgent adapter discovers multiple accessible MariaDB schemas containing a
matching table name and correctly refuses to guess which to use. This error is
NOT caused by Whisper, SQL syntax, or a broken DBAgent connection.

## Root cause of the persistent error

On Windows, electron-builder's **portable** executable extracts an inner
application executable under a temporary folder. The previous Electron launcher
looked for `calian.env` beside `process.execPath`, the **temporary executable**.
The included `SET-CALIAN-DATABASE-WINDOWS.bat` script, however, correctly wrote
`calian.env` beside the **downloaded portable .exe** in `release`. Consequently,
the database selection was invisible to the running app.

## Exact fix

`electron/main.cjs` now reads the official `PORTABLE_EXECUTABLE_DIR` (or the
directory of `PORTABLE_EXECUTABLE_FILE`), using that location for `calian.env`.
The selected portable-exe config takes precedence over stale fallback settings.
The backend log now prints `CALIAN configured schema: ...` (schema name only).

## Windows instructions (no Docker or REQA changes)

1. Extract this source ZIP into a **new** directory. Keep your old working version.
2. Run `BUILD-CALIAN-WINDOWS.bat` to rebuild the corrected portable executable.
3. Run `SET-CALIAN-DATABASE-WINDOWS.bat` in the extracted top-level directory.
4. Enter the MariaDB database you intend to query. From your HeidiSQL screenshot,
   that appeared to be `vcci_aug_26_dbg_1` (confirm on your machine).
5. The script writes `CALIAN_SCHEMA_DATABASE=<your selection>` into
   `CALIAN_AI_ELECTRON_THEMES\release\calian.env`, next to the new .exe.
6. **Close all running CALIAN.AI windows** and start the newly rebuilt `.exe`.
7. Say `How many records are in the context O I association table?`

## Test directly (before natural language)

    SELECT COUNT(*) AS total_records FROM `vcci_aug_26_dbg_1`.`contxt_oi_assoc`;

This explicit SQL should succeed only if the configured REQA database connection
can access the indicated schema and table. The name above comes from the user's
prior HeidiSQL screenshot; substitute the actual database name as needed.

## Diagnostics

If the error persists, inspect the CALIAN backend log at the Electron userData
folder, typically `%APPDATA%\calian-ai\backend-startup.log` (the exact path
is shown by startup errors). Check the `CALIAN configured schema:` line.

When multiple accessible databases have the same table, selecting a database once
per SQL connection is necessary: CALIAN must not guess or execute against a
random schema. The selector changes only local CALIAN configuration, not a
Docker container or Fouad's database model.

## What was NOT changed

REQA, DBAgent, MariaDB, Whisper, spoken output, automatic table matching,
SQL execution, A2A, Ollama, and Windows build commands remain intact.

## Verification limitations

Node syntax and mocked portable path tests were performed here. A full Windows
build and live connection test must be performed on your PC.
