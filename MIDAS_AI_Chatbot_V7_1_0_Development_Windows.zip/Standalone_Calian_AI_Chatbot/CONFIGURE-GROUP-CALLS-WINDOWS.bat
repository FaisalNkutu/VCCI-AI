@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0CONFIGURE-GROUP-CALLS-WINDOWS.ps1"
if errorlevel 1 (echo LiveKit configuration failed. & pause & exit /b 1)
pause
