# CALIAN.AI V8 — Dynamic Schema Speech-to-SQL + Spoken Results

This release is based on **Standalone_Calian_AI_Chatbot_V8_Mobile_Speech_Accuracy_Update**. It retains the desktop Electron interface, the Android/iPhone installable web interface (PWA), Whisper microphone input, all four themes, AI Core, Ollama routing, existing direct-SQL access, A2A, and the REQA API files.

## What changed

1. **No hardcoded model-specific table catalog.** For English database requests, CALIAN.AI uses the existing read-only `execute_sql` bridge to retrieve accessible table names from `INFORMATION_SCHEMA.TABLES`. Metadata is cached for **2 minutes** and refreshed if no match is found.
2. **Spoken names resolve against real metadata.** Generic abbreviation/phonetic normalization helps match e.g. "context O I association" to `contxt_oi_assoc`. If the best match is weak or ambiguous, the app asks for clarification: no SQL is guessed or executed.
3. **Simple count / list requests do not need an LLM.** The adapter generates a read-only `SELECT COUNT(*)` or `SELECT ... LIMIT N` from the verified table. For filtered / sorted / aggregate single-table questions, Ollama receives the verified column names, returns a JSON plan, and the local adapter compiles permitted read-only SQL. It rejects invented columns and unsafe operations.
4. **Responses can be spoken aloud.** An assistant message offers **Read results** (summary/first 3 records), **Read details** (up to 10 records), and **Stop reading**. The **Read answers aloud** checkbox is off by default, for privacy and browser compatibility. The voice is provided by the Windows/Android/iPhone browser/system, not by Whisper; Whisper remains speech-to-text only.
5. **The mobile PWA service worker has a new cache key.** After upgrading the Windows host, reopen/reload the mobile app so it fetches the latest UI.

## Install / build

1. Unzip **into a NEW folder**, preserving your working copy.
2. On Windows run `BUILD-CALIAN-WINDOWS.bat` and start the new executable from `CALIAN_AI_ELECTRON_THEMES\release`.
3. Existing Docker container `reqa-api`, its **MCP `execute_sql` tool**, database connectivity, and appropriate `INFORMATION_SCHEMA` access must already be working. Existing Ollama + AI Core remain as before.
4. For mobile access, use `START-CALIAN-MOBILE-WINDOWS.bat` on the Windows host, with your existing private HTTPS / Tailscale setup. On the phone, close and relaunch the home-screen app; refresh once if it shows the previous interface.
5. No changes to Fouad's Docker image or Python code are required.

## Voice test

* Turn on **Technical terms** if Whisper routinely mishears specialized table names.
* Click **Speak**, say "Show me ten records from the context O I association table", then click **Stop**. Verify the transcript and press **Send**.
* The answer should show `Resolved table: <schema>.contxt_oi_assoc`, generated read-only SQL containing `LIMIT 10`, and returned rows.
* Press **Read results** to hear a brief answer. Press **Read details** to hear up to 10 rows; press **Stop reading** to silence it.
* Say "How many records are in the context O I association table?" to test `COUNT(*)` and a spoken count.
* On iPhone, automatic speech playback may be restricted; tap **Read results** manually if needed.

## Multiple database models

The schema is discovered at runtime, not written into the CALIAN source. This **does not require a code change when tables are added, renamed, or a different accessible MariaDB database is selected**. The adapter first asks the *same read-only execute_sql connection* which database is currently selected using `SELECT DATABASE()`. It limits discovery to that schema. If the connection has no selected database (or the MCP blocks that safe metadata call), duplicate names are never guessed: say/enter `database_name.table_name`, or set `CALIAN_SCHEMA_DATABASE=your_database` in `calian.env` next to the portable Windows EXE (or `.env` in development). A changed selection is picked up after restarting the backend. You never need to edit table-specific mappings.

**Current engine support is MariaDB/MySQL through the existing local `reqa-api` MCP/Docker bridge.** PostgreSQL, SQL Server, Oracle, etc. will require a separate read-only metadata/execution adapter for that database engine; no claim is made that those engines work out of the box.

The metadata query requires read access to `INFORMATION_SCHEMA.TABLES` / `INFORMATION_SCHEMA.COLUMNS`. Some DB security policies may deny metadata. In that case the UI reports the limitation; it does not run speculative SQL. To opt into the old REQA English fallback for unresolved questions, set `CALIAN_DB_FALLBACK_TO_REQA=true` in the CALIAN backend environment. **Default is false**, because a failed REQA schema grounding step should not be silently hidden.

## Source changes (CALIAN-only)

- `server/schema-aware-sql.ts` — new discovery, spoken-name matching, deterministic read-only SQL, metadata-based LLM plan
- `server/index.ts` — calls the adapter for English requests, preserves existing literal SQL and agent/A2A branches
- `src/app/result-speech.ts` — new concise spoken summaries
- `src/app/app.component.{ts,html,scss}` + `src/app/protocol.ts` — answer read-back controls
- `public/sw.js` — mobile cache refresh

No modifications to `server/direct-sql.ts`, `server/reqa-web-query.ts`, `server/db-a2a-dispatch.ts`, Whisper, Python A2A, or Fouad's Docker image. Two pre-existing missing imports in `server/index.ts`'s legacy A2A fallback branch were restored to avoid build errors.

## Verification

Run `npx tsx server/test-schema-tts.mjs` after `npm install` inside `CALIAN_AI_ELECTRON_THEMES` for unit tests. The publisher checked TypeScript syntax and mocked schema-matching and spoken-response tests. A complete Windows Electron build, microphone operation, live database metadata permissions, and real device audio are **not verified** in the publisher's environment; test with your setup and preserve the older working folder.
