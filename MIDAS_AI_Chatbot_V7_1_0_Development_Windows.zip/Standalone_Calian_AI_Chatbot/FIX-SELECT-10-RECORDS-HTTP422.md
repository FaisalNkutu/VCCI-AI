# CALIAN.AI V8 Live Video: HTTP 422 for “Select 10 records...”

## Cause
In the original video-enabled V8 source, both `classifyDbInput()` and `isDirectSql()` classified **every** message starting with `SELECT` as executable SQL. Thus the spoken English instruction

> Select 10 records from the table contxt_oi_assoc

was submitted directly to the REQA MCP `execute_sql` tool, which rejected its English tokens with `Invalid expression / Unexpected token` (HTTP 422).

## Repair
The two functions now use a shared classification rule:

- Spoken instructions such as **Select 10 records from the table...**, **Select ten rows...**, and **Select all records...** are treated as **natural-language requests**, passed through the existing verified-schema discovery, and translated into read-only SQL.
- Literal statements such as `SELECT * FROM ... LIMIT 10;`, `SELECT COUNT(*) ...`, and SQL CTEs still use the original direct SQL execution route.
- Unsafe SQL commands remain blocked by the existing validator.
- Spoken names are matched only to available schema metadata. Ambiguous names remain blocked.

This is a small CALIAN application fix. No Docker image, REQA API, DBAgent, database schema, video call service, or SQL executor was modified.

## Build on Windows
1. Keep your previous working `release` folder as a backup.
2. Extract the entire new ZIP to a **new folder**.
3. Run `BUILD-CALIAN-WINDOWS.bat`. It performs the dependency installation and produces a portable executable.
4. Copy your **working `calian.env`** into the newly built `CALIAN_AI_ELECTRON_THEMES\release` folder (especially the `CALIAN_SCHEMA_DATABASE=...` setting).
5. Start **the new** `release\CALIAN AI 1.0.0.exe`.

## Verify
Run the same tests without editing the English question into SQL:

1. Say or type: `Select 10 records from the table contxt_oi_assoc`.
   - Expected SQL: `SELECT * FROM `vcci_aug_26_dbg_1`.`contxt_oi_assoc` LIMIT 10;` (if that is the selected database and table exists).
2. Type: `SELECT * FROM `vcci_aug_26_dbg_1`.`contxt_oi_assoc` LIMIT 10;`.
   - This must still execute directly.
3. Test **Live Video** independently; the video files are unchanged.

If your selected database is different, the generated SQL will be qualified with *that* verified database, rather than hardcoding the example.

After `npm install`, an optional local routing test is available:

`cd CALIAN_AI_ELECTRON_THEMES && node server/test-select-english-routing.cjs`

## Verification limits
The patched source passed local simulated routing and schema-discovery tests. The complete Electron/Windows executable build and the real Docker/REQA database call must be verified on your computer.
