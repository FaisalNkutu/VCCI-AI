# CALIAN.AI V7 — Direct REQA MCP ExecuteSQL bridge

## Why V7 differs from V3–V6

We found the actual `execute_sql` implementation in REQA's existing `mcp_servers/database_server.py` and a prior working CALIAN-only adapter that invokes it with `docker exec -i reqa-api python -c ...`.

V6 forwarded all SQL through the A2A `message/send` interface; A2A sometimes chose `GenerateSQL` and modified valid SELECT queries. V7 bypasses that non-deterministic skill choice **for DBAgent only**.

- Direct `SELECT` or `WITH ... SELECT` → Node backend → local Docker CLI → existing `reqa-api` MCP `call_tool('execute_sql',...)` → MariaDB. No GenerateSQL.
- English count/list question → existing local translator → the **same** MCP execution function.
- More complex single-table English questions → schema retrieved through `execute_sql` → Ollama JSON plan → checked SQL → same execution function.
- All non-DBAgent agents retain existing routing and A2A behavior.

No Docker images/containers or Python code are edited by V7. It **executes** the existing tool inside the already running REQA API container. Docker Desktop/CLI must be installed and accessible to the Electron backend. Default container: `reqa-api`; optional `CALIAN_SQL_DOCKER_CONTAINER` overrides it.

## Install

1. Extract into a **separate folder** and leave the working version untouched.
2. From extracted root, run `BUILD-CALIAN-WINDOWS.bat` (Node + npm required).
3. Close older CALIAN.AI windows; run the newly built Windows executable from `CALIAN_AI_ELECTRON_THEMES\release`.
4. Keep `reqa-api` running in Docker. No need to rebuild or restart it.

## Tests (in the GUI, DBAgent selected)

- `SELECT * FROM contxt_oi_assoc LIMIT 10` — expect `used_skill: execute_sql`, `Success: true`, 1 row from the known sample.
- `Show me 10 records from contxt_oi_assoc.` — expect `Generated read-only SQL` and the same rows.
- `How many records are in contxt_oi_assoc?` — expect SQL with `COUNT(*)` and the returned count.

**Verification performed:** local client routing, SQL generation, and mocked Docker CLI tool tests. The live REQA container/DB is not accessible from this build environment; please verify on your Windows machine.

## Safety and deployment

CALIAN validates read-only SQL in a separate Python process using the sqlglot module already included in REQA; only one SELECT expression and restricted functions are allowed. No writes/DDL allowed. REQA's underlying MCP function itself is not a security boundary; for deployment, use a SELECT-only DB account. The bridge depends on local Docker CLI access and is intended for the user's local Windows workstation; do not expose CALIAN's backend over the network.

## Troubleshooting

- `Cannot start Docker CLI`: Docker CLI is not on the Windows PATH seen by the executable.
- `No such container: reqa-api`: set `CALIAN_SQL_DOCKER_CONTAINER` to actual running container name.
- `SQL contains ...`: the client rejected SQL as unsafe; no database query was sent.
- Error connecting to database: review existing REQA container/db connectivity; V7 does not change it.

Rollback: close V7 and launch your previous working executable. No Docker changes to revert.
