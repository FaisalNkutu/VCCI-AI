@echo off
setlocal
cd /d "%~dp0"
echo Installing high-accuracy OFFLINE Whisper speech recognition for CALIAN.AI...
echo This downloads a prebuilt Windows speech engine and approximately 460 MB English model.
echo No Docker or Fouad services will be modified.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0SETUP-ACCURATE-SPEECH-WINDOWS.ps1"
if errorlevel 1 (echo SETUP FAILED. See the error above. & pause & exit /b 1)
echo.
echo Whisper is installed. Restart CALIAN.AI and use Speak.
pause
