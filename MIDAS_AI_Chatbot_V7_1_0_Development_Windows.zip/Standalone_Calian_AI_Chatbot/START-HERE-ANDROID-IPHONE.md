# CALIAN.AI V8 — Android and iPhone (installable private web app)

This build preserves the **V8 REQA Web UI/API**, direct SQL via `execute_sql`, Python A2A, AI Core, Ollama, four themes, and local Windows Whisper. The mobile interface is a **PWA (Progressive Web App)**. It is *not* yet an Android APK, iOS IPA, or published store app.

## What runs where

- **Windows PC:** Existing CALIAN Node/Angular backend, AI Core, REQA Docker, Ollama, and local Whisper speech engine. The phone never runs Docker or local models.
- **Android/iPhone:** CALIAN responsive UI, agent selection, chat, editable speech input; accesses Windows over private HTTPS.
- **Tailscale Serve:** Publishes a private HTTPS URL inside *your Tailnet only*. No port forwarding or public website. **Do not use Tailscale Funnel.**

## One-time preparation

1. Install [Tailscale](https://tailscale.com/download) on your Windows PC and on each phone; sign in to **the same Tailnet**.
2. Enable **MagicDNS** and **HTTPS certificates** for your Tailnet in the Tailscale admin console, if not already enabled. Tailscale Serve may prompt for this itself.
3. Install Node.js 20+ on the Windows computer; make sure your usual **REQA Docker, AI Core, Ollama, and Python A2A** backends are running as in V8 desktop.
4. Make sure the working V8 backend URLs are configured. This launcher reads `CALIAN_AI_ELECTRON_THEMES/.env` or `CALIAN_AI_ELECTRON_THEMES/release/calian.env`, if present. It does **not** alter them.
5. For accurate mobile microphone input, run the previously provided `SETUP-ACCURATE-SPEECH-WINDOWS.bat` on the Windows PC (one-time Whisper installation). No Whisper installation on the phone.

## Start the mobile server (Windows)

**Double-click `START-CALIAN-MOBILE-WINDOWS.bat` in this extracted ZIP root.**

It installs npm dependencies if absent, builds Angular and the Node server, configures `tailscale serve --bg 8798`, and starts CALIAN on **127.0.0.1:8798**. It prints the private **https://...ts.net** address for your PC. Do not close the PowerShell window while using CALIAN on mobile. This is separate from the Electron desktop backend, so the existing executable remains intact.

The script does **not** make the API publicly accessible: the backend continues listening on loopback only. The server accepts WebSockets only from localhost or its exact private HTTPS origin.

## Install on a phone

**Android:** Connect Tailscale, open the printed URL in Chrome, use menu **⋮ → Add to Home screen / Install app**.

**iPhone:** Connect Tailscale, open the printed URL in Safari, use **Share → Add to Home Screen → Add** (choose **Open as Web App**, if offered).

Open the new CALIAN.AI icon on the phone. The four skins, agent selection, chat and **Speak / Stop** controls are retained. Whisper transcribes on the Windows server; speech text remains editable until Send is pressed.

## Troubleshooting

- **Site inaccessible:** Ensure Windows is awake, PowerShell mobile-server window is open, and Tailscale is connected on both devices. Confirm `tailscale serve status` on Windows. Check that the mobile device is on the same Tailnet.
- **WebSocket unavailable:** Open the *exact* URL printed by the script (do not substitute the PC IP or HTTP address). The HTTPS origin must match `CALIAN_PUBLIC_ORIGIN` automatically configured by the launcher.
- **Agents offline:** The phone cannot operate agents by itself; start the backend dependencies on Windows. It uses the same REQA/DBAgent routes as desktop.
- **Mic not working:** Allow microphone permission on the phone; ensure Tailscale HTTPS and Windows Whisper are both working. You can also tap the phone keyboard's dictation icon and edit before sending.
- **Windows app works but mobile doesn't:** The desktop exe runs a separate loopback backend on a dynamically assigned port. The mobile launcher runs a *new* Node backend on port **8798**, on the same Windows machine. Both are independent processes.
- **Port conflict:** Close the other process using port 8798 before starting this launcher.
- **Do not expose directly:** Never forward port 8798 from your router to the Internet. Do not replace Tailscale Serve with public Funnel. Network access is enforced by Tailnet identity/ACLs, not by a CALIAN login screen.

## Security and functional boundaries

- A Tailnet member permitted to reach this PC can use the exposed CALIAN interface and its agents. Keep Tailnet membership and access control restrictive; for multi-user/public deployments, add a proper authentication layer first.
- Cached static assets may display offline, **but AI/SQL/voice requests require the online Windows backend**.
- iOS and Android native store app releases require separate packaging, signing, and testing. This ZIP does not contain APK/IPA files. A native Android build requires Android Studio; an iOS App Store build needs macOS/Xcode or a compatible hosted macOS builder.
- **No changes** are made to Fouad's Docker image or Python NL2SQL implementation.

## Developer changes (all outside Fouad's services)

- `src/app/socket.service.ts`: HTTPS → WSS and same-origin mobile connections; keeps desktop WS behavior.
- `server/index.ts`, `server/speech-whisper.ts`: exact optional `CALIAN_PUBLIC_ORIGIN` for browser WebSocket and speech HTTP origin validation; still binds 127.0.0.1.
- `src/app/app.component.{ts,scss}`: phone layout, inspector handling, microphone hints; desktop routes preserved.
- `src/index.html`, `public/`, `angular.json`: installable manifest/icons and mobile-only service worker. API responses are never cached.
- `START-CALIAN-MOBILE-WINDOWS.{bat,ps1}`: one-command private HTTPS mobile server launcher.

**Build status:** Sources can be checked and bundled outside Windows; actual Android/iPhone microphone operation and full cross-device end-to-end connectivity must be verified on your devices.
