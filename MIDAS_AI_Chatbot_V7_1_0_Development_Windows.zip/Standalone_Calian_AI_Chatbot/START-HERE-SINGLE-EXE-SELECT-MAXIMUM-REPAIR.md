# CALIAN.AI V8 — Single EXE / English SELECT routing repair

This update is based on the existing `Standalone_Calian_AI_Chatbot_V8_One_Executable_Auto_Config` source package.

## What was wrong

An instruction such as `Select a maximum of 10 records from the table contxt_oi_assoc` was being misclassified as literal SQL because it begins with `Select`. That text was sent to REQA's read-only `execute_sql`, where sqlglot rejected it as an invalid SQL expression (HTTP 422). The database connection, schema selection, and query execution were not the source of this particular failure.

## What changed

- `CALIAN_AI_ELECTRON_THEMES/server/direct-sql.ts`: recognizes spoken row-limit qualifiers (`a maximum of`, `maximum of`, `at most`, `up to`, `no more than`, etc.) before dispatching a SELECT. True SQL remains direct SQL.
- `CALIAN_AI_ELECTRON_THEMES/server/test-select-english-routing.cjs`: expanded regressions for spoken row-count expressions, genuine SQL, and schema-aware translation.
- `BUILD-CALIAN-WINDOWS.bat`: runs the routing regression test after dependency installation and stops before building if it fails.

No changes to the Electron first-run config, `calian.env`, MariaDB schema resolver, REQA, DBAgent, Whisper, or video services.

## Build the **one distributable EXE** (on Windows)

1. Extract this ZIP into a new folder. Do not overwrite your working app.
2. Double-click `BUILD-CALIAN-WINDOWS.bat` and allow `npm install` to complete.
3. The build runs the SQL-routing test and then creates `DELIVER_TO_FOUAD\CALIAN.AI.exe`.
4. Distribute only `CALIAN.AI.exe` as before. The first-launch setup and automatic `calian.env` creation are retained; external Docker/REQA/Ollama/video dependencies remain separate.

## Tests

- Spoken: `Select a maximum of 10 records from the table contxt_oi_assoc`
- Spoken: `Select at most ten records from the context O I association table`
- Literal SQL: `SELECT * FROM \`vcci_aug_26_dbg_1\`.\`contxt_oi_assoc\` LIMIT 10;`

The two spoken examples should use automatic schema discovery to produce a verified `SELECT ... LIMIT 10`; the literal SQL should not be modified or regenerated.

**Verification boundary:** code-level regression tests pass; no live MariaDB/Windows executable build was performed in this environment.
