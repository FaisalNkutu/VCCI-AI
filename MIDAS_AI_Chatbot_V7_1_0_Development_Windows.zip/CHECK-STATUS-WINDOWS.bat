@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title MIDAS + Calian AI V4 - Instance Status
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0SETUP-AND-RUN-WINDOWS.ps1" -CheckOnly
echo.
pause
endlocal
