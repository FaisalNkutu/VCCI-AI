@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLY-V6-2-POPOUT-WINDOWS.ps1" %*
echo.
pause
