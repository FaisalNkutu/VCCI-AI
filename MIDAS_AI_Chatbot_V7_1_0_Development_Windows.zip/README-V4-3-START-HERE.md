# MIDAS + CALIAN AI COPILOT V4.3 — SAFE PATHS & ISOLATED AUTO PORTS

This release addresses the browser-serving failure recorded in `Debug Midas 1.txt` (2026-11-24).

## What changed compared with V4.2
- Renamed the original MIDAS source directory from `midas-plan-midas#296` to `midas` to remove the `#` URL delimiter from the Vite project root.
- `SETUP-AND-RUN-WINDOWS.ps1` now points to `midas\midas-frontend`.
- The MIDAS Angular development server runs with `--prebundle=false` to avoid the shared optimized-dependency cache conflict when running multiple `ng serve` instances from the same source tree. This can slow dev-page startup but does not disable pnpm integrity checks.
- V4.2 TypeScript action-signature corrections, lockfile corrections, approved dependency build policy, Calian context bridge, dynamic ports and video/agent source are preserved.

## Install and start
1. Extract this ZIP to a short directory without a `#` character, e.g. `C:\MIDAS_Calian_V4_3` or `Downloads\MIDAS_Calian_V4_3`.
2. Double-click `START-EVERYTHING-WINDOWS.bat`. It will look for missing Node packages and install them through your authorized npm/Simfront registries when needed.
3. It selects a fresh free trio of ports: MIDAS 4200+n; Calian UI 4300+n; Calian backend 8797+n, without terminating unrelated applications.
4. Use the MIDAS URL displayed by the launcher, e.g. `http://127.0.0.1:4201/calian-ai`. Do not assume 4201 in every run.
5. To check URLs, run `VERIFY-LAST-RUN-WINDOWS.bat`.

This is a complete source-based development kit, not an offline installer. Existing Artifactory authorization and external AI/MIDAS/video services are still required for their features.

## Current validation
Static code checks and JavaScript bridge tests pass in the packaging environment. We cannot execute the Windows dev launcher or authenticate against Simfront's private registry here. Do not claim this release has passed an end-to-end Windows launch until verified on your machine.

## Error interpretation
- `Application bundle generation complete`: Angular compiled. This does not mean browser requests succeeded.
- `# project root` or `optimized info should be defined`: clear affected `.angular` cache after moving to a safe path; V4.3 avoids that path.
- `ERR_PNPM_*`: keep integrity controls enabled; do not delete lockfile or paste private tokens.
- Native JavaScript cache warning for node ABI 137: generally a performance warning, not the source of the 2026-11-24 browser failure.
