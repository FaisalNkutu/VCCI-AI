# AI Chatbot V7.0.2 LOCAL DBAgent schema configuration.
# Stores a schema name only. Does not store passwords, tokens, or server endpoints.
[CmdletBinding()]
param([string]$Database = '')
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$dest=Join-Path $root 'V7_DATABASE_CONFIG.json'
Write-Host 'AI Chatbot V7.0.2 - DBAgent Default Database' -ForegroundColor Cyan
if(-not $Database){
  if(Test-Path -LiteralPath $dest){
    try{$current=Get-Content -LiteralPath $dest -Raw | ConvertFrom-Json;Write-Host ('Previous selected database: '+$current.Database) -ForegroundColor Gray}catch{}
  }
  $Database=Read-Host 'Database/schema name (for example vcci_aug_26_dbg_1)'
}
if($Database -notmatch '^[A-Za-z_][A-Za-z0-9_]{0,127}$'){throw 'Invalid database/schema name. Use only letters, digits and underscore, starting with letter/underscore.'}
if(Test-Path -LiteralPath $dest){Copy-Item -LiteralPath $dest -Destination ($dest+'.bak.'+(Get-Date -Format yyyyMMdd-HHmmss))}
@{Database=$Database}|ConvertTo-Json|Set-Content -LiteralPath $dest -Encoding UTF8
Write-Host ('Saved selected schema: '+$Database) -ForegroundColor Green
Write-Host 'Run START-V7-ISOLATED-WINDOWS.bat for a NEW V7 instance. Existing backend instances keep their previous selection.'
Write-Host 'The selected schema must be accessible to your existing REQA database account. No permissions were changed.'
