@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLY-V6-2-5-WINDOWS.ps1"
if errorlevel 1 echo UPDATE FAILED. Review the error above.
pause
