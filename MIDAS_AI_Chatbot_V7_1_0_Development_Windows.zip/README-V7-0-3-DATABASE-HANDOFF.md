# AI Chatbot + MIDAS V7.0.3 — Database-selection handoff correction

## Applies to

The **isolated V7.0.2 development build only**. Do not apply to the stable V6.5 installation. The full V7.0.3 ZIP is an independent source-based installation.

## Verified cause

In V7.0.2, `app.component.ts` forwarded `databaseSchema` with direct calls to `/api/ai-core/execute`. It did **not** include `database` in requests to `/api/orchestration/execute`, and its database-intent regex missed requests such as `Show me the records from table contxt_oi_assoc`. The general agent planner then rewrote the request, causing a DB lookup without the user's selected schema and sometimes unsupported or invented explanations. The selected schema in Session Inspector did not necessarily reach the multi-agent path.

## Changed implementation

- `src/app/db-intent.ts`: shared, narrowly scoped database-retrieval classifier used by Angular and Node. No user-generated SQL is created here.
- `src/app/app.component.ts`: natural-language database requests, not only literal SQL, are sent unchanged to DBAgent. The selected schema is included in orchestration requests for server-side defensive routing. Existing MIDAS actions are not intercepted.
- `server/index.ts`: the orchestrator recognizes database retrieval **before** the LLM planner, validates the selected schema with the existing REQA accessible-schema list, and calls the same read-only DBAgent path as a direct request. It returns database rows/counts only when the underlying executor succeeds; otherwise it returns a specific error, not a synthesized or fallback answer.
- `SETUP_SUPPORT/V7/dbagent-v703.test.mjs`: new routing checks for previously failing phrases.
- `SETUP_SUPPORT/V7/dbagent-v702.test.mjs` and `RUN-V7-CHECKS-WINDOWS.bat`: retain previous regression checks using the new shared classifier.

## Quick-fix installation (recommended)

1. Extract `MIDAS_AI_Chatbot_V7_0_3_Database_Handoff_Quick_Fix.zip` to its own folder.
2. Double-click `APPLY-V7-0-3-WINDOWS.bat` and **paste the absolute path** of the running extracted V7.0.2 project root (the folder containing `midas` and `Standalone_Calian_AI_Chatbot`).
3. Review the displayed paths, enter `APPLY`. The updater checks V7.0.2 source file hashes and backs up previous files. **It refuses to overwrite unexpected local changes**.
4. Allow the existing Angular and Node development watchers to reload. If the backend is running without a watcher, **restart only the V7 development backend**, not the V6.5 services. An already-started backend cannot load changed server code until restarted.
5. Open the V7 browser instance, refresh it, and check **Session Inspector → DBAgent Database/Schema**. Confirm `vcci_aug_26_dbg_1` is selected. Send a **new** question; old transcript errors will not change.

## Recommended verification

Ask **in Intelligent Auto Select**:

```
Show me the number of records in table contxt_oi_assoc
```

The new trace should show one DBAgent step, a deterministic database-retrieval route, and schema `vcci_aug_26_dbg_1`. If execution is authorized, it should show a count returned by the database, not a guess from the model.

Then try:

```
Show me the first 10 records from table contxt_oi_assoc
```

This is subject to the DBAgent service's actual list/row-read policy; a denied read must be presented clearly. Also verify that `Open Combat Power` and `Select entity 123` continue through MIDAS's approval controls, not DBAgent.

For predictable direct SQL, submit:

```sql
SELECT COUNT(*) AS total_records FROM `vcci_aug_26_dbg_1`.`contxt_oi_assoc`;
```

Do not write `` `vcci_aug_26_dbg_1.contxt_oi_assoc` `` as a single quoted identifier.

## Safeguards / limitations

- Never apply this patch to V6.5. Existing V7 auto-selected ports are unchanged.
- REQA/MCP access remains read-only, and the selected schema must be accessible through the existing REQA connection; no credentials, tokens, or grants are added.
- The MIDAS dashboard's `No Data Source Connected` status is **independent** of DBAgent's selected schema.
- This patch cannot change REQA's external policy; row listing may still be rejected, and absent permissions remain absent.
- Backend API/WS identity management is still development-grade; do not expose this local schema picker to guests or production users.
- Static TypeScript checks and Node regression tests passed in the build environment. Actual Windows Angular compilation, REQA connection and SQL results have **not** been verified here.
