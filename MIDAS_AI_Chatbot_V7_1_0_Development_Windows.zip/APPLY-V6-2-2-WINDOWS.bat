@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLY-V6-2-2-WINDOWS.ps1"
if errorlevel 1 echo ERROR: See messages above.
echo.
pause
