@echo off
setlocal
set "SCRIPT=%~dp0HOTFIX-V4-1-COMPILER-WINDOWS.ps1"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
set "EXITCODE=%ERRORLEVEL%"
echo.
if not "%EXITCODE%"=="0" ( echo Fix did not complete. See the message above. ) else ( echo Done. Check your existing MIDAS Angular console for recompilation. )
pause
exit /b %EXITCODE%
