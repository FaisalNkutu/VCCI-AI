# MIDAS Calian V5.3 — Guided control commands

## What changed

- On the Calian Session Inspector > Context pane, the version label `Controls V5.3` confirms the updated frontend is running.
- Incomplete `Set time range` and `Change time format` commands now ask for required values and display available choices rather than generic rejection.
- `Select entity <ID>` checks the shared MIDAS entity list; when no entities are available, it explains that entity selection cannot be completed until MIDAS data is connected.
- Added example buttons, displayed available time-format choices, Combat Power entity availability, and time boundaries when MIDAS provides them.
- Range syntax includes `Set time range 10 to 30` and `Set time range from 10 to 30` in MIDAS native units. MIDAS still checks its actual range and requires approval.
- No change to agents, video, ports, popup, security or MIDAS backend; all actions remain subject to host permission checks and explicit user approval.

## Test

1. Start MIDAS and Calian as before. Ensure the correct Calian frontend instance is being served; refresh MIDAS and confirm `Controls V5.3` in the Session Inspector.
2. Enable **Share dashboard context**. Bridge connected is necessary but not sufficient for a valid action.
3. On Combat Power, enter `Set time range`: the interface should ask for two numbers and, when available, show range bounds.
4. Enter `Change time format`: the interface should list valid available formats; if none are shared, it explains that data/configuration must be connected.
5. Enter `Select entity 123`: when the entity list is empty, the interface should explain why selection cannot succeed.
6. Enter `Open Summary` and approve in MIDAS to confirm action request/approval remains operational.
7. Test the pop-out and dock flow separately; the new controls do not alter that functionality.

**Limitations:** This cannot manufacture missing MIDAS data or formats. If your screenshot still shows the *old* `No supported MIDAS action matched` wording, you are probably using an older Calian Angular instance. Find which project runs the actual port and restart that instance deliberately, without terminating unrelated services. Full Windows browser testing has not been performed in this environment.
