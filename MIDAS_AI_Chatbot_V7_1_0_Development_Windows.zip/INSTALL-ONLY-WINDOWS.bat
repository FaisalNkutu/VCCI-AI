@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title MIDAS + Calian AI V4 - Install Dependencies Only
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0SETUP-AND-RUN-WINDOWS.ps1" -InstallOnly
echo.
pause
endlocal
