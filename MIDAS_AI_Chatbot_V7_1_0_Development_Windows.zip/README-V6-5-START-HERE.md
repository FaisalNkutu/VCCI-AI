# AI Chatbot V6.5 — viewport-filling conversation and pinned controls

This patch is intended for the **V6.4** Windows MIDAS + AI Chatbot source bundle. It updates **only** `Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/src/app/app.component.scss`.

The chat now fills the available browser/iframe height instead of staying within a short, fixed-height card. The messages scroll within their own area; shared MIDAS context and optional settings scroll within the composer. **Speak / Stop and Send remain in the composer footer**, and microphone/transcription status remains visible as a live status region. The same layout applies to side panel, expanded/full page and the browser pop-out. The existing **Read responses** view is preserved.

## Install
1. Extract this ZIP to its own folder.
2. Double-click `APPLY-V6-5-WINDOWS.bat`.
3. Select the **running V6.4 project** (not an old project on a different port) and type `APPLY`.
4. A timestamped backup is saved under `BACKUPS`. Angular watch mode should detect the stylesheet change. If it compiles, refresh MIDAS in Chrome/Edge using Ctrl+Shift+R.

No dependency installation or service restarts are needed for this CSS-only change. The script will **refuse** to overwrite a customized or unexpected stylesheet.

## Test
- Open an expanded AI Chatbot: the Conversation card should fill the space above the bottom of the window instead of leaving a large empty area.
- Confirm Send and Speak stay in view when you scroll the chat history or shared MIDAS selections. Send remains disabled until text is entered.
- Speak, then Stop: a Recording/Transcribing status should appear. Validate local Whisper separately (requires its backend).
- Switch to a narrow MIDAS side panel, resize, then use the large pop-out. Check all three.
- Verify MIDAS navigation, context bridge, agents and video are unchanged.

## Validation / limitation
The updated CSS was inspected and structural/viewport tests were run in a Chromium layout harness. A full Angular 19 build against the user's actual Windows dependencies and a live MIDAS browser are not available in this environment.
