# MIDAS AI Chatbot V7.0.8 — Whisper memory recovery

Baseline: complete V7.0.7 development ZIP. Extract into a new directory, stop previous chatbot services, and run START-V7-ISOLATED-WINDOWS.bat. Existing local registry and service configuration requirements apply. No patch needed.

## What changed
- Hands-free uses installed small.en by default rather than medium.en when both exist (base.en is also supported if installed). Manual Speak retains the previous model preference. An explicit CALIAN_WHISPER_MODEL remains the first preference subject to an established memory downgrade.
- Hands-free and memory retries use beam size and best-of 1 to reduce decoder cache demands. Recognition accuracy may be lower than medium/beam 5.
- On allocation failures, retry the same audio sequentially with a lighter installed model; manual mode first tries lower-memory decoding on the same model. A downgrade sticks until the server restarts. No model download or remote speech service is invoked automatically.
- Distinct attempt output paths, a combined deadline, drained stdout and wait for child exit before retry. Non-memory errors are not retried by the model fallback.
- If no smaller model is available, a concise error suggests recovery. Existing voice pause after repeated errors remains. If only medium is installed, run Standalone_Calian_AI_Chatbot/SETUP-ACCURATE-SPEECH-WINDOWS.bat to install the small model. Close unused programs and old chatbot instances if memory is still insufficient. Existing USE-FASTER-SPEECH-WINDOWS.bat can disable medium reversibly for V7.0.7 as a workaround (verify small is installed first).
- SQL generation, database command parser, MIDAS integration and video sources unchanged. The only backend source change is speech-whisper.ts; the UI passes a hands-free profile and shows the new version.

## Acceptance test
Enable Auto-submit and Hands-free. Say “List databases”, wait for the list, choose a number, and verify selection before a read-only query. Repeat several times, including after another local application is running. Do not deliberately exhaust memory. Inspect Heard/status on failure. If failures persist, inspect Task Manager > Performance > Memory (including committed memory), free disk space and the installed models. Keep Windows paging file system-managed unless IT policy requires otherwise.

## Verification
100 Node source regression tests passed (91 existing + 9 new). Fallback tests exercise actual model policy and retry functions with simulated errors, not a running Whisper binary. Full Windows/Angular compilation, actual whisper.cpp memory usage, recognition accuracy and database switching remain untested here. The pinned CLI is expected to support -bs and -bo; live validation is required. Base model must already be installed to be used. No guarantees against all memory allocation failures.
