# Return this V7 source copy to OFF feature flags. Do not affect V6.5 installations.
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$files=@(
 @{path=(Join-Path $root 'midas\midas-frontend\src\assets\calian-embed-config.js');from='contextV2: true, typedActions: true';to='contextV2: false, typedActions: false'},
 @{path=(Join-Path $root 'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\public\ai-chatbot-v7-config.js');from='syntheticDemo:true, nlActions:true';to='syntheticDemo:false, nlActions:false'}
)
foreach($f in $files){
 $content=[System.IO.File]::ReadAllText($f.path)
 if($content.Contains($f.from)){[System.IO.File]::WriteAllText($f.path,$content.Replace($f.from,$f.to))}
}
Write-Host 'V7 optional features are disabled in this source copy. Restart V7 for the change to take effect.' -ForegroundColor Green
