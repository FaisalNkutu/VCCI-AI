# AI Chatbot + MIDAS V7.0.1 — TypeScript TS2300 compiler fix

This targeted fix addresses the **four `TS2300: Duplicate identifier` messages** visible in the MIDAS Angular console. The V7 source inadvertently imported `V7_CAPABILITIES` and `preflightV7Action` twice in the same component (lines 19–20). **Only the second import is removed.**

## Recommended: update your running, isolated V7 installation

1. Extract the `MIDAS_AI_Chatbot_V7_0_1_Quick_Fix.zip` to its own folder.
2. Double-click `APPLY-V7-0-1-WINDOWS.bat`.
3. If more than one V7 folder is found, choose the one corresponding to your active MIDAS URL. The script refuses to modify V6.5.
4. The script backs up the affected file before editing and confirms a single import remains.
5. Leave Angular's existing `ng serve` window open; it should recompile automatically. After compilation succeeds, refresh MIDAS (`Ctrl+Shift+R`).

Alternatively, in the V7 project, edit `midas/midas-frontend/src/app/components/calian-ai/midas-calian-copilot.component.ts` and delete **line 20**, the second identical `import { V7_CAPABILITIES, preflightV7Action } from './midas-v7-actions';` statement.

## What this fixes and does not fix

- Corrects the duplicate import only; no changes to MIDAS routing, approved-action bridge, synthetic evidence, AI agents or video.
- Does not affect your V6.5 working installation.
- Sass deprecation warnings can still appear; they do not cause `TS2300`.
- Node tests passed with `node --experimental-strip-types --test ...` (29/29). Source TypeScript transpilation completed; **full Angular compilation requires local dependencies and remains unverified here**.
- V7 remains a **development build**. Do not enable production real-MIDAS data calls before identity, permissions and security review are complete.

## If another Angular error appears

Share the **first red error** from the MIDAS Angular console (not the Sass warning). This fix deliberately avoids speculative changes to unrelated components.
