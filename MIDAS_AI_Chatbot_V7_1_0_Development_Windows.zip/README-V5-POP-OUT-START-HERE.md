# MIDAS + Calian AI Copilot V5 — optional movable / resizable pop-out

This V5 release builds on the working V4.3 **embedded iframe** and dynamic-port Windows launcher. The Calian Angular frontend and Node backend remain independent of MIDAS Angular.

## Start
1. **Extract this ZIP to a new short folder without `#`** in any path, for example `C:\MIDAS_Calian_V5`.
2. Double-click `START-EVERYTHING-WINDOWS.bat` (or use your current V4.3 instance only if you apply the updated source manually). The launcher installs missing dependencies and selects an unused set of ports, without stopping other instances.
3. Visit the exact MIDAS URL printed by the launcher, usually `http://127.0.0.1:4200/calian-ai` or another 4200+n port.
4. In the Calian AI toolbar, click **Pop out ↗**. Your browser should open a new, independently resizable Calian window. Allow pop-ups for MIDAS if the browser blocks it.
5. **Move** the pop-out by dragging the browser title bar; **resize** it by dragging the edges/corners. The MIDAS dock also offers **Compact**, **Standard**, **Large**, and **Center** requests. Browsers/operating systems can ignore scripted positioning or resizing.
6. Enable **Share dashboard context** in the MIDAS dock if you wish Calian to see dashboard controls. To test an action, enter `Open Combat Power` in Calian; approve or decline the change in the MIDAS window.
7. Select **Dock in MIDAS** to transfer the latest chat back and close the pop-out. Use this button rather than the pop-out's native X button when you wish to retain the newest chat turns. Closing the popup via its native X returns to the last embedded chat snapshot, which may be older.

## What is transferred
On explicit user clicks to pop out or dock, the bridge copies a bounded **in-memory** chat snapshot: conversation ID, up to 100 turns, editable context fields, selected agent and UI preferences. It does not transfer API keys, authentication cookies, active microphone streams or active video calls. Agent execution, voice recordings, and video calls must finish before moving a session; otherwise transfer is refused and both windows stay available. A new popup chat may still be available if the embedded window has never connected to the bridge.

## Security and behavior
- The popup is the same Calian Angular web app and retains its existing agent/video APIs; no Electron requirement.
- MIDAS communicates only with the configured Calian origin and the exact popup/iframe window; Calian accepts MIDAS messages only from the allowlisted matched local origin and `window.opener`/`window.parent`. Each endpoint has its own random bridge token.
- Chat context remains **opt-in** and proposed UI actions still require explicit approval in MIDAS. The pop-out dock includes the approval panel; the standalone popup does not receive authority to execute MIDAS actions directly.
- Pop-outs opened by scripts use a reference to the MIDAS opener for the development bridge. Production hosting requires secure same-site authentication and CSP, strict origin allowlists, and a review of opener trust; consider a same-origin popup shell if your security policy disallows cross-origin opener relationships.
- A browser may block popups, limit `moveTo`/`resizeTo`, or discard state when a window is closed unexpectedly. Native window dragging and resizing remain available on desktop when a genuine popup is created.
- Multiple development instances remain isolated through automatically paired MIDAS UI, Calian UI and Calian backend ports. Older processes are left untouched.

## Runtime requirements & limitations
Node/npm, pnpm and authorized Simfront Artifactory access are still needed for first installation; this is source + automated setup, not an offline executable. MIDAS data sources, external A2A agents, AI Core and video gateways need their respective services/configurations. Full Windows/Chrome/Edge end-to-end testing and production authentication are **not** claimed to have been performed by the packaging environment.

## Acceptance tests
1. **iFrame side panel**: Open MIDAS and use Calian side panel; test normal chat.
2. **Pop-out**: Click Pop out; confirm its separate taskbar/window, drag it, resize it, and select presets from MIDAS.
3. **Context bridge**: Enable Share dashboard context in MIDAS and verify bridge connected. Ask to open Combat Power; approve in MIDAS.
4. **Conversation transfer**: Send a recognizable chat turn in the embedded frame, pop out, confirm it appears; send a new turn in the popup, Dock in MIDAS, confirm both turns appear.
5. **Safety**: Test that a request to delete data or another unsupported action cannot directly change MIDAS. Confirm the popup closes no unrelated applications.
6. **Video/voice**: Verify a fresh popup still has video and microphone controls; do not use active call migration as a test, because active calls are deliberately not transferred.
7. **Port isolation**: Launch again with ports occupied; check a new run record under RUNS and verify that earlier services remain running.
