# AI Chatbot V6.4 - Visible Send and Transcription Status

This update fixes a **layout regression** in V6.3. With MIDAS selections enabled, the composer could grow taller than its visible frame, pushing **Send** and the Whisper transcription-status line below the bottom of the clipped chat card.

## Fix

- `Speak / Stop` and `Send` are always placed together in a dedicated, non-wrapping footer at the bottom of the composer, including in a narrow MIDAS side panel.
- MIDAS linked selections, agent-chain options, prompt text and optional speech settings scroll inside a separate composer body. Existing values are not discarded.
- The microphone / transcription line remains visible below those buttons and announces the live `voiceStatus` through `aria-live="polite"`. During a pending speech request the button displays `Working...`.
- Existing `send()`, `toggleVoice()`, `/api/speech/status`, `/api/speech/transcribe`, chat history and agent orchestration logic are unchanged. Transcript text is still editable before pressing Send.

## Apply to a V6.3 source installation

1. Extract this ZIP.
2. Run `APPLY-V6-4-WINDOWS.bat` in the extracted folder.
3. Select the **specific extracted MIDAS + AI Chatbot project that is serving your browser**. Several instances may coexist, so do not simply choose the newest by date.
4. Type `APPLY`. The updater validates the two original V6.3 file hashes, creates timestamped backups, and replaces just the template and stylesheet. It will safely refuse unknown custom modifications.
5. Once Angular reports a successful recompilation, hard-refresh MIDAS using `Ctrl+Shift+R`.

## Verify

- Open MIDAS > AI Chatbot, with `Share dashboard context` enabled and one or more linked selections.
- **Send** and **Speak** should remain visible together even in the 350px side panel. Send is disabled until you enter non-empty text or while a recording / transcription is active.
- Press **Speak**, allow microphone access, speak, then press **Stop**. You should see the status line `Transcribing locally with Whisper...` while waiting for results, followed by a message that transcription completed. The text stays editable; press **Send** to submit it.
- Test in **Expand** and **Pop out** modes, and make sure existing MIDAS navigation, theme selection and context transfer still work.

## Scope and caveats

This is a layout-only correction for the V6.3 chatbot source. It does not install or configure Whisper, grant microphone permissions, or fix a failing speech endpoint. If transcription still does not succeed, check the Chatbot backend logs for `/api/speech/status` and `/api/speech/transcribe`. Windows, Chrome and Edge runtime tests have not been executed in this environment.
