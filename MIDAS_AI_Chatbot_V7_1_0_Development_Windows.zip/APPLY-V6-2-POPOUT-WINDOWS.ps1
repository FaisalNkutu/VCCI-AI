﻿# AI Chatbot V6.2 pop-out stability fix. Source-only patch; never stops services.
param([string]$ProjectRoot = '')
$ErrorActionPreference='Stop'
$relative='midas\midas-frontend\src\app\components\calian-ai\midas-calian-copilot.component.ts'
Write-Host 'AI Chatbot V6.2 - Pop-out Stability Hotfix' -ForegroundColor Cyan
Write-Host 'Prevents the pop-out from auto-closing on session handoff failure, timeout, or slow bridge connection.'
Write-Host 'No dependency installation, port changes or service termination.'
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
  $locations=@((Join-Path $env:USERPROFILE 'Downloads'),(Get-Location).Path) | Select-Object -Unique
  $candidates=New-Object System.Collections.Generic.List[string]
  foreach ($location in $locations) {
    if (!(Test-Path -LiteralPath $location)) {continue}
    $dirs=@((Get-Item -LiteralPath $location)) + @(Get-ChildItem -LiteralPath $location -Recurse -Directory -Depth 4 -ErrorAction SilentlyContinue)
    foreach ($d in $dirs) {
      if ((Test-Path -LiteralPath (Join-Path $d.FullName $relative)) -and !$candidates.Contains($d.FullName)) {
        $candidates.Add($d.FullName)
      }
    }
  }
  if (!$candidates.Count) {throw 'No source project found. Pass -ProjectRoot to select the extracted MIDAS project root.'}
  Write-Host 'Select the project serving your active MIDAS browser port:' -ForegroundColor Yellow
  for($i=0;$i -lt $candidates.Count;$i++){Write-Host ('[{0}] {1}' -f ($i+1),$candidates[$i])}
  $choice=Read-Host 'Enter number; leave blank to cancel'
  if($choice -notmatch '^\d+$' -or [int]$choice -lt 1 -or [int]$choice -gt $candidates.Count) {throw 'Cancelled without changes.'}
  $ProjectRoot=$candidates[[int]$choice-1]
}
$ProjectRoot=(Resolve-Path -LiteralPath $ProjectRoot).Path
$target=Join-Path $ProjectRoot $relative
if(!(Test-Path -LiteralPath $target)){throw ('Missing expected MIDAS source: '+$target)}
$existing=[IO.File]::ReadAllText($target)
if(!$existing.Contains("popOut(): void") -or !$existing.Contains('MIDAS_CALIAN_V1') -or !$existing.Contains('beginHandoff(') -or !$existing.Contains('data-resize-version="6.1"')) {
  throw 'This quick fix requires V6.1 source with visible resize controls. Upgrade to V6.1 first or use the full V6.2 ZIP. No changes made.'
}
$gateway=Join-Path $ProjectRoot 'midas\midas-frontend\src\app\components\calian-ai\midas-tool-gateway.ts'
if(!(Test-Path -LiteralPath $gateway)){throw 'Missing V6 capability gateway. No changes made.'}
if($existing.Contains('V6.2 popout-keep-open')) {Write-Host 'V6.2 appears already applied to this source.' -ForegroundColor Green;exit 0}
$confirmation=Read-Host ('Apply V6.2 to '+$target+'? Type Y to proceed')
if($confirmation -notin @('Y','y')){Write-Host 'Cancelled without changes.';exit 0}
$patched=Join-Path $PSScriptRoot ('PATCH\'+$relative)
if(!(Test-Path -LiteralPath $patched)){throw ('Missing patch file: '+$patched)}
$backupDir=Join-Path $ProjectRoot ('V6_2_POPOUT_BACKUP_'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
$backup=Join-Path $backupDir 'midas-calian-copilot.component.ts'
Copy-Item -LiteralPath $target -Destination $backup -ErrorAction Stop
try {
  Copy-Item -LiteralPath $patched -Destination $target -Force -ErrorAction Stop
  Write-Host 'Pop-out stability patch applied successfully.' -ForegroundColor Green
  Write-Host ('Backup: '+$backup)
  Write-Host 'Allow MIDAS Angular to recompile, then hard-refresh MIDAS with Ctrl+Shift+R.'
  Write-Host 'Keep the browser pop-up open while testing; do not need to stop other app instances.'
} catch {
  Copy-Item -LiteralPath $backup -Destination $target -Force
  throw
}
