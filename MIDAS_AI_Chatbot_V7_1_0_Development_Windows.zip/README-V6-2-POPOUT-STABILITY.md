# AI Chatbot V6.2 — Pop-out stability hotfix

**Problem:** The MIDAS host explicitly called `popupWindow.close()` when the embedded-to-pop-out conversation handoff failed (for example, an agent was busy or the request timed out after 12 seconds). This may look like the window closes when the mouse enters it, but pointer entry is not itself a programmed close trigger.

**Correction:** The pop-out now remains open if chat transfer times out, is rejected because the microphone/video/agent is active, or the popup handshake is not yet complete. MIDAS displays a status message instead. The only intentional programmatic close remaining is a successful, user-invoked **Dock in MIDAS** after an acknowledged session import. Closing the browser window manually still works.

**Compatibility:** Quick Fix requires the **V6.1** source with its resize bar and capability gateway. If you have not installed V6.1, use the full V6.2 package or install V6.1 first. The installer will refuse older source trees rather than overwrite them.

**Quick upgrade:**
1. Fully extract the Quick Fix ZIP.
2. Run `APPLY-V6-2-POPOUT-WINDOWS.bat`; choose the installed project serving the current MIDAS URL. There can be multiple instances because your launcher allocates ports dynamically.
3. Confirm patch; the script saves the original TypeScript file in a timestamped `V6_2_POPOUT_BACKUP_*` directory.
4. Allow MIDAS Angular to recompile and refresh MIDAS with `Ctrl+Shift+R`.
5. Click **Pop out** and move your mouse into the new browser window. Test for at least 20 seconds; exercise **Compact**, **Standard**, and dragging a window edge.
6. Test while an agent response is in progress: the session handoff may be declined, but the new window should remain open. Finish the activity before using **Dock in MIDAS**.

**Important:** A failed transfer means the popped-out window may start with a fresh conversation. Do not assume history has moved unless the UI confirms it. Video calls and active microphone sessions cannot be transferred. The current bridge authorization and MIDAS action approvals are unchanged.

**If the window still vanishes:** In Chrome/Edge open `F12` → Console for both MIDAS and AI Chatbot, and check whether there is a page crash, browser extension, or COOP isolation warning. The patch removes the known automatic closure paths, but we cannot rule out environmental causes without browser logs.

**Verification:** The TypeScript file passed parser/transpilation checks and targeted lifecycle-source checks. No Windows runtime or real browser test was possible in this environment.
