@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title MIDAS + Calian V4 - Latest Instance HTTP/WebSocket Checks
node "%~dp0TOOLS\verify-last-run.cjs"
echo.
pause
endlocal
