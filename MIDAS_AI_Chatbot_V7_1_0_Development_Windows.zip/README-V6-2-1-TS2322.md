# AI Chatbot V6.2.1 — TS2322 UUID Context-ID Type Fix

## Problem
Calian Angular 19 compilation fails at `src/app/app.component.ts:170` with `TS2322 Type string is not assignable to type ${string}-${string}-${string}-${string}-${string}`. `crypto.randomUUID()` causes TypeScript to infer a UUID-specific template-literal type, but a validated transferred session value is of type `string`.

## Fix
In the `Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/src/app/app.component.ts` class field, replace:

    contextId=crypto.randomUUID();

with:

    contextId: string = crypto.randomUUID();

This keeps the runtime-generated UUID, imported-session validation, and existing session-transfer behavior unchanged. No dependency or port changes are needed.

## Quick Fix installation
1. Extract `MIDAS_AI_Chatbot_V6_2_1_TS2322_Quick_Fix.zip`.
2. Run `APPLY-V6-2-1-CONTEXT-ID-WINDOWS.bat` from the extracted folder.
3. Select the project actually serving your chatbot browser URL (especially if multiple copies are installed). The script makes a timestamped `.bak` of the one target file, then edits exactly one string occurrence.
4. Leave the Angular development-server window open. Its watch mode should rebuild automatically. Refresh the chatbot/browser after a successful compilation.
5. If source change is not picked up, use the matching launch script to restart only that affected version when convenient. No need to stop unrelated MIDAS instances.

If the script finds no candidates, open a PowerShell window beside this script and run:

    powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\APPLY-V6-2-1-CONTEXT-ID-WINDOWS.ps1 -ProjectRoot "C:\path\to\extracted\MIDAS_V6_2_project"

## Full package
`MIDAS_AI_Chatbot_V6_2_1_Context_ID_Full_Windows.zip` includes the complete V6.2 source, unchanged launcher and MIDAS frontend, and the corrected Calian Angular `app.component.ts`.

## Validation and limits
- The replacement was inspected in the exact V6.2 source ZIP; only the `contextId` class-field declaration is changed.
- An isolated TypeScript 5.8.3 strict-mode type test passed.
- The archives and targeted patch were verified in this environment.
- A complete Angular/Windows build has not been performed because this environment does not have the project's installed dependencies or private services.
