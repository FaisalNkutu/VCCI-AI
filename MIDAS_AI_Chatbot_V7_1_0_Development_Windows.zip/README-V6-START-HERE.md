# MIDAS + AI Chatbot V6 — Context-Aware Capability Gateway

**Version:** 6.0 (source preview, November 25, 2026)

## Quick start

If V5.3 is running on your Windows machine, use the separate **V6 Quick Upgrade ZIP** instead of reinstalling dependencies. Extract it, double-click `APPLY-V6-AI-CHATBOT-WINDOWS.bat`, select the *source tree belonging to your active MIDAS/AI Chatbot browser ports*, and confirm the backup/apply. Angular watch mode should recompile the changed files. Refresh MIDAS and the AI Chatbot tab. If you have multiple instances, the update will **not** affect instances whose source directories were not selected.

For a fresh copy, extract this full ZIP to a new directory, then run **`START-EVERYTHING-WINDOWS.bat`**. The inherited launcher installs dependencies if required, chooses a free trio of development ports, and starts MIDAS, the AI Chatbot Angular UI, and the AI Chatbot backend independently. Existing running instances are **not** stopped. Simfront private registry access, external AI services, MIDAS data backend and video service configuration remain your responsibility; secrets and node_modules are not included.

## New V6 capabilities (implemented source)

- **Visible name: AI Chatbot.** Sidebar branding, MIDAS workspace selector, tab title, video page labels and panel text changed. Internal paths, project folder names, API routes, package names, protocol ID `MIDAS_CALIAN_V1` and launcher service variables remain unchanged for compatibility.
- **Three view modes:** side-panel iframe, expanded iframe, independently movable/resizable pop-out. A **Width** slider (350–1100 px) and **− / +** controls now appear in the MIDAS iframe toolbar. Full-page mode remains available. A pop-out uses standard browser drag/resize plus Compact/Standard/Large/Center actions in the MIDAS docking controls. Browser window managers can restrict programmatic resize.
- **Bidirectional approved actions:** navigation across the existing dashboard catalogue, time-format selection, Combat Power timeframe, entity selection and grouping (unit/equipment), Rate of Movement timeframe/capture selection, Control Measures timeframe/measure selection. All changes still validate against MIDAS state and prompt the user in the MIDAS host for approval. No arbitrary code or free-form endpoint calls.
- **Capability registry:** `midas-tool-gateway.ts` publishes dashboards, labels, supported UI actions and four read tools. Calian's legacy frontend parser retains aliases and is still limited to the declared actions. It is **not** universal automation of every MIDAS control.
- **Read-only tool gateway:** `capabilities`, `dashboard_snapshot`, `compare_combat_power`, `report_data`. The host uses MIDAS's authenticated NgRx state; it does not scrape DOM or invent data. It sends bounded numeric summary metrics and (where loaded) Combat Power series statistics, not full raw records. Other dashboards currently contribute cross-dashboard summary counts, **not** all page-specific datasets.
- **Context in AI queries:** User Context and Task Context are now included in the **agent-facing message/query** as well as the structured context. With **Share dashboard context** enabled in MIDAS, the additional **Include MIDAS context in AI queries** checkbox adds MIDAS route, time format, connected-state, CP selection/timeframe and (for explicit analysis/report/compare prompts) read-only data evidence to the actual query sent to the existing router, multi-agent orchestrator, Ollama, Python A2A and AI Core execution. It does not silently add MIDAS state when sharing is off. Be aware that connected agents/services may receive this contextual information.
- **Analytics and reporting:** `Analyze dashboard`, `Compare units`, `AI report` buttons prefill a chat request. `Export evidence (.md)` downloads a structured evidence report from the MIDAS store without generating unsupported claims. Full AI-generated explanations require reachable configured agents and valid MIDAS data. If `No Datasource Connected` appears, analysis/report/comparison explicitly reports unavailable rather than fabricating observations.
- **Agent, video and chat continuity:** existing orchestrator, automatic/manual agent selection, video, iframe popup and session handoff source are preserved. Active video cannot be transferred by session handoff.

## Test plan

1. Run the launcher or use the existing V5.3 process after applying the V6 Quick Upgrade; use the **actual port shown**. Confirm the AI Chatbot label in the host toolbar, browser title and embedded sidebar.
2. In side-panel mode move the **Width** slider left/right and click `−` and `+`; confirm MIDAS main panel resizes. Expand/full-page and Pop out; move/resize the pop-out. Dock when finished.
3. Enable **Share dashboard context** in MIDAS. In the AI Chatbot Session Inspector enable **Include MIDAS context in AI queries**; note that the host badge must show **Bridge connected**.
4. Enter `Open CM Occupations`, `Open Enemy Engagement`, `Open Summary`; approve or decline and verify only approved changes occur.
5. With appropriate data loaded, test `Change Combat Power grouping to equipment`, `Set time range 10 to 30`, `Select capture 11` on ROM (with real capture 11), and `Select control measure 7` on CM (with real measure 7). Invalid/unloaded IDs must be rejected.
6. With MIDAS connected to an authorized source and valid data loaded, on Combat Power select at least two series and submit `Compare the selected Combat Power series and explain the changes.`. Inspect the agent response and compare it to the visible series. Do not treat AI analysis as verified evidence without review.
7. Use **Export evidence (.md)** in Session Inspector and verify the report clearly identifies its source and observed figures. Test with the MIDAS data source disconnected: a *data unavailable* result is expected.
8. Confirm manual agent selection, intelligent auto-routing, existing video calls, and pop-out return/dock still work. Test Firefox/Chrome/Edge popup behavior as required.

## Important implementation boundaries

- These are **source modifications** inspected and syntax/logic-tested in a Linux environment. **An Angular 21 build, Angular 19 build, Windows launcher, production identity integration, and real end-to-end multi-agent analysis were not run here.** Verify on your Windows computer and inspect the *first error* if one appears.
- The read gateway has **summary-level coverage and loaded Combat Power aggregates**. Per-dashboard specialized analytics, all field controls, arbitrary data retrieval, general document search, comprehensive reports and production deployment are **not complete**; they require authenticated MIDAS API connectors, schema-by-schema permission review and data-source setup. No false claim of universal dashboard control is made.
- This is a local development integration. **Before deploying to employees or invited external users**, implement and verify SSO, per-user server-side authorization on both services, role/field-level data permissions, action audit logs, HTTPS/WSS, restrictive CSP `frame-ancestors`, anti-CSRF protections, session controls and source review. Opt-in context may reach the configured AI agents, so only share approved data.
- Existing private Simfront Artifactory packages still require authorized credentials; neither ZIP includes private credentials, preinstalled dependencies or data source passwords. The inherited Windows setup may need network access and a compatible Node/pnpm environment.

## Source changes

- `midas/midas-frontend/src/app/components/calian-ai/midas-tool-gateway.ts` (new)
- `midas/midas-frontend/src/app/components/calian-ai/midas-calian-copilot.component.ts`
- `midas/midas-frontend/src/app/components/calian-ai/calian-ai.component.ts`
- `midas/midas-frontend/src/app/components/selection/selection.component.ts`
- `Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/src/app/midas-bridge.ts`
- `Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/src/app/app.component.ts`
- `Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/src/app/app.component.html`
- `Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/src/app/video-center.component.html`
- `Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/src/index.html`
- `Standalone_Calian_AI_Chatbot/CALIAN_AI_ELECTRON_THEMES/public/manifest.webmanifest`
- `TOOLS/test-v6-capabilities.cjs` (checks parser, UI wiring, query wiring and revalidation; requires TypeScript installed in one frontend)
