REQA A2A fix - plain text SQL from CALIAN.AI

Diagnosis:
- In a2a_nl2sql_agent.py, _run_async_impl previously called json.loads(part.text).
- CALIAN.AI sends raw SQL (or natural language), not the earlier {"GenerateSQL": ...} wrapper.
- json.loads('SELECT ...') throws JSONDecodeError: Expecting value at char 0.

This patch:
- Accepts plain text and converts it into the existing GenerateSQL request shape.
- Keeps existing JSON GenerateSQL and Ingest skill requests working.
- Does not bypass the existing SQL generation pipeline or its safeguards.
- Requires no Java, Electron, RabbitMQ, or Maven edits.

How to apply:
1. Extract the ZIP so both files are in the same folder.
2. Open PowerShell in the extracted folder.
3. Run:
   powershell -NoProfile -ExecutionPolicy Bypass -File .\APPLY_REQA_A2A_FIX.ps1

The script will back up the running container's original Python file, copy and syntax-check the corrected file, restart reqa-a2a, and send a SQL query over A2A.

WARNING: A Docker container recreation may discard this patch if the Python file is not bind-mounted. To make it permanent, also update the a2a_nl2sql_agent.py in the source checkout used for the reqa-a2a image, then rebuild that image. The uploaded export did not contain Docker Compose/build configuration, so that host path cannot be safely inferred here.
