# REQA/A2A - accept plain text SQL in the existing GenerateSQL handler.
# Patches only the running reqa-a2a container; does not change Java, Electron, or Maven.
# Container recreation may replace this file unless you also update the source used for its Docker build.
$ErrorActionPreference = 'Stop'
$container = 'reqa-a2a'
$source = Join-Path $PSScriptRoot 'a2a_nl2sql_agent_FIXED.py'
$backupDir = Join-Path $HOME 'Downloads\REQA-A2A-Backups'
$backup = Join-Path $backupDir ('a2a_nl2sql_agent-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.py')
$target = $null
$copied = $false

try {
    if (-not (Test-Path -LiteralPath $source)) { throw "Patched file missing beside script: $source" }
    New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
    Write-Host '[1/5] Checking the running reqa-a2a container...' -ForegroundColor Cyan
    $running = (& docker inspect -f '{{.State.Running}}' $container 2>&1 | Out-String).Trim()
    if ($LASTEXITCODE -ne 0 -or $running -ne 'true') { throw "Container $container is not running." }

    $finder = @'
import os, sys
roots = [os.getcwd(), '/app', '/code', '/usr/src/app', '/workspace']
for root in roots:
    p = os.path.join(root, 'a2a_nl2sql_agent.py')
    if os.path.isfile(p):
        print(os.path.realpath(p))
        break
else:
    sys.exit('a2a_nl2sql_agent.py was not found at expected application roots')
'@
    $result = @($finder | & docker exec -i $container python -)
    if ($LASTEXITCODE -ne 0) { throw 'Could not locate a2a_nl2sql_agent.py inside the container.' }
    $target = (@($result) | Where-Object { $_ -match '^/' } | Select-Object -First 1)
    if (-not $target) { throw 'Missing target path in container.' }
    $target = $target.Trim()
    Write-Host "SOURCE: $target" -ForegroundColor Green

    Write-Host '[2/5] Backing up the existing Python file...' -ForegroundColor Cyan
    & docker cp "${container}:$target" $backup
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path $backup)) { throw 'Backup failed; no patch applied.' }
    Write-Host "BACKUP: $backup" -ForegroundColor Green

    Write-Host '[3/5] Installing the corrected Python file...' -ForegroundColor Cyan
    & docker cp $source "${container}:$target"
    if ($LASTEXITCODE -ne 0) { throw 'Docker copy failed.' }
    $copied = $true
    & docker exec $container python -m py_compile $target
    if ($LASTEXITCODE -ne 0) {
        & docker cp $backup "${container}:$target" | Out-Null
        $copied = $false
        throw 'Python syntax validation failed. Original file restored.'
    }
    Write-Host 'SUCCESS: File copied and Python syntax verified.' -ForegroundColor Green

    Write-Host '[4/5] Restarting A2A service...' -ForegroundColor Cyan
    & docker restart $container
    if ($LASTEXITCODE -ne 0) { throw 'Docker restart failed. Original file saved in backup folder.' }
    $ready = $false
    for ($i=0; $i -lt 24; $i++) {
        $tcp = New-Object System.Net.Sockets.TcpClient
        try {
            $ar = $tcp.BeginConnect('127.0.0.1', 5022, $null, $null)
            if ($ar.AsyncWaitHandle.WaitOne(1500)) {
                $tcp.EndConnect($ar)
                $ready = $true
            }
        } catch {} finally { $tcp.Dispose() }
        if ($ready) { break }
        Start-Sleep -Seconds 2
    }
    if (-not $ready) { throw 'Port 5022 did not become ready. Check docker logs reqa-a2a.' }
    Write-Host 'SUCCESS: A2A port 5022 is reachable.' -ForegroundColor Green

    Write-Host '[5/5] Testing plain SQL through A2A (may take several minutes)...' -ForegroundColor Cyan
    $body = @{
        jsonrpc = '2.0'
        id = [guid]::NewGuid().ToString()
        method = 'message/send'
        params = @{
            message = @{
                role = 'user'
                messageId = [guid]::NewGuid().ToString()
                parts = @(@{kind='text';text='SELECT * FROM context_ol_assoc LIMIT 1'})
            }
        }
    } | ConvertTo-Json -Depth 12 -Compress
    $response = Invoke-WebRequest 'http://127.0.0.1:5022/' -Method Post -ContentType 'application/json' -Body $body -UseBasicParsing -TimeoutSec 420
    $parsed = $response.Content | ConvertFrom-Json
    Write-Host "HTTP STATUS: $($response.StatusCode)"
    if ($parsed.error) { throw "A2A JSON-RPC error: $($parsed.error.message)" }
    $state = $parsed.result.status.state
    if (-not $state) { $state = '(not specified)' }
    Write-Host "A2A TASK STATE: $state"
    if ($state -eq 'failed') {
        $messages = @($parsed.result.status.message.parts | Where-Object { $_.text } | ForEach-Object { $_.text })
        if ($messages.Count) { Write-Host ('AGENT ERROR: ' + ($messages -join ' | ')) -ForegroundColor Yellow }
        throw 'A2A request reached the server but the agent task failed. Python code is installed; inspect the agent error above.'
    }
    if ($state -eq 'completed') {
        Write-Host 'SUCCESS: A2A task completed after sending plain SQL.' -ForegroundColor Green
    } else {
        Write-Host 'Request was accepted; verify the final response in CALIAN.AI.' -ForegroundColor Yellow
    }
    Write-Host 'IMPORTANT: If you recreate the Docker container, also update the source used to build its image.' -ForegroundColor Yellow
} catch {
    Write-Host "FAILED: $($_.Exception.Message)" -ForegroundColor Red
    if (Test-Path $backup) { Write-Host "Your original Python file is safely backed up at: $backup" -ForegroundColor Yellow }
    if ($copied) { Write-Host 'The patch is still in the container; no automatic rollback was performed after Python syntax verification.' -ForegroundColor Yellow }
    exit 1
}
