# MIDAS / Calian Copilot V5.3 targeted guided-control fix, based on V5.2.
# Does not stop processes, change ports, registries or credentials.
$ErrorActionPreference = 'Stop'
$relativeRootMarker = 'midas\midas-frontend\src\app\components\calian-ai\midas-calian-copilot.component.ts'
$files = @(
  @{ from='PATCH\midas-bridge.ts'; dest='Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\midas-bridge.ts'; signature='parseMidasCommand' },
  @{ from='PATCH\calian-app.component.ts'; dest='Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\app.component.ts'; signature='proposeMidasCommand' },
  @{ from='PATCH\calian-app.component.html'; dest='Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\app.component.html'; signature='MIDAS control request' },
  @{ from='PATCH\calian-app.component.scss'; dest='Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\app.component.scss'; signature='app-shell' },
  @{ from='PATCH\midas-calian-copilot.component.ts'; dest=$relativeRootMarker; signature='MIDAS_CALIAN_V1' }
)
Write-Host 'MIDAS + Calian AI Copilot V5.3 - Guided control fix' -ForegroundColor Cyan
Write-Host 'This patch targets V5.1/V5.2 source installations. It does not terminate any process.'
$roots = @((Join-Path $env:USERPROFILE 'Downloads'), (Get-Location).Path) | Select-Object -Unique
$found = @()
foreach ($folder in $roots) {
  if (Test-Path -LiteralPath $folder) {
    $found += @(Get-ChildItem -LiteralPath $folder -Recurse -File -Filter 'midas-calian-copilot.component.ts' -ErrorAction SilentlyContinue | Where-Object {
      $_.FullName.EndsWith($relativeRootMarker,[StringComparison]::OrdinalIgnoreCase)
    })
  }
}
$found = @($found | Sort-Object FullName -Unique | Sort-Object LastWriteTime -Descending)
if (!$found.Count) { throw 'No MIDAS V5.2 source found under Downloads/current folder. Extract the full V5.3 package instead.' }
Write-Host 'Choose the source installation actually used by your RUNNING browser instance:' -ForegroundColor Yellow
for($i=0;$i -lt $found.Count;$i++) { Write-Host ('[{0}] {1}' -f ($i+1),$found[$i].FullName) }
$answer=Read-Host 'Enter project number (blank cancels)'
if ($answer -notmatch '^\d+$' -or [int]$answer -lt 1 -or [int]$answer -gt $found.Count) { throw 'Cancelled: no files were changed.' }
$chosen=$found[[int]$answer - 1]
$projectRoot=$chosen.FullName.Substring(0,$chosen.FullName.Length-$relativeRootMarker.Length).TrimEnd([char]'\',[char]'/')
Write-Host ('Selected project: '+$projectRoot) -ForegroundColor Cyan
foreach ($entry in $files) {
  $destination=Join-Path $projectRoot $entry.dest
  $source=Join-Path $PSScriptRoot $entry.from
  if (!(Test-Path -LiteralPath $source)) { throw ('Patch file missing: '+$source) }
  if (!(Test-Path -LiteralPath $destination)) { throw ('Project source file missing: '+$destination) }
  if (!([IO.File]::ReadAllText($destination).Contains($entry.signature))) { throw ('Unexpected source version; refusing to overwrite: '+$destination) }
}
$calian = Join-Path $projectRoot 'Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\app.component.ts'
$current = [IO.File]::ReadAllText($calian)
if ($current.Contains('explainMidasCommand(this.midasCommand,this.midasContext)')) { Write-Host 'V5.3 appears to be already installed in this source. Check the running Calian frontend port.'; exit 0 }
if (!$current.Contains('Command not recognized. Try Open Combat Power') -and !$current.Contains('No supported MIDAS action matched')) { throw 'Expected V5.1/V5.2 source not found. Patch not applied.' }
$agree=Read-Host 'Back up five source files and apply V5.3? Type Y to proceed'
if ($agree -notin @('y','Y')) { Write-Host 'Cancelled.'; exit 0 }
$backup=Join-Path $projectRoot ('V5_3_BACKUP_'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $backup -Force | Out-Null
for($i=0;$i -lt $files.Count;$i++) {
  Copy-Item -LiteralPath (Join-Path $projectRoot $files[$i].dest) -Destination (Join-Path $backup ($i.ToString()+'-'+[IO.Path]::GetFileName($files[$i].dest))) -ErrorAction Stop
}
try {
  foreach ($entry in $files) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot $entry.from) -Destination (Join-Path $projectRoot $entry.dest) -Force -ErrorAction Stop
    Write-Host ('Patched: '+$entry.dest) -ForegroundColor Green
  }
} catch {
  Write-Warning 'Apply failed; restoring backups.'
  for($i=0;$i -lt $files.Count;$i++) {
    Copy-Item -LiteralPath (Join-Path $backup ($i.ToString()+'-'+[IO.Path]::GetFileName($files[$i].dest))) -Destination (Join-Path $projectRoot $files[$i].dest) -Force
  }
  throw
}
Write-Host ('Backup: '+$backup)
Write-Host 'Refresh the running Calian browser UI after Angular recompiles.' -ForegroundColor Green
Write-Host 'Check Session Inspector for Controls V5.3. If absent, the browser points to a different Calian server.' -ForegroundColor Yellow
Write-Host 'Note: a disconnected MIDAS data source still prevents entity/timebound operations.'
