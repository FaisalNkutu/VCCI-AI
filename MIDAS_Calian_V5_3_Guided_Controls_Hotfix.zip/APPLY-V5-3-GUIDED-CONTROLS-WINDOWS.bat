@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLY-V5-3-GUIDED-CONTROLS-WINDOWS.ps1"
if errorlevel 1 echo Update failed. See the error above.
pause
