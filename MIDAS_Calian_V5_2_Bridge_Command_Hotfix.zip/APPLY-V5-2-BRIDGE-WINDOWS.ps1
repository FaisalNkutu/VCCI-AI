# MIDAS + Calian AI V5.2 -- targeted source update for V5/V5.1.
# It does not stop servers, change ports or registries, modify credentials,
# disable security checks, or touch the MIDAS data source.
$ErrorActionPreference = 'Stop'
$hostSuffix = 'midas\midas-frontend\src\app\components\calian-ai\midas-calian-copilot.component.ts'
$items = @(
  @{ from='PATCH\midas-calian-copilot.component.ts'; to=$hostSuffix; marker='MIDAS_CALIAN_V1' },
  @{ from='PATCH\calian-app.component.ts'; to='Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\app.component.ts'; marker='proposeMidasCommand' },
  @{ from='PATCH\midas-bridge.ts'; to='Standalone_Calian_AI_Chatbot\CALIAN_AI_ELECTRON_THEMES\src\app\midas-bridge.ts'; marker='DISPLAY_NAMES' }
)
Write-Host 'MIDAS + Calian V5.2 -- context bridge and command correction' -ForegroundColor Cyan
$searchRoots = @()
foreach ($place in @((Join-Path $env:USERPROFILE 'Downloads'), (Get-Location).Path)) {
  if ((Test-Path -LiteralPath $place) -and ($searchRoots -notcontains $place)) { $searchRoots += $place }
}
$found = @()
foreach ($place in $searchRoots) {
  $found += @(Get-ChildItem -LiteralPath $place -Recurse -File -Filter 'midas-calian-copilot.component.ts' -ErrorAction SilentlyContinue | Where-Object {
    $_.FullName.EndsWith($hostSuffix,[StringComparison]::OrdinalIgnoreCase)
  })
}
$found = @($found | Sort-Object -Property FullName -Unique | Sort-Object LastWriteTime -Descending)
if ($found.Count -eq 0) { throw 'MIDAS V5/V5.1 source not found. Extract the full V5.2 ZIP or place this patch beside the extracted project.' }
Write-Host 'Available extracted MIDAS projects:' -ForegroundColor Yellow
for ($i=0; $i -lt $found.Count; $i++) {
  Write-Host ('[{0}] {1}' -f ($i+1),$found[$i].FullName)
}
if ($found.Count -eq 1) { $chosen = $found[0] }
else {
  $answer = Read-Host 'Enter the number of your RUNNING MIDAS project (blank cancels)'
  if ($answer -notmatch '^\d+$' -or [int]$answer -lt 1 -or [int]$answer -gt $found.Count) { throw 'Cancelled: no project changed.' }
  $chosen = $found[[int]$answer-1]
}
$projectRoot = $chosen.FullName.Substring(0,$chosen.FullName.Length-$hostSuffix.Length).TrimEnd([char]'\',[char]'/')
Write-Host ('Selected installation: '+$projectRoot) -ForegroundColor Cyan
$sourceDir = $PSScriptRoot
foreach ($entry in $items) {
  $file = Join-Path $projectRoot $entry.to
  $replacement = Join-Path $sourceDir $entry.from
  if (-not (Test-Path -LiteralPath $file)) { throw ('Required project file not found: '+$file) }
  if (-not (Test-Path -LiteralPath $replacement)) { throw ('Patch file missing: '+$replacement) }
  $text = [System.IO.File]::ReadAllText($file)
  if (-not $text.Contains($entry.marker)) { throw ('Source version not recognized, leaving unchanged: '+$file) }
}
$confirm = Read-Host 'Back up and apply V5.2 to this installation? Enter Y to continue'
if ($confirm -notin @('Y','y')) { Write-Host 'Cancelled; no changes made.'; exit 0 }
$backupDir = Join-Path $projectRoot ('V5_2_BACKUP_'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
# Back up every original file before modifying any of them.
for ($i=0; $i -lt $items.Count; $i++) {
  Copy-Item -LiteralPath (Join-Path $projectRoot $items[$i].to) -Destination (Join-Path $backupDir ($i.ToString()+'-'+[IO.Path]::GetFileName($items[$i].to))) -ErrorAction Stop
}
try {
  foreach ($entry in $items) {
    Copy-Item -LiteralPath (Join-Path $sourceDir $entry.from) -Destination (Join-Path $projectRoot $entry.to) -Force -ErrorAction Stop
    Write-Host ('Updated: '+$entry.to) -ForegroundColor Green
  }
} catch {
  Write-Warning 'A copy failed. Restoring all original files.'
  for ($i=0; $i -lt $items.Count; $i++) {
    Copy-Item -LiteralPath (Join-Path $backupDir ($i.ToString()+'-'+[IO.Path]::GetFileName($items[$i].to))) -Destination (Join-Path $projectRoot $items[$i].to) -Force
  }
  throw
}
Write-Host ('Original source backups: '+$backupDir) -ForegroundColor Cyan
Write-Host 'No services were stopped. Both MIDAS and Calian Angular watch mode should recompile.' -ForegroundColor Green
Write-Host 'Refresh MIDAS after recompilation, then test: Open Combat Power.' -ForegroundColor Green
