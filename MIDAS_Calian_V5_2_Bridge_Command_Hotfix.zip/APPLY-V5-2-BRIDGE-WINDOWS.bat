@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLY-V5-2-BRIDGE-WINDOWS.ps1"
echo.
pause
