/** Explicitly approved MIDAS <-> Calian iframe protocol. Never executes arbitrary scripts. */
export const MIDAS_BRIDGE_ID = 'MIDAS_CALIAN_V1';
export type MidasAction = 'navigate' | 'time_format' | 'cp_time_range' | 'cp_select_entity';
export interface MidasContext {
  route?: string | null;
  selectedTimeFormat?: string;
  availableTimeFormats?: string[];
  cpTimeframe?: { start: number; end: number };
  cpSelectedEntityIds?: number[];
  cpEntities?: { id: number; name: string }[];
}
export interface MidasRequest { action: MidasAction; params: Record<string, unknown> }
export interface MidasCapabilities { dashboards: string[]; actions: string[]; approvalRequired: boolean }

const DISPLAY_NAMES: Record<string,string> = {
  summary:'summary', 'h-hour':'h-hour', 'rate of movement':'rom', rom:'rom',
  'picture of enemy':'poe', poe:'poe', 'control measures':'cm', cm:'cm',
  fratricide:'fratricide', 'enemy engagement':'enemy-engagement',
  'combat power':'cp', cp:'cp', 'unit watch':'unit-watch', 'entity watch':'unit-watch',
  'holdings rollup':'holdings-rollup', 'c2 compare':'c2', c2:'c2'
};
export function parseMidasCommand(raw: string, context: MidasContext | null, capabilities: MidasCapabilities | null): MidasRequest | null {
  // The MIDAS host validates every proposed action against its own allowlist.
  // A delayed capabilities handshake must not prevent a known, safe navigation
  // request from being proposed. It still requires the user to approve in MIDAS.
  const text = raw.normalize('NFKC').trim().toLowerCase().replace(/\s+/g, ' ').replace(/[.!?]+$/,'');
  if (!text || text.length > 160) return null;
  const nav = text.match(/^(?:open|show|navigate to|go to|switch to|display)(?: the)? (.+?)(?: dashboard| view| report)?$/);
  if (nav) {
    const id = DISPLAY_NAMES[nav[1].trim()];
    if (id) return { action:'navigate', params:{dashboard:id} };
  }
  const format = text.match(/^(?:set|change)(?: the)? time format to (.{1,60})$/);
  if (format) {
    const name = context?.availableTimeFormats?.find(x => x.toLowerCase() === format[1]);
    if (name) return {action:'time_format',params:{name}};
  }
  const range = text.match(/^(?:set|change)(?: combat power)? time (?:range|frame) (?:to )?(\d+(?:\.\d+)?) (?:to|through|-) (\d+(?:\.\d+)?)$/);
  if (range && context?.route === '/advmetrics/cp') return {action:'cp_time_range',params:{start:Number(range[1]),end:Number(range[2])}};
  const unit = text.match(/^(select|deselect) (?:unit|entity) (.{1,70})$/);
  if (unit && context?.route === '/advmetrics/cp') {
    const key=unit[2].trim();
    const found=context.cpEntities?.find(x => String(x.id) === key || x.name.toLowerCase() === key);
    if (found) return {action:'cp_select_entity',params:{id:found.id,selected:unit[1]==='select'}};
  }
  return null;
}
/** Assistant-generated snippets are suggestions only and ALWAYS require MIDAS approval. */
export function suggestedActionFromAgent(text: string): MidasRequest | null {
  const match = text.match(/```midas-action\s*([\s\S]{1,2048}?)```/i);
  if (!match) return null;
  try {
    const value: unknown = JSON.parse(match[1]);
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const record = value as Record<string,unknown>;
    const allowed = ['navigate','time_format','cp_time_range','cp_select_entity'];
    if (typeof record['action'] !== 'string' || !allowed.includes(record['action']) || !record['params'] || typeof record['params'] !== 'object' || Array.isArray(record['params'])) return null;
    return {action:record['action'] as MidasAction,params:record['params'] as Record<string,unknown>};
  } catch { return null; }
}
